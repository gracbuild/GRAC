B='/home/claude/'
full=''.join(open(B+f).read() for f in ['442_a.sql','442_b.sql','442_c.sql','442_d.sql'])+"\n"+open(B+'442_f.sql').read()
assert all(ord(c)<128 for c in full)
open(B+'442.sql','w',newline='').write(full); print('442.sql', full.count('\n'))
