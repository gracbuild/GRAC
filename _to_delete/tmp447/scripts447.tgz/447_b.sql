-- =====================================================================
-- 3. Operands, facts and the one evaluation (19.7 "rules apply
--    consistently to forms, imports, APIs, bulk preview, dashboards and
--    reports")
-- =====================================================================
-- Operands a condition may use: every field of the dictionary plus the
-- derived ones below (D143).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_consistency_operands ()
RETURNS TABLE
AS
RETURN
    SELECT CAST(v.k AS NVARCHAR(100)) AS OperandKey, CAST(v.label AS NVARCHAR(200)) AS OperandLabel,
           CAST(N'DERIVED' AS NVARCHAR(10)) AS OperandKind, CAST(v.hint AS NVARCHAR(300)) AS Hint, v.ord AS DisplayOrder
      FROM (VALUES
        (N'CRITICALITY',               N'Criticality (name)',                    N'Name of the asset criticality, for example Low or Critical.', 10),
        (N'CRITICALITY_SCORE',         N'Criticality score',                     N'Score of the asset criticality on the Active valuation configuration.', 20),
        (N'SERVICE_CRITICALITY',       N'Supported service criticality (name)',  N'Highest criticality of the business services the asset supports.', 30),
        (N'SERVICE_CRITICALITY_SCORE', N'Supported service criticality score',   N'Score of that criticality on the Active valuation configuration.', 40),
        (N'ASSET_VALUE_STATUS',        N'Asset Value validation status',         N'NOT_RATED, INCOMPLETE, INVALID or VALID.', 50)
      ) v(k, label, hint, ord)
    UNION ALL
    SELECT d.field_key, d.display_label, N'FIELD', CAST(NULL AS NVARCHAR(300)), 1000 + ISNULL(d.display_order, 0)
      FROM grac_practice.asset_field_definition d
     WHERE d.status_code = N'ACTIVE';
GO

-- Facts of each asset: stored values (multi-select values as elements)
-- and the derived operands.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_consistency_facts (@organization_id BIGINT, @asset_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT a.asset_id AS AssetId, CAST(sv.FieldKey AS NVARCHAR(100)) AS FactKey, CAST(LEFT(e.val, 400) AS NVARCHAR(400)) AS FactValue
      FROM grac_practice.organization_dependency_asset a
     CROSS APPLY grac_practice.fn_asset_stored_values(a.asset_id) sv
     CROSS APPLY (SELECT LTRIM(RTRIM(j.[value])) AS val
                    FROM OPENJSON(CASE WHEN ISJSON(sv.Value) = 1 AND LEFT(LTRIM(sv.Value), 1) = N'[' THEN sv.Value
                                       ELSE N'["' + STRING_ESCAPE(sv.Value, 'json') + N'"]' END) j) e
     WHERE a.organization_id = @organization_id AND a.merged_into_asset_id IS NULL
       AND (@asset_id IS NULL OR a.asset_id = @asset_id) AND e.val <> N''
    UNION ALL
    SELECT a.asset_id, v.k, v.val
      FROM grac_practice.organization_dependency_asset a
      LEFT JOIN grac_practice.criticality_master cm ON cm.criticality_id = a.criticality_id
      OUTER APPLY (SELECT TOP (1) cl.score
                     FROM grac_practice.asset_valuation_config c
                     JOIN grac_practice.asset_criticality_level cl ON cl.config_id = c.config_id
                    WHERE c.organization_id = a.organization_id AND c.is_active_version = 1
                      AND cl.criticality_master_id = a.criticality_id
                    ORDER BY cl.score DESC) cs
      OUTER APPLY (SELECT TOP (1) scm.criticality_name AS label, scl.score
                     FROM grac_practice.asset_relationship x
                     JOIN grac_practice.business_service b ON b.service_id = x.target_id AND b.organization_id = a.organization_id
                     JOIN grac_practice.criticality_master scm ON scm.criticality_id = b.criticality_id
                     OUTER APPLY (SELECT TOP (1) cl.score
                                    FROM grac_practice.asset_valuation_config c
                                    JOIN grac_practice.asset_criticality_level cl ON cl.config_id = c.config_id
                                   WHERE c.organization_id = a.organization_id AND c.is_active_version = 1
                                     AND cl.criticality_master_id = b.criticality_id
                                   ORDER BY cl.score DESC) scl
                    WHERE x.organization_id = a.organization_id AND x.relationship_type_code = N'SUPPORTS_SERVICE'
                      AND x.source_kind = N'ASSET' AND x.source_id = a.asset_id AND x.target_kind = N'SERVICE'
                      AND x.status = N'ACTIVE' AND x.effective_from <= CAST(SYSUTCDATETIME() AS DATE)
                      AND (x.effective_to IS NULL OR x.effective_to >= CAST(SYSUTCDATETIME() AS DATE))
                      AND b.status <> N'RETIRED'
                    ORDER BY ISNULL(scl.score, -1) DESC, scm.display_order) sc
      LEFT JOIN grac_practice.asset_valuation_result vr ON vr.asset_id = a.asset_id
     CROSS APPLY (VALUES
        (CAST(N'CRITICALITY' AS NVARCHAR(100)),       CAST(cm.criticality_name AS NVARCHAR(400))),
        (N'CRITICALITY_SCORE',                         CAST(cs.score AS NVARCHAR(400))),
        (N'SERVICE_CRITICALITY',                       CAST(sc.label AS NVARCHAR(400))),
        (N'SERVICE_CRITICALITY_SCORE',                 CAST(sc.score AS NVARCHAR(400))),
        (N'ASSET_VALUE_STATUS',                        CAST(vr.validation_status AS NVARCHAR(400)))
     ) v(k, val)
     WHERE a.organization_id = @organization_id AND a.merged_into_asset_id IS NULL
       AND (@asset_id IS NULL OR a.asset_id = @asset_id) AND v.val IS NOT NULL;
GO

-- Which in-scope assets each rule matches. @rule_id NULL = the Active,
-- in-effect rules; a @rule_id = that rule in any status (Draft preview).
-- Disposed, archived and merged-away assets are not evaluated (D145).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_consistency_eval (@organization_id BIGINT, @asset_id BIGINT, @rule_id BIGINT)
RETURNS @out TABLE (
    AssetId    BIGINT        NOT NULL,
    RuleId     BIGINT        NOT NULL,
    RuleCode   NVARCHAR(20)  COLLATE DATABASE_DEFAULT NOT NULL,
    RuleName   NVARCHAR(200) COLLATE DATABASE_DEFAULT NOT NULL,
    Severity   NVARCHAR(20)  COLLATE DATABASE_DEFAULT NOT NULL,
    ActionCode NVARCHAR(20)  COLLATE DATABASE_DEFAULT NOT NULL,
    Matched    BIT           NOT NULL,
    FactsJson  NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL,
    PRIMARY KEY (AssetId, RuleId))
AS
BEGIN
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    DECLARE @rules TABLE (rule_id BIGINT NOT NULL PRIMARY KEY, rule_code NVARCHAR(20) COLLATE DATABASE_DEFAULT NOT NULL,
                          rule_name NVARCHAR(200) COLLATE DATABASE_DEFAULT NOT NULL, severity NVARCHAR(20) COLLATE DATABASE_DEFAULT NOT NULL,
                          action_code NVARCHAR(20) COLLATE DATABASE_DEFAULT NOT NULL, scope_kind NVARCHAR(12) COLLATE DATABASE_DEFAULT NOT NULL,
                          scope_ref_id BIGINT NULL);
    INSERT @rules (rule_id, rule_code, rule_name, severity, action_code, scope_kind, scope_ref_id)
    SELECT r.rule_id, r.rule_code, r.rule_name, r.severity, r.action_code, r.scope_kind, r.scope_ref_id
      FROM grac_practice.asset_consistency_rule r
     WHERE r.organization_id = @organization_id
       AND (   (@rule_id IS NULL AND r.status = N'ACTIVE' AND ISNULL(r.effective_from, @today) <= @today
                AND (r.effective_to IS NULL OR r.effective_to >= @today))
            OR r.rule_id = @rule_id)
       AND EXISTS (SELECT 1 FROM grac_practice.asset_consistency_rule_condition c WHERE c.rule_id = r.rule_id);
    IF NOT EXISTS (SELECT 1 FROM @rules) RETURN;

    DECLARE @ra TABLE (asset_id BIGINT NOT NULL, rule_id BIGINT NOT NULL, PRIMARY KEY (asset_id, rule_id));
    INSERT @ra (asset_id, rule_id)
    SELECT a.asset_id, r.rule_id
      FROM grac_practice.organization_dependency_asset a
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
      JOIN @rules r
        ON r.scope_kind = N'TENANT'
        OR (r.scope_kind = N'CATEGORY'    AND a.asset_category_id    = r.scope_ref_id)
        OR (r.scope_kind = N'SUBCATEGORY' AND a.asset_subcategory_id = r.scope_ref_id)
        OR (r.scope_kind = N'ASSET_TYPE'  AND a.asset_type_id        = r.scope_ref_id)
        OR (r.scope_kind = N'SERVICE' AND EXISTS (
                SELECT 1 FROM grac_practice.asset_relationship x
                 WHERE x.organization_id = a.organization_id AND x.relationship_type_code = N'SUPPORTS_SERVICE'
                   AND x.source_kind = N'ASSET' AND x.source_id = a.asset_id AND x.target_kind = N'SERVICE'
                   AND x.target_id = r.scope_ref_id AND x.status = N'ACTIVE' AND x.effective_from <= @today
                   AND (x.effective_to IS NULL OR x.effective_to >= @today)))
     WHERE a.organization_id = @organization_id AND a.merged_into_asset_id IS NULL
       AND (@asset_id IS NULL OR a.asset_id = @asset_id)
       AND ISNULL(s.status_code, N'') NOT IN (N'DISPOSED', N'ARCHIVED');
    IF NOT EXISTS (SELECT 1 FROM @ra) RETURN;

    DECLARE @facts TABLE (asset_id BIGINT NOT NULL, fact_key NVARCHAR(100) COLLATE DATABASE_DEFAULT NOT NULL,
                          fact_value NVARCHAR(400) COLLATE DATABASE_DEFAULT NOT NULL,
                          INDEX ix_pm_acons_facts CLUSTERED (asset_id, fact_key));
    INSERT @facts (asset_id, fact_key, fact_value)
    SELECT f.AssetId, f.FactKey, f.FactValue
      FROM grac_practice.fn_asset_consistency_facts(@organization_id, @asset_id) f
     WHERE f.FactKey IN (SELECT c.operand_key FROM grac_practice.asset_consistency_rule_condition c JOIN @rules r ON r.rule_id = c.rule_id)
       AND f.AssetId IN (SELECT asset_id FROM @ra);

    -- One row per condition: 421 operators, text compared in the database collation.
    DECLARE @cond TABLE (asset_id BIGINT NOT NULL, rule_id BIGINT NOT NULL, group_no INT NOT NULL, ok INT NOT NULL);
    INSERT @cond (asset_id, rule_id, group_no, ok)
    SELECT ra.asset_id, ra.rule_id, c.group_no,
           CASE c.operator_code
             WHEN N'EQ'        THEN CASE WHEN EXISTS (SELECT 1 FROM @facts f WHERE f.asset_id = ra.asset_id AND f.fact_key = c.operand_key AND f.fact_value = c.compare_value) THEN 1 ELSE 0 END
             WHEN N'NEQ'       THEN CASE WHEN EXISTS (SELECT 1 FROM @facts f WHERE f.asset_id = ra.asset_id AND f.fact_key = c.operand_key AND f.fact_value = c.compare_value) THEN 0 ELSE 1 END
             WHEN N'IN'        THEN CASE WHEN EXISTS (SELECT 1 FROM @facts f
                                                       JOIN STRING_SPLIT(ISNULL(c.compare_value, N''), N'|') l ON LTRIM(RTRIM(l.[value])) = f.fact_value
                                                      WHERE f.asset_id = ra.asset_id AND f.fact_key = c.operand_key) THEN 1 ELSE 0 END
             WHEN N'NOT_IN'    THEN CASE WHEN EXISTS (SELECT 1 FROM @facts f
                                                       JOIN STRING_SPLIT(ISNULL(c.compare_value, N''), N'|') l ON LTRIM(RTRIM(l.[value])) = f.fact_value
                                                      WHERE f.asset_id = ra.asset_id AND f.fact_key = c.operand_key) THEN 0 ELSE 1 END
             WHEN N'EMPTY'     THEN CASE WHEN EXISTS (SELECT 1 FROM @facts f WHERE f.asset_id = ra.asset_id AND f.fact_key = c.operand_key) THEN 0 ELSE 1 END
             WHEN N'NOT_EMPTY' THEN CASE WHEN EXISTS (SELECT 1 FROM @facts f WHERE f.asset_id = ra.asset_id AND f.fact_key = c.operand_key) THEN 1 ELSE 0 END
             WHEN N'GT'  THEN CASE WHEN nv.num >  TRY_CONVERT(DECIMAL(38, 6), c.compare_value) THEN 1 ELSE 0 END
             WHEN N'GTE' THEN CASE WHEN nv.num >= TRY_CONVERT(DECIMAL(38, 6), c.compare_value) THEN 1 ELSE 0 END
             WHEN N'LT'  THEN CASE WHEN nv.num <  TRY_CONVERT(DECIMAL(38, 6), c.compare_value) THEN 1 ELSE 0 END
             WHEN N'LTE' THEN CASE WHEN nv.num <= TRY_CONVERT(DECIMAL(38, 6), c.compare_value) THEN 1 ELSE 0 END
             WHEN N'DATE_BEFORE_TODAY' THEN CASE WHEN nv.dt < @today THEN 1 ELSE 0 END
             WHEN N'DATE_AFTER_TODAY'  THEN CASE WHEN nv.dt > @today THEN 1 ELSE 0 END
             WHEN N'DATE_WITHIN_DAYS'  THEN CASE WHEN nv.dt >= @today
                                                  AND nv.dt <= DATEADD(DAY, ISNULL(TRY_CONVERT(INT, c.compare_value), 0), @today) THEN 1 ELSE 0 END
             ELSE 0 END
      FROM @ra ra
      JOIN grac_practice.asset_consistency_rule_condition c ON c.rule_id = ra.rule_id
      OUTER APPLY (SELECT TOP (1) TRY_CONVERT(DECIMAL(38, 6), f.fact_value) AS num, TRY_CONVERT(DATE, f.fact_value, 23) AS dt
                     FROM @facts f WHERE f.asset_id = ra.asset_id AND f.fact_key = c.operand_key) nv;

    DECLARE @grp TABLE (asset_id BIGINT NOT NULL, rule_id BIGINT NOT NULL, group_no INT NOT NULL, ok INT NOT NULL);
    INSERT @grp (asset_id, rule_id, group_no, ok)
    SELECT asset_id, rule_id, group_no, MIN(ok) FROM @cond GROUP BY asset_id, rule_id, group_no;

    INSERT @out (AssetId, RuleId, RuleCode, RuleName, Severity, ActionCode, Matched, FactsJson)
    SELECT ra.asset_id, r.rule_id, r.rule_code, r.rule_name, r.severity, r.action_code,
           CASE WHEN EXISTS (SELECT 1 FROM @grp g WHERE g.asset_id = ra.asset_id AND g.rule_id = ra.rule_id AND g.ok = 1) THEN 1 ELSE 0 END,
           NULL
      FROM @ra ra JOIN @rules r ON r.rule_id = ra.rule_id;

    -- The operand values behind a match (kept on the finding).
    UPDATE o
       SET FactsJson = (SELECT f.fact_key AS operand, f.fact_value AS value
                          FROM @facts f
                         WHERE f.asset_id = o.AssetId
                           AND f.fact_key IN (SELECT c.operand_key FROM grac_practice.asset_consistency_rule_condition c WHERE c.rule_id = o.RuleId)
                         ORDER BY f.fact_key
                           FOR JSON PATH)
      FROM @out o
     WHERE o.Matched = 1;
    RETURN;
END
GO

-- =====================================================================
-- 4. Asset Value for the risk module (5.1.18.3, D151): per risk with
--    linked assets, the highest valid Asset Value and whether a linked
--    Asset Value changed after the risk was last assessed. First
--    calculations are not changes. Risk scoring is unchanged (19.12).
-- =====================================================================
CREATE OR ALTER FUNCTION grac_practice.fn_asset_risk_value (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT r.risk_register_id AS RiskRegisterId, la.LinkedAssets, t.AssetId AS TopAssetId,
           t.Score AS AssetValueScore, t.Category AS AssetValueCategory, ch.LastValueChangeDt,
           COALESCE(r.residual_assessed_dt, r.updated_dt, r.entered_dt) AS RiskAssessedDt,
           CASE WHEN ch.LastValueChangeDt > COALESCE(r.residual_assessed_dt, r.updated_dt, r.entered_dt) THEN 1 ELSE 0 END AS ReviewSuggested
      FROM grac_practice.risk_register r
     CROSS APPLY (SELECT COUNT(DISTINCT m.dependency_object_id) AS LinkedAssets
                    FROM grac_practice.risk_dependency_map m
                    JOIN grac_practice.dependency_type_master dt ON dt.dependency_type_id = m.dependency_type_id
                                                                AND (dt.dependency_type_code = N'ASSET' OR dt.dependency_type_name = N'Asset')
                   WHERE m.risk_register_id = r.risk_register_id) la
     OUTER APPLY (SELECT TOP (1) vr.asset_id AS AssetId, vr.asset_value_score AS Score, vr.asset_value_category AS Category
                    FROM grac_practice.risk_dependency_map m
                    JOIN grac_practice.dependency_type_master dt ON dt.dependency_type_id = m.dependency_type_id
                                                                AND (dt.dependency_type_code = N'ASSET' OR dt.dependency_type_name = N'Asset')
                    JOIN grac_practice.asset_valuation_result vr ON vr.asset_id = m.dependency_object_id AND vr.validation_status = N'VALID'
                   WHERE m.risk_register_id = r.risk_register_id
                   ORDER BY vr.asset_value_score DESC, vr.asset_id) t
     OUTER APPLY (SELECT MAX(h.entered_dt) AS LastValueChangeDt
                    FROM grac_practice.risk_dependency_map m
                    JOIN grac_practice.dependency_type_master dt ON dt.dependency_type_id = m.dependency_type_id
                                                                AND (dt.dependency_type_code = N'ASSET' OR dt.dependency_type_name = N'Asset')
                    JOIN grac_practice.asset_valuation_history h ON h.asset_id = m.dependency_object_id
                   WHERE m.risk_register_id = r.risk_register_id AND h.prev_status IS NOT NULL
                     AND (ISNULL(h.prev_category, N'') <> ISNULL(h.new_category, N'') OR ISNULL(h.prev_score, -1) <> ISNULL(h.new_score, -1))) ch
     WHERE r.organization_id = @organization_id AND la.LinkedAssets > 0;
GO
PRINT '447: operands, facts, evaluation and risk value functions created.';
GO

