parts = ["445_a.sql", "445_b.sql", "445_c.sql", "445_e.sql", "445_f.sql"]
s = "".join(open("/home/claude/" + p).read() for p in parts)
open("/home/claude/445.sql", "w").write(s)
print("445.sql", s.count("\n"))
