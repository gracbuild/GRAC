B='/home/claude/'
re_body=open(B+'b440/new_sp_asset_lifecycle_transition.sql').read()
e = "\n-- =====================================================================\n-- 7. Lifecycle gate: sp_asset_lifecycle_transition (435 body, 440 lines marked)\n-- =====================================================================\n" + re_body + "PRINT '440: sp_asset_lifecycle_transition re-issued.';\nGO\n\n"
full=open(B+'440_a.sql').read()+open(B+'440_b.sql').read()+open(B+'440_c.sql').read()+open(B+'440_d.sql').read()+e+open(B+'440_f.sql').read()
assert all(ord(c)<128 for c in full)
open(B+'440.sql','w',newline='').write(full); print('440.sql', full.count('\n'))
