# 443: Asset Discovery screen -- Stale assets tab, Register action.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    open(path, 'w', encoding='utf-8', newline='').write(s)
V = "src/PracticeManagement.Web/Views/Practice/Partials/asset-discovery.cshtml"
J = "src/PracticeManagement.Web/wwwroot/js/AssetConfig/asset-discovery.js"

edit(V, [
("""    score thresholds and the freshness and verification rules.
""",
"""    score thresholds and the freshness and verification rules.
    443: the queue registers a new candidate through the Asset Register form
    (Register); "Stale assets" lists assets no source has seen for the
    aging rule and runs the stale review (source confirmation, dependency
    review, then dismiss or request decommission -- 5.6.3 Retire / Stale).
"""),
("""            <button role="tab" data-adc-main="CONFIDENCE" aria-selected="false">Data confidence</button>
""",
"""            <button role="tab" data-adc-main="CONFIDENCE" aria-selected="false">Data confidence</button>
            <button role="tab" data-adc-main="STALE" aria-selected="false">Stale assets</button>
"""),
("""        @* ---------------- settings ---------------- *@
        <div class="pm-tab-panel" data-adc-mainpanel="SETTINGS" hidden>
""",
"""        @* ---------------- stale assets (443) ---------------- *@
        <div class="pm-tab-panel" data-adc-mainpanel="STALE" hidden>
            <div class="pm-toolbar">
                <select id="adcStView" title="View"><option value="">Stale and in review</option><option value="CLOSED">Closed reviews</option></select>
                <input type="search" id="adcStSearch" placeholder="Search asset or type" maxlength="200" />
                <label class="adc-check">Aging rule (days without observation) <input type="number" id="adcStDays" min="1" max="3650" /></label>
                @if (adcCanEdit)
                {
                    <button class="pm-button" id="adcStDaysSave" type="button"><i class="fa-solid fa-floppy-disk"></i> Save rule</button>
                }
            </div>
            <p class="adc-note">An asset is stale when it has source links, none of them is fresh (expected interval x stale multiplier) and no source has observed it for the aging rule. Retirement needs the source confirmation and the dependency review (BRD 5.6.3); the decommission request then follows the Asset Register lifecycle rules.</p>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Asset</th><th>Status</th><th>Last observed</th><th>Days unseen</th><th>Sources (fresh / linked)</th><th>Review</th></tr></thead>
                    <tbody id="adcStBody"></tbody>
                </table>
            </div>
            <div id="adcStPager"></div>
        </div>

        @* ---------------- settings ---------------- *@
        <div class="pm-tab-panel" data-adc-mainpanel="SETTINGS" hidden>
"""),
("""@* ======================= Asset confidence window ======================= *@
""",
"""@* ======================= Stale review window (443) ======================= *@
<div class="pm-modal" id="adcStaleModal" hidden>
    <div class="pm-modal-panel pm-modal-wide">
        <header>
            <h2 id="adcSrTitle">Stale asset</h2>
            <button class="pm-modal-close" type="button" data-close-adc="adcStaleModal" aria-label="Close">&times;</button>
        </header>
        <div class="adc-info" id="adcSrInfo"></div>
        <p class="pm-message" id="adcSrMessage" role="status" aria-live="polite" hidden></p>
        <div class="pm-modal-footer" id="adcSrStartBar" hidden>
            <button class="pm-button primary" type="button" id="adcSrStart"><i class="fa-solid fa-clipboard-check"></i> Start stale review</button>
        </div>

        <div id="adcSrSteps" hidden>
            <h3 class="adc-sub">1. Source confirmation</h3>
            <p class="adc-note" id="adcSrSourceDone" hidden></p>
            <form id="adcSrSourceForm" class="pm-form-grid">
                <label><span>Source owner confirms *</span>
                    <select id="adcSrOutcome"><option value="">--</option><option value="ABSENT">Absent from the source</option><option value="PRESENT">Still present (connector or scope issue)</option></select></label>
                <label class="full"><span>Confirmation note *</span><textarea id="adcSrSourceNote" rows="2" maxlength="1000"></textarea></label>
                <footer class="pm-modal-footer full"><button type="submit" class="pm-button"><i class="fa-solid fa-check"></i> Record confirmation</button></footer>
            </form>

            <h3 class="adc-sub">2. Dependency review</h3>
            <p class="adc-note" id="adcSrDepDone" hidden></p>
            <form id="adcSrDepForm" class="pm-form-grid">
                <label class="full"><span>Review note * (what was checked and agreed for the items below)</span><textarea id="adcSrDepNote" rows="2" maxlength="1000"></textarea></label>
                <footer class="pm-modal-footer full"><button type="submit" class="pm-button"><i class="fa-solid fa-check"></i> Record dependency review</button></footer>
            </form>

            <h3 class="adc-sub">3. Decision</h3>
            <form id="adcSrDecisionForm" class="pm-form-grid">
                <label class="full"><span>Reason *</span><textarea id="adcSrDecisionNote" rows="2" maxlength="1000"></textarea></label>
                <p class="adc-note full">Request decommission moves the asset to Pending Decommission through its lifecycle rules (Asset Register permission needed). Dismiss keeps the asset; it is not listed again for one aging period.</p>
                <footer class="pm-modal-footer full">
                    <button type="button" class="pm-button" id="adcSrDismiss"><i class="fa-solid fa-xmark"></i> Dismiss (still in use)</button>
                    <button type="button" class="pm-button primary" id="adcSrDecom"><i class="fa-solid fa-box-archive"></i> Request decommission</button>
                </footer>
            </form>
        </div>

        <h3 class="adc-sub">Source records</h3>
        <div class="pm-table-wrap">
            <table>
                <thead><tr><th>Source</th><th>Record ID</th><th>Link</th><th>Last seen</th><th>Days unseen</th><th>Source last run</th></tr></thead>
                <tbody id="adcSrLinkBody"></tbody>
            </table>
        </div>
        <h3 class="adc-sub">Dependencies</h3>
        <div class="pm-table-wrap">
            <table>
                <thead><tr><th>Kind</th><th>Item</th><th>Detail</th><th></th></tr></thead>
                <tbody id="adcSrDepBody"></tbody>
            </table>
        </div>
        <h3 class="adc-sub">Reviews</h3>
        <div class="pm-table-wrap">
            <table>
                <thead><tr><th>Opened</th><th>Status</th><th>Source</th><th>Dependency review</th><th>Decision</th><th>Closed</th></tr></thead>
                <tbody id="adcSrHistBody"></tbody>
            </table>
        </div>
    </div>
</div>

@* ======================= Asset confidence window ======================= *@
"""),
])

edit(J, [
("""// relationships/ci-lookup (kind ASSET). The procedures hold every rule
// (matching, scores, precedence, outcomes); this screen shows them.
""",
"""// relationships/ci-lookup (kind ASSET). The procedures hold every rule
// (matching, scores, precedence, outcomes); this screen shows them.
// 443: Register (new candidate / manual review) opens the Asset Register
// form for the exception (asset-register.js links it after the save);
// Stale assets: discovery/stale, discovery/stale/assets/{id},
// discovery/stale/settings, discovery/stale/reviews, .../{id}/action.
"""),
("""  const RESOLUTION = { LINKED: "Linked", IGNORE: "Ignored",""",
"""  const RESOLUTION = { LINKED: "Linked", REGISTERED: "Registered as new asset", IGNORE: "Ignored","""),
("""  const state = { organizationId: null, config: null, mainTab: "SOURCES", batPager: null, qPager: null, cPager: null,
""",
"""  const REVIEW = { OPEN: ["In review", "adc-st-open"], DISMISSED: ["Dismissed", "adc-st-ended"],
                   DECOMMISSION_REQUESTED: ["Decommission requested", "adc-st-wait"] };   // 443
  const DEP_KIND = { RELATIONSHIP: "Relationship", CONTRACT: "Contract coverage", ACTIVITY: "Activity", WORKFLOW: "Workflow",
                     LIFECYCLE: "Lifecycle change", RECONCILIATION: "Reconciliation", RISK: "Risk" };
  const state = { organizationId: null, config: null, mainTab: "SOURCES", batPager: null, qPager: null, cPager: null, stPager: null, stale: null,
"""),
("""    state.cPager = g ? g.attach({ hostId: "adcCPager", onChange: refreshConfidence }) : null;
""",
"""    state.cPager = g ? g.attach({ hostId: "adcCPager", onChange: refreshConfidence }) : null;
    state.stPager = g ? g.attach({ hostId: "adcStPager", onChange: refreshStale }) : null;
"""),
("""    document.getElementById("adcQBody").addEventListener("click", ev => {
      const r = ev.target.closest("button[data-adc-resolve]");
""",
"""    document.getElementById("adcQBody").addEventListener("click", ev => {
      const g = ev.target.closest("button[data-adc-register]");   // 443
      if (g) { registerCandidate(Number(g.dataset.adcRegister)); return; }
      const r = ev.target.closest("button[data-adc-resolve]");
"""),
("""    // settings
    document.getElementById("adcSetForm").addEventListener("submit", ev => { ev.preventDefault(); saveSettings(); });
""",
"""    // stale assets (443)
    let ts = null;
    document.getElementById("adcStView").addEventListener("change", () => { state.stPager?.reset(true); refreshStale(); });
    document.getElementById("adcStSearch").addEventListener("input", () => { clearTimeout(ts); ts = setTimeout(() => { state.stPager?.reset(true); refreshStale(); }, 300); });
    document.getElementById("adcStDaysSave")?.addEventListener("click", saveStaleRule);
    document.getElementById("adcStBody").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-adc-stale]");
      if (b) openStale(Number(b.dataset.adcStale));
    });
    document.getElementById("adcSrStart").addEventListener("click", startStaleReview);
    document.getElementById("adcSrSourceForm").addEventListener("submit", ev => { ev.preventDefault(); staleAction("CONFIRM_SOURCE", "adcSrSourceNote"); });
    document.getElementById("adcSrDepForm").addEventListener("submit", ev => { ev.preventDefault(); staleAction("REVIEW_DEPENDENCIES", "adcSrDepNote"); });
    document.getElementById("adcSrDecisionForm").addEventListener("submit", ev => ev.preventDefault());
    document.getElementById("adcSrDismiss").addEventListener("click", () => staleAction("DISMISS", "adcSrDecisionNote"));
    document.getElementById("adcSrDecom").addEventListener("click", () => staleAction("REQUEST_DECOMMISSION", "adcSrDecisionNote"));
    // settings
    document.getElementById("adcSetForm").addEventListener("submit", ev => { ev.preventDefault(); saveSettings(); });
"""),
("""    [state.batPager, state.qPager, state.cPager].forEach(p => p?.reset(true));
""",
"""    [state.batPager, state.qPager, state.cPager, state.stPager].forEach(p => p?.reset(true));
"""),
("""    else if (name === "CONFIDENCE") await refreshConfidence();
""",
"""    else if (name === "CONFIDENCE") await refreshConfidence();
    else if (name === "STALE") await refreshStale();
"""),
("""      const canAct = e.status === "OPEN" && (CAN_EDIT || (CAN_APPROVE && e.exceptionKind === "CONFLICT"));
      const status = e.status === "OPEN"
        ? (canAct ? `<button class="pm-button" type="button" data-adc-resolve="${e.exceptionId}"><i class="fa-solid fa-scale-balanced"></i> Resolve</button>` : `<span class="adc-chip adc-st-open">Open</span>`)
""",
"""      const canAct = e.status === "OPEN" && (CAN_EDIT || (CAN_APPROVE && e.exceptionKind === "CONFLICT"));
      const canRegister = e.status === "OPEN" && CAN_EDIT && (e.exceptionKind === "NEW_CANDIDATE" || e.exceptionKind === "MANUAL_REVIEW");   // 443
      const status = e.status === "OPEN"
        ? (canAct ? `<button class="pm-button" type="button" data-adc-resolve="${e.exceptionId}"><i class="fa-solid fa-scale-balanced"></i> Resolve</button>` : `<span class="adc-chip adc-st-open">Open</span>`)
          + (canRegister ? ` <button class="pm-button" type="button" data-adc-register="${e.exceptionId}" title="Register a new Draft asset from this record"><i class="fa-solid fa-plus"></i> Register</button>` : "")
"""),
("""  // ------------------------------------------------------------------ data confidence
""",
"""  // 443: register a new candidate on the Asset Register form (prefilled from
  // the observation); asset-register.js links the record after the save.
  function registerCandidate(id) {
    const qs = new URLSearchParams({ organizationId: state.organizationId, discoveryException: id });
    window.location.href = U(`/Practice/Index/asset-register?${qs}`);
  }

  // ------------------------------------------------------------------ data confidence
"""),
("""  // ------------------------------------------------------------------ settings
  async function saveSettings() {
""",
"""  // ------------------------------------------------------------------ stale assets (443)
  async function refreshStale() {
    const body = document.getElementById("adcStBody");
    if (!state.organizationId) { body.innerHTML = empty(6, "Select an organization."); state.stPager?.clear(); return; }
    body.innerHTML = empty(6, "Loading...");
    const qs = new URLSearchParams({ organizationId: state.organizationId,
      pageNumber: state.stPager ? state.stPager.page() : 1, pageSize: state.stPager ? state.stPager.size() : 25 });
    if (val("adcStView")) qs.set("view", val("adcStView"));
    if (val("adcStSearch")) qs.set("search", val("adcStSearch"));
    const res = await api("GET", `/discovery/stale?${qs}`);
    if (!res.ok) { body.innerHTML = empty(6, res.error); state.stPager?.clear(); return; }
    const d = res.data.data, rows = d.rows || [];
    const days = document.getElementById("adcStDays");
    days.value = d.settings ? d.settings.retireAfterDays : 90;
    days.disabled = !CAN_EDIT;
    state.stPager?.setTotal(d.totalRows, rows.length);
    body.innerHTML = rows.map(r => {
      const [rl, rc] = REVIEW[r.reviewStatus] || ["Not reviewed", "adc-st-ended"];
      const progress = r.reviewStatus === "OPEN"
        ? `<div class="adc-note">${r.sourceOutcome ? "source: " + esc(label(r.sourceOutcome)) : "source not confirmed"}, ${r.dependenciesReviewedDt ? "dependencies reviewed" : "dependencies not reviewed"}</div>`
        : (r.closedDt ? `<div class="adc-note">${esc(r.closedBy || "")} ${esc(dateTime(r.closedDt))}${r.changeResult ? " - lifecycle " + esc(label(r.changeResult)) : ""}</div>` : "");
      return `<tr><td><button class="pm-link-button" type="button" data-adc-stale="${r.assetId}">${esc(r.assetName)}</button><div class="adc-note">${esc(r.assetTypeName || "")}</div></td>
        <td>${esc(r.statusName || "--")}</td><td>${esc(dateTime(r.lastObservedDt) || "--")}</td><td>${esc(r.daysUnseen ?? "--")}</td>
        <td>${r.freshLinkCount != null ? esc(r.freshLinkCount) + " / " : ""}${esc(r.linkCount)}</td>
        <td><span class="adc-chip ${rc}">${esc(rl)}</span>${r.reviewStatus === "OPEN" && !r.isStale ? ' <span class="adc-chip adc-st-active">Seen again</span>' : ""}${progress}</td></tr>`;
    }).join("") || empty(6, val("adcStView") === "CLOSED" ? "No closed reviews." : "No stale assets.");
  }

  async function saveStaleRule() {
    const res = await api("POST", "/discovery/stale/settings", { organizationId: state.organizationId, retireAfterDays: num("adcStDays") });
    if (!res.ok) { showMessage(res.error, "error"); return; }
    showMessage("Aging rule saved.", "success");
    state.stPager?.reset(true);
    await refreshStale();
  }

  async function openStale(assetId) {
    const res = await api("GET", `/discovery/stale/assets/${assetId}?organizationId=${state.organizationId}`);
    if (!res.ok) { showMessage(res.error); return; }
    const d = res.data.data, a = d.asset;
    state.stale = d;
    hide("adcSrMessage");
    document.getElementById("adcSrTitle").textContent = a.assetName;
    const item = (l, v) => `<div><span>${esc(l)}</span>${v}</div>`;
    const [rl, rc] = REVIEW[a.reviewStatus] || ["Not reviewed", "adc-st-ended"];
    document.getElementById("adcSrInfo").innerHTML =
      item("Type / status", `${esc(a.assetTypeName || "--")} / ${esc(a.statusName)}`) +
      item("Last observed", esc(dateTime(a.lastObservedDt) || "--")) + item("Days unseen", esc(a.daysUnseen ?? "--")) +
      item("Sources (fresh / linked)", `${esc(a.freshLinkCount)} / ${esc(a.linkCount)}`) + item("Aging rule", `${esc(a.retireAfterDays)} days`) +
      item("Stale", a.isStale ? '<span class="adc-chip adc-st-wait">Yes</span>' : "No") +
      item("Review", `<span class="adc-chip ${rc}">${esc(rl)}</span>${a.seenAgain ? ' <span class="adc-chip adc-st-active">Seen again</span>' : ""}`) +
      (a.reviewId ? item("Opened", `${esc(a.openedBy || "")} ${esc(dateTime(a.openedDt))}`) : "");
    const open = !!a.reviewId;
    document.getElementById("adcSrStartBar").hidden = open || !a.isStale || !CAN_EDIT;
    document.getElementById("adcSrSteps").hidden = !open;
    if (open) {
      const srcDone = !!a.sourceOutcome, depDone = !!a.dependenciesReviewedDt;
      const sd = document.getElementById("adcSrSourceDone");
      sd.hidden = !srcDone;
      sd.textContent = srcDone ? `Source owner confirmed: ${label(a.sourceOutcome)} - ${a.sourceNote || ""} (${a.sourceConfirmedBy || ""}, ${dateTime(a.sourceConfirmedDt)})` : "";
      document.getElementById("adcSrSourceForm").hidden = srcDone || !CAN_EDIT;
      const dd = document.getElementById("adcSrDepDone");
      dd.hidden = !depDone;
      dd.textContent = depDone ? `Reviewed: ${a.dependencyNote || ""} (${a.dependencyBlockers || 0} blocker(s); ${a.dependenciesReviewedBy || ""}, ${dateTime(a.dependenciesReviewedDt)})` : "";
      document.getElementById("adcSrDepForm").hidden = depDone || !CAN_EDIT;
      document.getElementById("adcSrDecisionForm").hidden = !CAN_EDIT;
      document.getElementById("adcSrDecom").disabled = !(srcDone && a.sourceOutcome === "ABSENT" && depDone && !a.seenAgain);
      ["adcSrOutcome", "adcSrSourceNote", "adcSrDepNote", "adcSrDecisionNote"].forEach(id => { document.getElementById(id).value = ""; });
    }
    document.getElementById("adcSrLinkBody").innerHTML = (d.links || []).map(l => `<tr><td>${esc(l.sourceName)}${l.sourceActive ? "" : ' <span class="adc-chip adc-st-ended">Inactive</span>'}</td>
        <td>${esc(l.externalKey)}</td><td>${esc(l.linkMethod === "AUTO" ? "Auto match" : "Confirmed")}</td><td>${esc(dateTime(l.lastSeenDt))}</td>
        <td>${esc(l.daysUnseen)}</td><td>${esc(dateTime(l.sourceLastRunDt) || "--")}${l.sourceLastRunStatus ? `<div class="adc-note">${esc(label(l.sourceLastRunStatus))}</div>` : ""}</td></tr>`).join("")
      || empty(6, "No source records.");
    document.getElementById("adcSrDepBody").innerHTML = (d.dependencies || []).map(x => `<tr><td>${esc(DEP_KIND[x.itemKind] || x.itemKind)}</td>
        <td>${esc(x.itemName)}</td><td>${esc(x.detail || "")}</td><td>${x.isBlocker ? '<span class="adc-chip adc-st-bad">Blocker</span>' : ""}</td></tr>`).join("")
      || empty(4, "Nothing relies on or refers to this asset.");
    document.getElementById("adcSrHistBody").innerHTML = (d.reviews || []).map(r => {
      const [hl, hc] = REVIEW[r.reviewStatus] || [r.reviewStatus, ""];
      return `<tr><td>${esc(dateTime(r.openedDt))}<div class="adc-note">${esc(r.openedBy || "")}</div></td><td><span class="adc-chip ${hc}">${esc(hl)}</span></td>
        <td>${esc(r.sourceOutcome ? label(r.sourceOutcome) : "--")}<div class="adc-note">${esc(r.sourceNote || "")}</div></td>
        <td>${esc(r.dependencyNote || "--")}${r.dependencyBlockers ? `<div class="adc-note">${esc(r.dependencyBlockers)} blocker(s)</div>` : ""}</td>
        <td>${esc(r.decisionNote || "--")}${r.changeResult ? `<div class="adc-note">lifecycle ${esc(label(r.changeResult))}</div>` : ""}</td>
        <td>${esc(dateTime(r.closedDt) || "--")}<div class="adc-note">${esc(r.closedBy || "")}</div></td></tr>`;
    }).join("") || empty(6, "No reviews yet.");
    document.getElementById("adcStaleModal").hidden = false;
  }

  async function startStaleReview() {
    const a = state.stale && state.stale.asset;
    if (!a) return;
    const res = await api("POST", "/discovery/stale/reviews", { organizationId: state.organizationId, assetId: a.assetId });
    if (!res.ok) { show("adcSrMessage", res.error); return; }
    await openStale(a.assetId);
    show("adcSrMessage", "Review started. Record the source confirmation and the dependency review.", "success");
    await refreshStale();
  }

  async function staleAction(action, noteId) {
    const a = state.stale && state.stale.asset;
    if (!a || !a.reviewId) return;
    if (action === "REQUEST_DECOMMISSION" && window.gracUi && window.gracUi.confirm
        && !(await window.gracUi.confirm("Request decommission of this asset? It moves to Pending Decommission through its lifecycle rules."))) return;
    const res = await api("POST", `/discovery/stale/reviews/${a.reviewId}/action`, {
      organizationId: state.organizationId, action, sourceOutcome: action === "CONFIRM_SOURCE" ? val("adcSrOutcome") : null,
      note: val(noteId), expectedRecordVersion: a.recordVersion
    });
    if (!res.ok) { show("adcSrMessage", res.error); return; }
    const done = { CONFIRM_SOURCE: "Source confirmation recorded.", REVIEW_DEPENDENCIES: "Dependency review recorded.", DISMISS: "Review dismissed.",
                   REQUEST_DECOMMISSION: "Decommission requested; see the asset Lifecycle tab in the Asset Register." };
    await openStale(a.assetId);
    show("adcSrMessage", res.data.result === "DISMISSED" && action === "CONFIRM_SOURCE" ? "The source still holds the asset: review closed (still in use)." : done[action], "success");
    await refreshStale();
  }

  // ------------------------------------------------------------------ settings
  async function saveSettings() {
"""),
])
print("pui443 ok")
