# Applies the 415 View Data Scope code changes to a repo root (argv[1] =
# folder that contains PracticeManagement/). Every replacement is asserted.
import os, re, sys, shutil
ROOT = os.path.join(sys.argv[1], 'PracticeManagement', 'src')
NEW  = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'new')
def rd(p): return open(p, encoding='utf-8', newline='').read()
def wr(p, s): open(p, 'w', encoding='utf-8', newline='').write(s)
def patch(rel, pairs):
    p = os.path.join(ROOT, rel); s = rd(p)
    for a, b in pairs:
        assert s.count(a) == 1, (rel, a[:70], s.count(a)); s = s.replace(a, b)
    wr(p, s)

# 1. new files
for side, proj in (('Api', 'PracticeManagement.Api'), ('Web', 'PracticeManagement.Web')):
    for dp, _, fs in os.walk(os.path.join(NEW, side)):
        for f in fs:
            src = os.path.join(dp, f)
            dst = os.path.join(ROOT, proj, os.path.relpath(src, os.path.join(NEW, side)))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(src, dst)

# 2. Api Program.cs
patch('PracticeManagement.Api/Program.cs', [
("""builder.Services.AddPracticeManagementDashboardService();
""", """builder.Services.AddPracticeManagementDashboardService();
// Role View Data Scope (migration 415): the Advanced Settings of the Role
// Menu Permission section. Enforcement is the row-level security policy,
// applied per connection by Infrastructure.ViewScopeSession.
builder.Services.AddPracticeRoleViewDataScopeService();
"""),
("""app.MapControllers();""", """// View Data Scope (415): a GET is a read; its reader is the employee the
// Web tier stamped from the session (X-PM-Caller-Employee-Id). Every
// connection opened while serving it applies that reader's role View
// Data Scope (Infrastructure.ViewScopeSession). Cleared after the request.
app.Use(async (context, next) =>
{
    PracticeManagement.Api.Infrastructure.CallerViewScope.BeginForRequest(context.Request);
    try { await next(); }
    finally { PracticeManagement.Api.Infrastructure.CallerViewScope.Clear(); }
});

app.MapControllers();""")])

# 3. one line after every connection open in the Api (login excluded)
rx = re.compile(r'^(\s*)await (\w+)\.OpenAsync\((\w+)\);\s*$')
hooked = []
for sub in ('Services', 'Controllers'):
    d = os.path.join(ROOT, 'PracticeManagement.Api', sub)
    for f in sorted(os.listdir(d)):
        if not f.endswith('.cs') or f in ('PracticeAuthenticationService.cs', 'RoleViewDataScopeService.cs'):
            continue
        p = os.path.join(d, f); s = rd(p)
        if 'ViewScopeSession.ApplyAsync' in s: continue
        nl = '\r\n' if '\r\n' in s else '\n'
        out = []; n = 0
        for line in s.split(nl):
            out.append(line)
            m = rx.match(line)
            if m:
                out.append(f"{m.group(1)}await Infrastructure.ViewScopeSession.ApplyAsync({m.group(2)}, {m.group(3)});   // 415: View Data Scope")
                n += 1
        if n:
            wr(p, nl.join(out)); hooked.append((f, n))

# 4. gateway secure/query reader (from the signed envelope)
patch('PracticeManagement.Api/Controllers/PracticeRepositoryController.cs', [
("""        ExecuteAsync(envelope, "VIEW", async (request, principal) =>
        {
            var data = NormalizeQueryData(request);""", """        ExecuteAsync(envelope, "VIEW", async (request, principal) =>
        {
            // 415: a query is a read. Its reader is the employee the Web
            // gateway put in the signed envelope from the session, so the
            // reader's View Data Scope applies to every row this returns.
            Infrastructure.CallerViewScope.BeginRead(JsonLong(request.Data, "callerEmployeeId"));
            var data = NormalizeQueryData(request);""")])

# 5. Web Program.cs: stamp the caller on every API call
patch('PracticeManagement.Web/Program.cs', [
("""builder.Services.AddHttpClient<SecurePracticeClient>();
""", """builder.Services.AddHttpClient<SecurePracticeClient>();
// View Data Scope (migration 415): every proxy call to the Practice
// Management API carries the signed-in employee from the session, so the
// API can apply the reader's role View Data Scope on every read.
builder.Services.AddHttpContextAccessor();
builder.Services.AddTransient<CallerIdentityHandler>();
builder.Services.AddHttpClient("PracticeManagementApi").AddHttpMessageHandler<CallerIdentityHandler>();
""")])

# 6. Role Menu Permission section: Advanced Settings
patch('PracticeManagement.Web/wwwroot/js/role-menu-permission-editor.js', [
("""     - Write:  POST {api}/role-menu-permissions  (upsert, UNIQUE(role,menu))""",
 """     - Write:  POST {api}/role-menu-permissions  (upsert, UNIQUE(role,menu))
     - Advanced Settings (migration 415): the role's View Data Scope,
               GET/POST {appBase}/practice/api/roles/{roleId}/view-data-scope
               -- staged like the matrix and written by the same Save."""),
("""  const state = {
    opts: null, host: null, orgEl: null, menus: [], byId: new Map(),
    perm: new Map(), original: new Map(), rowId: new Map()
  };""", """  const state = {
    opts: null, host: null, orgEl: null, menus: [], byId: new Map(),
    perm: new Map(), original: new Map(), rowId: new Map(),
    // 415: Advanced Settings -> View Data Scope. viewScope is the UI value,
    // viewScopeOriginal what the server holds (ALL for a new role -- the
    // column default, i.e. the unrestricted behaviour every role had).
    viewScope: "ALL", viewScopeOriginal: "ALL", viewScopeAvailable: true
  };

  // The View Data Scope options (organization_role.view_data_scope, 415).
  // "All records" is the explicit default every existing role carries.
  const VIEW_SCOPES = [
    { value: "ALL",      label: "All records",    hint: "No restriction -- every record of the module (the default)." },
    { value: "LOCATION", label: "Location",       hint: "Records of the user's own location." },
    { value: "TEAM",     label: "Team",           hint: "Records assigned to the user's teams." },
    { value: "OWNER",    label: "Assigned Owner", hint: "Only records the user owns." }
  ];
  const roleScopeUrl = roleId => `${appBasePath()}/practice/api/roles/${encodeURIComponent(roleId)}/view-data-scope`;"""),
("""      <div class="pm-role-perms-body"><div class="pm-empty compact">Loading menus and permissions...</div></div>`;""",
 """      <div class="pm-role-perms-body"><div class="pm-empty compact">Loading menus and permissions...</div></div>
      <div class="pm-role-adv" data-role-adv>
        <div class="pm-section-heading">
          <h2>Advanced Settings</h2>
          <p>Which records this role's users see where they have View access. Menu access is still decided by the matrix above.</p>
        </div>
        <div class="pm-role-adv-body"></div>
      </div>`;"""),
("""    const orgId = resolveOrg();
    try {
      const [menuRes, permRes] = await Promise.all([""", """    const orgId = resolveOrg();
    loadViewScope(section, opts, orgId);
    try {
      const [menuRes, permRes] = await Promise.all(["""),
("""  function draw(section) {""", """  // ---- Advanced Settings: View Data Scope (415) -----------------------
  async function loadViewScope(section, opts, orgId) {
    state.viewScope = state.viewScopeOriginal = "ALL";
    state.viewScopeAvailable = true;
    if (opts.roleId && orgId) {
      try {
        const r = await fetch(`${roleScopeUrl(opts.roleId)}?organizationId=${encodeURIComponent(orgId)}`,
                              { credentials: "same-origin" });
        if (!r.ok) throw new Error("HTTP " + r.status);
        const b = await r.json();
        state.viewScope = state.viewScopeOriginal = String(val(b, "viewDataScope") || "ALL").toUpperCase();
      } catch (_) {
        state.viewScopeAvailable = false;
      }
    }
    drawViewScope(section);
  }

  function drawViewScope(section) {
    const body = section.querySelector(".pm-role-adv-body");
    if (!body) return;
    if (!state.viewScopeAvailable) {
      body.innerHTML = `<div class="pm-empty compact">The View Data Scope could not be loaded for this role.</div>`;
      return;
    }
    const dis = state.opts?.readonly ? " disabled" : "";
    body.innerHTML = `
      <fieldset class="pm-view-scope">
        <legend>View Data Scope</legend>
        ${VIEW_SCOPES.map(o => `
          <label class="pm-view-scope-opt">
            <input type="radio" name="rmpViewDataScope" value="${o.value}"${o.value === state.viewScope ? " checked" : ""}${dis} />
            <span><strong>${esc(o.label)}</strong><small>${esc(o.hint)}</small></span>
          </label>`).join("")}
      </fieldset>`;
    body.querySelectorAll("input[name='rmpViewDataScope']").forEach(rb =>
      rb.addEventListener("change", () => { if (rb.checked) state.viewScope = rb.value; }));
  }

  function draw(section) {"""),
("""  async function flushPending(roleId) {
    const rid = Number(roleId || state.opts?.roleId || 0);
    const orgId = resolveOrg();
    if (!rid || !orgId) return { saved: 0, failed: 0 };
    let saved = 0, failed = 0;""", """  async function flushPending(roleId) {
    const rid = Number(roleId || state.opts?.roleId || 0);
    const orgId = resolveOrg();
    if (!rid || !orgId) return { saved: 0, failed: 0 };
    let saved = 0, failed = 0;
    // 415: the role's View Data Scope, when it changed.
    if (state.viewScopeAvailable && state.viewScope !== state.viewScopeOriginal) {
      try {
        const r = await fetch(roleScopeUrl(rid), {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-CSRF-TOKEN": csrf() },
          credentials: "same-origin",
          body: JSON.stringify({ organizationId: orgId, viewDataScope: state.viewScope })
        });
        if (!r.ok) throw new Error("HTTP " + r.status);
        state.viewScopeOriginal = state.viewScope;
        saved++;
      } catch (_) { failed++; }
    }"""),
("""  function hasPending() {
    for""", """  function hasPending() {
    if (state.viewScopeAvailable && state.viewScope !== state.viewScopeOriginal) return true;
    for""")])

# 7. CSS
patch('PracticeManagement.Web/wwwroot/css/practice-management.css', [
(""".pm-role-perms .pm-perms-key {
    color: var(--fg-muted);
    font-size: 11px;
}
""", """.pm-role-perms .pm-perms-key {
    color: var(--fg-muted);
    font-size: 11px;
}

/* Advanced Settings -> View Data Scope (migration 415). Sits under the
   matrix in the same section; a plain radio list in the form's own type
   scale. */
.pm-role-perms .pm-role-adv {
    border-top: 1px solid var(--border);
    margin-top: 16px;
    padding-top: 12px;
}

.pm-role-perms .pm-view-scope {
    border: 0;
    display: grid;
    gap: 8px;
    margin: 0;
    padding: 0;
}

.pm-role-perms .pm-view-scope legend {
    color: var(--fg-secondary);
    font-size: 12px;
    font-weight: 700;
    margin-bottom: 6px;
}

.pm-role-perms .pm-view-scope-opt {
    align-items: flex-start;
    cursor: pointer;
    display: flex;
    font-size: 13px;
    gap: 8px;
}

.pm-role-perms .pm-view-scope-opt input { margin-top: 3px; }

.pm-role-perms .pm-view-scope-opt small {
    color: var(--fg-muted);
    display: block;
    font-size: 12px;
}
""")])
print('hooked:', hooked)
