CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_setting_save
    @organization_id            BIGINT,
    @template_code              NVARCHAR(40),
    @is_active                  BIT           = 1,
    @lead_days                  INT           = NULL,
    @due_soon_days              INT           = NULL,
    @grouping_mode              NVARCHAR(12)  = N'INDIVIDUAL',
    @campaign_owner_employee_id BIGINT        = NULL,
    @actor                      NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @grouping_mode = UPPER(ISNULL(NULLIF(LTRIM(RTRIM(@grouping_mode)), N''), N'INDIVIDUAL'));
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54650, 'Organization not found.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_activity_template WHERE template_code = @template_code)
        THROW 54651, 'Unknown activity template.', 1;
    IF @lead_days IS NULL OR @lead_days NOT BETWEEN 0 AND 365 OR @due_soon_days IS NULL OR @due_soon_days NOT BETWEEN 0 AND 365
        THROW 54652, 'Task lead days and due-soon days must be between 0 and 365.', 1;
    IF @grouping_mode NOT IN (N'INDIVIDUAL', N'CAMPAIGN')
        THROW 54653, 'Tasks are created individually or grouped in a monthly campaign.', 1;
    IF @campaign_owner_employee_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM grac_practice.organization_employee
                                                                WHERE employee_id = @campaign_owner_employee_id
                                                                  AND organization_id = @organization_id AND status = N'Active')
        THROW 54654, 'The campaign owner must be an active employee of the organization.', 1;
    DECLARE @before NVARCHAR(MAX) = (SELECT is_active AS isActive, lead_days AS leadDays, due_soon_days AS dueSoonDays,
                                            grouping_mode AS groupingMode, campaign_owner_employee_id AS campaignOwnerEmployeeId
                                       FROM grac_practice.asset_activity_setting
                                      WHERE organization_id = @organization_id AND template_code = @template_code
                                        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    BEGIN TRAN;
    MERGE grac_practice.asset_activity_setting AS t
    USING (SELECT @organization_id AS organization_id, @template_code AS template_code) AS s
    ON t.organization_id = s.organization_id AND t.template_code = s.template_code
    WHEN MATCHED THEN UPDATE SET
        is_active = ISNULL(@is_active, 1), lead_days = @lead_days, due_soon_days = @due_soon_days, grouping_mode = @grouping_mode,
        campaign_owner_employee_id = @campaign_owner_employee_id, updated_by = @actor, updated_dt = SYSUTCDATETIME()
    WHEN NOT MATCHED THEN
        INSERT (organization_id, template_code, is_active, lead_days, due_soon_days, grouping_mode, campaign_owner_employee_id, entered_by)
        VALUES (@organization_id, @template_code, ISNULL(@is_active, 1), @lead_days, @due_soon_days, @grouping_mode,
                @campaign_owner_employee_id, @actor);
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-activity-setting', @organization_id, CASE WHEN @before IS NULL THEN N'CREATE' ELSE N'UPDATE' END, @before,
            (SELECT @template_code AS templateCode, ISNULL(@is_active, 1) AS isActive, @lead_days AS leadDays, @due_soon_days AS dueSoonDays,
                    @grouping_mode AS groupingMode, @campaign_owner_employee_id AS campaignOwnerEmployeeId FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @organization_id AS OrganizationId, N'SAVED' AS Result;
END
GO
