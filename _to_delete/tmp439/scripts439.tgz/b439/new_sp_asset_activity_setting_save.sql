CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_setting_save
    @organization_id            BIGINT,
    @template_code              NVARCHAR(40),
    @is_active                  BIT           = 1,
    @lead_days                  INT           = NULL,
    @due_soon_days              INT           = NULL,
    @grouping_mode              NVARCHAR(12)  = N'INDIVIDUAL',
    @campaign_owner_employee_id BIGINT        = NULL,
    @result_review_required        BIT           = NULL,     -- 439: NULL = the template default
    @disposition_approval_required BIT           = NULL,
    @restrict_on_overdue           NVARCHAR(100) = NULL,     -- ALL | NONE | CRITICAL,HIGH,MEDIUM,LOW
    @restrict_on_fail              BIT           = NULL,
    @actor                      NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @grouping_mode = UPPER(ISNULL(NULLIF(LTRIM(RTRIM(@grouping_mode)), N''), N'INDIVIDUAL'));
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54650, 'Organization not found.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_activity_template WHERE template_code = @template_code)
        THROW 54651, 'Unknown activity template.', 1;
    IF @lead_days IS NULL OR @lead_days NOT BETWEEN 0 AND 365 OR @due_soon_days IS NULL OR @due_soon_days NOT BETWEEN 0 AND 365
        THROW 54652, 'Task lead days and due-soon days must be between 0 and 365.', 1;
    IF @grouping_mode NOT IN (N'INDIVIDUAL', N'CAMPAIGN')
        THROW 54653, 'Tasks are created individually or grouped in a monthly campaign.', 1;
    IF @campaign_owner_employee_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM grac_practice.organization_employee
                                                                WHERE employee_id = @campaign_owner_employee_id
                                                                  AND organization_id = @organization_id AND status = N'Active')
        THROW 54654, 'The campaign owner must be an active employee of the organization.', 1;
    -- 439: restricted-use policy on overdue.
    SET @restrict_on_overdue = NULLIF(UPPER(REPLACE(LTRIM(RTRIM(@restrict_on_overdue)), N' ', N'')), N'');
    IF @restrict_on_overdue IS NOT NULL AND @restrict_on_overdue NOT IN (N'ALL', N'NONE')
       AND EXISTS (SELECT 1 FROM STRING_SPLIT(@restrict_on_overdue, N',') x
                    WHERE x.value NOT IN (N'CRITICAL', N'HIGH', N'MEDIUM', N'LOW'))
        THROW 54691, 'The restricted-use policy is All, None or a list of Critical, High, Medium, Low.', 1;
    DECLARE @before NVARCHAR(MAX) = (SELECT is_active AS isActive, lead_days AS leadDays, due_soon_days AS dueSoonDays,
                                            grouping_mode AS groupingMode, campaign_owner_employee_id AS campaignOwnerEmployeeId,
                                            result_review_required AS resultReviewRequired,                  -- 439
                                            disposition_approval_required AS dispositionApprovalRequired,
                                            restrict_on_overdue AS restrictOnOverdue, restrict_on_fail AS restrictOnFail
                                       FROM grac_practice.asset_activity_setting
                                      WHERE organization_id = @organization_id AND template_code = @template_code
                                        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    BEGIN TRAN;
    MERGE grac_practice.asset_activity_setting AS t
    USING (SELECT @organization_id AS organization_id, @template_code AS template_code) AS s
    ON t.organization_id = s.organization_id AND t.template_code = s.template_code
    WHEN MATCHED THEN UPDATE SET
        is_active = ISNULL(@is_active, 1), lead_days = @lead_days, due_soon_days = @due_soon_days, grouping_mode = @grouping_mode,
        campaign_owner_employee_id = @campaign_owner_employee_id, updated_by = @actor, updated_dt = SYSUTCDATETIME(),
        result_review_required = @result_review_required, disposition_approval_required = @disposition_approval_required,   -- 439
        restrict_on_overdue = @restrict_on_overdue, restrict_on_fail = @restrict_on_fail
    WHEN NOT MATCHED THEN
        INSERT (organization_id, template_code, is_active, lead_days, due_soon_days, grouping_mode, campaign_owner_employee_id, entered_by,
                result_review_required, disposition_approval_required, restrict_on_overdue, restrict_on_fail)            -- 439
        VALUES (@organization_id, @template_code, ISNULL(@is_active, 1), @lead_days, @due_soon_days, @grouping_mode,
                @campaign_owner_employee_id, @actor,
                @result_review_required, @disposition_approval_required, @restrict_on_overdue, @restrict_on_fail);
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-activity-setting', @organization_id, CASE WHEN @before IS NULL THEN N'CREATE' ELSE N'UPDATE' END, @before,
            (SELECT @template_code AS templateCode, ISNULL(@is_active, 1) AS isActive, @lead_days AS leadDays, @due_soon_days AS dueSoonDays,
                    @grouping_mode AS groupingMode, @campaign_owner_employee_id AS campaignOwnerEmployeeId,
                    @result_review_required AS resultReviewRequired, @disposition_approval_required AS dispositionApprovalRequired,   -- 439
                    @restrict_on_overdue AS restrictOnOverdue, @restrict_on_fail AS restrictOnFail FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @organization_id AS OrganizationId, N'SAVED' AS Result;
END
GO
