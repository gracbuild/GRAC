# 439 -- API (models / service / controller), Web proxy. Run from the repository root.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    return s

A = 'src/PracticeManagement.Api/'
W = 'src/PracticeManagement.Web/'
files = {}

files[A + 'Models/AssetConfigModels.cs'] = edit(A + 'Models/AssetConfigModels.cs', [
("""public sealed record AssetActivitySettingRequest(
    long    OrganizationId,
    string? TemplateCode,
    bool?   IsActive,
    int?    LeadDays,
    int?    DueSoonDays,
    string? GroupingMode,
    long?   CampaignOwnerEmployeeId);""",
"""/// 439 adds the reviewer / approval requirements and the restricted-use policy
/// (null = the template default; RestrictOnOverdue ALL | NONE | CRITICAL,HIGH,...).</summary>
public sealed record AssetActivitySettingRequest(
    long    OrganizationId,
    string? TemplateCode,
    bool?   IsActive,
    int?    LeadDays,
    int?    DueSoonDays,
    string? GroupingMode,
    long?   CampaignOwnerEmployeeId,
    bool?   ResultReviewRequired = null,
    bool?   DispositionApprovalRequired = null,
    string? RestrictOnOverdue = null,
    bool?   RestrictOnFail = null);"""),
("""/// <summary>Organization settings of one activity template: active, task lead days,
/// due-soon days, INDIVIDUAL tasks or a monthly CAMPAIGN, campaign owner.</summary>""",
"""/// <summary>Organization settings of one activity template: active, task lead days,
/// due-soon days, INDIVIDUAL tasks or a monthly CAMPAIGN, campaign owner."""),
("""/// <summary>Record the reconciliation of a flagged activity occurrence (BRD 7.1.5).</summary>
public sealed record AssetActivityReconcileRequest(long OrganizationId, string? Note, long? ExpectedRecordVersion);""",
"""/// <summary>Record the reconciliation of a flagged activity occurrence (BRD 7.1.5).</summary>
public sealed record AssetActivityReconcileRequest(long OrganizationId, string? Note, long? ExpectedRecordVersion);

/// <summary>439: save (Submit = false) or submit the result of an open activity occurrence.
/// Outcome PASS | FAIL (execution) or RENEWED | NOT_RENEWED (renewal); dates as yyyy-mm-dd.
/// ExpectedRecordVersion is the version of the result row (null for a first save).</summary>
public sealed record AssetActivityResultRequest(
    long      OrganizationId,
    string?   Outcome,
    DateTime? PerformedDate,
    string?   CertificateNumber,
    DateTime? CertificateExpiry,
    DateTime? NewExpiry,
    string?   EvidenceReference,
    string?   ResultNote,
    bool?     Submit,
    long?     ExpectedRecordVersion);

/// <summary>439: request RESCHEDULE (RevisedDueDate) | WAIVE | NOT_APPLICABLE | EXCEPTION
/// (ReviewDate) for an open occurrence, with a reason (BRD 7.1.5). ExpectedRecordVersion
/// is the version of the occurrence.</summary>
public sealed record AssetActivityDispositionRequest(
    long      OrganizationId,
    string?   DispositionType,
    string?   Reason,
    DateTime? RevisedDueDate,
    DateTime? ReviewDate,
    long?     ExpectedRecordVersion);"""),
])

files[A + 'Services/AssetConfigService.cs'] = edit(A + 'Services/AssetConfigService.cs', [
("""//   sp_asset_activity_* (438 -- recurring asset activities: templates, schedules, occurrences, campaigns)""",
"""//   sp_asset_activity_* (438 -- recurring asset activities: templates, schedules, occurrences, campaigns;
//   439 -- results, dispositions; sp_asset_restrictive_* restrictive-use reviews)"""),
("""    Task<object> ListActivityOccurrencesAsync(long organizationId, string? templateCode, string? status, bool reconcileOnly, long? campaignId, string? search, int pageNumber, int pageSize, CancellationToken ct);""",
"""    Task<object> ListActivityOccurrencesAsync(long organizationId, string? templateCode, string? status, bool reconcileOnly, long? campaignId, string? search, bool awaitingDecision, int pageNumber, int pageSize, CancellationToken ct);"""),
("""    Task<AssetLifecycleResult> ReconcileActivityAsync(long occurrenceId, AssetActivityReconcileRequest request, string actor, CancellationToken ct);
}""",
"""    Task<AssetLifecycleResult> ReconcileActivityAsync(long occurrenceId, AssetActivityReconcileRequest request, string actor, CancellationToken ct);

    // 439 -- Results, dispositions, restrictive-use reviews
    Task<object?> GetActivityOccurrenceAsync(long organizationId, long occurrenceId, CancellationToken ct);
    Task<AssetLifecycleResult> SaveActivityResultAsync(long occurrenceId, AssetActivityResultRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> DecideActivityResultAsync(long occurrenceId, AssetLifecycleDecisionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> RequestActivityDispositionAsync(long occurrenceId, AssetActivityDispositionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> DecideActivityDispositionAsync(long dispositionId, AssetLifecycleDecisionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<object> ListRestrictiveReviewsAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> DecideRestrictiveReviewAsync(long reviewId, AssetLifecycleDecisionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
}"""),
("""        var templates = await ReadRowsAsync(reader, ct);
        var employees = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
        return new { templates, employees };""",
"""        var templates = await ReadRowsAsync(reader, ct);
        var employees = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
        var evidenceFields = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();   // 439
        return new { templates, employees, evidenceFields };"""),
("""            AddParam(command, "@campaign_owner_employee_id", DbType.Int64,   request.CampaignOwnerEmployeeId);
            AddParam(command, "@actor",                      DbType.String,  actor, 100);""",
"""            AddParam(command, "@campaign_owner_employee_id", DbType.Int64,   request.CampaignOwnerEmployeeId);
            AddParam(command, "@result_review_required",        DbType.Boolean, request.ResultReviewRequired);          // 439
            AddParam(command, "@disposition_approval_required", DbType.Boolean, request.DispositionApprovalRequired);
            AddParam(command, "@restrict_on_overdue",           DbType.String,  Blank(request.RestrictOnOverdue), 100);
            AddParam(command, "@restrict_on_fail",              DbType.Boolean, request.RestrictOnFail);
            AddParam(command, "@actor",                      DbType.String,  actor, 100);"""),
("""    public async Task<object> ListActivityOccurrencesAsync(long organizationId, string? templateCode, string? status, bool reconcileOnly, long? campaignId, string? search, int pageNumber, int pageSize, CancellationToken ct)""",
"""    public async Task<object> ListActivityOccurrencesAsync(long organizationId, string? templateCode, string? status, bool reconcileOnly, long? campaignId, string? search, bool awaitingDecision, int pageNumber, int pageSize, CancellationToken ct)"""),
("""        AddParam(command, "@search",          DbType.String,  Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,   pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,   pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object> ListActivityCampaignsAsync(""",
"""        AddParam(command, "@search",          DbType.String,  Blank(search), 200);
        AddParam(command, "@awaiting_decision", DbType.Boolean, awaitingDecision);   // 439
        AddParam(command, "@page_number",     DbType.Int32,   pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,   pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object> ListActivityCampaignsAsync("""),
("""            AddParam(command, "@note",                    DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);
""",
"""            AddParam(command, "@note",                    DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    // ----------------------------------------------------------------
    // 439 -- Results, dispositions, restrictive-use reviews
    // ----------------------------------------------------------------
    public async Task<object?> GetActivityOccurrenceAsync(long organizationId, long occurrenceId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_activity_occurrence_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@occurrence_id",   DbType.Int64, occurrenceId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var header = await ReadRowsAsync(reader, ct);
            if (header.Count == 0) return null;
            var result = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
            var dispositions = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
            var reviews = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
            return new { occurrence = header[0], result = result.Count > 0 ? result[0] : null, dispositions, reviews };
        }
        catch (SqlException ex) when (ex.Number == 54670) { return null; }
    }

    public Task<AssetLifecycleResult> SaveActivityResultAsync(long occurrenceId, AssetActivityResultRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_activity_result_save", "occurrenceId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,   request.OrganizationId);
            AddParam(command, "@occurrence_id",           DbType.Int64,   occurrenceId);
            AddParam(command, "@outcome",                 DbType.String,  Blank(request.Outcome), 12);
            AddParam(command, "@performed_date",          DbType.Date,    request.PerformedDate?.Date);
            AddParam(command, "@certificate_number",      DbType.String,  Blank(request.CertificateNumber), 100);
            AddParam(command, "@certificate_expiry",      DbType.Date,    request.CertificateExpiry?.Date);
            AddParam(command, "@new_expiry",              DbType.Date,    request.NewExpiry?.Date);
            AddParam(command, "@evidence_reference",      DbType.String,  Blank(request.EvidenceReference), 400);
            AddParam(command, "@result_note",             DbType.String,  Blank(request.ResultNote), 2000);
            AddParam(command, "@submit",                  DbType.Boolean, request.Submit ?? false);
            AddParam(command, "@expected_record_version", DbType.Int64,   request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,   actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String,  actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> DecideActivityResultAsync(long occurrenceId, AssetLifecycleDecisionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_activity_result_decide", "occurrenceId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@occurrence_id",           DbType.Int64,  occurrenceId);
            AddParam(command, "@decision",                DbType.String, request.Decision, 10);
            AddParam(command, "@decision_note",           DbType.String, Blank(request.DecisionNote), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> RequestActivityDispositionAsync(long occurrenceId, AssetActivityDispositionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_activity_disposition_request", "dispositionId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@occurrence_id",           DbType.Int64,  occurrenceId);
            AddParam(command, "@disposition_type",        DbType.String, Blank(request.DispositionType), 16);
            AddParam(command, "@reason",                  DbType.String, Blank(request.Reason), 1000);
            AddParam(command, "@revised_due_date",        DbType.Date,   request.RevisedDueDate?.Date);
            AddParam(command, "@review_date",             DbType.Date,   request.ReviewDate?.Date);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> DecideActivityDispositionAsync(long dispositionId, AssetLifecycleDecisionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_activity_disposition_decide", "dispositionId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@disposition_id",          DbType.Int64,  dispositionId);
            AddParam(command, "@decision",                DbType.String, request.Decision, 10);
            AddParam(command, "@decision_note",           DbType.String, Blank(request.DecisionNote), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public async Task<object> ListRestrictiveReviewsAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, string actor, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_restrictive_reviews");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 10);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        AddParam(command, "@actor",           DbType.String, actor, 100);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public Task<AssetLifecycleResult> DecideRestrictiveReviewAsync(long reviewId, AssetLifecycleDecisionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_restrictive_review_decide", "reviewId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@review_id",               DbType.Int64,  reviewId);
            AddParam(command, "@decision_code",           DbType.String, Blank(request.Decision), 30);
            AddParam(command, "@decision_note",           DbType.String, Blank(request.DecisionNote), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);
"""),
])

files[A + 'Controllers/AssetConfigController.cs'] = edit(A + 'Controllers/AssetConfigController.cs', [
("""//   POST activities/run                             run the scheduler now for the organization (as notifications/run)
""",
"""//   POST activities/run                             run the scheduler now for the organization (as notifications/run)
//   GET  activities/occurrences/{id}?organizationId=  occurrence, result, dispositions, reviews (439)
//   POST activities/occurrences/{id}/result          save / submit the result
//   POST activities/occurrences/{id}/result-decision APPROVE | RETURN a submitted result
//   POST activities/occurrences/{id}/disposition     request RESCHEDULE | WAIVE | NOT_APPLICABLE | EXCEPTION
//   POST activities/dispositions/{id}/decision       APPROVE | REJECT | WITHDRAW a request
//   GET  activities/reviews?organizationId=&status=&search=&pageNumber=&pageSize=   restrictive-use reviews
//   POST activities/reviews/{id}/decision            decide a review (action code + note)
"""),
("""    public Task<IActionResult> ActivityOccurrences([FromQuery] long? organizationId, [FromQuery] string? templateCode, [FromQuery] string? status,
        [FromQuery] bool? reconcileOnly, [FromQuery] long? campaignId, [FromQuery] string? search, [FromQuery] int? pageNumber,
        [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListActivityOccurrencesAsync(organizationId.Value, templateCode, status, reconcileOnly ?? false, campaignId, search,
            pageNumber ?? 1, pageSize ?? 25, ct), "activity occurrences");
    }""",
"""    public Task<IActionResult> ActivityOccurrences([FromQuery] long? organizationId, [FromQuery] string? templateCode, [FromQuery] string? status,
        [FromQuery] bool? reconcileOnly, [FromQuery] long? campaignId, [FromQuery] string? search, [FromQuery] int? pageNumber,
        [FromQuery] int? pageSize, [FromQuery] bool? awaitingDecision, CancellationToken ct)   // 439: awaitingDecision
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListActivityOccurrencesAsync(organizationId.Value, templateCode, status, reconcileOnly ?? false, campaignId, search,
            awaitingDecision ?? false, pageNumber ?? 1, pageSize ?? 25, ct), "activity occurrences");
    }

    // ---------------------------------------------------------------- 439: results, dispositions, reviews
    [HttpGet("activities/occurrences/{occurrenceId:long}")]
    public Task<IActionResult> ActivityOccurrence(long occurrenceId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetActivityOccurrenceAsync(o, occurrenceId, ct), "Activity occurrence not found.", "activity occurrence");

    [HttpPost("activities/occurrences/{occurrenceId:long}/result")]
    public async Task<IActionResult> SaveActivityResult(long occurrenceId, [FromBody] AssetActivityResultRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveActivityResultAsync(occurrenceId, request, ActorEmployeeId, Actor, ct), ActivityNotFound, ActivityConflict);
    }

    [HttpPost("activities/occurrences/{occurrenceId:long}/result-decision")]
    public async Task<IActionResult> DecideActivityResult(long occurrenceId, [FromBody] AssetLifecycleDecisionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Decision)) return BadRequest(new { error = "decision is required." });
        return ResultWritten(await service.DecideActivityResultAsync(occurrenceId, request, ActorEmployeeId, Actor, ct), ActivityNotFound, ActivityConflict);
    }

    [HttpPost("activities/occurrences/{occurrenceId:long}/disposition")]
    public async Task<IActionResult> RequestActivityDisposition(long occurrenceId, [FromBody] AssetActivityDispositionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.RequestActivityDispositionAsync(occurrenceId, request, ActorEmployeeId, Actor, ct), ActivityNotFound, ActivityConflict);
    }

    [HttpPost("activities/dispositions/{dispositionId:long}/decision")]
    public async Task<IActionResult> DecideActivityDisposition(long dispositionId, [FromBody] AssetLifecycleDecisionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Decision)) return BadRequest(new { error = "decision is required." });
        return ResultWritten(await service.DecideActivityDispositionAsync(dispositionId, request, ActorEmployeeId, Actor, ct), ActivityNotFound, ActivityConflict);
    }

    [HttpGet("activities/reviews")]
    public Task<IActionResult> RestrictiveReviews([FromQuery] long? organizationId, [FromQuery] string? status, [FromQuery] string? search,
        [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListRestrictiveReviewsAsync(organizationId.Value, status, search, pageNumber ?? 1, pageSize ?? 25, Actor, ct),
            "restrictive-use reviews");
    }

    [HttpPost("activities/reviews/{reviewId:long}/decision")]
    public async Task<IActionResult> DecideRestrictiveReview(long reviewId, [FromBody] AssetLifecycleDecisionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Decision)) return BadRequest(new { error = "decision is required." });
        return ResultWritten(await service.DecideRestrictiveReviewAsync(reviewId, request, ActorEmployeeId, Actor, ct), ActivityNotFound, ActivityConflict);
    }"""),
("""    // 438: 54650 / 54651 / 54655 -> 404; 54658 (stale) -> 409.
    private static readonly int[] ActivityNotFound = { 54650, 54651, 54655 };
    private static readonly int[] ActivityConflict = { 54658 };""",
"""    // 438: 54650 / 54651 / 54655 -> 404; 54658 (stale) -> 409.
    // 439: 54670 (occurrence), 54686 (disposition), 54688 (review), 54692 (organization) -> 404;
    //      54680 (stale), 54685 (a request is already pending) -> 409.
    private static readonly int[] ActivityNotFound = { 54650, 54651, 54655, 54670, 54686, 54688, 54692 };
    private static readonly int[] ActivityConflict = { 54658, 54680, 54685 };"""),
])

files[W + 'Controllers/AssetConfigController.cs'] = edit(W + 'Controllers/AssetConfigController.cs', [
("""//   activities... (438)                asset-activities: GET VIEW (organization required); POST
//                                      activities/settings, activities/occurrences/{id}/reconcile and
//                                      activities/run EDIT""",
"""//   activities... (438)                asset-activities: GET VIEW (organization required); POST
//                                      activities/settings, activities/occurrences/{id}/reconcile and
//                                      activities/run EDIT; (439) activities/occurrences/{id}/result and
//                                      /disposition EDIT, /result-decision APPROVE (the procedure keeps the
//                                      submitter from reviewing), activities/dispositions/{id}/decision
//                                      APPROVE / REJECT -> APPROVE, WITHDRAW -> EDIT (requester only, in SQL),
//                                      activities/reviews/{id}/decision APPROVE"""),
("""            : isActivity && (lower == "activities/settings" || lower == "activities/run"     // 438
                             || (lower.StartsWith("activities/occurrences/") && lower.EndsWith("/reconcile")))
            ? Can(area, "EDIT")
            : isActivity""",
"""            : isActivity && (lower == "activities/settings" || lower == "activities/run"     // 438
                             || (lower.StartsWith("activities/occurrences/") && lower.EndsWith("/reconcile")))
            ? Can(area, "EDIT")
            : isActivity && lower.StartsWith("activities/occurrences/")                         // 439
                         && (lower.EndsWith("/result") || lower.EndsWith("/disposition"))
            ? Can(area, "EDIT")
            : isActivity && lower.StartsWith("activities/occurrences/") && lower.EndsWith("/result-decision")
            ? Can(area, "APPROVE")
            : isActivity && lower.StartsWith("activities/dispositions/") && lower.EndsWith("/decision")
            ? (decision is "APPROVE" or "REJECT" ? Can(area, "APPROVE") : Can(area, "EDIT"))
            : isActivity && lower.StartsWith("activities/reviews/") && lower.EndsWith("/decision")
            ? Can(area, "APPROVE")
            : isActivity"""),
])

for p, s in files.items():
    open(p, 'w', encoding='utf-8', newline='').write(s)
print('439 api/web ok', len(files))
