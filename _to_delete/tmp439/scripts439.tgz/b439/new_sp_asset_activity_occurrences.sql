CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_occurrences
    @organization_id BIGINT,
    @template_code   NVARCHAR(40)  = NULL,
    @status          NVARCHAR(12)  = N'OPEN',
    @reconcile_only  BIT           = 0,
    @campaign_id     BIGINT        = NULL,
    @search          NVARCHAR(200) = NULL,
    @awaiting_decision BIT         = 0,        -- 439: a submitted result or a pending disposition
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @template_code = NULLIF(LTRIM(RTRIM(@template_code)), N'');
    SET @status = UPPER(ISNULL(NULLIF(LTRIM(RTRIM(@status)), N''), N'OPEN'));
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    SELECT o.occurrence_id AS OccurrenceId, o.occurrence_key AS OccurrenceKey, o.asset_id AS AssetId, a.asset_name AS AssetName,
           o.template_code AS TemplateCode, t.template_name AS TemplateName, o.due_date AS DueDate,
           DATEDIFF(DAY, @today, o.due_date) AS DaysToDue, o.sequence_no AS SequenceNo, o.decision AS Decision,
           o.decision_reason AS DecisionReason, c.contract_number AS ContractNumber, v.version_no AS ContractVersionNo,
           cm.campaign_key AS CampaignKey, cm.campaign_name AS CampaignName, o.task_id AS TaskId, pt.task_number AS TaskNumber,
           ts.status_name AS TaskStatusName, ae.employee_name AS TaskOwnerName, o.task_error AS TaskError, o.status AS Status,
           o.needs_reconciliation AS NeedsReconciliation, o.reconciliation_reason AS ReconciliationReason,
           o.reconciled_note AS ReconciledNote, o.reconciled_by AS ReconciledBy, o.reconciled_dt AS ReconciledDt,
           o.completed_dt AS CompletedDt, cb.employee_name AS CompletedByName, o.entered_dt AS OpenedDt,
           CONVERT(BIGINT, o.record_version) AS RecordVersion,
           o.revised_due_date AS RevisedDueDate, o.review_date AS ReviewDate, o.is_retest AS IsRetest,          -- 439
           rs.state AS ResultState, rs.outcome AS ResultOutcome, pd.disposition_type AS PendingDispositionType,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_activity_occurrence o
      JOIN grac_practice.asset_activity_template t ON t.template_code = o.template_code
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = o.asset_id
      LEFT JOIN grac_practice.asset_contract_version v ON v.version_id = o.contract_version_id
      LEFT JOIN grac_practice.asset_contract c ON c.contract_id = v.contract_id
      LEFT JOIN grac_practice.asset_activity_campaign cm ON cm.campaign_id = o.campaign_id
      LEFT JOIN grac_practice.practice_task pt ON pt.task_id = o.task_id
      LEFT JOIN grac_practice.entity_status_master ts ON ts.entity_status_id = pt.current_status_id
      LEFT JOIN grac_practice.organization_employee ae ON ae.employee_id = pt.assigned_to_employee_id
      LEFT JOIN grac_practice.organization_employee cb ON cb.employee_id = o.completed_by_employee_id
      LEFT JOIN grac_practice.asset_activity_result rs ON rs.occurrence_id = o.occurrence_id                         -- 439
      LEFT JOIN grac_practice.asset_activity_disposition pd ON pd.occurrence_id = o.occurrence_id AND pd.status = N'PENDING'
     WHERE o.organization_id = @organization_id
       AND (@template_code IS NULL OR o.template_code = @template_code)
       AND (@status = N'ALL' OR o.status = @status)
       AND (ISNULL(@reconcile_only, 0) = 0 OR o.needs_reconciliation = 1)
       AND (@campaign_id IS NULL OR o.campaign_id = @campaign_id)
       AND (@search IS NULL OR a.asset_name LIKE N'%' + @search + N'%' OR o.occurrence_key LIKE N'%' + @search + N'%')
       AND (ISNULL(@awaiting_decision, 0) = 0 OR rs.state = N'SUBMITTED' OR pd.disposition_id IS NOT NULL)          -- 439
     ORDER BY o.due_date, o.occurrence_id
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO
