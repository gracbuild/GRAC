-- =====================================================================
-- 8. Verification
-- =====================================================================
SELECT '446-a objects' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_valuation_result','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_valuation_history','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_valuation_recalc_run','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_value_calc_method') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_valuation_eval') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_valuation_state') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_valuation_risk_links') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_valuation_apply','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_valuation_sync','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_valuation_method_set','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_valuation_recalculate','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_valuation_recalc_preview','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_valuation_recalc_run','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_valuation_get','P') IS NOT NULL
            THEN 'PASS' ELSE 'FAIL' END AS Result;
SELECT '446-b re-issued bodies' AS Check_,
       CASE WHEN OBJECT_DEFINITION(OBJECT_ID('grac_practice.fn_asset_value_calc')) LIKE '%fn_asset_value_calc_method%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_register_save')) LIKE '%sp_asset_valuation_apply%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) LIKE '%sp_asset_valuation_sync%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.fn_asset_stored_values')) LIKE '%asset_valuation_result%'
            THEN 'PASS' ELSE 'FAIL' END AS Result;
-- The 422 calculator and the method function agree for every Active configuration (score 3 / 3 / 3).
SELECT '446-c one formula' AS Check_,
       CASE WHEN NOT EXISTS (
                SELECT 1 FROM grac_practice.asset_valuation_config c
                 CROSS APPLY grac_practice.fn_asset_value_calc(c.config_id, 3, 3, 3) a
                 CROSS APPLY grac_practice.fn_asset_value_calc_method(c.config_id, c.valuation_method, 3, 3, 3) b
                 WHERE c.is_active_version = 1
                   AND (a.AssetValueScore <> b.AssetValueScore OR ISNULL(a.AssetValueCategory, N'') <> ISNULL(b.AssetValueCategory, N'')))
            THEN 'PASS' ELSE 'FAIL' END AS Result;
-- The state function reads for every organization with assets (no runtime error).
SELECT '446-d state readable' AS Check_, COUNT(*) AS AssetsEvaluated, 'PASS' AS Result
  FROM grac_practice.organization o
 CROSS APPLY grac_practice.fn_asset_valuation_state(o.organization_id) s;
GO

/* =====================================================================
   UAT (run as a user with asset-register EDIT / APPROVE and
   asset-valuation-config VIEW / APPROVE)
   ---------------------------------------------------------------------
   1. Asset Valuation: an Active configuration (bands set). Asset
      Register: open an asset whose template has the CIA fields, set
      C / I / A, save -> the Valuation section shows score, category,
      configuration version, VALID; Asset Value Score / Category on the
      form are read-only and filled; history shows a FORM row.
   2. Clear one rating, save -> warning "Asset Value: Rating missing ...",
      status INCOMPLETE, no score or category.
   3. Change Asset Valuation Method on the form to a method other than
      the configured one -> ERROR (override not permitted / use Override
      method). With override_allowed on a new Active version, Override
      method (approver, reason) -> MethodSource OVERRIDE, history row
      METHOD_OVERRIDE; Remove override returns to the configured method.
   4. Activate a new configuration version with different bands -> the
      asset shows "Out of date" (configuration changed), the value is
      unchanged. Asset Valuation -> Recalculation tab: impact shows the
      asset, category move and linked risks; Run with a reason -> value
      moves to the new version; history row RECALC_RUN with the run id;
      the old row is kept.
   5. Run again with the old preview open -> 409 "changed since the
      preview".
   6. Merge or discovery changes a rating -> after the scheduler run the
      asset is recalculated (history SCHEDULER).
   ===================================================================== */
