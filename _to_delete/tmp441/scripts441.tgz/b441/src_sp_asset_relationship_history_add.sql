CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationship_history_add
    @relationship_id   BIGINT,
    @action_code       NVARCHAR(20),
    @note              NVARCHAR(1000) = NULL,
    @actor             NVARCHAR(100),
    @actor_employee_id BIGINT         = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT grac_practice.asset_relationship_history
        (relationship_id, organization_id, version_no, action_code, status, snapshot_json, note, actor, actor_employee_id)
    SELECT r.relationship_id, r.organization_id, r.version_no, @action_code, r.status,
           (SELECT r2.relationship_type_code AS typeCode, r2.source_kind AS sourceKind, r2.source_id AS sourceId,
                   r2.target_kind AS targetKind, r2.target_id AS targetId, r2.is_critical AS isCritical,
                   r2.dependency_criticality AS dependencyCriticality, r2.impact_weight AS impactWeight, r2.status AS status,
                   r2.effective_from AS effectiveFrom, r2.effective_to AS effectiveTo, r2.source_code AS sourceCode,
                   r2.confidence_pct AS confidencePct, r2.verification_status AS verificationStatus,
                   r2.owner_employee_id AS ownerEmployeeId, r2.verifier_employee_id AS verifierEmployeeId,
                   r2.evidence_reference AS evidenceReference, r2.change_reference AS changeReference, r2.reason AS reason,
                   r2.in_loop AS inLoop, r2.pending_action AS pendingAction, r2.retirement_accepted AS retirementAccepted
              FROM grac_practice.asset_relationship r2 WHERE r2.relationship_id = r.relationship_id
               FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           @note, @actor, @actor_employee_id
      FROM grac_practice.asset_relationship r
     WHERE r.relationship_id = @relationship_id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    SELECT N'asset-relationship', h.relationship_id, @action_code, NULL, h.snapshot_json, N'Active', @actor
      FROM grac_practice.asset_relationship_history h
     WHERE h.history_id = SCOPE_IDENTITY();
END
GO
