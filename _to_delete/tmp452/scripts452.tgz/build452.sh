#!/bin/bash
# Rebuilds the 452 delivery from the staged base files (orig/) into $1.
set -e
W=/home/claude/w452; OUT=${1:-$W/new}
rm -rf "$OUT"; cp -r $W/orig "$OUT"
cd $W
cat 452_a.sql 452_a2.sql 452_b.sql 452_c.sql 452_d.sql 452_m.sql 452_e.sql > 452.sql
cp 452.sql "$OUT/database/452_asset_reports.sql"
cp 452_rb.sql "$OUT/database/452_asset_reports_rollback.sql"
python3 p452_api.py "$OUT" >/dev/null
python3 p452_web.py "$OUT" >/dev/null
mkdir -p "$OUT/src/PracticeManagement.Web/Views/Practice/Partials" "$OUT/src/PracticeManagement.Web/wwwroot/js/AssetConfig"
cp asset-reports.cshtml "$OUT/src/PracticeManagement.Web/Views/Practice/Partials/asset-reports.cshtml"
cp asset-reports.js "$OUT/src/PracticeManagement.Web/wwwroot/js/AssetConfig/asset-reports.js"
python3 doc452.py "$OUT" >/dev/null
echo built "$OUT"
