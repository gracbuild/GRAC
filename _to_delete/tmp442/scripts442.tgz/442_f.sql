-- =====================================================================
-- 10. Menu: Asset & Contract -> Asset Discovery (also carried in 274)
-- =====================================================================
MERGE grac_practice.menu_master AS t
USING (VALUES
    (N'asset-discovery', N'Asset Discovery', N'Practice/Index/asset-discovery', 363, N'satellite-dish', N'Asset & Contract')
) AS s(menu_key, menu_name, menu_url, display_order, icon_class, module_type)
ON t.menu_key = s.menu_key
WHEN MATCHED AND (ISNULL(t.menu_name, N'') <> s.menu_name OR ISNULL(t.menu_url, N'') <> s.menu_url
               OR t.display_order <> s.display_order OR ISNULL(t.icon_class, N'') <> s.icon_class
               OR ISNULL(t.module_type, N'') <> s.module_type OR t.status <> N'Active') THEN UPDATE SET
    menu_name = s.menu_name, menu_url = s.menu_url, display_order = s.display_order, icon_class = s.icon_class,
    module_type = s.module_type, status = N'Active', updated_by = N'seed-442', updated_dt = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (menu_key, menu_name, menu_url, display_order, icon_class, module_type, status, entered_by)
    VALUES (s.menu_key, s.menu_name, s.menu_url, s.display_order, s.icon_class, s.module_type, N'Active', N'seed-442');
PRINT CONCAT('442: menu row upserted: ', @@ROWCOUNT);
GO

UPDATE c
   SET parent_menu_id = p.menu_id, updated_by = N'seed-442', updated_dt = SYSUTCDATETIME()
  FROM grac_practice.menu_master c
  JOIN grac_practice.menu_master p ON p.menu_key = N'nav-asset-contract'
 WHERE c.menu_key = N'asset-discovery' AND ISNULL(c.parent_menu_id, -1) <> p.menu_id;
GO

DECLARE @active_rs INT = (
    SELECT TOP 1 record_status_id FROM grac_practice.record_status_master
     WHERE status_code = N'Active' OR status_name = N'Active' ORDER BY record_status_id);
IF @active_rs IS NULL SET @active_rs = 1;
INSERT grac_practice.organization_role_menu_permission
    (role_id, menu_id, can_view, can_add, can_edit, can_delete, can_approve, status, record_status_id, entered_by, entered_dt)
SELECT r.role_id, m.menu_id, 1, 1, 1, 0, 1, N'Active', @active_rs, N'seed-442', SYSUTCDATETIME()
  FROM grac_practice.organization_role r
  JOIN grac_practice.menu_master m ON m.menu_key = N'asset-discovery'
 WHERE r.role_name = N'Admin' AND r.status = N'Active'
   AND NOT EXISTS (SELECT 1 FROM grac_practice.organization_role_menu_permission e
                    WHERE e.role_id = r.role_id AND e.menu_id = m.menu_id);
PRINT CONCAT('442: Admin grants inserted: ', @@ROWCOUNT);
GO

-- =====================================================================
-- Verification
-- =====================================================================
SELECT '442-a tables and task type' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_discovery_source','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_discovery_priority','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_identification_rule','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_discovery_setting','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_discovery_batch','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_discovery_observation','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_discovery_link','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_attribute_source','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_reconciliation_exception','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_duplicate_decision','U') IS NOT NULL
             AND EXISTS (SELECT 1 FROM grac_practice.task_type_master WHERE type_code = N'AssetReconciliation')
            THEN 'PASS' ELSE 'FAIL' END AS Result
UNION ALL
SELECT '442-b functions and procedures present',
       CASE WHEN OBJECT_ID('grac_practice.fn_asset_norm') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_discovery_confidence') IS NOT NULL
             AND (SELECT COUNT(*) FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'grac_practice'
                   AND name IN ('sp_asset_discovery_defaults_ensure', 'sp_asset_discovery_source_save', 'sp_asset_discovery_priorities_save',
                                'sp_asset_identification_rule_save', 'sp_asset_discovery_setting_save', 'sp_asset_discovery_identity_load',
                                'sp_asset_reconciliation_exception_raise', 'sp_asset_discovery_apply', 'sp_asset_discovery_reconcile',
                                'sp_asset_discovery_ingest', 'sp_asset_reconciliation_resolve', 'sp_asset_discovery_config_get',
                                'sp_asset_discovery_batches', 'sp_asset_discovery_batch_get', 'sp_asset_reconciliation_exceptions',
                                'sp_asset_discovery_confidence', 'sp_asset_discovery_asset_get')) = 17
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '442-c normalization (MAC separators, hostname short name, blank)',
       CASE WHEN grac_practice.fn_asset_norm(N'mac_address', N'aa:bb-cc.dd:ee:ff') = N'AABBCCDDEEFF'
             AND grac_practice.fn_asset_norm(N'hostname', N'srv01.corp.local') = N'SRV01'
             AND grac_practice.fn_asset_norm(N'serial_number', N'  abc123 ') = N'ABC123'
             AND grac_practice.fn_asset_norm(N'serial_number', N'   ') IS NULL
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '442-d menu row Active under Asset & Contract',
       CASE WHEN EXISTS (SELECT 1 FROM grac_practice.menu_master c
                           JOIN grac_practice.menu_master p ON p.menu_id = c.parent_menu_id AND p.menu_key = N'nav-asset-contract'
                          WHERE c.menu_key = N'asset-discovery' AND c.status = N'Active') THEN 'PASS' ELSE 'FAIL' END;
GO

-- =====================================================================
-- UAT (after deploying the API + Web build; re-login for the menu grant)
--   Needs: asset SRV1 with serial "SN-1", make / model set, hostname
--   "srv1", asset tag "T-1"; asset SRV2 with hostname "srv2"; users E (edit)
--   and A (approve).
--   1. Asset Discovery -> Sources: add CMDB-SCAN (Discovery, Batch, trust
--      100, interval 24 h). Field precedence: hostname golden, ip_address
--      contributing. Identification rules: the ten defaults are listed.
--   2. Import: batch B1, records
--        [{"externalKey":"d-1","attributes":{"asset_tag":"T-1","hostname":"srv1","ip_address":"10.0.0.5","serial_number":"SN-9"}},
--         {"externalKey":"d-2","attributes":{"hostname":"newbox"}},
--         {"externalKey":"d-3","attributes":"bad"}]
--      -> d-1 Updated (asset tag match; IP filled; serial differs and the
--      source is not golden -> Conflict with an owner task), d-2 New
--      candidate, d-3 Error; batch Partial with per-record results.
--   3. Import B1 again -> the same batch is returned, nothing reprocessed.
--      Import B2 with the d-1 record unchanged -> No change (freshness only).
--   4. Reconciliation queue: Conflict -> Keep current (note) or Accept
--      observed (A). New candidate d-2 -> Link to SRV2 (E) -> the hostname
--      "newbox" is a conflict on SRV2 (hostname golden would overwrite: set
--      hostname golden for this source first to see the overwrite).
--   5. A record matching SRV1 and SRV2 at the suggested score -> Potential
--      duplicate; Not a duplicate (note) -> a repeat no longer raises it.
--   6. Data confidence: SRV1 Probable (fresh, auto match) or Conflicting
--      while its conflict is open; set the source interval to 1 h and wait
--      past 3 h -> Stale; a recent last verified date -> Verified.
-- =====================================================================
