# Builds the 441 re-issued bodies from the 440 sources (b441/src_*.sql): verbatim + marked 441 changes.
B = '/home/claude/b441/'
out = {}
def tx(name, pairs):
    s = open(B + 'src_' + name + '.sql', encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (name, a[:70], s.count(a))
        s = s.replace(a, b)
    out[name] = s

tx('fn_asset_ci_catalog', [(
"""      FROM grac_practice.organization_location l
     WHERE l.organization_id = @organization_id;""",
"""      FROM grac_practice.organization_location l
     WHERE l.organization_id = @organization_id
    UNION ALL
    -- 441: business services (usable until Retired) and contracts (usable until terminated).
    SELECT N'SERVICE', b.service_id, CAST(b.service_name AS NVARCHAR(400)),
           CAST(CONCAT(N'Service - ', LOWER(REPLACE(b.service_type, N'_', N' '))) AS NVARCHAR(200)),
           CAST(b.status AS NVARCHAR(120)), CAST(CASE WHEN b.status = N'RETIRED' THEN 0 ELSE 1 END AS BIT), b.business_owner_employee_id
      FROM grac_practice.business_service b
     WHERE b.organization_id = @organization_id
    UNION ALL
    SELECT N'CONTRACT', c.contract_id, CAST(CONCAT(c.contract_number, N' - ', c.contract_name) AS NVARCHAR(400)),
           CAST(CONCAT(N'Contract - ', c.contract_type) AS NVARCHAR(200)), CAST(c.contract_status AS NVARCHAR(120)),
           CAST(CASE WHEN c.contract_status = N'TERMINATED' THEN 0 ELSE 1 END AS BIT), cv.contract_owner_id
      FROM grac_practice.asset_contract c
      LEFT JOIN grac_practice.asset_contract_version cv ON cv.version_id = c.current_version_id
     WHERE c.organization_id = @organization_id;""")])

tx('sp_asset_relationship_history_add', [(
"""                   r2.in_loop AS inLoop, r2.pending_action AS pendingAction, r2.retirement_accepted AS retirementAccepted""",
"""                   r2.in_loop AS inLoop, r2.pending_action AS pendingAction, r2.retirement_accepted AS retirementAccepted,
                   r2.service_role AS serviceRole                                                   -- 441""")])

tx('sp_asset_relationship_save', [
("""    @change_reference        NVARCHAR(200)  = NULL,
    @reason """,
"""    @change_reference        NVARCHAR(200)  = NULL,
    @service_role            NVARCHAR(100)  = NULL,      -- 441: role of the mapping ("primary database")
    @reason """),
("""    SET @change_reference = NULLIF(LTRIM(RTRIM(@change_reference)), N'');""",
"""    SET @change_reference = NULLIF(LTRIM(RTRIM(@change_reference)), N'');
    SET @service_role = NULLIF(LTRIM(RTRIM(@service_role)), N'');                                    -- 441"""),
("""             owner_employee_id, verifier_employee_id, evidence_reference, change_reference, reason, in_loop,
             proposed_by, proposed_by_employee_id, entered_by)""",
"""             owner_employee_id, verifier_employee_id, evidence_reference, change_reference, reason, in_loop,
             proposed_by, proposed_by_employee_id, entered_by, service_role)                           -- 441"""),
("""                @owner_employee_id, @verifier_employee_id, @evidence_reference, @change_reference, @reason, ISNULL(@loop, 0),
                @actor, @actor_employee_id, @actor);""",
"""                @owner_employee_id, @verifier_employee_id, @evidence_reference, @change_reference, @reason, ISNULL(@loop, 0),
                @actor, @actor_employee_id, @actor, @service_role);"""),
("""                                      @change_reference AS changeReference, @reason AS reason
                                  FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER),""",
"""                                      @change_reference AS changeReference, @reason AS reason,
                                      @service_role AS serviceRole                                -- 441
                                  FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER),"""),
("""               evidence_reference = @evidence_reference, change_reference = @change_reference, reason = @reason,
               version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()""",
"""               evidence_reference = @evidence_reference, change_reference = @change_reference, reason = @reason,
               service_role = @service_role,                                                          -- 441
               version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()"""),
])

tx('sp_asset_relationship_action', [
("""                   evidence_reference = j.evidenceReference, change_reference = j.changeReference, reason = j.reason,
                   version_no = version_no + 1""",
"""                   evidence_reference = j.evidenceReference, change_reference = j.changeReference, reason = j.reason,
                   service_role = j.serviceRole,                                                      -- 441
                   version_no = version_no + 1"""),
("""                    evidenceReference NVARCHAR(400), changeReference NVARCHAR(200), reason NVARCHAR(1000)) j""",
"""                    evidenceReference NVARCHAR(400), changeReference NVARCHAR(200), reason NVARCHAR(1000),
                    serviceRole NVARCHAR(100)) j                                                      -- 441"""),
])

tx('sp_asset_relationship_get', [("""r.dependency_criticality AS DependencyCriticality, r.impact_weight AS ImpactWeight,""",
        """r.dependency_criticality AS DependencyCriticality, r.impact_weight AS ImpactWeight,
           r.service_role AS ServiceRole,                                                             -- 441""")])
tx('sp_asset_relationships', [("""r.dependency_criticality AS DependencyCriticality, r.impact_weight AS ImpactWeight, r.status AS Status,""",
        """r.dependency_criticality AS DependencyCriticality, r.impact_weight AS ImpactWeight,
           r.service_role AS ServiceRole,                                                             -- 441
           r.status AS Status,""")])

tx('sp_asset_ci_impact', [
("""           (SELECT MAX(lvl) FROM #seen) AS DeepestLevel;
END""",
"""           (SELECT MAX(lvl) FROM #seen) AS DeepestLevel;

    -- 441: business services reached.
    SELECT s.i AS ServiceId, b.service_code AS ServiceCode, b.service_name AS ServiceName, b.service_type AS ServiceType,
           b.status AS ServiceStatus, s.lvl AS ImpactLevel, cm.criticality_code AS CriticalityCode, b.rto_hours AS RtoHours,
           b.rpo_hours AS RpoHours, b.mtpd_hours AS MtpdHours, bo.employee_name AS BusinessOwnerName,
           sm.employee_name AS ServiceManagerName, cn.Consumers
      FROM #seen s
      JOIN grac_practice.business_service b ON b.service_id = s.i
      LEFT JOIN grac_practice.criticality_master cm ON cm.criticality_id = b.criticality_id
      LEFT JOIN grac_practice.organization_employee bo ON bo.employee_id = b.business_owner_employee_id
      LEFT JOIN grac_practice.organization_employee sm ON sm.employee_id = b.service_manager_employee_id
     OUTER APPLY (SELECT STRING_AGG(c.ConsumerName, N', ') AS Consumers
                    FROM grac_practice.fn_business_service_consumers(b.service_id) c) cn
     WHERE s.k = N'SERVICE' AND s.lvl > 0
     ORDER BY s.lvl, b.service_name;
END"""),
])

for n, s in out.items():
    open(B + 'new_' + n + '.sql', 'w', encoding='utf-8', newline='').write(s)
print('re-issues built:', len(out))
