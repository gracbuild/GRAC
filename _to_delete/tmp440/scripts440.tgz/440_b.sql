
-- =====================================================================
-- 3. Helpers
-- =====================================================================
-- Relationship endpoints of an organization (D80): assets (usable unless
-- Disposed / Archived), applications, processes, vendors and locations
-- (usable while Active).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_ci_catalog (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT N'ASSET' AS CiKind, a.asset_id AS CiId, CAST(a.asset_name AS NVARCHAR(400)) AS CiName,
           CAST(ISNULL(ty.asset_type_name, N'Asset') AS NVARCHAR(200)) AS CiClass,
           CAST(ISNULL(s.status_name, N'Active') AS NVARCHAR(120)) AS CiStatus,
           CAST(CASE WHEN ISNULL(s.status_code, N'ACTIVE') IN (N'DISPOSED', N'ARCHIVED') THEN 0 ELSE 1 END AS BIT) AS IsUsable,
           a.owner_id AS OwnerEmployeeId
      FROM grac_practice.organization_dependency_asset a
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
      LEFT JOIN grac_practice.dependency_asset_type_master ty ON ty.asset_type_id = a.asset_type_id
     WHERE a.organization_id = @organization_id
    UNION ALL
    SELECT N'APPLICATION', p.application_id, CAST(p.application_name AS NVARCHAR(400)), CAST(N'Application' AS NVARCHAR(200)),
           CAST(p.status AS NVARCHAR(120)), CAST(CASE WHEN p.status = N'Active' THEN 1 ELSE 0 END AS BIT), p.business_owner_id
      FROM grac_practice.organization_dependency_application p
     WHERE p.organization_id = @organization_id
    UNION ALL
    SELECT N'PROCESS', p.process_id, CAST(p.process_name AS NVARCHAR(400)), CAST(N'Process' AS NVARCHAR(200)),
           CAST(p.status AS NVARCHAR(120)), CAST(CASE WHEN p.status = N'Active' THEN 1 ELSE 0 END AS BIT), p.process_owner_id
      FROM grac_practice.organization_dependency_process p
     WHERE p.organization_id = @organization_id
    UNION ALL
    SELECT N'VENDOR', v.vendor_id, CAST(v.vendor_name AS NVARCHAR(400)), CAST(N'Vendor' AS NVARCHAR(200)),
           CAST(v.status AS NVARCHAR(120)), CAST(CASE WHEN v.status = N'Active' THEN 1 ELSE 0 END AS BIT), v.relationship_owner_id
      FROM grac_practice.organization_dependency_vendor v
     WHERE v.organization_id = @organization_id
    UNION ALL
    SELECT N'LOCATION', l.location_id, CAST(l.location_name AS NVARCHAR(400)), CAST(N'Location' AS NVARCHAR(200)),
           CAST(l.status AS NVARCHAR(120)), CAST(CASE WHEN l.status = N'Active' THEN 1 ELSE 0 END AS BIT), l.location_head_id
      FROM grac_practice.organization_location l
     WHERE l.organization_id = @organization_id;
GO

-- Dependency edges (dependent -> provider) of the relationships in the
-- given statuses; types whose dependent side is NONE carry no impact.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_relationship_edges (@organization_id BIGINT, @current_only BIT)
RETURNS TABLE
AS
RETURN
    SELECT r.relationship_id AS RelationshipId, r.relationship_type_code AS TypeCode, r.is_critical AS IsCritical, r.status AS Status,
           CASE WHEN t.dependent_side = N'SOURCE' THEN r.source_kind ELSE r.target_kind END AS DependentKind,
           CASE WHEN t.dependent_side = N'SOURCE' THEN r.source_id ELSE r.target_id END AS DependentId,
           CASE WHEN t.dependent_side = N'SOURCE' THEN r.target_kind ELSE r.source_kind END AS ProviderKind,
           CASE WHEN t.dependent_side = N'SOURCE' THEN r.target_id ELSE r.source_id END AS ProviderId,
           r.retirement_accepted AS RetirementAccepted
      FROM grac_practice.asset_relationship r
      JOIN grac_practice.asset_relationship_type t ON t.type_code = r.relationship_type_code
     WHERE r.organization_id = @organization_id AND t.dependent_side <> N'NONE'
       AND ((@current_only = 1 AND r.status = N'ACTIVE'
             AND r.effective_from <= CAST(SYSUTCDATETIME() AS DATE)
             AND (r.effective_to IS NULL OR r.effective_to >= CAST(SYSUTCDATETIME() AS DATE)))
            OR (@current_only = 0 AND r.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')));
GO

-- Active critical relationships that rely on a CI and were not accepted
-- for its retirement (5.4.2 retirement gate, D86).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_relationship_blockers (@organization_id BIGINT, @ci_kind NVARCHAR(12), @ci_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT e.RelationshipId, e.TypeCode, e.DependentKind, e.DependentId
      FROM grac_practice.fn_asset_relationship_edges(@organization_id, 1) e
     WHERE e.ProviderKind = @ci_kind AND e.ProviderId = @ci_id AND e.IsCritical = 1 AND e.RetirementAccepted = 0;
GO

-- Validates a relationship (new or being approved): type, kinds,
-- endpoints, duplicates, cardinality, loops (D81-D83). @out_loop = 1 when
-- the relationship closes a loop its type permits (flagged).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationship_check
    @organization_id BIGINT,
    @relationship_id BIGINT        = NULL,     -- excluded from the duplicate / cardinality / loop checks
    @type_code       NVARCHAR(30),
    @source_kind     NVARCHAR(12),
    @source_id       BIGINT,
    @target_kind     NVARCHAR(12),
    @target_id       BIGINT,
    @out_loop        BIT           = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @out_loop = 0;
    DECLARE @active BIT, @type_name NVARCHAR(100), @src_kinds NVARCHAR(200), @tgt_kinds NVARCHAR(200), @card NVARCHAR(12),
            @loop NVARCHAR(6), @side NVARCHAR(6), @msg NVARCHAR(1000), @self BIGINT = ISNULL(@relationship_id, -1);
    SELECT @active = is_active, @type_name = type_name, @src_kinds = source_kinds, @tgt_kinds = target_kinds, @card = cardinality,
           @loop = loop_rule, @side = dependent_side
      FROM grac_practice.asset_relationship_type WHERE type_code = @type_code;
    IF ISNULL(@active, 0) = 0 THROW 54702, 'Select an active relationship type.', 1;
    IF CHARINDEX(N',' + ISNULL(@source_kind, N'') + N',', N',' + @src_kinds + N',') = 0
       OR CHARINDEX(N',' + ISNULL(@target_kind, N'') + N',', N',' + @tgt_kinds + N',') = 0
    BEGIN
        SET @msg = CONCAT(N'"', @type_name, N'" links a source of kind ', REPLACE(@src_kinds, N',', N' / '),
                          N' to a target of kind ', REPLACE(@tgt_kinds, N',', N' / '), N'.');
        THROW 54703, @msg, 1;
    END
    IF @source_kind = @target_kind AND @source_id = @target_id
        THROW 54705, 'The source and the target must be different.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.fn_asset_ci_catalog(@organization_id) c
                    WHERE c.CiKind = @source_kind AND c.CiId = @source_id AND c.IsUsable = 1)
        THROW 54704, 'The source was not found in this organization or is no longer in use.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.fn_asset_ci_catalog(@organization_id) c
                    WHERE c.CiKind = @target_kind AND c.CiId = @target_id AND c.IsUsable = 1)
        THROW 54704, 'The target was not found in this organization or is no longer in use.', 1;
    IF EXISTS (SELECT 1 FROM grac_practice.asset_relationship
                WHERE organization_id = @organization_id AND relationship_type_code = @type_code
                  AND source_kind = @source_kind AND source_id = @source_id AND target_kind = @target_kind AND target_id = @target_id
                  AND status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED') AND relationship_id <> @self)
        THROW 54706, 'This relationship already exists (proposed, active or disputed).', 1;
    IF @card IN (N'ONE_TARGET', N'ONE_TO_ONE')
       AND EXISTS (SELECT 1 FROM grac_practice.asset_relationship
                    WHERE organization_id = @organization_id AND relationship_type_code = @type_code
                      AND source_kind = @source_kind AND source_id = @source_id
                      AND status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED') AND relationship_id <> @self)
    BEGIN
        SET @msg = CONCAT(N'The source already has a "', @type_name, N'" relationship; retire it first (one target only).');
        THROW 54707, @msg, 1;
    END
    IF @card IN (N'ONE_SOURCE', N'ONE_TO_ONE')
       AND EXISTS (SELECT 1 FROM grac_practice.asset_relationship
                    WHERE organization_id = @organization_id AND relationship_type_code = @type_code
                      AND target_kind = @target_kind AND target_id = @target_id
                      AND status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED') AND relationship_id <> @self)
    BEGIN
        SET @msg = CONCAT(N'The target already has a "', @type_name, N'" relationship; retire it first (one source only).');
        THROW 54707, @msg, 1;
    END

    IF @loop = N'ALLOW' RETURN;
    -- Loop: does the provider (or, for a type without impact, the target)
    -- already reach the other end? Breadth-first walk with a visited set.
    DECLARE @from_kind NVARCHAR(12), @from_id BIGINT, @to_kind NVARCHAR(12), @to_id BIGINT;
    CREATE TABLE #edge (dk NVARCHAR(12) NOT NULL, di BIGINT NOT NULL, pk NVARCHAR(12) NOT NULL, pi BIGINT NOT NULL);
    IF @side = N'NONE'
    BEGIN
        INSERT #edge (dk, di, pk, pi)
        SELECT source_kind, source_id, target_kind, target_id FROM grac_practice.asset_relationship
         WHERE organization_id = @organization_id AND relationship_type_code = @type_code
           AND status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED') AND relationship_id <> @self;
        SELECT @from_kind = @target_kind, @from_id = @target_id, @to_kind = @source_kind, @to_id = @source_id;
    END
    ELSE
    BEGIN
        INSERT #edge (dk, di, pk, pi)
        SELECT DependentKind, DependentId, ProviderKind, ProviderId FROM grac_practice.fn_asset_relationship_edges(@organization_id, 0)
         WHERE RelationshipId <> @self;
        -- new edge: dependent -> provider; a loop exists when the provider already depends on the dependent.
        SELECT @from_kind = CASE WHEN @side = N'SOURCE' THEN @target_kind ELSE @source_kind END,
               @from_id   = CASE WHEN @side = N'SOURCE' THEN @target_id ELSE @source_id END,
               @to_kind   = CASE WHEN @side = N'SOURCE' THEN @source_kind ELSE @target_kind END,
               @to_id     = CASE WHEN @side = N'SOURCE' THEN @source_id ELSE @target_id END;
    END
    CREATE TABLE #seen (k NVARCHAR(12) NOT NULL, i BIGINT NOT NULL, lvl INT NOT NULL, PRIMARY KEY (k, i));
    INSERT #seen (k, i, lvl) VALUES (@from_kind, @from_id, 0);
    DECLARE @lvl INT = 0, @hit BIT = 0;
    WHILE @lvl < 100 AND @hit = 0
    BEGIN
        INSERT #seen (k, i, lvl)
        SELECT DISTINCT e.pk, e.pi, @lvl + 1
          FROM #edge e
          JOIN #seen s ON s.lvl = @lvl AND s.k = e.dk AND s.i = e.di
         WHERE NOT EXISTS (SELECT 1 FROM #seen x WHERE x.k = e.pk AND x.i = e.pi);
        IF @@ROWCOUNT = 0 BREAK;
        IF EXISTS (SELECT 1 FROM #seen WHERE k = @to_kind AND i = @to_id) SET @hit = 1;
        SET @lvl = @lvl + 1;
    END
    IF @hit = 1 AND @loop = N'BLOCK'
    BEGIN
        SET @msg = CONCAT(N'"', @type_name, N'" would create a circular dependency: the other end already depends on this one (',
                          @lvl, N' step(s)).');
        THROW 54708, @msg, 1;
    END
    IF @hit = 1 SET @out_loop = 1;
END
GO

-- Writes one history row with a snapshot of the relationship.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationship_history_add
    @relationship_id   BIGINT,
    @action_code       NVARCHAR(20),
    @note              NVARCHAR(1000) = NULL,
    @actor             NVARCHAR(100),
    @actor_employee_id BIGINT         = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT grac_practice.asset_relationship_history
        (relationship_id, organization_id, version_no, action_code, status, snapshot_json, note, actor, actor_employee_id)
    SELECT r.relationship_id, r.organization_id, r.version_no, @action_code, r.status,
           (SELECT r2.relationship_type_code AS typeCode, r2.source_kind AS sourceKind, r2.source_id AS sourceId,
                   r2.target_kind AS targetKind, r2.target_id AS targetId, r2.is_critical AS isCritical,
                   r2.dependency_criticality AS dependencyCriticality, r2.impact_weight AS impactWeight, r2.status AS status,
                   r2.effective_from AS effectiveFrom, r2.effective_to AS effectiveTo, r2.source_code AS sourceCode,
                   r2.confidence_pct AS confidencePct, r2.verification_status AS verificationStatus,
                   r2.owner_employee_id AS ownerEmployeeId, r2.verifier_employee_id AS verifierEmployeeId,
                   r2.evidence_reference AS evidenceReference, r2.change_reference AS changeReference, r2.reason AS reason,
                   r2.in_loop AS inLoop, r2.pending_action AS pendingAction, r2.retirement_accepted AS retirementAccepted
              FROM grac_practice.asset_relationship r2 WHERE r2.relationship_id = r.relationship_id
               FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           @note, @actor, @actor_employee_id
      FROM grac_practice.asset_relationship r
     WHERE r.relationship_id = @relationship_id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    SELECT N'asset-relationship', h.relationship_id, @action_code, NULL, h.snapshot_json, N'Active', @actor
      FROM grac_practice.asset_relationship_history h
     WHERE h.history_id = SCOPE_IDENTITY();
END
GO

-- Active relationships whose effective-to date passed become Inactive
-- (kept for history).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationship_sync
    @organization_id BIGINT,
    @actor           NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    DECLARE @ended TABLE (relationship_id BIGINT NOT NULL);
    BEGIN TRAN;
    UPDATE grac_practice.asset_relationship
       SET status = N'INACTIVE', version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()
    OUTPUT inserted.relationship_id INTO @ended (relationship_id)
     WHERE organization_id = @organization_id AND status = N'ACTIVE' AND effective_to < @today;
    DECLARE @rid BIGINT;
    DECLARE end_cur CURSOR LOCAL STATIC FOR SELECT relationship_id FROM @ended;
    OPEN end_cur;
    FETCH NEXT FROM end_cur INTO @rid;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC grac_practice.sp_asset_relationship_history_add @relationship_id = @rid, @action_code = N'EXPIRE',
             @note = N'The effective-to date passed.', @actor = @actor;
        FETCH NEXT FROM end_cur INTO @rid;
    END
    CLOSE end_cur;
    DEALLOCATE end_cur;
    COMMIT;
END
GO
PRINT '440: helpers created.';
GO
