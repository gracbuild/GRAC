import sys, json, re
R = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w451/new'
def edit(path, old, new, count=1):
    p = R + '/' + path
    s = open(p, encoding='utf-8').read()
    assert s.count(old) == count, (path, old[:80], s.count(old))
    open(p, 'w', encoding='utf-8', newline='').write(s.replace(old, new))

W = 'src/PracticeManagement.Web/'
# ------------------------------------------------------------------ API
edit('src/PracticeManagement.Api/Services/ManagementDashboardService.cs', """//   audit-assurance  sp_dashboard_audit_assurance
""", """//   audit-assurance  sp_dashboard_audit_assurance
//   asset-contract   sp_dashboard_asset_contract    (451)
""")
edit('src/PracticeManagement.Api/Services/ManagementDashboardService.cs', """        ["audit-assurance"] = "grac_practice.sp_dashboard_audit_assurance"
""", """        ["audit-assurance"] = "grac_practice.sp_dashboard_audit_assurance",
        ["asset-contract"]  = "grac_practice.sp_dashboard_asset_contract"       // 451
""")

# ------------------------------------------------------------------ Web models
edit(W + 'Models/ManagementDashboards.cs', """                ("plans",    "org-assurance-plans")
            ]
""", """                ("plans",    "org-assurance-plans")
            ],
            // 451: Asset & Contract dashboard (sp_dashboard_asset_contract).
            ["asset-contract-dashboard"] =
            [
                ("governance",    "asset-governance"),
                ("assets",        "asset-register"),
                ("technology",    "asset-register"),
                ("contracts",     "asset-contracts"),
                ("attestation",   "asset-attestation"),
                ("activities",    "asset-activities"),
                ("privacy",       "asset-privacy"),
                ("discovery",     "asset-discovery"),
                ("services",      "business-services"),
                ("relationships", "asset-relationships"),
                ("notifications", "asset-notifications")
            ]
""")
P = R + '/' + W + 'Models/PracticeScreen.cs'
s = open(P, encoding='utf-8').read()
i = s.index('        new("asset-governance",'); j = s.index('\n', i)
s = s[:j] + """
        // Phase 8.4b (migration 451): the module dashboard of Asset &
        // Contract (first child, 416 rule) -- Partials/management-dashboard.
        new("asset-contract-dashboard","Asset & Contract Dashboard","Governance score, asset register, technology lifecycle, contracts and coverage, attestation, maintenance and calibration, privacy, CMDB quality and discovery, business services, relationships and notification operations for the selected organization.","boxes-stacked",["Metric","Value"], AssetContractGroup),""" + s[j:]
open(P, 'w', encoding='utf-8', newline='').write(s)

for app in ['src/PracticeManagement.Web/appsettings.json', 'src/PracticeManagement.Api/appsettings.json']:
    edit(app, '"nav-asset-contract:VIEW"', '"nav-asset-contract:VIEW", "asset-contract-dashboard:VIEW"')
    json.load(open(R + '/' + app, encoding='utf-8'))

# ------------------------------------------------------------------ 274
M = 'database/274_menu_master_seed.sql'
edit(M, """--   450 -- 'asset-governance' (365, Asset Governance) under
--     'nav-asset-contract'.
""", """--   450 -- 'asset-governance' (365, Asset Governance) under
--     'nav-asset-contract'.
--   451 -- 'asset-contract-dashboard' (348, Dashboard -- first child, 416
--     rule) under 'nav-asset-contract'.
""")
edit(M, """    (N'asset-governance'              , N'Asset Governance'                  , N'Practice/Index/asset-governance'            ,  365, N'gauge-high'            , N'Asset & Contract'           , N'Active')   -- 450
""", """    (N'asset-governance'              , N'Asset Governance'                  , N'Practice/Index/asset-governance'            ,  365, N'gauge-high'            , N'Asset & Contract'           , N'Active'),  -- 450
    (N'asset-contract-dashboard'      , N'Dashboard'                         , N'Practice/Index/asset-contract-dashboard'    ,  348, N'chart-pie'             , N'Asset & Contract'           , N'Active')   -- 451
""")
edit(M, """    (N'asset-governance'              , N'nav-asset-contract')   -- 450
""", """    (N'asset-governance'              , N'nav-asset-contract'),  -- 450
    (N'asset-contract-dashboard'      , N'nav-asset-contract')   -- 451
""")

# ------------------------------------------------------------------ management-dashboard.js
J = W + 'wwwroot/js/ManagementDashboard/management-dashboard.js'
edit(J, """// Nothing here decides what "open", "overdue" or "pending" means: the
""", """// 451: also the Asset & Contract dashboard (asset-contract). Its tiles
// and bars open the asset screens with tab / status / kind / pending, which
// those screens read through Shared/dashboard-drill.js; an ageing band is a
// link only where the page filters by age (AGEING_DRILL).
//
// Nothing here decides what "open", "overdue" or "pending" means: the
""")
edit(J, """    instances:  (p, l) => link("/Practice/Index/resolve", p, l)
  };
""", """    instances:  (p, l) => link("/Practice/Index/resolve", p, l),
    // 451: Asset & Contract dashboard sections
    governance:    (p, l) => link("/Practice/Index/asset-governance", p, l),
    assets:        (p, l) => link("/Practice/Index/asset-register", p, l),
    technology:    (p, l) => link("/Practice/Index/asset-register", p, l),
    contracts:     (p, l) => link("/Practice/Index/asset-contracts", p, l),
    attestation:   (p, l) => link("/Practice/Index/asset-attestation", p, l),
    activities:    (p, l) => link("/Practice/Index/asset-activities", p, l),
    privacy:       (p, l) => link("/Practice/Index/asset-privacy", p, l),
    discovery:     (p, l) => link("/Practice/Index/asset-discovery", p, l),
    services:      (p, l) => link("/Practice/Index/business-services", p, l),
    relationships: (p, l) => link("/Practice/Index/asset-relationships", p, l),
    notifications: (p, l) => link("/Practice/Index/asset-notifications", p, l)
  };
""")
edit(J, """    "instances.notimplemented": { status: "Not Implemented" }
""", """    "instances.notimplemented": { status: "Not Implemented" },
    // 451: Asset & Contract. A tile without an entry counts something its
    // page cannot filter to (in use, no owner, overdue activities ...), so
    // it is not a link.
    "governance.overall":     {},
    "governance.red":         {},
    "governance.amber":       {},
    "governance.green":       {},
    "governance.failing":     {},
    "assets.total":           {},
    "assets.draft":           { status: "DRAFT" },
    "assets.pending":         { pending: "1" },
    "contracts.active":       { tab: "CONTRACTS", status: "ACTIVE" },
    "contracts.expired":      { tab: "CONTRACTS", status: "EXPIRED" },
    "contracts.renewals":     { tab: "RENEWALS" },
    "contracts.gaps":         { tab: "GAPS" },
    "attestation.pending":    { tab: "ALL", status: "PENDING" },
    "attestation.inprogress": { tab: "ALL", status: "IN_PROGRESS" },
    "attestation.overdue":    { tab: "ALL", status: "OVERDUE" },
    "attestation.confirmed":  { tab: "ALL", status: "CONFIRMED" },
    "attestation.disputed":   { tab: "ALL", status: "DISPUTED" },
    "attestation.exceptions": { tab: "EXCEPTIONS", status: "OPEN_ALL" },
    "activities.open":        { tab: "OCCURRENCES", status: "OPEN" },
    "activities.reviews":     { tab: "REVIEWS", status: "OPEN" },
    "privacy.noncompliant":   { tab: "ASSETS", status: "NON_COMPLIANT" },
    "privacy.incomplete":     { tab: "ASSETS", status: "INCOMPLETE" },
    "privacy.undetermined":   { tab: "ASSETS", status: "UNDETERMINED" },
    "discovery.open":         { tab: "QUEUE" },
    "discovery.conflicts":    { tab: "QUEUE", kind: "CONFLICT" },
    "discovery.duplicates":   { tab: "QUEUE", kind: "DUPLICATE" },
    "discovery.stale":        { tab: "STALE" },
    "services.degraded":      { tab: "SERVICES", status: "DEGRADED" },
    "services.conflicts":     { tab: "CONFLICTS" },
    "relationships.active":   { tab: "RELATIONSHIPS", status: "ACTIVE" },
    "relationships.proposed": { tab: "RELATIONSHIPS", status: "PROPOSED" },
    "relationships.disputed": { tab: "RELATIONSHIPS", status: "DISPUTED" },
    "notifications.open":     { tab: "OCCURRENCES", status: "OPEN" },
    "notifications.failed":   { tab: "LOG", status: "Failed" }
""")
edit(J, """          href: TARGET[key] ? TARGET[key](filter, `${g.title} aged ${F(b, "bandName")}`) : null
""", """          // 451: a band links only where the page filters by age (AGEING_DRILL).
          href: TARGET[key] && AGEING_DRILL[key] ? TARGET[key](filter, `${g.title} aged ${F(b, "bandName")}`) : null
""")
edit(J, """    instances_status:  ["instances",  k => ({ status: k })]
""", """    instances_status:  ["instances",  k => ({ status: k })],
    // 451: Asset & Contract (groups without an entry are not links)
    assets_status:        ["assets",        k => ({ status: k })],
    contracts_status:     ["contracts",     k => ({ tab: "CONTRACTS", status: k })],
    attestation_status:   ["attestation",   k => ({ tab: "ALL", status: k })],
    privacy_status:       ["privacy",       k => ({ tab: "ASSETS", status: k })],
    discovery_kind:       ["discovery",     k => ({ tab: "QUEUE", kind: k })],
    discovery_confidence: ["discovery",     k => ({ tab: "CONFIDENCE", status: k })],
    services_status:      ["services",      k => ({ tab: "SERVICES", status: k })],
    relationships_status: ["relationships", k => ({ tab: "RELATIONSHIPS", status: k })]
""")
edit(J, """    if (listKey === "audits_overdue")  return TARGET.audits({ drill: "overdue" }, "Overdue audits");
""", """    if (listKey === "audits_overdue")  return TARGET.audits({ drill: "overdue" }, "Overdue audits");
    // 451: an asset opens on the Asset Register (?assetId=, 450).
    if (listKey === "technology_unsupported" && id)
      return U("/Practice/Index/asset-register") + "?" + new URLSearchParams({ organizationId: orgId, assetId: id }).toString();
    if (listKey === "attestation_overdue") return TARGET.attestation({ tab: "ALL", status: "OVERDUE" }, "Overdue attestations");
""")

# ------------------------------------------------------------------ dashboard-drill.js
D = W + 'wwwroot/js/Shared/dashboard-drill.js'
edit(D, """//     drillLabel      the words the banner shows
""", """//     tab             451: the tab of an asset screen holding the list
//     kind            451: a kind filter (reconciliation exception kind)
//     pending         451: 1 = only records awaiting approval
//     drillLabel      the words the banner shows
""")
edit(D, """  const DRILL_KEYS = ["drill", "statusText", "severity", "minAge", "maxAge", "noOwner", "drillLabel", "from",
                      "status", "overdue", "priority", "requestType"];
""", """  const DRILL_KEYS = ["drill", "statusText", "severity", "minAge", "maxAge", "noOwner", "drillLabel", "from",
                      "status", "overdue", "priority", "requestType", "tab", "kind", "pending"];   // 451: tab, kind, pending
""")
edit(D, """    d.requestType = q.get("requestType");   // null = not given; "" = all types
    d.active = !!(d.drill || d.statusText || d.severity || d.minAge !== null || d.maxAge !== null
                  || d.noOwner || d.label || d.status || d.overdue || d.priority);
""", """    d.requestType = q.get("requestType");   // null = not given; "" = all types
    d.tab     = q.get("tab") || "";           // 451
    d.kind    = q.get("kind") || "";          // 451
    d.pending = q.get("pending") === "1";     // 451
    d.active = !!(d.drill || d.statusText || d.severity || d.minAge !== null || d.maxAge !== null
                  || d.noOwner || d.label || d.status || d.overdue || d.priority || d.tab || d.kind || d.pending);
""")
edit(D, """  window.__pmDrill = { read, apiParams, appendTo, banner, preselect };
""", """  // 451: Asset & Contract screens (their lists filter in the page, not in
  // the API). Before the page loads its organization: the drill's
  // organization, then the page's own filter controls for the drill's tab
  // -- map = { TAB: { status | kind | pending: elementId } } ("" = no tab).
  function preselectFor(d, orgSelect, map) {
    if (!d) return;
    if (d.organizationId) preselect(orgSelect, d.organizationId);
    if (!d.active) return;
    const m = (map && (map[d.tab] || (!d.tab ? map[""] : null))) || {};
    Object.entries(m).forEach(([param, id]) => {
      const el = document.getElementById(id);
      if (!el) return;
      if (el.type === "checkbox") { if (param === "pending" && d.pending) el.checked = true; return; }
      preselect(el, d[param]);
    });
  }

  // 451: after the page loaded -- the banner above the page root and the
  // drill's tab (a button whose tabAttr equals d.tab), which reloads that
  // list with the preselected filter.
  function showOnPage(rootOrId, tabAttr, d) {
    const root = typeof rootOrId === "string" ? document.getElementById(rootOrId) : rootOrId;
    if (!root || !d || !d.active) return;
    let host = document.getElementById("pmDrillBanner");
    if (!host) {
      host = document.createElement("div");
      host.id = "pmDrillBanner";
      root.parentNode.insertBefore(host, root);
    }
    banner(host, d);
    if (tabAttr && d.tab) {
      const btn = [...document.querySelectorAll(`[${tabAttr}]`)].find(b => b.getAttribute(tabAttr) === d.tab);
      if (btn) btn.click();
    }
  }

  window.__pmDrill = { read, apiParams, appendTo, banner, preselect, preselectFor, showOnPage };
""")

# ------------------------------------------------------------------ asset screens
PAGES = [
    ('asset-register',      'argRoot', None,              '{ "": { status: "argStatusFilter", pending: "argPendingOnly" } }'),
    ('asset-contracts',     'acoRoot', 'data-aco-main',   '{ "": { status: "acoStatus" }, CONTRACTS: { status: "acoStatus" } }'),
    ('asset-attestation',   'aatRoot', 'data-aat-tab',    '{ ALL: { status: "aatStatus" }, EXCEPTIONS: { status: "aatExcStatus" } }'),
    ('asset-activities',    'aacRoot', 'data-aac-main',   '{ OCCURRENCES: { status: "aacOccStatus" }, REVIEWS: { status: "aacRevStatus" } }'),
    ('asset-privacy',       'apvRoot', 'data-apv-main',   '{ "": { status: "apvAStatus" }, ASSETS: { status: "apvAStatus" } }'),
    ('asset-discovery',     'adcRoot', 'data-adc-main',   '{ QUEUE: { kind: "adcQKind" }, CONFIDENCE: { status: "adcCStatus" } }'),
    ('business-services',   'bsvRoot', 'data-bsv-main',   '{ "": { status: "bsvFltStatus" }, SERVICES: { status: "bsvFltStatus" } }'),
    ('asset-relationships', 'arlRoot', 'data-arl-main',   '{ "": { status: "arlFltStatus" }, RELATIONSHIPS: { status: "arlFltStatus" } }'),
    ('asset-notifications', 'antRoot', 'data-ant-main',   '{ OCCURRENCES: { status: "antOccStatus" }, LOG: { status: "antLogStatus" } }'),
]
for page, root, attr, mp in PAGES:
    edit(W + f'Views/Practice/Partials/{page}.cshtml',
         f'<script src="~/js/AssetConfig/{page}.js" asp-append-version="true"></script>',
         f'<script src="~/js/Shared/dashboard-drill.js" asp-append-version="true"></script>   @* 451: Asset & Contract dashboard drill-down *@\n'
         f'<script src="~/js/AssetConfig/{page}.js" asp-append-version="true"></script>')
    show_attr = 'null' if attr is None else f'"{attr}"'
    edit(W + f'wwwroot/js/AssetConfig/{page}.js', """    await changeOrg(Number(sel.value) || null);
""", f"""    // 451: opened from the Asset & Contract dashboard -- organization, tab and filter (Shared/dashboard-drill.js).
    const dashDrill = window.__pmDrill ? window.__pmDrill.read() : null;
    window.__pmDrill?.preselectFor(dashDrill, sel, {mp});
    await changeOrg(Number(sel.value) || null);
    window.__pmDrill?.showOnPage("{root}", {show_attr}, dashDrill);
""")
print('451 patched')
