// =====================================================================
// OrgAssuranceQuestionModels
//
// Phase 2 Assurance Management -- Stage 2 Question Builder (BRD Part 2
// Sec 4). Kept in its own file to mirror TaskModels / WorkflowModels /
// CustomGapModels conventions.
// =====================================================================
namespace PracticeManagement.Api.Models;

// ---------- Admin-published question type ----------
public sealed record OrgAssuranceAdminQuestionTypeRow(
    long?   Id,
    string? Code,
    string? Name,
    string? Description);

// ---------- Question Set ----------
public sealed record OrgAssuranceQuestionSetListQuery(
    long    OrganizationId,
    string? Search   = null,
    int     Page     = 1,
    int     PageSize = 25);

public sealed record OrgAssuranceQuestionSetListRow(
    long      QuestionSetId,
    long      OrganizationId,
    string    SetCode,
    string    SetName,
    string?   Description,
    long?     OwnerEmployeeId,
    string?   OwnerDisplayName,
    string    Status,
    long      QuestionCount,
    DateTime? EnteredDt,
    DateTime? UpdatedDt);

public sealed record OrgAssuranceQuestionSetListResult(
    long TotalCount,
    int  PageNumber,
    int  PageSize,
    IReadOnlyList<OrgAssuranceQuestionSetListRow> Rows);

public sealed record OrgAssuranceQuestionSetDetail(
    long      QuestionSetId,
    long      OrganizationId,
    string    SetCode,
    string    SetName,
    string?   Description,
    long?     OwnerEmployeeId,
    string?   OwnerDisplayName,
    string    Status,
    string?   EnteredBy,
    DateTime? EnteredDt,
    string?   UpdatedBy,
    DateTime? UpdatedDt);

public sealed record OrgAssuranceQuestionSetSaveRequest(
    long    OrganizationId,
    long?   QuestionSetId,
    string  SetCode,
    string  SetName,
    string? Description,
    long?   OwnerEmployeeId,
    string? OwnerDisplayName,
    string? Status,
    string? Actor);

public sealed record OrgAssuranceQuestionSetSaveResult(
    bool    Success,
    long?   QuestionSetId = null,
    string? Error         = null,
    string? ReasonCode    = null);

// ---------- Question ----------
public sealed record OrgAssuranceQuestionRow(
    long      QuestionId,
    long      QuestionSetId,
    string    QuestionCode,
    string    QuestionText,
    string?   HelpText,
    long?     QuestionTypeId,
    string?   QuestionTypeCode,
    string?   QuestionTypeName,
    bool      IsMandatory,
    int       DisplayOrder,
    decimal?  Weight,
    string?   ExpectedResponse,
    string?   EnteredBy,
    DateTime? EnteredDt,
    string?   UpdatedBy,
    DateTime? UpdatedDt,
    // 516: the Repository question this set item was picked from.
    long?     RepositoryQuestionId = null,
    string?   CategoryName         = null,
    string?   SubcategoryName      = null);

public sealed record OrgAssuranceQuestionSaveRequest(
    long     OrganizationId,
    long     QuestionSetId,
    long?    QuestionId,
    string   QuestionCode,
    string   QuestionText,
    string?  HelpText,
    long?    QuestionTypeId,
    string?  QuestionTypeCode,
    string?  QuestionTypeName,
    bool?    IsMandatory,
    int?     DisplayOrder,
    decimal? Weight,
    string?  ExpectedResponse,
    string?  Actor);

public sealed record OrgAssuranceQuestionSaveResult(
    bool    Success,
    long?   QuestionId = null,
    string? Error      = null,
    string? ReasonCode = null);

public sealed record OrgAssuranceCommandResult(
    bool    Success,
    long?   Id         = null,
    string? Error      = null,
    string? ReasonCode = null);

// =====================================================================
// Question Repository (migration 516)
//   Organization-level library of audit questions, filed by Category /
//   Subcategory. Question Sets pick their questions from here.
// =====================================================================

// ---------- Category / Subcategory ----------
public sealed record OrgAssuranceQuestionCategoryRow(
    long   CategoryId,
    string CategoryName,
    int    DisplayOrder,
    long   QuestionCount);

public sealed record OrgAssuranceQuestionSubcategoryRow(
    long   SubcategoryId,
    long   CategoryId,
    string SubcategoryName,
    int    DisplayOrder,
    long   QuestionCount);

public sealed record OrgAssuranceQuestionCategoryTree(
    IReadOnlyList<OrgAssuranceQuestionCategoryRow>    Categories,
    IReadOnlyList<OrgAssuranceQuestionSubcategoryRow> Subcategories);

public sealed record OrgAssuranceQuestionCategorySaveRequest(
    long    OrganizationId,
    long?   CategoryId,
    string  CategoryName,
    int?    DisplayOrder,
    string? Actor);

public sealed record OrgAssuranceQuestionSubcategorySaveRequest(
    long    OrganizationId,
    long    CategoryId,
    long?   SubcategoryId,
    string  SubcategoryName,
    int?    DisplayOrder,
    string? Actor);

// ---------- Repository question ----------
public sealed record OrgAssuranceRepositoryQuestionListQuery(
    long    OrganizationId,
    string? Search,
    long?   CategoryId,
    long?   SubcategoryId,
    string? Status,
    long?   ExcludeSetId,
    int     Page,
    int     PageSize);

public sealed record OrgAssuranceRepositoryQuestionRow(
    long      RepositoryQuestionId,
    long      OrganizationId,
    string    QuestionCode,
    string    QuestionText,
    long      CategoryId,
    string    CategoryName,
    long?     SubcategoryId,
    string?   SubcategoryName,
    string?   Guidance,
    long?     QuestionTypeId,
    string?   QuestionTypeCode,
    string?   QuestionTypeName,
    bool      IsMandatory,
    bool      EvidenceRequired,
    string?   ExpectedEvidence,
    decimal?  Weight,
    string    Status,
    int       VersionNumber,
    long      UsedInSets,
    string?   EnteredBy,
    DateTime? EnteredDt,
    string?   UpdatedBy,
    DateTime? UpdatedDt);

public sealed record OrgAssuranceRepositoryQuestionListResult(
    long TotalCount,
    int  Page,
    int  PageSize,
    IReadOnlyList<OrgAssuranceRepositoryQuestionRow> Rows);

public sealed record OrgAssuranceRepositoryQuestionSaveRequest(
    long     OrganizationId,
    long?    RepositoryQuestionId,
    string   QuestionCode,
    string   QuestionText,
    long     CategoryId,
    long?    SubcategoryId,
    string?  Guidance,
    long?    QuestionTypeId,
    string?  QuestionTypeCode,
    string?  QuestionTypeName,
    bool?    IsMandatory,
    bool?    EvidenceRequired,
    string?  ExpectedEvidence,
    decimal? Weight,
    string?  Status,
    string?  Actor);

// ---------- Question Set <- Repository ----------
public sealed record OrgAssuranceSetAddFromRepositoryRequest(
    long                OrganizationId,
    IReadOnlyList<long> RepositoryQuestionIds,
    string?             Actor);
