
-- =====================================================================
-- 3. Helpers
-- =====================================================================
-- Consumers of a service with their names resolved.
CREATE OR ALTER FUNCTION grac_practice.fn_business_service_consumers (@service_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT c.consumer_id AS ConsumerId, c.consumer_kind AS ConsumerKind, c.consumer_ref_id AS ConsumerRefId,
           CAST(COALESCE(d.department_name, f.function_name, l.location_name, c.consumer_name) AS NVARCHAR(200)) AS ConsumerName,
           c.note AS Note
      FROM grac_practice.business_service_consumer c
      LEFT JOIN grac_practice.organization_department d ON c.consumer_kind = N'DEPARTMENT' AND d.department_id = c.consumer_ref_id
      LEFT JOIN grac_practice.organization_business_function f ON c.consumer_kind = N'BUSINESS_FUNCTION'
                                                              AND f.business_function_id = c.consumer_ref_id
      LEFT JOIN grac_practice.organization_location l ON c.consumer_kind = N'LOCATION' AND l.location_id = c.consumer_ref_id
     WHERE c.service_id = @service_id;
GO

-- "4 hours" -> 4; minutes, hours, days, weeks. Anything else -> NULL.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_duration_hours (@text NVARCHAR(400))
RETURNS DECIMAL(12, 2)
AS
BEGIN
    DECLARE @t NVARCHAR(400) = LTRIM(RTRIM(ISNULL(@text, N'')));
    DECLARE @n DECIMAL(18, 4) = TRY_CONVERT(DECIMAL(18, 4), LEFT(@t, CHARINDEX(N' ', @t + N' ') - 1));
    DECLARE @u NVARCHAR(100) = LOWER(LTRIM(SUBSTRING(@t, CHARINDEX(N' ', @t + N' ') + 1, 100)));
    RETURN CASE WHEN @n IS NULL OR @n < 0 THEN NULL
                WHEN @u LIKE N'min%' THEN CAST(@n / 60 AS DECIMAL(12, 2))
                WHEN @u LIKE N'h%' THEN CAST(@n AS DECIMAL(12, 2))
                WHEN @u LIKE N'day%' THEN CAST(@n * 24 AS DECIMAL(12, 2))
                WHEN @u LIKE N'week%' THEN CAST(@n * 168 AS DECIMAL(12, 2)) END;
END
GO

-- Validation warnings of the services of an organization (5.5.1, D93).
CREATE OR ALTER FUNCTION grac_practice.fn_business_service_conflicts (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    WITH svc AS (
        SELECT b.service_id, b.service_name, b.status, b.rto_hours, b.rpo_hours, b.business_owner_employee_id, b.review_date,
               cm.criticality_code,
               CASE cm.criticality_code WHEN N'Critical' THEN 4 WHEN N'High' THEN 3 WHEN N'Medium' THEN 2 WHEN N'Low' THEN 1 END AS crit_rank
          FROM grac_practice.business_service b
          LEFT JOIN grac_practice.criticality_master cm ON cm.criticality_id = b.criticality_id
         WHERE b.organization_id = @organization_id AND b.status <> N'RETIRED'),
    sup AS (
        SELECT r.relationship_id, r.target_id AS service_id, r.source_kind, r.source_id, r.status AS rel_status,
               ci.CiName, ci.IsUsable, scm.criticality_code AS sup_crit,
               CASE scm.criticality_code WHEN N'Critical' THEN 4 WHEN N'High' THEN 3 WHEN N'Medium' THEN 2 WHEN N'Low' THEN 1 END AS sup_rank,
               cs.rto_hours AS child_rto, cs.rpo_hours AS child_rpo, rp.rpo_h AS asset_rpo
          FROM grac_practice.asset_relationship r
          LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) ci ON ci.CiKind = r.source_kind AND ci.CiId = r.source_id
          LEFT JOIN grac_practice.organization_dependency_asset a ON r.source_kind = N'ASSET' AND a.asset_id = r.source_id
          LEFT JOIN grac_practice.organization_dependency_application ap ON r.source_kind = N'APPLICATION' AND ap.application_id = r.source_id
          LEFT JOIN grac_practice.organization_dependency_vendor v ON r.source_kind = N'VENDOR' AND v.vendor_id = r.source_id
          LEFT JOIN grac_practice.business_service cs ON r.source_kind = N'SERVICE' AND cs.service_id = r.source_id
          LEFT JOIN grac_practice.criticality_master scm
                 ON scm.criticality_id = COALESCE(a.criticality_id, ap.criticality_id, v.criticality_id, cs.criticality_id)
         OUTER APPLY (SELECT grac_practice.fn_asset_duration_hours(fv.value_text) AS rpo_h
                        FROM grac_practice.asset_field_value fv
                        JOIN grac_practice.asset_field_definition fd ON fd.field_definition_id = fv.field_definition_id AND fd.field_key = N'rpo'
                       WHERE r.source_kind = N'ASSET' AND fv.asset_id = r.source_id) rp
         WHERE r.organization_id = @organization_id AND r.relationship_type_code = N'SUPPORTS_SERVICE' AND r.target_kind = N'SERVICE'
           AND r.status IN (N'ACTIVE', N'DISPUTED')
           AND r.effective_from <= CAST(SYSUTCDATETIME() AS DATE)
           AND (r.effective_to IS NULL OR r.effective_to >= CAST(SYSUTCDATETIME() AS DATE)))
    SELECT s.service_id AS ServiceId, s.service_name AS ServiceName, N'SUPPORT_CRITICALITY' AS ConflictCode,
           CAST(CONCAT(p.CiName, N' is rated ', p.sup_crit, N'; the service is ', s.criticality_code, N'.') AS NVARCHAR(600)) AS Message,
           p.source_kind AS CiKind, p.source_id AS CiId, p.CiName, p.relationship_id AS RelationshipId
      FROM svc s JOIN sup p ON p.service_id = s.service_id
     WHERE p.rel_status = N'ACTIVE' AND s.crit_rank IS NOT NULL AND p.sup_rank IS NOT NULL AND p.sup_rank < s.crit_rank
    UNION ALL
    SELECT s.service_id, s.service_name, N'SUPPORT_RPO',
           CAST(CONCAT(p.CiName, N' has an RPO of ', p.asset_rpo, N' hour(s); the service RPO is ', s.rpo_hours, N'.') AS NVARCHAR(600)),
           p.source_kind, p.source_id, p.CiName, p.relationship_id
      FROM svc s JOIN sup p ON p.service_id = s.service_id
     WHERE p.rel_status = N'ACTIVE' AND s.rpo_hours IS NOT NULL AND p.asset_rpo IS NOT NULL AND p.asset_rpo > s.rpo_hours
    UNION ALL
    SELECT s.service_id, s.service_name, N'CHILD_OBJECTIVE',
           CAST(CONCAT(N'Supporting service ', p.CiName, N' allows RTO ', ISNULL(CAST(p.child_rto AS NVARCHAR(20)), N'-'), N' h / RPO ',
                       ISNULL(CAST(p.child_rpo AS NVARCHAR(20)), N'-'), N' h; this service needs RTO ',
                       ISNULL(CAST(s.rto_hours AS NVARCHAR(20)), N'-'), N' h / RPO ', ISNULL(CAST(s.rpo_hours AS NVARCHAR(20)), N'-'), N' h.')
                AS NVARCHAR(600)),
           p.source_kind, p.source_id, p.CiName, p.relationship_id
      FROM svc s JOIN sup p ON p.service_id = s.service_id
     WHERE p.rel_status = N'ACTIVE' AND p.source_kind = N'SERVICE'
       AND ((s.rto_hours IS NOT NULL AND p.child_rto > s.rto_hours) OR (s.rpo_hours IS NOT NULL AND p.child_rpo > s.rpo_hours))
    UNION ALL
    SELECT s.service_id, s.service_name, N'SUPPORT_NOT_IN_USE',
           CAST(CONCAT(p.CiName, N' still supports the service but is no longer in use.') AS NVARCHAR(600)),
           p.source_kind, p.source_id, p.CiName, p.relationship_id
      FROM svc s JOIN sup p ON p.service_id = s.service_id
     WHERE ISNULL(p.IsUsable, 0) = 0
    UNION ALL
    SELECT s.service_id, s.service_name, N'SUPPORT_DISPUTED',
           CAST(CONCAT(N'The mapping of ', p.CiName, N' is disputed.') AS NVARCHAR(600)),
           p.source_kind, p.source_id, p.CiName, p.relationship_id
      FROM svc s JOIN sup p ON p.service_id = s.service_id
     WHERE p.rel_status = N'DISPUTED'
    UNION ALL
    SELECT s.service_id, s.service_name, N'NO_OWNER', CAST(N'The service is in operation without a business owner.' AS NVARCHAR(600)),
           NULL, NULL, NULL, NULL
      FROM svc s
     WHERE s.status IN (N'ACTIVE', N'DEGRADED') AND s.business_owner_employee_id IS NULL
    UNION ALL
    SELECT s.service_id, s.service_name, N'NO_SUPPORT', CAST(N'The service is in operation with no active supporting item.' AS NVARCHAR(600)),
           NULL, NULL, NULL, NULL
      FROM svc s
     WHERE s.status IN (N'ACTIVE', N'DEGRADED')
       AND NOT EXISTS (SELECT 1 FROM sup p WHERE p.service_id = s.service_id AND p.rel_status = N'ACTIVE')
    UNION ALL
    SELECT s.service_id, s.service_name, N'REVIEW_OVERDUE',
           CAST(CONCAT(N'The service review was due on ', CONVERT(NVARCHAR(10), s.review_date, 23), N'.') AS NVARCHAR(600)),
           NULL, NULL, NULL, NULL
      FROM svc s
     WHERE s.review_date < CAST(SYSUTCDATETIME() AS DATE);
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_business_service_history_add
    @service_id        BIGINT,
    @action_code       NVARCHAR(20),
    @note              NVARCHAR(1000) = NULL,
    @actor             NVARCHAR(100),
    @actor_employee_id BIGINT         = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT grac_practice.business_service_history
        (service_id, organization_id, version_no, action_code, status, snapshot_json, note, actor, actor_employee_id)
    SELECT b.service_id, b.organization_id, b.version_no, @action_code, b.status,
           (SELECT b2.service_code AS serviceCode, b2.service_name AS serviceName, b2.service_type AS serviceType,
                   b2.description AS description, b2.customer_outcome AS customerOutcome,
                   b2.business_owner_employee_id AS businessOwnerEmployeeId, b2.service_manager_employee_id AS serviceManagerEmployeeId,
                   b2.accountable_department_id AS accountableDepartmentId, b2.criticality_id AS criticalityId,
                   b2.confidentiality_rating AS confidentialityRating, b2.integrity_rating AS integrityRating,
                   b2.availability_rating AS availabilityRating, b2.rto_hours AS rtoHours, b2.rpo_hours AS rpoHours,
                   b2.mtpd_hours AS mtpdHours, b2.service_hours AS serviceHours, b2.sla_text AS slaText,
                   b2.data_classification AS dataClassification, b2.privacy_classification AS privacyClassification,
                   b2.status AS status, b2.review_date AS reviewDate, b2.pending_retirement AS pendingRetirement,
                   (SELECT c.ConsumerKind AS consumerKind, c.ConsumerRefId AS consumerRefId, c.ConsumerName AS consumerName
                      FROM grac_practice.fn_business_service_consumers(b2.service_id) c FOR JSON PATH) AS consumers
              FROM grac_practice.business_service b2 WHERE b2.service_id = b.service_id
               FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           @note, @actor, @actor_employee_id
      FROM grac_practice.business_service b
     WHERE b.service_id = @service_id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    SELECT N'business-service', h.service_id, @action_code, NULL, h.snapshot_json, N'Active', @actor
      FROM grac_practice.business_service_history h
     WHERE h.history_id = SCOPE_IDENTITY();
END
GO
PRINT '441: helpers created.';
GO
