-- =====================================================================
-- 8. Restrictive-use reviews (9.1.9; D77-D78)
-- =====================================================================
-- Causes, recalculated on every pass from the schedules and the register:
--   FAILED   a failed result (schedule status Failed) of an activity whose
--            fail policy is on (Calibration by default)
--   OVERDUE  an overdue execution activity, EXPIRED an overdue renewal
--            (licence), on an asset whose severity (criticality) the
--            overdue policy names: ALL, NONE or a list (Calibration:
--            CRITICAL,HIGH; Equipment licence: ALL)
--   EXPIRED  an expired evidence date whose catalogue row restricts on
--            expiry (insurance, fitness, permit, registration)
-- One active (open or decided) review per asset, source and trigger; an
-- active review whose cause cleared is resolved, never deleted.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_restrictive_review_sync
    @organization_id BIGINT,
    @actor           NVARCHAR(100) = N'scheduler',
    @raised          INT           = NULL OUTPUT,
    @resolved        INT           = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'scheduler');
    SELECT @raised = 0, @resolved = 0;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    CREATE TABLE #cause (
        asset_id      BIGINT        NOT NULL,
        source_kind   NVARCHAR(10)  NOT NULL,
        source_code   NVARCHAR(100) NOT NULL,
        trigger_code  NVARCHAR(10)  NOT NULL,
        trigger_date  DATE          NOT NULL,
        title         NVARCHAR(400) NOT NULL,
        severity_code NVARCHAR(10)  NOT NULL,
        occurrence_id BIGINT        NULL,
        PRIMARY KEY (asset_id, source_kind, source_code, trigger_code)
    );

    -- Failed result.
    INSERT #cause (asset_id, source_kind, source_code, trigger_code, trigger_date, title, severity_code, occurrence_id)
    SELECT s.asset_id, N'ACTIVITY', s.template_code, N'FAILED', ISNULL(s.last_done_date, @today),
           LEFT(CONCAT(t.template_name, N' failed: ', a.asset_name), 400), N'CRITICAL', o.occurrence_id
      FROM grac_practice.asset_activity_schedule s
      JOIN grac_practice.asset_activity_template t ON t.template_code = s.template_code
      JOIN grac_practice.fn_asset_activity_settings(@organization_id) st ON st.TemplateCode = s.template_code
                                                                         AND st.IsActive = 1 AND st.RestrictOnFail = 1
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = s.asset_id
      LEFT JOIN grac_practice.asset_activity_occurrence o ON o.asset_id = s.asset_id AND o.template_code = s.template_code
                                                         AND o.status = N'OPEN'
     WHERE s.organization_id = @organization_id AND s.status_code = N'FAILED';

    -- Overdue execution / expired renewal for the severities the policy names.
    INSERT #cause (asset_id, source_kind, source_code, trigger_code, trigger_date, title, severity_code, occurrence_id)
    SELECT s.asset_id, N'ACTIVITY', s.template_code, CASE WHEN t.activity_kind = N'RENEWAL' THEN N'EXPIRED' ELSE N'OVERDUE' END,
           ISNULL(s.revised_due_date, s.next_due_date),
           LEFT(CONCAT(t.template_name, CASE WHEN t.activity_kind = N'RENEWAL' THEN N' expired: ' ELSE N' overdue: ' END, a.asset_name), 400),
           sv.severity_code, o.occurrence_id
      FROM grac_practice.asset_activity_schedule s
      JOIN grac_practice.asset_activity_template t ON t.template_code = s.template_code
      JOIN grac_practice.fn_asset_activity_settings(@organization_id) st ON st.TemplateCode = s.template_code AND st.IsActive = 1
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = s.asset_id
     CROSS APPLY (SELECT grac_practice.fn_asset_ntf_asset_severity(s.asset_id) AS severity_code) sv
      LEFT JOIN grac_practice.asset_activity_occurrence o ON o.asset_id = s.asset_id AND o.template_code = s.template_code
                                                         AND o.status = N'OPEN'
     WHERE s.organization_id = @organization_id AND s.status_code = N'OVERDUE' AND s.next_due_date IS NOT NULL
       AND st.RestrictOnOverdue <> N'NONE'
       AND (st.RestrictOnOverdue = N'ALL'
            OR CHARINDEX(N',' + sv.severity_code + N',', N',' + REPLACE(st.RestrictOnOverdue, N' ', N'') + N',') > 0);

    -- Expired evidence that restricts use (assets in use, as 431 D24).
    INSERT #cause (asset_id, source_kind, source_code, trigger_code, trigger_date, title, severity_code, occurrence_id)
    SELECT a.asset_id, N'EVIDENCE', ef.field_key, N'EXPIRED', v.value_date,
           LEFT(CONCAT(ef.evidence_name, N' expired: ', a.asset_name), 400),
           grac_practice.fn_asset_ntf_asset_severity(a.asset_id), NULL
      FROM grac_practice.organization_dependency_asset a
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
      JOIN grac_practice.asset_field_value v ON v.asset_id = a.asset_id AND v.value_date IS NOT NULL
      JOIN grac_practice.asset_field_definition fd ON fd.field_definition_id = v.field_definition_id
      JOIN grac_practice.asset_evidence_field ef ON ef.field_key = fd.field_key AND ef.is_active = 1 AND ef.restrict_on_expiry = 1
     WHERE a.organization_id = @organization_id AND v.value_date < @today
       AND ISNULL(s.status_code, N'ACTIVE') NOT IN (N'DRAFT', N'REQUESTED', N'APPROVED', N'ORDERED', N'LOST', N'STOLEN',
                                                     N'DISPOSED', N'ARCHIVED');

    DECLARE @chg TABLE (review_id BIGINT NOT NULL, action_type NVARCHAR(20) NOT NULL);
    BEGIN TRAN;
    UPDATE r
       SET status = N'RESOLVED', resolved_dt = SYSUTCDATETIME(),
           resolved_reason = N'The cause cleared (result approved, rescheduled, renewed, covered, or the asset left use).',
           updated_by = @actor, updated_dt = SYSUTCDATETIME()
    OUTPUT inserted.review_id, N'RESOLVE' INTO @chg (review_id, action_type)
      FROM grac_practice.asset_restrictive_review r
     WHERE r.organization_id = @organization_id AND r.status IN (N'OPEN', N'DECIDED')
       AND NOT EXISTS (SELECT 1 FROM #cause c
                        WHERE c.asset_id = r.asset_id AND c.source_kind = r.source_kind AND c.source_code = r.source_code
                          AND c.trigger_code = r.trigger_code);
    SET @resolved = @@ROWCOUNT;

    INSERT grac_practice.asset_restrictive_review
        (organization_id, asset_id, source_kind, source_code, trigger_code, trigger_date, review_key, title, severity_code,
         occurrence_id, status, entered_by)
    OUTPUT inserted.review_id, N'CREATE' INTO @chg (review_id, action_type)
    SELECT @organization_id, c.asset_id, c.source_kind, c.source_code, c.trigger_code, c.trigger_date, k.review_key, c.title,
           c.severity_code, c.occurrence_id, N'OPEN', @actor
      FROM #cause c
     CROSS APPLY (SELECT CONCAT(c.source_kind, N':', c.source_code, N':', c.trigger_code, N':', c.asset_id, N':',
                                CONVERT(NVARCHAR(8), c.trigger_date, 112)) AS review_key) k
     WHERE NOT EXISTS (SELECT 1 FROM grac_practice.asset_restrictive_review r
                        WHERE r.asset_id = c.asset_id AND r.source_kind = c.source_kind AND r.source_code = c.source_code
                          AND r.trigger_code = c.trigger_code AND r.status IN (N'OPEN', N'DECIDED'))
       AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_restrictive_review r
                        WHERE r.organization_id = @organization_id AND r.review_key = k.review_key);
    SET @raised = @@ROWCOUNT;

    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    SELECT N'asset-restrictive-review', x.review_id, x.action_type, NULL,
           (SELECT r.review_key AS reviewKey, r.status AS status, r.title AS title FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           N'Active', @actor
      FROM @chg x JOIN grac_practice.asset_restrictive_review r ON r.review_id = x.review_id;
    COMMIT;
END
GO
PRINT '439: sp_asset_restrictive_review_sync created.';
GO
