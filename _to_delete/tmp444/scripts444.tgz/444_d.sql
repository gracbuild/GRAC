
-- =====================================================================
-- 6. Recovery (19.4 "restorative event where technically possible";
--    D121). Newest outcome first; a row is restored only when the object is
--    still as the merge left it, otherwise its recovery note says why.
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_merge_recover
    @organization_id   BIGINT,
    @event_id          BIGINT,
    @note              NVARCHAR(1000),
    @actor_employee_id BIGINT        = NULL,
    @actor             NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @row BIGINT, @kind NVARCHAR(20), @oid BIGINT, @okey NVARCHAR(200), @from_asset BIGINT, @to_asset BIGINT, @outcome NVARCHAR(12),
            @before NVARCHAR(MAX), @after NVARCHAR(MAX), @done BIT, @why NVARCHAR(400);
    DECLARE @msg NVARCHAR(400) = CONCAT(N'Merge #', @event_id, N' recovered: ', LEFT(@note, 300));
    DECLARE @prev NVARCHAR(60), @to_id INT, @log BIGINT, @rtext NVARCHAR(1000) = CONCAT(N'Merge #', @event_id, N' recovered.'),
            @bs BIGINT, @bt BIGINT;
    DECLARE obj_cur CURSOR LOCAL STATIC FOR
        SELECT object_row_id, object_kind, object_id, object_key, from_asset_id, to_asset_id, outcome, before_value, after_value
          FROM grac_practice.asset_merge_split_object
         WHERE event_id = @event_id AND recovered = 0
         ORDER BY object_row_id DESC;
    OPEN obj_cur;
    FETCH NEXT FROM obj_cur INTO @row, @kind, @oid, @okey, @from_asset, @to_asset, @outcome, @before, @after;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SELECT @done = 0, @why = NULL;
        IF @outcome = N'KEPT'
        BEGIN
            SET @done = 1;
        END
        ELSE IF @kind = N'ASSET_RECORD'
        BEGIN
            SET @prev = JSON_VALUE(@before, '$.statusCode');
            IF EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset a
                         JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
                        WHERE a.asset_id = @oid AND s.status_code = N'ARCHIVED' AND a.merged_into_asset_id = @to_asset)
               AND @prev IS NOT NULL
            BEGIN
                EXEC grac_practice.sp_pm_state_transition
                     @entity_type = N'Asset', @entity_id = @oid, @from_status_code = N'ARCHIVED', @to_status_code = @prev,
                     @actor_employee_id = @actor_employee_id, @actor_role_code = N'ASSET_MERGE', @reason_code = N'MERGE_RECOVERED',
                     @reason_text = @rtext, @to_status_id = @to_id OUTPUT, @transition_log_id = @log OUTPUT;
                UPDATE grac_practice.organization_dependency_asset
                   SET current_status_id = @to_id, status = ISNULL(JSON_VALUE(@before, '$.status'), N'Active'),
                       record_status_id = ISNULL(TRY_CONVERT(INT, JSON_VALUE(@before, '$.recordStatusId')), record_status_id),
                       lifecycle_status = JSON_VALUE(@before, '$.lifecycleStatus'),
                       merged_into_asset_id = NULL, updated_by = @actor, updated_dt = SYSUTCDATETIME()
                 WHERE asset_id = @oid;
                SET @done = 1;
            END
            ELSE BEGIN SET @why = N'The merged record is no longer archived into the survivor.'; END
        END
        ELSE IF @kind = N'ALIAS'
        BEGIN
            UPDATE grac_practice.asset_alias SET is_active = 0 WHERE alias_id = @oid;
            SET @done = 1;
        END
        ELSE IF @kind = N'FIELD'
        BEGIN
            IF EXISTS (SELECT 1 FROM grac_practice.asset_field_value WHERE asset_id = @to_asset AND field_definition_id = @oid AND value_text = @after)
            BEGIN
                IF @before IS NULL
                BEGIN
                    DELETE FROM grac_practice.asset_field_value WHERE asset_id = @to_asset AND field_definition_id = @oid;
                END
                ELSE
                    UPDATE v
                       SET value_text = @before,
                           value_number = TRY_CONVERT(DECIMAL(38, 6), CASE WHEN f.data_type_code = N'QUANTITY_UNIT'
                                                                         THEN LEFT(@before, CHARINDEX(N' ', @before + N' ') - 1) ELSE @before END),
                           value_date = CASE WHEN f.data_type_code = N'DATE' THEN TRY_CONVERT(DATE, @before, 23) END,
                           value_ref = CASE WHEN f.lookup_source LIKE N'MASTER:%' AND f.data_type_code NOT IN (N'MULTI_SELECT', N'MULTI_USER')
                                            THEN TRY_CONVERT(BIGINT, @before) END,
                           updated_by = @actor, updated_dt = SYSUTCDATETIME()
                      FROM grac_practice.asset_field_value v
                      JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id
                     WHERE v.asset_id = @to_asset AND v.field_definition_id = @oid;
                SET @done = 1;
            END
            ELSE BEGIN SET @why = N'The survivor value was changed after the merge.'; END
        END
        ELSE IF @kind = N'RELATIONSHIP' AND @outcome = N'MOVED'
        BEGIN
            SELECT @bs = TRY_CONVERT(BIGINT, JSON_VALUE(@before, '$.sourceId')), @bt = TRY_CONVERT(BIGINT, JSON_VALUE(@before, '$.targetId'));
            IF EXISTS (SELECT 1 FROM grac_practice.asset_relationship r
                        WHERE r.relationship_id = @oid AND r.source_id = TRY_CONVERT(BIGINT, JSON_VALUE(@after, '$.sourceId'))
                          AND r.target_id = TRY_CONVERT(BIGINT, JSON_VALUE(@after, '$.targetId')))
               AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_relationship r
                                 JOIN grac_practice.asset_relationship q ON q.organization_id = r.organization_id
                                  AND q.relationship_type_code = r.relationship_type_code AND q.relationship_id <> r.relationship_id
                                  AND q.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')
                                  AND q.source_kind = r.source_kind AND q.source_id = @bs AND q.target_kind = r.target_kind AND q.target_id = @bt
                                WHERE r.relationship_id = @oid AND r.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED'))
            BEGIN
                UPDATE grac_practice.asset_relationship
                   SET source_id = @bs, target_id = @bt, version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()
                 WHERE relationship_id = @oid;
                EXEC grac_practice.sp_asset_relationship_history_add @relationship_id = @oid, @action_code = N'MERGE_RECOVER', @note = @msg,
                     @actor = @actor, @actor_employee_id = @actor_employee_id;
                SET @done = 1;
            END
            ELSE BEGIN SET @why = N'The relationship changed after the merge, or restoring it would duplicate a current one.'; END
        END
        ELSE IF @kind = N'RELATIONSHIP' AND @outcome = N'ENDED'
        BEGIN
            IF EXISTS (SELECT 1 FROM grac_practice.asset_relationship WHERE relationship_id = @oid AND status = N'RETIRED')
               AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_relationship r
                                 JOIN grac_practice.asset_relationship q ON q.organization_id = r.organization_id
                                  AND q.relationship_type_code = r.relationship_type_code AND q.relationship_id <> r.relationship_id
                                  AND q.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')
                                  AND q.source_kind = r.source_kind AND q.source_id = r.source_id AND q.target_kind = r.target_kind
                                  AND q.target_id = r.target_id
                                WHERE r.relationship_id = @oid)
            BEGIN
                UPDATE grac_practice.asset_relationship
                   SET status = JSON_VALUE(@before, '$.status'), effective_to = TRY_CONVERT(DATE, JSON_VALUE(@before, '$.effectiveTo')),
                       status_note = @msg, version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()
                 WHERE relationship_id = @oid;
                EXEC grac_practice.sp_asset_relationship_history_add @relationship_id = @oid, @action_code = N'MERGE_RECOVER', @note = @msg,
                     @actor = @actor, @actor_employee_id = @actor_employee_id;
                SET @done = 1;
            END
            ELSE BEGIN SET @why = N'The relationship is no longer retired, or restoring it would duplicate a current one.'; END
        END
        ELSE IF @kind = N'DISCOVERY_LINK'
        BEGIN
            UPDATE grac_practice.asset_discovery_link SET asset_id = @from_asset WHERE link_id = @oid AND asset_id = @to_asset;
            IF @@ROWCOUNT = 1 BEGIN SET @done = 1; END ELSE BEGIN SET @why = N'The source record is linked elsewhere now.'; END
        END
        ELSE IF @kind = N'ATTRIBUTE_SOURCE'
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_attribute_source WHERE asset_id = @from_asset AND field_key = @okey AND source_id = @oid)
            BEGIN
                UPDATE grac_practice.asset_attribute_source SET asset_id = @from_asset
                 WHERE asset_id = @to_asset AND field_key = @okey AND source_id = @oid;
                IF @@ROWCOUNT = 1 BEGIN SET @done = 1; END ELSE BEGIN SET @why = N'The value is no longer on the survivor.'; END
            END
            ELSE BEGIN SET @why = N'The merged record already holds a value from this source.'; END
        END
        ELSE IF @kind = N'RECON_EXCEPTION' AND @outcome = N'RESOLVED'
        BEGIN
            UPDATE grac_practice.asset_reconciliation_exception
               SET status = N'OPEN', resolution = NULL, resolution_note = NULL, resolved_by = NULL, resolved_dt = NULL, updated_dt = SYSUTCDATETIME()
             WHERE exception_id = @oid AND status = N'RESOLVED' AND resolution = N'MERGED';
            IF @@ROWCOUNT = 1 BEGIN SET @done = 1; END ELSE BEGIN SET @why = N'The exception was handled again after the merge.'; END
        END
        ELSE IF @kind = N'RECON_EXCEPTION'
        BEGIN
            UPDATE grac_practice.asset_reconciliation_exception
               SET asset_id = TRY_CONVERT(BIGINT, JSON_VALUE(@before, '$.assetId')),
                   other_asset_id = TRY_CONVERT(BIGINT, JSON_VALUE(@before, '$.otherAssetId')), updated_dt = SYSUTCDATETIME()
             WHERE exception_id = @oid AND status = N'OPEN' AND (asset_id = @to_asset OR other_asset_id = @to_asset);
            IF @@ROWCOUNT = 1 BEGIN SET @done = 1; END ELSE BEGIN SET @why = N'The exception was resolved or changed after the merge.'; END
        END
        ELSE IF @kind = N'COVERAGE'
        BEGIN
            UPDATE c SET asset_id = @from_asset
              FROM grac_practice.asset_contract_coverage c
             WHERE c.coverage_id = @oid AND c.asset_id = @to_asset
               AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_contract_coverage c2
                                WHERE c2.version_id = c.version_id AND c2.asset_id = @from_asset AND c2.coverage_type = c.coverage_type);
            IF @@ROWCOUNT = 1 BEGIN SET @done = 1; END ELSE BEGIN SET @why = N'The coverage line changed after the merge.'; END
        END
        ELSE IF @kind = N'OCCURRENCE'
        BEGIN
            UPDATE o SET asset_id = @from_asset, updated_by = @actor, updated_dt = SYSUTCDATETIME()
              FROM grac_practice.asset_activity_occurrence o
             WHERE o.occurrence_id = @oid AND o.asset_id = @to_asset
               AND (o.status <> N'OPEN' OR NOT EXISTS (SELECT 1 FROM grac_practice.asset_activity_occurrence o2
                                                        WHERE o2.asset_id = @from_asset AND o2.template_code = o.template_code AND o2.status = N'OPEN'));
            IF @@ROWCOUNT = 1 BEGIN SET @done = 1; END ELSE BEGIN SET @why = N'The activity changed after the merge.'; END
        END
        ELSE IF @kind = N'RESTRICTIVE_REVIEW'
        BEGIN
            UPDATE r SET asset_id = @from_asset
              FROM grac_practice.asset_restrictive_review r
             WHERE r.review_id = @oid AND r.asset_id = @to_asset
               AND (r.status NOT IN (N'OPEN', N'DECIDED') OR NOT EXISTS (
                        SELECT 1 FROM grac_practice.asset_restrictive_review r2
                         WHERE r2.asset_id = @from_asset AND r2.status IN (N'OPEN', N'DECIDED') AND r2.source_kind = r.source_kind
                           AND r2.source_code = r.source_code AND r2.trigger_code = r.trigger_code));
            IF @@ROWCOUNT = 1 BEGIN SET @done = 1; END ELSE BEGIN SET @why = N'The review changed after the merge.'; END
        END
        ELSE IF @kind = N'RISK_MAP'
        BEGIN
            UPDATE m SET dependency_object_id = @from_asset, dependency_object_name = @before, updated_by = @actor, updated_dt = SYSUTCDATETIME()
              FROM grac_practice.risk_dependency_map m
             WHERE m.risk_dependency_map_id = @oid AND m.dependency_object_id = @to_asset
               AND NOT EXISTS (SELECT 1 FROM grac_practice.risk_dependency_map m2
                                WHERE m2.risk_register_id = m.risk_register_id AND m2.dependency_type_id = m.dependency_type_id
                                  AND m2.dependency_object_id = @from_asset);
            IF @@ROWCOUNT = 1 BEGIN SET @done = 1; END ELSE BEGIN SET @why = N'The risk mapping changed after the merge.'; END
        END
        ELSE IF @kind = N'RISK_LINK'
        BEGIN
            UPDATE grac_practice.risk_register SET linked_asset_id = @from_asset WHERE risk_register_id = @oid AND linked_asset_id = @to_asset;
            IF @@ROWCOUNT = 1 BEGIN SET @done = 1; END ELSE BEGIN SET @why = N'The risk was linked elsewhere after the merge.'; END
        END
        ELSE IF @kind = N'PRACTICE_RESOLUTION'
        BEGIN
            UPDATE d SET resolved_dependency_id = @from_asset, resolved_dependency_name = ISNULL(@before, d.resolved_dependency_name),
                         updated_by = @actor, updated_dt = SYSUTCDATETIME()
              FROM grac_practice.practice_dependency_resolution d
             WHERE d.resolution_id = @oid AND d.resolved_dependency_id = @to_asset
               AND NOT EXISTS (SELECT 1 FROM grac_practice.practice_dependency_resolution d2
                                WHERE d2.organization_id = d.organization_id AND d2.practice_instance_id = d.practice_instance_id
                                  AND d2.dependency_type_id = d.dependency_type_id AND d2.resolved_dependency_id = @from_asset);
            IF @@ROWCOUNT = 1 BEGIN SET @done = 1; END ELSE BEGIN SET @why = N'The practice resolution changed after the merge.'; END
        END
        UPDATE grac_practice.asset_merge_split_object SET recovered = @done, recovery_note = @why WHERE object_row_id = @row;
        FETCH NEXT FROM obj_cur INTO @row, @kind, @oid, @okey, @from_asset, @to_asset, @outcome, @before, @after;
    END
    CLOSE obj_cur;
    DEALLOCATE obj_cur;
END
GO

-- =====================================================================
-- 7. Merge actions (D115, D120)
--   SUBMIT   Draft -> Pending approval (reason, no blockers; plan counts kept)
--   CANCEL   Draft / Pending approval / Approved -> Cancelled (note)
--   APPROVE  Pending approval: another person than the requester; a critical
--            merge needs two different approvers -> Approved
--   REJECT   Pending approval -> Rejected (note; not the requester)
--   EXECUTE  Approved -> Executed (blockers checked again; per duplicate)
--   RECOVER  Executed -> Recovered (note)
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_merge_action
    @organization_id         BIGINT,
    @event_id                BIGINT,
    @action                  NVARCHAR(10),
    @note                    NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @action = UPPER(LTRIM(RTRIM(ISNULL(@action, N''))));
    SET @note = NULLIF(LTRIM(RTRIM(@note)), N'');
    DECLARE @found BIT = 0, @status NVARCHAR(20), @rv BIGINT, @survivor BIGINT, @reason NVARCHAR(1000), @choices NVARCHAR(MAX),
            @requested_by NVARCHAR(100), @requested_emp BIGINT, @required INT;
    SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version), @survivor = survivor_asset_id, @reason = reason,
           @choices = field_choices_json, @requested_by = requested_by, @requested_emp = requested_by_employee_id,
           @required = approvals_required
      FROM grac_practice.asset_merge_split_event
     WHERE event_id = @event_id AND organization_id = @organization_id AND event_kind = N'MERGE';
    IF @found = 0 THROW 52902, 'Merge not found for this organization.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 52903, 'The merge was changed by someone else; reload it and try again.', 1;
    IF @action NOT IN (N'SUBMIT', N'CANCEL', N'APPROVE', N'REJECT', N'EXECUTE', N'RECOVER')
        THROW 52911, 'That action is not available for a merge.', 1;
    IF NOT ((@action = N'SUBMIT' AND @status = N'DRAFT')
         OR (@action = N'CANCEL' AND @status IN (N'DRAFT', N'PENDING_APPROVAL', N'APPROVED'))
         OR (@action IN (N'APPROVE', N'REJECT') AND @status = N'PENDING_APPROVAL')
         OR (@action = N'EXECUTE' AND @status = N'APPROVED')
         OR (@action = N'RECOVER' AND @status = N'EXECUTED'))
        THROW 52907, 'The merge status does not allow this action.', 1;
    IF @action IN (N'CANCEL', N'REJECT', N'RECOVER') AND @note IS NULL
        THROW 52910, 'Record the reason in the note.', 1;
    IF @action IN (N'APPROVE', N'REJECT')
       AND ((@actor_employee_id IS NOT NULL AND @actor_employee_id = @requested_emp) OR @actor = @requested_by)
        THROW 52909, 'The requester cannot approve or reject the merge; another person decides.', 1;
    IF @action = N'APPROVE'
       AND EXISTS (SELECT 1 FROM grac_practice.asset_merge_split_approval
                    WHERE event_id = @event_id AND decision = N'APPROVE'
                      AND ((@actor_employee_id IS NOT NULL AND approver_employee_id = @actor_employee_id) OR approver = @actor))
        THROW 52909, 'You already approved this merge; a critical merge needs a second, different approver.', 1;
    IF @action IN (N'SUBMIT', N'EXECUTE')
    BEGIN
        IF @action = N'SUBMIT' AND @reason IS NULL THROW 52906, 'Record the reason for the merge first.', 1;
        DECLARE @blk NVARCHAR(1500) = (
            SELECT LEFT(STRING_AGG(CAST(CONCAT(a.asset_name, N': ', b.Detail) AS NVARCHAR(MAX)), N' | '), 1400)
              FROM grac_practice.asset_merge_split_member m
              JOIN grac_practice.organization_dependency_asset a ON a.asset_id = m.asset_id
             CROSS APPLY grac_practice.fn_asset_merge_blockers(@organization_id, @survivor, m.asset_id) b
             WHERE m.event_id = @event_id);
        IF @blk IS NOT NULL
        BEGIN
            DECLARE @blk_msg NVARCHAR(1600) = CONCAT(N'Resolve these first: ', @blk);
            THROW 52908, @blk_msg, 1;
        END
    END

    DECLARE @result NVARCHAR(20) = @status, @approvals INT;
    BEGIN TRAN;
    IF @action = N'SUBMIT'
    BEGIN
        UPDATE e
           SET status = N'PENDING_APPROVAL', submitted_dt = SYSUTCDATETIME(), is_critical = c.IsCritical,
               approvals_required = CASE WHEN c.IsCritical = 1 THEN 2 ELSE 1 END,
               preview_json = (SELECT p.ObjectKind AS kind, p.Outcome AS outcome, COUNT(*) AS items
                                 FROM grac_practice.asset_merge_split_member m
                                CROSS APPLY grac_practice.fn_asset_merge_plan(@organization_id, @survivor, m.asset_id) p
                                WHERE m.event_id = @event_id
                                GROUP BY p.ObjectKind, p.Outcome FOR JSON PATH)
          FROM grac_practice.asset_merge_split_event e
         CROSS APPLY grac_practice.fn_asset_merge_critical(@organization_id, @event_id) c
         WHERE e.event_id = @event_id;
        SET @result = N'PENDING_APPROVAL';
    END
    ELSE IF @action = N'CANCEL'
    BEGIN
        UPDATE grac_practice.asset_merge_split_event SET status = N'CANCELLED', decided_note = @note, closed_dt = SYSUTCDATETIME()
         WHERE event_id = @event_id;
        SET @result = N'CANCELLED';
    END
    ELSE IF @action IN (N'APPROVE', N'REJECT')
    BEGIN
        INSERT grac_practice.asset_merge_split_approval (event_id, decision, note, approver, approver_employee_id)
        VALUES (@event_id, @action, @note, @actor, @actor_employee_id);
        SET @approvals = (SELECT COUNT(*) FROM grac_practice.asset_merge_split_approval WHERE event_id = @event_id AND decision = N'APPROVE');
        IF @action = N'REJECT'
        BEGIN
            UPDATE grac_practice.asset_merge_split_event SET status = N'REJECTED', decided_note = @note, closed_dt = SYSUTCDATETIME()
             WHERE event_id = @event_id;
            SET @result = N'REJECTED';
        END
        ELSE IF @approvals >= @required
        BEGIN
            UPDATE grac_practice.asset_merge_split_event SET status = N'APPROVED' WHERE event_id = @event_id;
            SET @result = N'APPROVED';
        END
        ELSE
            SET @result = N'FIRST_APPROVAL';
    END
    ELSE IF @action = N'EXECUTE'
    BEGIN
        DECLARE @dup BIGINT;
        DECLARE dup_cur CURSOR LOCAL STATIC FOR
            SELECT asset_id FROM grac_practice.asset_merge_split_member WHERE event_id = @event_id ORDER BY sequence_no;
        OPEN dup_cur;
        FETCH NEXT FROM dup_cur INTO @dup;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            EXEC grac_practice.sp_asset_merge_execute_one
                 @organization_id = @organization_id, @event_id = @event_id, @survivor = @survivor, @duplicate = @dup,
                 @field_choices_json = @choices, @actor_employee_id = @actor_employee_id, @actor = @actor;
            FETCH NEXT FROM dup_cur INTO @dup;
        END
        CLOSE dup_cur;
        DEALLOCATE dup_cur;
        UPDATE grac_practice.asset_merge_split_event
           SET status = N'EXECUTED', executed_by = @actor, executed_dt = SYSUTCDATETIME(), closed_dt = SYSUTCDATETIME()
         WHERE event_id = @event_id;
        SET @result = N'EXECUTED';
    END
    ELSE
    BEGIN
        EXEC grac_practice.sp_asset_merge_recover
             @organization_id = @organization_id, @event_id = @event_id, @note = @note,
             @actor_employee_id = @actor_employee_id, @actor = @actor;
        UPDATE grac_practice.asset_merge_split_event
           SET status = N'RECOVERED', recovered_by = @actor, recovered_dt = SYSUTCDATETIME(), recovery_reason = @note
         WHERE event_id = @event_id;
        SET @result = N'RECOVERED';
    END
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-merge', @event_id, @action, (SELECT @status AS status FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            (SELECT @result AS result, @note AS note,
                    (SELECT COUNT(*) FROM grac_practice.asset_merge_split_object WHERE event_id = @event_id) AS outcomes,
                    (SELECT COUNT(*) FROM grac_practice.asset_merge_split_object WHERE event_id = @event_id AND recovered = 1) AS recovered
                FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @event_id AS EventId, @result AS Result;
END
GO
PRINT '444: merge recovery and actions created.';
GO
