# Re-issue of sp_asset_scheduler_run from its 448 body: one governance
# snapshot per organization per day after the notification sweep.
src = open('db/sched448.sql').read()
def ins_after(s, anchor, add):
    assert s.count(anchor) == 1, anchor[:60]; return s.replace(anchor, anchor + add)
def ins_before(s, anchor, add):
    assert s.count(anchor) == 1, anchor[:60]; return s.replace(anchor, add + anchor)
s = ins_after(src, """    DECLARE @po INT, @pc INT, @px INT;                                                     -- 448
""", """    DECLARE @gs BIGINT, @gc BIT;                                                           -- 450
""")
s = ins_before(s, """        FETCH NEXT FROM org_cur INTO @org;
    END
    CLOSE org_cur;""", """        -- 450: one governance KPI snapshot per organization per day (19.8), after the sweep.
        IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_governance_snapshot                -- 450
                        WHERE organization_id = @org AND as_of_date = @today)               -- 450
        BEGIN                                                                              -- 450
        BEGIN TRY                                                                          -- 450
            EXEC grac_practice.sp_asset_governance_snapshot_take @organization_id = @org, @source_code = N'SCHEDULER',   -- 450
                 @actor = @actor, @suppress_result = 1, @out_snapshot_id = @gs OUTPUT, @out_created = @gc OUTPUT;   -- 450
        END TRY                                                                            -- 450
        BEGIN CATCH                                                                        -- 450
            IF XACT_STATE() <> 0 ROLLBACK;                                                 -- 450
            SET @errors = @errors + 1;                                                     -- 450
            SET @err = LEFT(CONCAT(@err, CASE WHEN @err IS NULL THEN N'' ELSE CHAR(10) END,   -- 450
                                   N'Organization ', @org, N' (governance snapshot): ', ERROR_MESSAGE()), 8000);   -- 450
        END CATCH                                                                          -- 450
        END                                                                                -- 450

""")
open('part_sc.sql','w').write(src)
open('part_sc2.sql','w').write(s)
print(len(src.splitlines()), len(s.splitlines()))
