
-- =====================================================================
-- 3. Split plan and blockers (D127-D129)
-- =====================================================================
-- Every object of the source (the 444 merge plan read for the source), its
-- allocation and what moving it to that resulting record does now:
--   MOVE   it moves
--   BLOCK  the result already has the equivalent open item (activity /
--          restrictive review) -- finish one first
--   STAY   not allocated, or the result already holds the equivalent (or the
--          relationship would join the result to itself) -- it stays with
--          the source
-- plus the source field values (user-entered) with MOVE / COPY / STAY.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_split_plan (@organization_id BIGINT, @event_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT o.ObjectKind, o.ObjectId, o.ObjectKey, o.ObjectLabel, o.Domain, o.Detail,
           al.target_asset_id AS TargetAssetId, CAST(NULL AS NVARCHAR(4)) AS FieldMode,
           CAST(CASE WHEN al.target_asset_id IS NULL THEN N'STAY' WHEN tp.Outcome = N'MOVE' THEN N'MOVE'
                     WHEN tp.Outcome = N'BLOCK' THEN N'BLOCK' ELSE N'STAY' END AS NVARCHAR(10)) AS Outcome,
           CAST(CASE WHEN al.target_asset_id IS NULL OR tp.Outcome IN (N'MOVE', N'BLOCK') THEN NULL
                     WHEN tp.Outcome IS NULL THEN N'No longer on the source.'
                     ELSE N'The resulting record already holds the equivalent (or it would refer to itself).' END AS NVARCHAR(200)) AS OutcomeNote
      FROM grac_practice.asset_merge_split_event ev
     CROSS APPLY grac_practice.fn_asset_merge_plan(ev.organization_id, -1, ev.survivor_asset_id) o
      LEFT JOIN grac_practice.asset_split_allocation al
        ON al.event_id = ev.event_id AND al.object_kind = o.ObjectKind
       AND ISNULL(al.object_id, -1) = ISNULL(o.ObjectId, -1) AND ISNULL(al.object_key, N'') = ISNULL(o.ObjectKey, N'')
     OUTER APPLY (SELECT TOP 1 t.Outcome
                    FROM grac_practice.fn_asset_merge_plan(ev.organization_id, al.target_asset_id, ev.survivor_asset_id) t
                   WHERE al.target_asset_id IS NOT NULL AND t.ObjectKind = o.ObjectKind
                     AND ISNULL(t.ObjectId, -1) = ISNULL(o.ObjectId, -1) AND ISNULL(t.ObjectKey, N'') = ISNULL(o.ObjectKey, N'')) tp
     WHERE ev.event_id = @event_id AND ev.organization_id = @organization_id AND ev.event_kind = N'SPLIT'
    UNION ALL
    SELECT N'FIELD', CAST(f.field_definition_id AS BIGINT), f.field_key, CAST(f.display_label AS NVARCHAR(400)), CAST(N'Field values' AS NVARCHAR(40)),
           CAST(LEFT(v.value_text, 400) AS NVARCHAR(600)), al.target_asset_id, al.field_mode,
           CAST(CASE WHEN al.target_asset_id IS NULL THEN N'STAY' ELSE al.field_mode END AS NVARCHAR(10)),
           CAST(CASE WHEN tv.value_text IS NOT NULL AND al.target_asset_id IS NOT NULL THEN CONCAT(N'Replaces "', LEFT(tv.value_text, 150), N'".') END
                AS NVARCHAR(200))
      FROM grac_practice.asset_merge_split_event ev
      JOIN grac_practice.asset_field_value v ON v.asset_id = ev.survivor_asset_id
      JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id AND f.storage_kind = N'VALUE'
                                                 AND f.is_system_field = 0
      JOIN grac_practice.asset_field_data_type_master dt ON dt.data_type_code = f.data_type_code AND dt.is_user_entered = 1
      LEFT JOIN grac_practice.asset_split_allocation al
        ON al.event_id = ev.event_id AND al.object_kind = N'FIELD' AND al.object_id = f.field_definition_id
      LEFT JOIN grac_practice.asset_field_value tv ON tv.asset_id = al.target_asset_id AND tv.field_definition_id = f.field_definition_id
     WHERE ev.event_id = @event_id AND ev.organization_id = @organization_id AND ev.event_kind = N'SPLIT';
GO

-- What stops a split: the source not in use or merged, a pending lifecycle
-- change or open workflow case on it; a resulting record that is not a new
-- Draft of the organization; nothing allocated; an allocation that no
-- longer matches the source or is blocked.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_split_blockers (@organization_id BIGINT, @event_id BIGINT)
RETURNS TABLE
AS
RETURN
    WITH ev AS (SELECT event_id, survivor_asset_id AS source_id FROM grac_practice.asset_merge_split_event
                 WHERE event_id = @event_id AND organization_id = @organization_id AND event_kind = N'SPLIT'),
         res AS (SELECT m.asset_id FROM grac_practice.asset_merge_split_member m JOIN ev ON ev.event_id = m.event_id WHERE m.member_role = N'RESULT')
    SELECT CAST(N'SOURCE_NOT_IN_USE' AS NVARCHAR(30)) AS BlockerCode,
           CAST(CONCAT(a.asset_name, N' is disposed, archived or merged.') AS NVARCHAR(600)) AS Detail
      FROM ev JOIN grac_practice.organization_dependency_asset a ON a.asset_id = ev.source_id
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
     WHERE a.merged_into_asset_id IS NOT NULL OR ISNULL(s.status_code, N'ACTIVE') IN (N'DISPOSED', N'ARCHIVED')
    UNION ALL
    SELECT N'PENDING_LIFECYCLE', CAST(CONCAT(N'Lifecycle change ', c.from_status_code, N' -> ', c.to_status_code,
                                             N' of the source awaits approval; approve, reject or cancel it.') AS NVARCHAR(600))
      FROM ev JOIN grac_practice.asset_lifecycle_change c ON c.asset_id = ev.source_id AND c.change_status = N'PENDING_APPROVAL'
    UNION ALL
    SELECT N'OPEN_WORKFLOW', CAST(CONCAT(N'Workflow case #', w.case_id, N' (', w.workflow_code, N') of the source is open; complete or cancel it.') AS NVARCHAR(600))
      FROM ev JOIN grac_practice.asset_workflow_case w ON w.asset_id = ev.source_id AND w.case_status = N'OPEN'
    UNION ALL
    SELECT N'RESULT_NOT_DRAFT', CAST(CONCAT(a.asset_name, N' is not a Draft asset of this organization (register the resulting records as new Draft assets).') AS NVARCHAR(600))
      FROM res JOIN grac_practice.organization_dependency_asset a ON a.asset_id = res.asset_id
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
     WHERE a.organization_id <> @organization_id OR a.merged_into_asset_id IS NOT NULL OR ISNULL(s.status_code, N'ACTIVE') <> N'DRAFT'
    UNION ALL
    SELECT N'NOTHING_ALLOCATED', CAST(N'Allocate at least one item or field value to a resulting record.' AS NVARCHAR(600))
      FROM ev WHERE NOT EXISTS (SELECT 1 FROM grac_practice.asset_split_allocation al WHERE al.event_id = ev.event_id)
    UNION ALL
    SELECT N'ALLOCATION_CHANGED', CAST(CONCAT(al.object_kind, N' #', ISNULL(CAST(al.object_id AS NVARCHAR(30)), al.object_key),
                                              N' is no longer on the source; allocate again.') AS NVARCHAR(600))
      FROM ev JOIN grac_practice.asset_split_allocation al ON al.event_id = ev.event_id
     WHERE NOT EXISTS (SELECT 1 FROM grac_practice.fn_asset_split_plan(@organization_id, @event_id) p
                        WHERE p.ObjectKind = al.object_kind AND ISNULL(p.ObjectId, -1) = ISNULL(al.object_id, -1)
                          AND (al.object_kind = N'FIELD' OR ISNULL(p.ObjectKey, N'') = ISNULL(al.object_key, N'')))
    UNION ALL
    SELECT N'ALLOCATION_BLOCKED', CAST(CONCAT(p.ObjectLabel, N': the resulting record already has this open item; finish one first.') AS NVARCHAR(600))
      FROM grac_practice.fn_asset_split_plan(@organization_id, @event_id) p WHERE p.Outcome = N'BLOCK';
GO
PRINT '445: split plan and blockers created.';
GO

-- =====================================================================
-- 4. Split writers (D125, D128)
-- =====================================================================
-- New or changed Draft: source, resulting records (JSON array of 1-5 Draft
-- asset ids), reason, allocations (JSON array of {objectKind, objectId,
-- objectKey, targetAssetId, fieldMode} -- fieldMode MOVE | COPY for FIELD).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_split_save
    @organization_id         BIGINT,
    @event_id                BIGINT         = NULL,
    @source_asset_id         BIGINT,
    @results_json            NVARCHAR(MAX),
    @reason                  NVARCHAR(1000) = NULL,
    @allocations_json        NVARCHAR(MAX)  = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @reason = NULLIF(LTRIM(RTRIM(@reason)), N'');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 52900, 'Organization not found.', 1;
    IF @event_id IS NOT NULL
    BEGIN
        DECLARE @found BIT = 0, @status NVARCHAR(20), @rv BIGINT;
        SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version)
          FROM grac_practice.asset_merge_split_event
         WHERE event_id = @event_id AND organization_id = @organization_id AND event_kind = N'SPLIT';
        IF @found = 0 THROW 52902, 'Split not found for this organization.', 1;
        IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
            THROW 52903, 'The split was changed by someone else; reload it and try again.', 1;
        IF @status <> N'DRAFT' THROW 52907, 'Only a draft split can be changed.', 1;
    END

    DECLARE @res TABLE (asset_id BIGINT NOT NULL PRIMARY KEY, seq INT NOT NULL);
    IF ISJSON(ISNULL(@results_json, N'')) = 1
        INSERT @res (asset_id, seq)
        SELECT d.asset_id, ROW_NUMBER() OVER (ORDER BY MIN(d.ord))
          FROM (SELECT TRY_CONVERT(BIGINT, j.[value]) AS asset_id, CAST(j.[key] AS INT) AS ord FROM OPENJSON(@results_json) j) d
         WHERE d.asset_id IS NOT NULL
         GROUP BY d.asset_id;
    IF (SELECT COUNT(*) FROM @res) NOT BETWEEN 1 AND 5
        THROW 52915, 'Choose 1 to 5 resulting records.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset WHERE asset_id = @source_asset_id AND organization_id = @organization_id)
       OR EXISTS (SELECT 1 FROM @res r WHERE NOT EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset a
                                                          WHERE a.asset_id = r.asset_id AND a.organization_id = @organization_id))
        THROW 52901, 'Asset not found for this organization.', 1;
    IF EXISTS (SELECT 1 FROM @res WHERE asset_id = @source_asset_id)
       OR EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset a
                    LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
                   WHERE a.asset_id = @source_asset_id
                     AND (a.merged_into_asset_id IS NOT NULL OR ISNULL(s.status_code, N'ACTIVE') IN (N'DISPOSED', N'ARCHIVED')))
        THROW 52904, 'The source must be an asset in use (not disposed, archived or merged) and not one of the resulting records.', 1;
    IF EXISTS (SELECT 1 FROM @res r
                 JOIN grac_practice.organization_dependency_asset a ON a.asset_id = r.asset_id
                 LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
                WHERE a.merged_into_asset_id IS NOT NULL OR ISNULL(s.status_code, N'ACTIVE') <> N'DRAFT')
        THROW 52916, 'Each resulting record is a new Draft asset registered on the Asset Register form.', 1;
    IF EXISTS (SELECT 1 FROM grac_practice.asset_merge_split_event e
                WHERE e.organization_id = @organization_id AND e.status IN (N'DRAFT', N'PENDING_APPROVAL', N'APPROVED')
                  AND e.event_id <> ISNULL(@event_id, -1)
                  AND (e.survivor_asset_id = @source_asset_id OR e.survivor_asset_id IN (SELECT asset_id FROM @res)
                       OR EXISTS (SELECT 1 FROM grac_practice.asset_merge_split_member m
                                   WHERE m.event_id = e.event_id
                                     AND (m.asset_id = @source_asset_id OR m.asset_id IN (SELECT asset_id FROM @res)))))
        THROW 52905, 'One of these assets is already in another open merge or split; finish or cancel it first.', 1;

    DECLARE @al TABLE (object_kind NVARCHAR(20) NOT NULL, object_id BIGINT NULL, object_key NVARCHAR(200) NULL,
                       target_asset_id BIGINT NULL, field_mode NVARCHAR(4) NULL);
    IF @allocations_json IS NOT NULL AND LTRIM(@allocations_json) <> N''
    BEGIN
        IF ISJSON(@allocations_json) = 0 OR LEFT(LTRIM(@allocations_json), 1) <> N'['
            THROW 52917, 'The allocations are not valid.', 1;
        INSERT @al (object_kind, object_id, object_key, target_asset_id, field_mode)
        SELECT UPPER(LTRIM(RTRIM(j.objectKind))), j.objectId, NULLIF(LTRIM(RTRIM(j.objectKey)), N''), j.targetAssetId,
               NULLIF(UPPER(LTRIM(RTRIM(j.fieldMode))), N'')
          FROM OPENJSON(@allocations_json) WITH (objectKind NVARCHAR(20), objectId BIGINT, objectKey NVARCHAR(200), targetAssetId BIGINT,
                                                 fieldMode NVARCHAR(4)) j;
        IF EXISTS (SELECT 1 FROM @al a
                    WHERE a.target_asset_id IS NULL OR a.target_asset_id NOT IN (SELECT asset_id FROM @res)
                       OR a.object_kind NOT IN (N'RELATIONSHIP', N'DISCOVERY_LINK', N'ATTRIBUTE_SOURCE', N'RECON_EXCEPTION', N'COVERAGE',
                                                N'OCCURRENCE', N'RESTRICTIVE_REVIEW', N'RISK_MAP', N'RISK_LINK', N'PRACTICE_RESOLUTION', N'FIELD')
                       OR (a.object_kind = N'FIELD' AND ISNULL(a.field_mode, N'') NOT IN (N'MOVE', N'COPY'))
                       OR (a.object_kind <> N'FIELD' AND a.field_mode IS NOT NULL)
                       OR (a.object_kind = N'FIELD' AND NOT EXISTS (
                               SELECT 1 FROM grac_practice.asset_field_value v
                                 JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id
                                                                            AND f.storage_kind = N'VALUE' AND f.is_system_field = 0
                                 JOIN grac_practice.asset_field_data_type_master dt ON dt.data_type_code = f.data_type_code AND dt.is_user_entered = 1
                                WHERE v.asset_id = @source_asset_id AND v.field_definition_id = a.object_id))
                       OR (a.object_kind <> N'FIELD' AND NOT EXISTS (
                               SELECT 1 FROM grac_practice.fn_asset_merge_plan(@organization_id, -1, @source_asset_id) p
                                WHERE p.ObjectKind = a.object_kind AND ISNULL(p.ObjectId, -1) = ISNULL(a.object_id, -1)
                                  AND ISNULL(p.ObjectKey, N'') = ISNULL(a.object_key, N''))))
            THROW 52917, 'Each allocation names an item of the source (field values: a user-entered value, Move or Copy) and one of the resulting records.', 1;
        IF EXISTS (SELECT 1 FROM @al GROUP BY object_kind, object_id, object_key HAVING COUNT(*) > 1)
            THROW 52917, 'An item can be allocated to one resulting record only.', 1;
    END

    DECLARE @id BIGINT = @event_id, @result NVARCHAR(20) = CASE WHEN @event_id IS NULL THEN N'CREATED' ELSE N'SAVED' END;
    BEGIN TRAN;
    IF @id IS NULL
    BEGIN
        INSERT grac_practice.asset_merge_split_event
            (organization_id, event_kind, survivor_asset_id, status, reason, requested_by, requested_by_employee_id)
        VALUES (@organization_id, N'SPLIT', @source_asset_id, N'DRAFT', @reason, @actor, @actor_employee_id);
        SET @id = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE grac_practice.asset_merge_split_event SET survivor_asset_id = @source_asset_id, reason = @reason WHERE event_id = @id;
        DELETE FROM grac_practice.asset_merge_split_member WHERE event_id = @id;
        DELETE FROM grac_practice.asset_split_allocation WHERE event_id = @id;
    END
    INSERT grac_practice.asset_merge_split_member (event_id, asset_id, member_role, sequence_no)
    SELECT @id, asset_id, N'RESULT', seq FROM @res;
    INSERT grac_practice.asset_split_allocation (event_id, object_kind, object_id, object_key, target_asset_id, field_mode)
    SELECT @id, object_kind, object_id, CASE WHEN object_kind = N'FIELD' THEN NULL ELSE object_key END, target_asset_id, field_mode FROM @al;
    UPDATE e
       SET is_critical = c.IsCritical, approvals_required = CASE WHEN c.IsCritical = 1 THEN 2 ELSE 1 END
      FROM grac_practice.asset_merge_split_event e
     CROSS APPLY grac_practice.fn_asset_merge_critical(@organization_id, @id) c
     WHERE e.event_id = @id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-split', @id, CASE WHEN @event_id IS NULL THEN N'CREATE' ELSE N'UPDATE' END, NULL,
            (SELECT @source_asset_id AS sourceAssetId, JSON_QUERY(@results_json) AS results, @reason AS reason,
                    (SELECT COUNT(*) FROM @al) AS allocations FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @id AS EventId, @result AS Result;
END
GO

-- Execution (internal; inside the EXECUTE transaction of
-- sp_asset_merge_action): per resulting record, allocated items that can
-- move are moved by sp_asset_merge_split_move, the others are recorded as
-- kept; then the allocated field values are copied (and, for Move, taken
-- off the source).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_split_execute
    @organization_id   BIGINT,
    @event_id          BIGINT,
    @actor_employee_id BIGINT        = NULL,
    @actor             NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF EXISTS (SELECT 1 FROM grac_practice.fn_asset_split_blockers(@organization_id, @event_id))
        THROW 52908, 'The split has blockers; open it to see them.', 1;
    DECLARE @source BIGINT = (SELECT survivor_asset_id FROM grac_practice.asset_merge_split_event WHERE event_id = @event_id);
    CREATE TABLE #msplan (object_kind NVARCHAR(20) COLLATE DATABASE_DEFAULT NOT NULL, object_id BIGINT NULL,
                          object_key NVARCHAR(200) COLLATE DATABASE_DEFAULT NULL, object_label NVARCHAR(400) COLLATE DATABASE_DEFAULT NULL,
                          outcome NVARCHAR(10) COLLATE DATABASE_DEFAULT NOT NULL, detail NVARCHAR(600) COLLATE DATABASE_DEFAULT NULL);
    DECLARE @target BIGINT, @note NVARCHAR(400);
    DECLARE @fv TABLE (field_definition_id INT PRIMARY KEY, field_key NVARCHAR(100) NOT NULL, label NVARCHAR(200) NULL,
                       before_text NVARCHAR(MAX) NULL, value_text NVARCHAR(MAX) NOT NULL, field_mode NVARCHAR(4) NOT NULL);
    DECLARE res_cur CURSOR LOCAL STATIC FOR
        SELECT asset_id FROM grac_practice.asset_merge_split_member WHERE event_id = @event_id AND member_role = N'RESULT' ORDER BY sequence_no;
    OPEN res_cur;
    FETCH NEXT FROM res_cur INTO @target;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @note = CONCAT(N'Split #', @event_id, N': from asset #', @source, N' to #', @target, N'.');
        TRUNCATE TABLE #msplan;
        -- allocated items that stay (the result holds the equivalent): recorded as kept
        INSERT grac_practice.asset_merge_split_object
            (event_id, object_kind, object_id, object_key, object_label, from_asset_id, to_asset_id, outcome, detail)
        SELECT @event_id, p.ObjectKind, p.ObjectId, p.ObjectKey, p.ObjectLabel, @source, @target, N'KEPT', p.OutcomeNote
          FROM grac_practice.fn_asset_split_plan(@organization_id, @event_id) p
         WHERE p.TargetAssetId = @target AND p.ObjectKind <> N'FIELD' AND p.Outcome = N'STAY';
        INSERT #msplan (object_kind, object_id, object_key, object_label, outcome, detail)
        SELECT p.ObjectKind, p.ObjectId, p.ObjectKey, p.ObjectLabel, N'MOVE', p.Detail
          FROM grac_practice.fn_asset_split_plan(@organization_id, @event_id) p
         WHERE p.TargetAssetId = @target AND p.ObjectKind <> N'FIELD' AND p.Outcome = N'MOVE';
        EXEC grac_practice.sp_asset_merge_split_move
             @organization_id = @organization_id, @event_id = @event_id, @from_asset = @source, @to_asset = @target,
             @note = @note, @actor_employee_id = @actor_employee_id, @actor = @actor;

        -- field values: copied to the result (filled / replaced) ...
        DELETE FROM @fv;
        INSERT @fv (field_definition_id, field_key, label, before_text, value_text, field_mode)
        SELECT f.field_definition_id, f.field_key, f.display_label, tv.value_text, sv.value_text, al.field_mode
          FROM grac_practice.asset_split_allocation al
          JOIN grac_practice.asset_field_definition f ON f.field_definition_id = al.object_id
          JOIN grac_practice.asset_field_value sv ON sv.asset_id = @source AND sv.field_definition_id = f.field_definition_id
          LEFT JOIN grac_practice.asset_field_value tv ON tv.asset_id = @target AND tv.field_definition_id = f.field_definition_id
         WHERE al.event_id = @event_id AND al.object_kind = N'FIELD' AND al.target_asset_id = @target;
        INSERT grac_practice.asset_merge_split_object
            (event_id, object_kind, object_id, object_key, object_label, from_asset_id, to_asset_id, outcome, before_value, after_value, detail)
        SELECT @event_id, N'FIELD', field_definition_id, field_key, label, @source, @target,
               CASE WHEN before_text IS NULL THEN N'FILLED' ELSE N'REPLACED' END, before_text, value_text, LOWER(field_mode)
          FROM @fv WHERE ISNULL(before_text, N'') <> value_text;
        MERGE grac_practice.asset_field_value AS t
        USING (SELECT sv.field_definition_id, sv.value_text, sv.value_number, sv.value_date, sv.value_ref
                 FROM grac_practice.asset_field_value sv JOIN @fv x ON x.field_definition_id = sv.field_definition_id
                WHERE sv.asset_id = @source) AS s
           ON t.asset_id = @target AND t.field_definition_id = s.field_definition_id
        WHEN MATCHED AND t.value_text <> s.value_text THEN
            UPDATE SET value_text = s.value_text, value_number = s.value_number, value_date = s.value_date, value_ref = s.value_ref,
                       updated_by = @actor, updated_dt = SYSUTCDATETIME()
        WHEN NOT MATCHED THEN INSERT (asset_id, field_definition_id, value_text, value_number, value_date, value_ref, entered_by)
                              VALUES (@target, s.field_definition_id, s.value_text, s.value_number, s.value_date, s.value_ref, @actor);
        -- ... and, for Move, taken off the source (row without an after value)
        INSERT grac_practice.asset_merge_split_object
            (event_id, object_kind, object_id, object_key, object_label, from_asset_id, to_asset_id, outcome, before_value, after_value, detail)
        SELECT @event_id, N'FIELD', field_definition_id, field_key, label, @target, @source, N'REPLACED', value_text, NULL,
               N'moved to the resulting record'
          FROM @fv WHERE field_mode = N'MOVE';
        DELETE v FROM grac_practice.asset_field_value v
          JOIN @fv x ON x.field_definition_id = v.field_definition_id AND x.field_mode = N'MOVE'
         WHERE v.asset_id = @source;

        INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
        VALUES (N'asset-register', @target, N'SPLIT_RESULT', NULL,
                (SELECT @source AS sourceAssetId, @event_id AS splitEventId,
                        (SELECT COUNT(*) FROM grac_practice.asset_merge_split_object o WHERE o.event_id = @event_id AND o.to_asset_id = @target) AS outcomes
                    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), N'Active', @actor);
        FETCH NEXT FROM res_cur INTO @target;
    END
    CLOSE res_cur;
    DEALLOCATE res_cur;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-register', @source, N'SPLIT_SOURCE', NULL,
            (SELECT @event_id AS splitEventId,
                    (SELECT COUNT(*) FROM grac_practice.asset_merge_split_object o WHERE o.event_id = @event_id) AS outcomes
                FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), N'Active', @actor);
END
GO
PRINT '445: split save and execution created.';
GO

-- =====================================================================
-- 5. Split reader. 1. event  2. assets (source first)  3. approvals
-- 4. blockers (open)  5. plan / allocation (open)  6. outcomes  7. impact.
-- The list is sp_asset_merge_events with @event_kind = SPLIT.
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_split_get
    @organization_id BIGINT,
    @event_id        BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @source BIGINT, @status NVARCHAR(20);
    SELECT @source = survivor_asset_id, @status = status
      FROM grac_practice.asset_merge_split_event
     WHERE event_id = @event_id AND organization_id = @organization_id AND event_kind = N'SPLIT';
    IF @source IS NULL THROW 52902, 'Split not found for this organization.', 1;
    DECLARE @open BIT = CASE WHEN @status IN (N'DRAFT', N'PENDING_APPROVAL', N'APPROVED') THEN 1 ELSE 0 END;
    SELECT e.event_id AS EventId, e.status AS Status, e.survivor_asset_id AS SourceAssetId, s.asset_name AS SourceName,
           e.reason AS Reason, e.is_critical AS IsCritical, e.approvals_required AS ApprovalsRequired,
           (SELECT COUNT(*) FROM grac_practice.asset_merge_split_approval p WHERE p.event_id = e.event_id AND p.decision = N'APPROVE') AS Approvals,
           e.requested_by AS RequestedBy, e.requested_dt AS RequestedDt, e.submitted_dt AS SubmittedDt, e.decided_note AS DecidedNote,
           e.executed_by AS ExecutedBy, e.executed_dt AS ExecutedDt, e.recovered_by AS RecoveredBy, e.recovered_dt AS RecoveredDt,
           e.recovery_reason AS RecoveryReason, e.closed_dt AS ClosedDt, CONVERT(BIGINT, e.record_version) AS RecordVersion
      FROM grac_practice.asset_merge_split_event e
      JOIN grac_practice.organization_dependency_asset s ON s.asset_id = e.survivor_asset_id
     WHERE e.event_id = @event_id;
    SELECT x.asset_id AS AssetId, x.role_code AS MemberRole, x.seq AS SequenceNo, a.asset_name AS AssetName,
           ty.asset_type_name AS AssetTypeName, ISNULL(st.status_name, N'Active') AS StatusName, c.criticality_name AS CriticalityName,
           ow.employee_name AS OwnerName
      FROM (SELECT @source AS asset_id, N'SOURCE' AS role_code, 0 AS seq
            UNION ALL SELECT asset_id, member_role, sequence_no FROM grac_practice.asset_merge_split_member WHERE event_id = @event_id) x
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = x.asset_id
      LEFT JOIN grac_practice.dependency_asset_type_master ty ON ty.asset_type_id = a.asset_type_id
      LEFT JOIN grac_practice.entity_status_master st ON st.entity_status_id = a.current_status_id
      LEFT JOIN grac_practice.criticality_master c ON c.criticality_id = a.criticality_id
      LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = a.owner_id
     ORDER BY x.seq;
    SELECT approval_id AS ApprovalId, decision AS Decision, note AS Note, approver AS Approver, decided_dt AS DecidedDt
      FROM grac_practice.asset_merge_split_approval WHERE event_id = @event_id ORDER BY approval_id;
    SELECT BlockerCode, Detail FROM grac_practice.fn_asset_split_blockers(@organization_id, @event_id) WHERE @open = 1;
    SELECT p.ObjectKind, p.ObjectId, p.ObjectKey, p.ObjectLabel, p.Domain, p.Detail, p.TargetAssetId, p.FieldMode, p.Outcome, p.OutcomeNote
      FROM grac_practice.fn_asset_split_plan(@organization_id, @event_id) p
     WHERE @open = 1
     ORDER BY p.Domain, p.ObjectKind, p.ObjectLabel;
    SELECT o.object_row_id AS ObjectRowId, o.from_asset_id AS FromAssetId, o.to_asset_id AS ToAssetId, o.object_kind AS ObjectKind,
           o.object_id AS ObjectId, o.object_label AS ObjectLabel, o.outcome AS Outcome, LEFT(o.before_value, 400) AS BeforeValue,
           LEFT(o.after_value, 400) AS AfterValue, o.detail AS Detail, o.recovered AS Recovered, o.recovery_note AS RecoveryNote
      FROM grac_practice.asset_merge_split_object o
     WHERE o.event_id = @event_id
     ORDER BY o.object_row_id;
    SELECT x.asset_id AS AssetId, i.ImpactItem, i.ItemCount, i.SortOrder
      FROM (SELECT @source AS asset_id UNION SELECT asset_id FROM grac_practice.asset_merge_split_member WHERE event_id = @event_id) x
     CROSS APPLY grac_practice.fn_asset_merge_impact(@organization_id, x.asset_id) i
     ORDER BY x.asset_id, i.SortOrder;
END
GO
PRINT '445: split reader created.';
GO
