parts = ["444_a.sql", "444_b.sql", "444_c.sql", "444_d.sql", "444_e1.sql", "444_e2.sql", "444_f.sql"]
s = "".join(open("/home/claude/" + p).read() for p in parts)
open("/home/claude/444.sql", "w").write(s)
print("444.sql", s.count("\n"))
