# 443: API + Web proxy for candidate registration and stale reviews.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    open(path, 'w', encoding='utf-8', newline='').write(s)

API = "src/PracticeManagement.Api/"
WEB = "src/PracticeManagement.Web/"

# ------------------------------------------------------------------ models
edit(API + "Models/AssetConfigModels.cs", [(
"""/// <summary>Reconciliation queue action: LINK | IGNORE | NOT_DUPLICATE | ACCEPT_OBSERVED | KEEP_CURRENT.</summary>
public sealed record AssetReconciliationResolveRequest(long OrganizationId, string? Action, long? AssetId, string? Note, long? ExpectedRecordVersion);
""",
"""/// <summary>Reconciliation queue action: LINK | IGNORE | NOT_DUPLICATE | ACCEPT_OBSERVED | KEEP_CURRENT;
/// 443: REGISTER (new candidate / manual review -> the Draft asset just registered for it).</summary>
public sealed record AssetReconciliationResolveRequest(long OrganizationId, string? Action, long? AssetId, string? Note, long? ExpectedRecordVersion);

// ---------------------------------------------------------------------
// Discovery follow-up: stale-asset review (migration 443)
// ---------------------------------------------------------------------
/// <summary>Aging rule: days without any source observation before an asset is stale (1-3650).</summary>
public sealed record AssetStaleSettingRequest(long OrganizationId, int? RetireAfterDays);
public sealed record AssetStaleReviewOpenRequest(long OrganizationId, long AssetId);
/// <summary>CONFIRM_SOURCE (SourceOutcome ABSENT | PRESENT) | REVIEW_DEPENDENCIES | DISMISS | REQUEST_DECOMMISSION; Note required.</summary>
public sealed record AssetStaleReviewActionRequest(long OrganizationId, string? Action, string? SourceOutcome, string? Note, long? ExpectedRecordVersion);
""")])

# ------------------------------------------------------------------ service
edit(API + "Services/AssetConfigService.cs", [
("""//   sp_asset_discovery_* / sp_asset_reconciliation_* (442 -- discovery sources, rules, ingestion, queue, confidence)
""",
"""//   sp_asset_discovery_* / sp_asset_reconciliation_* (442 -- discovery sources, rules, ingestion, queue, confidence)
//   sp_asset_stale_* / sp_asset_discovery_candidate_get (443 -- stale review, candidate registration)
"""),
("""    Task<object?> GetDiscoveryAssetAsync(long organizationId, long assetId, CancellationToken ct);
""",
"""    Task<object?> GetDiscoveryAssetAsync(long organizationId, long assetId, CancellationToken ct);

    // 443 -- Discovery follow-up: candidate registration, stale review
    Task<object?> GetDiscoveryCandidateAsync(long organizationId, long exceptionId, CancellationToken ct);
    Task<object> ListStaleReviewsAsync(long organizationId, string? view, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<object?> GetStaleReviewAsync(long organizationId, long assetId, CancellationToken ct);
    Task<AssetLifecycleResult> SaveStaleSettingAsync(AssetStaleSettingRequest request, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> OpenStaleReviewAsync(AssetStaleReviewOpenRequest request, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> StaleReviewActionAsync(long reviewId, AssetStaleReviewActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
"""),
("""        catch (SqlException ex) when (ex.Number == 54777) { return null; }
    }

    public async Task<object> GetBusinessServiceTreeAsync(""",
"""        catch (SqlException ex) when (ex.Number == 54777) { return null; }
    }

    // ----------------------------------------------------------------
    // 443 -- Discovery follow-up: candidate registration, stale review
    // ----------------------------------------------------------------
    public async Task<object?> GetDiscoveryCandidateAsync(long organizationId, long exceptionId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_discovery_candidate_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@exception_id",    DbType.Int64, exceptionId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var exception = await ReadRowsAsync(reader, ct);
            if (exception.Count == 0) return null;
            var attributes = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
            return new { exception = exception[0], attributes };
        }
        catch (SqlException ex) when (ex.Number == 54773) { return null; }
    }

    public async Task<object> ListStaleReviewsAsync(long organizationId, string? view, string? search, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_stale_reviews");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@view",            DbType.String, Blank(view), 10);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var settings = await ReadRowsAsync(reader, ct);
        var rows = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
        return new { settings = settings.Count > 0 ? settings[0] : null, rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object?> GetStaleReviewAsync(long organizationId, long assetId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_stale_review_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@asset_id",        DbType.Int64, assetId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var asset = await ReadRowsAsync(reader, ct);
            if (asset.Count == 0) return null;
            var empty = new List<Dictionary<string, object?>>();
            var links = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var dependencies = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var reviews = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            return new { asset = asset[0], links, dependencies, reviews };
        }
        catch (SqlException ex) when (ex.Number == 54781) { return null; }
    }

    public Task<AssetLifecycleResult> SaveStaleSettingAsync(AssetStaleSettingRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_stale_setting_save", "organizationId", command =>
        {
            AddParam(command, "@organization_id",   DbType.Int64,  request.OrganizationId);
            AddParam(command, "@retire_after_days", DbType.Int32,  request.RetireAfterDays);
            AddParam(command, "@actor",             DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> OpenStaleReviewAsync(AssetStaleReviewOpenRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_stale_review_open", "reviewId", command =>
        {
            AddParam(command, "@organization_id", DbType.Int64,  request.OrganizationId);
            AddParam(command, "@asset_id",        DbType.Int64,  request.AssetId);
            AddParam(command, "@actor",           DbType.String, actor, 100);
        }, ct);

    // REQUEST_DECOMMISSION returns the lifecycle move's result set first; the
    // review result (ReviewId, Result) is always the last result set.
    public async Task<AssetLifecycleResult> StaleReviewActionAsync(long reviewId, AssetStaleReviewActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_stale_review_action");
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@review_id",               DbType.Int64,  reviewId);
            AddParam(command, "@action",                  DbType.String, Blank(request.Action), 24);
            AddParam(command, "@source_outcome",          DbType.String, Blank(request.SourceOutcome), 10);
            AddParam(command, "@note",                    DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
            var last = new List<Dictionary<string, object?>>();
            await using (var reader = await command.ExecuteReaderAsync(ct))
            {
                do
                {
                    var rows = await ReadRowsAsync(reader, ct);
                    if (rows.Count > 0) last = rows;
                } while (await reader.NextResultAsync(ct));
            }
            var row = last.Count > 0 ? last[0] : new Dictionary<string, object?>();
            row.TryGetValue("reviewId", out var id);
            row.TryGetValue("result", out var result);
            return new AssetLifecycleResult(true, Convert.ToString(result) ?? "SAVED", id is null ? null : Convert.ToInt64(id), null, null);
        }
        catch (SqlException ex)
        {
            logger.LogWarning(ex, "AssetConfigService sp_asset_stale_review_action refused ({Number})", ex.Number);
            return new AssetLifecycleResult(false, null, null, ex.Number, ex.Message);
        }
    }

    public async Task<object> GetBusinessServiceTreeAsync("""),
])

# ------------------------------------------------------------------ controller
edit(API + "Controllers/AssetConfigController.cs", [
("""//   GET  discovery/assets/{assetId}?organizationId=  confidence, links, values per source, open exceptions
""",
"""//   GET  discovery/assets/{assetId}?organizationId=  confidence, links, values per source, open exceptions
//   GET  discovery/exceptions/{id}/candidate?organizationId=   exception + observed values for the register form (443)
//        (discovery/exceptions/{id}/resolve also takes REGISTER -- 443)
//   GET  discovery/stale?organizationId=&view=&search=&pageNumber=&pageSize=   aging rule + stale assets / closed reviews
//   GET  discovery/stale/assets/{assetId}?organizationId=   stale state + open review, links, dependencies, reviews
//   POST discovery/stale/settings                    aging rule
//   POST discovery/stale/reviews                     open a review on a stale asset
//   POST discovery/stale/reviews/{id}/action         CONFIRM_SOURCE | REVIEW_DEPENDENCIES | DISMISS | REQUEST_DECOMMISSION
"""),
("""    private static readonly int[] DiscoveryConflict = { 54774 };
""",
"""    private static readonly int[] DiscoveryConflict = { 54774 };

    // ---------------------------------------------------------------- 443: candidate registration, stale review
    [HttpGet("discovery/exceptions/{exceptionId:long}/candidate")]
    public Task<IActionResult> DiscoveryCandidate(long exceptionId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetDiscoveryCandidateAsync(o, exceptionId, ct), "Reconciliation exception not found.", "discovery candidate");

    [HttpGet("discovery/stale")]
    public Task<IActionResult> StaleReviews([FromQuery] long? organizationId, [FromQuery] string? view, [FromQuery] string? search,
        [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListStaleReviewsAsync(organizationId.Value, view, search, pageNumber ?? 1, pageSize ?? 25, ct), "stale reviews");
    }

    [HttpGet("discovery/stale/assets/{assetId:long}")]
    public Task<IActionResult> StaleReview(long assetId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetStaleReviewAsync(o, assetId, ct), "Asset not found.", "stale review");

    [HttpPost("discovery/stale/settings")]
    public async Task<IActionResult> SaveStaleSetting([FromBody] AssetStaleSettingRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveStaleSettingAsync(request, Actor, ct), StaleNotFound, StaleConflict);
    }

    [HttpPost("discovery/stale/reviews")]
    public async Task<IActionResult> OpenStaleReview([FromBody] AssetStaleReviewOpenRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (request.AssetId <= 0) return BadRequest(new { error = "assetId is required." });
        return ResultWritten(await service.OpenStaleReviewAsync(request, Actor, ct), StaleNotFound, StaleConflict);
    }

    [HttpPost("discovery/stale/reviews/{reviewId:long}/action")]
    public async Task<IActionResult> StaleReviewAction(long reviewId, [FromBody] AssetStaleReviewActionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Action)) return BadRequest(new { error = "action is required." });
        return ResultWritten(await service.StaleReviewActionAsync(reviewId, request, ActorEmployeeId, Actor, ct), StaleNotFound, StaleConflict);
    }

    // 443: 54780 (organization), 54781 (asset), 54784 (review) -> 404; 54785 (stale) -> 409.
    //      Lifecycle refusals of REQUEST_DECOMMISSION (5497x, 54719) -> 400.
    private static readonly int[] StaleNotFound = { 54780, 54781, 54784 };
    private static readonly int[] StaleConflict = { 54785 };
"""),
])

# ------------------------------------------------------------------ Web proxy
edit(WEB + "Controllers/AssetConfigController.cs", [
("""//                                      relationships/ci-lookup also open to asset-discovery VIEW (asset picker)
""",
"""//                                      relationships/ci-lookup also open to asset-discovery VIEW (asset picker)
//                                      443: stale/settings, stale/reviews and stale/reviews/{id}/action EDIT;
//                                      REQUEST_DECOMMISSION also needs asset-register EDIT (lifecycle move)
"""),
("""            : isDiscovery && (lower == "discovery/sources" || lower == "discovery/rules" || lower == "discovery/settings"
""",
"""            : isDiscovery && lower.StartsWith("discovery/stale/reviews/") && lower.EndsWith("/action")   // 443
            ? (exceptionAction == "REQUEST_DECOMMISSION" ? Can(area, "EDIT") && Can(RegisterArea, "EDIT") : Can(area, "EDIT"))
            : isDiscovery && (lower == "discovery/stale/settings" || lower == "discovery/stale/reviews")   // 443
            ? Can(area, "EDIT")
            : isDiscovery && (lower == "discovery/sources" || lower == "discovery/rules" || lower == "discovery/settings"
"""),
])
print("p443 ok")
