-- =====================================================================
-- 447  CIA and criticality consistency rules, approved inconsistencies,
--      lifecycle gate, Asset Value for risk
--      (Asset & Contract Management, Phase 8 increment 2)
--
-- REQUEST
-- -------
--   BRD v1.7 19.7 (CIA and Criticality Consistency Rules): condition over
--   CIA, Asset Value, Criticality, service importance, safety or recovery
--   fields; severity Information / Warning / Error / Approval Required;
--   scope tenant, entity, category, asset type or service; action warn,
--   require rationale, create exception / task or block transition;
--   approver; override with reason, evidence, approver and expiry;
--   effective-dated and immutable after activation; applied the same way
--   to forms, imports, APIs, bulk preview, dashboards and reports;
--   approved inconsistencies keep rationale, owner, approval and review
--   date. 5.1.18.3 (the risk module uses the calculated Asset Value).
--   Plan: docs/asset-contract-management.md (Phase 8.2, D142-D153).
--
-- WHAT THIS DOES
-- --------------
--   1. asset_consistency_rule (+ _condition): per organization, one rule
--      code with versions -- Draft (editable) -> Active (immutable) ->
--      Retired; a new version is a Draft copy; activating it retires the
--      previous one. Conditions use the 421 operators and semantics
--      (conditions in a group are ANDed, groups are ORed). Operands: any
--      field of the field dictionary (stored asset values, including the
--      446 Asset Value Score / Category) plus CRITICALITY,
--      CRITICALITY_SCORE, SERVICE_CRITICALITY, SERVICE_CRITICALITY_SCORE
--      and ASSET_VALUE_STATUS.
--   2. fn_asset_consistency_facts / fn_asset_consistency_eval: one
--      evaluation used by the form save, imports and APIs (they all save
--      through sp_asset_register_save), the scheduler, the rule preview
--      (bulk preview), the findings list and later dashboards.
--   3. asset_consistency_finding: one open finding per asset and rule code;
--      resolved when the condition no longer holds. Acceptance records
--      rationale, evidence, owner and review date; Error and Approval
--      Required findings need approval by another person (asset-register
--      APPROVE); an accepted finding reopens when its review date passes.
--      Action CREATE_TASK opens a Task Centre task (type
--      AssetConsistency); BLOCK_TRANSITION stops a move to Active while
--      the finding is open or pending.
--   4. Re-issued: sp_asset_register_save (446) evaluates the asset after
--      the save and returns its open findings as warnings;
--      sp_asset_scheduler_run (446) evaluates every organization;
--      sp_asset_lifecycle_transition (440) has the BLOCK_TRANSITION gate;
--      sp_asset_valuation_get (446) adds the linked risks with a review
--      flag and the consistency findings of the asset.
--   5. fn_asset_risk_value: per risk, the highest valid Asset Value of
--      its linked assets and whether that value changed after the risk
--      was last assessed -- what the risk module reads (5.1.18.3). Risk
--      scoring itself is unchanged (19.12).
--
-- NOT DONE HERE: free-text expressions (conditions are structured);
--   closing the Task Centre task when the finding resolves; privacy,
--   dashboards, report catalogue and exports (8.3-8.5).
--
-- ERROR NUMBERS: 53010-53039
--   53010 organization not found        53011 rule not found
--   53012 only a Draft can be changed   53013 rule changed by someone else
--   53014 name required                 53015 scope invalid
--   53016 severity / action invalid     53017 condition invalid
--   53018 no condition                  53019 a Draft already exists
--   53020 activator saved the Draft     53021 reason required
--   53022 effective dates invalid       53023 invalid rule action
--   53030 finding not found             53031 the rule permits no override
--   53032 approver is the requester     53033 action not allowed now
--   53034 rationale / owner / review date / evidence required
--   53035 review date out of range      53036 finding changed by someone else
--   53037 open blocking findings (lifecycle move to Active)
--   53038 invalid finding action
--
-- ALSO EDITED: API (AssetConfig service / controller / models), Web
--   proxy, asset-valuation-config.cshtml / .js (Consistency rules view),
--   asset-register.cshtml / .js (findings and linked risks on the
--   Valuation tab, Consistency findings list), docs.
-- DEPENDS ON: 196, 265, 438, 440, 441, 446.
-- Rollback: 447_asset_consistency_rules_rollback.sql (restores the 440 and
--   446 bodies, drops the 447 objects; the task type stays).
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.asset_valuation_result','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_valuation_history','U') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_valuation_apply','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_valuation_sync','P') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_valuation_state') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_stored_values') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_relationship_edges') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_relationship_blockers') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_ci_catalog') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_coverage_gaps') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_activity_person') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_lifecycle_apply','P') IS NULL
   OR OBJECT_ID('grac_practice.asset_lifecycle_transition_gate','U') IS NULL
   OR OBJECT_ID('grac_practice.business_service','U') IS NULL
   OR OBJECT_ID('grac_practice.sp_task_open','P') IS NULL
   OR OBJECT_ID('grac_practice.risk_dependency_map','U') IS NULL
   OR COL_LENGTH('grac_practice.risk_register','residual_assessed_dt') IS NULL
   OR COL_LENGTH('grac_practice.asset_scheduler_run','tasks_created') IS NULL
   OR NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_practice_task_source_type' AND definition LIKE '%Asset''%')
BEGIN
    RAISERROR('ABORT (447): run 196, 265, 438, 440, 441 and 446 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Task type for CREATE_TASK findings
-- =====================================================================
MERGE grac_practice.task_type_master AS t
USING (VALUES (N'AssetConsistency', N'Asset Consistency', N'Resolve or justify a CIA / criticality consistency finding on an asset', 120, N'Medium', 1, 92))
   AS s(type_code, type_name, description, default_sla_hours, default_priority, is_system_only, display_order)
ON t.type_code = s.type_code
WHEN NOT MATCHED BY TARGET THEN
    INSERT (type_code, type_name, description, default_sla_hours, default_priority, is_system_only, display_order, entered_by)
    VALUES (s.type_code, s.type_name, s.description, s.default_sla_hours, s.default_priority, s.is_system_only, s.display_order, N'seed-447');
PRINT CONCAT('447: task type inserted: ', @@ROWCOUNT);
GO

-- =====================================================================
-- 2. Tables
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_consistency_rule','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_consistency_rule (
        rule_id           BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_acons_rule PRIMARY KEY,
        organization_id   BIGINT         NOT NULL
            CONSTRAINT fk_pm_acons_rule_org REFERENCES grac_practice.organization(organization_id),
        rule_code         NVARCHAR(20)   NOT NULL,
        version_no        INT            NOT NULL,
        rule_name         NVARCHAR(200)  NOT NULL,
        description       NVARCHAR(1000) NULL,
        scope_kind        NVARCHAR(12)   NOT NULL CONSTRAINT df_pm_acons_rule_scope DEFAULT N'TENANT'
            CONSTRAINT ck_pm_acons_rule_scope CHECK (scope_kind IN (N'TENANT', N'CATEGORY', N'SUBCATEGORY', N'ASSET_TYPE', N'SERVICE')),
        scope_ref_id      BIGINT         NULL,
        severity          NVARCHAR(20)   NOT NULL
            CONSTRAINT ck_pm_acons_rule_sev CHECK (severity IN (N'INFO', N'WARNING', N'ERROR', N'APPROVAL_REQUIRED')),
        action_code       NVARCHAR(20)   NOT NULL
            CONSTRAINT ck_pm_acons_rule_action CHECK (action_code IN (N'WARN', N'REQUIRE_RATIONALE', N'CREATE_TASK', N'BLOCK_TRANSITION')),
        override_allowed  BIT            NOT NULL CONSTRAINT df_pm_acons_rule_ovr DEFAULT 1,
        max_override_days INT            NULL
            CONSTRAINT ck_pm_acons_rule_days CHECK (max_override_days IS NULL OR max_override_days BETWEEN 1 AND 1095),
        status            NVARCHAR(10)   NOT NULL CONSTRAINT df_pm_acons_rule_status DEFAULT N'DRAFT'
            CONSTRAINT ck_pm_acons_rule_status CHECK (status IN (N'DRAFT', N'ACTIVE', N'RETIRED', N'DISCARDED')),
        effective_from    DATE           NULL,
        effective_to      DATE           NULL,
        change_reason     NVARCHAR(1000) NULL,
        source_rule_id    BIGINT         NULL,
        activated_by      NVARCHAR(100)  NULL,
        activated_dt      DATETIME2      NULL,
        retired_by        NVARCHAR(100)  NULL,
        retired_dt        DATETIME2      NULL,
        entered_by        NVARCHAR(100)  NOT NULL,
        entered_dt        DATETIME2      NOT NULL CONSTRAINT df_pm_acons_rule_edt DEFAULT SYSUTCDATETIME(),
        updated_by        NVARCHAR(100)  NULL,
        updated_dt        DATETIME2      NULL,
        record_version    ROWVERSION     NOT NULL,
        CONSTRAINT uq_pm_acons_rule_version UNIQUE (organization_id, rule_code, version_no)
    );
    CREATE UNIQUE INDEX ux_pm_acons_rule_active ON grac_practice.asset_consistency_rule(organization_id, rule_code) WHERE status = N'ACTIVE';
    CREATE UNIQUE INDEX ux_pm_acons_rule_draft ON grac_practice.asset_consistency_rule(organization_id, rule_code) WHERE status = N'DRAFT';
    PRINT '447: asset_consistency_rule created.';
END
GO

IF OBJECT_ID('grac_practice.asset_consistency_rule_condition','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_consistency_rule_condition (
        condition_id   BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_acons_cond PRIMARY KEY,
        rule_id        BIGINT        NOT NULL
            CONSTRAINT fk_pm_acons_cond_rule REFERENCES grac_practice.asset_consistency_rule(rule_id) ON DELETE CASCADE,
        group_no       INT           NOT NULL CONSTRAINT df_pm_acons_cond_grp DEFAULT 1,
        operand_key    NVARCHAR(100) NOT NULL,
        operator_code  NVARCHAR(30)  NOT NULL
            CONSTRAINT ck_pm_acons_cond_op CHECK (operator_code IN (N'EQ', N'NEQ', N'IN', N'NOT_IN', N'EMPTY', N'NOT_EMPTY',
                N'GT', N'GTE', N'LT', N'LTE', N'DATE_BEFORE_TODAY', N'DATE_AFTER_TODAY', N'DATE_WITHIN_DAYS')),
        compare_value  NVARCHAR(400) NULL,
        display_order  INT           NOT NULL CONSTRAINT df_pm_acons_cond_order DEFAULT 0
    );
    CREATE INDEX ix_pm_acons_cond_rule ON grac_practice.asset_consistency_rule_condition(rule_id, group_no);
    PRINT '447: asset_consistency_rule_condition created.';
END
GO

IF OBJECT_ID('grac_practice.asset_consistency_finding','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_consistency_finding (
        finding_id            BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_acons_finding PRIMARY KEY,
        organization_id       BIGINT         NOT NULL,
        asset_id              BIGINT         NOT NULL
            CONSTRAINT fk_pm_acons_finding_asset REFERENCES grac_practice.organization_dependency_asset(asset_id),
        rule_code             NVARCHAR(20)   NOT NULL,
        rule_id               BIGINT         NOT NULL
            CONSTRAINT fk_pm_acons_finding_rule REFERENCES grac_practice.asset_consistency_rule(rule_id),
        severity              NVARCHAR(20)   NOT NULL,
        action_code           NVARCHAR(20)   NOT NULL,
        status                NVARCHAR(20)   NOT NULL CONSTRAINT df_pm_acons_finding_status DEFAULT N'OPEN'
            CONSTRAINT ck_pm_acons_finding_status CHECK (status IN (N'OPEN', N'PENDING_APPROVAL', N'ACCEPTED', N'RESOLVED')),
        message               NVARCHAR(600)  NOT NULL,
        facts_json            NVARCHAR(MAX)  NULL,
        detected_dt           DATETIME2      NOT NULL CONSTRAINT df_pm_acons_finding_ddt DEFAULT SYSUTCDATETIME(),
        last_evaluated_dt     DATETIME2      NOT NULL CONSTRAINT df_pm_acons_finding_edt DEFAULT SYSUTCDATETIME(),
        resolved_dt           DATETIME2      NULL,
        rationale             NVARCHAR(1000) NULL,
        evidence              NVARCHAR(1000) NULL,
        owner_employee_id     BIGINT         NULL,
        review_date           DATE           NULL,
        requested_by          NVARCHAR(100)  NULL,
        requested_employee_id BIGINT         NULL,
        requested_dt          DATETIME2      NULL,
        decided_by            NVARCHAR(100)  NULL,
        decided_employee_id   BIGINT         NULL,
        decided_dt            DATETIME2      NULL,
        decision_note         NVARCHAR(1000) NULL,
        reopened_count        INT            NOT NULL CONSTRAINT df_pm_acons_finding_reopen DEFAULT 0,
        task_id               BIGINT         NULL,
        record_version        ROWVERSION     NOT NULL
    );
    CREATE UNIQUE INDEX ux_pm_acons_finding_open ON grac_practice.asset_consistency_finding(asset_id, rule_code) WHERE status <> N'RESOLVED';
    CREATE INDEX ix_pm_acons_finding_org ON grac_practice.asset_consistency_finding(organization_id, status, severity);
    PRINT '447: asset_consistency_finding created.';
END
GO

