
-- =====================================================================
-- 5. Snapshot (D172-D174)
-- =====================================================================
-- Computes every enabled KPI from fn_asset_governance_items, scores it
-- (one decimal, half away from zero), rates it against its thresholds and
-- the overall score (weighted mean of the scored KPIs; a lower-is-better
-- KPI enters as 100 - rate), then:
--   * the same date already has a current snapshot with exactly the same
--     KPI rows and record rows -> nothing is written (UNCHANGED);
--   * otherwise a new snapshot (version n + 1 of the date) becomes the
--     current one and the previous one of the date is kept, superseded.
-- Record rows of snapshots older than the retention are removed (the KPI
-- rows stay); the latest snapshot always keeps its records.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_governance_snapshot_take
    @organization_id BIGINT,
    @source_code     NVARCHAR(10)  = N'MANUAL',
    @actor           NVARCHAR(100) = N'system',
    @suppress_result BIT           = 0,
    @out_snapshot_id BIGINT        = NULL OUTPUT,
    @out_created     BIT           = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @source_code = CASE WHEN UPPER(ISNULL(@source_code, N'')) = N'SCHEDULER' THEN N'SCHEDULER' ELSE N'MANUAL' END;
    SELECT @out_snapshot_id = NULL, @out_created = 0;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53080, 'Organization not found.', 1;

    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    DECLARE @ot DECIMAL(5, 1), @ow DECIMAL(5, 1), @ret INT, @code NVARCHAR(30), @cur BIGINT, @ver INT, @overall DECIMAL(5, 1),
            @rag NVARCHAR(6), @items INT, @latest BIGINT;
    SELECT @ot = overall_target, @ow = overall_warning, @ret = item_retention_days
      FROM grac_practice.asset_governance_org_setting WHERE organization_id = @organization_id;
    SELECT @ot = ISNULL(@ot, 90.0), @ow = ISNULL(@ow, 75.0), @ret = ISNULL(@ret, 90);

    CREATE TABLE #set (kpi_code NVARCHAR(30) COLLATE DATABASE_DEFAULT NOT NULL PRIMARY KEY, is_enabled BIT NOT NULL, weight INT NOT NULL,
                       target_value DECIMAL(5, 1) NOT NULL, warning_value DECIMAL(5, 1) NOT NULL, period_days INT NULL,
                       direction NVARCHAR(6) COLLATE DATABASE_DEFAULT NOT NULL, display_order INT NOT NULL);
    INSERT #set (kpi_code, is_enabled, weight, target_value, warning_value, period_days, direction, display_order)
    SELECT KpiCode, IsEnabled, Weight, TargetValue, WarningValue, PeriodDays, Direction, DisplayOrder
      FROM grac_practice.fn_asset_governance_effective(@organization_id);

    CREATE TABLE #item (kpi_code NVARCHAR(30) COLLATE DATABASE_DEFAULT NOT NULL, record_kind NVARCHAR(16) COLLATE DATABASE_DEFAULT NOT NULL,
                        record_id BIGINT NOT NULL, record_name NVARCHAR(400) COLLATE DATABASE_DEFAULT NULL,
                        outcome NVARCHAR(8) COLLATE DATABASE_DEFAULT NOT NULL, numerator INT NOT NULL, denominator INT NOT NULL,
                        reason NVARCHAR(1000) COLLATE DATABASE_DEFAULT NULL,
                        PRIMARY KEY (kpi_code, record_kind, record_id));
    -- One KPI at a time, enabled ones only (a disabled KPI is recorded, not computed).
    DECLARE kpi_cur CURSOR LOCAL STATIC FOR SELECT kpi_code FROM #set WHERE is_enabled = 1 ORDER BY display_order;
    OPEN kpi_cur;
    FETCH NEXT FROM kpi_cur INTO @code;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        INSERT #item (kpi_code, record_kind, record_id, record_name, outcome, numerator, denominator, reason)
        SELECT KpiCode, RecordKind, RecordId, RecordName, Outcome, ISNULL(Numerator, 0), ISNULL(Denominator, 0), Reason
          FROM grac_practice.fn_asset_governance_items(@organization_id, @code);
        FETCH NEXT FROM kpi_cur INTO @code;
    END
    CLOSE kpi_cur;
    DEALLOCATE kpi_cur;

    CREATE TABLE #kpi (kpi_code NVARCHAR(30) COLLATE DATABASE_DEFAULT NOT NULL PRIMARY KEY, is_enabled BIT NOT NULL, numerator INT NOT NULL,
                       denominator INT NOT NULL, excluded_count INT NOT NULL, failing_count INT NOT NULL, score DECIMAL(5, 1) NULL,
                       rag NVARCHAR(6) COLLATE DATABASE_DEFAULT NOT NULL, direction NVARCHAR(6) COLLATE DATABASE_DEFAULT NOT NULL,
                       target_value DECIMAL(5, 1) NOT NULL, warning_value DECIMAL(5, 1) NOT NULL, weight INT NOT NULL, period_days INT NULL);
    INSERT #kpi (kpi_code, is_enabled, numerator, denominator, excluded_count, failing_count, score, rag, direction,
                 target_value, warning_value, weight, period_days)
    SELECT s.kpi_code, s.is_enabled, ISNULL(a.num, 0), ISNULL(a.den, 0), ISNULL(a.exc, 0), ISNULL(a.fail, 0), sc.score,
           CASE WHEN sc.score IS NULL THEN N'NA'
                WHEN s.direction = N'HIGHER' AND sc.score >= s.target_value THEN N'GREEN'
                WHEN s.direction = N'HIGHER' AND sc.score >= s.warning_value THEN N'AMBER'
                WHEN s.direction = N'LOWER' AND sc.score <= s.target_value THEN N'GREEN'
                WHEN s.direction = N'LOWER' AND sc.score <= s.warning_value THEN N'AMBER'
                ELSE N'RED' END,
           s.direction, s.target_value, s.warning_value, s.weight, s.period_days
      FROM #set s
     OUTER APPLY (SELECT SUM(CASE WHEN i.outcome <> N'EXCLUDED' THEN i.numerator ELSE 0 END) AS num,
                         SUM(CASE WHEN i.outcome <> N'EXCLUDED' THEN i.denominator ELSE 0 END) AS den,
                         SUM(CASE WHEN i.outcome = N'EXCLUDED' THEN 1 ELSE 0 END) AS exc,
                         SUM(CASE WHEN i.outcome = N'FAIL' THEN 1 ELSE 0 END) AS fail
                    FROM #item i WHERE i.kpi_code = s.kpi_code) a
     -- Zero denominator: no score, rated NA, left out of the overall score (D171).
     CROSS APPLY (SELECT CAST(CASE WHEN s.is_enabled = 1 AND ISNULL(a.den, 0) > 0
                                   THEN ROUND(100.0 * a.num / a.den, 1) END AS DECIMAL(5, 1)) AS score) sc;

    SET @overall = (SELECT CAST(ROUND(SUM((CASE WHEN k.direction = N'LOWER' THEN 100.0 - k.score ELSE k.score END) * k.weight)
                                      / NULLIF(SUM(k.weight), 0), 1) AS DECIMAL(5, 1))
                      FROM #kpi k WHERE k.is_enabled = 1 AND k.score IS NOT NULL AND k.weight > 0);
    SET @rag = CASE WHEN @overall IS NULL THEN N'NA' WHEN @overall >= @ot THEN N'GREEN' WHEN @overall >= @ow THEN N'AMBER' ELSE N'RED' END;
    SET @items = (SELECT COUNT(*) FROM #item);

    SET @cur = (SELECT snapshot_id FROM grac_practice.asset_governance_snapshot
                 WHERE organization_id = @organization_id AND as_of_date = @today AND is_current = 1);
    IF @cur IS NOT NULL
       AND EXISTS (SELECT 1 FROM grac_practice.asset_governance_snapshot
                    WHERE snapshot_id = @cur AND items_purged = 0 AND overall_target = @ot AND overall_warning = @ow)
       AND NOT EXISTS (SELECT kpi_code, is_enabled, numerator, denominator, excluded_count, failing_count, target_value, warning_value, weight, period_days
                         FROM #kpi
                       EXCEPT
                       SELECT kpi_code, is_enabled, numerator, denominator, excluded_count, failing_count, target_value, warning_value, weight, period_days
                         FROM grac_practice.asset_governance_snapshot_kpi WHERE snapshot_id = @cur)
       AND NOT EXISTS (SELECT kpi_code, is_enabled, numerator, denominator, excluded_count, failing_count, target_value, warning_value, weight, period_days
                         FROM grac_practice.asset_governance_snapshot_kpi WHERE snapshot_id = @cur
                       EXCEPT
                       SELECT kpi_code, is_enabled, numerator, denominator, excluded_count, failing_count, target_value, warning_value, weight, period_days
                         FROM #kpi)
       AND NOT EXISTS (SELECT kpi_code, record_kind, record_id, outcome, numerator, denominator, reason FROM #item
                       EXCEPT
                       SELECT kpi_code, record_kind, record_id, outcome, numerator, denominator, reason
                         FROM grac_practice.asset_governance_snapshot_item WHERE snapshot_id = @cur)
       AND NOT EXISTS (SELECT kpi_code, record_kind, record_id, outcome, numerator, denominator, reason
                         FROM grac_practice.asset_governance_snapshot_item WHERE snapshot_id = @cur
                       EXCEPT
                       SELECT kpi_code, record_kind, record_id, outcome, numerator, denominator, reason FROM #item)
    BEGIN
        SET @out_snapshot_id = @cur;
    END
    ELSE
    BEGIN
        SET @ver = ISNULL((SELECT MAX(version_no) FROM grac_practice.asset_governance_snapshot
                            WHERE organization_id = @organization_id AND as_of_date = @today), 0) + 1;
        BEGIN TRAN;
        UPDATE grac_practice.asset_governance_snapshot
           SET is_current = 0, superseded_dt = SYSUTCDATETIME()
         WHERE snapshot_id = @cur;
        INSERT grac_practice.asset_governance_snapshot
            (organization_id, as_of_date, version_no, is_current, source_code, overall_score, overall_rag, overall_target,
             overall_warning, item_count, taken_by)
        VALUES (@organization_id, @today, @ver, 1, @source_code, @overall, @rag, @ot, @ow, @items, @actor);
        SET @out_snapshot_id = SCOPE_IDENTITY();
        INSERT grac_practice.asset_governance_snapshot_kpi
            (snapshot_id, kpi_code, is_enabled, numerator, denominator, excluded_count, failing_count, score, rag, direction,
             target_value, warning_value, weight, period_days)
        SELECT @out_snapshot_id, kpi_code, is_enabled, numerator, denominator, excluded_count, failing_count, score, rag, direction,
               target_value, warning_value, weight, period_days
          FROM #kpi;
        INSERT grac_practice.asset_governance_snapshot_item
            (snapshot_id, kpi_code, record_kind, record_id, record_name, outcome, numerator, denominator, reason)
        SELECT @out_snapshot_id, kpi_code, record_kind, record_id, record_name, outcome, numerator, denominator, reason
          FROM #item;
        INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
        VALUES (N'asset-governance-snapshot', @out_snapshot_id, N'SNAPSHOT',
                CASE WHEN @cur IS NULL THEN NULL ELSE (SELECT @cur AS supersededSnapshotId FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) END,
                (SELECT @organization_id AS organizationId, @today AS asOfDate, @ver AS versionNo, @source_code AS source,
                        @overall AS overallScore, @rag AS overallRag, @items AS records FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
                N'Active', @actor);
        COMMIT;
        SET @out_created = 1;
    END

    -- Record-detail retention (D174): the KPI rows stay; the latest snapshot keeps its records.
    SET @latest = (SELECT TOP (1) snapshot_id FROM grac_practice.asset_governance_snapshot
                    WHERE organization_id = @organization_id ORDER BY as_of_date DESC, version_no DESC);
    DELETE i
      FROM grac_practice.asset_governance_snapshot_item i
      JOIN grac_practice.asset_governance_snapshot s ON s.snapshot_id = i.snapshot_id
     WHERE s.organization_id = @organization_id AND s.snapshot_id <> @latest
       AND s.taken_dt < DATEADD(DAY, -@ret, SYSUTCDATETIME());
    UPDATE grac_practice.asset_governance_snapshot
       SET items_purged = 1
     WHERE organization_id = @organization_id AND snapshot_id <> @latest AND items_purged = 0
       AND taken_dt < DATEADD(DAY, -@ret, SYSUTCDATETIME());

    IF @suppress_result = 0
        SELECT @out_snapshot_id AS SnapshotId, CASE WHEN @out_created = 1 THEN N'CREATED' ELSE N'UNCHANGED' END AS Result;
END
GO
PRINT '450: snapshot procedure created.';
GO

-- =====================================================================
-- 6. Readers
-- =====================================================================
-- Scorecard of a snapshot (default: the current snapshot of the latest
-- date). 1. snapshot header  2. KPI rows with their definitions and the
-- previous date score  3. trend: current snapshot of each date in the
-- window (KpiCode OVERALL = the overall score).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_governance_get
    @organization_id BIGINT,
    @snapshot_id     BIGINT = NULL,
    @trend_days      INT    = 90
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53080, 'Organization not found.', 1;
    SET @trend_days = CASE WHEN ISNULL(@trend_days, 90) < 7 THEN 7 WHEN @trend_days > 366 THEN 366 ELSE @trend_days END;
    IF @snapshot_id IS NULL
    BEGIN
        SET @snapshot_id = (SELECT TOP (1) snapshot_id FROM grac_practice.asset_governance_snapshot
                             WHERE organization_id = @organization_id AND is_current = 1 ORDER BY as_of_date DESC);
    END
    ELSE IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_governance_snapshot
                         WHERE snapshot_id = @snapshot_id AND organization_id = @organization_id)
    BEGIN
        THROW 53083, 'Snapshot not found.', 1;
    END
    DECLARE @as_of DATE = (SELECT as_of_date FROM grac_practice.asset_governance_snapshot WHERE snapshot_id = @snapshot_id);

    -- 1. Header
    SELECT s.snapshot_id AS SnapshotId, s.as_of_date AS AsOfDate, s.version_no AS VersionNo, s.is_current AS IsCurrent,
           s.source_code AS SourceCode, s.overall_score AS OverallScore, s.overall_rag AS OverallRag,
           s.overall_target AS OverallTarget, s.overall_warning AS OverallWarning, s.item_count AS ItemCount,
           s.items_purged AS ItemsPurged, s.taken_by AS TakenBy, s.taken_dt AS TakenDt, s.superseded_dt AS SupersededDt,
           (SELECT COUNT(*) FROM grac_practice.asset_governance_snapshot x
             WHERE x.organization_id = s.organization_id AND x.as_of_date = s.as_of_date) AS VersionsOfDate,
           (SELECT TOP (1) p.overall_score FROM grac_practice.asset_governance_snapshot p
             WHERE p.organization_id = s.organization_id AND p.is_current = 1 AND p.as_of_date < s.as_of_date
             ORDER BY p.as_of_date DESC) AS PreviousOverallScore
      FROM grac_practice.asset_governance_snapshot s
     WHERE s.snapshot_id = @snapshot_id;

    -- 2. KPIs: definition + the snapshot row (+ effective settings when no snapshot yet)
    SELECT k.kpi_code AS KpiCode, k.kpi_name AS KpiName, k.formula_text AS FormulaText, k.numerator_text AS NumeratorText,
           k.denominator_text AS DenominatorText, k.population_text AS PopulationText, k.exclusions_text AS ExclusionsText,
           k.as_of_text AS AsOfText, k.record_label AS RecordLabel, k.brd_reference AS BrdReference, k.display_order AS DisplayOrder,
           ISNULL(sk.is_enabled, e.IsEnabled) AS IsEnabled, sk.numerator AS Numerator, sk.denominator AS Denominator,
           sk.excluded_count AS ExcludedCount, sk.failing_count AS FailingCount, sk.score AS Score, ISNULL(sk.rag, N'NA') AS Rag,
           ISNULL(sk.direction, k.direction) AS Direction, ISNULL(sk.target_value, e.TargetValue) AS TargetValue,
           ISNULL(sk.warning_value, e.WarningValue) AS WarningValue, ISNULL(sk.weight, e.Weight) AS Weight,
           CASE WHEN sk.snapshot_id IS NULL THEN e.PeriodDays ELSE sk.period_days END AS PeriodDays,
           prev.score AS PreviousScore
      FROM grac_practice.asset_governance_kpi k
      JOIN grac_practice.fn_asset_governance_effective(@organization_id) e ON e.KpiCode = k.kpi_code
      LEFT JOIN grac_practice.asset_governance_snapshot_kpi sk ON sk.snapshot_id = @snapshot_id AND sk.kpi_code = k.kpi_code
     OUTER APPLY (SELECT TOP (1) pk.score
                    FROM grac_practice.asset_governance_snapshot ps
                    JOIN grac_practice.asset_governance_snapshot_kpi pk ON pk.snapshot_id = ps.snapshot_id AND pk.kpi_code = k.kpi_code
                   WHERE ps.organization_id = @organization_id AND ps.is_current = 1 AND ps.as_of_date < @as_of
                   ORDER BY ps.as_of_date DESC) prev
     ORDER BY k.display_order;

    -- 3. Trend
    SELECT s.as_of_date AS AsOfDate, CAST(N'OVERALL' AS NVARCHAR(30)) AS KpiCode, s.overall_score AS Score, s.overall_rag AS Rag
      FROM grac_practice.asset_governance_snapshot s
     WHERE s.organization_id = @organization_id AND s.is_current = 1
       AND s.as_of_date BETWEEN DATEADD(DAY, -@trend_days, @as_of) AND @as_of
    UNION ALL
    SELECT s.as_of_date, sk.kpi_code, sk.score, sk.rag
      FROM grac_practice.asset_governance_snapshot s
      JOIN grac_practice.asset_governance_snapshot_kpi sk ON sk.snapshot_id = s.snapshot_id
     WHERE s.organization_id = @organization_id AND s.is_current = 1
       AND s.as_of_date BETWEEN DATEADD(DAY, -@trend_days, @as_of) AND @as_of
     ORDER BY AsOfDate, KpiCode;
END
GO

-- Drill-down: the record rows of one KPI of a snapshot (exact numerator,
-- denominator, excluded and failing records). @outcome PASS | FAIL |
-- EXCLUDED | empty (all). 1. rows (paged)  2. totals per outcome.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_governance_items
    @organization_id BIGINT,
    @snapshot_id     BIGINT,
    @kpi_code        NVARCHAR(30),
    @outcome         NVARCHAR(8)   = NULL,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @outcome = NULLIF(UPPER(LTRIM(RTRIM(@outcome))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53080, 'Organization not found.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_governance_snapshot WHERE snapshot_id = @snapshot_id AND organization_id = @organization_id)
        THROW 53083, 'Snapshot not found.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_governance_kpi WHERE kpi_code = @kpi_code)
        THROW 53081, 'Unknown KPI.', 1;

    SELECT i.record_kind AS RecordKind, i.record_id AS RecordId, i.record_name AS RecordName, i.outcome AS Outcome,
           i.numerator AS Numerator, i.denominator AS Denominator, i.reason AS Reason, COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_governance_snapshot_item i
     WHERE i.snapshot_id = @snapshot_id AND i.kpi_code = @kpi_code
       AND (@outcome IS NULL OR i.outcome = @outcome)
       AND (@search IS NULL OR i.record_name LIKE N'%' + @search + N'%' OR i.reason LIKE N'%' + @search + N'%'
            OR CAST(i.record_id AS NVARCHAR(20)) = @search)
     ORDER BY CASE i.outcome WHEN N'FAIL' THEN 0 WHEN N'EXCLUDED' THEN 2 ELSE 1 END, i.record_name, i.record_id
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;

    SELECT o.outcome AS Outcome, COUNT(i.record_id) AS ItemCount, ISNULL(SUM(i.numerator), 0) AS Numerator,
           ISNULL(SUM(i.denominator), 0) AS Denominator
      FROM (VALUES (N'PASS'), (N'FAIL'), (N'EXCLUDED')) o(outcome)
      LEFT JOIN grac_practice.asset_governance_snapshot_item i
             ON i.snapshot_id = @snapshot_id AND i.kpi_code = @kpi_code AND i.outcome = o.outcome
     GROUP BY o.outcome;
END
GO

-- Snapshot history (every version of every date, superseded ones too).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_governance_snapshots
    @organization_id BIGINT,
    @page_number     INT = 1,
    @page_size       INT = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53080, 'Organization not found.', 1;
    SELECT s.snapshot_id AS SnapshotId, s.as_of_date AS AsOfDate, s.version_no AS VersionNo, s.is_current AS IsCurrent,
           s.source_code AS SourceCode, s.overall_score AS OverallScore, s.overall_rag AS OverallRag, s.item_count AS ItemCount,
           s.items_purged AS ItemsPurged, s.taken_by AS TakenBy, s.taken_dt AS TakenDt, s.superseded_dt AS SupersededDt,
           r.green AS GreenCount, r.amber AS AmberCount, r.red AS RedCount, r.na AS NaCount, COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_governance_snapshot s
     CROSS APPLY (SELECT SUM(CASE WHEN k.rag = N'GREEN' THEN 1 ELSE 0 END) AS green, SUM(CASE WHEN k.rag = N'AMBER' THEN 1 ELSE 0 END) AS amber,
                         SUM(CASE WHEN k.rag = N'RED' THEN 1 ELSE 0 END) AS red, SUM(CASE WHEN k.rag = N'NA' THEN 1 ELSE 0 END) AS na
                    FROM grac_practice.asset_governance_snapshot_kpi k WHERE k.snapshot_id = s.snapshot_id) r
     WHERE s.organization_id = @organization_id
     ORDER BY s.as_of_date DESC, s.version_no DESC
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- Settings: 1. KPIs with defaults and the organization values  2. overall
-- thresholds and retention  3. relationship requirements  4. asset types
-- 5. relationship types an asset can take part in  6. the 441 minimum
-- supporting relationships of business services.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_governance_settings
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53080, 'Organization not found.', 1;
    SELECT k.kpi_code AS KpiCode, k.kpi_name AS KpiName, k.formula_text AS FormulaText, k.direction AS Direction,
           k.default_target AS DefaultTarget, k.default_warning AS DefaultWarning, k.default_weight AS DefaultWeight,
           k.default_period_days AS DefaultPeriodDays, e.IsEnabled, e.Weight, e.TargetValue, e.WarningValue, e.PeriodDays,
           e.IsCustomised, s.updated_by AS UpdatedBy, ISNULL(s.updated_dt, s.entered_dt) AS UpdatedDt
      FROM grac_practice.asset_governance_kpi k
      JOIN grac_practice.fn_asset_governance_effective(@organization_id) e ON e.KpiCode = k.kpi_code
      LEFT JOIN grac_practice.asset_governance_setting s ON s.organization_id = @organization_id AND s.kpi_code = k.kpi_code
     ORDER BY k.display_order;
    SELECT ISNULL(o.overall_target, 90.0) AS OverallTarget, ISNULL(o.overall_warning, 75.0) AS OverallWarning,
           ISNULL(o.item_retention_days, 90) AS ItemRetentionDays, o.updated_by AS UpdatedBy, ISNULL(o.updated_dt, o.entered_dt) AS UpdatedDt
      FROM (SELECT 1 AS one) x
      LEFT JOIN grac_practice.asset_governance_org_setting o ON o.organization_id = @organization_id;
    SELECT r.rule_id AS RuleId, r.asset_type_id AS AssetTypeId, t.asset_type_name AS AssetTypeName,
           r.relationship_type_code AS RelationshipTypeCode, rt.type_name AS TypeName, rt.inverse_label AS InverseLabel,
           r.asset_side AS AssetSide, r.min_count AS MinCount, r.is_active AS IsActive,
           ISNULL(r.updated_by, r.entered_by) AS UpdatedBy, ISNULL(r.updated_dt, r.entered_dt) AS UpdatedDt
      FROM grac_practice.asset_governance_relationship_rule r
      JOIN grac_practice.asset_relationship_type rt ON rt.type_code = r.relationship_type_code
      LEFT JOIN grac_practice.dependency_asset_type_master t ON t.asset_type_id = r.asset_type_id
     WHERE r.organization_id = @organization_id
     ORDER BY t.asset_type_name, rt.display_order, r.asset_side;
    SELECT t.asset_type_id AS AssetTypeId, t.asset_type_name AS AssetTypeName
      FROM grac_practice.dependency_asset_type_master t
     WHERE t.is_active = 1
     ORDER BY t.asset_type_name;
    SELECT rt.type_code AS TypeCode, rt.type_name AS TypeName, rt.inverse_label AS InverseLabel,
           CAST(CASE WHEN N',' + REPLACE(rt.source_kinds, N' ', N'') + N',' LIKE N'%,ASSET,%' THEN 1 ELSE 0 END AS BIT) AS AssetAsSource,
           CAST(CASE WHEN N',' + REPLACE(rt.target_kinds, N' ', N'') + N',' LIKE N'%,ASSET,%' THEN 1 ELSE 0 END AS BIT) AS AssetAsTarget
      FROM grac_practice.asset_relationship_type rt
     WHERE rt.is_active = 1
       AND (N',' + REPLACE(rt.source_kinds, N' ', N'') + N',' LIKE N'%,ASSET,%'
            OR N',' + REPLACE(rt.target_kinds, N' ', N'') + N',' LIKE N'%,ASSET,%')
     ORDER BY rt.display_order;
    SELECT ISNULL((SELECT bs.min_supporting_relationships FROM grac_practice.business_service_setting bs
                    WHERE bs.organization_id = @organization_id), 1) AS MinSupportingRelationships;
END
GO
PRINT '450: readers created.';
GO

-- =====================================================================
-- 7. Writers (asset-governance EDIT)
-- =====================================================================
-- One KPI of the organization. @reset = 1 removes the row (catalogue
-- defaults again). Higher-is-better: warning <= target; lower-is-better:
-- warning >= target. The period applies only to KPIs that have one.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_governance_setting_save
    @organization_id BIGINT,
    @kpi_code        NVARCHAR(30),
    @reset           BIT           = 0,
    @is_enabled      BIT           = 1,
    @weight          INT           = NULL,
    @target_value    DECIMAL(5, 1) = NULL,
    @warning_value   DECIMAL(5, 1) = NULL,
    @period_days     INT           = NULL,
    @actor           NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53080, 'Organization not found.', 1;
    DECLARE @direction NVARCHAR(6), @has_period INT;
    SELECT @direction = direction, @has_period = CASE WHEN default_period_days IS NULL THEN 0 ELSE 1 END
      FROM grac_practice.asset_governance_kpi WHERE kpi_code = @kpi_code;
    IF @direction IS NULL THROW 53081, 'Unknown KPI.', 1;
    IF ISNULL(@reset, 0) = 0
    BEGIN
        IF @weight IS NULL OR @weight NOT BETWEEN 0 AND 100
            THROW 53082, 'The weight must be between 0 and 100.', 1;
        IF @target_value IS NULL OR @warning_value IS NULL OR @target_value NOT BETWEEN 0 AND 100 OR @warning_value NOT BETWEEN 0 AND 100
            THROW 53082, 'Target and warning thresholds must be between 0 and 100.', 1;
        IF @direction = N'HIGHER' AND @warning_value > @target_value
            THROW 53082, 'For this KPI higher is better: the warning threshold cannot be above the target.', 1;
        IF @direction = N'LOWER' AND @warning_value < @target_value
            THROW 53082, 'For this KPI lower is better: the warning threshold cannot be below the target.', 1;
        IF @has_period = 1 AND (@period_days IS NULL OR @period_days NOT BETWEEN 1 AND 3650)
            THROW 53082, 'The period must be between 1 and 3650 days.', 1;
        IF @has_period = 0 SET @period_days = NULL;
    END

    DECLARE @before NVARCHAR(MAX) = (SELECT s.is_enabled AS isEnabled, s.weight AS weight, s.target_value AS targetValue,
                                            s.warning_value AS warningValue, s.period_days AS periodDays
                                       FROM grac_practice.asset_governance_setting s
                                      WHERE s.organization_id = @organization_id AND s.kpi_code = @kpi_code
                                        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    BEGIN TRAN;
    IF ISNULL(@reset, 0) = 1
    BEGIN
        DELETE FROM grac_practice.asset_governance_setting WHERE organization_id = @organization_id AND kpi_code = @kpi_code;
    END
    ELSE
    BEGIN
        UPDATE grac_practice.asset_governance_setting
           SET is_enabled = ISNULL(@is_enabled, 1), weight = @weight, target_value = @target_value, warning_value = @warning_value,
               period_days = @period_days, updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE organization_id = @organization_id AND kpi_code = @kpi_code;
        IF @@ROWCOUNT = 0
            INSERT grac_practice.asset_governance_setting
                (organization_id, kpi_code, is_enabled, weight, target_value, warning_value, period_days, entered_by)
            VALUES (@organization_id, @kpi_code, ISNULL(@is_enabled, 1), @weight, @target_value, @warning_value, @period_days, @actor);
    END
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-governance-setting', @organization_id, CASE WHEN ISNULL(@reset, 0) = 1 THEN N'RESET' ELSE N'SAVE' END, @before,
            (SELECT @kpi_code AS kpiCode, CASE WHEN ISNULL(@reset, 0) = 1 THEN NULL ELSE ISNULL(@is_enabled, 1) END AS isEnabled,
                    @weight AS weight, @target_value AS targetValue, @warning_value AS warningValue, @period_days AS periodDays
               FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @organization_id AS OrganizationId, @kpi_code AS KpiCode, CASE WHEN ISNULL(@reset, 0) = 1 THEN N'RESET' ELSE N'SAVED' END AS Result;
END
GO

-- Overall thresholds and record-detail retention of the organization.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_governance_org_setting_save
    @organization_id     BIGINT,
    @overall_target      DECIMAL(5, 1),
    @overall_warning     DECIMAL(5, 1),
    @item_retention_days INT,
    @actor               NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53080, 'Organization not found.', 1;
    IF @overall_target IS NULL OR @overall_warning IS NULL OR @overall_target NOT BETWEEN 0 AND 100
       OR @overall_warning NOT BETWEEN 0 AND 100 OR @overall_warning > @overall_target
        THROW 53089, 'Overall thresholds must be between 0 and 100, the warning not above the target.', 1;
    IF @item_retention_days IS NULL OR @item_retention_days NOT BETWEEN 7 AND 3650
        THROW 53089, 'Record detail is kept between 7 and 3650 days.', 1;
    DECLARE @before NVARCHAR(MAX) = (SELECT o.overall_target AS overallTarget, o.overall_warning AS overallWarning,
                                            o.item_retention_days AS itemRetentionDays
                                       FROM grac_practice.asset_governance_org_setting o
                                      WHERE o.organization_id = @organization_id FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    BEGIN TRAN;
    UPDATE grac_practice.asset_governance_org_setting
       SET overall_target = @overall_target, overall_warning = @overall_warning, item_retention_days = @item_retention_days,
           updated_by = @actor, updated_dt = SYSUTCDATETIME()
     WHERE organization_id = @organization_id;
    IF @@ROWCOUNT = 0
        INSERT grac_practice.asset_governance_org_setting (organization_id, overall_target, overall_warning, item_retention_days, entered_by)
        VALUES (@organization_id, @overall_target, @overall_warning, @item_retention_days, @actor);
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-governance-org-setting', @organization_id, N'SAVE', @before,
            (SELECT @overall_target AS overallTarget, @overall_warning AS overallWarning, @item_retention_days AS itemRetentionDays
               FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @organization_id AS OrganizationId, N'SAVED' AS Result;
END
GO

-- Relationship requirement of an asset type (new when @rule_id is NULL).
-- Type, relationship and side are fixed once saved; deactivate instead of
-- deleting (IsActive = 0).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_governance_relationship_rule_save
    @organization_id        BIGINT,
    @rule_id                BIGINT        = NULL,
    @asset_type_id          INT           = NULL,
    @relationship_type_code NVARCHAR(30)  = NULL,
    @asset_side             NVARCHAR(6)   = NULL,
    @min_count              INT           = 1,
    @is_active              BIT           = 1,
    @actor                  NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @asset_side = NULLIF(UPPER(LTRIM(RTRIM(@asset_side))), N'');
    SET @relationship_type_code = NULLIF(UPPER(LTRIM(RTRIM(@relationship_type_code))), N'');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53080, 'Organization not found.', 1;
    IF @min_count IS NULL OR @min_count NOT BETWEEN 1 AND 50
        THROW 53087, 'The minimum is between 1 and 50 relationships.', 1;
    DECLARE @before NVARCHAR(MAX);
    IF @rule_id IS NOT NULL
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_governance_relationship_rule
                        WHERE rule_id = @rule_id AND organization_id = @organization_id)
            THROW 53086, 'Relationship requirement not found.', 1;
        SET @before = (SELECT r.min_count AS minCount, r.is_active AS isActive
                         FROM grac_practice.asset_governance_relationship_rule r WHERE r.rule_id = @rule_id
                          FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    END
    ELSE
    BEGIN
        IF @asset_type_id IS NULL OR NOT EXISTS (SELECT 1 FROM grac_practice.dependency_asset_type_master WHERE asset_type_id = @asset_type_id)
            THROW 53084, 'Asset type not found.', 1;
        IF @asset_side IS NULL OR @asset_side NOT IN (N'SOURCE', N'TARGET')
            THROW 53087, 'Choose whether the asset is the source or the target of the relationship.', 1;
        IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_relationship_type rt
                        WHERE rt.type_code = @relationship_type_code AND rt.is_active = 1
                          AND N',' + REPLACE(CASE @asset_side WHEN N'SOURCE' THEN rt.source_kinds ELSE rt.target_kinds END, N' ', N'') + N','
                              LIKE N'%,ASSET,%')
            THROW 53085, 'Relationship type not found, inactive, or an asset cannot be on that side of it.', 1;
        IF EXISTS (SELECT 1 FROM grac_practice.asset_governance_relationship_rule
                    WHERE organization_id = @organization_id AND asset_type_id = @asset_type_id
                      AND relationship_type_code = @relationship_type_code AND asset_side = @asset_side)
            THROW 53088, 'A requirement for this asset type, relationship and side exists; change it instead.', 1;
    END

    BEGIN TRAN;
    IF @rule_id IS NOT NULL
    BEGIN
        UPDATE grac_practice.asset_governance_relationship_rule
           SET min_count = @min_count, is_active = ISNULL(@is_active, 1), updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE rule_id = @rule_id;
    END
    ELSE
    BEGIN
        INSERT grac_practice.asset_governance_relationship_rule
            (organization_id, asset_type_id, relationship_type_code, asset_side, min_count, is_active, entered_by)
        VALUES (@organization_id, @asset_type_id, @relationship_type_code, @asset_side, @min_count, ISNULL(@is_active, 1), @actor);
        SET @rule_id = SCOPE_IDENTITY();
    END
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-governance-relationship-rule', @rule_id, CASE WHEN @before IS NULL THEN N'CREATE' ELSE N'UPDATE' END, @before,
            (SELECT r.organization_id AS organizationId, r.asset_type_id AS assetTypeId, r.relationship_type_code AS relationshipTypeCode,
                    r.asset_side AS assetSide, r.min_count AS minCount, r.is_active AS isActive
               FROM grac_practice.asset_governance_relationship_rule r WHERE r.rule_id = @rule_id FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @rule_id AS RuleId, CASE WHEN @before IS NULL THEN N'CREATED' ELSE N'SAVED' END AS Result;
END
GO
PRINT '450: writers created.';
GO
