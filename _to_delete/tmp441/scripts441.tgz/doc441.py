import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (a[:60], s.count(a))
    s = s.replace(a, b)

rep("impact analysis and the retirement gate (`440`).",
    "impact analysis and the retirement gate (`440`), Phase 7.2 business services -- register, consumers, supporting items, activation / retirement rules, conflicts, hierarchy and service impact (`441`).")
rep("| 7.2 | Business services (5.5): service hierarchy, owners, criticality / CIA, RTO / RPO / MTPD, supporting assets and services (Supports Service), supplier / contract dependencies, activation and retirement rules, conflict warnings, service impact | | 7.1 |",
    "| 7.2 **(done)** | Business services (5.5): service register (ID, name, type, description / outcome, business owner, service manager, accountable department, criticality, CIA 1-5, RTO / RPO / MTPD, service hours, SLA, data / privacy classification, review date, status Draft-Retired, history); consumers (departments, business functions, locations, external); supporting assets, applications, processes, suppliers, contracts and child services as Supports Service relationships with a role; activation (owner + minimum support) and retirement (no critical dependants, consumer review, contract assessment, approval) rules; validation conflicts; hierarchy; service impact | 441 | 7.1 |")
rep("""| D33 | **Cancel keeps the asset status** (433)""",
"""| D88 | **Service register** (441): service ID and name unique per organization; type Business / Customer-facing / Technical / Shared / Supporting; business owner and service manager (employees); accountable department (the "accountable organization"); criticality from the criticality master; confidentiality / integrity / availability rated 1-5; RTO / RPO / MTPD in hours (RTO not above MTPD); service hours, SLA, data and privacy classification as text; review date. Consumers ("legal entity / units") are departments, business functions, locations or named external consumers. Every save and status change is a numbered history row with a snapshot. | BRD 5.5. | Yes. |
| D89 | **Supporting items** are Supports Service relationships (440 rules -- proposal, approval, another approver for critical, pending changes, effective dates, history), now active: assets, applications, processes, suppliers, contracts (new item kind) and child services support a service, each with an optional role. The hierarchy is these service-to-service links (no separate parent field); a service may support several parents. Mappings proposed from the service window are approved in Asset Relationships (and need its permissions). | BRD 5.5, 5.5.1. | Yes. |
| D90 | **Status model**: Draft -> Design / Retired; Design -> Draft / Active / Retired; Active -> Degraded / Suspended / Retiring; Degraded -> Active / Suspended / Retiring; Suspended -> Active / Retiring; Retiring -> Active / Retired. A note is required except for Draft / Design moving forward. Saving changes (including objectives of an active service) needs no approval -- the BRD asks approval for retirement only. | BRD 5.5. | Yes. |
| D91 | **Activation** (every move to Active) needs a business owner and the organization minimum of active, currently effective supporting relationships (default 1; setting 0-50). | BRD 5.5.1. | Yes. |
| D92 | **Retirement**: Retiring -> Retired needs no active critical relationship relying on the service (440 blockers), the consumer review and contract assessment notes, and approval by another person where configured (default on; the requester can withdraw). Draft / Design -> Retired (never in operation) needs only the dependant check and a note. Retiring ends every current relationship to or from the service (kept in their history). "Dependency migration" = retire or accept the critical dependants first. | BRD 5.5.1. | Yes. |
| D93 | **Conflicts** (warnings, no tasks): supporting asset / application / supplier / child service rated less critical than the service; supporting asset RPO (register text such as "4 hours") longer than the service RPO; child service RTO / RPO longer than the parent; supporting item no longer in use; disputed mapping; Active / Degraded service without owner or active support; review date passed. The asset recovery tier (an option list) and CIA ratings are not compared. | BRD 5.5.1. | Yes. |
| D94 | **Service impact**: the 440 impact analysis also returns the business services reached (level, status, criticality, RTO / RPO / MTPD, owner, manager, consumers); affected processes and locations are in its item list. Business Services -> Service impact runs it downstream at depth 10. | BRD 5.5.1, 5.5.2. | Yes. |
| D95 | **Contracts as items** are usable until terminated; their owner is the owner of the current version. | BRD 5.5 "supplier / contract dependencies". | Yes. |
| D96 | **Not in 7.2**: tasks raised from conflicts; review-date reminders through notification profiles; service dashboards and exports (Phase 8); a consumer-review workflow (recorded as a note). | BRD 5.5.1, 5.5.2. | Yes. |
| D33 | **Cancel keeps the asset status** (433)""")
rep("""### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""",
"""### Business services (441)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `business-services/config?organizationId=` | `{settings, employees, departments, businessFunctions, locations, criticalities}` | `sp_business_service_config_get` |
| GET | `business-services?organizationId=&status=&serviceType=&search=&pageNumber=&pageSize=` | Services (status empty = all but Retired; ALL) with support, supports, consumer and conflict counts | `sp_business_services` |
| GET | `business-services/{id}?organizationId=` | `{service, consumers, supporting, supports, conflicts, history}` | `sp_business_service_get` |
| POST | `business-services` | `{organizationId, serviceId?, serviceCode, serviceName, serviceType, description?, customerOutcome?, businessOwnerEmployeeId?, serviceManagerEmployeeId?, accountableDepartmentId?, criticalityId?, confidentialityRating?, integrityRating?, availabilityRating?, rtoHours?, rpoHours?, mtpdHours?, serviceHours?, slaText?, dataClassification?, privacyClassification?, reviewDate?, consumers?: [{consumerKind, consumerRefId?, consumerName?, note?}], expectedRecordVersion?}` -> CREATED / SAVED | `sp_business_service_save` |
| POST | `business-services/{id}/transition` | `{organizationId, toStatus, note?, consumerReviewNote?, contractAssessmentNote?, expectedRecordVersion?}` -> new status or PENDING_APPROVAL | `sp_business_service_transition` |
| POST | `business-services/{id}/retirement-decision` | `{organizationId, decision: APPROVE \\| REJECT \\| WITHDRAW, decisionNote?, expectedRecordVersion?}` | `sp_business_service_retirement_decide` |
| POST | `business-services/settings` | `{organizationId, minSupportingRelationships, retirementApprovalRequired}` | `sp_business_service_setting_save` |
| GET | `business-services/conflicts?organizationId=&serviceId=&search=&pageNumber=&pageSize=` | Validation warnings | `sp_business_service_conflicts` |
| GET | `business-services/tree?organizationId=` | `{services, links}` (child -> parent) | `sp_business_service_tree` |

Changed in 441: `relationships` (save) takes `serviceRole`; relationship rows return `serviceRole`; item kinds add CONTRACT (and SERVICE is usable); `relationships/impact` returns `services` (business services reached). Proxy area `business-services`: GETs VIEW; new service ADD, change EDIT; transition and settings EDIT; retirement decision APPROVE / REJECT -> APPROVE, WITHDRAW -> EDIT. Errors `54730-54751`; 54730 / 54731 -> 404, 54732 / 54747 -> 409.

### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""")
rep("""## 8. Verification (static -- no compiler or database on this machine)""",
"""### Phase 7.2 files (441)
| Layer | File | Change |
|---|---|---|
| DB | `database/441_business_services.sql` (+ rollback restoring the seven 440 bodies) | Service, consumer, history and setting tables; relationship role column and CONTRACT kind; Supports Service active; consumers, duration and conflict functions; save, retire, transition, retirement decision, settings and readers; menu row. Re-issued: `fn_asset_ci_catalog`, `sp_asset_relationship_history_add`, `sp_asset_relationship_save`, `sp_asset_relationship_action`, `sp_asset_relationships`, `sp_asset_relationship_get`, `sp_asset_ci_impact`. |
| DB | `database/274_menu_master_seed.sql` | `business-services` (362) under `nav-asset-contract`. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 9 routes; service, transition, setting requests; relationship role; impact services. |
| API / Web | `appsettings.json` (both) | `business-services:*` for PM_ORG_ADMIN. |
| Web | `Controllers/AssetConfigController.cs`, `Models/PracticeScreen.cs`, `Views/Practice/Manage.cshtml` | Service permissions; Business Services screen. |
| Web | `Partials/business-services.cshtml`, `js/AssetConfig/business-services.js` (new) | Services, service window (fields, consumers, status, supporting items, supports, conflicts, history), hierarchy, conflicts, service impact, settings. |
| Web | `Partials/asset-relationships.cshtml`, `js/AssetConfig/asset-relationships.js` | Role field, contract and service kinds, business services reached in the impact analysis. |

## 8. Verification (static -- no compiler or database on this machine)""")
s = s.rstrip('\n') + """

441 got the same sweep (clean; one semicolon before ELSE replaced by BEGIN / END), the reserved-alias scan (none), a parameter-name check of every internal EXEC, a diff of the seven re-issued relationship bodies against their 440 sources (only marked lines; one inserted column was first placed after an end-of-line marker that commented out the next column -- caught by a scan of every marker line and fixed, and the 439 / 440 marker lines were scanned the same way), the C#-to-procedure parameter cross-check for all 14 bound procedures, the JS-to-alias and HTML-id / duplicate-id checks on both screens, `node --check`, brace / parenthesis / bracket balance of the five edited C# files, both `appsettings.json` parse, the ASCII check and the Razor scan. Its verification block checks the tables, the relationship changes, the functions and eleven procedures, the re-issues, the duration parsing and the menu row. Not compiled or executed. Not yet done: discovery and reconciliation (7.3); tasks from conflicts; service review reminders; service dashboards (Phase 8).
"""
open(p, 'w', encoding='utf-8', newline='').write(s)
print('doc ok')
