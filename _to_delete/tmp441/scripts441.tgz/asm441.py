B='/home/claude/'
def g(n): return open(B+'b441/new_'+n+'.sql').read()
re1 = """
-- =====================================================================
-- 6. Re-issued 440 relationship bodies (441 lines marked; the rest verbatim)
-- =====================================================================
-- 440 body + business services and contracts as configuration items.
""" + g('fn_asset_ci_catalog') + """
-- 440 body + the role in the snapshot.
""" + g('sp_asset_relationship_history_add') + """
-- 440 body + the role of the mapping.
""" + g('sp_asset_relationship_save') + """
-- 440 body + the role in a pending change.
""" + g('sp_asset_relationship_action') + """
-- 440 body + ServiceRole.
""" + g('sp_asset_relationships') + """
-- 440 body + ServiceRole.
""" + g('sp_asset_relationship_get') + """
-- 440 body + 3. the business services reached, with owners, continuity
-- objectives and consumers (5.5.1).
""" + g('sp_asset_ci_impact') + """PRINT '441: relationship bodies re-issued.';
GO
"""
full=open(B+'441_a.sql').read()+open(B+'441_b.sql').read()+re1+open(B+'441_c.sql').read()+open(B+'441_d.sql').read()+"\n"+open(B+'441_f.sql').read()
assert all(ord(c)<128 for c in full)
open(B+'441.sql','w',newline='').write(full); print('441.sql', full.count('\n'))
