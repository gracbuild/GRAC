import sys
R = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w451/new'
P = R + '/docs/asset-contract-management.md'
def edit(old, new, count=1):
    s = open(P).read(); assert s.count(old) == count, (old[:80], s.count(old)); open(P, 'w').write(s.replace(old, new))

edit("""the overall score, trend and history (`450`).""",
"""the overall score, trend and history (`450`), Phase 8.4b the Asset & Contract module dashboard -- governance, register, technology, contracts and coverage, attestation, activities, privacy, CMDB quality and discovery, services, relationships and notification sections with drill-down into the asset screens (`451`).""")

edit("""| 8.4b | Asset & Contract module dashboards (13.1 executive / owner / contract / privacy / attestation, 13.2 technology lifecycle, 13.3 notification and configuration, 13.5 CMDB quality / business service / discovery operations, 19.10 service widgets) on the management-dashboard framework | | 8.4a |
""", """| 8.4b **(done)** | Asset & Contract module dashboard (13.1 executive / owner / contract / biomedical / privacy / attestation, 13.2.2 technology KPI cards, 13.3 notification operations, 13.5 CMDB quality / business service / discovery operations / governance, 19.10 service widgets) on the management-dashboard framework: Asset & Contract -> Dashboard (first child), eleven sections shown by screen permission, KPI tiles, ageing, distributions and lists; tiles and bars open the asset screens on the same filter (tab / status / kind / pending) with the drill banner | 451 | 8.4a |
| 8.5 | Report catalogue (13.4) and exports (13.2.7 exports with user, tenant, date and filters) | | 8.4b |
""")
s = open(P).read()
assert "| 8.5 | Report catalogue (13.4) and exports | | 8.4 |\n" in s
edit("""| 8.5 | Report catalogue (13.4) and exports | | 8.4 |
""", "")

edit("""| D141 | **Not in 8.1**:""", """| D184 | **One module dashboard** (451) for Asset & Contract on the 414 / 416 framework: screen `asset-contract-dashboard` (menu Dashboard, 348, the first child of Asset & Contract), procedure `sp_dashboard_asset_contract` (KPIs, ageing, distributions, lists), the shared partial and script. The BRD lists many dashboards (13.1 seven, 13.2, 13.3 four, 13.5 five, 19.10); they are sections of this one page rather than separate pages. | Reuse; 416 "Dashboard first child" convention. | Yes -- a section can be split into its own page later. |
| D185 | **Sections and access**: governance (asset-governance), assets and technology (asset-register), contracts (asset-contracts), attestation (asset-attestation), activities (asset-activities), privacy (asset-privacy), discovery (asset-discovery), services (business-services), relationships (asset-relationships), notifications (asset-notifications). The page needs VIEW on its own row and on at least one of these screens; only the sections whose screen the caller may VIEW are shown (`ManagementDashboards`). 451 grants VIEW on the row to every role that can VIEW one of them (416 rule) and PM_ORG_ADMIN gets `asset-contract-dashboard:VIEW`. Re-login needed. | 416. | Yes. |
| D186 | **One definition per bucket**: every count uses the rule its screen lists with -- register status (current status, else the legacy map, as `sp_asset_register_list`), attestation display status (open and past due = Overdue, as `sp_asset_attestation_list`), coverage gaps (`fn_asset_coverage_gaps`), privacy status (`fn_asset_privacy_status`), reconciliation queue (Open), stale list (`fn_asset_stale_state` listed), data confidence, service conflicts (`fn_business_service_conflicts`), relationship / service / notification status. "In use" is the 450 rule. | 13.2.7 / 9.1.11 "totals reconcile with detailed records". | Yes. |
| D187 | **Drill-down**: a tile or bar is a link only when its screen can show exactly that set; it opens the screen with `organizationId`, `tab`, `status`, `kind` or `pending` (new in `dashboard-drill.js`), the screen preselects its own filter and tab and shows the drill banner (Clear filter / Dashboard). Counts a screen cannot filter to (in use, no owner, overdue activities, ending in 30 / 90 days, reviews overdue, sources needing attention, technology) are not links; the technology and attestation lists open the asset (Asset Register, `?assetId=`) or the overdue list. An ageing band is a link only where the page filters by age (none of the asset screens, so their bands are not links -- the 414 dashboards are unchanged). | 414 rule "an unfiltered list under a tile would lie". | Yes. |
| D188 | **Technology** (13.2.2): assets in use with any applicable technology Unsupported, Due soon (support ending), Unknown or on an Exception (430 classification), approved technology exceptions expiring in 30 days; firmware and operating-system distributions; list of unsupported / unknown with support end. Campaign progress, refresh pipeline and criticality-based critical exposure are not shown: there is no technology campaign workflow and asset criticality levels are organization data with no fixed "critical" level. | 13.2.2. | Yes. |
| D189 | **Contracts** (13.1 Contract): Active, ending in 30 / 90 days (effective end of the version in force), Expired, open renewals, coverage gaps; list of active contracts ending in 90 days. Spend, entitlement and SLA widgets are left to the report catalogue (8.5). | 13.1. | Yes. |
| D190 | **Attestation / activities / privacy** (13.1 Asset Attestation, Biomedical, Privacy): attestation by display status, verification exceptions not closed, open attestations by age; open / overdue / due-in-30-days activities, restrictive-use reviews open, open activities by type, overdue list; privacy -- personal data assets, Non-compliant, Incomplete, Undetermined, reviews overdue, exceptions awaiting approval, assets by privacy status. | 13.1. | Yes. |
| D191 | **CMDB, services, relationships, notifications** (13.5, 13.3, 19.10): open reconciliation exceptions (conflicts, duplicates), stale assets, active sources needing attention (never run, failed / partial, or past the expected interval -- the 442 health rule), open reconciliation by kind and age, data confidence; services in operation, degraded, conflicts, no owner, review date passed; relationships active, awaiting approval, disputed, active critical; notification occurrences open, escalated, failed deliveries, open occurrences by activity. Governance: overall score of the latest current snapshot (rounded to a whole number on the tile), KPIs below threshold / at warning / on target, failing records; shown once a snapshot exists. | 13.5, 13.3, 19.10. | Yes. |
| D192 | **Asset screens read the drill** (asset-register, asset-contracts, asset-attestation, asset-activities, asset-privacy, asset-discovery, business-services, asset-relationships, asset-notifications): one script include and three lines at the end of their initialisation; opened without drill parameters they behave exactly as before. | -- | Yes. |
| D193 | **Error number 53090** (organization required). Not in 8.4b: charts beyond the shared tiles and bars; the 13.3 Form Configuration / Form Governance widgets (the Form Templates screen already lists templates by status, version and approval); exports (8.5). | -- | Yes. |
| D141 | **Not in 8.1**:""")

edit("""### Rule semantics (421 -- the BRD is silent on these, so they are stated here)
""", """### Asset & Contract dashboard (451)

| Tier | Route | Proc |
|---|---|---|
| Web proxy | `GET /practice/api/management-dashboard/asset-contract?organizationId=` (page and section rule of `ManagementDashboards`) | -- |
| API | `GET /api/practice/management-dashboard/asset-contract?organizationId=` -> `{module, kpis, ageing, distributions, lists}` (the 414 contract) | `sp_dashboard_asset_contract` |

Sections (`SectionKey`): governance, assets, technology, contracts, attestation, activities, privacy, discovery, services, relationships, notifications. Ageing groups: attestation, discovery. Distribution groups: assets_status, assets_value, technology_firmware, technology_os, contracts_status, attestation_status, activities_template, privacy_status, discovery_kind, discovery_confidence, services_status, relationships_status, notifications_activity. Lists: technology_unsupported, contracts_expiring, attestation_overdue, activities_overdue. Drill parameters read by the asset screens (`Shared/dashboard-drill.js`): `organizationId`, `tab`, `status`, `kind`, `pending`, `drillLabel`, `from`.

### Rule semantics (421 -- the BRD is silent on these, so they are stated here)
""")

edit("""### Phase 8.4a files (450)
""", """### Phase 8.4b files (451)
| Layer | File | Change |
|---|---|---|
| DB | `database/451_asset_contract_dashboard.sql` (+ rollback) | `sp_dashboard_asset_contract`; menu row `asset-contract-dashboard` (348) and VIEW grants (416 rule). |
| DB | `database/274_menu_master_seed.sql` | Dashboard row and parent link (fresh installs). |
| API | `Services/ManagementDashboardService.cs`, `appsettings.json` | Module `asset-contract`; PM_ORG_ADMIN `asset-contract-dashboard:VIEW`. |
| Web | `Models/ManagementDashboards.cs`, `Models/PracticeScreen.cs`, `appsettings.json` | Sections of the dashboard; screen entry. |
| Web | `js/ManagementDashboard/management-dashboard.js` | Targets, tile / bar drills and list links of the asset sections; an ageing band links only where the page filters by age. |
| Web | `js/Shared/dashboard-drill.js` | `tab`, `kind`, `pending`; `preselectFor` / `showOnPage` for screens that filter in the page. |
| Web | Partials and scripts of asset-register, asset-contracts, asset-attestation, asset-activities, asset-privacy, asset-discovery, business-services, asset-relationships, asset-notifications | Include `dashboard-drill.js`; preselect organization, filter and tab from the drill; banner. |

### Phase 8.4a files (450)
""")

s = open(P).read()
tail = "Not compiled or executed. Next: 8.4b (Asset & Contract module dashboards).\n"
assert s.endswith(tail)
s += """
451 got the same sweep (clean), the semicolon-before-ELSE and comment-apostrophe scans, a declared-variable scan, a check that every ItemKey a bar passes is an option of the filter it lands on (register status, contract status, attestation display status, privacy status, reconciliation kind, data confidence, service and relationship status), that every filter element and tab the drill map names exists on its screen, brace / parenthesis / bracket balance of the three edited C# files, `node --check` of every edited script, JSON parse of both appsettings files, the ASCII check and a re-run of the patch script on the base files reproducing the delivered copies. Its verification block checks the procedure, that Dashboard is the first Active child of Asset & Contract, and runs the dashboard for the first organization with assets. Not compiled or executed. Next: 8.5 (report catalogue and exports).
"""
open(P, 'w').write(s)
print('doc patched')
