# 444: the 429 verification checks govern the user lifecycle matrix (role-free
# rules); the role-bound merge rules of 444 (ASSET_MERGE) are not user moves.
p = "database/429_asset_lifecycle_transitions.sql"
s = open(p, encoding="utf-8").read()
a = """       CASE WHEN NOT EXISTS (SELECT 1 FROM grac_practice.entity_state_transition_rule r
                              WHERE r.entity_type = N'Asset' AND r.from_status_code IS NOT NULL
"""
b = """       CASE WHEN NOT EXISTS (SELECT 1 FROM grac_practice.entity_state_transition_rule r
                              WHERE r.entity_type = N'Asset' AND r.from_status_code IS NOT NULL
                                AND r.actor_role_code IS NULL   -- 444: role-bound merge rules have no gate
"""
assert s.count(a) == 1; s = s.replace(a, b)
a = """                              WHERE entity_type = N'Asset' AND is_active = 1
                                AND from_status_code IN (N'DISPOSED', N'ARCHIVED') AND to_status_code <> N'ARCHIVED')
"""
b = """                              WHERE entity_type = N'Asset' AND is_active = 1
                                AND actor_role_code IS NULL   -- 444: merge recovery (ASSET_MERGE) is not a user move
                                AND from_status_code IN (N'DISPOSED', N'ARCHIVED') AND to_status_code <> N'ARCHIVED')
"""
assert s.count(a) == 1; s = s.replace(a, b)
open(p, "w", encoding="utf-8", newline="").write(s)
print("p444_429 ok")
