# 439 -- Asset Activities screen: occurrence detail (result, review, dispositions),
# restrictive-use reviews tab, settings, evidence fields. Run from the repository root.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    return s

V = 'src/PracticeManagement.Web/Views/Practice/Partials/asset-activities.cshtml'
J = 'src/PracticeManagement.Web/wwwroot/js/AssetConfig/asset-activities.js'
files = {}

files[V] = edit(V, [
("""    keeping its own task. "Templates" holds the organization settings.
""",
"""    keeping its own task. "Templates" holds the organization settings.

    Phase 6.3 (migration 439): an occurrence opens in a detail window with
    its result (Pass / Fail, Renewed / Not renewed, performed date,
    certificate, evidence reference -- submitted, then approved or returned
    by another person when the activity needs a reviewer, 7.1.2 / 7.1.6),
    reschedule / waive / not applicable / exception requests with reason and
    approver (7.1.5) and the restrictive-use reviews of the asset.
    "Restrictive reviews" lists the 9.1.9 reviews (failed or overdue
    calibration, expired licence, expired insurance / fitness / permit /
    registration) and records the decision.
"""),
("""    var aacCanEdit = aacHas("EDIT");
}""",
"""    var aacCanEdit = aacHas("EDIT");
    var aacCanApprove = aacHas("APPROVE");   // 439: result review, disposition and restrictive-use decisions
}"""),
("""<div id="aacRoot" data-can-edit="@(aacCanEdit ? "1" : "0")">""",
"""<div id="aacRoot" data-can-edit="@(aacCanEdit ? "1" : "0")" data-can-approve="@(aacCanApprove ? "1" : "0")">"""),
("""            <button role="tab" data-aac-main="CAMPAIGNS" aria-selected="false">Campaigns</button>""",
"""            <button role="tab" data-aac-main="CAMPAIGNS" aria-selected="false">Campaigns</button>
            <button role="tab" data-aac-main="REVIEWS" aria-selected="false">Restrictive reviews</button>"""),
("""                    <option value="VALID">Valid</option><option value="COVERED">Covered by contract</option>
                    <option value="NOT_SCHEDULED">Not scheduled</option><option value="ALL">All, including not applicable</option>""",
"""                    <option value="VALID">Valid</option><option value="COVERED">Covered by contract</option>
                    <option value="FAILED">Failed</option><option value="WAIVED">Waived</option>
                    <option value="NOT_SCHEDULED">Not scheduled</option><option value="ALL">All, including not applicable</option>"""),
("""and the contracts covering the asset. A completed task sets the last date.</p>""",
"""and the contracts covering the asset. An approved result sets the last date (a task completed without a result, for activities that do not need one). A failed result is re-tested after the re-test days; a waiver lasts until its review date.</p>"""),
("""                    <option value="COVERED">Covered by contract</option><option value="ALL">All</option>
                </select>
                <label class="aac-check"><input type="checkbox" id="aacOccReconcile" /> Needs reconciliation only</label>""",
"""                    <option value="COVERED">Covered by contract</option><option value="WAIVED">Waived</option><option value="ALL">All</option>
                </select>
                <label class="aac-check"><input type="checkbox" id="aacOccReconcile" /> Needs reconciliation only</label>
                <label class="aac-check"><input type="checkbox" id="aacOccAwaiting" /> Awaiting a decision only</label>"""),
("""                    <thead><tr><th>Occurrence</th><th>Asset</th><th>Due</th><th>Decision</th><th>Task</th><th>Status</th><th>Reconciliation</th></tr></thead>""",
"""                    <thead><tr><th>Occurrence</th><th>Asset</th><th>Due</th><th>Decision</th><th>Task</th><th>Status</th><th>Result</th><th>Reconciliation</th></tr></thead>"""),
("""        @* ---------------- templates ---------------- *@""",
"""        @* ---------------- restrictive-use reviews (439) ---------------- *@
        <div class="pm-tab-panel" data-aac-mainpanel="REVIEWS" hidden>
            <div class="pm-toolbar">
                <select id="aacRevStatus" title="Status">
                    <option value="">Open and decided</option><option value="OPEN">Open</option><option value="DECIDED">Decided</option>
                    <option value="RESOLVED">Resolved</option><option value="ALL">All</option>
                </select>
                <input type="search" id="aacRevSearch" placeholder="Search asset or review" maxlength="200" />
            </div>
            <p class="aac-note">BRD 9.1.9: a failed result, an overdue activity on an asset of the criticality the policy names (calibration: Critical and High), an expired equipment licence, or expired insurance / fitness / permit / registration evidence raises a review. Record the action taken; the asset lifecycle status is changed on the Asset Register (Lifecycle). A review is resolved by itself once the cause clears.</p>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Review</th><th>Asset</th><th>Since</th><th>Severity</th><th>Status</th><th>Decision</th><th></th></tr></thead>
                    <tbody id="aacRevBody"></tbody>
                </table>
            </div>
            <div id="aacRevPager"></div>
        </div>

        @* ---------------- templates ---------------- *@"""),
("""                    <thead><tr><th>Activity</th><th>Rule</th><th>Register fields</th><th>Contract types</th><th>Lead / due soon</th><th>Tasks</th><th>Notification profile</th><th>Status</th></tr></thead>
                    <tbody id="aacTplBody"></tbody>
                </table>
            </div>""",
"""                    <thead><tr><th>Activity</th><th>Rule</th><th>Register fields</th><th>Contract types</th><th>Lead / due soon</th><th>Tasks</th><th>Notification profile</th><th>Status</th></tr></thead>
                    <tbody id="aacTplBody"></tbody>
                </table>
            </div>
            <h3 class="aac-sub">Evidence expiry</h3>
            <p class="aac-note">Evidence date fields of the asset register that raise the Evidence / certificate expiry notifications (BRD 9.1.7) and, where marked, a restrictive-use review once expired (9.1.9).</p>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Evidence</th><th>Register field</th><th>Evidence owner</th><th>Restrictive review when expired</th></tr></thead>
                    <tbody id="aacEvidenceBody"></tbody>
                </table>
            </div>"""),
("""            <label><span>Campaign owner</span><select id="aacStOwner"></select></label>
            <p class="pm-message full" id="aacStMessage" role="status" aria-live="polite" hidden></p>""",
"""            <label><span>Campaign owner</span><select id="aacStOwner"></select></label>
            <label class="aac-check full"><input type="checkbox" id="aacStReview" /> Results need a reviewer (another person approves)</label>
            <label class="aac-check full"><input type="checkbox" id="aacStApproval" /> Reschedule / waive / not applicable / exception need approval</label>
            <label><span>Restrictive review when overdue</span>
                <select id="aacStOverdue">
                    <option value="NONE">Never</option><option value="CRITICAL">Critical assets</option>
                    <option value="CRITICAL,HIGH">Critical and High assets</option><option value="CRITICAL,HIGH,MEDIUM">Critical, High and Medium assets</option>
                    <option value="ALL">Every asset</option>
                </select></label>
            <label class="aac-check"><input type="checkbox" id="aacStFail" /> Restrictive review on a failed result</label>
            <p class="pm-message full" id="aacStMessage" role="status" aria-live="polite" hidden></p>"""),
("""<style>
    .aac-note""",
"""@* ======================= Occurrence detail (439) ======================= *@
<div class="pm-modal" id="aacOccModal" hidden>
    <div class="pm-modal-panel pm-modal-wide">
        <header>
            <h2 id="aacOdTitle">Occurrence</h2>
            <button class="pm-modal-close" type="button" data-close-aac="aacOccModal" aria-label="Close">&times;</button>
        </header>
        <div class="aac-info" id="aacOdInfo"></div>
        <p class="pm-message" id="aacOdMessage" role="status" aria-live="polite" hidden></p>

        <h3 class="aac-sub">Result <span class="aac-note" id="aacOdResultState"></span></h3>
        <form id="aacResultForm" class="pm-form-grid">
            <label><span>Outcome *</span><select id="aacRsOutcome"></select></label>
            <label><span>Performed date *</span><input type="date" id="aacRsPerformed" /></label>
            <label data-aac-cert><span>Certificate number</span><input type="text" id="aacRsCertNo" maxlength="100" /></label>
            <label data-aac-cert><span>Certificate expiry</span><input type="date" id="aacRsCertExp" /></label>
            <label data-aac-renewal><span>New expiry date</span><input type="date" id="aacRsNewExp" /></label>
            <label class="full"><span>Evidence reference (report, certificate or document link)</span><input type="text" id="aacRsEvidence" maxlength="400" /></label>
            <label class="full"><span>Note (required for a failure or not renewed)</span><textarea id="aacRsNote" rows="2" maxlength="2000"></textarea></label>
            <footer class="pm-modal-footer full" id="aacRsButtons">
                <button type="button" class="pm-button" id="aacRsDraft"><i class="fa-solid fa-floppy-disk"></i> Save draft</button>
                <button type="submit" class="pm-button primary"><i class="fa-solid fa-paper-plane"></i> Submit result</button>
            </footer>
        </form>
        <div id="aacRsReview" class="pm-form-grid" hidden>
            <label class="full"><span>Review note (required to return)</span><textarea id="aacRsDecisionNote" rows="2" maxlength="1000"></textarea></label>
            <footer class="pm-modal-footer full">
                <button type="button" class="pm-button" data-aac-result-decision="RETURN"><i class="fa-solid fa-rotate-left"></i> Return</button>
                <button type="button" class="pm-button primary" data-aac-result-decision="APPROVE"><i class="fa-solid fa-check"></i> Approve result</button>
            </footer>
        </div>

        <h3 class="aac-sub">Reschedule, waive, not applicable or exception</h3>
        <div class="pm-table-wrap">
            <table>
                <thead><tr><th>Request</th><th>Dates</th><th>Reason</th><th>Status</th><th></th></tr></thead>
                <tbody id="aacOdDispBody"></tbody>
            </table>
        </div>
        <form id="aacDispForm" class="pm-form-grid">
            <label><span>Outcome *</span>
                <select id="aacDpType">
                    <option value="RESCHEDULE">Reschedule</option><option value="WAIVE">Waive</option>
                    <option value="NOT_APPLICABLE">Not applicable</option><option value="EXCEPTION">Exception</option>
                </select></label>
            <label id="aacDpRevisedWrap"><span>Revised due date *</span><input type="date" id="aacDpRevised" /></label>
            <label id="aacDpReviewWrap" hidden><span>Review date *</span><input type="date" id="aacDpReview" /></label>
            <label class="full"><span>Reason *</span><textarea id="aacDpReason" rows="2" maxlength="1000"></textarea></label>
            <footer class="pm-modal-footer full">
                <button type="submit" class="pm-button primary"><i class="fa-solid fa-paper-plane"></i> Request</button>
            </footer>
        </form>

        <h3 class="aac-sub">Restrictive-use reviews of this asset and activity</h3>
        <div class="pm-table-wrap">
            <table>
                <thead><tr><th>Review</th><th>Since</th><th>Status</th><th>Decision</th></tr></thead>
                <tbody id="aacOdRevBody"></tbody>
            </table>
        </div>
    </div>
</div>

@* ======================= Disposition / review decision (439) ======================= *@
<div class="pm-modal" id="aacDecisionModal" hidden>
    <div class="pm-modal-panel">
        <header>
            <h2 id="aacDcTitle">Decision</h2>
            <button class="pm-modal-close" type="button" data-close-aac="aacDecisionModal" aria-label="Close">&times;</button>
        </header>
        <form id="aacDecisionForm" class="pm-form-grid">
            <p class="aac-note full" id="aacDcInfo"></p>
            <label class="full"><span>Decision *</span><select id="aacDcDecision"></select></label>
            <label class="full"><span id="aacDcNoteLabel">Note</span><textarea id="aacDcNote" rows="3" maxlength="1000"></textarea></label>
            <p class="pm-message full" id="aacDcMessage" role="status" aria-live="polite" hidden></p>
            <footer class="pm-modal-footer full">
                <button type="button" class="pm-button" data-close-aac="aacDecisionModal">Cancel</button>
                <button type="submit" class="pm-button primary"><i class="fa-solid fa-check"></i> Record</button>
            </footer>
        </form>
    </div>
</div>

<style>
    .aac-note"""),
("""    tr[data-aac-campaign] { cursor: pointer; }""",
"""    tr[data-aac-campaign] { cursor: pointer; }
    .aac-sub { font-size: 13px; font-weight: 600; color: var(--fg-strong); margin: 16px 0 8px; }
    .aac-info { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 8px 16px; font-size: 13px; margin-bottom: 12px; }
    .aac-info span { display: block; color: var(--fg-secondary); font-size: 11px; }"""),
])

files[J] = edit(J, [
("""// open occurrence per asset and activity); this screen shows them.
// =====================================================================""",
"""// open occurrence per asset and activity); this screen shows them.
// 439: activities/occurrences/{id} (detail), .../result, .../result-decision,
// .../disposition, activities/dispositions/{id}/decision, activities/reviews,
// activities/reviews/{id}/decision -- results with reviewer approval,
// reschedule / waive / not applicable / exception with approver (7.1.5) and
// the restrictive-use reviews (9.1.9). Segregation of duties is in SQL.
// ====================================================================="""),
("""  const CAN_EDIT = root.dataset.canEdit === "1";
""",
"""  const CAN_EDIT = root.dataset.canEdit === "1";
  const CAN_APPROVE = root.dataset.canApprove === "1";   // 439
"""),
("""                   COVERED: ["Covered by contract", "aac-st-open"], NOT_SCHEDULED: ["Not scheduled", "aac-st-ended"],
                   NOT_APPLICABLE: ["Not applicable", "aac-st-ended"] };
  const OCC_STATUS = { OPEN: ["Open", "aac-st-open"], COMPLETED: ["Completed", "aac-st-active"], CANCELLED: ["Cancelled", "aac-st-ended"],
                       COVERED: ["Covered", "aac-st-open"] };""",
"""                   COVERED: ["Covered by contract", "aac-st-open"], NOT_SCHEDULED: ["Not scheduled", "aac-st-ended"],
                   NOT_APPLICABLE: ["Not applicable", "aac-st-ended"],
                   FAILED: ["Failed", "aac-st-bad"], WAIVED: ["Waived", "aac-st-ended"] };            // 439
  const OCC_STATUS = { OPEN: ["Open", "aac-st-open"], COMPLETED: ["Completed", "aac-st-active"], CANCELLED: ["Cancelled", "aac-st-ended"],
                       COVERED: ["Covered", "aac-st-open"], WAIVED: ["Waived", "aac-st-ended"] };
  // 439: results, dispositions, restrictive-use reviews.
  const OUTCOME = { PASS: "Pass", FAIL: "Fail", RENEWED: "Renewed", NOT_RENEWED: "Not renewed" };
  const RESULT_STATE = { DRAFT: ["Draft", "aac-st-ended"], SUBMITTED: ["Waiting for review", "aac-st-wait"],
                         RETURNED: ["Returned", "aac-st-bad"], APPROVED: ["Approved", "aac-st-active"] };
  const DISPOSITION = { RESCHEDULE: "Reschedule", WAIVE: "Waive", NOT_APPLICABLE: "Not applicable", EXCEPTION: "Exception" };
  const DISP_STATUS = { PENDING: ["Pending approval", "aac-st-wait"], APPROVED: ["Approved", "aac-st-active"],
                        REJECTED: ["Rejected", "aac-st-bad"], WITHDRAWN: ["Withdrawn", "aac-st-ended"] };
  const REV_STATUS = { OPEN: ["Open", "aac-st-bad"], DECIDED: ["Decided", "aac-st-wait"], RESOLVED: ["Resolved", "aac-st-active"] };
  const REV_ACTION = { CONTROLLED_USE: "Controlled use", RESTRICTED_USE: "Restricted use", REMOVED_FROM_SERVICE: "Removed from service",
                       EXCEPTION_APPROVED: "Exception approved", NO_ACTION_REQUIRED: "No action required", DISABLE: "Disable",
                       UNINSTALL: "Uninstall", REPLACE: "Replace", PURCHASE: "Purchase" };
  // The actions the procedure accepts for each trigger (BRD 9.1.9, 7.1.2, 7.1.3).
  function reviewActions(r) {
    if (r.sourceKind === "EVIDENCE") return ["RESTRICTED_USE", "REMOVED_FROM_SERVICE", "EXCEPTION_APPROVED", "NO_ACTION_REQUIRED"];
    if (r.triggerCode === "EXPIRED") return ["DISABLE", "UNINSTALL", "REPLACE", "PURCHASE", "RESTRICTED_USE", "EXCEPTION_APPROVED"];
    return ["CONTROLLED_USE", "RESTRICTED_USE", "REMOVED_FROM_SERVICE", "EXCEPTION_APPROVED", "NO_ACTION_REQUIRED"];
  }"""),
("""                       NO_HISTORY: "no history -- due now", EXPIRY_FIELD: "licence expiry" };""",
"""                       NO_HISTORY: "no history -- due now", EXPIRY_FIELD: "licence expiry",
                       FAILED_RESULT: "re-test after a failed result", WAIVED_REVIEW: "review date of a waiver" };   // 439"""),
("""                  campaignId: null, setting: null, reconcile: null };""",
"""                  campaignId: null, setting: null, reconcile: null, revPager: null, detail: null, decision: null, revRows: [] };"""),
("""    state.cmpPager = window.__pmGrid ? window.__pmGrid.attach({ hostId: "aacCmpPager", onChange: refreshCampaigns }) : null;""",
"""    state.cmpPager = window.__pmGrid ? window.__pmGrid.attach({ hostId: "aacCmpPager", onChange: refreshCampaigns }) : null;
    state.revPager = window.__pmGrid ? window.__pmGrid.attach({ hostId: "aacRevPager", onChange: refreshReviews }) : null;   // 439"""),
("""    ["aacOccStatus", "aacOccReconcile"].forEach(id => document.getElementById(id).addEventListener("change", () => {""",
"""    ["aacOccStatus", "aacOccReconcile", "aacOccAwaiting"].forEach(id => document.getElementById(id).addEventListener("change", () => {"""),
("""      const b = ev.target.closest("button[data-aac-reconcile]");
      if (b) openReconcile(Number(b.dataset.aacReconcile));
    });""",
"""      const b = ev.target.closest("button[data-aac-reconcile]");
      if (b) openReconcile(Number(b.dataset.aacReconcile));
      const d = ev.target.closest("button[data-aac-open]");                    // 439
      if (d) openOccurrence(Number(d.dataset.aacOpen));
    });
    // 439: reviews, occurrence detail, decisions.
    let t3 = null;
    document.getElementById("aacRevSearch").addEventListener("input", () => { clearTimeout(t3); t3 = setTimeout(() => { state.revPager?.reset(true); refreshReviews(); }, 300); });
    document.getElementById("aacRevStatus").addEventListener("change", () => { state.revPager?.reset(true); refreshReviews(); });
    document.getElementById("aacRevBody").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-aac-review]");
      if (b) openReviewDecision((state.revRows || []).find(x => x.reviewId === Number(b.dataset.aacReview)));
      const o = ev.target.closest("button[data-aac-open]");
      if (o) openOccurrence(Number(o.dataset.aacOpen));
    });
    document.getElementById("aacResultForm").addEventListener("submit", ev => { ev.preventDefault(); saveResult(true); });
    document.getElementById("aacRsDraft").addEventListener("click", () => saveResult(false));
    document.querySelectorAll("[data-aac-result-decision]").forEach(b => b.addEventListener("click", () => decideResult(b.dataset.aacResultDecision)));
    document.getElementById("aacDpType").addEventListener("change", toggleDispositionDates);
    document.getElementById("aacDispForm").addEventListener("submit", ev => { ev.preventDefault(); requestDisposition(); });
    document.getElementById("aacOdDispBody").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-aac-disp]");
      if (b) openDispositionDecision((state.detail?.dispositions || []).find(x => x.dispositionId === Number(b.dataset.aacDisp)));
    });
    document.getElementById("aacDecisionForm").addEventListener("submit", ev => { ev.preventDefault(); saveDecision(); });"""),
("""    if (name === "OCCURRENCES") await refreshOccurrences();
    else if (name === "CAMPAIGNS") await refreshCampaigns();""",
"""    if (name === "OCCURRENCES") await refreshOccurrences();
    else if (name === "CAMPAIGNS") await refreshCampaigns();
    else if (name === "REVIEWS") await refreshReviews();                       // 439"""),
("""  function resetPagers() { state.schPager?.reset(true); state.occPager?.reset(true); state.cmpPager?.reset(true); }""",
"""  function resetPagers() { state.schPager?.reset(true); state.occPager?.reset(true); state.cmpPager?.reset(true); state.revPager?.reset(true); }"""),
("""        <td>${s.nextDueDate ? esc(date(s.nextDueDate)) + `<div class="aac-note">${days < 0""",
"""        <td>${s.revisedDueDate ? `<div class="aac-note">Rescheduled to ${esc(date(s.revisedDueDate))}</div>` : ""}${s.nextDueDate ? esc(date(s.nextDueDate)) + `<div class="aac-note">${days < 0"""),
("""    if (!state.organizationId) { body.innerHTML = empty(7, "Select an organization."); state.occPager?.clear(); return; }
    body.innerHTML = empty(7, "Loading...");""",
"""    if (!state.organizationId) { body.innerHTML = empty(8, "Select an organization."); state.occPager?.clear(); return; }
    body.innerHTML = empty(8, "Loading...");"""),
("""    if (state.campaignId) qs.set("campaignId", state.campaignId);
    if (val("aacOccSearch")) qs.set("search", val("aacOccSearch"));
    const res = await api("GET", `/occurrences?${qs}`);
    if (!res.ok) { body.innerHTML = empty(7, res.error); state.occPager?.clear(); return; }""",
"""    if (state.campaignId) qs.set("campaignId", state.campaignId);
    if (val("aacOccSearch")) qs.set("search", val("aacOccSearch"));
    if (document.getElementById("aacOccAwaiting").checked) qs.set("awaitingDecision", "true");   // 439
    const res = await api("GET", `/occurrences?${qs}`);
    if (!res.ok) { body.innerHTML = empty(8, res.error); state.occPager?.clear(); return; }"""),
("""      return `<tr><td>${esc(o.occurrenceKey)}<div class="aac-note">${esc(o.templateName)}${o.campaignKey ? " - " + esc(o.campaignKey) : ""}</div></td>
        <td>${esc(o.assetName)}</td>
        <td>${esc(date(o.dueDate))}${o.status === "OPEN" ? `<div class="aac-note">${o.daysToDue < 0 ? esc(-o.daysToDue) + " days overdue" : "in " + esc(o.daysToDue) + " days"}</div>` : ""}</td>""",
"""      const [rl, rc] = RESULT_STATE[o.resultState] || ["", ""];
      return `<tr><td><button class="pm-link-button" type="button" data-aac-open="${o.occurrenceId}">${esc(o.occurrenceKey)}</button><div class="aac-note">${esc(o.templateName)}${o.isRetest ? " - re-test" : ""}${o.campaignKey ? " - " + esc(o.campaignKey) : ""}</div></td>
        <td>${esc(o.assetName)}</td>
        <td>${esc(date(o.dueDate))}${o.revisedDueDate ? `<div class="aac-note">Rescheduled to ${esc(date(o.revisedDueDate))}</div>` : ""}${o.status === "OPEN" ? `<div class="aac-note">${o.daysToDue < 0 ? esc(-o.daysToDue) + " days overdue" : "in " + esc(o.daysToDue) + " days"}</div>` : ""}${o.reviewDate ? `<div class="aac-note">Review ${esc(date(o.reviewDate))}</div>` : ""}</td>"""),
("""        <td><span class="aac-chip ${oc}">${esc(ol)}</span>${o.completedDt ? `<div class="aac-note">${esc(dateTime(o.completedDt))} ${esc(o.completedByName || "")}</div>` : ""}</td>
        <td>${o.needsReconciliation""",
"""        <td><span class="aac-chip ${oc}">${esc(ol)}</span>${o.completedDt ? `<div class="aac-note">${esc(dateTime(o.completedDt))} ${esc(o.completedByName || "")}</div>` : ""}</td>
        <td>${o.resultState ? `<span class="aac-chip ${rc}">${esc(rl)}</span>${o.resultOutcome ? `<div class="aac-note">${esc(OUTCOME[o.resultOutcome] || o.resultOutcome)}</div>` : ""}` : "--"}
            ${o.pendingDispositionType ? `<div><span class="aac-chip aac-st-wait">${esc(DISPOSITION[o.pendingDispositionType] || o.pendingDispositionType)} pending</span></div>` : ""}</td>
        <td>${o.needsReconciliation"""),
("""    }).join("") || empty(7, "No occurrences. The scheduler opens them when a due date comes within the lead days.");""",
"""    }).join("") || empty(8, "No occurrences. The scheduler opens them when a due date comes within the lead days.");"""),
("""        <td><div class="aac-note">${esc(t.description)}</div></td>""",
"""        <td><div class="aac-note">${esc(t.description)}</div>
            <div class="aac-note">${t.resultRequired ? (t.resultReviewRequired ? "Result approved by a reviewer." : "Result approved on submission.") : ""}
              ${t.dispositionApprovalRequired ? "Reschedule / waive need approval." : "Reschedule / waive apply at once."}
              ${t.restrictOnOverdue && t.restrictOnOverdue !== "NONE" ? "Restrictive review when overdue: " + esc(label(t.restrictOnOverdue.replace(/,/g, ", "))) + "." : ""}
              ${t.restrictOnFail ? "Restrictive review on a failed result." : ""}
              ${t.retestDays != null ? "Re-test " + esc(t.retestDays) + " days after a failure." : ""}</div></td>"""),
("""            ${CAN_EDIT ? `<div><button class="pm-button" type="button" data-aac-setting="${esc(t.templateCode)}">Settings</button></div>` : ""}</td></tr>`).join("");
  }""",
"""            ${CAN_EDIT ? `<div><button class="pm-button" type="button" data-aac-setting="${esc(t.templateCode)}">Settings</button></div>` : ""}</td></tr>`).join("");
    // 439: evidence date fields.
    document.getElementById("aacEvidenceBody").innerHTML = (c.evidenceFields || []).map(e => `<tr>
        <td>${esc(e.evidenceName)}</td><td>${esc(e.fieldLabel || e.fieldKey)}<div class="aac-note">${esc(e.fieldKey)}</div></td>
        <td>${esc(e.ownerFieldKey ? e.ownerFieldKey + ", else the asset owner" : "Asset owner")}</td>
        <td>${e.restrictOnExpiry ? "Yes" : "No"}</td></tr>`).join("") || empty(4, "No evidence fields.");
  }"""),
("""    document.getElementById("aacStOwner").value = t.campaignOwnerEmployeeId ? String(t.campaignOwnerEmployeeId) : "";""",
"""    document.getElementById("aacStOwner").value = t.campaignOwnerEmployeeId ? String(t.campaignOwnerEmployeeId) : "";
    // 439
    document.getElementById("aacStReview").checked = !!t.resultReviewRequired;
    document.getElementById("aacStApproval").checked = !!t.dispositionApprovalRequired;
    const ov = document.getElementById("aacStOverdue");
    if (![...ov.options].some(x => x.value === t.restrictOnOverdue)) ov.insertAdjacentHTML("beforeend", `<option value="${esc(t.restrictOnOverdue)}">${esc(t.restrictOnOverdue)}</option>`);
    ov.value = t.restrictOnOverdue || "NONE";
    document.getElementById("aacStFail").checked = !!t.restrictOnFail;
    document.getElementById("aacStFail").disabled = t.activityKind === "RENEWAL";"""),
("""      groupingMode: val("aacStGrouping"), campaignOwnerEmployeeId: Number(val("aacStOwner")) || null
    });""",
"""      groupingMode: val("aacStGrouping"), campaignOwnerEmployeeId: Number(val("aacStOwner")) || null,
      resultReviewRequired: document.getElementById("aacStReview").checked,                       // 439
      dispositionApprovalRequired: document.getElementById("aacStApproval").checked,
      restrictOnOverdue: val("aacStOverdue"),
      restrictOnFail: state.setting.activityKind === "RENEWAL" ? false : document.getElementById("aacStFail").checked
    });"""),
("""  // ------------------------------------------------------------------ run now""",
"""  // ------------------------------------------------------------------ occurrence detail (439)
  async function openOccurrence(id) {
    if (!id) return;
    const res = await api("GET", `/occurrences/${id}?organizationId=${state.organizationId}`);
    if (!res.ok) { showMessage(res.error, "error"); return; }
    state.detail = res.data.data;
    renderOccurrence();
    hide("aacOdMessage");
    document.getElementById("aacOccModal").hidden = false;
  }

  function renderOccurrence() {
    const d = state.detail, o = d.occurrence, r = d.result;
    const [ol] = OCC_STATUS[o.status] || [o.status];
    document.getElementById("aacOdTitle").textContent = `${o.templateName} - ${o.assetName}`;
    document.getElementById("aacOdInfo").innerHTML = [
      ["Occurrence", o.occurrenceKey + (o.isRetest ? " (re-test)" : "")], ["Status", ol],
      ["Due", date(o.dueDate) + (o.revisedDueDate ? ", rescheduled to " + date(o.revisedDueDate) : "")],
      ["Review date", date(o.reviewDate) || "--"],
      ["Task", o.taskId ? (o.taskNumber || "#" + o.taskId) + " - " + (o.taskStatusName || "") + " - " + (o.taskOwnerName || "unassigned") : "--"],
      ["Contract", o.contractNumber ? o.contractNumber + " v" + o.contractVersionNo : "--"],
      ["Decision", o.decisionReason || "--"],
      ["Reconciliation", o.needsReconciliation ? o.reconciliationReason || "Needed" : "--"]
    ].map(([k, v]) => `<div><span>${esc(k)}</span>${esc(v)}</div>`).join("");

    // Result.
    const renewal = o.activityKind === "RENEWAL";
    const outcomes = renewal ? ["RENEWED", "NOT_RENEWED"] : ["PASS", "FAIL"];
    document.getElementById("aacRsOutcome").innerHTML = `<option value="">--</option>` + outcomes.map(x => `<option value="${x}">${esc(OUTCOME[x])}</option>`).join("");
    document.getElementById("aacRsOutcome").value = r?.outcome || "";
    document.getElementById("aacRsPerformed").value = date(r?.performedDate);
    document.getElementById("aacRsCertNo").value = r?.certificateNumber || "";
    document.getElementById("aacRsCertExp").value = date(r?.certificateExpiry);
    document.getElementById("aacRsNewExp").value = date(r?.newExpiry);
    document.getElementById("aacRsEvidence").value = r?.evidenceReference || "";
    document.getElementById("aacRsNote").value = r?.resultNote || "";
    document.querySelectorAll("[data-aac-cert]").forEach(x => { x.hidden = renewal || !o.certificateNumberFieldKey; });
    document.querySelectorAll("[data-aac-renewal]").forEach(x => { x.hidden = !renewal; });
    const [sl] = RESULT_STATE[r?.state] || [""];
    document.getElementById("aacOdResultState").textContent = r
      ? `${sl}${r.submittedByName || r.submittedBy ? " - submitted by " + (r.submittedByName || r.submittedBy) : ""}${r.decidedDt ? ", " + (r.state === "RETURNED" ? "returned" : "decided") + " by " + (r.decidedByName || r.decidedBy || "") : ""}${r.decisionNote ? ": " + r.decisionNote : ""}`
      : (o.resultReviewRequired ? "A reviewer approves the submitted result." : "The submitted result is approved at once.");
    const editable = CAN_EDIT && o.status === "OPEN" && o.decision === "ASSET_TASK" && !(r && (r.state === "SUBMITTED" || r.state === "APPROVED"));
    document.querySelectorAll("#aacResultForm input, #aacResultForm select, #aacResultForm textarea").forEach(x => { x.disabled = !editable; });
    document.getElementById("aacRsButtons").hidden = !editable;
    document.getElementById("aacRsReview").hidden = !(CAN_APPROVE && r && r.state === "SUBMITTED" && o.status === "OPEN");
    document.getElementById("aacRsDecisionNote").value = "";

    // Dispositions.
    const pending = (d.dispositions || []).some(x => x.status === "PENDING");
    document.getElementById("aacOdDispBody").innerHTML = (d.dispositions || []).map(x => {
      const [dl, dc] = DISP_STATUS[x.status] || [x.status, ""];
      return `<tr><td>${esc(DISPOSITION[x.dispositionType] || x.dispositionType)}<div class="aac-note">${esc(x.requestedByName || x.requestedBy)} ${esc(dateTime(x.requestedDt))}</div></td>
        <td>${x.revisedDueDate ? "Due " + esc(date(x.previousDueDate)) + " to " + esc(date(x.revisedDueDate)) : "Until " + esc(date(x.reviewDate))}</td>
        <td>${esc(x.reason)}${x.taskNote ? `<div class="aac-note">${esc(x.taskNote)}</div>` : ""}</td>
        <td><span class="aac-chip ${dc}">${esc(dl)}</span>${x.decidedDt ? `<div class="aac-note">${esc(x.decidedByName || x.decidedBy || "")} ${esc(dateTime(x.decidedDt))}${x.decisionNote ? ": " + esc(x.decisionNote) : ""}</div>` : ""}</td>
        <td>${x.status === "PENDING" && (CAN_APPROVE || CAN_EDIT) ? `<button class="pm-button" type="button" data-aac-disp="${x.dispositionId}">Decide</button>` : ""}</td></tr>`;
    }).join("") || empty(5, "No requests.");
    document.getElementById("aacDispForm").hidden = !(CAN_EDIT && o.status === "OPEN" && !pending);
    document.getElementById("aacDpType").value = "RESCHEDULE";
    document.getElementById("aacDpRevised").value = "";
    document.getElementById("aacDpReview").value = "";
    document.getElementById("aacDpReason").value = "";
    toggleDispositionDates();

    // Reviews.
    document.getElementById("aacOdRevBody").innerHTML = (d.reviews || []).map(x => {
      const [vl, vc] = REV_STATUS[x.status] || [x.status, ""];
      return `<tr><td>${esc(x.title)}</td><td>${esc(date(x.triggerDate))}</td><td><span class="aac-chip ${vc}">${esc(vl)}</span></td>
        <td>${x.decisionCode ? esc(REV_ACTION[x.decisionCode] || x.decisionCode) + `<div class="aac-note">${esc(x.decisionNote || "")}</div>` : "--"}</td></tr>`;
    }).join("") || empty(4, "No restrictive-use reviews.");
  }

  function toggleDispositionDates() {
    const reschedule = val("aacDpType") === "RESCHEDULE";
    document.getElementById("aacDpRevisedWrap").hidden = !reschedule;
    document.getElementById("aacDpReviewWrap").hidden = reschedule;
  }

  async function reloadDetail(text) {
    await openOccurrence(state.detail.occurrence.occurrenceId);
    if (text) show("aacOdMessage", text, "success");
    await refreshOccurrences();
  }

  async function saveResult(submit) {
    const o = state.detail.occurrence, r = state.detail.result;
    if (submit && !await window.gracUi.confirm(o.resultReviewRequired
        ? "Submit the result for review? It cannot be changed while it waits for review."
        : "Submit the result? It is approved at once and updates the asset register.")) return;
    const res = await api("POST", `/occurrences/${o.occurrenceId}/result`, {
      organizationId: state.organizationId, outcome: val("aacRsOutcome") || null, performedDate: val("aacRsPerformed") || null,
      certificateNumber: val("aacRsCertNo") || null, certificateExpiry: val("aacRsCertExp") || null,
      newExpiry: val("aacRsNewExp") || null, evidenceReference: val("aacRsEvidence") || null, resultNote: val("aacRsNote") || null,
      submit, expectedRecordVersion: r ? r.recordVersion : null
    });
    if (!res.ok) { show("aacOdMessage", res.error); return; }
    await reloadDetail(submit ? "Result submitted." : "Draft saved.");
  }

  async function decideResult(decision) {
    const o = state.detail.occurrence, r = state.detail.result;
    const note = val("aacRsDecisionNote");
    if (decision === "RETURN" && !note) { show("aacOdMessage", "Give the reason for returning the result."); return; }
    const res = await api("POST", `/occurrences/${o.occurrenceId}/result-decision`, {
      organizationId: state.organizationId, decision, decisionNote: note || null, expectedRecordVersion: r.recordVersion
    });
    if (!res.ok) { show("aacOdMessage", res.error); return; }
    await reloadDetail(decision === "APPROVE" ? "Result approved; the asset register is updated." : "Result returned.");
  }

  async function requestDisposition() {
    const o = state.detail.occurrence, type = val("aacDpType");
    const res = await api("POST", `/occurrences/${o.occurrenceId}/disposition`, {
      organizationId: state.organizationId, dispositionType: type, reason: val("aacDpReason") || null,
      revisedDueDate: type === "RESCHEDULE" ? val("aacDpRevised") || null : null,
      reviewDate: type === "RESCHEDULE" ? null : val("aacDpReview") || null,
      expectedRecordVersion: o.recordVersion
    });
    if (!res.ok) { show("aacOdMessage", res.error); return; }
    await reloadDetail(res.data.result === "APPROVED" ? "Applied." : "Request recorded; it waits for approval.");
  }

  function openDispositionDecision(x) {
    if (!x) return;
    const opts = [];
    if (CAN_APPROVE) opts.push(["APPROVE", "Approve"], ["REJECT", "Reject"]);
    if (CAN_EDIT) opts.push(["WITHDRAW", "Withdraw (requester only)"]);
    openDecision({ kind: "DISPOSITION", id: x.dispositionId, recordVersion: x.recordVersion },
      `${DISPOSITION[x.dispositionType] || x.dispositionType} - ${x.reason}`, opts, "Note (required to reject)");
  }

  function openReviewDecision(x) {
    if (!x) return;
    openDecision({ kind: "REVIEW", id: x.reviewId, recordVersion: x.recordVersion },
      `${x.title} (since ${date(x.triggerDate)})`, reviewActions(x).map(a => [a, REV_ACTION[a] || label(a)]), "Reason / action taken *");
  }

  function openDecision(target, info, options, noteLabel) {
    state.decision = target;
    document.getElementById("aacDcTitle").textContent = target.kind === "REVIEW" ? "Restrictive-use review" : "Request decision";
    document.getElementById("aacDcInfo").textContent = info;
    document.getElementById("aacDcDecision").innerHTML = options.map(([v, l]) => `<option value="${esc(v)}">${esc(l)}</option>`).join("");
    document.getElementById("aacDcNoteLabel").textContent = noteLabel;
    document.getElementById("aacDcNote").value = "";
    hide("aacDcMessage");
    document.getElementById("aacDecisionModal").hidden = false;
  }

  async function saveDecision() {
    const t = state.decision;
    const path = t.kind === "REVIEW" ? `/reviews/${t.id}/decision` : `/dispositions/${t.id}/decision`;
    const res = await api("POST", path, {
      organizationId: state.organizationId, decision: val("aacDcDecision"), decisionNote: val("aacDcNote") || null,
      expectedRecordVersion: t.recordVersion
    });
    if (!res.ok) { show("aacDcMessage", res.error); return; }
    document.getElementById("aacDecisionModal").hidden = true;
    if (t.kind === "REVIEW") { showMessage("Decision recorded.", "success"); await refreshReviews(); }
    else await reloadDetail("Decision recorded.");
  }

  // ------------------------------------------------------------------ restrictive-use reviews (439)
  async function refreshReviews() {
    const body = document.getElementById("aacRevBody");
    if (!state.organizationId) { body.innerHTML = empty(7, "Select an organization."); state.revPager?.clear(); return; }
    body.innerHTML = empty(7, "Loading...");
    const qs = new URLSearchParams({ organizationId: state.organizationId,
      pageNumber: state.revPager ? state.revPager.page() : 1, pageSize: state.revPager ? state.revPager.size() : 25 });
    if (val("aacRevStatus")) qs.set("status", val("aacRevStatus"));
    if (val("aacRevSearch")) qs.set("search", val("aacRevSearch"));
    const res = await api("GET", `/reviews?${qs}`);
    if (!res.ok) { body.innerHTML = empty(7, res.error); state.revPager?.clear(); return; }
    const rows = res.data.data.rows || [];
    state.revPager?.setTotal(res.data.data.totalRows, rows.length);
    state.revRows = rows;
    body.innerHTML = rows.map(r => {
      const [vl, vc] = REV_STATUS[r.status] || [r.status, ""];
      return `<tr><td>${esc(r.title)}<div class="aac-note">${esc(r.sourceName)} - ${esc(label(r.triggerCode))}</div>
            ${r.occurrenceId ? `<button class="pm-link-button" type="button" data-aac-open="${r.occurrenceId}">Open occurrence</button>` : ""}</td>
        <td>${esc(r.assetName)}</td><td>${esc(date(r.triggerDate))}</td><td>${esc(label(r.severityCode))}</td>
        <td><span class="aac-chip ${vc}">${esc(vl)}</span>${r.resolvedDt ? `<div class="aac-note">${esc(dateTime(r.resolvedDt))}</div>` : ""}</td>
        <td>${r.decisionCode ? esc(REV_ACTION[r.decisionCode] || r.decisionCode) + `<div class="aac-note">${esc(r.decisionNote || "")} (${esc(r.decidedByName || r.decidedBy || "")} ${esc(dateTime(r.decidedDt))})</div>` : "--"}</td>
        <td>${CAN_APPROVE && r.status !== "RESOLVED" ? `<button class="pm-button" type="button" data-aac-review="${r.reviewId}">${r.status === "DECIDED" ? "Change" : "Decide"}</button>` : ""}</td></tr>`;
    }).join("") || empty(7, "No restrictive-use reviews.");
  }

  // ------------------------------------------------------------------ run now"""),
])

for p, s in files.items():
    open(p, 'w', encoding='utf-8', newline='').write(s)
print('439 ui ok', len(files))
