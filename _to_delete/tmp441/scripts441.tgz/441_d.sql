
-- =====================================================================
-- 5. Readers
-- =====================================================================
-- 1. settings (defaults when none saved)  2. active employees  3. departments
-- 4. business functions  5. locations  6. criticalities.
CREATE OR ALTER PROCEDURE grac_practice.sp_business_service_config_get
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54730, 'Organization not found.', 1;
    SELECT ISNULL(s.min_supporting_relationships, 1) AS MinSupportingRelationships,
           CAST(ISNULL(s.retirement_approval_required, 1) AS BIT) AS RetirementApprovalRequired
      FROM (SELECT 1 AS x) d
      LEFT JOIN grac_practice.business_service_setting s ON s.organization_id = @organization_id;
    SELECT employee_id AS EmployeeId, employee_name AS EmployeeName
      FROM grac_practice.organization_employee WHERE organization_id = @organization_id AND status = N'Active' ORDER BY employee_name;
    SELECT department_id AS DepartmentId, department_name AS DepartmentName
      FROM grac_practice.organization_department WHERE organization_id = @organization_id AND status = N'Active' ORDER BY department_name;
    SELECT business_function_id AS BusinessFunctionId, function_name AS FunctionName
      FROM grac_practice.organization_business_function WHERE organization_id = @organization_id AND status = N'Active'
     ORDER BY function_name;
    SELECT location_id AS LocationId, location_name AS LocationName
      FROM grac_practice.organization_location WHERE organization_id = @organization_id AND status = N'Active' ORDER BY location_name;
    SELECT criticality_id AS CriticalityId, criticality_code AS CriticalityCode
      FROM grac_practice.criticality_master
     ORDER BY CASE criticality_code WHEN N'Critical' THEN 1 WHEN N'High' THEN 2 WHEN N'Medium' THEN 3 WHEN N'Low' THEN 4 ELSE 5 END;
END
GO

-- Services. @status: NULL = every status but Retired, ALL, or one status.
CREATE OR ALTER PROCEDURE grac_practice.sp_business_services
    @organization_id BIGINT,
    @status          NVARCHAR(10)  = NULL,
    @service_type    NVARCHAR(16)  = NULL,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54730, 'Organization not found.', 1;
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @service_type = NULLIF(UPPER(LTRIM(RTRIM(@service_type))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    DECLARE @conf TABLE (service_id BIGINT NOT NULL PRIMARY KEY, n INT NOT NULL);
    INSERT @conf (service_id, n)
    SELECT ServiceId, COUNT(*) FROM grac_practice.fn_business_service_conflicts(@organization_id) GROUP BY ServiceId;

    SELECT b.service_id AS ServiceId, b.service_code AS ServiceCode, b.service_name AS ServiceName, b.service_type AS ServiceType,
           b.status AS Status, cm.criticality_code AS CriticalityCode, bo.employee_name AS BusinessOwnerName,
           sm.employee_name AS ServiceManagerName, d.department_name AS AccountableDepartmentName, b.rto_hours AS RtoHours,
           b.rpo_hours AS RpoHours, b.mtpd_hours AS MtpdHours, b.review_date AS ReviewDate,
           (SELECT COUNT(*) FROM grac_practice.asset_relationship r
             WHERE r.relationship_type_code = N'SUPPORTS_SERVICE' AND r.target_kind = N'SERVICE' AND r.target_id = b.service_id
               AND r.status = N'ACTIVE' AND r.effective_from <= @today AND (r.effective_to IS NULL OR r.effective_to >= @today)) AS SupportCount,
           (SELECT COUNT(*) FROM grac_practice.asset_relationship r
             WHERE r.relationship_type_code = N'SUPPORTS_SERVICE' AND r.source_kind = N'SERVICE' AND r.source_id = b.service_id
               AND r.status = N'ACTIVE' AND r.effective_from <= @today AND (r.effective_to IS NULL OR r.effective_to >= @today)) AS SupportsCount,
           (SELECT COUNT(*) FROM grac_practice.business_service_consumer c WHERE c.service_id = b.service_id) AS ConsumerCount,
           ISNULL(cf.n, 0) AS ConflictCount, b.pending_retirement AS PendingRetirement, b.version_no AS VersionNo,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.business_service b
      LEFT JOIN grac_practice.criticality_master cm ON cm.criticality_id = b.criticality_id
      LEFT JOIN grac_practice.organization_employee bo ON bo.employee_id = b.business_owner_employee_id
      LEFT JOIN grac_practice.organization_employee sm ON sm.employee_id = b.service_manager_employee_id
      LEFT JOIN grac_practice.organization_department d ON d.department_id = b.accountable_department_id
      LEFT JOIN @conf cf ON cf.service_id = b.service_id
     WHERE b.organization_id = @organization_id
       AND ((@status IS NULL AND b.status <> N'RETIRED') OR @status = N'ALL' OR b.status = @status)
       AND (@service_type IS NULL OR b.service_type = @service_type)
       AND (@search IS NULL OR b.service_name LIKE N'%' + @search + N'%' OR b.service_code LIKE N'%' + @search + N'%')
     ORDER BY CASE WHEN b.pending_retirement = 1 THEN 0 ELSE 1 END, b.service_name
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- One service: 1. service  2. consumers  3. supporting items (relationships
-- into the service)  4. services it supports  5. conflicts  6. history.
CREATE OR ALTER PROCEDURE grac_practice.sp_business_service_get
    @organization_id BIGINT,
    @service_id      BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.business_service WHERE service_id = @service_id AND organization_id = @organization_id)
        THROW 54731, 'Business service not found for this organization.', 1;
    SELECT b.service_id AS ServiceId, b.service_code AS ServiceCode, b.service_name AS ServiceName, b.service_type AS ServiceType,
           b.description AS Description, b.customer_outcome AS CustomerOutcome, b.business_owner_employee_id AS BusinessOwnerEmployeeId,
           bo.employee_name AS BusinessOwnerName, b.service_manager_employee_id AS ServiceManagerEmployeeId,
           sm.employee_name AS ServiceManagerName, b.accountable_department_id AS AccountableDepartmentId,
           d.department_name AS AccountableDepartmentName, b.criticality_id AS CriticalityId, cm.criticality_code AS CriticalityCode,
           b.confidentiality_rating AS ConfidentialityRating, b.integrity_rating AS IntegrityRating,
           b.availability_rating AS AvailabilityRating, b.rto_hours AS RtoHours, b.rpo_hours AS RpoHours, b.mtpd_hours AS MtpdHours,
           b.service_hours AS ServiceHours, b.sla_text AS SlaText, b.data_classification AS DataClassification,
           b.privacy_classification AS PrivacyClassification, b.status AS Status, b.review_date AS ReviewDate,
           b.version_no AS VersionNo, b.status_note AS StatusNote, b.pending_retirement AS PendingRetirement,
           b.consumer_review_note AS ConsumerReviewNote, b.contract_assessment_note AS ContractAssessmentNote,
           b.pending_by AS PendingBy, b.pending_dt AS PendingDt, b.retired_dt AS RetiredDt,
           CONVERT(BIGINT, b.record_version) AS RecordVersion
      FROM grac_practice.business_service b
      LEFT JOIN grac_practice.criticality_master cm ON cm.criticality_id = b.criticality_id
      LEFT JOIN grac_practice.organization_employee bo ON bo.employee_id = b.business_owner_employee_id
      LEFT JOIN grac_practice.organization_employee sm ON sm.employee_id = b.service_manager_employee_id
      LEFT JOIN grac_practice.organization_department d ON d.department_id = b.accountable_department_id
     WHERE b.service_id = @service_id;
    SELECT ConsumerId, ConsumerKind, ConsumerRefId, ConsumerName, Note
      FROM grac_practice.fn_business_service_consumers(@service_id) ORDER BY ConsumerKind, ConsumerName;
    SELECT r.relationship_id AS RelationshipId, r.source_kind AS CiKind, r.source_id AS CiId, c.CiName, c.CiClass, c.CiStatus,
           r.service_role AS ServiceRole, r.is_critical AS IsCritical, r.dependency_criticality AS DependencyCriticality,
           r.status AS Status, r.effective_from AS EffectiveFrom, r.effective_to AS EffectiveTo, r.source_code AS SourceCode,
           r.pending_action AS PendingAction
      FROM grac_practice.asset_relationship r
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) c ON c.CiKind = r.source_kind AND c.CiId = r.source_id
     WHERE r.organization_id = @organization_id AND r.relationship_type_code = N'SUPPORTS_SERVICE'
       AND r.target_kind = N'SERVICE' AND r.target_id = @service_id AND r.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')
     ORDER BY r.is_critical DESC, c.CiKind, c.CiName;
    SELECT r.relationship_id AS RelationshipId, r.target_id AS ServiceId, b.service_name AS ServiceName, b.status AS ServiceStatus,
           r.service_role AS ServiceRole, r.is_critical AS IsCritical, r.status AS Status
      FROM grac_practice.asset_relationship r
      JOIN grac_practice.business_service b ON b.service_id = r.target_id
     WHERE r.organization_id = @organization_id AND r.relationship_type_code = N'SUPPORTS_SERVICE'
       AND r.source_kind = N'SERVICE' AND r.source_id = @service_id AND r.target_kind = N'SERVICE'
       AND r.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')
     ORDER BY b.service_name;
    SELECT ConflictCode, Message, CiKind, CiId, CiName, RelationshipId
      FROM grac_practice.fn_business_service_conflicts(@organization_id) WHERE ServiceId = @service_id
     ORDER BY ConflictCode;
    SELECT h.history_id AS HistoryId, h.version_no AS VersionNo, h.action_code AS ActionCode, h.status AS Status, h.note AS Note,
           h.actor AS Actor, e.employee_name AS ActorName, h.entered_dt AS EnteredDt
      FROM grac_practice.business_service_history h
      LEFT JOIN grac_practice.organization_employee e ON e.employee_id = h.actor_employee_id
     WHERE h.service_id = @service_id
     ORDER BY h.history_id DESC;
END
GO

-- Conflicts of every service (or one).
CREATE OR ALTER PROCEDURE grac_practice.sp_business_service_conflicts
    @organization_id BIGINT,
    @service_id      BIGINT        = NULL,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    SELECT ServiceId, ServiceName, ConflictCode, Message, CiKind, CiId, CiName, RelationshipId, COUNT(*) OVER () AS TotalRows
      FROM grac_practice.fn_business_service_conflicts(@organization_id)
     WHERE (@service_id IS NULL OR ServiceId = @service_id)
       AND (@search IS NULL OR ServiceName LIKE N'%' + @search + N'%' OR CiName LIKE N'%' + @search + N'%')
     ORDER BY ServiceName, ConflictCode, CiName
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- Service hierarchy: 1. services (not retired)  2. links child -> parent
-- (Supports Service between services; proposed / active / disputed).
CREATE OR ALTER PROCEDURE grac_practice.sp_business_service_tree
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT b.service_id AS ServiceId, b.service_code AS ServiceCode, b.service_name AS ServiceName, b.service_type AS ServiceType,
           b.status AS Status, cm.criticality_code AS CriticalityCode, bo.employee_name AS BusinessOwnerName,
           b.rto_hours AS RtoHours, b.rpo_hours AS RpoHours
      FROM grac_practice.business_service b
      LEFT JOIN grac_practice.criticality_master cm ON cm.criticality_id = b.criticality_id
      LEFT JOIN grac_practice.organization_employee bo ON bo.employee_id = b.business_owner_employee_id
     WHERE b.organization_id = @organization_id AND b.status <> N'RETIRED'
     ORDER BY b.service_name;
    SELECT r.relationship_id AS RelationshipId, r.source_id AS ChildServiceId, r.target_id AS ParentServiceId,
           r.status AS Status, r.is_critical AS IsCritical, r.service_role AS ServiceRole
      FROM grac_practice.asset_relationship r
     WHERE r.organization_id = @organization_id AND r.relationship_type_code = N'SUPPORTS_SERVICE'
       AND r.source_kind = N'SERVICE' AND r.target_kind = N'SERVICE' AND r.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED');
END
GO
PRINT '441: readers created.';
GO
