import sys
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w446/new'
W=R+'/src/PracticeManagement.Web/Controllers/AssetConfigController.cs'
def edit(path, old, new, count=1):
    s=open(path).read()
    assert s.count(old)==count, (old[:80], s.count(old))
    s=s.replace(old,new); open(path,'w').write(s)
edit(W, """//                                      445: splits / splits/{id}/action as merges
""", """//                                      445: splits / splits/{id}/action as merges
//   Asset Value (446)                  GET register/{id}/valuation -> asset-register VIEW;
//                                      POST register/{id}/valuation/recalculate -> asset-register EDIT;
//                                      POST register/{id}/valuation/method (override) -> asset-register APPROVE;
//                                      GET valuation/recalculation -> asset-valuation-config VIEW;
//                                      POST valuation/recalculation (run) -> asset-valuation-config APPROVE
""")
edit(W, """            : isRegister && isTransition                         // 429: lifecycle transition (approval gates in SQL)
            ? Can(area, "EDIT")
""", """            : isRegister && isTransition                         // 429: lifecycle transition (approval gates in SQL)
            ? Can(area, "EDIT")
            : isRegister && lower.EndsWith("/valuation/recalculate")   // 446: one asset now
            ? Can(area, "EDIT")
            : isRegister && lower.EndsWith("/valuation/method")        // 446: method override -- authorized role (5.1.18.5.3)
            ? Can(area, "APPROVE")
""")
edit(W, """            : lower.EndsWith("/approve")                         // 426: firmware compatibility approval
            ? Can(area, "APPROVE")
""", """            : lower.EndsWith("/approve")                         // 426: firmware compatibility approval
            ? Can(area, "APPROVE")
            : isValuation && lower == "valuation/recalculation"    // 446: controlled recalculation run
            ? Can(area, "APPROVE")
""")
edit(W, """                client.Timeout = TimeSpan.FromMinutes(10);                       // 442: batch ingestion
""", """                client.Timeout = TimeSpan.FromMinutes(10);                       // 442: batch ingestion
            if (relativeUrl.EndsWith("/valuation/recalculation", StringComparison.OrdinalIgnoreCase) && method == HttpMethod.Post)
                client.Timeout = TimeSpan.FromMinutes(10);                       // 446: recalculation run
""")
print('web patched')
