# 443: Asset Register -- register a discovery candidate (prefill + link).
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    open(path, 'w', encoding='utf-8', newline='').write(s)
J = "src/PracticeManagement.Web/wwwroot/js/AssetConfig/asset-register.js"
edit(J, [
("""// workflows (start), register/workflows/{id}/step and /cancel.
// =====================================================================
""",
"""// workflows (start), register/workflows/{id}/step and /cancel.
// 443: opened with ?discoveryException={id} (Asset Discovery -> Register),
// New asset is prefilled from the observed values of that reconciliation
// exception (discovery/exceptions/{id}/candidate; list values matched by
// value or label) and, once saved as Draft, the source record is linked to
// it (discovery/exceptions/{id}/resolve, action REGISTER).
// =====================================================================
"""),
("""  const base = "/practice/api/asset-config/register";
""",
"""  const base = "/practice/api/asset-config/register";
  const discoveryBase = "/practice/api/asset-config/discovery";   // 443
"""),
("""    wfDefs: null, wfCase: null
  };
""",
"""    wfDefs: null, wfCase: null,
    discovery: null   // 443: { exceptionId, recordVersion, sourceName, externalKey, values }
  };
"""),
("""    await populateOrgs();
    const sel = document.getElementById("argOrg");
    if (sel.options.length > 1) sel.selectedIndex = 1;
    await changeOrg(Number(sel.value) || null);
  }
""",
"""    await populateOrgs();
    const sel = document.getElementById("argOrg");
    if (sel.options.length > 1) sel.selectedIndex = 1;
    // 443: Asset Discovery -> Register passes the organization and the exception.
    const params = new URLSearchParams(window.location.search);
    const orgParam = params.get("organizationId");
    if (orgParam && [...sel.options].some(o => o.value === orgParam)) sel.value = orgParam;
    await changeOrg(Number(sel.value) || null);
    const excParam = Number(params.get("discoveryException"));
    if (excParam > 0 && state.organizationId) await startFromDiscovery(excParam);
  }

  // 443: New asset prefilled from a discovery candidate (New candidate / Manual review).
  async function startFromDiscovery(exceptionId) {
    const res = await api("GET", `/exceptions/${exceptionId}/candidate?organizationId=${state.organizationId}`, null, discoveryBase);
    if (!res.ok) { showMessage(res.error, "error"); return; }
    const d = res.data.data, x = d.exception;
    if (x.status !== "OPEN" || !["NEW_CANDIDATE", "MANUAL_REVIEW"].includes(x.exceptionKind)) {
      showMessage("This discovery record is no longer an open new candidate; register the asset normally or link it in Asset Discovery.", "info");
      return;
    }
    if (!CAN_ADD) { showMessage("Registering an asset needs the Add permission on the Asset Register.", "error"); return; }
    const values = {};
    (d.attributes || []).forEach(a => { values[a.fieldKey] = a.observedValue; });
    state.discovery = { exceptionId: x.exceptionId, recordVersion: x.recordVersion, sourceName: x.sourceName, externalKey: x.externalKey, values };
    openNew();
    showMessage(`Registering the discovery record ${x.externalKey || "#" + x.exceptionId} from ${x.sourceName}: choose the asset type; `
      + "the form is prefilled from the observed values. The asset is saved as Draft and the source record is linked to it.", "info");
  }

  // 443: the observed value for a field of a new asset, when it fits the field.
  function discoveryValue(f) {
    if (!state.discovery || state.asset || MULTI_TYPES.has(f.dataTypeCode)) return null;
    const v = state.discovery.values[f.fieldKey];
    if (v == null || v === "") return null;
    const opts = optionsFor(f);
    if (opts) {
      const t = String(v).trim().toLowerCase();
      const hit = opts.find(o => String(o.value).toLowerCase() === t) || opts.find(o => String(o.label ?? "").trim().toLowerCase() === t);
      return hit ? String(hit.value) : null;
    }
    return f.dataTypeCode === "DATE" ? String(v).substring(0, 10) : String(v);
  }
"""),
("""    if (f.fieldKey in state.stored) return state.stored[f.fieldKey];
    return state.asset ? "" : (f.defaultValue ?? "");
""",
"""    if (f.fieldKey in state.stored) return state.stored[f.fieldKey];
    return state.asset ? "" : (discoveryValue(f) ?? f.defaultValue ?? "");   // 443
"""),
("""    if (res.ok && body.result === "SAVED") {
      const warnings = (body.issues || []).filter(i => i.severity === "WARNING");
      await openAsset(body.id);
      showMessage(warnings.length ? "Saved with warnings -- see below." : "Asset saved.", "success");
      renderIssues(warnings);
      return;
    }
""",
"""    if (res.ok && body.result === "SAVED") {
      const warnings = (body.issues || []).filter(i => i.severity === "WARNING");
      const linked = !a && state.discovery ? await linkDiscovery(body.id) : null;   // 443
      await openAsset(body.id);
      showMessage(linked || (warnings.length ? "Saved with warnings -- see below." : "Asset saved."), linked && linked.startsWith("Saved") ? "info" : "success");
      renderIssues(warnings);
      return;
    }
"""),
("""  async function api(method, path, body) {
    try {
      const r = await fetch(U(base + path), {
""",
"""  // 443: link the discovery record to the asset just registered for it.
  async function linkDiscovery(assetId) {
    const x = state.discovery;
    state.discovery = null;
    const res = await api("POST", `/exceptions/${x.exceptionId}/resolve`, {
      organizationId: state.organizationId, action: "REGISTER", assetId, note: null, expectedRecordVersion: x.recordVersion
    }, discoveryBase);
    try { window.history.replaceState(null, "", window.location.pathname); } catch (_) { /* address stays */ }
    return res.ok ? `Asset registered as Draft and linked to the discovery record ${x.externalKey || "#" + x.exceptionId} (${x.sourceName}).`
                  : `Saved as Draft, but the discovery record was not linked: ${res.error} Link it in Asset Discovery.`;
  }

  async function api(method, path, body, root) {
    try {
      const r = await fetch(U((root || base) + path), {   // 443: root = another asset-config area
"""),
])
print("pr443 ok")
