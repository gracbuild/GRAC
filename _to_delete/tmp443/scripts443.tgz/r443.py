# Builds 443_c2.sql: sp_asset_reconciliation_resolve (442) re-issued with the
# REGISTER action. Source body verbatim; changed / added lines end with "-- 443".
import re
src = open("/home/claude/442.sql").read()
m = re.search(r"CREATE OR ALTER PROCEDURE grac_practice\.sp_asset_reconciliation_resolve\n.*?\nEND\nGO\n", src, re.S)
body = m.group(0)
open("/home/claude/resolve442_body.sql", "w").write(body)
def rep(a, b):
    global body
    assert body.count(a) == 1, a
    body = body.replace(a, b)
M = "   -- 443"
rep("""    IF @status <> N'OPEN' THROW 54775, 'This exception is already resolved.', 1;
""", """    IF @status <> N'OPEN' THROW 54775, 'This exception is already resolved.', 1;
    -- REGISTER: link a new candidate to the Draft asset just registered for it (D109).""" + M + """
    DECLARE @registered BIT = 0;""" + M + """
    IF @action = N'REGISTER'""" + M + """
    BEGIN""" + M + """
        IF @kind NOT IN (N'NEW_CANDIDATE', N'MANUAL_REVIEW')""" + M + """
            THROW 54793, 'Only a new candidate or a manual review can be registered as a new asset.', 1;""" + M + """
        IF @asset_id IS NULL""" + M + """
           OR NOT EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset a""" + M + """
                            JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id""" + M + """
                           WHERE a.asset_id = @asset_id AND a.organization_id = @organization_id AND s.status_code = N'DRAFT')""" + M + """
           OR EXISTS (SELECT 1 FROM grac_practice.asset_discovery_link k WHERE k.asset_id = @asset_id)""" + M + """
            THROW 54793, 'Register the candidate as a new Draft asset first (Asset Register). An asset already linked to a source is linked with Link.', 1;""" + M + """
        SELECT @action = N'LINK', @registered = 1;""" + M + """
    END""" + M + """
""")
rep("""    DECLARE @upd INT, @conf INT, @result NVARCHAR(20) = @action;
""", """    DECLARE @upd INT, @conf INT, @result NVARCHAR(20) = CASE WHEN @registered = 1 THEN N'REGISTERED' ELSE @action END;""" + M + """
""")
rep("""           SET status = N'RESOLVED', resolution = N'LINKED', resolution_note = ISNULL(@note, CONCAT(N'Linked to asset ', @asset_id, N'.')),
""", """           SET status = N'RESOLVED', resolution = CASE WHEN @registered = 1 THEN N'REGISTERED' ELSE N'LINKED' END,""" + M + """
               resolution_note = ISNULL(@note, CONCAT(N'Linked to asset ', @asset_id, N'.')),""" + M + """
""")
rep("""            (SELECT @action AS resolution, @asset_id AS assetId, @note AS note FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), N'Active', @actor);
""", """            (SELECT @result AS resolution, @asset_id AS assetId, @note AS note FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), N'Active', @actor);""" + M + """
""")
hdr = """
-- =====================================================================
-- 6. sp_asset_reconciliation_resolve (442) re-issued: action REGISTER
-- =====================================================================
-- REGISTER (New candidate / Manual review): @asset_id is the Draft asset
-- registered for the candidate on the Asset Register form, with no source
-- link yet; it is then handled as LINK and the exception is closed as
-- REGISTERED. Every other action is unchanged.
"""
open("/home/claude/443_c2.sql", "w").write(hdr + body + "PRINT '443: sp_asset_reconciliation_resolve re-issued.';\nGO\n")
print("r443 ok")
