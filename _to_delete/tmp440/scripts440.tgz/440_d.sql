
-- =====================================================================
-- 5. Impact analysis (5.4.2, 5.5.2; D84)
-- =====================================================================
-- DOWNSTREAM: the CIs affected when this CI fails (those that depend on it,
-- level by level). UPSTREAM: the CIs this one relies on. Only Active,
-- currently effective relationships of types that carry impact are walked;
-- @preview_relationship_id adds one Proposed relationship (or the pending
-- change of an Active one, by its current endpoints) to preview its effect.
-- Each CI appears once, at its nearest level (no double counting); depth
-- 1-10; @critical_only walks critical dependencies only.
-- 1. affected / supporting CIs  2. summary.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_ci_impact
    @organization_id         BIGINT,
    @ci_kind                 NVARCHAR(12),
    @ci_id                   BIGINT,
    @direction               NVARCHAR(10)  = N'DOWNSTREAM',
    @max_depth               INT           = 5,
    @critical_only           BIT           = 0,
    @preview_relationship_id BIGINT        = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET @ci_kind = UPPER(LTRIM(RTRIM(ISNULL(@ci_kind, N''))));
    SET @direction = UPPER(LTRIM(RTRIM(ISNULL(@direction, N'DOWNSTREAM'))));
    SET @max_depth = CASE WHEN ISNULL(@max_depth, 5) < 1 THEN 1 WHEN @max_depth > 10 THEN 10 ELSE @max_depth END;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54701, 'Organization not found.', 1;
    IF @direction NOT IN (N'DOWNSTREAM', N'UPSTREAM')
       OR NOT EXISTS (SELECT 1 FROM grac_practice.fn_asset_ci_catalog(@organization_id) WHERE CiKind = @ci_kind AND CiId = @ci_id)
        THROW 54720, 'Select a configuration item of this organization and the direction (downstream or upstream).', 1;

    CREATE TABLE #edge (rel BIGINT NOT NULL, type_code NVARCHAR(30) NOT NULL, crit BIT NOT NULL,
                        dk NVARCHAR(12) NOT NULL, di BIGINT NOT NULL, pk NVARCHAR(12) NOT NULL, pi BIGINT NOT NULL);
    INSERT #edge (rel, type_code, crit, dk, di, pk, pi)
    SELECT RelationshipId, TypeCode, IsCritical, DependentKind, DependentId, ProviderKind, ProviderId
      FROM grac_practice.fn_asset_relationship_edges(@organization_id, 1)
     WHERE ISNULL(@critical_only, 0) = 0 OR IsCritical = 1;
    IF @preview_relationship_id IS NOT NULL
        INSERT #edge (rel, type_code, crit, dk, di, pk, pi)
        SELECT e.RelationshipId, e.TypeCode, e.IsCritical, e.DependentKind, e.DependentId, e.ProviderKind, e.ProviderId
          FROM grac_practice.fn_asset_relationship_edges(@organization_id, 0) e
         WHERE e.RelationshipId = @preview_relationship_id
           AND NOT EXISTS (SELECT 1 FROM #edge x WHERE x.rel = e.RelationshipId);

    CREATE TABLE #seen (k NVARCHAR(12) NOT NULL, i BIGINT NOT NULL, lvl INT NOT NULL, rel BIGINT NULL,
                        from_k NVARCHAR(12) NULL, from_i BIGINT NULL, PRIMARY KEY (k, i));
    INSERT #seen (k, i, lvl) VALUES (@ci_kind, @ci_id, 0);
    DECLARE @lvl INT = 0;
    WHILE @lvl < @max_depth
    BEGIN
        -- one row per newly reached CI: the lowest relationship id reaching it from this level
        INSERT #seen (k, i, lvl, rel, from_k, from_i)
        SELECT x.k, x.i, @lvl + 1, x.rel, x.from_k, x.from_i
          FROM (SELECT CASE WHEN @direction = N'DOWNSTREAM' THEN e.dk ELSE e.pk END AS k,
                       CASE WHEN @direction = N'DOWNSTREAM' THEN e.di ELSE e.pi END AS i,
                       e.rel, s.k AS from_k, s.i AS from_i,
                       ROW_NUMBER() OVER (PARTITION BY CASE WHEN @direction = N'DOWNSTREAM' THEN e.dk ELSE e.pk END,
                                                       CASE WHEN @direction = N'DOWNSTREAM' THEN e.di ELSE e.pi END
                                          ORDER BY e.crit DESC, e.rel) AS rn
                  FROM #edge e
                  JOIN #seen s ON s.lvl = @lvl
                              AND ((@direction = N'DOWNSTREAM' AND s.k = e.pk AND s.i = e.pi)
                                   OR (@direction = N'UPSTREAM' AND s.k = e.dk AND s.i = e.di))) x
         WHERE x.rn = 1
           AND NOT EXISTS (SELECT 1 FROM #seen z WHERE z.k = x.k AND z.i = x.i);
        IF @@ROWCOUNT = 0 BREAK;
        SET @lvl = @lvl + 1;
    END

    SELECT s.k AS CiKind, s.i AS CiId, c.CiName, c.CiClass, c.CiStatus, s.lvl AS ImpactLevel, s.rel AS ViaRelationshipId,
           e.type_code AS ViaTypeCode,
           CASE WHEN @direction = N'DOWNSTREAM' THEN
                     CASE t.dependent_side WHEN N'SOURCE' THEN t.type_name ELSE t.inverse_label END
                ELSE CASE t.dependent_side WHEN N'SOURCE' THEN t.inverse_label ELSE t.type_name END END AS ViaLabel,
           e.crit AS ViaCritical, s.from_k AS FromKind, s.from_i AS FromId, fc.CiName AS FromName,
           CAST(CASE WHEN e.rel = @preview_relationship_id THEN 1 ELSE 0 END AS BIT) AS ViaPreview
      FROM #seen s
      JOIN #edge e ON e.rel = s.rel
      JOIN grac_practice.asset_relationship_type t ON t.type_code = e.type_code
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) c ON c.CiKind = s.k AND c.CiId = s.i
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) fc ON fc.CiKind = s.from_k AND fc.CiId = s.from_i
     WHERE s.lvl > 0
     ORDER BY s.lvl, c.CiKind, c.CiName;

    SELECT @ci_kind AS CiKind, @ci_id AS CiId, (SELECT CiName FROM grac_practice.fn_asset_ci_catalog(@organization_id)
                                                  WHERE CiKind = @ci_kind AND CiId = @ci_id) AS CiName,
           @direction AS Direction, @max_depth AS MaxDepth,
           (SELECT COUNT(*) FROM #seen WHERE lvl > 0) AS ReachedCount,
           (SELECT COUNT(*) FROM #seen s JOIN #edge e ON e.rel = s.rel WHERE s.lvl > 0 AND e.crit = 1) AS CriticalCount,
           (SELECT MAX(lvl) FROM #seen) AS DeepestLevel;
END
GO
PRINT '440: impact analysis created.';
GO

-- =====================================================================
-- 6. Readers
-- =====================================================================
-- 1. relationship types  2. active employees.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationship_config_get
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54701, 'Organization not found.', 1;
    SELECT type_code AS TypeCode, type_name AS TypeName, inverse_label AS InverseLabel, brd_pair AS BrdPair, description AS Description,
           source_kinds AS SourceKinds, target_kinds AS TargetKinds, cardinality AS Cardinality, loop_rule AS LoopRule,
           dependent_side AS DependentSide, is_active AS IsActive, inactive_reason AS InactiveReason
      FROM grac_practice.asset_relationship_type
     ORDER BY display_order;
    SELECT employee_id AS EmployeeId, employee_name AS EmployeeName
      FROM grac_practice.organization_employee
     WHERE organization_id = @organization_id AND status = N'Active'
     ORDER BY employee_name;
END
GO

-- CI picker: up to @top configuration items of a kind (or every kind)
-- whose name or class matches.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_ci_lookup
    @organization_id BIGINT,
    @ci_kind         NVARCHAR(12)  = NULL,
    @search          NVARCHAR(200) = NULL,
    @top             INT           = 50
AS
BEGIN
    SET NOCOUNT ON;
    SET @ci_kind = NULLIF(UPPER(LTRIM(RTRIM(@ci_kind))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @top = CASE WHEN ISNULL(@top, 50) < 1 THEN 50 WHEN @top > 200 THEN 200 ELSE @top END;
    SELECT TOP (@top) c.CiKind, c.CiId, c.CiName, c.CiClass, c.CiStatus, c.IsUsable
      FROM grac_practice.fn_asset_ci_catalog(@organization_id) c
     WHERE (@ci_kind IS NULL OR c.CiKind = @ci_kind)
       AND (@search IS NULL OR c.CiName LIKE N'%' + @search + N'%' OR c.CiClass LIKE N'%' + @search + N'%')
     ORDER BY c.IsUsable DESC, c.CiName;
END
GO

-- Relationships (Inactive ones refreshed first). @status: NULL = current
-- (proposed, active, disputed), ALL, or one status. @ci_kind / @ci_id: either
-- end. @pending_only: proposals and pending changes waiting for approval.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationships
    @organization_id BIGINT,
    @ci_kind         NVARCHAR(12)  = NULL,
    @ci_id           BIGINT        = NULL,
    @type_code       NVARCHAR(30)  = NULL,
    @status          NVARCHAR(10)  = NULL,
    @critical_only   BIT           = 0,
    @pending_only    BIT           = 0,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25,
    @actor           NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54701, 'Organization not found.', 1;
    SET @ci_kind = NULLIF(UPPER(LTRIM(RTRIM(@ci_kind))), N'');
    SET @type_code = NULLIF(UPPER(LTRIM(RTRIM(@type_code))), N'');
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    EXEC grac_practice.sp_asset_relationship_sync @organization_id = @organization_id, @actor = @actor;

    SELECT r.relationship_id AS RelationshipId, r.relationship_type_code AS TypeCode, t.type_name AS TypeName,
           t.inverse_label AS InverseLabel, t.dependent_side AS DependentSide,
           r.source_kind AS SourceKind, r.source_id AS SourceId, sc.CiName AS SourceName, sc.CiClass AS SourceClass,
           sc.CiStatus AS SourceStatus, r.target_kind AS TargetKind, r.target_id AS TargetId, tc.CiName AS TargetName,
           tc.CiClass AS TargetClass, tc.CiStatus AS TargetStatus, r.is_critical AS IsCritical,
           r.dependency_criticality AS DependencyCriticality, r.impact_weight AS ImpactWeight, r.status AS Status,
           r.effective_from AS EffectiveFrom, r.effective_to AS EffectiveTo, r.source_code AS SourceCode,
           r.confidence_pct AS ConfidencePct, r.verification_status AS VerificationStatus, ow.employee_name AS OwnerName,
           vf.employee_name AS VerifierName, r.in_loop AS InLoop, r.version_no AS VersionNo, r.pending_action AS PendingAction,
           r.pending_reason AS PendingReason, r.pending_by AS PendingBy, r.retirement_accepted AS RetirementAccepted,
           r.proposed_by AS ProposedBy, r.approved_by AS ApprovedBy, r.approved_dt AS ApprovedDt, r.status_note AS StatusNote,
           CONVERT(BIGINT, r.record_version) AS RecordVersion,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_relationship r
      JOIN grac_practice.asset_relationship_type t ON t.type_code = r.relationship_type_code
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) sc ON sc.CiKind = r.source_kind AND sc.CiId = r.source_id
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) tc ON tc.CiKind = r.target_kind AND tc.CiId = r.target_id
      LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = r.owner_employee_id
      LEFT JOIN grac_practice.organization_employee vf ON vf.employee_id = r.verifier_employee_id
     WHERE r.organization_id = @organization_id
       AND (@ci_kind IS NULL OR @ci_id IS NULL
            OR (r.source_kind = @ci_kind AND r.source_id = @ci_id) OR (r.target_kind = @ci_kind AND r.target_id = @ci_id))
       AND (@type_code IS NULL OR r.relationship_type_code = @type_code)
       AND ((@status IS NULL AND r.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')) OR @status = N'ALL' OR r.status = @status)
       AND (ISNULL(@critical_only, 0) = 0 OR r.is_critical = 1)
       AND (ISNULL(@pending_only, 0) = 0 OR r.status = N'PROPOSED' OR r.pending_action IS NOT NULL)
       AND (@search IS NULL OR sc.CiName LIKE N'%' + @search + N'%' OR tc.CiName LIKE N'%' + @search + N'%')
     ORDER BY CASE WHEN r.status = N'PROPOSED' OR r.pending_action IS NOT NULL THEN 0 WHEN r.status = N'DISPUTED' THEN 1
                   WHEN r.status = N'ACTIVE' THEN 2 ELSE 3 END,
              r.is_critical DESC, sc.CiName, t.display_order, tc.CiName
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- One relationship: 1. the relationship  2. history.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationship_get
    @organization_id BIGINT,
    @relationship_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_relationship
                    WHERE relationship_id = @relationship_id AND organization_id = @organization_id)
        THROW 54709, 'Relationship not found for this organization.', 1;
    SELECT r.relationship_id AS RelationshipId, r.relationship_type_code AS TypeCode, t.type_name AS TypeName,
           t.inverse_label AS InverseLabel, t.dependent_side AS DependentSide, r.source_kind AS SourceKind, r.source_id AS SourceId,
           sc.CiName AS SourceName, sc.CiClass AS SourceClass, sc.CiStatus AS SourceStatus, r.target_kind AS TargetKind,
           r.target_id AS TargetId, tc.CiName AS TargetName, tc.CiClass AS TargetClass, tc.CiStatus AS TargetStatus,
           r.is_critical AS IsCritical, r.dependency_criticality AS DependencyCriticality, r.impact_weight AS ImpactWeight,
           r.status AS Status, r.effective_from AS EffectiveFrom, r.effective_to AS EffectiveTo, r.source_code AS SourceCode,
           r.confidence_pct AS ConfidencePct, r.verification_status AS VerificationStatus, r.owner_employee_id AS OwnerEmployeeId,
           ow.employee_name AS OwnerName, r.verifier_employee_id AS VerifierEmployeeId, vf.employee_name AS VerifierName,
           r.evidence_reference AS EvidenceReference, r.change_reference AS ChangeReference, r.reason AS Reason, r.in_loop AS InLoop,
           r.version_no AS VersionNo, r.proposed_by AS ProposedBy, r.proposed_dt AS ProposedDt, r.approved_by AS ApprovedBy,
           r.approved_dt AS ApprovedDt, r.pending_action AS PendingAction, r.pending_json AS PendingJson,
           r.pending_reason AS PendingReason, r.pending_by AS PendingBy, r.pending_dt AS PendingDt,
           r.retirement_accepted AS RetirementAccepted, r.retirement_note AS RetirementNote,
           r.retirement_accepted_by AS RetirementAcceptedBy, r.retirement_accepted_dt AS RetirementAcceptedDt,
           r.status_note AS StatusNote, CONVERT(BIGINT, r.record_version) AS RecordVersion
      FROM grac_practice.asset_relationship r
      JOIN grac_practice.asset_relationship_type t ON t.type_code = r.relationship_type_code
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) sc ON sc.CiKind = r.source_kind AND sc.CiId = r.source_id
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) tc ON tc.CiKind = r.target_kind AND tc.CiId = r.target_id
      LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = r.owner_employee_id
      LEFT JOIN grac_practice.organization_employee vf ON vf.employee_id = r.verifier_employee_id
     WHERE r.relationship_id = @relationship_id;
    SELECT h.history_id AS HistoryId, h.version_no AS VersionNo, h.action_code AS ActionCode, h.status AS Status,
           h.note AS Note, h.actor AS Actor, e.employee_name AS ActorName, h.entered_dt AS EnteredDt, h.snapshot_json AS SnapshotJson
      FROM grac_practice.asset_relationship_history h
      LEFT JOIN grac_practice.organization_employee e ON e.employee_id = h.actor_employee_id
     WHERE h.relationship_id = @relationship_id
     ORDER BY h.history_id DESC;
END
GO
PRINT '440: readers created.';
GO
