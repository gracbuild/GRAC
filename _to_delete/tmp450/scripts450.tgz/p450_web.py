import sys,json
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w450/new'
def edit(path, old, new, count=1):
    s=open(path).read(); assert s.count(old)==count, (path, old[:80], s.count(old)); open(path,'w').write(s.replace(old,new))
W=R+'/src/PracticeManagement.Web/Controllers/AssetConfigController.cs'
edit(W, """//   privacy... (448)                   asset-privacy: GET VIEW (organization required); POST requirements,
""", """//   governance... (450)                asset-governance: GET VIEW (organization required); POST settings,
//                                      settings/overall, relationship-rules, snapshot EDIT
//   privacy... (448)                   asset-privacy: GET VIEW (organization required); POST requirements,
""")
edit(W, """    private const string PrivacyArea = "asset-privacy";              // 448
""", """    private const string PrivacyArea = "asset-privacy";              // 448
    private const string GovernanceArea = "asset-governance";        // 450
""")
edit(W, """        else if (lower.StartsWith("privacy/"))                                  // 448
""", """        else if (lower == "governance" || lower.StartsWith("governance/"))     // 450
        {
            if (!long.TryParse(Request.Query["organizationId"], out var orgId) || orgId <= 0)
                return BadRequest(new { error = "organizationId is required." });
            if (!HttpContext.IsOrganizationAllowed(orgId)) return OrganizationDenied();
            allowed = Can(GovernanceArea, "VIEW");
        }
        else if (lower.StartsWith("privacy/"))                                  // 448
""")
edit(W, """        var isPrivacy = lower.StartsWith("privacy/");                            // 448
""", """        var isPrivacy = lower.StartsWith("privacy/");                            // 448
        var isGovernance = lower.StartsWith("governance/");                      // 450
""")
edit(W, """            && !isActivity && !isRelationship && !isService && !isDiscovery && !isPrivacy && !lower.StartsWith("templates"))""",
"""            && !isActivity && !isRelationship && !isService && !isDiscovery && !isPrivacy && !isGovernance && !lower.StartsWith("templates"))""")
edit(W, """        var area = isPrivacy ? PrivacyArea : isDiscovery""", """        var area = isGovernance ? GovernanceArea : isPrivacy ? PrivacyArea : isDiscovery""")
edit(W, """            : isPrivacy
            ? false
""", """            : isPrivacy
            ? false
            : isGovernance && (lower == "governance/settings" || lower == "governance/settings/overall"   // 450
                               || lower == "governance/relationship-rules" || lower == "governance/snapshot")
            ? Can(area, "EDIT")
            : isGovernance
            ? false
""")
for app in ['/src/PracticeManagement.Web/appsettings.json','/src/PracticeManagement.Api/appsettings.json']:
    edit(R+app, '"asset-privacy:*"', '"asset-privacy:*", "asset-governance:*"')
    json.load(open(R+app))
P=R+'/src/PracticeManagement.Web/Models/PracticeScreen.cs'
s=open(P).read()
i=s.index('        new("asset-privacy",'); j=s.index('\n', i)
s=s[:j]+"""
        // Phase 8.4a (migration 450): governance KPIs -- BRD 19.8 scores
        // with snapshots, record drill-down, thresholds and weights.
        new("asset-governance","Asset Governance","Governance KPIs of the asset register (BRD 19.8): attestation compliance, metadata, ownership and relationship completeness, coverage and technology support compliance, exception health, discovery freshness, reconciliation backlog and connector availability -- scores against thresholds, the overall score, trends, snapshot history and the exact numerator, denominator, excluded and failing records of every score.","gauge-high",["KPI","Score","Numerator","Denominator","Rating"], AssetContractGroup),"""+s[j:]
open(P,'w').write(s)
edit(R+'/src/PracticeManagement.Web/Views/Practice/Manage.cshtml', """        // Phase 8.3 (migration 448): privacy.
        "asset-privacy"
""", """        // Phase 8.3 (migration 448): privacy.
        "asset-privacy",
        // Phase 8.4a (migration 450): governance KPIs.
        "asset-governance"
""")
M=R+'/database/274_menu_master_seed.sql'
edit(M, """--   448 -- 'asset-privacy' (364, Asset Privacy) under
--     'nav-asset-contract'.
""", """--   448 -- 'asset-privacy' (364, Asset Privacy) under
--     'nav-asset-contract'.
--   450 -- 'asset-governance' (365, Asset Governance) under
--     'nav-asset-contract'.
""")
edit(M, """    (N'asset-privacy'                 , N'Asset Privacy'                     , N'Practice/Index/asset-privacy'               ,  364, N'user-shield'           , N'Asset & Contract'           , N'Active')   -- 448
""", """    (N'asset-privacy'                 , N'Asset Privacy'                     , N'Practice/Index/asset-privacy'               ,  364, N'user-shield'           , N'Asset & Contract'           , N'Active'),  -- 448
    (N'asset-governance'              , N'Asset Governance'                  , N'Practice/Index/asset-governance'            ,  365, N'gauge-high'            , N'Asset & Contract'           , N'Active')   -- 450
""")
edit(M, """    (N'asset-privacy'                 , N'nav-asset-contract')   -- 448
""", """    (N'asset-privacy'                 , N'nav-asset-contract'),  -- 448
    (N'asset-governance'              , N'nav-asset-contract')   -- 450
""")
print('web patched')
