-- =====================================================================
-- 9. Verification
-- =====================================================================
SELECT '447-a objects' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_consistency_rule','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_consistency_rule_condition','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_consistency_finding','U') IS NOT NULL
             AND EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_pm_acons_finding_open')
             AND EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_pm_acons_rule_active')
             AND OBJECT_ID('grac_practice.fn_asset_consistency_operands') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_consistency_facts') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_consistency_eval') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_consistency_scope_label') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_risk_value') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_consistency_evaluate','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_consistency_run','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_consistency_finding_action','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_consistency_rule_save','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_consistency_rule_action','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_consistency_rules','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_consistency_rule_get','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_consistency_operands','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_consistency_rule_preview','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_consistency_findings','P') IS NOT NULL
             AND EXISTS (SELECT 1 FROM grac_practice.task_type_master WHERE type_code = N'AssetConsistency')
            THEN 'PASS' ELSE 'FAIL' END AS Result;
SELECT '447-b re-issued bodies' AS Check_,
       CASE WHEN OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_register_save')) LIKE '%sp_asset_consistency_evaluate%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_register_save')) LIKE '%sp_asset_valuation_apply%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) LIKE '%sp_asset_consistency_evaluate%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) LIKE '%sp_asset_valuation_sync%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_lifecycle_transition')) LIKE '%53037%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_lifecycle_transition')) LIKE '%54719%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_valuation_get')) LIKE '%fn_asset_risk_value%'
            THEN 'PASS' ELSE 'FAIL' END AS Result;
-- Every organization evaluates without error and the derived operands are listed.
SELECT '447-c functions run' AS Check_,
       (SELECT COUNT(*) FROM grac_practice.organization o CROSS APPLY grac_practice.fn_asset_consistency_eval(o.organization_id, NULL, NULL) e) AS RuleAssetPairs,
       (SELECT COUNT(*) FROM grac_practice.organization o CROSS APPLY grac_practice.fn_asset_risk_value(o.organization_id) r) AS RisksWithAssets,
       CASE WHEN (SELECT COUNT(*) FROM grac_practice.fn_asset_consistency_operands() WHERE OperandKind = N'DERIVED') = 5
            THEN 'PASS' ELSE 'FAIL' END AS Result;
GO

/* =====================================================================
   UAT (asset-valuation-config EDIT and APPROVE held by two people;
   asset-register EDIT and APPROVE likewise)
   ---------------------------------------------------------------------
   1. Asset Valuation -> Consistency rules -> New rule "Critical value,
      low criticality": scope Whole organization, severity Approval
      Required, action Block transition, conditions (group 1)
      asset_value_category EQ Critical AND CRITICALITY EQ Low. Save.
      Preview lists the matching assets. Activate as the same person ->
      refused (segregation); activate as the second person -> Active,
      version 1; findings open for the matching assets.
   2. Asset Register: such an asset shows the finding on its Valuation
      tab and the save shows "Consistency (approval required) ...".
      Lifecycle -> Active is refused with 53037.
   3. Accept the finding (rationale, evidence, owner, review date) ->
      Awaiting approval; approve as the requester -> refused; approve as
      another APPROVE holder -> Accepted; the move to Active is allowed.
   4. Change the criticality to High and save -> the finding is Resolved.
   5. New version of the rule (reason) -> Draft v2; edit, activate ->
      v1 Retired with an end date; findings refreshed.
   6. A rule with action Create task -> a Task Centre task of type Asset
      Consistency for the asset owner.
   7. Set a review date of tomorrow, then (next day) run the scheduler or
      Re-evaluate -> the acceptance reopens.
   8. A risk linked to the asset: the Valuation tab lists it; after a
      recalculation that changes the Asset Value it shows Review
      suggested.
   ===================================================================== */
