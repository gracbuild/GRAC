import sys
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w447/new'
W=R+'/src/PracticeManagement.Web/Controllers/AssetConfigController.cs'
def edit(old, new, count=1):
    s=open(W).read(); assert s.count(old)==count, (old[:80], s.count(old)); open(W,'w').write(s.replace(old,new))
edit("""//                                      POST valuation/recalculation (run) -> asset-valuation-config APPROVE
""", """//                                      POST valuation/recalculation (run) -> asset-valuation-config APPROVE
//   Consistency rules (447)            GET valuation/consistency/... -> asset-valuation-config VIEW;
//                                      POST valuation/consistency/rules ADD or EDIT;
//                                      .../rules/{id}/action ACTIVATE / RETIRE -> APPROVE, NEW_VERSION / DISCARD -> ADD or EDIT;
//                                      GET register/consistency/findings -> asset-register VIEW;
//                                      POST register/consistency/findings/{id}/action ACCEPT / WITHDRAW -> EDIT,
//                                      APPROVE / REJECT / REVOKE -> APPROVE; POST register/consistency/run -> EDIT
""")
edit("""            : isRegister && lower.EndsWith("/valuation/recalculate")   // 446: one asset now
            ? Can(area, "EDIT")
""", """            : isRegister && lower.EndsWith("/valuation/recalculate")   // 446: one asset now
            ? Can(area, "EDIT")
            : isRegister && lower.StartsWith("register/consistency/findings/") && lower.EndsWith("/action")   // 447
            ? (exceptionAction is "APPROVE" or "REJECT" or "REVOKE" ? Can(area, "APPROVE") : Can(area, "EDIT"))
            : isRegister && lower == "register/consistency/run"      // 447: re-evaluate
            ? Can(area, "EDIT")
""")
edit("""            : isValuation && lower == "valuation/recalculation"    // 446: controlled recalculation run
            ? Can(area, "APPROVE")
""", """            : isValuation && lower == "valuation/recalculation"    // 446: controlled recalculation run
            ? Can(area, "APPROVE")
            : isValuation && lower.StartsWith("valuation/consistency/rules/") && lower.EndsWith("/action")   // 447
            ? (exceptionAction is "ACTIVATE" or "RETIRE" ? Can(area, "APPROVE") : Can(area, "ADD", "EDIT"))
""")
print('web patched')
