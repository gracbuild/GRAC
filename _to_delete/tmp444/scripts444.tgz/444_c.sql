
-- =====================================================================
-- 4. Merge event writers (D115, D120)
-- =====================================================================
-- Critical CI (19.4 two-person control): the survivor or a duplicate has
-- criticality Critical, or a current critical relationship relies on it.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_merge_critical (@organization_id BIGINT, @event_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT CAST(CASE WHEN EXISTS (
                SELECT 1
                  FROM (SELECT survivor_asset_id AS asset_id FROM grac_practice.asset_merge_split_event WHERE event_id = @event_id
                        UNION SELECT asset_id FROM grac_practice.asset_merge_split_member WHERE event_id = @event_id) m
                  JOIN grac_practice.organization_dependency_asset a ON a.asset_id = m.asset_id
                  LEFT JOIN grac_practice.criticality_master c ON c.criticality_id = a.criticality_id
                 WHERE c.criticality_code = N'Critical'
                    OR EXISTS (SELECT 1 FROM grac_practice.fn_asset_relationship_edges(@organization_id, 1) e
                                WHERE e.ProviderKind = N'ASSET' AND e.ProviderId = m.asset_id AND e.IsCritical = 1))
                THEN 1 ELSE 0 END AS BIT) AS IsCritical;
GO

-- New or changed Draft: survivor, duplicates (JSON array of asset ids,
-- 1-10), reason, field choices ({"fieldKey": duplicateAssetId}).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_merge_save
    @organization_id         BIGINT,
    @event_id                BIGINT         = NULL,
    @survivor_asset_id       BIGINT,
    @duplicates_json         NVARCHAR(MAX),
    @reason                  NVARCHAR(1000) = NULL,
    @field_choices_json      NVARCHAR(MAX)  = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @reason = NULLIF(LTRIM(RTRIM(@reason)), N'');
    SET @field_choices_json = NULLIF(LTRIM(RTRIM(@field_choices_json)), N'');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 52900, 'Organization not found.', 1;
    IF @event_id IS NOT NULL
    BEGIN
        DECLARE @found BIT = 0, @status NVARCHAR(20), @rv BIGINT;
        SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version)
          FROM grac_practice.asset_merge_split_event
         WHERE event_id = @event_id AND organization_id = @organization_id AND event_kind = N'MERGE';
        IF @found = 0 THROW 52902, 'Merge not found for this organization.', 1;
        IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
            THROW 52903, 'The merge was changed by someone else; reload it and try again.', 1;
        IF @status <> N'DRAFT' THROW 52907, 'Only a draft merge can be changed.', 1;
    END

    DECLARE @dups TABLE (asset_id BIGINT NOT NULL PRIMARY KEY, seq INT NOT NULL);
    IF ISJSON(ISNULL(@duplicates_json, N'')) = 1
        INSERT @dups (asset_id, seq)
        SELECT d.asset_id, ROW_NUMBER() OVER (ORDER BY MIN(d.ord))
          FROM (SELECT TRY_CONVERT(BIGINT, j.[value]) AS asset_id, CAST(j.[key] AS INT) AS ord FROM OPENJSON(@duplicates_json) j) d
         WHERE d.asset_id IS NOT NULL
         GROUP BY d.asset_id;
    IF (SELECT COUNT(*) FROM @dups) NOT BETWEEN 1 AND 10
        THROW 52913, 'Choose 1 to 10 duplicate assets.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset WHERE asset_id = @survivor_asset_id AND organization_id = @organization_id)
       OR EXISTS (SELECT 1 FROM @dups d WHERE NOT EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset a
                                                           WHERE a.asset_id = d.asset_id AND a.organization_id = @organization_id))
        THROW 52901, 'Asset not found for this organization.', 1;
    IF EXISTS (SELECT 1 FROM @dups WHERE asset_id = @survivor_asset_id)
       OR EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset a
                    LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
                   WHERE (a.asset_id = @survivor_asset_id OR a.asset_id IN (SELECT asset_id FROM @dups))
                     AND (a.merged_into_asset_id IS NOT NULL OR ISNULL(s.status_code, N'ACTIVE') IN (N'DISPOSED', N'ARCHIVED')))
        THROW 52904, 'The survivor and the duplicates must be different assets in use (not disposed, archived or merged).', 1;
    IF EXISTS (SELECT 1 FROM grac_practice.asset_merge_split_event e
                WHERE e.organization_id = @organization_id AND e.status IN (N'DRAFT', N'PENDING_APPROVAL', N'APPROVED')
                  AND e.event_id <> ISNULL(@event_id, -1)
                  AND (e.survivor_asset_id = @survivor_asset_id OR e.survivor_asset_id IN (SELECT asset_id FROM @dups)
                       OR EXISTS (SELECT 1 FROM grac_practice.asset_merge_split_member m
                                   WHERE m.event_id = e.event_id
                                     AND (m.asset_id = @survivor_asset_id OR m.asset_id IN (SELECT asset_id FROM @dups)))))
        THROW 52905, 'One of these assets is already in another open merge or split; finish or cancel it first.', 1;
    -- Field choices: mergeable value fields, each naming a duplicate that holds a value.
    IF @field_choices_json IS NOT NULL
    BEGIN
        IF ISJSON(@field_choices_json) = 0 OR LEFT(@field_choices_json, 1) <> N'{'
            THROW 52912, 'The field choices are not valid.', 1;
        IF EXISTS (SELECT 1 FROM OPENJSON(@field_choices_json) j
                    LEFT JOIN grac_practice.asset_field_definition f ON f.field_key = j.[key] COLLATE DATABASE_DEFAULT AND f.storage_kind = N'VALUE'
                                                                     AND f.is_system_field = 0
                    LEFT JOIN grac_practice.asset_field_data_type_master dt ON dt.data_type_code = f.data_type_code AND dt.is_user_entered = 1
                    LEFT JOIN @dups d ON d.asset_id = TRY_CONVERT(BIGINT, j.[value])
                    LEFT JOIN grac_practice.asset_field_value v ON v.asset_id = d.asset_id AND v.field_definition_id = f.field_definition_id
                   WHERE dt.data_type_code IS NULL OR d.asset_id IS NULL OR v.asset_id IS NULL)
            THROW 52912, 'Each field choice names a user-entered value field and a duplicate that holds a value for it.', 1;
    END

    DECLARE @id BIGINT = @event_id, @result NVARCHAR(20) = CASE WHEN @event_id IS NULL THEN N'CREATED' ELSE N'SAVED' END;
    BEGIN TRAN;
    IF @id IS NULL
    BEGIN
        INSERT grac_practice.asset_merge_split_event
            (organization_id, event_kind, survivor_asset_id, status, reason, field_choices_json, requested_by, requested_by_employee_id)
        VALUES (@organization_id, N'MERGE', @survivor_asset_id, N'DRAFT', @reason, @field_choices_json, @actor, @actor_employee_id);
        SET @id = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE grac_practice.asset_merge_split_event
           SET survivor_asset_id = @survivor_asset_id, reason = @reason, field_choices_json = @field_choices_json
         WHERE event_id = @id;
        DELETE FROM grac_practice.asset_merge_split_member WHERE event_id = @id;
    END
    INSERT grac_practice.asset_merge_split_member (event_id, asset_id, member_role, sequence_no)
    SELECT @id, asset_id, N'DUPLICATE', seq FROM @dups;
    UPDATE e
       SET is_critical = c.IsCritical, approvals_required = CASE WHEN c.IsCritical = 1 THEN 2 ELSE 1 END
      FROM grac_practice.asset_merge_split_event e
     CROSS APPLY grac_practice.fn_asset_merge_critical(@organization_id, @id) c
     WHERE e.event_id = @id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-merge', @id, CASE WHEN @event_id IS NULL THEN N'CREATE' ELSE N'UPDATE' END, NULL,
            (SELECT @survivor_asset_id AS survivorAssetId, JSON_QUERY(@duplicates_json) AS duplicates, @reason AS reason,
                    JSON_QUERY(@field_choices_json) AS fieldChoices FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @id AS EventId, @result AS Result;
END
GO

-- =====================================================================
-- 5. Execution of one duplicate (internal; called inside the EXECUTE
--    transaction of sp_asset_merge_action). Outcome rows first, then the
--    change, so every row carries its before / after values.
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_merge_execute_one
    @organization_id    BIGINT,
    @event_id           BIGINT,
    @survivor           BIGINT,
    @duplicate          BIGINT,
    @field_choices_json NVARCHAR(MAX)  = NULL,
    @actor_employee_id  BIGINT         = NULL,
    @actor              NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @plan TABLE (object_kind NVARCHAR(20) NOT NULL, object_id BIGINT NULL, object_key NVARCHAR(200) NULL,
                         object_label NVARCHAR(400) NULL, outcome NVARCHAR(10) NOT NULL, detail NVARCHAR(600) NULL);
    INSERT @plan (object_kind, object_id, object_key, object_label, outcome, detail)
    SELECT ObjectKind, ObjectId, ObjectKey, ObjectLabel, Outcome, Detail
      FROM grac_practice.fn_asset_merge_plan(@organization_id, @survivor, @duplicate);
    IF EXISTS (SELECT 1 FROM @plan WHERE outcome = N'BLOCK')
       OR EXISTS (SELECT 1 FROM grac_practice.fn_asset_merge_blockers(@organization_id, @survivor, @duplicate))
        THROW 52908, 'The merge has blockers; open it to see them.', 1;
    DECLARE @survivor_name NVARCHAR(300) = (SELECT asset_name FROM grac_practice.organization_dependency_asset WHERE asset_id = @survivor);
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE), @note NVARCHAR(400) = CONCAT(N'Merge #', @event_id, N': asset #', @duplicate,
                                                                                    N' merged into #', @survivor, N'.');

    -- ---------------------------------------------------------- relationships
    DECLARE @rid BIGINT, @rout NVARCHAR(10);
    DECLARE rel_cur CURSOR LOCAL STATIC FOR
        SELECT object_id, outcome FROM @plan WHERE object_kind = N'RELATIONSHIP' ORDER BY object_id;
    OPEN rel_cur;
    FETCH NEXT FROM rel_cur INTO @rid, @rout;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @rout = N'MOVE'
        BEGIN
            INSERT grac_practice.asset_merge_split_object
                (event_id, object_kind, object_id, object_label, from_asset_id, to_asset_id, outcome, before_value, after_value, detail)
            SELECT @event_id, N'RELATIONSHIP', r.relationship_id, p.object_label, @duplicate, @survivor, N'MOVED',
                   (SELECT r.source_id AS sourceId, r.target_id AS targetId FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
                   (SELECT CASE WHEN r.source_kind = N'ASSET' AND r.source_id = @duplicate THEN @survivor ELSE r.source_id END AS sourceId,
                           CASE WHEN r.target_kind = N'ASSET' AND r.target_id = @duplicate THEN @survivor ELSE r.target_id END AS targetId
                       FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), p.detail
              FROM grac_practice.asset_relationship r JOIN @plan p ON p.object_kind = N'RELATIONSHIP' AND p.object_id = r.relationship_id
             WHERE r.relationship_id = @rid;
            UPDATE grac_practice.asset_relationship
               SET source_id = CASE WHEN source_kind = N'ASSET' AND source_id = @duplicate THEN @survivor ELSE source_id END,
                   target_id = CASE WHEN target_kind = N'ASSET' AND target_id = @duplicate THEN @survivor ELSE target_id END,
                   version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE relationship_id = @rid;
            EXEC grac_practice.sp_asset_relationship_history_add @relationship_id = @rid, @action_code = N'MERGE_MOVE', @note = @note,
                 @actor = @actor, @actor_employee_id = @actor_employee_id;
        END
        ELSE
        BEGIN
            INSERT grac_practice.asset_merge_split_object
                (event_id, object_kind, object_id, object_label, from_asset_id, to_asset_id, outcome, before_value, after_value, detail)
            SELECT @event_id, N'RELATIONSHIP', r.relationship_id, p.object_label, @duplicate, @survivor, N'ENDED',
                   (SELECT r.status AS status, r.effective_to AS effectiveTo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
                   N'{"status":"RETIRED"}', p.detail
              FROM grac_practice.asset_relationship r JOIN @plan p ON p.object_kind = N'RELATIONSHIP' AND p.object_id = r.relationship_id
             WHERE r.relationship_id = @rid;
            UPDATE grac_practice.asset_relationship
               SET status = N'RETIRED', effective_to = CASE WHEN @today < effective_from THEN effective_from ELSE @today END,
                   status_note = @note, version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE relationship_id = @rid;
            EXEC grac_practice.sp_asset_relationship_history_add @relationship_id = @rid, @action_code = N'MERGE_END', @note = @note,
                 @actor = @actor, @actor_employee_id = @actor_employee_id;
        END
        FETCH NEXT FROM rel_cur INTO @rid, @rout;
    END
    CLOSE rel_cur;
    DEALLOCATE rel_cur;

    -- ---------------------------------------------------------- discovery links and per-source values
    INSERT grac_practice.asset_merge_split_object (event_id, object_kind, object_id, object_key, object_label, from_asset_id, to_asset_id, outcome, detail)
    SELECT @event_id, N'DISCOVERY_LINK', p.object_id, p.object_key, p.object_label, @duplicate, @survivor, N'MOVED', p.detail
      FROM @plan p WHERE p.object_kind = N'DISCOVERY_LINK';
    UPDATE l SET asset_id = @survivor
      FROM grac_practice.asset_discovery_link l JOIN @plan p ON p.object_kind = N'DISCOVERY_LINK' AND p.object_id = l.link_id;

    INSERT grac_practice.asset_merge_split_object (event_id, object_kind, object_id, object_key, object_label, from_asset_id, to_asset_id, outcome, detail)
    SELECT @event_id, N'ATTRIBUTE_SOURCE', p.object_id, p.object_key, p.object_label, @duplicate, @survivor,
           CASE p.outcome WHEN N'MOVE' THEN N'MOVED' ELSE N'KEPT' END, p.detail
      FROM @plan p WHERE p.object_kind = N'ATTRIBUTE_SOURCE';
    UPDATE x SET asset_id = @survivor
      FROM grac_practice.asset_attribute_source x
      JOIN @plan p ON p.object_kind = N'ATTRIBUTE_SOURCE' AND p.outcome = N'MOVE' AND p.object_id = x.source_id AND p.object_key = x.field_key
     WHERE x.asset_id = @duplicate;

    -- ---------------------------------------------------------- open reconciliation exceptions
    INSERT grac_practice.asset_merge_split_object
        (event_id, object_kind, object_id, object_label, from_asset_id, to_asset_id, outcome, before_value, detail)
    SELECT @event_id, N'RECON_EXCEPTION', e.exception_id, p.object_label, @duplicate, @survivor,
           CASE p.outcome WHEN N'RESOLVE' THEN N'RESOLVED' ELSE N'MOVED' END,
           (SELECT e.asset_id AS assetId, e.other_asset_id AS otherAssetId FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), p.detail
      FROM grac_practice.asset_reconciliation_exception e JOIN @plan p ON p.object_kind = N'RECON_EXCEPTION' AND p.object_id = e.exception_id;
    UPDATE e
       SET status = N'RESOLVED', resolution = N'MERGED', resolution_note = @note, resolved_by = @actor, resolved_dt = SYSUTCDATETIME(),
           updated_dt = SYSUTCDATETIME()
      FROM grac_practice.asset_reconciliation_exception e JOIN @plan p ON p.object_kind = N'RECON_EXCEPTION' AND p.outcome = N'RESOLVE'
                                                                      AND p.object_id = e.exception_id;
    UPDATE e
       SET asset_id = CASE WHEN e.asset_id = @duplicate THEN @survivor ELSE e.asset_id END,
           other_asset_id = CASE WHEN e.other_asset_id = @duplicate THEN @survivor ELSE e.other_asset_id END,
           updated_dt = SYSUTCDATETIME()
      FROM grac_practice.asset_reconciliation_exception e JOIN @plan p ON p.object_kind = N'RECON_EXCEPTION' AND p.outcome = N'MOVE'
                                                                      AND p.object_id = e.exception_id;

    -- ---------------------------------------------------------- coverage, occurrences, restrictive reviews
    INSERT grac_practice.asset_merge_split_object (event_id, object_kind, object_id, object_key, object_label, from_asset_id, to_asset_id, outcome, detail)
    SELECT @event_id, p.object_kind, p.object_id, p.object_key, p.object_label, @duplicate, @survivor,
           CASE p.outcome WHEN N'MOVE' THEN N'MOVED' ELSE N'KEPT' END, p.detail
      FROM @plan p WHERE p.object_kind IN (N'COVERAGE', N'OCCURRENCE', N'RESTRICTIVE_REVIEW');
    UPDATE c SET asset_id = @survivor
      FROM grac_practice.asset_contract_coverage c JOIN @plan p ON p.object_kind = N'COVERAGE' AND p.outcome = N'MOVE' AND p.object_id = c.coverage_id;
    UPDATE o SET asset_id = @survivor, updated_by = @actor, updated_dt = SYSUTCDATETIME()
      FROM grac_practice.asset_activity_occurrence o JOIN @plan p ON p.object_kind = N'OCCURRENCE' AND p.outcome = N'MOVE' AND p.object_id = o.occurrence_id;
    UPDATE r SET asset_id = @survivor
      FROM grac_practice.asset_restrictive_review r JOIN @plan p ON p.object_kind = N'RESTRICTIVE_REVIEW' AND p.outcome = N'MOVE' AND p.object_id = r.review_id;

    -- ---------------------------------------------------------- risks and practice resolutions
    INSERT grac_practice.asset_merge_split_object
        (event_id, object_kind, object_id, object_label, from_asset_id, to_asset_id, outcome, before_value, after_value, detail)
    SELECT @event_id, N'RISK_MAP', m.risk_dependency_map_id, p.object_label, @duplicate, @survivor,
           CASE p.outcome WHEN N'MOVE' THEN N'MOVED' ELSE N'KEPT' END, m.dependency_object_name,
           CASE p.outcome WHEN N'MOVE' THEN @survivor_name END, p.detail
      FROM grac_practice.risk_dependency_map m JOIN @plan p ON p.object_kind = N'RISK_MAP' AND p.object_id = m.risk_dependency_map_id;
    UPDATE m SET dependency_object_id = @survivor, dependency_object_name = @survivor_name, updated_by = @actor, updated_dt = SYSUTCDATETIME()
      FROM grac_practice.risk_dependency_map m JOIN @plan p ON p.object_kind = N'RISK_MAP' AND p.outcome = N'MOVE' AND p.object_id = m.risk_dependency_map_id;

    INSERT grac_practice.asset_merge_split_object (event_id, object_kind, object_id, object_label, from_asset_id, to_asset_id, outcome, detail)
    SELECT @event_id, N'RISK_LINK', p.object_id, p.object_label, @duplicate, @survivor, N'MOVED', p.detail
      FROM @plan p WHERE p.object_kind = N'RISK_LINK';
    UPDATE r SET linked_asset_id = @survivor
      FROM grac_practice.risk_register r JOIN @plan p ON p.object_kind = N'RISK_LINK' AND p.object_id = r.risk_register_id;

    INSERT grac_practice.asset_merge_split_object
        (event_id, object_kind, object_id, object_label, from_asset_id, to_asset_id, outcome, before_value, after_value, detail)
    SELECT @event_id, N'PRACTICE_RESOLUTION', d.resolution_id, p.object_label, @duplicate, @survivor,
           CASE p.outcome WHEN N'MOVE' THEN N'MOVED' ELSE N'KEPT' END, d.resolved_dependency_name,
           CASE p.outcome WHEN N'MOVE' THEN LEFT(@survivor_name, 300) END, p.detail
      FROM grac_practice.practice_dependency_resolution d JOIN @plan p ON p.object_kind = N'PRACTICE_RESOLUTION' AND p.object_id = d.resolution_id;
    UPDATE d SET resolved_dependency_id = @survivor, resolved_dependency_name = LEFT(@survivor_name, 300), updated_by = @actor,
                 updated_dt = SYSUTCDATETIME()
      FROM grac_practice.practice_dependency_resolution d JOIN @plan p ON p.object_kind = N'PRACTICE_RESOLUTION' AND p.outcome = N'MOVE'
                                                                     AND p.object_id = d.resolution_id;

    -- ---------------------------------------------------------- field values (D117)
    -- Filled: the survivor has no value and no choice names another duplicate;
    -- replaced: a field choice names this duplicate.
    DECLARE @fv TABLE (field_definition_id INT PRIMARY KEY, field_key NVARCHAR(100) NOT NULL, label NVARCHAR(200) NULL,
                       before_text NVARCHAR(MAX) NULL, after_text NVARCHAR(MAX) NOT NULL, outcome NVARCHAR(10) NOT NULL);
    INSERT @fv (field_definition_id, field_key, label, before_text, after_text, outcome)
    SELECT f.field_definition_id, f.field_key, f.display_label, sv.value_text, dv.value_text,
           CASE WHEN sv.asset_id IS NULL THEN N'FILLED' ELSE N'REPLACED' END
      FROM grac_practice.asset_field_value dv
      JOIN grac_practice.asset_field_definition f ON f.field_definition_id = dv.field_definition_id AND f.storage_kind = N'VALUE'
                                                 AND f.is_system_field = 0
      JOIN grac_practice.asset_field_data_type_master dt ON dt.data_type_code = f.data_type_code AND dt.is_user_entered = 1
      LEFT JOIN grac_practice.asset_field_value sv ON sv.asset_id = @survivor AND sv.field_definition_id = dv.field_definition_id
      OUTER APPLY (SELECT TOP 1 TRY_CONVERT(BIGINT, j.[value]) AS chosen FROM OPENJSON(ISNULL(@field_choices_json, N'{}')) j
                    WHERE j.[key] COLLATE DATABASE_DEFAULT = f.field_key) ch
     WHERE dv.asset_id = @duplicate
       AND ((ch.chosen = @duplicate AND ISNULL(sv.value_text, N'') <> dv.value_text)
            OR (ch.chosen IS NULL AND sv.asset_id IS NULL));
    INSERT grac_practice.asset_merge_split_object
        (event_id, object_kind, object_id, object_key, object_label, from_asset_id, to_asset_id, outcome, before_value, after_value)
    SELECT @event_id, N'FIELD', field_definition_id, field_key, label, @duplicate, @survivor, outcome, before_text, after_text FROM @fv;
    MERGE grac_practice.asset_field_value AS t
    USING (SELECT dv.field_definition_id, dv.value_text, dv.value_number, dv.value_date, dv.value_ref
             FROM grac_practice.asset_field_value dv JOIN @fv x ON x.field_definition_id = dv.field_definition_id
            WHERE dv.asset_id = @duplicate) AS s
       ON t.asset_id = @survivor AND t.field_definition_id = s.field_definition_id
    WHEN MATCHED THEN UPDATE SET value_text = s.value_text, value_number = s.value_number, value_date = s.value_date, value_ref = s.value_ref,
                                 updated_by = @actor, updated_dt = SYSUTCDATETIME()
    WHEN NOT MATCHED THEN INSERT (asset_id, field_definition_id, value_text, value_number, value_date, value_ref, entered_by)
                          VALUES (@survivor, s.field_definition_id, s.value_text, s.value_number, s.value_date, s.value_ref, @actor);

    -- ---------------------------------------------------------- aliases (D118)
    DECLARE @al TABLE (alias_id BIGINT NOT NULL, alias_kind NVARCHAR(30) NOT NULL, alias_value NVARCHAR(400) NOT NULL);
    INSERT grac_practice.asset_alias (organization_id, asset_id, alias_kind, alias_value, source_asset_id, event_id, entered_by)
    OUTPUT inserted.alias_id, inserted.alias_kind, inserted.alias_value INTO @al (alias_id, alias_kind, alias_value)
    SELECT @organization_id, @survivor, k.kind, k.val, @duplicate, @event_id, @actor
      FROM (SELECT N'NAME' AS kind, CAST(a.asset_name AS NVARCHAR(400)) AS val
              FROM grac_practice.organization_dependency_asset a WHERE a.asset_id = @duplicate
            UNION ALL
            SELECT N'ASSET_ID', CAST(CONCAT(N'#', @duplicate) AS NVARCHAR(400))
            UNION ALL
            SELECT f.field_key, CAST(LEFT(v.value_text, 400) AS NVARCHAR(400))
              FROM grac_practice.asset_field_value v
              JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id
             WHERE v.asset_id = @duplicate
               AND f.field_key IN (N'asset_tag', N'serial_number', N'finance_asset_number', N'hostname', N'mac_address', N'cloud_resource_identifier')) k
     WHERE k.val IS NOT NULL AND LTRIM(RTRIM(k.val)) <> N''
       AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_field_value sv
                        JOIN grac_practice.asset_field_definition sf ON sf.field_definition_id = sv.field_definition_id
                       WHERE sv.asset_id = @survivor AND sf.field_key = k.kind AND sv.value_text = k.val)
       AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_alias x
                        WHERE x.asset_id = @survivor AND x.alias_kind = k.kind AND x.alias_value = k.val AND x.is_active = 1);
    INSERT grac_practice.asset_merge_split_object (event_id, object_kind, object_id, object_key, object_label, from_asset_id, to_asset_id, outcome, after_value)
    SELECT @event_id, N'ALIAS', alias_id, alias_kind, CONCAT(alias_kind, N': ', alias_value), @duplicate, @survivor, N'ALIASED', alias_value FROM @al;

    -- ---------------------------------------------------------- the merged record (D119)
    DECLARE @from NVARCHAR(60), @from_id INT, @rs INT, @st NVARCHAR(30), @legacy NVARCHAR(30), @to_id INT, @log BIGINT;
    SELECT @from = COALESCE(cs.status_code, ls.status_code), @from_id = a.current_status_id, @rs = a.record_status_id, @st = a.status,
           @legacy = a.lifecycle_status
      FROM grac_practice.organization_dependency_asset a
      LEFT JOIN grac_practice.entity_status_master cs ON cs.entity_status_id = a.current_status_id
      LEFT JOIN grac_practice.asset_legacy_status_map ls ON ls.legacy_lifecycle_status = ISNULL(a.lifecycle_status, N'Commissioned')
     WHERE a.asset_id = @duplicate;
    INSERT grac_practice.asset_merge_split_object
        (event_id, object_kind, object_id, object_label, from_asset_id, to_asset_id, outcome, before_value, after_value)
    VALUES (@event_id, N'ASSET_RECORD', @duplicate, CONCAT(N'Asset #', @duplicate), @duplicate, @survivor, N'ARCHIVED',
            (SELECT @from AS statusCode, @st AS status, @rs AS recordStatusId, @legacy AS lifecycleStatus FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'{"statusCode":"ARCHIVED"}');
    DECLARE @reason_text NVARCHAR(1000) = CONCAT(N'Merged into asset #', @survivor, N' (merge #', @event_id, N').');
    EXEC grac_practice.sp_pm_state_transition
         @entity_type = N'Asset', @entity_id = @duplicate, @from_status_code = @from, @to_status_code = N'ARCHIVED',
         @actor_employee_id = @actor_employee_id, @actor_role_code = N'ASSET_MERGE', @reason_code = N'MERGED', @reason_text = @reason_text,
         @to_status_id = @to_id OUTPUT, @transition_log_id = @log OUTPUT;
    DECLARE @inactive_rs INT = (SELECT TOP 1 record_status_id FROM grac_practice.record_status_master
                                 WHERE status_code = N'Inactive' OR status_name = N'Inactive' ORDER BY record_status_id);
    UPDATE grac_practice.organization_dependency_asset
       SET current_status_id = @to_id, status = N'Inactive', record_status_id = ISNULL(@inactive_rs, record_status_id),
           lifecycle_status = ISNULL((SELECT legacy_lifecycle_status FROM grac_practice.asset_lifecycle_status_phase WHERE status_code = N'ARCHIVED'),
                                     lifecycle_status),
           merged_into_asset_id = @survivor, updated_by = @actor, updated_dt = SYSUTCDATETIME()
     WHERE asset_id = @duplicate;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-register', @duplicate, N'MERGED', (SELECT @from AS statusCode FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            (SELECT @survivor AS mergedIntoAssetId, @event_id AS mergeEventId FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), N'Active', @actor),
           (N'asset-register', @survivor, N'MERGE_SURVIVOR', NULL,
            (SELECT @duplicate AS mergedAssetId, @event_id AS mergeEventId,
                    (SELECT COUNT(*) FROM grac_practice.asset_merge_split_object o WHERE o.event_id = @event_id AND o.from_asset_id = @duplicate) AS outcomes
                FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), N'Active', @actor);
END
GO
PRINT '444: merge save and execution created.';
GO
