W='/home/claude/w448/'
p=lambda k: open(W+'part_'+k+'.sql').read()
d = """-- =====================================================================
-- 10. Re-issued bodies (448 lines marked; otherwise unchanged)
-- =====================================================================
-- 447 body: privacy reviews refreshed after the save; privacy gaps as warnings.
""" + p('rs2') + """GO
PRINT '448: sp_asset_register_save re-issued.';
GO

-- 447 body: privacy sync per organization.
""" + p('sc2') + """GO
PRINT '448: sp_asset_scheduler_run re-issued.';
GO

-- 447 body: blocking privacy gaps stop Active; blocking sanitization stops Disposed / Archived.
""" + p('lt2') + """GO
PRINT '448: sp_asset_lifecycle_transition re-issued.';
GO

-- 439 body: privacy and retention review sources.
""" + p('sw2') + """GO
PRINT '448: sp_asset_notification_sweep re-issued.';
GO

-- 439 body: privacy review and privacy exception parties.
""" + p('np2') + """GO
PRINT '448: sp_asset_notification_parties re-issued.';
GO

"""
open(W+'448_d.sql','w').write(d)
s=''.join(open(W+f).read() for f in ['448_a.sql','448_b.sql','448_c.sql','448_d.sql','448_m.sql','448_e.sql'])
open(W+'448.sql','w').write(s)
rb = """-- =====================================================================
-- 448 ROLLBACK  Asset privacy
-- =====================================================================
-- Restores sp_asset_register_save, sp_asset_scheduler_run and
-- sp_asset_lifecycle_transition (447) and sp_asset_notification_sweep and
-- sp_asset_notification_parties (439); closes open privacy notification
-- occurrences; drops the 448 procedures, functions and tables (settings,
-- exceptions and reviews are lost) and the Asset Privacy menu row and its
-- grants. The widened notification object types and the source flags of
-- the two activities stay (harmless without sources).
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

""" + p('rs') + "GO\n" + p('sc') + "GO\n" + p('lt') + "GO\n" + p('sw') + "GO\n" + p('np') + """GO
PRINT '448 rollback: 439 and 447 bodies restored.';
GO

UPDATE grac_practice.asset_notification_occurrence
   SET status = N'COMPLETED', close_reason = N'Privacy sources removed (448 rollback).', closed_dt = SYSUTCDATETIME(),
       updated_by = N'rollback-448', updated_dt = SYSUTCDATETIME()
 WHERE status = N'OPEN' AND object_type IN (N'PRIVACY_REVIEW', N'PRIVACY_EXCEPTION');
GO

DROP PROCEDURE IF EXISTS grac_practice.sp_asset_privacy_reviews;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_privacy_exceptions;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_privacy_asset_get;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_privacy_assets;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_privacy_review_complete;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_privacy_exception_action;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_privacy_exception_request;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_privacy_setting_save;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_privacy_requirements;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_privacy_run;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_privacy_sync;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_privacy_status;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_privacy_gaps;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_privacy_retention_calc;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_privacy_values;
GO
DROP TABLE IF EXISTS grac_practice.asset_privacy_review;
DROP TABLE IF EXISTS grac_practice.asset_privacy_exception;
DROP TABLE IF EXISTS grac_practice.asset_privacy_setting;
DROP TABLE IF EXISTS grac_practice.asset_privacy_requirement;
GO
DELETE p
  FROM grac_practice.organization_role_menu_permission p
  JOIN grac_practice.menu_master m ON m.menu_id = p.menu_id
 WHERE m.menu_key = N'asset-privacy';
DELETE FROM grac_practice.menu_master WHERE menu_key = N'asset-privacy';
GO
PRINT '448 rollback: privacy objects and menu dropped.';
GO

SELECT '448 rollback' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_privacy_review','U') IS NULL
             AND OBJECT_ID('grac_practice.fn_asset_privacy_gaps') IS NULL
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_register_save')) NOT LIKE '%sp_asset_privacy_sync%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) NOT LIKE '%sp_asset_privacy_sync%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_lifecycle_transition')) NOT LIKE '%53070%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_notification_sweep')) NOT LIKE '%PRIVACY_REVIEW:PX:%'
             AND NOT EXISTS (SELECT 1 FROM grac_practice.menu_master WHERE menu_key = N'asset-privacy')
            THEN 'PASS' ELSE 'FAIL' END AS Result;
GO
"""
open(W+'448_rb.sql','w').write(rb)
print('assembled', s.count('\n'), rb.count('\n'))
