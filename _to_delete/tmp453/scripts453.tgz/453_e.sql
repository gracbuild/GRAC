
-- =====================================================================
-- 7. Verification
-- =====================================================================
SELECT '453-a tables and export column' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_report_schedule','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_report_schedule_recipient','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_report_delivery','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_report_delivery_recipient','U') IS NOT NULL
             AND COL_LENGTH('grac_practice.asset_report_export', 'delivery_recipient_id') IS NOT NULL
            THEN 'PASS' ELSE 'FAIL' END AS Result
UNION ALL
SELECT '453-b functions and procedures present',
       CASE WHEN OBJECT_ID('grac_practice.fn_asset_report_next_run') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_report_employee_in_org') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_report_employee_access') IS NOT NULL
             AND (SELECT COUNT(*) FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'grac_practice'
                   AND name IN ('sp_asset_report_schedules', 'sp_asset_report_schedule_save', 'sp_asset_report_delivery_finish',
                                'sp_asset_report_delivery_start', 'sp_asset_report_delivery_store', 'sp_asset_report_deliveries',
                                'sp_asset_report_delivery_recipients', 'sp_asset_report_my_deliveries',
                                'sp_asset_report_delivery_download')) = 9
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
-- 2026-10-06 is a Tuesday: daily -> same day, weekly Monday -> 2026-10-12,
-- weekly Tuesday -> same day, monthly day 5 -> 2026-11-05, monthly day 28 -> 2026-10-28.
SELECT '453-c next run dates',
       CASE WHEN (SELECT NextRunDate FROM grac_practice.fn_asset_report_next_run(N'DAILY', NULL, NULL, '20261006')) = '20261006'
             AND (SELECT NextRunDate FROM grac_practice.fn_asset_report_next_run(N'WEEKLY', 1, NULL, '20261006')) = '20261012'
             AND (SELECT NextRunDate FROM grac_practice.fn_asset_report_next_run(N'WEEKLY', 2, NULL, '20261006')) = '20261006'
             AND (SELECT NextRunDate FROM grac_practice.fn_asset_report_next_run(N'MONTHLY', NULL, 5, '20261006')) = '20261105'
             AND (SELECT NextRunDate FROM grac_practice.fn_asset_report_next_run(N'MONTHLY', NULL, 28, '20261006')) = '20261028'
            THEN 'PASS' ELSE 'FAIL' END;
GO

/* =====================================================================
   UAT (re-login after 453; Admin, plus one employee with VIEW on Asset
   Reports and Asset Register only)
   ---------------------------------------------------------------------
   1. Asset Reports -> Schedules -> New: Complete Asset Register, status
      Active, weekly on Monday, keep files 30 days, recipients: the Admin
      employee, the second employee and a role -> next run is the coming
      Monday (or today when it is Monday).
   2. Run now: the run lists one row per recipient -- DELIVERED with the
      row count, or SKIPPED with the reason (for example a role member
      without Asset Reports VIEW). Schedule Vendor Contact Matrix (Asset
      Contracts screen) to the second employee -> SKIPPED: no VIEW on
      asset-contracts.
   3. As the second employee: Asset Reports -> My deliveries lists the
      file; Download writes the CSV with the watermark heading; Export
      history shows the download with the same filters and row count.
   4. Set the report export policy to Approver in Settings -> the next run
      skips recipients without Asset Reports APPROVE; a file delivered
      before can no longer be downloaded by them (53129).
   5. Leave the API running: the worker delivers due schedules once per
      day each (TaskNotification:AssetReportDeliveryEnabled); a second
      pass the same day starts nothing.
   6. Files older than the retention are removed on the next pass; the
      run keeps the distribution result and My deliveries shows the file
      as removed.
   ===================================================================== */
