namespace PracticeManagement.Web.Models;

public sealed record PracticeScreen(string Key, string Title, string Description, string Icon, string[] Columns, string Group)
{
    public const string OrganizationOnboardingGroup = "Organization Setup";
    public const string OrganizationAdministrationGroup = "Organization Administration";
    public const string OrganizationDependenciesGroup = "Organization Dependencies";
    public const string OrganizationAccessAdministrationGroup = "Organization Access Administration";
    public const string OrganizationSetupGroup = OrganizationOnboardingGroup;
    public const string PracticeManagementGroup = "Practice Management";
    public const string AssuranceManagementGroup = "Assurance Management";
    public const string DependencyWorkbenchGroup = "Registers";
    public const string DashboardGroup = "Dashboard";
    // Oversight group — split off from PracticeManagementGroup so
    // gap-identification (Gap Center) and task-execution (Task Center)
    // sit alongside future Assurance / Exceptions / Risks screens.
    // Introduced when Task Center's Gaps tab was extracted into its
    // own Gap Center module.
    // Displayed as "Issues & Actions" since migration 384 (was "Oversight").
    // Label only: the constant NAME, menu_key nav-oversight, routes and
    // permissions are unchanged. Must match menu_master.module_type.
    public const string OversightGroup = "Issues & Actions";
    // Migration 384 -- Document Management became the root
    // "Policies & Documents" (nav-documents) again, and the existing
    // my-notifications row became the "My Notification" parent that
    // hosts My Practices / My Approvals / My Acknowledgements. Both
    // values match the rows' menu_master.module_type (page eyebrow).
    public const string PoliciesDocumentsGroup = "Policies & Documents";
    public const string MyNotificationGroup = "My Notification";
    // Sidebar reorganisation (migration 051) — enterprise-GRC grouping.
    // These match module_type values in grac_practice.menu_master; the
    // Group value on each PracticeScreen is used for the page eyebrow
    // (see Views/Practice/Manage.cshtml → `@Model.Group / @Model.Title`)
    // so the eyebrow stays consistent with the sidebar hierarchy.
    public const string GovernanceGroup     = "Governance";
    public const string OrganizationGroup   = "Organization";
    public const string OperationsGroup     = "Operations";
    public const string AdministrationGroup = "Administration";
    // Workflow & Event-Driven Assurance Engine (BRD v1.0) -- sits
    // beside Oversight (400) in the sidebar, seeded by migration 068.
    // Independent of the Practice Assurance Engine (BRD Sec 4).
    public const string WorkflowGroup       = "Workflow";
    // Phase 2 Assurance Management (BRD Part 2 -- Organization Portal).
    // NEW, INDEPENDENT module. Screens live under the existing
    // nav-assurance parent (seeded by migration 063). Menu rows and
    // permissions added by migration 071. Distinct from
    // AssuranceManagementGroup above -- that group belongs to the
    // unrelated legacy assurance-* screens which stay untouched.
    //
    // Renamed by migration 276: the group was "Organization Assurance"
    // and the nav-assurance row read "Assurance". Both now read "Audit
    // Management". Only the labels changed -- every screen key, route,
    // menu_key and permission row is untouched, so existing audit data
    // and grants are unaffected. The constant is the page eyebrow's
    // source, so it has to match menu_master.module_type.
    // Renamed again by migration 384: displayed as "Audit Assurance".
    public const string AuditManagementGroup = "Audit Assurance";
    // Asset & Contract Management (migration 420). Root menu
    // nav-asset-contract; must match menu_master.module_type (page eyebrow).
    public const string AssetContractGroup = "Asset & Contract";
    // Third-Party Risk Management (migrations 486-490). Root menu nav-tprm;
    // must match menu_master.module_type (page eyebrow).
    public const string TprmGroup = "Third-Party Risk";

    public static readonly PracticeScreen[] All =
    [
        new("dashboard","Home","Practice Management summary dashboard","chart-line",["Id","Message"], DashboardGroup),
        new("organization-setup","Organization Setup","GRAC Admin module for organization onboarding, metadata, repository subscription, locations, departments, business functions, teams, committees, and employees","building",["Code","Name","Industry","EntityType","Country","Status"], OrganizationOnboardingGroup),
        new("organization-administration","Organization Administration","Organization profile, locations, departments, business functions, teams, committees, and employees for organization users","building-user",["Code","Name","Industry","EntityType","Country","Status"], OrganizationAdministrationGroup),
        new("organizations","Organization Onboarding","Legal entities and organization-level operating context","building",["Code","Name","Industry","EntityType","Country","Status"], OrganizationGroup),
        new("organization-metadata","Organization Metadata","Configurable metadata used for applicability discovery","sliders",["OrganizationId","MetadataName","DataType","ValueText","Status"], OrganizationGroup),
        new("repository-subscriptions","Standards & Frameworks","Organization subscriptions to repository artifacts and releases","bookmark",["OrganizationId","AuthorityId","ArtifactId","ReleaseId","SubscriptionStatus","Status"], GovernanceGroup),
        new("locations","Location Management","Organization locations used for operating context, ownership, and responsibility mapping","location-dot",["Organization","Name","LocationType","LocationHead","Region","Status"], OrganizationGroup),
        new("departments","Department Management","Departments mapped to organizations","building-user",["Organization","Code","Name","HeadUser","Status"], OrganizationGroup),
        new("teams","Team Management","Organization teams mapped to departments and managed by employees. In-house or vendor-managed; accountability stays with the team manager either way","people-group",["Organization","Name","TeamType","Vendor","TeamManager","ParentDepartment","Status"], OrganizationGroup),
        new("committees","Committee Management","Organization committees with committee head and review frequency","users-gear",["Organization","Name","Chairperson","ReviewFrequency","Status"], OrganizationGroup),
        new("roles","Role Master","Organization-specific roles used for menu and action permissions","user-lock",["Organization","RoleCode","RoleName","Description","Status"], AdministrationGroup),
        new("role-menu-permissions","Role Menu Permission","Assign Practice Management menu permissions to an organization role","list-check",["Organization","RoleName","MenuName","CanView","CanAdd","CanEdit","CanDelete","CanApprove","Status"], AdministrationGroup),
        new("user-role-assignments","User Role Assignment","Assign one or more organization roles to organization users","user-gear",["EmployeeCode","EmployeeName","Email","RoleNames","Status"], AdministrationGroup),
        new("users","User Management","Users available for organization ownership and assignment. Employees and third-party personnel; a third party must name the provider that supplies them","users",["EmployeeCode","EmployeeName","PersonnelType","Email","RoleName","Provider","Designation","Status"], AdministrationGroup),
        new("ownership-management","Ownership Management","Select a user and reassign every item they currently own to an active Functional User; a user cannot be deactivated until they still own items","user-gear",["Module","Item","CurrentOwner","NewOwner","Action"], AdministrationGroup),
        new("organization-dependencies","Organization Dependencies","Organization dependency objects for applications, tools, vendors, assets, and processes","diagram-project",["Name","Owner","Criticality","Status"], OrganizationDependenciesGroup),
        new("dependency-applications","Applications","Business applications supporting organization practices","window-restore",["Name","BusinessOwner","TechnicalOwner","Vendor","HostingType","Criticality","Status"], OperationsGroup),
        new("dependency-tools","Tools","Utility tools supporting execution of practices","screwdriver-wrench",["Name","BusinessOwner","Vendor","LicenseType","Criticality","Status"], OperationsGroup),
        new("dependency-vendors","Vendors","Third parties providing services or products","handshake",["Name","ServiceCategory","RelationshipOwner","Criticality","Status"], OperationsGroup),
        new("dependency-assets","Assets","Physical or logical assets supporting practices","server",["Name","AssetCategory","Owner","Location","Criticality","Status"], OperationsGroup),
        // Asset counterpart of the checklist section on the Role Master form
        // (migration 138). A screen of its own, not a section on an Asset
        // Category form, because dependency_asset_category_master is global
        // master data with no organization_id -- while the checklist decision
        // is per (organization, category). Renders via
        // Views/Practice/Partials/asset-category-assurance.cshtml; the columns
        // below are unused (the partial owns its own layout) but are kept
        // meaningful so the screen registry stays self-describing.
        new("asset-category-assurance","Asset Category Assurance","Set what has to be done when an asset of a given category is commissioned or decommissioned.","boxes-stacked",["Applies","Event","Checklist","Items","OwnerRole","DueDays","State"], OperationsGroup),
        // Event Profiles (migrations 329-332) -- the people-side counterpart
        // of the screen above. Replaces "one role, one set of checklists"
        // with a named population expressed in Location / Department / Role
        // and whatever else is seeded into event_profile_dimension_master.
        // The role-scoped path is NOT retired: it still resolves, and the
        // Role Master section still configures it. Renders via
        // Views/Practice/Partials/event-profiles.cshtml -- which also has to
        // be listed in Manage.cshtml's own workflowScreens set, or the
        // request falls through to the generic entity grid and 400s.
        new("event-profiles","Event Profiles","Define user populations by Location, Department and Role, then set which onboarding and offboarding checklists apply to each.","users-gear",["ProfileName","Description","Criteria","Status","Checklists"], OrganizationGroup),
        new("dependency-processes","Processes","Business processes supporting organizational execution","arrows-spin",["Name","ProcessOwner","Version","NextReviewDate","Status"], OperationsGroup),
        new("user-assignments","User Assignment","Assign users to organization and department scope","user-check",["Organization","Department","User","Role","Status"], OrganizationOnboardingGroup),
        new("owner-mappings","Role / Owner Mapping","Map ownership roles to users for organization operations","user-shield",["Organization","Role","Owner","BackupOwner","Status"], OrganizationOnboardingGroup),
        // organization-controls is the underlying two-level screen: Level 1 renders
        // the subscribed Framework Release summary (RS2); Level 2 drills into that
        // release's Source Statement tree (RS3). Migration 056 makes this the target
        // of the Repository Subscriptions menu so users land on Level 1 by default.
        // Columns here paint the pre-hydration header only; practice.js swaps in
        // releaseSummaryColumns (Level 1) or statementTreeColumns (Level 2) as soon
        // as it runs. They are kept in step with releaseSummaryColumns so the grid
        // does not flash a header with columns that were removed from Level 1.
        // The five count columns are painted here with the same short labels
        // practice.js uses under its "Governance Overview" group header, so the
        // pre-hydration header does not flash wider columns than the real one.
        new("organization-controls","Standards & Frameworks","Subscribed Framework Release summary with drill-down into Control Statements.","shield",["Framework / Release","Owner","Total","Not Applicable","Applicable","Implemented","Not Updated"], GovernanceGroup),
        // source-statements is an ALIAS of organization-controls -- same view, same
        // columns, same JS. It exists so the Source Statements menu has its own
        // sidebar-highlighting URL and lands users directly on the Level 2 statement
        // grid (auto-drilling into the first subscribed release).
        // Pre-hydration header only; practice.js swaps in statementTreeColumns.
        // Kept in step with it (minus Actions, which Manage.cshtml appends) so the
        // grid does not flash a different column set before the script runs.
        new("source-statements","Control Statements","Control Statement grid for a subscribed Framework Release.","shield",["Statement Reference","Statement Title","Owner","Applicability Status","Implementation Status","Practice Count"], GovernanceGroup),   // Owner 2026-10-08: same columns as practice.js statementTreeColumnDefs, so the server-drawn loading header matches
        // custom-source-statements: no menu_master row of its own (same convention as
        // ownership-management / practice-instances / gap-detail) -- reached only by a
        // link from the Standards & Frameworks screen (organization-controls), which is
        // also the permission area ScreenPermissionArea() maps this key onto in
        // PracticeController.cs. Renders through the workflow-layer dispatch in
        // Manage.cshtml as its own self-contained partial, not through the generic
        // grid/toolbar/practice.js layout, so the columns below are unused placeholders.
        // Purpose-built for authoring a Custom Release's own Source Structure and Source
        // Statements (Release -> Source Structure -> Source Statements), with no
        // Organization selector, leaving the existing Organization+Release toolbar
        // screen above completely untouched for subscribed-framework statements.
        new("custom-source-statements","Add Source Statements","Author Source Structure and Source Statements for a Custom Release -- no Organization selection required.","shield",["Source Structure Node","Statement Reference","Statement Title","Applicability Status"], GovernanceGroup),
        // repository-updates (migration 395): review / approve the changes
        // Control Management made to a subscribed release since the
        // organization copied it. Same no-menu-row convention as
        // custom-source-statements -- reached from the Standards & Frameworks
        // release row (and Home), permissioned through organization-controls
        // (PracticeController.ScreenPermissionArea). Self-contained partial;
        // the columns below are unused placeholders.
        new("repository-updates","Repository Updates","Review and approve Control Management changes to a subscribed framework release.","shield",["Item","Change","Release","Detected"], GovernanceGroup),
        // Pre-hydration header and colspan source only: practice.js draws this
        // grid through renderRequirementStatementGroups / renderStatementPracticeRows,
        // which write their own <th> row. ImplementationStatus is the practice-level
        // roll-up over the practice's instances (PracticeImplementationStatus on the
        // row), mirroring the Source Statement column above. Six entries plus the
        // Actions column Manage.cshtml appends = the seven cells those renderers emit.
        new("organization-requirements","Practices","Organization-scoped practices and applicability decisions with expandable Practice Instances","list-check",["Code","Name","ApplicabilityStatus","ImplementationStatus","PracticeOwner","PracticeInstanceCount"], GovernanceGroup),
        new("practices","Practice Management","Implementation approaches for applicable requirements","clipboard-check",["Code","Name","OriginType","ApplicabilityStatus","PracticeOwner","Status"], GovernanceGroup),
        // Resolve workspace (migrations 140/141). Not a menu screen: it is
        // reached from a row on the Resolve list, carrying the instance id.
        new("resolve-workspace","Operationalize","Everything one practice instance still needs -- its obligations and its dependencies.","link",["Obligation","Type","Release","Adopted","Evidence"], OperationsGroup),
        // Full-page replacement for the practice View modal (migration 139).
        // Not a menu screen: it is reached only from the Practices grid, with
        // an encrypted navigation code carrying the practice id. Registered
        // here so PracticeController.ShowArea can resolve and permission it.
        new("practice-view","Practice","Practice details, its obligations, and Configure -- one Practice Instance per team.","clipboard-check",["Obligation","Type","Frequency","Responsible","Approval"], GovernanceGroup),
        // RETIRED BY MIGRATION 288 -- and deliberately still registered.
        //
        // Its menu row is Inactive, so it is gone from the sidebar, but
        // PracticeController.ShowArea resolves screens from THIS list, not
        // from menu_master. Deleting the entry would 404 every existing
        // deep link and bookmark the moment 288 ships; leaving it means
        // the URL keeps working while the navigation stops offering it.
        //
        // Everything it used to do now lives in Operationalize:
        //   create              Configure, per team              (139)
        //   profile + retire    Operationalize workspace         (222)
        //   restore, retired
        //   visibility, and the
        //   practice/requirement
        //   drill-down          Operationalize                   (287)
        //
        // Do not add fields here. The edit form's inputs are all owned
        // elsewhere -- see docs/practice-instance-form-slimming.md.
        new("practice-instances","Practice Instances","Retired -- superseded by Operationalize. Route kept for existing links only.","network-wired",["Code","Name","PrimaryOwner","Department","ExecutionFrequency","AssuranceFrequency","AssuranceMode","Criticality","ImplementationStatus","Status"], GovernanceGroup),
        new("resolve","Operationalize","Operationalize practice instance dependency and evidence registers assigned to you","gears",["Name","OwningDepartment","PrimaryOwner","Frequency","Register","ResolvedDependencyName","ResolutionStatus","ResolutionOwner","LastUpdated"], OperationsGroup),
        new("workbench-applications","Applications","Application custodian queue for resolving configured Practice Instance application dependencies","window-restore",["Name","OwningDepartment","PrimaryOwner","Frequency","DependencyCategory","ResolvedDependencyName","ResolutionStatus","ResolutionOwner","LastUpdated"], DependencyWorkbenchGroup),
        new("workbench-tools","Tools","Tool custodian queue for resolving configured Practice Instance tool dependencies","screwdriver-wrench",["Name","OwningDepartment","PrimaryOwner","Frequency","DependencyCategory","ResolvedDependencyName","ResolutionStatus","ResolutionOwner","LastUpdated"], DependencyWorkbenchGroup),
        new("workbench-vendors","Vendors","Vendor custodian queue for resolving configured Practice Instance vendor dependencies","handshake",["Name","OwningDepartment","PrimaryOwner","Frequency","DependencyCategory","ResolvedDependencyName","ResolutionStatus","ResolutionOwner","LastUpdated"], DependencyWorkbenchGroup),
        new("workbench-assets","Assets","Asset custodian queue for resolving configured Practice Instance asset dependencies","server",["Name","OwningDepartment","PrimaryOwner","Frequency","DependencyCategory","ResolvedDependencyName","ResolutionStatus","ResolutionOwner","LastUpdated"], DependencyWorkbenchGroup),
        new("workbench-teams","Teams","Team custodian queue for resolving configured Practice Instance team dependencies","people-group",["Name","OwningDepartment","PrimaryOwner","Frequency","DependencyCategory","ResolvedDependencyName","ResolutionStatus","ResolutionOwner","LastUpdated"], DependencyWorkbenchGroup),
        new("workbench-committees","Committees","Committee custodian queue for resolving configured Practice Instance committee dependencies","users-gear",["Name","OwningDepartment","PrimaryOwner","Frequency","DependencyCategory","ResolvedDependencyName","ResolutionStatus","ResolutionOwner","LastUpdated"], DependencyWorkbenchGroup),
        new("workbench-processes","Processes","Process custodian queue for resolving configured Practice Instance process dependencies","arrows-spin",["Name","OwningDepartment","PrimaryOwner","Frequency","DependencyCategory","ResolvedDependencyName","ResolutionStatus","ResolutionOwner","LastUpdated"], DependencyWorkbenchGroup),
        new("workbench-locations","Locations","Location custodian queue for resolving configured Practice Instance location dependencies","location-dot",["Name","OwningDepartment","PrimaryOwner","Frequency","DependencyCategory","ResolvedDependencyName","ResolutionStatus","ResolutionOwner","LastUpdated"], DependencyWorkbenchGroup),
        new("dependencies","Dependency Intelligence","People, tools, assets, vendors, applications, processes and locations","diagram-project",["DependencyType","Name","OwnerName","Criticality","Status"], PracticeManagementGroup),
        new("evidence-configurations","Evidence Configuration","Organization evidence expectations and collection settings","file-circle-check",["EvidenceType","AssuranceTypeName","RetentionPeriod","CollectionMethod","CollectionFrequency","EvidenceOwner","Status"], PracticeManagementGroup),
        new("evidence-obligations","View Obligations","Evidence obligations inherited from applicable requirements and practices","list-check",["FrameworkRelease","ObligationName","ExecutionFrequency","EvidenceType","Frequency","RetentionRequirement","Remarks"], PracticeManagementGroup),
        new("assurance-attributes","Assurance Attributes","Manual and automated assurance metadata","user-shield",["Id","Message"], PracticeManagementGroup),
        new("vendor-attributes","Vendor Attributes","Vendor, contract, SLA and service criticality metadata","handshake",["Id","Message"], PracticeManagementGroup),
        new("risk-attributes","Risk Attributes","Operational, compliance, financial, cyber and reputational impacts","triangle-exclamation",["Id","Message"], PracticeManagementGroup),
        new("audit-attributes","Audit Attributes","Auditable assets, tools, configuration scope and frequency recommendations","magnifying-glass-chart",["Id","Message"], PracticeManagementGroup),
        new("task-attributes","Task/Ticket Attributes","Execution frequency, due date logic, reminders, escalation and SLA","calendar-days",["Id","Message"], PracticeManagementGroup),
        new("resilience-attributes","Resilience Attributes","Single-point dependencies and operational resilience signals","arrows-spin",["Id","Message"], PracticeManagementGroup),
        new("future-triggers","Future Integration Trigger Matrix","Candidate leads for risk, audit, vendor, task and resilience modules","bolt",["Id","Message"], PracticeManagementGroup),
        new("audit-trace","Audit Traceability","Immutable history for major practice entities","timeline",["EntityType","EntityId","ActionType","Status","EnteredBy","EnteredDt"], AdministrationGroup)
        ,
        // ===== Workflow Layer (§12.1.3) — feature-flagged OFF by default =====
        // Task Center now lives under Oversight (was PracticeManagementGroup) so
        // it sits alongside Gap Center and future Assurance / Exceptions / Risks.
        new("tasks","Task Board","Tasks created to address gaps and lifecycle work — Implementation, Assurance, Custom","list-check",["TaskId","Type","Subject","Assignee","Status","Priority","SlaDueAt"], OversightGroup),
        // Gap Center — identifies work that needs to be done (Implementation
        // gaps today; Assurance / Custom gaps expand later). Kept independent
        // of Task Center because gap sources (assurance findings, exceptions,
        // risk register, audits, repository gaps) can grow well beyond
        // Implementation. See conversation notes for full source list.
        new("gaps","Gap Register","Unified sources of work — Implementation, Assurance and Custom gaps in one place","triangle-exclamation",["Instance","Practice","Organization","ImplementationStatus","Owner","Criticality","ExistingTasks"], OversightGroup),
        // Document Upload + Acknowledgement module (migrations 146-149).
        // Renamed "Document Library" and moved under Governance by
        // migration 358 (sidebar half in menu_master; Title/Group here
        // is the page-heading/eyebrow half -- Manage.cshtml's `<h1>` and
        // its `@Model.Group / @Model.Title` eyebrow read straight off
        // this record, not off menu_master, so both had to move together).
        // document-acknowledgements / my-acknowledgements were NOT
        // renamed or moved -- they stay under Oversight/Document
        // Management exactly as 155 left them. Columns are unused (the
        // partial owns its own layout) but kept meaningful so the screen
        // registry stays self-describing.
        new("document-uploads","Document Library","Register controlled documents, distribute them, and route them through review and approval","file-lines",["Code","Name","Type","Version","Stage","Status","NextReview"], PoliciesDocumentsGroup),
        // Phase 2 companion to Document Library (migrations 150-152) --
        // admin batches for tracking user acknowledgement of published
        // documents. Renders via document-acknowledgements.cshtml.
        new("document-acknowledgements","Document Acknowledgements","Roll published documents into named batches and track who has acknowledged each","file-signature",["Name","Due","Docs","Users","AckCount","Progress","Status"], PoliciesDocumentsGroup),
        // Evidence Center (migration 476, Phase 1): evidence files uploaded
        // once for the organisation and linked wherever they are used
        // (Operationalize one-time evidence in Phase 1). Own partial, own
        // JS, own proxy (practice/api/evidence-center) -- no generic grid.
        new("evidence-center","Evidence Center","Evidence uploaded once for the organization and reused wherever it is needed: owner, validity, versions and where each item is used","box-archive",["Title","Type","Owner","Validity","Version","UsedIn","Status"], PoliciesDocumentsGroup),
        // Phase 3 user-side counterpart (migrations 153-154). Every
        // employee sees their own pending acknowledgements here.
        new("my-acknowledgements","My Acknowledgements","Documents you are asked to acknowledge -- pick a batch and confirm each one","inbox",["Batch","Due","MyDocs","Acknowledged","Pending","Progress","Status"], MyNotificationGroup),
        // Personal inbox for SLA task notifications (migrations 201-203).
        // Sits next to My Acknowledgements: both are addressed to the
        // signed-in individual rather than to a role or an organisation.
        new("my-notifications","My Notifications","Task SLA warnings, breaches and escalations addressed to you","bell",["Event","Task","WhyYou","Due","Received","Status"], MyNotificationGroup),
        // Gap Centre v1.0 (migrations 156-158 / AES) -- lifecycle
        // engine on a single custom_gap row: canonical states, Gap
        // Analysis Engine, Decision Gateway with downstream links.
        // Reached from Gap Centre's 3-dot menu with ?gapId=.
        new("gap-detail","Gap Details","Gap lifecycle, analysis and downstream link management","route",["State","Severity","Impact"], OversightGroup),
        // Exception Centre (migrations 161-163) -- time-boxed
        // acceptance of gaps. Auto-populated from gap analysis.
        new("exception-centre","Exceptions & Waivers","Approve or reject time-boxed exception requests raised from gap analysis","shield-halved",["Request","Gap","Status","EffectiveUntil"], OversightGroup),
        // Exception analysis (migration 257) -- the stage between a raised
        // request and the approval decision. Reached from Exception
        // Centre's 3-dot menu with ?exceptionId=, the same way gap-detail
        // is reached from Gap Centre. A "route" screen: no menu entry of
        // its own, because it is always about one specific request.
        new("exception-analysis","Exception Analysis","Analyse an exception request and submit it for approval","route",["Request","Justification","Risk","Tasks"], OversightGroup),
        // Gap View (migration 325) -- read-only consolidated view of a
        // Gap: its full details plus the Task, Exception and Risk raised
        // against it, each a clickable card opening that artefact's own
        // existing full view in a new tab. Reached from Gap Centre's
        // 3-dot menu, or from gap-detail's own toolbar, with ?gapId=,
        // the same way gap-detail is reached from Gap Centre. A "route"
        // screen: no menu entry of its own, because it is always about
        // one specific gap.
        new("gap-view","Gap View","Read-only consolidated view of a Gap and the Task, Exception and Risk raised against it","route",["Task","Exception","Risk"], OversightGroup),
        // Task View -- dedicated full-page replacement for the old
        // "View" dialog/drawer on Task Center's row menu (#taskDetailDialog
        // / openTaskViewDrawer). Reached from Task Center's row menu, or
        // Gap View's Task card, with ?taskId=. A "route" screen: no menu
        // entry of its own, because it is always about one specific task.
        new("task-view","Task View","Read-only full view of a single task -- identity, SLA, related record, evidence and activity","route",["Type","Status","Priority","Owner","Related"], OversightGroup),
        // New Task / Edit Task -- full-page versions of the Task Board's
        // create and edit forms (previously modal dialogs). Same "route"
        // convention as task-view/gap-view: no sidebar entry, reached by
        // URL from the Task Board, permission tied to tasks (below).
        new("task-new","New Task","Create a Custom task -- full-page form.","route",["Organization","Title","Assignee","Priority","Target"], OversightGroup),
        new("task-edit","Edit Task","Edit a task -- full-page form.","route",["Status","Owner","Priority","Due"], OversightGroup),
        // Complete Task -- full page (2026-10-23): the Complete dialog grew a
        // list of recurring evidence (482/483), too much for a modal.
        new("task-complete","Complete Task","Complete a task -- evidence and completion remark, full page.","route",["Evidence","Remark"], OversightGroup),
        // Exception View -- dedicated read-only full view of an exception
        // request in ANY status, complementing exception-analysis (the
        // Pending-request analysis workflow, unchanged). Reached from
        // Exception Centre's row menu, or Gap View's Exception card, with
        // ?exceptionId=. A "route" screen: no menu entry of its own.
        new("exception-view","Exception View","Read-only full view of an exception request -- reason, validity, approval and evidence","route",["Request","Status","Approval","Evidence"], OversightGroup),
        // Risk Centre (migrations 169-172, 176, 204-207) -- the full
        // module: candidates from any GRAC source, the mandatory initial
        // risk analysis, and the Risk Register both entry routes feed.
        new("risk-centre","Risk Centre","Analyse risk candidates raised by Gap, Exception, Assurance and other GRAC sources, then register them; or create a custom risk directly","triangle-exclamation",["Candidate","Source","Rating","Status"], OversightGroup),
        // Risk Management submenus (migration 383). Each opens the SAME
        // risk-centre partial locked to one of its tabs (see Manage.cshtml's
        // risk sub-tab map and risk-centre.js's window.riskCentreInitialTab
        // handling), so the grids, filters, actions, APIs and business logic
        // are reused verbatim -- these entries only give each tab its own
        // route/screen so it can be a standalone submenu page. Their VIEW
        // permission is shared with 'risk-centre' via ScreenPermissionArea,
        // and Group 'Risk Management' matches the parent menu's module_type.
        new("risk-centre-candidates","Risk Candidate","Risk candidates raised by Gap, Exception, Assurance, Obligation and other GRAC sources, assessed before entering the Risk Register.","inbox",["Candidate","Source","Rating","Status"], "Risk Management"),
        new("risk-centre-register","Risk Register","The authoritative repository of registered risks.","book",["Risk","Source","Rating","Status"], "Risk Management"),
        new("risk-centre-accept","Accept Risk","Risks ready for an acceptance decision.","circle-check",["Risk","Rating","Owner","Status"], "Risk Management"),
        new("risk-centre-review","Review Risk","Registered risks due for review.","rotate-left",["Risk","Next Review","Owner","Status"], "Risk Management"),
        new("risk-centre-calendar","Calendar","Upcoming risk reviews across the selected range.","calendar-days",["Risk","Next Review","Owner"], "Risk Management"),
        new("risk-centre-dashboard","Dashboard","Risk posture overview for the selected organization.","chart-pie",["Metric","Value"], "Risk Management"),
        // Management dashboards (migration 414). Since 416 each is the
        // "Dashboard" submenu (first child) of nav-governance /
        // nav-oversight / nav-assurance -- its menu row has this key, so the
        // row's name ("Dashboard") is the page title, as for
        // risk-centre-dashboard. VIEW: the row's own grant plus a child
        // screen (ManagementDashboards.CanOpen). Rendered by the shared
        // Partials/management-dashboard.cshtml.
        new("governance-dashboard","Governance Dashboard","Standards, practices and practice instances for the selected organization.","landmark",["Metric","Value"], GovernanceGroup),
        new("issues-actions-dashboard","Issues & Actions Dashboard","Issues, tasks and exceptions for the selected organization.","binoculars",["Metric","Value"], OversightGroup),
        new("audit-assurance-dashboard","Audit & Assurance Dashboard","Audits, findings and audit plans for the selected organization.","clipboard-check",["Metric","Value"], AuditManagementGroup),
        // =====================================================================
        new("assurance-dashboard","Assurance Dashboard","Operational assurance coverage, overdue activities, findings, and health signals for resolved practice instances","chart-line",["Metric","Value","Severity","Message"], AssuranceManagementGroup),
        new("assurance-generation","Assurance Activity Generation","Generate assurance activities for eligible resolved practice instances based on assurance frequency","calendar-plus",["PracticeInstance","AssuranceFrequency","AssuranceType","EligibilityStatus","NextDueDate","ActionStatus"], AssuranceManagementGroup),
        new("assurance-activities","Assurance Activity List","Assurance activities generated for resolved practice instances","clipboard-list",["ActivityNumber","PracticeInstance","PeriodFrom","PeriodTo","AssuranceType","ActivityOwner","DueDate","Status"], AssuranceManagementGroup),
        new("assurance-execution","Assurance Execution","Execute manual or automated assurance checks for an activity","person-circle-check",["ActivityNumber","PracticeInstance","ExecutionDate","Executor","EvidenceStatus","DependencyStatus","ResultStatus","Status"], AssuranceManagementGroup),
        new("evidence-assurance","Evidence Assurance","Verify expected evidence exists, is accessible, matches expected type, and relates to assurance","file-circle-check",["ActivityNumber","PracticeInstance","EvidenceType","EvidenceExists","EvidenceAccessible","MatchesExpectedType","RelatesToAssurance","ResultStatus"], AssuranceManagementGroup),
        new("dependency-assurance","Dependency Assurance","Verify resolved dependencies remain valid and support practice operation during the assurance period","network-wired",["ActivityNumber","PracticeInstance","DependencyType","ResolvedDependency","DependencyAvailable","DependencyCurrent","ResultStatus"], AssuranceManagementGroup),
        new("assurance-results","Assurance Result","Final assurance outcomes and operating effectiveness conclusions","square-poll-vertical",["ActivityNumber","PracticeInstance","ResultStatus","OperatingEffectiveness","CompletedDate","CompletedBy"], AssuranceManagementGroup),
        new("assurance-findings","Findings","Findings raised from assurance activities and unresolved evidence or dependency gaps","triangle-exclamation",["FindingNumber","ActivityNumber","PracticeInstance","Severity","FindingStatus","Owner","DueDate"], AssuranceManagementGroup),
        new("assurance-signals","Assurance Signals","Signals derived from evidence, dependency, trend, risk, and audit intelligence","wave-square",["SignalType","PracticeInstance","Severity","SignalStatus","DetectedDate","Message"], AssuranceManagementGroup),
        new("assurance-trends","Trend Engine","Assurance trend indicators across practice instances and periods","chart-column",["PracticeInstance","TrendType","CurrentValue","PreviousValue","TrendDirection","Severity"], AssuranceManagementGroup),
        new("practice-health","Practice Health Engine","Practice instance health calculated from assurance results, evidence, dependency, and findings","heart-pulse",["PracticeInstance","HealthScore","HealthStatus","Criticality","LastAssuredDate","OpenFindings"], AssuranceManagementGroup),
        new("audit-intelligence","Audit Intelligence View","Audit-oriented assurance intelligence for resolved practice instances","magnifying-glass-chart",["PracticeInstance","AuditableArea","LastAssuranceResult","EvidenceStatus","OpenFindings","AuditPriority"], AssuranceManagementGroup),
        new("risk-intelligence","Risk Intelligence View","Risk-oriented assurance intelligence for resolved practice instances","shield-halved",["PracticeInstance","RiskSignal","Criticality","HealthStatus","OpenFindings","RiskPriority"], AssuranceManagementGroup),
        // Sidebar placement: Oversight, not Assurance (migration 275).
        // The screen, its route and its permission area are unchanged --
        // only the group moved. This Group value drives the page eyebrow
        // (Views/Practice/Calendar.cshtml), so it has to track the
        // menu_master module_type or the eyebrow contradicts the sidebar.
        new("assurance-calendar","Task Calendar","Calendar and per-schedule list of the Execution and Assurance obligation schedules, one row per configured schedule","calendar-days",["Obligation","Type","Frequency","Owner","Next Schedule Date"], OversightGroup)
        ,
        // ===== Workflow & Event-Driven Assurance Engine (BRD v1.0) =====
        // Every screen renders via Views/Practice/Partials/{key}.cshtml
        // (dispatched from Manage.cshtml's workflowScreens set). Menu
        // rows + Admin permissions are seeded in migration 068.
        new("workflows","Workflow Definitions","Organization workflows -- unlimited, versioned, org-defined (BRD Sec 6).","sitemap",["Code","Name","ApplicableEntityType","Version","Owner","Status"], WorkflowGroup),
        new("workflow-stages","Workflow Stages","Ordered stages within a workflow with allowed transitions (BRD Sec 7).","route",["Sequence","Code","Name","AllowedTransitions","Status"], WorkflowGroup),
        new("workflow-entity-types","Entity Types","Configurable, org-defined entity types the engine understands -- no hard-coded categories (BRD Sec 9).","shapes",["Code","Name","Category","Status"], WorkflowGroup),
        new("workflow-events","Events","Lifecycle events organizations wish to observe -- People / Assets / Vendor / Application / Custom (BRD Sec 8).","bolt",["Code","Name","EntityCategory","TriggerSource","Status"], WorkflowGroup),
        new("workflow-checklists","Checklists","Reusable checklists composed of items -- Manual / Automated / API / Document / Approval / Integration (BRD Sec 11).","list-check",["Code","Name","Version","Items","Status"], WorkflowGroup),
        new("workflow-event-mappings","Event-Checklist Mappings","Entity + Event -> Checklist mappings driving the trigger engine (BRD Sec 10).","link",["EntityType","Event","Checklist","DefaultOwnerRole","DefaultDueDays","Status"], WorkflowGroup),
        // "workflow-scope-mapping" retired by migration 138. It was one screen
        // doing two unrelated jobs. Each half moved to where its master data
        // is maintained: role checklists to Role Master Add/Edit (a section on
        // the role form), asset-category checklists to "asset-category-
        // assurance" under Operations. No mapping data moved.
        // "workflow-event-inbox" retired: its contents are the Event Driven
        // Assurance tab of Task Center (Oversight). Two places showing the same
        // open checklists would mean two places to close them from, and no
        // answer to which one is the queue of record.
        new("event-assurance","Event Assurance","Event-driven assurance instances -- received, pending, completed, failed, overdue (BRD Sec 13/14).","shield-halved",["EventCode","Entity","Checklist","Owner","DueDate","Status"], WorkflowGroup),
        new("workflow-dashboard","Workflow Dashboard","Cross-workflow event and assurance KPIs (BRD Sec 16).","chart-line",["Metric","Value"], WorkflowGroup)
        ,
        // ===== Phase 2 Assurance Management (BRD Part 2) =====
        // Presented as "Audit Management" since migration 276.
        // NEW, INDEPENDENT module. Menu row seeded under nav-assurance
        // (parent_menu_id) by migration 071. Consumes Admin (grac_new)
        // published assurance metadata via repository_subscription.
        // Stage 1 = Assurance Definitions + lifecycle only.
        //
        // The two container screens below are pure navigation: they own
        // no data, no API and no business logic. Each renders the
        // EXISTING screen partials as steps of one flow (see
        // Partials/_audit-flow-shell.cshtml), so every screen still has
        // exactly one implementation and every screen below remains
        // reachable on its own route and its own menu row.
        new("org-audit-definition","Audit Definition","Define an audit in one flow: audit details, then scope, then question sets.","file-shield",["Step","Screen"], AuditManagementGroup),
        new("org-audit-configuration","Audit Configuration","Configure how a defined audit operates: evidence, workflow, scoring, triggers and scope resolution.","sliders",["Step","Screen"], AuditManagementGroup),
        new("org-assurance-definitions","Audit Definitions","Organization-level Audit Definitions with lifecycle Draft / Under Review / Approved / Active / Retired (BRD Part 2 Sec 1).","file-shield",["Code","Name","Category","Owner","Version","Status"], AuditManagementGroup),
        // Scope Builder (BRD Part 2 Sec 2). Menu row seeded by
        // migration 075. Loads a definition via ?definitionId=X and
        // renders read-only when the current version is not Draft.
        new("org-assurance-scope-builder","Scope Builder","Configure the audit scope for an audit using groups + conditions across 17 dimensions with AND / OR / NOT operators (BRD Part 2 Sec 2).","diagram-project",["Group","Operator","Dimension","Condition","Values"], AuditManagementGroup),
        // Question Builder (BRD Part 2 Sec 4). Menu row seeded by
        // migration 078. Question sets are organization-level reusable
        // artifacts; each definition later ADOPTS one or more sets.
        new("org-assurance-question-sets","Question Sets","Reusable Question Sets and their Questions -- with Admin-published question types, mandatory / weight / order / expected response (BRD Part 2 Sec 4).","clipboard-list",["Code","Name","Owner","Questions","Status"], AuditManagementGroup),
        // Evidence Configuration (BRD Part 2 Sec 5). Per-definition-
        // version evidence expectations. Menu row seeded by migration
        // 081; reuses PM evidence_type_master + collection_method_master.
        new("org-assurance-evidence-config","Evidence Config","Configure the evidence expected for a definition -- type, collection method (existing / API / manual), mandatory flag, validity, expiry (BRD Part 2 Sec 5).","file-circle-check",["Label","Type","Method","Mandatory","Validity"], AuditManagementGroup),
        // Workflow Configuration (BRD Part 2 Sec 6). Per-definition-
        // version workflow with stages (Auditor / Reviewer / Approver /
        // Custom), assigned role / employee, SLA and escalation.
        // Menu row seeded by migration 085.
        new("org-assurance-workflow-config","Workflow Config","Configure the workflow for a definition -- customize from an Admin template; stages with auditor / reviewer / approver, assignments, SLA, escalation (BRD Part 2 Sec 6).","sitemap",["Order","Stage","Type","Assigned","SLA"], AuditManagementGroup),
        // Scoring Configuration (BRD Part 2 Sec 7). Per-definition-
        // version scoring model + bands. Menu row seeded by migration
        // 088. Controlled representation -- no user formulas, no
        // dynamic SQL.
        new("org-assurance-scoring-config","Scoring Config","Configure the scoring model for a definition -- Pass/Fail, Weighted, Risk Based, Maturity Based, Percentage or Custom; with thresholds and bands (BRD Part 2 Sec 7).","gauge",["ModelType","Bands","Pass","Warning","Fail"], AuditManagementGroup),
        // Assurance Plans (BRD Part 2 Sec 8). Stage 3. Annual /
        // Quarterly / Monthly / One-Time plans; items link to
        // assurance definitions with schedule + assignments.
        // Menu row seeded by migration 091.
        new("org-assurance-plans","Audit Plans","Annual / Quarterly / Monthly / One-Time Audit Plans with items that schedule audits and assign owner / team / auditor / department / branch (BRD Part 2 Sec 8).","calendar-days",["Code","Name","Type","Period","Owner","Items","Status"], AuditManagementGroup),
        // Triggers (BRD Part 2 Sec 9). Stage 3. Per-definition-version
        // triggers of type SCHEDULED / EVENT_DRIVEN / CONTINUOUS /
        // MANUAL. Menu row seeded by migration 094.
        new("org-assurance-triggers","Triggers","Configure Scheduled / Event Driven / Continuous / Manual triggers for a definition version. Scheduled uses Daily/Weekly/Monthly/Quarterly/Annual; Event Driven uses License Expiry / User Termination / Vendor Renewal / High Value Transaction / New Asset / Policy Change / Security Incident (BRD Part 2 Sec 9).","bolt",["Code","Name","Type","Enabled","Details"], AuditManagementGroup),
        // Scope Resolution (BRD Part 2 Sec 3). Stage 3. Runs the
        // resolver over a definition version's scope and stores an
        // immutable snapshot for historical execution. Menu row seeded
        // by migration 097.
        new("org-assurance-scope-resolution","Scope Resolution","Preview or view historical Scope Resolution snapshots for an audit (BRD Part 2 Sec 3).","circle-nodes",["When","Purpose","Dimensions","Total"], AuditManagementGroup),
        // Executions (BRD Part 2 Sec 9-10). Stage 3. Materializes a
        // definition + resolved scope + immutable config snapshot into
        // a live executable record. Menu row seeded by migration 100.
        new("org-assurance-executions","Executions","Materialize and manage live audit executions against resolved scope snapshots (BRD Part 2 Sec 9-10).","play-circle",["Execution","Definition","Status","Progress"], AuditManagementGroup),
        // Observations (BRD Part 2 Sec 11). Stage 4. Findings recorded
        // during an execution, evidence attachments, review + resolution
        // lifecycle. Menu row seeded by migration 103.
        // Assurance-source gaps now land in the UNIFIED Gap Center
        // (Practice/Index/gaps -> Assurance Gaps tab) instead of a
        // separate assurance-only page. See migrations 109 - 113.
        new("org-assurance-observations","Observations","Findings recorded during audit executions -- capture, evidence, review, resolve (BRD Part 2 Sec 11).","triangle-exclamation",["Observation","Severity","Status","Owner"], AuditManagementGroup),
        // ===== Organization SLA Configuration (migrations 178/179/180) =====
        // Adopts SLA masters published by Control Management (grac_new)
        // into per-organization configurations with warning/escalation
        // day thresholds, notify roles (WARNING / ESCALATION), and
        // process bindings (GAP / TASK / OBSERVATION / EXCEPTION ...).
        // Screen sits under nav-governance (menu seed 180).
        new("org-sla-config","SLA Configuration","Adopt Control Management SLA masters, configure warning + escalation day thresholds, pick notify roles, and bind the tuned SLA against processes (Gap / Task / Observation / Exception).","clock",["SLA","TotalDays","Warning","Escalation","Roles","Processes"], GovernanceGroup),
        // Risk acceptance approval authority (migration 271).
        //
        // OrganizationGroup, not Oversight: this configures the
        // ORGANISATION -- who may approve accepting a risk at each rating
        // level -- and the Risk Centre reads it. It is reached from
        // Organization -> Risk Acceptance Approval Authority, and the
        // group here is what puts "Organization / ..." in the page
        // eyebrow so the screen matches the sidebar it hangs off.
        //
        // The columns are the grid's real headers. They do NOT name the
        // rating levels: those come per-organisation from risk_matrix_cell
        // at runtime, so listing them here would be a second, stale copy
        // of a vocabulary that is deliberately not fixed.
        new("risk-acceptance-authority","Risk Acceptance Approval Authority","Set who may approve accepting a risk at each rating level, separately for the inherent score and the residual score after treatment. Levels not set here fall back to the organization's general risk approver.","user-shield",["Risk Level","Inherent Authority","Same as Inherent","Residual Authority"], OrganizationGroup),
        // Settings -> Risk Settings (migration 458, 2026-10-08). The Risk
        // Centre settings (BRD §19, §22) moved off the gear icon on Risk
        // Candidate / Risk Register into their own Settings page.
        new("risk-settings","Risk Settings","Risk Management settings for an organization: approval before registering a risk, the approver, the treatment-task default, notifications and the residual-analysis rule.","sliders",["Setting","Value"], OrganizationGroup),
        // Asset & Contract Management, Phase 2.1 (migration 420). Field
        // Dictionary is the read-only BRD 5.1 field library; Asset Form
        // Templates is the per-organization, versioned form designer.
        new("asset-field-dictionary","Field Dictionary","The controlled library of asset fields: data type, validation, sensitivity and where each value is stored. Asset form templates select their fields from here.","book",["Field","Group","Data Type","Sensitivity","Baseline"], AssetContractGroup),
        new("asset-form-templates","Asset Form Templates","Design the registration form for each asset type: choose dictionary fields, arrange sections, set field behaviour, then test, approve and activate a version.","table-list",["Asset Type","Template","Version","Status","Owner"], AssetContractGroup),
        // Asset & Contract Management, Phase 2.3 (migration 422): versioned,
        // approval-controlled CIA scales, valuation method, Asset Value bands
        // and criticality scale for the organization (BRD 5.1.18).
        new("asset-valuation-config","Asset Valuation","Configure the Confidentiality, Integrity and Availability scales, the valuation method, Asset Value bands and the criticality scale used to value assets. Changes go through approval and create a new version.","scale-balanced",["Version","Method","Status","Effective"], AssetContractGroup),
        // Phase 2.4 (migration 423): the organization's own values for asset
        // option lists (sites' buildings, floors, rooms, zones, cost centres,
        // ...) on top of the global defaults.
        new("asset-option-lists","Option Lists","Maintain the organization's values for asset drop-down lists: add buildings, floors, rooms, zones and other local values, and relabel or hide a default value for this organization. Templates and the asset form use the resulting list.","list-ul",["List","Scope","Values","Used By"], AssetContractGroup),
        // Phase 2.5 (migration 424): governance of the global asset taxonomy
        // (category / L1-L2 subcategory / asset type) plus each
        // organization's default owner role and support group per type.
        new("asset-taxonomy","Asset Taxonomy","The shared classification of assets: categories, level-1 and level-2 subcategories and asset types, with sector, owner, standards, default criticality and effective dates. Organizations set the default business owner role and support group for each asset type.","sitemap",["Name","Level","Criticality","Effective","Status"], AssetContractGroup),
        // Phase 3.1 (migration 425): technology catalogue -- makes and
        // models with lifecycle dates, lifecycle status and approval.
        new("asset-tech-catalog","Technology Catalogue","Maintain asset makes and models: manufacturer details, supported asset types, release and support dates, lifecycle status and approval. Shared catalogue entries are maintained by the platform administrator; organizations can add their own.","microchip",["Make","Model","Lifecycle","Approval"], AssetContractGroup),
        // Phase 4.1 (migration 428): the Asset Register -- registration on
        // the Active form template of the asset type (dynamic form).
        new("asset-register","Asset Register","Register and maintain assets on the form designed for their asset type. Fields, sections and rules come from the Active form template; each asset keeps the template version it was registered with.","boxes-stacked",["Asset","Type","Status","Owner","Location"], AssetContractGroup),
        // Phase 4.4 (migration 431): custodian acknowledgement and periodic
        // attestation -- profiles, runs / campaigns, responses, approvals.
        new("asset-attestation","Asset Attestation","Custodians and owners confirm the assets assigned to them: initial acknowledgement on assignment and periodic attestation by profile, with disagreements recorded for investigation.","clipboard-check",["Asset","Assignee","Due","Status","Response"], AssetContractGroup),
        // Phase 7.3 (migration 442): discovery and reconciliation -- sources,
        // rules, ingestion, reconciliation queue, data confidence.
        new("asset-discovery","Asset Discovery","Discovery and reconciliation: source profiles with field precedence and trust, identification rules and thresholds, batch import with per-record results, the reconciliation queue (suggested matches, reviews, new candidates, duplicates, conflicts) and data confidence and freshness per asset.","satellite-dish",["Source","Batch","Outcome","Asset","Confidence"], AssetContractGroup),
        // Phase 8.3 (migration 448): privacy -- status and gaps per asset,
        // exceptions, privacy and retention reviews, requirement settings.
        new("asset-privacy","Asset Privacy","Personal data on assets: DPDP / GDPR applicability, privacy status and gaps against the privacy requirements (assessment, processing details, DPIA / PIA, masking, encryption, retention, third parties, review, sanitization), privacy exceptions with approval and expiry, privacy and retention reviews, and the requirement settings of the organization.","user-shield",["Asset","Privacy status","Gaps","Owner","Review"], AssetContractGroup),
        // Phase 8.4a (migration 450): governance KPIs -- BRD 19.8 scores
        // with snapshots, record drill-down, thresholds and weights.
        new("asset-governance","Asset Governance","Governance KPIs of the asset register (BRD 19.8): attestation compliance, metadata, ownership and relationship completeness, coverage and technology support compliance, exception health, discovery freshness, reconciliation backlog and connector availability -- scores against thresholds, the overall score, trends, snapshot history and the exact numerator, denominator, excluded and failing records of every score.","gauge-high",["KPI","Score","Numerator","Denominator","Rating"], AssetContractGroup),
        // Phase 8.5a (migration 452): report catalogue -- BRD 13.4 standard
        // reports with governed CSV export (13.4.1).
        new("asset-reports","Asset Reports","Standard reports of the asset module (BRD 13.4): asset register, ownership and custody, lifecycle, missing data, movement, disposal; attestation compliance, overdue, exceptions, lost and damaged, SLA; CMDB relationships, orphans, service topology, critical dependencies, data quality; discovery coverage, stale assets, source health, reconciliation queue, merge and split history; contract expiry, renewals, coverage gaps, entitlements, vendor contacts; technology support; CIA, Asset Value and risk; governance scores; privacy, DPIA, masking and encryption, retention and evidence expiry -- each limited to the screens the user may view, with CSV export recorded with report, version, filters, columns, user, organization, time and classification.","file-lines",["Report","Family","Classification","Rows","Exported"], AssetContractGroup),
        // Phase 8.4b (migration 451): the module dashboard of Asset &
        // Contract (first child, 416 rule) -- Partials/management-dashboard.
        new("asset-contract-dashboard","Asset & Contract Dashboard","Governance score, asset register, technology lifecycle, contracts and coverage, attestation, maintenance and calibration, privacy, CMDB quality and discovery, business services, relationships and notification operations for the selected organization.","boxes-stacked",["Metric","Value"], AssetContractGroup),
        // Phase 7.2 (migration 441): business services -- register, consumers,
        // supporting items, status rules, conflicts, hierarchy.
        new("business-services","Business Services","Business services and what they run on: owners, criticality and CIA, RTO / RPO / MTPD, consumers, supporting assets, applications, suppliers, contracts and child services, activation and retirement rules, continuity conflicts and the service hierarchy.","sitemap",["Service","Type","Status","Owner","Support"], AssetContractGroup),
        // Phase 7.1 (migration 440): CMDB relationships -- types, governed
        // relationships, impact analysis.
        new("asset-relationships","Asset Relationships","Effective-dated, governed relationships between assets, applications, processes, vendors and locations: proposals and approvals, disputes and retirement, circular-dependency and cardinality checks, and impact analysis upstream and downstream.","diagram-project",["Source","Relationship","Target","Status","Effective"], AssetContractGroup),
        // Phase 6.2 (migration 438): recurring asset activities -- templates,
        // schedules, occurrences with Task Centre tasks, campaigns.
        new("asset-activities","Asset Activities","Recurring asset activities: calibration, preventive maintenance, statutory inspection and equipment licence renewal. Schedules come from the asset register; the scheduler opens one occurrence per asset and due date and creates its Task Centre task, or records that a contract covers it.","calendar-check",["Asset","Activity","Next due","Status","Task"], AssetContractGroup),
        // Phase 6.1 (migration 437): notification profiles, escalation
        // matrix, notification occurrences and log, scheduler runs.
        new("asset-notifications","Asset Notifications","Reminders and escalations for asset and contract dates: notification profiles by activity with reminder, due and escalation stages, recipients and acknowledgement, the escalation matrix by severity, the occurrences the scheduler is tracking and every notice it recorded.","bell-concierge",["Activity","Subject","Date","Stage","Status"], AssetContractGroup),
        // Phase 5.1 (migration 434): contracts -- contract register,
        // immutable versions with approval, vendor contact mapping.
        new("asset-contracts","Contracts","Maintain contracts with the vendors of the organization: every renewal, amendment, extension or termination is a new version that is reviewed and approved, takes effect on its date and keeps the earlier versions, documents and vendor contacts unchanged.","file-contract",["Contract","Type","Vendor","Status","Version"], AssetContractGroup),
        // Third-Party Risk Management (migrations 486-490): the module
        // dashboard, the third-party register, the engagement workspace (the
        // BRD's five steps), reviews and the three configuration layers.
        new("tprm-dashboard","Third-Party Risk Dashboard","Third parties, engagements by stage, criticality and risk band, due diligence, open findings and remediation, reviews and expiring risk acceptances for the selected organization.","chart-pie",["Metric","Value"], TprmGroup),
        new("tprm-third-parties","Third Parties","Register third parties once with their legal identity, services, contacts and lifecycle status: duplicates are found before saving, GRAC vendors can be imported and linked, and every engagement with the third party is listed.","building",["Code","Third party","Type","Category","Status","Engagements","Owner"], TprmGroup),
        new("tprm-engagements","Engagements","Assess each engagement with a third party: scope and exposure discovered from GRAC, inherent risk, due diligence with safeguards and evidence, residual risk, the risk decision and approvals, onboarding and the engagement lifecycle.","file-signature",["Code","Engagement","Third party","Stage","Criticality","Risk band","Next review","Owner"], TprmGroup),
        new("tprm-reviews","Third-Party Reviews","Periodic and triggered reviews of third-party engagements: scheduled reviews, contract, certification and risk-acceptance expiry, incidents, material changes and overdue remediation.","calendar-check",["Review","Engagement","Type","Trigger","Due","Owner","Status"], TprmGroup),
        new("tprm-configuration","TPRM Configuration","GRAC baseline and organization configuration of Third-Party Risk Management: reference lists, safeguard and evidence library, risk models and questionnaires with versions, approval and review rules, delegations and custom fields.","sliders",["Item","Origin","Status"], TprmGroup)
    ];
}

