-- =====================================================================
-- 2. Menu: Asset & Contract -> Dashboard (first child, 416 rule; also
--    carried in 274) and VIEW for every role that can VIEW one of the
--    screens it summarises (the ManagementDashboards sections).
-- =====================================================================
MERGE grac_practice.menu_master AS t
USING (
    SELECT x.menu_key, x.menu_url, x.display_order, x.module_type, p.menu_id AS parent_menu_id
      FROM (VALUES (N'asset-contract-dashboard', N'Practice/Index/asset-contract-dashboard', 348, N'Asset & Contract', N'nav-asset-contract'))
           x(menu_key, menu_url, display_order, module_type, parent_key)
      JOIN grac_practice.menu_master p ON p.menu_key = x.parent_key
) AS s
ON t.menu_key = s.menu_key
WHEN MATCHED AND (ISNULL(t.menu_url, N'') <> s.menu_url OR ISNULL(t.parent_menu_id, -1) <> s.parent_menu_id
               OR t.display_order <> s.display_order OR t.menu_name <> N'Dashboard' OR t.status <> N'Active') THEN UPDATE SET
    menu_name = N'Dashboard', menu_url = s.menu_url, parent_menu_id = s.parent_menu_id, display_order = s.display_order,
    icon_class = N'chart-pie', module_type = s.module_type, status = N'Active', updated_by = N'seed-451', updated_dt = SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT
    (menu_key, menu_name, menu_url, parent_menu_id, display_order, icon_class, module_type, status, entered_by)
VALUES (s.menu_key, N'Dashboard', s.menu_url, s.parent_menu_id, s.display_order, N'chart-pie', s.module_type, N'Active', N'seed-451');
PRINT CONCAT('451: dashboard menu row upserted: ', @@ROWCOUNT);
GO

DECLARE @active_rs INT = (
    SELECT TOP 1 record_status_id FROM grac_practice.record_status_master
     WHERE status_code = N'Active' OR status_name = N'Active' ORDER BY record_status_id);
IF @active_rs IS NULL SET @active_rs = 1;
INSERT grac_practice.organization_role_menu_permission
    (role_id, menu_id, can_view, can_add, can_edit, can_delete, can_approve, status, record_status_id, entered_by, entered_dt)
SELECT DISTINCT p.role_id, d.menu_id, 1, 0, 0, 0, 0, N'Active', @active_rs, N'seed-451', SYSUTCDATETIME()
  FROM (VALUES (N'asset-register'), (N'asset-contracts'), (N'asset-attestation'), (N'asset-activities'), (N'asset-privacy'),
               (N'asset-discovery'), (N'business-services'), (N'asset-relationships'), (N'asset-notifications'),
               (N'asset-governance')) x(child_key)
  JOIN grac_practice.menu_master d ON d.menu_key = N'asset-contract-dashboard'
  JOIN grac_practice.menu_master c ON c.menu_key = x.child_key AND c.status = N'Active'
  JOIN grac_practice.organization_role_menu_permission p ON p.menu_id = c.menu_id AND p.can_view = 1 AND p.status = N'Active'
 WHERE NOT EXISTS (SELECT 1 FROM grac_practice.organization_role_menu_permission e
                    WHERE e.role_id = p.role_id AND e.menu_id = d.menu_id);
PRINT CONCAT('451: dashboard VIEW grants inserted: ', @@ROWCOUNT);
GO
