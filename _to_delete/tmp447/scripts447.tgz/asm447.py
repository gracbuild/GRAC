W='/home/claude/w447/'
p=lambda k: open(W+'part_'+k+'.sql').read()
d = """-- =====================================================================
-- 8. Re-issued bodies (447 lines marked; otherwise unchanged)
-- =====================================================================
-- 446 body: evaluate the saved asset; its open findings come back as warnings.
""" + p('rs2') + """GO
PRINT '447: sp_asset_register_save re-issued.';
GO

-- 446 body: consistency step per organization.
""" + p('sc2') + """GO
PRINT '447: sp_asset_scheduler_run re-issued.';
GO

-- 440 body: Block-transition findings stop a move to Active.
""" + p('lt2') + """GO
PRINT '447: sp_asset_lifecycle_transition re-issued.';
GO

-- 446 body: linked risks and consistency findings of the asset.
""" + p('vg2') + """GO
PRINT '447: sp_asset_valuation_get re-issued.';
GO

"""
open(W+'447_d.sql','w').write(d)
s=''.join(open(W+f).read() for f in ['447_a.sql','447_b.sql','447_c.sql','447_d.sql','447_e.sql'])
open(W+'447.sql','w').write(s)
rb = """-- =====================================================================
-- 447 ROLLBACK  CIA and criticality consistency rules
-- =====================================================================
-- Restores sp_asset_register_save, sp_asset_scheduler_run and
-- sp_asset_valuation_get (446) and sp_asset_lifecycle_transition (440),
-- drops the 447 procedures, functions and tables (rules, findings and
-- their acceptances are lost). The AssetConsistency task type and any
-- tasks it raised stay.
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

""" + p('rs') + "GO\n" + p('sc') + "GO\n" + p('lt') + "GO\n" + p('vg') + """GO
PRINT '447 rollback: 440 and 446 bodies restored.';
GO

DROP PROCEDURE IF EXISTS grac_practice.sp_asset_consistency_findings;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_consistency_rule_preview;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_consistency_operands;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_consistency_rule_get;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_consistency_rules;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_consistency_rule_action;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_consistency_rule_save;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_consistency_finding_action;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_consistency_run;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_consistency_evaluate;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_consistency_scope_label;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_risk_value;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_consistency_eval;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_consistency_facts;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_consistency_operands;
GO
DROP TABLE IF EXISTS grac_practice.asset_consistency_finding;
DROP TABLE IF EXISTS grac_practice.asset_consistency_rule_condition;
DROP TABLE IF EXISTS grac_practice.asset_consistency_rule;
GO
PRINT '447 rollback: consistency objects dropped.';
GO

SELECT '447 rollback' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_consistency_rule','U') IS NULL
             AND OBJECT_ID('grac_practice.fn_asset_consistency_eval') IS NULL
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_register_save')) NOT LIKE '%sp_asset_consistency_evaluate%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) NOT LIKE '%sp_asset_consistency_evaluate%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_lifecycle_transition')) NOT LIKE '%53037%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_valuation_get')) NOT LIKE '%fn_asset_risk_value%'
            THEN 'PASS' ELSE 'FAIL' END AS Result;
GO
"""
open(W+'447_rb.sql','w').write(rb)
print('assembled', s.count('\n'), rb.count('\n'))
