# 437 -- API, worker and Program.cs changes. Run from the repository root.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    return s

A = 'src/PracticeManagement.Api/'
files = {}

# ---------------------------------------------------------------- models
files[A + 'Models/AssetConfigModels.cs'] = edit(A + 'Models/AssetConfigModels.cs', [(
"""/// <summary>Outcome of a write: Success, the new/affected id, and on
/// failure the SQL error number + message so the controller can pick the""",
"""// ---------------------------------------------------------------------
// Notification profiles, escalation matrix, occurrences, scheduler (437)
// ---------------------------------------------------------------------
/// <summary>A recipient of a stage: a party code (ACTIVITY_OWNER, ASSET_OWNER, CONTRACT_OWNER,
/// MANAGER ...) or ROLE with the organization role.</summary>
public sealed record AssetNotificationRecipientRequest(string? RecipientCode, long? RoleId);

/// <summary>REMINDER (days before) | DUE | ESCALATION (days after, level 1-3); class
/// INFORMATIONAL | REMINDER | ESCALATION | CRITICAL.</summary>
public sealed record AssetNotificationStageRequest(
    string?                                           StageKind,
    int?                                              OffsetDays,
    int?                                              EscalationLevel,
    string?                                           NotificationClass,
    IReadOnlyList<AssetNotificationRecipientRequest>? Recipients);

/// <summary>Create (ProfileId null) or edit a notification profile with its stages (9.1.1).</summary>
public sealed record AssetNotificationProfileRequest(
    long                                          OrganizationId,
    long?                                         ProfileId,
    string?                                       ActivityCode,
    string?                                       ProfileName,
    string?                                       SeverityCode,
    long?                                         OwnerEmployeeId,
    DateTime?                                     EffectiveFrom,
    DateTime?                                     EffectiveTo,
    bool?                                         IsActive,
    string?                                       AckMode,
    bool?                                         ChannelInApp,
    bool?                                         ChannelEmail,
    bool?                                         ChannelWebhook,
    bool?                                         SnoozeAllowed,
    bool?                                         WorkingDaysOnly,
    IReadOnlyList<AssetNotificationStageRequest>? Stages,
    long?                                         ExpectedRecordVersion);

/// <summary>One escalation matrix entry: level 0-3 and a recipient.</summary>
public sealed record AssetEscalationEntryRequest(int? EscalationLevel, string? RecipientCode, long? RoleId);

/// <summary>Replace the escalation matrix entries of one severity (9.1.8).</summary>
public sealed record AssetEscalationMatrixRequest(long OrganizationId, string? SeverityCode, IReadOnlyList<AssetEscalationEntryRequest>? Entries);

/// <summary>Snooze / reschedule an occurrence to SnoozedUntil (null resumes); reason required.</summary>
public sealed record AssetNotificationSnoozeRequest(long OrganizationId, DateTime? SnoozedUntil, string? Reason, long? ExpectedRecordVersion);

/// <summary>A dispatcher reports a delivery: SENT, or FAILED with the reason.</summary>
public sealed record AssetNotificationDeliveryRequest(long OrganizationId, string? StatusCode, string? FailureReason);

/// <summary>Run the asset scheduler now for one organization.</summary>
public sealed record AssetSchedulerRunRequest(long OrganizationId);

/// <summary>The recipient's own action: READ | ACKNOWLEDGE (Note = action taken) | CONFIRM (manager).</summary>
public sealed record AssetNotificationMineActionRequest(string? Action, string? Note);

/// <summary>Outcome of a write: Success, the new/affected id, and on
/// failure the SQL error number + message so the controller can pick the""")])

# ---------------------------------------------------------------- service
files[A + 'Services/AssetConfigService.cs'] = edit(A + 'Services/AssetConfigService.cs', [
("""//   sp_asset_contract_renewal_* (436 -- renewal occurrences and coverage reconciliation)""",
"""//   sp_asset_contract_renewal_* (436 -- renewal occurrences and coverage reconciliation)
//   sp_asset_notification_* / sp_asset_escalation_matrix_save / sp_asset_scheduler_* (437 --
//   notification profiles, escalation, occurrences, the scheduler pass run by TaskNotificationWorker)"""),
("""    Task<AssetLifecycleResult> ResolveRenewalItemAsync(long itemId, AssetContractRenewalResolveRequest request, string actor, CancellationToken ct);
}""",
"""    Task<AssetLifecycleResult> ResolveRenewalItemAsync(long itemId, AssetContractRenewalResolveRequest request, string actor, CancellationToken ct);

    // 437 -- Notification profiles, escalation, occurrences, scheduler
    Task<object> GetNotificationConfigAsync(long organizationId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> SaveNotificationProfileAsync(AssetNotificationProfileRequest request, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> SaveEscalationMatrixAsync(AssetEscalationMatrixRequest request, string actor, CancellationToken ct);
    Task<object> ListNotificationOccurrencesAsync(long organizationId, string? status, string? activityCode, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<object?> GetNotificationOccurrenceAsync(long organizationId, long occurrenceId, CancellationToken ct);
    Task<AssetLifecycleResult> SnoozeNotificationOccurrenceAsync(long occurrenceId, AssetNotificationSnoozeRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<object> ListNotificationLogAsync(long organizationId, string? statusCode, string? activityCode, string? notificationClass, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<AssetLifecycleResult> ReportNotificationDeliveryAsync(long notificationId, AssetNotificationDeliveryRequest request, string actor, CancellationToken ct);
    Task<object> ListSchedulerRunsAsync(long organizationId, CancellationToken ct);
    /// <summary>One scheduler pass (sp_asset_scheduler_run): every organization when
    /// <paramref name="organizationId"/> is null. Used by TaskNotificationWorker and "Run now".</summary>
    Task<Dictionary<string, object?>> RunSchedulerAsync(long? organizationId, string triggerCode, string actor, CancellationToken ct);
    Task<object> ListMyNotificationsAsync(long employeeId, string? filter, int pageNumber, int pageSize, CancellationToken ct);
    Task<object> CountMyNotificationsAsync(long employeeId, CancellationToken ct);
    Task<AssetLifecycleResult> MyNotificationActionAsync(long employeeId, long notificationId, AssetNotificationMineActionRequest request, string actor, CancellationToken ct);
    Task<int> ReadAllMyNotificationsAsync(long employeeId, CancellationToken ct);
}"""),
("""    /// <summary>The lifecycle (429) and technology (430) write procedures
    /// end with one row""",
"""    // ----------------------------------------------------------------
    // 437 -- Notification profiles, escalation, occurrences, scheduler
    // ----------------------------------------------------------------
    public async Task<object> GetNotificationConfigAsync(long organizationId, string actor, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_notification_config_get");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@actor",           DbType.String, actor, 100);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var empty = new List<Dictionary<string, object?>>();
        var activities     = await ReadRowsAsync(reader, ct);
        var recipientTypes = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var profiles       = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var stages         = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var recipients     = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var matrix         = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var roles          = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var employees      = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        return new { activities, recipientTypes, profiles, stages, recipients, matrix, roles, employees };
    }

    public Task<AssetLifecycleResult> SaveNotificationProfileAsync(AssetNotificationProfileRequest request, string actor, CancellationToken ct)
    {
        var stages = System.Text.Json.JsonSerializer.Serialize((request.Stages ?? Array.Empty<AssetNotificationStageRequest>()).Select(s => new
        {
            stageKind = s.StageKind,
            offsetDays = s.OffsetDays,
            escalationLevel = s.EscalationLevel,
            notificationClass = s.NotificationClass,
            recipients = (s.Recipients ?? Array.Empty<AssetNotificationRecipientRequest>())
                .Select(r => new { recipientCode = r.RecipientCode, roleId = r.RoleId })
        }));
        return ResultRowWriteAsync("grac_practice.sp_asset_notification_profile_save", "profileId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,   request.OrganizationId);
            AddParam(command, "@profile_id",              DbType.Int64,   request.ProfileId);
            AddParam(command, "@activity_code",           DbType.String,  Blank(request.ActivityCode), 40);
            AddParam(command, "@profile_name",            DbType.String,  Blank(request.ProfileName), 200);
            AddParam(command, "@severity_code",           DbType.String,  Blank(request.SeverityCode), 10);
            AddParam(command, "@owner_employee_id",       DbType.Int64,   request.OwnerEmployeeId);
            AddParam(command, "@effective_from",          DbType.Date,    request.EffectiveFrom?.Date);
            AddParam(command, "@effective_to",            DbType.Date,    request.EffectiveTo?.Date);
            AddParam(command, "@is_active",               DbType.Boolean, request.IsActive ?? true);
            AddParam(command, "@ack_mode",                DbType.String,  Blank(request.AckMode) ?? "READ", 10);
            AddParam(command, "@channel_in_app",          DbType.Boolean, request.ChannelInApp ?? true);
            AddParam(command, "@channel_email",           DbType.Boolean, request.ChannelEmail ?? false);
            AddParam(command, "@channel_webhook",         DbType.Boolean, request.ChannelWebhook ?? false);
            AddParam(command, "@snooze_allowed",          DbType.Boolean, request.SnoozeAllowed ?? true);
            AddParam(command, "@working_days_only",       DbType.Boolean, request.WorkingDaysOnly ?? false);
            AddParam(command, "@stages_json",             DbType.String,  stages, -1);
            AddParam(command, "@expected_record_version", DbType.Int64,   request.ExpectedRecordVersion);
            AddParam(command, "@actor",                   DbType.String,  actor, 100);
        }, ct);
    }

    public Task<AssetLifecycleResult> SaveEscalationMatrixAsync(AssetEscalationMatrixRequest request, string actor, CancellationToken ct)
    {
        var entries = System.Text.Json.JsonSerializer.Serialize((request.Entries ?? Array.Empty<AssetEscalationEntryRequest>()).Select(e => new
        {
            escalationLevel = e.EscalationLevel,
            recipientCode = e.RecipientCode,
            roleId = e.RoleId
        }));
        return ResultRowWriteAsync("grac_practice.sp_asset_escalation_matrix_save", "organizationId", command =>
        {
            AddParam(command, "@organization_id", DbType.Int64,  request.OrganizationId);
            AddParam(command, "@severity_code",   DbType.String, Blank(request.SeverityCode), 10);
            AddParam(command, "@entries_json",    DbType.String, entries, -1);
            AddParam(command, "@actor",           DbType.String, actor, 100);
        }, ct);
    }

    public async Task<object> ListNotificationOccurrencesAsync(long organizationId, string? status, string? activityCode, string? search, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_notification_occurrence_list");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 12);
        AddParam(command, "@activity_code",   DbType.String, Blank(activityCode), 40);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object?> GetNotificationOccurrenceAsync(long organizationId, long occurrenceId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_notification_occurrence_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@occurrence_id",   DbType.Int64, occurrenceId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var header = await ReadRowsAsync(reader, ct);
            if (header.Count == 0) return null;
            var empty = new List<Dictionary<string, object?>>();
            var stages        = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var notifications = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            return new { occurrence = header[0], stages, notifications };
        }
        catch (SqlException ex) when (ex.Number == 54625) { return null; }
    }

    public Task<AssetLifecycleResult> SnoozeNotificationOccurrenceAsync(long occurrenceId, AssetNotificationSnoozeRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_notification_occurrence_snooze", "occurrenceId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@occurrence_id",           DbType.Int64,  occurrenceId);
            AddParam(command, "@snoozed_until",           DbType.Date,   request.SnoozedUntil?.Date);
            AddParam(command, "@reason",                  DbType.String, Blank(request.Reason), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public async Task<object> ListNotificationLogAsync(long organizationId, string? statusCode, string? activityCode, string? notificationClass, string? search, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_notification_log");
        AddParam(command, "@organization_id",    DbType.Int64,  organizationId);
        AddParam(command, "@status_code",        DbType.String, Blank(statusCode), 20);
        AddParam(command, "@activity_code",      DbType.String, Blank(activityCode), 40);
        AddParam(command, "@notification_class", DbType.String, Blank(notificationClass), 20);
        AddParam(command, "@search",             DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",        DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",          DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public Task<AssetLifecycleResult> ReportNotificationDeliveryAsync(long notificationId, AssetNotificationDeliveryRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_notification_delivery", "notificationId", command =>
        {
            AddParam(command, "@organization_id", DbType.Int64,  request.OrganizationId);
            AddParam(command, "@notification_id", DbType.Int64,  notificationId);
            AddParam(command, "@status_code",     DbType.String, Blank(request.StatusCode), 20);
            AddParam(command, "@failure_reason",  DbType.String, Blank(request.FailureReason), 1000);
            AddParam(command, "@actor",           DbType.String, actor, 100);
        }, ct);

    public async Task<object> ListSchedulerRunsAsync(long organizationId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_scheduler_runs");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        return await ReadRowsAsync(reader, ct);
    }

    public async Task<Dictionary<string, object?>> RunSchedulerAsync(long? organizationId, string triggerCode, string actor, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_scheduler_run");
        // A pass over every organization runs the contract dates, renewals,
        // attestation runs and the notification sweep: allow it time.
        command.CommandTimeout = 600;
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@trigger_code",    DbType.String, triggerCode, 12);
        AddParam(command, "@actor",           DbType.String, actor, 100);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return rows.Count > 0 ? rows[0] : new Dictionary<string, object?>();
    }

    public async Task<object> ListMyNotificationsAsync(long employeeId, string? filter, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_notification_mine");
        AddParam(command, "@employee_id", DbType.Int64,  employeeId);
        AddParam(command, "@filter",      DbType.String, Blank(filter), 20);
        AddParam(command, "@page_number", DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",   DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object> CountMyNotificationsAsync(long employeeId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_notification_mine_counts");
        AddParam(command, "@employee_id", DbType.Int64, employeeId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return rows.Count > 0 ? rows[0] : new Dictionary<string, object?>();
    }

    public Task<AssetLifecycleResult> MyNotificationActionAsync(long employeeId, long notificationId, AssetNotificationMineActionRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_notification_mine_action", "notificationId", command =>
        {
            AddParam(command, "@employee_id",     DbType.Int64,  employeeId);
            AddParam(command, "@notification_id", DbType.Int64,  notificationId);
            AddParam(command, "@action",          DbType.String, Blank(request.Action), 20);
            AddParam(command, "@note",            DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@actor",           DbType.String, actor, 100);
        }, ct);

    public async Task<int> ReadAllMyNotificationsAsync(long employeeId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_notification_mine_read_all");
        AddParam(command, "@employee_id", DbType.Int64, employeeId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return rows.Count > 0 && rows[0].TryGetValue("markedCount", out var n) && n is not null ? Convert.ToInt32(n) : 0;
    }

    /// <summary>The lifecycle (429) and technology (430) write procedures
    /// end with one row"""),
])

# ---------------------------------------------------------------- controller
files[A + 'Controllers/AssetConfigController.cs'] = edit(A + 'Controllers/AssetConfigController.cs', [
("""//   POST contracts/renewal-items/{itemId}/resolve   resolve an unresolved reconciliation item
""",
"""//   POST contracts/renewal-items/{itemId}/resolve   resolve an unresolved reconciliation item
//   GET  notifications/config?organizationId=       activities, recipient types, profiles, stages, matrix, roles (437)
//   POST notifications/profiles                     create / edit a profile with its stages and recipients
//   POST notifications/matrix                       replace the escalation matrix of one severity
//   GET  notifications/occurrences?organizationId=&status=&activityCode=&search=&pageNumber=&pageSize=
//   GET  notifications/occurrences/{id}?organizationId=   occurrence + stage schedule + notices
//   POST notifications/occurrences/{id}/snooze      snooze / reschedule (revised date + reason) or resume
//   GET  notifications/log?organizationId=&statusCode=&activityCode=&notificationClass=&search=&pageNumber=&pageSize=
//   POST notifications/log/{id}/delivery            a dispatcher reports SENT / FAILED
//   GET  notifications/runs?organizationId=         scheduler run log
//   POST notifications/run                          run the scheduler now for the organization
//   GET  notifications/mine?filter=&pageNumber=&pageSize=   the caller's own notices (no organization)
//   GET  notifications/mine/counts
//   POST notifications/mine/{id}/action             READ | ACKNOWLEDGE | CONFIRM
//   POST notifications/mine/read-all
"""),
("""    // 436: 54570 / 54571 / 54574 / 54588 -> 404; 54572 (open renewal), 54576 (stale), 54522 / 54525 (version in progress / stale)""",
"""    // ---------------------------------------------------------------- 437: notifications and scheduler
    [HttpGet("notifications/config")]
    public Task<IActionResult> NotificationConfig([FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.GetNotificationConfigAsync(organizationId.Value, Actor, ct), "notification config");
    }

    [HttpPost("notifications/profiles")]
    public async Task<IActionResult> SaveNotificationProfile([FromBody] AssetNotificationProfileRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveNotificationProfileAsync(request, Actor, ct), NotificationNotFound, NotificationConflict);
    }

    [HttpPost("notifications/matrix")]
    public async Task<IActionResult> SaveEscalationMatrix([FromBody] AssetEscalationMatrixRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveEscalationMatrixAsync(request, Actor, ct), NotificationNotFound, NotificationConflict);
    }

    [HttpGet("notifications/occurrences")]
    public Task<IActionResult> NotificationOccurrences([FromQuery] long? organizationId, [FromQuery] string? status, [FromQuery] string? activityCode,
        [FromQuery] string? search, [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListNotificationOccurrencesAsync(organizationId.Value, status, activityCode, search, pageNumber ?? 1, pageSize ?? 25, ct),
            "notification occurrences");
    }

    [HttpGet("notifications/occurrences/{occurrenceId:long}")]
    public Task<IActionResult> NotificationOccurrence(long occurrenceId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetNotificationOccurrenceAsync(o, occurrenceId, ct), "Notification occurrence not found.", "notification occurrence");

    [HttpPost("notifications/occurrences/{occurrenceId:long}/snooze")]
    public async Task<IActionResult> SnoozeNotificationOccurrence(long occurrenceId, [FromBody] AssetNotificationSnoozeRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SnoozeNotificationOccurrenceAsync(occurrenceId, request, ActorEmployeeId, Actor, ct), NotificationNotFound, NotificationConflict);
    }

    [HttpGet("notifications/log")]
    public Task<IActionResult> NotificationLog([FromQuery] long? organizationId, [FromQuery] string? statusCode, [FromQuery] string? activityCode,
        [FromQuery] string? notificationClass, [FromQuery] string? search, [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListNotificationLogAsync(organizationId.Value, statusCode, activityCode, notificationClass, search,
            pageNumber ?? 1, pageSize ?? 25, ct), "notification log");
    }

    [HttpPost("notifications/log/{notificationId:long}/delivery")]
    public async Task<IActionResult> ReportNotificationDelivery(long notificationId, [FromBody] AssetNotificationDeliveryRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.ReportNotificationDeliveryAsync(notificationId, request, Actor, ct), NotificationNotFound, NotificationConflict);
    }

    [HttpGet("notifications/runs")]
    public Task<IActionResult> SchedulerRuns([FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListSchedulerRunsAsync(organizationId.Value, ct), "scheduler runs");
    }

    [HttpPost("notifications/run")]
    public async Task<IActionResult> RunScheduler([FromBody] AssetSchedulerRunRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        try
        {
            var run = await service.RunSchedulerAsync(request.OrganizationId, "MANUAL", Actor, ct);
            return Ok(new { success = true, data = run });
        }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (ex.Number == 54610)
        {
            return NotFound(new { success = false, error = ex.Message, errorNumber = ex.Number });
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "AssetConfig scheduler run failed");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // The caller's own notices: addressed to the employee the Web tier stamped
    // (X-PM-Caller-Employee-Id); no organization or menu grant is involved.
    [HttpGet("notifications/mine")]
    public Task<IActionResult> MyNotifications([FromQuery] string? filter, [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (ActorEmployeeId is not { } me) return Task.FromResult(NotLinked());
        return ReadAsync(() => service.ListMyNotificationsAsync(me, filter, pageNumber ?? 1, pageSize ?? 25, ct), "my notifications");
    }

    [HttpGet("notifications/mine/counts")]
    public Task<IActionResult> MyNotificationCounts(CancellationToken ct)
    {
        if (ActorEmployeeId is not { } me) return Task.FromResult(NotLinked());
        return ReadAsync(() => service.CountMyNotificationsAsync(me, ct), "my notification counts");
    }

    [HttpPost("notifications/mine/{notificationId:long}/action")]
    public async Task<IActionResult> MyNotificationAction(long notificationId, [FromBody] AssetNotificationMineActionRequest request, CancellationToken ct)
    {
        if (ActorEmployeeId is not { } me) return NotLinked();
        if (request is null || string.IsNullOrWhiteSpace(request.Action)) return BadRequest(new { error = "action is required." });
        return ResultWritten(await service.MyNotificationActionAsync(me, notificationId, request, Actor, ct), NotificationNotFound, NotificationConflict);
    }

    [HttpPost("notifications/mine/read-all")]
    public async Task<IActionResult> ReadAllMyNotifications(CancellationToken ct)
    {
        if (ActorEmployeeId is not { } me) return NotLinked();
        try { return Ok(new { success = true, markedCount = await service.ReadAllMyNotificationsAsync(me, ct) }); }
        catch (Exception ex)
        {
            logger.LogError(ex, "AssetConfig read-all failed");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    private IActionResult NotLinked() =>
        StatusCode(403, new { error = "Your sign-in is not linked to an employee record, so no notifications can be addressed to you." });

    // 437: 54610 / 54611 / 54625 / 54630 -> 404; 54622 (active profile exists), 54623 (stale) -> 409.
    private static readonly int[] NotificationNotFound = { 54610, 54611, 54625, 54630 };
    private static readonly int[] NotificationConflict = { 54622, 54623 };

    // 436: 54570 / 54571 / 54574 / 54588 -> 404; 54572 (open renewal), 54576 (stale), 54522 / 54525 (version in progress / stale)"""),
])

# ---------------------------------------------------------------- worker
files[A + 'Services/TaskNotificationWorker.cs'] = edit(A + 'Services/TaskNotificationWorker.cs', [
("""// Wire-up (to be added by reviewer with approval — charter §5 keeps
// Program.cs off-limits without an explicit request):
//     builder.Services.AddPracticeTaskNotificationService();
//     builder.Services.AddHostedService<TaskNotificationWorker>();
// =====================================================================""",
"""// Wire-up (to be added by reviewer with approval — charter §5 keeps
// Program.cs off-limits without an explicit request):
//     builder.Services.AddPracticeTaskNotificationService();
//     builder.Services.AddHostedService<TaskNotificationWorker>();
//
// ASSET SCHEDULER (migration 437 -- registered in Program.cs on request)
// ----------------------------------------------------------------------
// The same loop also runs the Asset & Contract scheduler pass
// (IAssetConfigService.RunSchedulerAsync -> grac_practice.sp_asset_scheduler_run):
// contract effective dates, renewal occurrences, periodic attestation runs
// and the asset / contract reminders and escalations. It works in dates, so
// it runs at most every AssetSchedulerIntervalMinutes (default 60), not on
// every 5-minute tick, and it is guarded by its own try/catch so neither job
// can stop the other. The procedure takes an application lock: a second API
// instance, or "Run now" on the screen, skips instead of running twice.
// AssetSchedulerEnabled=false leaves it to SQL Agent:
//     EXEC grac_practice.sp_asset_scheduler_run;
// ====================================================================="""),
("""    /// <summary>Restrict to one organisation. NULL sweeps every organisation,
    /// which is the normal deployment.</summary>
    public long? OrganizationId { get; set; }
}""",
"""    /// <summary>Restrict to one organisation. NULL sweeps every organisation,
    /// which is the normal deployment.</summary>
    public long? OrganizationId { get; set; }

    /// <summary>437: run the Asset & Contract scheduler pass from this worker.</summary>
    public bool AssetSchedulerEnabled { get; set; } = true;

    /// <summary>437: minutes between asset scheduler passes (reminders are
    /// date-based; an hour is ample).</summary>
    public int AssetSchedulerIntervalMinutes { get; set; } = 60;
}"""),
("""        if (!options.Enabled)
        {
            logger.LogInformation(
                "TaskNotificationWorker disabled by configuration; SLA notifications must be swept manually via sp_task_notification_sweep.");
            return;
        }""",
"""        if (!options.Enabled && !options.AssetSchedulerEnabled)
        {
            logger.LogInformation(
                "TaskNotificationWorker disabled by configuration; SLA notifications must be swept manually via sp_task_notification_sweep.");
            return;
        }
        if (!options.Enabled)
            logger.LogInformation("TaskNotificationWorker: task SLA sweep disabled by configuration; only the asset scheduler runs.");

        var assetInterval = TimeSpan.FromMinutes(Math.Clamp(options.AssetSchedulerIntervalMinutes, 5, 1440));
        DateTime? lastAssetRun = null;   // 437"""),
("""            try
            {
                // A new scope per pass: ITaskNotificationService is scoped,
                // and holding one for the app's lifetime would pin a
                // connection.
                using var scope = scopeFactory.CreateScope();""",
"""            if (options.Enabled)
            try
            {
                // A new scope per pass: ITaskNotificationService is scoped,
                // and holding one for the app's lifetime would pin a
                // connection.
                using var scope = scopeFactory.CreateScope();"""),
("""                logger.LogError(ex, "TaskNotificationWorker pass failed; will retry on the next interval.");
            }
        }
        while (await SafeWaitAsync(timer, stoppingToken));""",
"""                logger.LogError(ex, "TaskNotificationWorker pass failed; will retry on the next interval.");
            }

            // 437: the Asset & Contract scheduler pass, at most every assetInterval.
            if (options.AssetSchedulerEnabled && (lastAssetRun is null || DateTime.UtcNow - lastAssetRun.Value >= assetInterval))
            {
                lastAssetRun = DateTime.UtcNow;   // also after a failure: retry on the next interval, not every tick
                try
                {
                    using var scope = scopeFactory.CreateScope();
                    var assets = scope.ServiceProvider.GetService<IAssetConfigService>();
                    if (assets is not null)
                    {
                        var run = await assets.RunSchedulerAsync(options.OrganizationId, "SCHEDULED", "scheduler", stoppingToken);
                        run.TryGetValue("result", out var result);
                        run.TryGetValue("notificationsQueued", out var queued);
                        run.TryGetValue("renewalsStarted", out var renewals);
                        run.TryGetValue("errorCount", out var errors);
                        if (Convert.ToInt32(queued ?? 0) > 0 || Convert.ToInt32(renewals ?? 0) > 0 || Convert.ToInt32(errors ?? 0) > 0)
                            logger.LogInformation(
                                "Asset scheduler pass {Result}: {Queued} notification(s), {Renewals} renewal(s) started, {Errors} error(s).",
                                result, queued, renewals, errors);
                    }
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    break;   // shutting down
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Asset scheduler pass failed; will retry on the next interval.");
                }
            }
        }
        while (await SafeWaitAsync(timer, stoppingToken));"""),
])

# ---------------------------------------------------------------- Program.cs
files[A + 'Program.cs'] = edit(A + 'Program.cs', [(
"""// Asset & Contract Management, Phase 2.1 (migration 420): field
// dictionary + versioned asset form templates. Rules live in the procs.
builder.Services.AddPracticeAssetConfigService();""",
"""// Asset & Contract Management, Phase 2.1 (migration 420): field
// dictionary + versioned asset form templates. Rules live in the procs.
builder.Services.AddPracticeAssetConfigService();
// Task Centre SLA notifications (201-203) and, in the same existing
// worker, the Asset & Contract scheduler pass (migration 437 -- reminders,
// escalations, renewal occurrences, periodic attestation runs). The worker
// was built in Task Centre v2 Phase 3 but never registered; registered on
// request (2026-10-05: "use existing background worker").
// TaskNotification:Enabled / AssetSchedulerEnabled switch either job off.
builder.Services.AddPracticeTaskNotificationService();
builder.Services.AddPracticeTaskNotificationWorker();""")])

# ---------------------------------------------------------------- API appsettings
files[A + 'appsettings.json'] = edit(A + 'appsettings.json', [
(""""asset-attestation:*", "asset-contracts:*" ],""", """"asset-attestation:*", "asset-contracts:*", "asset-notifications:*" ],"""),
("""  "EventAutoRaise": {""", """  "TaskNotification": {
    "Enabled": true,
    "IntervalSeconds": 300,
    "BatchSize": 200,
    "StartupDelaySeconds": 45,
    "AssetSchedulerEnabled": true,
    "AssetSchedulerIntervalMinutes": 60
  },
  "EventAutoRaise": {"""),
])

for p, s in files.items():
    open(p, 'w', encoding='utf-8', newline='').write(s)
print('api 437 ok', len(files))
