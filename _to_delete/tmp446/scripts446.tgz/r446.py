import re
D='/home/claude/w446/db/'
def body(fname, header):
    s=open(D+fname).read()
    i=s.index(header); j=s.index('\nGO\n', i)
    return s[i:j+1]
def ins_after(b, anchor, text, count=1):
    assert b.count(anchor)==count, (anchor, b.count(anchor))
    return b.replace(anchor, anchor+text)
def ins_before(b, anchor, text):
    assert b.count(anchor)==1, (anchor, b.count(anchor))
    return b.replace(anchor, text+anchor)

src = {}
# ---------------- register save (435)
rs = body('435_asset_contract_coverage.sql', 'CREATE OR ALTER PROCEDURE grac_practice.sp_asset_register_save')
src['rs']=rs
rs2 = ins_after(rs, """         WHERE t.editable = 1 AND t.default_value IS NOT NULL AND NOT EXISTS (SELECT 1 FROM @sub s WHERE s.field_key = t.field_key);
""", """    -- 446: the valuation method comes from the valuation configuration, not a template default (D134).
    IF @asset_id IS NULL                                                                       -- 446
        DELETE s FROM @sub s                                                                   -- 446
         WHERE s.field_key = N'asset_valuation_method'                                         -- 446
           AND NOT EXISTS (SELECT 1 FROM OPENJSON(@values_json) j                              -- 446
                            WHERE j.[key] COLLATE DATABASE_DEFAULT = N'asset_valuation_method'); -- 446
""")
rs2 = ins_before(rs2, """    -- ---------------------------------------------------------- stop or write
""", """    -- 446: Asset Valuation Method differing from the configured method is an
    -- 446: asset-level override -- set on the Valuation section, never by the form (D133).
    DECLARE @cfg_method NVARCHAR(30), @cfg_override BIT, @cfg_version INT;                       -- 446
    SELECT TOP (1) @cfg_method = valuation_method, @cfg_override = override_allowed, @cfg_version = version_no   -- 446
      FROM grac_practice.asset_valuation_config                                                 -- 446
     WHERE organization_id = @organization_id AND is_active_version = 1 ORDER BY config_id DESC; -- 446
    INSERT @issues (severity, field_key, message)                                               -- 446
    SELECT N'ERROR', e.field_key,                                                               -- 446
           CASE WHEN @cfg_method IS NULL                                                        -- 446
                THEN N'There is no Active valuation configuration; leave Asset Valuation Method empty.'   -- 446
                WHEN @cfg_override = 0                                                          -- 446
                THEN CONCAT(N'Valuation configuration version ', @cfg_version, N' uses ', @cfg_method,   -- 446
                            N' and does not permit an asset-level method override; leave the field empty.')   -- 446
                ELSE N'An asset-level method override needs an approver and a reason: use Override method in the Valuation section.' END   -- 446
      FROM @eff e                                                                               -- 446
     WHERE e.field_key = N'asset_valuation_method' AND e.submitted = 1 AND e.val IS NOT NULL    -- 446
       AND e.val <> ISNULL(@cfg_method, N'');                                                   -- 446

""")
rs2 = ins_before(rs2, """    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-register', @out_asset_id,""", """    -- 446: Asset Value (5.1.18.5.7) -- recalculated when the ratings or method changed.
    DECLARE @val_status NVARCHAR(20), @val_message NVARCHAR(500), @val_changed BIT;          -- 446
    EXEC grac_practice.sp_asset_valuation_apply                                                -- 446
         @organization_id = @organization_id, @asset_id = @out_asset_id, @mode = N'AUTO', @source = N'FORM',   -- 446
         @actor_employee_id = @actor_employee_id, @actor = @actor,                             -- 446
         @out_status = @val_status OUTPUT, @out_message = @val_message OUTPUT, @out_changed = @val_changed OUTPUT;   -- 446

""")
rs2 = ins_before(rs2, """    SET @out_result = N'SAVED';
""", """    IF @val_status IN (N'INCOMPLETE', N'INVALID', N'OUT_OF_DATE')                             -- 446
        INSERT @issues (severity, field_key, message)                                          -- 446
        VALUES (N'WARNING', NULL, LEFT(CONCAT(N'Asset Value: ', @val_message), 500));          -- 446
""")
rs2 = rs2.replace('CREATE OR ALTER PROCEDURE grac_practice.sp_asset_register_save\n', 'CREATE OR ALTER PROCEDURE grac_practice.sp_asset_register_save\n',1)
src['rs2']=rs2

# ---------------- scheduler (438)
sc = body('438_asset_activities.sql', 'CREATE OR ALTER PROCEDURE grac_practice.sp_asset_scheduler_run')
src['sc']=sc
sc2 = ins_after(sc, """            @tasks INT = 0, @t INT, @ao INT, @ac INT;                                      -- 438
""", """    DECLARE @vu INT;                                                                       -- 446
""")
sc2 = ins_before(sc2, """        -- 438: recurring asset activities (before the sweep, so new occurrences notify).
""", """        -- 446: Asset Value for ratings changed outside the asset form (5.1.18.5.7, D137).
        BEGIN TRY                                                                          -- 446
            SELECT @vu = 0, @e = 0, @et = NULL;                                            -- 446
            EXEC grac_practice.sp_asset_valuation_sync @organization_id = @org, @actor = @actor,   -- 446
                 @updated = @vu OUTPUT, @errors = @e OUTPUT, @error_text = @et OUTPUT;     -- 446
            SET @errors = @errors + ISNULL(@e, 0);                                         -- 446
            IF @et IS NOT NULL                                                             -- 446
                SET @err = LEFT(CONCAT(@err, CASE WHEN @err IS NULL THEN N'' ELSE CHAR(10) END, N'Organization ', @org, N': ', @et), 8000);   -- 446
        END TRY                                                                            -- 446
        BEGIN CATCH                                                                        -- 446
            IF XACT_STATE() <> 0 ROLLBACK;                                                 -- 446
            SET @errors = @errors + 1;                                                     -- 446
            SET @err = LEFT(CONCAT(@err, CASE WHEN @err IS NULL THEN N'' ELSE CHAR(10) END,   -- 446
                                   N'Organization ', @org, N' (asset value): ', ERROR_MESSAGE()), 8000);   -- 446
        END CATCH                                                                          -- 446

""")
src['sc2']=sc2

# ---------------- stored values (439)
sv = body('439_asset_activity_results.sql', 'CREATE OR ALTER FUNCTION grac_practice.fn_asset_stored_values')
src['sv']=sv
tail = """                        WHERE v.asset_id = @asset_id AND v.field_definition_id = d.field_definition_id);
"""
assert sv.endswith(tail), sv[-300:]
sv2 = sv[:-len(tail)] + """                        WHERE v.asset_id = @asset_id AND v.field_definition_id = d.field_definition_id)   -- 446: no semicolon
    UNION ALL                                                                                  -- 446
    -- 446: the stored VALID Asset Value (5.1.18.5.7; read-only, SYSTEM fields).
    SELECT d.field_definition_id, d.field_key, x.val                                           -- 446
      FROM grac_practice.asset_valuation_result r                                              -- 446
     CROSS APPLY (VALUES                                                                       -- 446
        (N'asset_value_score', REPLACE(RTRIM(REPLACE(REPLACE(RTRIM(REPLACE(                    -- 446
             CAST(r.asset_value_score AS NVARCHAR(40)), N'0', N' ')), N' ', N'0'), N'.', N' ')), N' ', N'.')),   -- 446
        (N'asset_value_category', CAST(r.asset_value_category AS NVARCHAR(MAX)))               -- 446
     ) AS x(field_key, val)                                                                    -- 446
      JOIN grac_practice.asset_field_definition d ON d.field_key = x.field_key AND d.storage_kind = N'SYSTEM'   -- 446
     WHERE r.asset_id = @asset_id AND r.validation_status = N'VALID' AND x.val IS NOT NULL;   -- 446
"""
src['sv2']=sv2

# ---------------- fn_asset_value_calc (422) for rollback
src['vc']=body('422_asset_valuation_config.sql','CREATE OR ALTER FUNCTION grac_practice.fn_asset_value_calc\n')
import json
for k,v in src.items(): open('/home/claude/w446/part_'+k+'.sql','w').write(v)
print({k:v.count('\n') for k,v in src.items()})
