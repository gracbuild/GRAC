# 437 -- Web proxy, screen registration, permissions, My Notifications, 274. Run from the repository root.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    return s

W = 'src/PracticeManagement.Web/'
files = {}

files[W + 'Controllers/AssetConfigController.cs'] = edit(W + 'Controllers/AssetConfigController.cs', [
("""//                                      contracts/renewals/{id}/action APPROVE / RETURN -> APPROVE (the
//                                      procedure keeps the submitter from approving), other steps EDIT (436)""",
"""//                                      contracts/renewals/{id}/action APPROVE / RETURN -> APPROVE (the
//                                      procedure keeps the submitter from approving), other steps EDIT (436)
//   notifications... (437)             asset-notifications: GET VIEW (organization required); POST
//                                      notifications/profiles ADD or EDIT, notifications/matrix EDIT,
//                                      notifications/occurrences/{id}/snooze APPROVE (the configured
//                                      roles of 9.1.1), notifications/log/{id}/delivery EDIT,
//                                      notifications/run EDIT
//   notifications/mine... (437)        the caller's own notices: session only, no organization or menu
//                                      grant -- the API addresses them to the stamped employee"""),
("""    private const string ContractArea = "asset-contracts";           // 434""",
"""    private const string ContractArea = "asset-contracts";           // 434
    private const string NotificationArea = "asset-notifications";   // 437"""),
("""        else if (lower == "contracts" || lower.StartsWith("contracts/"))       // 434""",
"""        else if (lower == "notifications/mine" || lower.StartsWith("notifications/mine/"))   // 437: own notices
            allowed = true;
        else if (lower.StartsWith("notifications/"))                            // 437
        {
            if (!long.TryParse(Request.Query["organizationId"], out var orgId) || orgId <= 0)
                return BadRequest(new { error = "organizationId is required." });
            if (!HttpContext.IsOrganizationAllowed(orgId)) return OrganizationDenied();
            allowed = Can(NotificationArea, "VIEW");
        }
        else if (lower == "contracts" || lower.StartsWith("contracts/"))       // 434"""),
("""        if (lower.StartsWith("taxonomy/"))                      // 424
            return await TaxonomyPostAsync(path!, lower, ct);""",
"""        if (lower.StartsWith("taxonomy/"))                      // 424
            return await TaxonomyPostAsync(path!, lower, ct);
        if (lower.StartsWith("notifications/mine/"))            // 437: own notices -- the API uses the stamped employee
        {
            using var mineReader = new StreamReader(Request.Body);
            var mineBody = await mineReader.ReadToEndAsync(ct);
            return await ForwardAsync(HttpMethod.Post, "api/practice/asset-config/" + path,
                string.IsNullOrWhiteSpace(mineBody) ? "{}" : mineBody, ct);
        }
        var isNotification = lower.StartsWith("notifications/");                 // 437"""),
("""        if (!isValuation && !isOptionList && !isTechCatalog && !isRegister && !isAttestation && !isContract && !lower.StartsWith("templates"))
            return NotFound(new { error = "Unknown asset configuration resource." });
        var area = isContract ? ContractArea""",
"""        if (!isValuation && !isOptionList && !isTechCatalog && !isRegister && !isAttestation && !isContract && !isNotification
            && !lower.StartsWith("templates"))
            return NotFound(new { error = "Unknown asset configuration resource." });
        var area = isNotification ? NotificationArea : isContract ? ContractArea"""),
("""            : isContract && lower == "contracts"                 // 434: new contract ADD, existing contract EDIT""",
"""            : isNotification && lower == "notifications/profiles"   // 437
            ? Can(area, "ADD", "EDIT")
            : isNotification && lower.StartsWith("notifications/occurrences/") && lower.EndsWith("/snooze")
            ? Can(area, "APPROVE")
            : isNotification && (lower == "notifications/matrix" || lower == "notifications/run"
                                 || (lower.StartsWith("notifications/log/") && lower.EndsWith("/delivery")))
            ? Can(area, "EDIT")
            : isNotification
            ? false
            : isContract && lower == "contracts"                 // 434: new contract ADD, existing contract EDIT"""),
])

files[W + 'Models/PracticeScreen.cs'] = edit(W + 'Models/PracticeScreen.cs', [(
"""        // Phase 5.1 (migration 434): contracts -- contract register,
        // immutable versions with approval, vendor contact mapping.
        new("asset-contracts",""",
"""        // Phase 6.1 (migration 437): notification profiles, escalation
        // matrix, notification occurrences and log, scheduler runs.
        new("asset-notifications","Asset Notifications","Reminders and escalations for asset and contract dates: notification profiles by activity with reminder, due and escalation stages, recipients and acknowledgement, the escalation matrix by severity, the occurrences the scheduler is tracking and every notice it recorded.","bell-concierge",["Activity","Subject","Date","Stage","Status"], AssetContractGroup),
        // Phase 5.1 (migration 434): contracts -- contract register,
        // immutable versions with approval, vendor contact mapping.
        new("asset-contracts",""")])

files[W + 'Views/Practice/Manage.cshtml'] = edit(W + 'Views/Practice/Manage.cshtml', [(
"""        // Phase 5.1 (migration 434): contracts.
        "asset-contracts"
    };""",
"""        // Phase 5.1 (migration 434): contracts.
        "asset-contracts",
        // Phase 6.1 (migration 437): asset notifications.
        "asset-notifications"
    };""")])

files[W + 'appsettings.json'] = edit(W + 'appsettings.json', [(
""""asset-attestation:*", "asset-contracts:*" ],""", """"asset-attestation:*", "asset-contracts:*", "asset-notifications:*" ],""")])

files[W + 'Views/Practice/Partials/my-notifications.cshtml'] = edit(W + 'Views/Practice/Partials/my-notifications.cshtml', [
("""    SCOPING
        Every read and write goes through /practice/api/task-notifications/me*,
        which takes the recipient from the SESSION. The browser never names
        a recipient: these messages identify overdue work and the people
        accountable for it, so one user must not be able to read another's.
*@""",
"""    SCOPING
        Every read and write goes through /practice/api/task-notifications/me*,
        which takes the recipient from the SESSION. The browser never names
        a recipient: these messages identify overdue work and the people
        accountable for it, so one user must not be able to read another's.

    ASSET & CONTRACT (migration 437)
        The second section lists the asset and contract reminders and
        escalations addressed to the user (BRD 9.1) through
        /practice/api/asset-config/notifications/mine*, scoped the same way.
        Read, action and manager acknowledgements follow the notification
        profile. Script: wwwroot/js/AssetConfig/asset-my-notifications.js
*@"""),
("""<script>
(function () {
    'use strict';
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);""",
"""@* ---------------- Asset & Contract notifications (437, BRD 9.1) ---------------- *@
<section class="pm-panel" id="amnRoot" hidden>
    <h2 class="amn-title">Asset &amp; Contract notifications</h2>
    <div class="pm-toolbar">
        <select id="amnFilter" title="Show">
            <option value="UNREAD">Unread</option>
            <option value="TO_ACKNOWLEDGE">To acknowledge</option>
            <option value="TO_CONFIRM">To confirm (manager)</option>
            <option value="READ">Read</option>
            <option value="ALL">All</option>
        </select>
        <span class="amn-counts" id="amnCounts"></span>
        <button class="pm-button icon" id="amnRefresh" type="button" title="Refresh" aria-label="Refresh">
            <i class="fa-solid fa-rotate-right" aria-hidden="true"></i>
        </button>
        <button class="pm-button" id="amnReadAll" type="button">
            <i class="fa-solid fa-check-double" aria-hidden="true"></i> Mark all read
        </button>
    </div>
    <p class="pm-message" id="amnMessage" role="status" aria-live="polite" hidden></p>
    <div class="pm-table-wrap">
        <table>
            <thead>
                <tr><th>Class</th><th>Notice</th><th>Why you</th><th>Date</th><th>Received</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody id="amnBody"><tr><td colspan="7" class="pm-empty">Loading...</td></tr></tbody>
        </table>
    </div>
    <div id="amnPager"></div>
</section>

<style>
    .amn-title { font-size: 15px; font-weight: 600; color: var(--fg-strong); margin: 0 0 8px; }
    .amn-counts { font-size: 12px; color: var(--fg-secondary); }
    .amn-note { font-size: 11px; font-weight: 400; color: var(--fg-muted); }
</style>
<script src="~/js/pm-grid.js" asp-append-version="true"></script>
<script src="~/js/AssetConfig/asset-my-notifications.js" asp-append-version="true"></script>

<script>
(function () {
    'use strict';
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);"""),
])

D = 'database/274_menu_master_seed.sql'
files[D] = edit(D, [
("""--   434 -- 'asset-contracts' (358, Contracts) under
--     'nav-asset-contract'.
""",
"""--   434 -- 'asset-contracts' (358, Contracts) under
--     'nav-asset-contract'.
--   437 -- 'asset-notifications' (359, Asset Notifications) under
--     'nav-asset-contract'.
"""),
("""    (N'asset-contracts'               , N'Contracts'                         , N'Practice/Index/asset-contracts'             ,  358, N'file-contract'         , N'Asset & Contract'           , N'Active')   -- 434""",
"""    (N'asset-contracts'               , N'Contracts'                         , N'Practice/Index/asset-contracts'             ,  358, N'file-contract'         , N'Asset & Contract'           , N'Active'),  -- 434
    (N'asset-notifications'           , N'Asset Notifications'               , N'Practice/Index/asset-notifications'         ,  359, N'bell-concierge'        , N'Asset & Contract'           , N'Active')   -- 437"""),
("""    (N'asset-contracts'               , N'nav-asset-contract')   -- 434""",
"""    (N'asset-contracts'               , N'nav-asset-contract'),  -- 434
    (N'asset-notifications'           , N'nav-asset-contract')   -- 437"""),
])

for p, s in files.items():
    open(p, 'w', encoding='utf-8', newline='').write(s)
print('web 437 ok', len(files))
