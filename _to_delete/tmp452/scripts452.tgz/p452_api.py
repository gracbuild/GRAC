import sys
R = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w452/new'
A = R + '/src/PracticeManagement.Api/'
def edit(path, old, new, count=1):
    s = open(path).read(); assert s.count(old) == count, (path, old[:80], s.count(old)); open(path, 'w').write(s.replace(old, new))

# ---------------------------------------------------------------- models
edit(A + 'Models/AssetConfigModels.cs', """/// <summary>Take a snapshot now (a new version of today only when the results changed).</summary>
public sealed record AssetGovernanceSnapshotRequest(long OrganizationId);
""", """/// <summary>Take a snapshot now (a new version of today only when the results changed).</summary>
public sealed record AssetGovernanceSnapshotRequest(long OrganizationId);

// ---------------------------------------------------------------------
// Asset & Contract report catalogue and exports (migration 452)
// ---------------------------------------------------------------------
/// <summary>Filters of one report run or export. The report definition decides which filters apply; the others are
/// ignored by sp_asset_report_run. Days empty = the report default.</summary>
public sealed record AssetReportRunRequest(long OrganizationId, string? ReportCode, string? Search, string? Status, int? AssetTypeId,
    DateTime? DateFrom, DateTime? DateTo, int? Days);

/// <summary>Organization setting of one report: enabled, classification (not below the default; empty = default),
/// export policy ALLOWED | APPROVER | DISABLED (empty = APPROVER for RESTRICTED, else ALLOWED).</summary>
public sealed record AssetReportSettingRequest(long OrganizationId, string? ReportCode, bool? IsEnabled, string? Classification,
    string? ExportPolicy);

/// <summary>Outcome of a report run or export: the data, or the refusal (53100-53119) of the procedures.</summary>
public sealed record AssetReportResult(bool Success, object? Data, int? ErrorNumber, string? Error);
""")

# ---------------------------------------------------------------- service
S = A + 'Services/AssetConfigService.cs'
edit(S, """//   sp_asset_split_* (445 -- split events and allocation; actions through sp_asset_merge_action)
""", """//   sp_asset_split_* (445 -- split events and allocation; actions through sp_asset_merge_action)
//   sp_asset_report_* (452 -- report catalogue, report runs, export log, organization report settings)
""")
edit(S, """    Task<AssetLifecycleResult> TakeGovernanceSnapshotAsync(AssetGovernanceSnapshotRequest request, string actor, CancellationToken ct);
}
""", """    Task<AssetLifecycleResult> TakeGovernanceSnapshotAsync(AssetGovernanceSnapshotRequest request, string actor, CancellationToken ct);

    // 452 -- Report catalogue and exports. allowedAreas: the screens the caller may VIEW (Web tier, from the session).
    Task<object?> GetReportCatalogueAsync(long organizationId, string? allowedAreas, bool canApprove, CancellationToken ct);
    Task<AssetReportResult> RunReportAsync(AssetReportRunRequest request, string? allowedAreas, bool canApprove, int pageNumber, int pageSize,
        CancellationToken ct);
    Task<AssetReportResult> ExportReportAsync(AssetReportRunRequest request, string? allowedAreas, bool canApprove, string actor,
        long? actorEmployeeId, CancellationToken ct);
    Task<object?> ListReportExportsAsync(long organizationId, string? allowedAreas, string? reportCode, int pageNumber, int pageSize,
        CancellationToken ct);
    Task<AssetLifecycleResult> SaveReportSettingAsync(AssetReportSettingRequest request, string? allowedAreas, string actor, CancellationToken ct);
}
""")
edit(S, """    public async Task<object> GetBusinessServiceTreeAsync(""", """    // ----------------------------------------------------------------
    // 452 -- Report catalogue and exports (BRD 13.4 / 13.4.1)
    // ----------------------------------------------------------------
    /// <summary>Rows an export may carry; one more is read to detect an export that is too large (53107).</summary>
    private const int ReportExportRowLimit = 50000;

    public async Task<object?> GetReportCatalogueAsync(long organizationId, string? allowedAreas, bool canApprove, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_report_catalogue");
            AddParam(command, "@organization_id", DbType.Int64,   organizationId);
            AddParam(command, "@allowed_areas",   DbType.String,  Blank(allowedAreas), 2000);
            AddParam(command, "@can_approve",     DbType.Boolean, canApprove);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var empty = new List<Dictionary<string, object?>>();
            var reports       = await ReadRowsAsync(reader, ct);
            var assetStatuses = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var assetTypes    = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            return new { reports, assetStatuses, assetTypes, exportRowLimit = ReportExportRowLimit };
        }
        catch (SqlException ex) when (ex.Number == 53100) { return null; }
    }

    public async Task<AssetReportResult> RunReportAsync(AssetReportRunRequest request, string? allowedAreas, bool canApprove, int pageNumber,
        int pageSize, CancellationToken ct)
    {
        try
        {
            var (columns, rows) = await ExecuteReportAsync(request, allowedAreas, canApprove, false, pageNumber, pageSize, ct);
            return new AssetReportResult(true, new { columns, rows, totalRows = TotalRows(rows), page = pageNumber, pageSize }, null, null);
        }
        catch (SqlException ex) when (ex.Number is >= 53100 and <= 53119)
        {
            logger.LogWarning(ex, "AssetConfigService report {Report} refused ({Number})", request.ReportCode, ex.Number);
            return new AssetReportResult(false, null, ex.Number, ex.Message);
        }
    }

    /// <summary>13.4.1: the rows are read with the export checks (policy, approver), the export is recorded (report,
    /// version, organization, filters, columns, row count, classification, user, time) and only then returned with the
    /// recorded heading, which the page writes at the top of the file.</summary>
    public async Task<AssetReportResult> ExportReportAsync(AssetReportRunRequest request, string? allowedAreas, bool canApprove, string actor,
        long? actorEmployeeId, CancellationToken ct)
    {
        try
        {
            var (columns, rows) = await ExecuteReportAsync(request, allowedAreas, canApprove, true, 1, ReportExportRowLimit + 1, ct);
            if (rows.Count > ReportExportRowLimit)
                return new AssetReportResult(false, null, 53107,
                    $"The export has more than {ReportExportRowLimit} rows. Narrow the filters and export again.");
            foreach (var row in rows) row.Remove("totalRows");
            var filters = System.Text.Json.JsonSerializer.Serialize(new
            {
                search = Blank(request.Search), status = Blank(request.Status), assetTypeId = request.AssetTypeId,
                dateFrom = request.DateFrom?.ToString("yyyy-MM-dd"), dateTo = request.DateTo?.ToString("yyyy-MM-dd"), days = request.Days
            });
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_report_export_log");
            AddParam(command, "@organization_id",   DbType.Int64,  request.OrganizationId);
            AddParam(command, "@report_code",       DbType.String, Blank(request.ReportCode), 40);
            AddParam(command, "@filters_json",      DbType.String, filters, -1);
            AddParam(command, "@columns_json",      DbType.String, System.Text.Json.JsonSerializer.Serialize(columns), -1);
            AddParam(command, "@row_count",         DbType.Int32,  rows.Count);
            AddParam(command, "@actor",             DbType.String, actor, 100);
            AddParam(command, "@actor_employee_id", DbType.Int64,  actorEmployeeId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var heading = await ReadRowsAsync(reader, ct);
            return new AssetReportResult(true, new { export = heading.Count > 0 ? heading[0] : null, columns, rows }, null, null);
        }
        catch (SqlException ex) when (ex.Number is >= 53100 and <= 53119)
        {
            logger.LogWarning(ex, "AssetConfigService report export {Report} refused ({Number})", request.ReportCode, ex.Number);
            return new AssetReportResult(false, null, ex.Number, ex.Message);
        }
    }

    public async Task<object?> ListReportExportsAsync(long organizationId, string? allowedAreas, string? reportCode, int pageNumber, int pageSize,
        CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_report_exports");
            AddParam(command, "@organization_id", DbType.Int64,  organizationId);
            AddParam(command, "@allowed_areas",   DbType.String, Blank(allowedAreas), 2000);
            AddParam(command, "@report_code",     DbType.String, Blank(reportCode), 40);
            AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
            AddParam(command, "@page_size",       DbType.Int32,  pageSize);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var rows = await ReadRowsAsync(reader, ct);
            return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
        }
        catch (SqlException ex) when (ex.Number == 53100) { return null; }
    }

    public Task<AssetLifecycleResult> SaveReportSettingAsync(AssetReportSettingRequest request, string? allowedAreas, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_report_org_setting_save", "organizationId", command =>
        {
            AddParam(command, "@organization_id", DbType.Int64,   request.OrganizationId);
            AddParam(command, "@report_code",     DbType.String,  Blank(request.ReportCode), 40);
            AddParam(command, "@allowed_areas",   DbType.String,  Blank(allowedAreas), 2000);
            AddParam(command, "@is_enabled",      DbType.Boolean, request.IsEnabled ?? true);
            AddParam(command, "@classification",  DbType.String,  Blank(request.Classification), 20);
            AddParam(command, "@export_policy",   DbType.String,  Blank(request.ExportPolicy), 10);
            AddParam(command, "@actor",           DbType.String,  actor, 100);
        }, ct);

    /// <summary>Runs sp_asset_report_run and reads the one result set of the report: the column names (camelCase,
    /// without TotalRows -- also when there are no rows) and the rows.</summary>
    private async Task<(string[] Columns, List<Dictionary<string, object?>> Rows)> ExecuteReportAsync(AssetReportRunRequest request,
        string? allowedAreas, bool canApprove, bool forExport, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_report_run");
        command.CommandTimeout = 300;   // whole-organization reports (privacy, technology, coverage)
        AddParam(command, "@organization_id", DbType.Int64,   request.OrganizationId);
        AddParam(command, "@report_code",     DbType.String,  Blank(request.ReportCode), 40);
        AddParam(command, "@allowed_areas",   DbType.String,  Blank(allowedAreas), 2000);
        AddParam(command, "@can_approve",     DbType.Boolean, canApprove);
        AddParam(command, "@for_export",      DbType.Boolean, forExport);
        AddParam(command, "@search",          DbType.String,  Blank(request.Search), 200);
        AddParam(command, "@status",          DbType.String,  Blank(request.Status), 60);
        AddParam(command, "@asset_type_id",   DbType.Int32,   request.AssetTypeId);
        AddParam(command, "@date_from",       DbType.Date,    request.DateFrom?.Date);
        AddParam(command, "@date_to",         DbType.Date,    request.DateTo?.Date);
        AddParam(command, "@days",            DbType.Int32,   request.Days);
        AddParam(command, "@page_number",     DbType.Int32,   pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,   pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var columns = Enumerable.Range(0, reader.FieldCount).Select(i => CamelCase(reader.GetName(i)))
                                .Where(n => n != "totalRows").ToArray();
        var rows = await ReadRowsAsync(reader, ct);
        return (columns, rows);
    }

    public async Task<object> GetBusinessServiceTreeAsync(""")

# ---------------------------------------------------------------- controller
C = A + 'Controllers/AssetConfigController.cs'
edit(C, """//   POST governance/snapshot                         take a snapshot now
""", """//   POST governance/snapshot                         take a snapshot now
//   GET  reports?organizationId=                     report catalogue of the screens the caller may view (452)
//   GET  reports/{code}/run?organizationId=&search=&status=&assetTypeId=&dateFrom=&dateTo=&days=&pageNumber=&pageSize=
//                                                    one page of a report (columns, rows, totalRows)
//   POST reports/{code}/export                       governed CSV export: checks the export policy, records the export,
//                                                    returns the recorded heading, the columns and every row (max 50000)
//   GET  reports/exports?organizationId=&reportCode=&pageNumber=&pageSize=   export history
//   POST reports/settings                            organization setting of a report (enabled, classification, policy)
""")
edit(C, """// which is the only source of the actor here.
""", """// which is the only source of the actor here. For reports (452) it also
// stamps X-PM-Caller-Report-Areas (the report screens the session may
// VIEW) and X-PM-Caller-Report-Approve (Asset Reports APPROVE); the
// procedures check every report against them.
""")
edit(C, """    // 448: 53050 (organization), 53051 (asset), 53052 (requirement), 53054 (asset type), 53056 (exception), 53064 (review)""",
"""    // ---------------------------------------------------------------- 452: report catalogue and exports
    private const string CallerReportAreasHeader = "X-PM-Caller-Report-Areas";
    private const string CallerReportApproveHeader = "X-PM-Caller-Report-Approve";

    private string? ReportAreas => Request.Headers[CallerReportAreasHeader].ToString() is { Length: > 0 } areas ? areas : null;

    private bool ReportApprove => Request.Headers[CallerReportApproveHeader].ToString() == "1";

    [HttpGet("reports")]
    public Task<IActionResult> Reports([FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetReportCatalogueAsync(o, ReportAreas, ReportApprove, ct), "Organization not found.",
            "report catalogue");

    [HttpGet("reports/exports")]
    public Task<IActionResult> ReportExports([FromQuery] long? organizationId, [FromQuery] string? reportCode, [FromQuery] int? pageNumber,
        [FromQuery] int? pageSize, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.ListReportExportsAsync(o, ReportAreas, reportCode, pageNumber ?? 1, pageSize ?? 25, ct),
            "Organization not found.", "report exports");

    [HttpGet("reports/{code}/run")]
    public async Task<IActionResult> RunReport(string code, [FromQuery] long? organizationId, [FromQuery] string? search,
        [FromQuery] string? status, [FromQuery] int? assetTypeId, [FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo,
        [FromQuery] int? days, [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0) return BadRequest(new { error = "organizationId is required." });
        var request = new AssetReportRunRequest(organizationId.Value, code, search, status, assetTypeId, dateFrom, dateTo, days);
        return ReportResult(await service.RunReportAsync(request, ReportAreas, ReportApprove, pageNumber ?? 1, pageSize ?? 25, ct));
    }

    [HttpPost("reports/{code}/export")]
    public async Task<IActionResult> ExportReport(string code, [FromBody] AssetReportRunRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ReportResult(await service.ExportReportAsync(request with { ReportCode = code }, ReportAreas, ReportApprove, Actor,
            ActorEmployeeId, ct));
    }

    [HttpPost("reports/settings")]
    public async Task<IActionResult> SaveReportSetting([FromBody] AssetReportSettingRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.ReportCode)) return BadRequest(new { error = "reportCode is required." });
        return ResultWritten(await service.SaveReportSettingAsync(request, ReportAreas, Actor, ct), ReportNotFound, Array.Empty<int>());
    }

    // 452: 53100 (organization), 53101 (report) -> 404; 53103 (screen not permitted), 53105 (export policy) -> 403;
    //      53102 (not available), 53104 (disabled) -> 409; 53106 / 53107 / 53108 / 53109 (filters, size, settings) -> 400.
    private static readonly int[] ReportNotFound = { 53100, 53101 };

    private IActionResult ReportResult(AssetReportResult r)
    {
        if (r.Success) return Ok(new { data = r.Data });
        var body = new { success = false, error = r.Error, errorNumber = r.ErrorNumber };
        return r.ErrorNumber switch
        {
            53100 or 53101 => NotFound(body),
            53103 or 53105 => StatusCode(403, body),
            53102 or 53104 => Conflict(body),
            _ => BadRequest(body)
        };
    }

    // 448: 53050 (organization), 53051 (asset), 53052 (requirement), 53054 (asset type), 53056 (exception), 53064 (review)""")
print('api patched')
