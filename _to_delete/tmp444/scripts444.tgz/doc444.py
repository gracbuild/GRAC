import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (a[:60], s.count(a))
    s = s.replace(a, b)

rep("the stale-asset review leading to a decommission request (`443`).",
    "the stale-asset review leading to a decommission request (`443`), Phase 7.4b asset merge -- preview, impact, approval, execution with per-object outcomes, aliases and recovery (`444`).")
rep("| 7.4b | Asset merge (5.6.3, 19.4): survivor and duplicates, preview (fields, sources, history, relationships, attachments, tasks), impact analysis (services, contracts, risks, attestations, tasks), validation, approval with two-person control for critical CIs, execution with per-object outcomes, aliases, recovery event | | 7.4a |",
    "| 7.4b **(done)** | Asset merge (5.6.3, 19.4): survivor and 1-10 duplicates, reason, field choices; impact per asset, field comparison, plan (move / end / resolve / keep) and blockers; Draft -> Pending approval -> Approved (another person; two for critical CIs) -> Executed with per-object outcomes, aliases searchable in the Asset Register, duplicates archived; Recover; Merges tab and Merge from a Potential duplicate | 444 | 7.4a |")
rep("""| D33 | **Cancel keeps the asset status** (433)""",
"""| D115 | **Merge event** (444): survivor + 1-10 duplicates of one organization (in use, not merged, not in another open merge), reason, field choices. Draft (save / change) -> Submit (reason, no blockers; plan counts kept) -> Pending approval -> Approve / Reject -> Approved -> Execute -> Executed -> Recover -> Recovered; Cancel from Draft, Pending approval or Approved; reject, cancel and recover need a note. Nothing is merged automatically (Potential duplicate only opens a prepared merge). | BRD 5.6.3, 19.4 initiation, 19.5. | Yes. |
| D116 | **Blockers** -- open items of a duplicate are never moved or closed silently, they are finished first: pending lifecycle change, open workflow case, open attestation, open verification exception, pending technology exception, open stale review, an open activity of a template the survivor also has open, an active restrictive review the survivor also has; plus invalid assets. Checked at Submit and again at Execute. | BRD 19.4 "open workflow items explicitly reassigned or linked, not silently closed"; validation. | Yes. |
| D117 | **Field values**: the survivor keeps its values; an empty survivor value is filled from the first duplicate (in the order chosen) holding one; a field choice takes a named duplicate value instead. Only user-entered value fields (not system / calculated, not the column fields name, owner, location, criticality, dates). | BRD 19.4 preview "field differences"; validation "resolve protected conflicts". | Yes. |
| D118 | **Aliases**: the duplicate name, its ID (#n) and its asset tag, serial number, finance asset number, hostname, MAC and cloud resource ID (where they differ from the survivor) are kept on the survivor; the Asset Register search (`sp_asset_register_list`, re-issued) finds them. Discovery links move, so the source record ID keeps matching the survivor. | BRD 19.4 "aliases and external identifiers remain searchable". | Yes. |
| D119 | **Merged record**: archived (status Archived) through system transition rules of role ASSET_MERGE (every status -> Archived, and back for recovery). They have no 429 gate, so they are not on the Lifecycle tab, not in sp_asset_lifecycle_transition and not in the matrix; no decommission event is raised; the record becomes Inactive with `merged_into_asset_id` = survivor. Its history (lifecycle changes, installations, custody, attestations, results, renewals, notifications, retired relationships) stays on it. The 429 verification checks 429-a / 429-b now consider role-free rules only (edited in 429). | BRD 5.6.3 "preserve surviving ID ... history"; 5.4.3 user moves out of Archived stay forbidden. | Yes. |
| D120 | **Approval**: asset-discovery APPROVE; the requester cannot approve or reject; a critical merge (survivor or a duplicate with criticality Critical, or a current critical relationship relying on it) needs two different approvers. Execute needs asset-discovery EDIT and asset-register EDIT; Recover asset-discovery APPROVE and asset-register EDIT. | BRD 19.4 "configured approver; two-person control for critical CIs". | Yes. |
| D121 | **Plan / execution**: current relationships of a duplicate move to the survivor, or end (retired) when they would join the survivor to itself or duplicate a current survivor relationship (history action MERGE_MOVE / MERGE_END); discovery links move; per-source values move unless the survivor holds one from that source; open reconciliation exceptions move, a duplicate review of the pair is closed as Merged; coverage lines of draft / in-review / approved / active contract versions move unless the survivor is covered for that type (others stay); open activities and active restrictive reviews move (their tasks follow); risk mappings (category Asset) move unless the risk already maps the survivor, risk links move; practice dependency resolutions (category Asset) move unless the survivor is already resolved there. One outcome row per object with before / after values. | BRD 5.6.3 Merge, 19.4 execution "per-object outcomes and recoverable state". | Yes. |
| D122 | **Recovery**: newest outcome first; a row is restored only when the object is still as the merge left it (and restoring breaks no uniqueness) -- otherwise its recovery note says why; the duplicate returns to its earlier status and record state; aliases are deactivated. The event and its rows stay. | BRD 19.4 recovery "where technically possible"; "never erases the original event". | Yes. |
| D123 | **Error numbers 52900-52914** -- the 547xx and 548xx ranges are taken (548xx by 425-427). | -- | Yes. |
| D124 | **Not in 7.4b**: split (7.4c); bulk merge jobs; merges across organizations; moving history rows; attachments (no asset attachment store exists yet). | BRD 9 bulk, 19.4. | Yes. |
| D33 | **Cancel keeps the asset status** (433)""")
rep("""### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""",
"""### Asset merge (444)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `discovery/merges?organizationId=&status=&search=&pageNumber=&pageSize=` | Merges (status empty = open; ALL; one status) | `sp_asset_merge_events` |
| GET | `discovery/merges/{id}?organizationId=` | `{merge, assets, approvals, blockers, plan, outcomes, fields, impact}` | `sp_asset_merge_get` (`fn_asset_merge_blockers`, `fn_asset_merge_plan`, `fn_asset_merge_fields`, `fn_asset_merge_impact`) |
| POST | `discovery/merges` | `{organizationId, eventId?, survivorAssetId, duplicateAssetIds: [..], reason?, fieldChoices?: {fieldKey: assetId}, expectedRecordVersion?}` -> CREATED / SAVED | `sp_asset_merge_save` |
| POST | `discovery/merges/{id}/action` | `{organizationId, action: SUBMIT \\| CANCEL \\| APPROVE \\| REJECT \\| EXECUTE \\| RECOVER, note?, expectedRecordVersion?}` -> new status (APPROVE may return FIRST_APPROVAL) | `sp_asset_merge_action` (-> `sp_asset_merge_execute_one`, `sp_asset_merge_recover`) |

Proxy: GETs asset-discovery VIEW; draft save, Submit, Cancel EDIT; Approve / Reject APPROVE; Execute EDIT + asset-register EDIT; Recover APPROVE + asset-register EDIT. Errors `52900-52914`; 52900 / 52901 / 52902 -> 404, 52903 -> 409.

### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""")
rep("""## 8. Verification (static -- no compiler or database on this machine)""",
"""### Phase 7.4b files (444)
| Layer | File | Change |
|---|---|---|
| DB | `database/444_asset_merge.sql` (+ rollback restoring the 429 body) | `merged_into_asset_id`; `asset_merge_split_event / _member / _approval / _object`, `asset_alias`; ASSET_MERGE transition rules; blockers, plan, fields, impact, critical functions; save, execute, recover, action, readers. Re-issued: `sp_asset_register_list` (alias search). |
| DB | `database/429_asset_lifecycle_transitions.sql` | Verification 429-a / 429-b limited to role-free rules (D119); no object changed. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 4 routes; merge save / action requests. |
| Web | `Controllers/AssetConfigController.cs` | Merge permissions. |
| Web | `Partials/asset-discovery.cshtml`, `js/AssetConfig/asset-discovery.js` | Merges tab and merge window (assets, impact, fields with choices, plan / outcomes, blockers, approvals, actions); Merge on a Potential duplicate. |

## 8. Verification (static -- no compiler or database on this machine)""")
s = s.rstrip('\n') + """

444 got the same sweep (clean), the semicolon-before-ELSE scan (four inline IF / ELSE forms of the recovery procedure rewritten with BEGIN / END before delivery, and declarations moved out of its loop), OPENJSON keys compared with `COLLATE DATABASE_DEFAULT`, the parameter check of every internal and external EXEC (`sp_asset_relationship_history_add`, `sp_pm_state_transition` against their signatures), a diff of the re-issued `sp_asset_register_list` against its 429 source (only lines marked `-- 444`), the C#-to-procedure parameter and string-size cross-check for the 4 bound procedures, the JS-to-alias and HTML-id / duplicate-id checks, `node --check`, brace / parenthesis / bracket balance of the four edited C# files and the ASCII check. Its verification block checks the tables, the functions and six procedures, the merge rules (count, no gate), that no role-free rule leaves Disposed / Archived, the register search and that the plan and blocker functions run. Not compiled or executed. Not yet done: split (7.4c); Phase 8.
"""
open(p, 'w', encoding='utf-8', newline='').write(s)
print('doc ok')
