W='/home/claude/w450/'
p=lambda k: open(W+'part_'+k+'.sql').read()
d = """-- =====================================================================
-- 8. Re-issued body (450 lines marked; otherwise unchanged)
-- =====================================================================
-- 448 body: one governance snapshot per organization per day.
""" + p('sc2') + """GO
PRINT '450: sp_asset_scheduler_run re-issued.';
GO
"""
open(W+'450_d.sql','w').write(d)
s=''.join(open(W+f).read() for f in ['450_a.sql','450_b.sql','450_c.sql','450_d.sql','450_m.sql','450_e.sql'])
open(W+'450.sql','w').write(s)
rb = """-- =====================================================================
-- 450 ROLLBACK  Asset governance KPIs
-- =====================================================================
-- Restores sp_asset_scheduler_run (448 body); drops the 450 procedures,
-- functions and tables (settings, relationship requirements and every
-- snapshot are lost) and the Asset Governance menu row and its grants.
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO
""" + p('sc') + """GO
PRINT '450 rollback: 448 scheduler body restored.';
GO
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_governance_relationship_rule_save;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_governance_org_setting_save;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_governance_setting_save;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_governance_settings;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_governance_snapshots;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_governance_items;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_governance_get;
DROP PROCEDURE IF EXISTS grac_practice.sp_asset_governance_snapshot_take;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_governance_items;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_governance_assets;
DROP FUNCTION IF EXISTS grac_practice.fn_asset_governance_effective;
GO
DROP TABLE IF EXISTS grac_practice.asset_governance_snapshot_item;
DROP TABLE IF EXISTS grac_practice.asset_governance_snapshot_kpi;
DROP TABLE IF EXISTS grac_practice.asset_governance_snapshot;
DROP TABLE IF EXISTS grac_practice.asset_governance_relationship_rule;
DROP TABLE IF EXISTS grac_practice.asset_governance_org_setting;
DROP TABLE IF EXISTS grac_practice.asset_governance_setting;
DROP TABLE IF EXISTS grac_practice.asset_governance_kpi;
GO
DELETE p
  FROM grac_practice.organization_role_menu_permission p
  JOIN grac_practice.menu_master m ON m.menu_id = p.menu_id
 WHERE m.menu_key = N'asset-governance';
DELETE FROM grac_practice.menu_master WHERE menu_key = N'asset-governance';
GO
PRINT '450 rollback: governance objects and menu dropped.';
GO
SELECT '450 rollback' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_governance_kpi','U') IS NULL
             AND OBJECT_ID('grac_practice.fn_asset_governance_items') IS NULL
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) NOT LIKE '%sp_asset_governance_snapshot_take%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) LIKE '%sp_asset_privacy_sync%'
             AND NOT EXISTS (SELECT 1 FROM grac_practice.menu_master WHERE menu_key = N'asset-governance')
            THEN 'PASS' ELSE 'FAIL' END AS Result;
GO
"""
open(W+'450_rb.sql','w').write(rb)
print('assembled', s.count('\n'), rb.count('\n'))
