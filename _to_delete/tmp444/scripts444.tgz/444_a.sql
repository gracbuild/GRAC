-- =====================================================================
-- 444  Asset merge: survivor and duplicates, preview, impact analysis,
--      validation, approval (two-person for critical CIs), execution with
--      per-object outcomes, aliases, recovery
--      (Asset & Contract Management, Phase 7 increment 4b)
--
-- REQUEST
-- -------
--   BRD v1.7 5.6.3 Merge -- "preserve surviving ID, aliases, source links,
--   history, relationships, evidence and audit"; Potential Duplicate -- "do
--   not merge automatically unless explicitly approved". 19.4 Merge and
--   Split Approval Governance: initiation (survivor and duplicates), preview
--   (field, source, history, relationship, attachment and task
--   differences), impact analysis (services, contracts, risks,
--   attestations, tasks, reports, integrations), validation (protected
--   conflicts resolved, survivor meets mandatory rules), approval
--   (configured approver; two-person control for critical CIs), execution
--   (per-object outcomes, recoverable state), recovery (restorative event
--   where technically possible), audit (before / after IDs, values, actor,
--   reason, approval); open workflow items explicitly reassigned or linked,
--   never silently closed; aliases and external identifiers stay
--   searchable; recovery never erases the original event. 19.5 confidence
--   alone never authorizes a merge. Plan: docs/asset-contract-management.md
--   (Phase 7.4b, D115-D124).
--
-- WHAT THIS DOES
-- --------------
--   1. Merge events (asset_merge_split_event, kind MERGE; split reuses them
--      in 7.4c): survivor + 1-10 duplicates, reason, field choices; Draft ->
--      Pending approval -> Approved -> Executed (-> Recovered), or Rejected /
--      Cancelled. Members, approvals, per-object outcomes.
--   2. Plan (fn_asset_merge_plan) -- the one source for preview and
--      execution: relationships, discovery links, per-source values, open
--      reconciliation exceptions, contract coverage, open activity
--      occurrences, active restrictive-use reviews, risk mappings, risk
--      links, practice dependency resolutions -> MOVE to the survivor, END
--      (would duplicate a survivor relationship or join the survivor to
--      itself), RESOLVE (duplicate review of the pair) or KEEP (stays with the
--      merged record). Blockers (fn_asset_merge_blockers): open items that
--      cannot move silently -- pending lifecycle change, open workflow case,
--      open attestation, open verification exception, pending technology
--      exception, open stale review, conflicting open occurrence or
--      restrictive review, invalid assets.
--   3. Field values: the survivor keeps its values; empty survivor values
--      are filled from the first duplicate holding one; a field choice takes
--      a duplicate value instead (user-entered value fields only).
--   4. Execution: per duplicate, the plan is applied with one outcome row per
--      object (before / after); aliases (name, ID, asset tag, serial, finance
--      number, hostname, MAC, cloud ID) are kept searchable on the survivor;
--      the duplicate is archived (status Archived through a system merge
--      rule, record Inactive, merged_into_asset_id = survivor). History rows
--      (lifecycle, installations, custody, attestations, results, renewals,
--      notifications, retired relationships) stay with the merged record.
--   5. Recovery: every outcome row is reversed where still possible (newest
--      first); the event becomes Recovered and keeps its rows.
--   6. Asset Register search also finds aliases (sp_asset_register_list).
--
-- NOT DONE HERE: split (7.4c); bulk merge jobs; merging across
--   organizations; moving history rows.
--
-- ERROR NUMBERS: 52900-52914 (the 547xx / 548xx asset ranges are full)
--   52900 organization not found          52901 asset not found
--   52902 merge event not found           52903 changed by someone else
--   52904 survivor / duplicates invalid   52905 asset in another open event
--   52906 reason required                 52907 status does not allow it
--   52908 blockers                        52909 approver not allowed
--   52910 note required                   52911 action not valid
--   52912 field choice invalid            52913 1-10 duplicates
--   52914 asset is merged
--
-- ALSO EDITED: sp_asset_register_list (429) re-issued (alias search); API
--   (AssetConfig service / controller / models), Web proxy,
--   asset-discovery.cshtml / .js (Merges tab, merge from a duplicate
--   review), docs.
-- DEPENDS ON: 002, 035, 265, 428-433, 435, 438-443.
-- Rollback: 444_asset_merge_rollback.sql (restores the 429 body of
--   sp_asset_register_list; merged assets stay merged -- recover them first).
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.asset_stale_review','U') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_relationship_history_add','P') IS NULL
   OR COL_LENGTH('grac_practice.asset_relationship','service_role') IS NULL
   OR OBJECT_ID('grac_practice.asset_discovery_link','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_attribute_source','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_reconciliation_exception','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_contract_coverage','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_activity_occurrence','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_restrictive_review','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_attestation','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_verification_exception','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_technology_exception','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_workflow_case','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_lifecycle_change','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_lifecycle_status_phase','U') IS NULL
   OR OBJECT_ID('grac_practice.risk_dependency_map','U') IS NULL
   OR COL_LENGTH('grac_practice.risk_register','linked_asset_id') IS NULL
   OR OBJECT_ID('grac_practice.practice_dependency_resolution','U') IS NULL
   OR OBJECT_ID('grac_practice.sp_pm_state_transition','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_register_list','P') IS NULL
   OR COL_LENGTH('grac_practice.organization_dependency_asset','current_status_id') IS NULL
   OR COL_LENGTH('grac_practice.organization_dependency_asset','lifecycle_status') IS NULL
   OR COL_LENGTH('grac_practice.organization_dependency_asset','template_id') IS NULL
BEGIN
    RAISERROR('ABORT (444): run 265, 428-433, 435, 438-443 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Merged record pointer, events, members, approvals, outcomes, aliases
-- =====================================================================
IF COL_LENGTH('grac_practice.organization_dependency_asset','merged_into_asset_id') IS NULL
BEGIN
    ALTER TABLE grac_practice.organization_dependency_asset
        ADD merged_into_asset_id BIGINT NULL
            CONSTRAINT fk_pm_org_dep_asset_merged REFERENCES grac_practice.organization_dependency_asset(asset_id);
    PRINT '444: organization_dependency_asset.merged_into_asset_id added.';
END
GO

IF OBJECT_ID('grac_practice.asset_merge_split_event','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_merge_split_event (
        event_id                 BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_amse PRIMARY KEY,
        organization_id          BIGINT         NOT NULL
            CONSTRAINT fk_pm_amse_org REFERENCES grac_practice.organization(organization_id),
        event_kind               NVARCHAR(10)   NOT NULL CONSTRAINT ck_pm_amse_kind CHECK (event_kind IN (N'MERGE', N'SPLIT')),
        survivor_asset_id        BIGINT         NOT NULL
            CONSTRAINT fk_pm_amse_survivor REFERENCES grac_practice.organization_dependency_asset(asset_id),
        status                   NVARCHAR(20)   NOT NULL
            CONSTRAINT ck_pm_amse_status CHECK (status IN (N'DRAFT', N'PENDING_APPROVAL', N'APPROVED', N'EXECUTED', N'RECOVERED',
                                                           N'REJECTED', N'CANCELLED')),
        reason                   NVARCHAR(1000) NULL,
        field_choices_json       NVARCHAR(MAX)  NULL,     -- {"fieldKey": duplicateAssetId}
        is_critical              BIT            NOT NULL CONSTRAINT df_pm_amse_crit DEFAULT 0,
        approvals_required       INT            NOT NULL CONSTRAINT df_pm_amse_appr DEFAULT 1,
        preview_json             NVARCHAR(MAX)  NULL,     -- plan counts when submitted
        requested_by             NVARCHAR(100)  NOT NULL,
        requested_by_employee_id BIGINT         NULL,
        requested_dt             DATETIME2      NOT NULL CONSTRAINT df_pm_amse_rdt DEFAULT SYSUTCDATETIME(),
        submitted_dt             DATETIME2      NULL,
        decided_note             NVARCHAR(1000) NULL,     -- rejection / cancellation note
        executed_by              NVARCHAR(100)  NULL,
        executed_dt              DATETIME2      NULL,
        recovered_by             NVARCHAR(100)  NULL,
        recovered_dt             DATETIME2      NULL,
        recovery_reason          NVARCHAR(1000) NULL,
        closed_dt                DATETIME2      NULL,
        record_version           ROWVERSION     NOT NULL
    );
    CREATE INDEX ix_pm_amse_org ON grac_practice.asset_merge_split_event(organization_id, status, event_id DESC);
    PRINT '444: asset_merge_split_event created.';
END
GO

IF OBJECT_ID('grac_practice.asset_merge_split_member','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_merge_split_member (
        event_id     BIGINT       NOT NULL CONSTRAINT fk_pm_amsm_event REFERENCES grac_practice.asset_merge_split_event(event_id),
        asset_id     BIGINT       NOT NULL CONSTRAINT fk_pm_amsm_asset REFERENCES grac_practice.organization_dependency_asset(asset_id),
        member_role  NVARCHAR(10) NOT NULL CONSTRAINT ck_pm_amsm_role CHECK (member_role IN (N'DUPLICATE', N'RESULT')),
        sequence_no  INT          NOT NULL,
        CONSTRAINT pk_pm_amsm PRIMARY KEY (event_id, asset_id)
    );
    CREATE INDEX ix_pm_amsm_asset ON grac_practice.asset_merge_split_member(asset_id);
    PRINT '444: asset_merge_split_member created.';
END
GO

IF OBJECT_ID('grac_practice.asset_merge_split_approval','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_merge_split_approval (
        approval_id          BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_amsa PRIMARY KEY,
        event_id             BIGINT         NOT NULL CONSTRAINT fk_pm_amsa_event REFERENCES grac_practice.asset_merge_split_event(event_id),
        decision             NVARCHAR(10)   NOT NULL CONSTRAINT ck_pm_amsa_dec CHECK (decision IN (N'APPROVE', N'REJECT')),
        note                 NVARCHAR(1000) NULL,
        approver             NVARCHAR(100)  NOT NULL,
        approver_employee_id BIGINT         NULL,
        decided_dt           DATETIME2      NOT NULL CONSTRAINT df_pm_amsa_dt DEFAULT SYSUTCDATETIME()
    );
    CREATE INDEX ix_pm_amsa_event ON grac_practice.asset_merge_split_approval(event_id);
    PRINT '444: asset_merge_split_approval created.';
END
GO

IF OBJECT_ID('grac_practice.asset_merge_split_object','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_merge_split_object (
        object_row_id  BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_amso PRIMARY KEY,
        event_id       BIGINT         NOT NULL CONSTRAINT fk_pm_amso_event REFERENCES grac_practice.asset_merge_split_event(event_id),
        object_kind    NVARCHAR(20)   NOT NULL,
        object_id      BIGINT         NULL,
        object_key     NVARCHAR(200)  NULL,
        object_label   NVARCHAR(400)  NULL,
        from_asset_id  BIGINT         NOT NULL,
        to_asset_id    BIGINT         NOT NULL,
        outcome        NVARCHAR(12)   NOT NULL
            CONSTRAINT ck_pm_amso_outcome CHECK (outcome IN (N'MOVED', N'ENDED', N'RESOLVED', N'KEPT', N'FILLED', N'REPLACED',
                                                             N'ALIASED', N'ARCHIVED')),
        before_value   NVARCHAR(MAX)  NULL,
        after_value    NVARCHAR(MAX)  NULL,
        detail         NVARCHAR(600)  NULL,
        recovered      BIT            NOT NULL CONSTRAINT df_pm_amso_rec DEFAULT 0,
        recovery_note  NVARCHAR(400)  NULL,
        entered_dt     DATETIME2      NOT NULL CONSTRAINT df_pm_amso_edt DEFAULT SYSUTCDATETIME()
    );
    CREATE INDEX ix_pm_amso_event ON grac_practice.asset_merge_split_object(event_id, object_row_id);
    PRINT '444: asset_merge_split_object created.';
END
GO

IF OBJECT_ID('grac_practice.asset_alias','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_alias (
        alias_id        BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_asset_alias PRIMARY KEY,
        organization_id BIGINT        NOT NULL,
        asset_id        BIGINT        NOT NULL CONSTRAINT fk_pm_asset_alias_asset REFERENCES grac_practice.organization_dependency_asset(asset_id),
        alias_kind      NVARCHAR(30)  NOT NULL,     -- NAME | ASSET_ID | or the dictionary field key
        alias_value     NVARCHAR(400) NOT NULL,
        source_asset_id BIGINT        NOT NULL,
        event_id        BIGINT        NOT NULL CONSTRAINT fk_pm_asset_alias_event REFERENCES grac_practice.asset_merge_split_event(event_id),
        is_active       BIT           NOT NULL CONSTRAINT df_pm_asset_alias_act DEFAULT 1,
        entered_by      NVARCHAR(100) NOT NULL,
        entered_dt      DATETIME2     NOT NULL CONSTRAINT df_pm_asset_alias_edt DEFAULT SYSUTCDATETIME()
    );
    CREATE INDEX ix_pm_asset_alias_value ON grac_practice.asset_alias(organization_id, alias_value) INCLUDE (asset_id, is_active);
    CREATE INDEX ix_pm_asset_alias_asset ON grac_practice.asset_alias(asset_id);
    PRINT '444: asset_alias created.';
END
GO

-- =====================================================================
-- 2. System merge rules: any status -> Archived (merged record) and back
--    (recovery). Role ASSET_MERGE only and no 429 gate: they are not user
--    moves -- the Lifecycle tab, sp_asset_lifecycle_transition and the
--    matrix use role-free rules with a gate only (D119). The 429
--    verification checks 429-a / 429-b now look at role-free rules only.
-- =====================================================================
MERGE grac_practice.entity_state_transition_rule AS t
USING (
    SELECT N'Asset' AS entity_type, s.status_code AS from_status_code, N'ARCHIVED' AS to_status_code, N'ASSET_MERGE' AS actor_role_code,
           CAST(1 AS BIT) AS requires_reason, N'Merged into another asset (444)' AS description
      FROM grac_practice.entity_status_master s
     WHERE s.entity_type = N'Asset' AND s.status_code <> N'ARCHIVED'
    UNION ALL
    SELECT N'Asset', N'ARCHIVED', s.status_code, N'ASSET_MERGE', CAST(1 AS BIT), N'Merge recovered (444)'
      FROM grac_practice.entity_status_master s
     WHERE s.entity_type = N'Asset' AND s.status_code <> N'ARCHIVED'
) AS s
ON t.entity_type = s.entity_type AND t.from_status_code = s.from_status_code AND t.to_status_code = s.to_status_code
   AND t.actor_role_code = s.actor_role_code
WHEN NOT MATCHED BY TARGET THEN
    INSERT (entity_type, from_status_code, to_status_code, actor_role_code, requires_reason, requires_approval, description, entered_by)
    VALUES (s.entity_type, s.from_status_code, s.to_status_code, s.actor_role_code, s.requires_reason, 0, s.description, N'seed-444');
PRINT CONCAT('444: merge transition rules inserted: ', @@ROWCOUNT);
GO
