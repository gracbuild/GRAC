import sys
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w446/new'
W=R+'/src/PracticeManagement.Web/'
def edit(path, old, new, count=1):
    s=open(path).read()
    assert s.count(old)==count, (path, old[:90], s.count(old))
    s=s.replace(old,new); open(path,'w').write(s)

# ======================================================== asset-register.cshtml
V=W+'Views/Practice/Partials/asset-register.cshtml'
edit(V, """    Backend: practice/api/asset-config/register... (AssetConfigController)
""", """    446 (BRD 5.1.18 / 5.1.18.5.7 / 5.1.18.5.8): the Valuation tab shows the
    stored Asset Value (score, category, configuration version, method,
    validation status) next to what the Active configuration gives now,
    the calculation history, Recalculate (EDIT; a reason when a newer
    configuration version applies) and Override method (APPROVE; only when
    the configuration permits it; reason required). Asset Value Score and
    Category on the form are read-only and come from the stored result.

    Backend: practice/api/asset-config/register... (AssetConfigController)
""")
edit(V, """                <button role="tab" data-arg-tab="coverage" aria-selected="false" id="argCoverageTab" hidden>Coverage</button>
""", """                <button role="tab" data-arg-tab="coverage" aria-selected="false" id="argCoverageTab" hidden>Coverage</button>
                <button role="tab" data-arg-tab="valuation" aria-selected="false" id="argValTab" hidden>Valuation</button>
""")
edit(V, """            <div class="pm-tab-panel" data-arg-panel="workflows" hidden id="argWfPanel">
""", """            <div class="pm-tab-panel" data-arg-panel="valuation" hidden id="argValPanel">
                <div class="arg-tech-head">
                    <p class="arg-note" id="argValState"></p>
                    <div class="arg-pending-actions">
                        @if (argCanEdit)
                        {
                            <button class="pm-button" type="button" id="argValRecalc" hidden><i class="fa-solid fa-arrows-rotate"></i> Recalculate</button>
                        }
                        @if (argCanApprove)
                        {
                            <button class="pm-button" type="button" id="argValOverride" hidden><i class="fa-solid fa-sliders"></i> Override method</button>
                        }
                    </div>
                </div>
                <div class="arg-section">
                    <h3>Asset Value</h3>
                    <div class="pm-table-wrap">
                        <table>
                            <thead><tr><th>Item</th><th>Active configuration now</th><th>Stored</th></tr></thead>
                            <tbody id="argValCompare"></tbody>
                        </table>
                    </div>
                </div>
                <div class="arg-section">
                    <h3>Calculation history</h3>
                    <div class="pm-table-wrap">
                        <table>
                            <thead><tr><th>When</th><th>Source</th><th>Configuration</th><th>C / I / A</th><th>Method</th><th>Score</th><th>Category</th><th>Status</th><th>By</th><th>Reason / message</th></tr></thead>
                            <tbody id="argValHistory"></tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="pm-tab-panel" data-arg-panel="workflows" hidden id="argWfPanel">
""")
edit(V, """@* ======================= Start workflow modal (433) ======================= *@
""", """@* ======================= Valuation method override modal (446) ======================= *@
<div class="pm-modal" id="argValModal" hidden>
    <div class="pm-modal-panel">
        <header>
            <h2>Override valuation method</h2>
            <button class="pm-modal-close" type="button" data-close-arg="argValModal" aria-label="Close">&times;</button>
        </header>
        <form id="argValForm" class="pm-form-grid">
            <p class="arg-note full" id="argValModalNote"></p>
            <label class="full"><span>Method</span><select id="argValMethod"></select></label>
            <label class="full"><span>Reason *</span><textarea id="argValReason" rows="3" maxlength="1000"></textarea></label>
            <p class="pm-message full" id="argValMessage" role="status" aria-live="polite" hidden></p>
            <footer class="pm-modal-footer full">
                <button type="button" class="pm-button" data-close-arg="argValModal">Cancel</button>
                <button type="submit" class="pm-button primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
            </footer>
        </form>
    </div>
</div>

@* ======================= Start workflow modal (433) ======================= *@
""")

# ======================================================== asset-register.js
J=W+'wwwroot/js/AssetConfig/asset-register.js'
edit(J, """// it (discovery/exceptions/{id}/resolve, action REGISTER).
// =====================================================================
""", """// it (discovery/exceptions/{id}/resolve, action REGISTER).
// 446: Valuation tab -- register/{id}/valuation (stored Asset Value, what the
// Active configuration gives now, history), register/{id}/valuation/
// recalculate and register/{id}/valuation/method (override). The rules
// (automatic recalculation, reason, override permission) are in the
// procedures.
// =====================================================================
""")
edit(J, """    discovery: null   // 443: { exceptionId, recordVersion, sourceName, externalKey, values }
""", """    discovery: null,  // 443: { exceptionId, recordVersion, sourceName, externalKey, values }
    valuation: null   // 446: { current, history }
""")
edit(J, """    document.getElementById("argCoverageTab").hidden = true;   // 435
    state.custody = null;
""", """    document.getElementById("argCoverageTab").hidden = true;   // 435
    document.getElementById("argValTab").hidden = true;        // 446
    state.valuation = null;
    state.custody = null;
""")
edit(J, """    await loadCoverage();   // 435
    await loadWorkflows();
""", """    await loadCoverage();   // 435
    await loadValuation();  // 446
    await loadWorkflows();
""")
edit(J, """    document.getElementById("argWfListBtn").addEventListener("click", openWorkflowList);
""", """    document.getElementById("argWfListBtn").addEventListener("click", openWorkflowList);
    // 446
    document.getElementById("argValRecalc")?.addEventListener("click", recalcValuation);
    document.getElementById("argValOverride")?.addEventListener("click", openValOverride);
    document.getElementById("argValForm").addEventListener("submit", ev => { ev.preventDefault(); submitValOverride(); });
""")
edit(J, """  // ------------------------------------------------------------------ workflows (433)
""", """  // ------------------------------------------------------------------ valuation (446)
  const VAL_STATUS = { NOT_RATED: "Not rated", INCOMPLETE: "Incomplete", INVALID: "Invalid", VALID: "Valid" };
  const VAL_STATE = {
    CURRENT: "Up to date.", NOT_CALCULATED: "Not calculated yet.",
    VALUES_CHANGED: "The ratings or method changed since the last calculation.",
    CONFIG_CHANGED: "A newer valuation configuration version is Active; the stored value changes with a controlled recalculation.",
    CONFIG_AND_VALUES: "The ratings changed and a newer valuation configuration version is Active."
  };
  const VAL_METHOD = { MAXIMUM: "Maximum", WEIGHTED_AVERAGE: "Weighted Average", SUMMATION: "Summation" };
  const VAL_SOURCE = { FORM: "Asset form", SCHEDULER: "Scheduler", MANUAL: "Recalculated", RECALC_RUN: "Recalculation run", METHOD_OVERRIDE: "Method override" };
  const valNum = v => v == null || v === "" ? "--" : String(Number(v));
  const valMethod = (m, src) => m ? (VAL_METHOD[m] || m) + (src === "OVERRIDE" ? " (asset override)" : "") : "--";

  async function loadValuation() {
    if (!state.asset) return;
    const res = await api("GET", `/${state.asset.assetId}/valuation?organizationId=${state.organizationId}`);
    if (!res.ok) return;
    state.valuation = res.data.data;
    document.getElementById("argValTab").hidden = false;
    renderValuation();
  }

  function renderValuation() {
    const d = state.valuation || {}, v = d.current || {};
    const shown = v.storedStatus || v.validationStatus;
    document.getElementById("argValState").textContent =
      `Asset Value: ${v.storedCategory ? `${v.storedCategory} (score ${valNum(v.storedScore)})` : (VAL_STATUS[shown] || "Not rated")}. `
      + (VAL_STATE[v.stateCode] || "")
      + (v.treatmentGuidance ? ` Treatment guidance: ${v.treatmentGuidance}` : "");
    const recalc = document.getElementById("argValRecalc");
    if (recalc) recalc.hidden = !!Number(v.isCurrent);
    const override = document.getElementById("argValOverride");
    if (override) override.hidden = !v.configId || !(v.overrideAllowed || v.methodOverride);
    const row = (label, now, stored) => `<tr><td>${esc(label)}</td><td>${now}</td><td>${stored}</td></tr>`;
    const st = (code, msg) => esc(VAL_STATUS[code] || code || "--") + (msg ? `<div class="arg-note">${esc(msg)}</div>` : "");
    const hasStored = !!v.storedStatus;
    document.getElementById("argValCompare").innerHTML = [
      row("Configuration version", v.configVersionNo ? `v${esc(v.configVersionNo)}` : "None Active", hasStored && v.storedConfigVersionNo ? `v${esc(v.storedConfigVersionNo)}` : "--"),
      row("Confidentiality", esc(v.confidentiality || "--"), esc(hasStored ? (v.storedConfidentiality || "--") : "--")),
      row("Integrity", esc(v.integrity || "--"), esc(hasStored ? (v.storedIntegrity || "--") : "--")),
      row("Availability", esc(v.availability || "--"), esc(hasStored ? (v.storedAvailability || "--") : "--")),
      row("Method", esc(valMethod(v.methodUsed, v.methodSource)), esc(hasStored ? valMethod(v.storedMethodUsed, v.storedMethodSource) : "--")),
      row("Asset Value score", esc(valNum(v.assetValueScore)), esc(hasStored ? valNum(v.storedScore) : "--")),
      row("Asset Value category", esc(v.assetValueCategory || "--"), esc(hasStored ? (v.storedCategory || "--") : "--")),
      row("Validation status", st(v.validationStatus, v.validationMessage), hasStored ? st(v.storedStatus, v.storedMessage) : "--"),
      row("Calculated", "", hasStored ? `${esc(v.calculatedBy || "")} ${esc(dateTime(v.calculatedDt))}<div class="arg-note">${esc(VAL_SOURCE[v.storedSource] || v.storedSource || "")}</div>` : "--")
    ].join("");
    document.getElementById("argValHistory").innerHTML = (d.history || []).map(h => `
      <tr><td>${esc(dateTime(h.enteredDt))}</td><td>${esc(VAL_SOURCE[h.source] || h.source)}${h.runId ? ` <span class="arg-note">run #${esc(h.runId)}</span>` : ""}</td>
          <td>${h.configVersionNo ? `v${esc(h.configVersionNo)}` : "--"}${h.prevConfigVersionNo && h.prevConfigVersionNo !== h.configVersionNo ? `<div class="arg-note">was v${esc(h.prevConfigVersionNo)}</div>` : ""}</td>
          <td>${esc([h.confidentiality, h.integrity, h.availability].map(x => x || "-").join(" / "))}</td>
          <td>${esc(valMethod(h.methodUsed, h.methodSource))}</td><td>${esc(valNum(h.score))}</td>
          <td>${esc(h.category || "--")}${h.prevStatus ? `<div class="arg-note">was ${esc(h.prevCategory || VAL_STATUS[h.prevStatus] || h.prevStatus)}</div>` : ""}</td>
          <td>${esc(VAL_STATUS[h.status] || h.status)}</td><td>${esc(h.enteredBy || "")}</td>
          <td>${esc(h.reason || "")}${h.message ? `<div class="arg-note">${esc(h.message)}</div>` : ""}</td></tr>`).join("")
      || empty(10, "No calculation yet.");
  }

  async function recalcValuation() {
    const v = (state.valuation || {}).current || {};
    let reason = null;
    if (Number(v.configChanged)) {
      reason = await window.gracUi.promptRequired(`Recalculate this asset with valuation configuration version ${v.configVersionNo || "(none)"}? The previous value stays in the history.`,
        { title: "Recalculate Asset Value", inputLabel: "Reason" });
      if (!reason) return;
    }
    const res = await api("POST", `/${state.asset.assetId}/valuation/recalculate`, { organizationId: state.organizationId, reason });
    if (!res.ok) { showMessage(res.error, "error"); return; }
    await openAsset(state.asset.assetId);
    selectTab("valuation");
    showMessage(res.data.result === "RECALCULATED" ? "Asset Value recalculated." : "Asset Value was already up to date.", "success");
  }

  function openValOverride() {
    const v = (state.valuation || {}).current || {};
    const configured = VAL_METHOD[v.configuredMethod] || v.configuredMethod || "--";
    const others = v.overrideAllowed ? Object.keys(VAL_METHOD).filter(m => m !== v.configuredMethod) : [];
    document.getElementById("argValMethod").innerHTML = `<option value="">Configured method (${esc(configured)}) -- no override</option>`
      + others.map(m => `<option value="${m}"${m === v.methodOverride ? " selected" : ""}>${esc(VAL_METHOD[m])}</option>`).join("");
    document.getElementById("argValModalNote").textContent = `Valuation configuration v${v.configVersionNo} uses ${configured}. `
      + (v.overrideAllowed ? "An asset-level method applies to this asset only and is recorded with your reason."
                           : "This version does not permit overrides; you can only remove the recorded override.");
    document.getElementById("argValReason").value = "";
    const msg = document.getElementById("argValMessage"); msg.hidden = true; msg.textContent = "";
    document.getElementById("argValModal").hidden = false;
  }

  async function submitValOverride() {
    const msg = document.getElementById("argValMessage");
    const res = await api("POST", `/${state.asset.assetId}/valuation/method`, {
      organizationId: state.organizationId, method: val("argValMethod") || null, reason: val("argValReason") || null
    });
    if (!res.ok) { msg.textContent = res.error; msg.hidden = false; return; }
    document.getElementById("argValModal").hidden = true;
    await openAsset(state.asset.assetId);
    selectTab("valuation");
    showMessage("Valuation method saved; Asset Value recalculated.", "success");
  }

  // ------------------------------------------------------------------ workflows (433)
""")

# ======================================================== asset-valuation-config.cshtml
C=W+'Views/Practice/Partials/asset-valuation-config.cshtml'
edit(C, """    Backend: practice/api/asset-config/valuation... (AssetConfigController)
""", """    446 (BRD 5.1.18.5.7 / 5.1.18.5.8): Recalculation shows the impact of the
    Active version on stored Asset Values (affected assets and why,
    category moves, linked risks, earlier runs) and runs a controlled
    recalculation with a reason (APPROVE). Activating a version never
    changes stored values by itself.

    Backend: practice/api/asset-config/valuation... (AssetConfigController)
""")
edit(C, """            <button class="pm-button icon" id="avcRefresh" type="button" title="Refresh" aria-label="Refresh">
                <i class="fa-solid fa-arrows-rotate"></i>
            </button>
        </div>
""", """            <button class="pm-button" id="avcRecalcBtn" type="button">
                <i class="fa-solid fa-calculator"></i> Recalculation
            </button>
            <button class="pm-button icon" id="avcRefresh" type="button" title="Refresh" aria-label="Refresh">
                <i class="fa-solid fa-arrows-rotate"></i>
            </button>
        </div>
""")
edit(C, """    @* =========================== Design view =========================== *@
""", """    @* ===================== Recalculation view (446) ===================== *@
    <section id="avcRecalcView" hidden>
        <div class="pm-panel avc-head">
            <div class="avc-head-main">
                <button class="pm-button" id="avcRecalcBack" type="button"><i class="fa-solid fa-arrow-left"></i> Configurations</button>
                <div>
                    <div class="avc-head-title">Asset Value recalculation</div>
                    <div class="avc-head-meta" id="avcRecalcMeta"></div>
                </div>
            </div>
            <div class="avc-head-actions">
                <button class="pm-button icon" id="avcRecalcRefresh" type="button" title="Refresh impact" aria-label="Refresh impact"><i class="fa-solid fa-arrows-rotate"></i></button>
                @if (avcCanApprove)
                {
                    <button class="pm-button primary" id="avcRecalcRun" type="button"><i class="fa-solid fa-play"></i> Run recalculation</button>
                }
            </div>
        </div>
        <p class="pm-message" id="avcRecalcMessage" role="status" aria-live="polite" hidden></p>
        <div class="pm-panel">
            <dl class="avc-result" id="avcRecalcSummary"></dl>
            <h3 class="avc-sub">Category moves</h3>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>From</th><th>To</th><th>Assets</th></tr></thead>
                    <tbody id="avcRecalcMoves"></tbody>
                </table>
            </div>
            <h3 class="avc-sub">Affected assets <small>(first 500)</small></h3>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Asset</th><th>Why</th><th>Stored</th><th>After recalculation</th><th>Linked risks</th></tr></thead>
                    <tbody id="avcRecalcAssets"></tbody>
                </table>
            </div>
            <h3 class="avc-sub">Runs</h3>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Run</th><th>Started</th><th>Configuration</th><th>Status</th><th>Affected / updated / errors</th><th>By</th><th>Reason</th></tr></thead>
                    <tbody id="avcRecalcRuns"></tbody>
                </table>
            </div>
        </div>
    </section>

    @* =========================== Design view =========================== *@
""")
edit(C, """    .avc-note { color: var(--fg-secondary); font-size: 12px; margin: 0; }
""", """    .avc-note { color: var(--fg-secondary); font-size: 12px; margin: 0; }
    .avc-sub { font-size: 13px; font-weight: 600; color: var(--fg-strong); margin: 16px 0 8px; }
""")

# ======================================================== asset-valuation-config.js
K=W+'wwwroot/js/AssetConfig/asset-valuation-config.js'
edit(K, """// the procedures; this screen only mirrors them and shows their messages.
// =====================================================================
""", """// the procedures; this screen only mirrors them and shows their messages.
// 446: Recalculation view -- valuation/recalculation (impact analysis of
// the Active version on stored Asset Values, earlier runs) and a controlled
// run with a reason against the affected count shown (409 when it moved).
// =====================================================================
""")
edit(K, """  const state = { organizationId: null, rows: [], detail: null };
""", """  const state = { organizationId: null, rows: [], detail: null, preview: null };
""")
edit(K, """    document.getElementById("avcReadyRefresh").addEventListener("click", loadReadiness);
  }
""", """    document.getElementById("avcReadyRefresh").addEventListener("click", loadReadiness);
    // 446
    document.getElementById("avcRecalcBtn").addEventListener("click", openRecalc);
    document.getElementById("avcRecalcBack").addEventListener("click", showList);
    document.getElementById("avcRecalcRefresh").addEventListener("click", loadRecalc);
    document.getElementById("avcRecalcRun")?.addEventListener("click", runRecalc);
  }
""")
edit(K, """    document.getElementById("avcDesignView").hidden = true;
    document.getElementById("avcListView").hidden = false;
""", """    document.getElementById("avcDesignView").hidden = true;
    document.getElementById("avcRecalcView").hidden = true;   // 446
    document.getElementById("avcListView").hidden = false;
""")
edit(K, """    await reload(`Configuration moved to ${STATUS[toStatusCode]?.label || toStatusCode}.`);
  }
""", """    await reload(`Configuration moved to ${STATUS[toStatusCode]?.label || toStatusCode}.`
      + (toStatusCode === "ACTIVE" ? " Stored Asset Values are not changed; review the impact under Recalculation." : ""));   // 446
  }

  // ------------------------------------------------------------------ recalculation (446)
  const RECALC_WHY = { NOT_CALCULATED: "Not calculated yet", VALUES_CHANGED: "Ratings / method changed",
                       CONFIG_CHANGED: "Newer configuration version", CONFIG_AND_VALUES: "Ratings changed and newer version" };
  const VAL_STATUS = { NOT_RATED: "Not rated", INCOMPLETE: "Incomplete", INVALID: "Invalid", VALID: "Valid" };
  const RUN_STATUS = { RUNNING: "Running", COMPLETED: "Completed", COMPLETED_WITH_ERRORS: "Completed with errors", FAILED: "Failed" };
  const valueText = (cat, score, status) => cat ? `${cat} (${num(score)})` : (VAL_STATUS[status] || "--");

  async function openRecalc() {
    if (!state.organizationId) { await notify("Select an organization first.", "warning"); return; }
    document.getElementById("avcListView").hidden = true;
    document.getElementById("avcDesignView").hidden = true;
    document.getElementById("avcRecalcView").hidden = false;
    recalcMessage("");
    await loadRecalc();
  }

  async function loadRecalc() {
    const res = await api("GET", `/recalculation?organizationId=${state.organizationId}`);
    if (!res.ok) { recalcMessage(res.error, "error"); return; }
    state.preview = res.data.data || {};
    renderRecalc();
  }

  function renderRecalc() {
    const p = state.preview || {}, s = p.summary || {};
    document.getElementById("avcRecalcMeta").textContent = s.activeVersionNo
      ? `Active configuration v${s.activeVersionNo} -- ${METHOD[s.valuationMethod] || s.valuationMethod}${s.overrideAllowed ? ", asset-level override permitted" : ""}`
      : "No Active valuation configuration -- rated assets are shown as invalid until one is activated.";
    document.getElementById("avcRecalcSummary").innerHTML = `
      <dt>Assets to recalculate</dt><dd>${esc(s.affectedAssets ?? 0)}</dd>
      <dt>Newer configuration version</dt><dd>${esc(s.configChanged ?? 0)}</dd>
      <dt>Ratings / method changed</dt><dd>${esc(s.valuesChanged ?? 0)}</dd>
      <dt>Not calculated yet</dt><dd>${esc(s.notCalculated ?? 0)}</dd>
      <dt>Category changes</dt><dd>${esc(s.categoryChanges ?? 0)}</dd>
      <dt>Not valid after recalculation</dt><dd>${esc(s.notValidAfter ?? 0)}</dd>
      <dt>Risks linked to these assets</dt><dd>${esc(s.linkedRisks ?? 0)}</dd>
      <dt>Assets with a valid Asset Value</dt><dd>${esc(s.valuedAssets ?? 0)}</dd>`;
    const run = document.getElementById("avcRecalcRun");
    if (run) run.disabled = !Number(s.affectedAssets) || !!Number(s.runsInProgress);
    document.getElementById("avcRecalcMoves").innerHTML = (p.moves || []).map(m => `
      <tr><td>${esc(m.fromCategory || VAL_STATUS[m.fromStatus] || "Not calculated")}</td>
          <td>${esc(m.toCategory || VAL_STATUS[m.toStatus] || m.toStatus)}</td><td>${esc(m.assetCount)}</td></tr>`).join("")
      || `<tr><td colspan="3" class="pm-empty">Every stored Asset Value is up to date.</td></tr>`;
    document.getElementById("avcRecalcAssets").innerHTML = (p.assets || []).map(a => `
      <tr><td>${esc(a.assetName)} <span class="avc-note">#${esc(a.assetId)}</span></td>
          <td>${esc(RECALC_WHY[a.stateCode] || a.stateCode)}</td>
          <td>${a.storedStatus ? esc(valueText(a.storedCategory, a.storedScore, a.storedStatus)) + (a.storedConfigVersionNo ? ` <span class="avc-note">v${esc(a.storedConfigVersionNo)}</span>` : "") : "--"}</td>
          <td>${esc(valueText(a.newCategory, a.newScore, a.newStatus))}${a.message ? `<div class="avc-note">${esc(a.message)}</div>` : ""}</td>
          <td>${esc(a.riskCount)}</td></tr>`).join("")
      || `<tr><td colspan="5" class="pm-empty">No asset to recalculate.</td></tr>`;
    document.getElementById("avcRecalcRuns").innerHTML = (p.runs || []).map(r => `
      <tr><td>#${esc(r.runId)}</td><td>${esc(dateTime(r.startedDt))}</td><td>${r.configVersionNo ? `v${esc(r.configVersionNo)}` : "--"}</td>
          <td>${esc(RUN_STATUS[r.status] || r.status)}${r.errorText ? `<div class="avc-note">${esc(r.errorText)}</div>` : ""}</td>
          <td>${esc(r.affectedCount)} / ${esc(r.updatedCount)} / ${esc(r.errorCount)}</td><td>${esc(r.enteredBy)}</td><td>${esc(r.reason)}</td></tr>`).join("")
      || `<tr><td colspan="7" class="pm-empty">No recalculation run yet.</td></tr>`;
  }

  async function runRecalc() {
    const s = (state.preview || {}).summary || {};
    const n = Number(s.affectedAssets) || 0;
    if (!n) { await notify("Every stored Asset Value is up to date.", "info"); return; }
    const reason = await window.gracUi.promptRequired(
      `Recalculate ${n} asset(s) with configuration v${s.activeVersionNo || "(none)"}? Previous values stay in each asset's history.`,
      { title: "Run recalculation", inputLabel: "Reason" });
    if (!reason) return;
    recalcMessage("Recalculating...", "info");
    const res = await api("POST", "/recalculation", { organizationId: state.organizationId, reason, expectedAffected: n });
    if (!res.ok) { recalcMessage(res.error, "error"); await loadRecalc(); return; }
    await loadRecalc();
    recalcMessage(`Run #${res.data.id}: ${RUN_STATUS[res.data.result] || res.data.result}.`, res.data.result === "COMPLETED" ? "success" : "error");
  }

  function recalcMessage(text, kind) {
    const el = document.getElementById("avcRecalcMessage");
    el.textContent = text || ""; el.classList.toggle("success", kind === "success"); el.hidden = !text;
  }
""")
print('ui patched')
