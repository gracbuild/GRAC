import sys
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w447/new'
W=R+'/src/PracticeManagement.Web/'
def edit(path, old, new, count=1):
    s=open(path).read(); assert s.count(old)==count, (path, old[:90], s.count(old)); open(path,'w').write(s.replace(old,new))
V=W+'Views/Practice/Partials/asset-register.cshtml'
edit(V, """    Backend: practice/api/asset-config/register... (AssetConfigController)
""", """    447 (BRD 19.7 / 5.1.18.3): the Valuation tab also lists the asset's CIA /
    criticality consistency findings -- accept with rationale, evidence,
    owner and review date (EDIT), approve / reject / revoke (APPROVE, not
    the requester), withdraw, re-evaluate -- and the risks linked to the
    asset with the Asset Value the risk module reads and a review flag.
    "Consistency findings" in the list toolbar is the organization worklist.

    Backend: practice/api/asset-config/register... (AssetConfigController)
""")
edit(V, """            <button class="pm-button" id="argWfListBtn" type="button"><i class="fa-solid fa-list-check"></i> Workflow cases</button>
""", """            <button class="pm-button" id="argWfListBtn" type="button"><i class="fa-solid fa-list-check"></i> Workflow cases</button>
            <button class="pm-button" id="argConsListBtn" type="button"><i class="fa-solid fa-scale-balanced"></i> Consistency findings</button>
""")
edit(V, """                <div class="arg-section">
                    <h3>Calculation history</h3>
""", """                <div class="arg-section">
                    <div class="arg-tech-head">
                        <h3>Consistency findings</h3>
                        @if (argCanEdit)
                        {
                            <button class="pm-button" type="button" id="argConsRun"><i class="fa-solid fa-arrows-rotate"></i> Re-evaluate</button>
                        }
                    </div>
                    <div class="pm-table-wrap">
                        <table>
                            <thead><tr><th>Rule</th><th>Severity</th><th>Status</th><th>Detected</th><th>Acceptance</th><th></th></tr></thead>
                            <tbody id="argConsBody"></tbody>
                        </table>
                    </div>
                </div>
                <div class="arg-section">
                    <h3>Linked risks</h3>
                    <div class="pm-table-wrap">
                        <table>
                            <thead><tr><th>Risk</th><th>Status</th><th>Inherent / residual</th><th>Asset Value used</th><th>Last assessed</th><th>Review</th></tr></thead>
                            <tbody id="argValRisks"></tbody>
                        </table>
                    </div>
                </div>
                <div class="arg-section">
                    <h3>Calculation history</h3>
""")
edit(V, """@* ======================= Start workflow modal (433) ======================= *@
""", """@* ======================= Accept consistency finding modal (447) ======================= *@
<div class="pm-modal" id="argConsModal" hidden>
    <div class="pm-modal-panel">
        <header>
            <h2>Accept inconsistency</h2>
            <button class="pm-modal-close" type="button" data-close-arg="argConsModal" aria-label="Close">&times;</button>
        </header>
        <form id="argConsForm" class="pm-form-grid">
            <p class="arg-note full" id="argConsNote"></p>
            <label class="full"><span>Rationale *</span><textarea id="argConsRationale" rows="3" maxlength="1000"></textarea></label>
            <label class="full"><span id="argConsEvidenceLabel">Evidence</span><textarea id="argConsEvidence" rows="2" maxlength="1000"></textarea></label>
            <label><span>Owner *</span><select id="argConsOwner"></select></label>
            <label><span>Review date *</span><input type="date" id="argConsReview" /></label>
            <p class="pm-message full" id="argConsMessage" role="status" aria-live="polite" hidden></p>
            <footer class="pm-modal-footer full">
                <button type="button" class="pm-button" data-close-arg="argConsModal">Cancel</button>
                <button type="submit" class="pm-button primary"><i class="fa-solid fa-paper-plane"></i> Accept</button>
            </footer>
        </form>
    </div>
</div>

@* ======================= Consistency findings list (447) ======================= *@
<div class="pm-modal" id="argConsListModal" hidden>
    <div class="pm-modal-panel arg-wide">
        <header>
            <h2>Consistency findings</h2>
            <button class="pm-modal-close" type="button" data-close-arg="argConsListModal" aria-label="Close">&times;</button>
        </header>
        <div class="pm-toolbar">
            <select id="argConsStatus" title="Status">
                <option value="">Open and awaiting approval</option>
                <option value="PENDING_APPROVAL">Awaiting approval</option>
                <option value="OPEN">Open</option>
                <option value="ACCEPTED">Accepted</option>
                <option value="RESOLVED">Resolved</option>
                <option value="ALL">All</option>
            </select>
            <select id="argConsSeverity" title="Severity">
                <option value="">All severities</option>
                <option value="APPROVAL_REQUIRED">Approval Required</option>
                <option value="ERROR">Error</option>
                <option value="WARNING">Warning</option>
                <option value="INFO">Information</option>
            </select>
            <input type="search" id="argConsSearch" placeholder="Search asset or rule" maxlength="200" />
            @if (argCanEdit)
            {
                <button class="pm-button" type="button" id="argConsRunAll"><i class="fa-solid fa-arrows-rotate"></i> Re-evaluate all</button>
            }
        </div>
        <p class="arg-note" id="argConsCounts"></p>
        <div class="pm-table-wrap">
            <table>
                <thead><tr><th>Asset</th><th>Rule</th><th>Severity</th><th>Status</th><th>Detected</th><th>Acceptance</th><th></th></tr></thead>
                <tbody id="argConsListBody"></tbody>
            </table>
        </div>
    </div>
</div>

@* ======================= Start workflow modal (433) ======================= *@
""")

J=W+'wwwroot/js/AssetConfig/asset-register.js'
edit(J, """// (automatic recalculation, reason, override permission) are in the
// procedures.
""", """// (automatic recalculation, reason, override permission) are in the
// procedures.
// 447: the Valuation tab lists the asset's consistency findings and linked
// risks (register/{id}/valuation); findings are acted on through
// register/consistency/findings/{id}/action, re-evaluated through
// register/consistency/run; register/consistency/findings is the worklist.
""")
edit(J, """    valuation: null   // 446: { current, history }
""", """    valuation: null,  // 446: { current, history } (+ 447: risks, findings)
    consFinding: null, consFrom: null, consList: []   // 447
""")
edit(J, """    document.getElementById("argValForm").addEventListener("submit", ev => { ev.preventDefault(); submitValOverride(); });
""", """    document.getElementById("argValForm").addEventListener("submit", ev => { ev.preventDefault(); submitValOverride(); });
    // 447
    document.getElementById("argConsBody").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-arg-cons-act]");
      if (b) consAction(Number(b.dataset.argCons), b.dataset.argConsAct, "asset");
    });
    document.getElementById("argConsRun")?.addEventListener("click", () => runConsistency(true));
    document.getElementById("argConsForm").addEventListener("submit", ev => { ev.preventDefault(); submitConsAccept(); });
    document.getElementById("argConsListBtn").addEventListener("click", openConsList);
    ["argConsStatus", "argConsSeverity"].forEach(id => document.getElementById(id).addEventListener("change", loadConsList));
    let ct = null;
    document.getElementById("argConsSearch").addEventListener("input", () => { clearTimeout(ct); ct = setTimeout(loadConsList, 300); });
    document.getElementById("argConsRunAll")?.addEventListener("click", () => runConsistency(false));
    document.getElementById("argConsListBody").addEventListener("click", ev => {
      const act = ev.target.closest("button[data-arg-cons-act]");
      if (act) { consAction(Number(act.dataset.argCons), act.dataset.argConsAct, "list"); return; }
      const open = ev.target.closest("button[data-arg-cons-asset]");
      if (!open) return;
      document.getElementById("argConsListModal").hidden = true;
      openAsset(Number(open.dataset.argConsAsset)).then(() => selectTab("valuation"));
    });
""")
edit(J, """      || empty(10, "No calculation yet.");
  }
""", """      || empty(10, "No calculation yet.");
    renderConsistency();   // 447
    renderValRisks();      // 447
  }

  // ------------------------------------------------------------------ consistency findings (447)
  const CONS_SEV = { INFO: "Information", WARNING: "Warning", ERROR: "Error", APPROVAL_REQUIRED: "Approval Required" };
  const CONS_STATUS = { OPEN: "Open", PENDING_APPROVAL: "Awaiting approval", ACCEPTED: "Accepted", RESOLVED: "Resolved" };
  const CONS_ACTION = { WARN: "Warn", REQUIRE_RATIONALE: "Rationale required", CREATE_TASK: "Task", BLOCK_TRANSITION: "Blocks move to Active" };
  const consFacts = j => { try { return (JSON.parse(j || "[]") || []).map(x => `${x.operand} = ${x.value}`).join("; "); } catch (_) { return ""; } };
  const consAcceptance = f => f.rationale
    ? `${esc(f.rationale)}<div class="arg-note">Owner ${esc(f.ownerName || "--")}; review ${esc(date(f.reviewDate))}${f.decidedBy ? `; decided by ${esc(f.decidedBy)}` : ""}</div>`
      + (f.decisionNote ? `<div class="arg-note">${esc(f.decisionNote)}</div>` : "")
    : (f.decisionNote ? `<span class="arg-note">${esc(f.decisionNote)}</span>` : "--");
  function consButtons(f) {
    const b = [];
    if (f.status === "OPEN" && f.overrideAllowed && CAN_EDIT) b.push(["ACCEPT", "Accept"]);
    if (f.status === "PENDING_APPROVAL" && CAN_APPROVE) b.push(["APPROVE", "Approve"], ["REJECT", "Reject"]);
    if (f.status === "PENDING_APPROVAL" && CAN_EDIT) b.push(["WITHDRAW", "Withdraw"]);
    if (f.status === "ACCEPTED" && CAN_APPROVE) b.push(["REVOKE", "Revoke"]);
    return b.map(([a, l]) => `<button class="pm-button" type="button" data-arg-cons="${esc(f.findingId)}" data-arg-cons-act="${a}">${esc(l)}</button>`).join(" ");
  }

  function renderConsistency() {
    const rows = (state.valuation || {}).findings || [];
    document.getElementById("argConsBody").innerHTML = rows.map(f => `
      <tr><td>${esc(f.ruleCode)} v${esc(f.ruleVersionNo)}: ${esc(f.message)}<div class="arg-note">${esc(CONS_ACTION[f.actionCode] || f.actionCode)}${consFacts(f.factsJson) ? ` -- ${esc(consFacts(f.factsJson))}` : ""}</div></td>
          <td>${esc(CONS_SEV[f.severity] || f.severity)}</td><td>${esc(CONS_STATUS[f.status] || f.status)}</td>
          <td>${esc(dateTime(f.detectedDt))}${f.resolvedDt ? `<div class="arg-note">resolved ${esc(dateTime(f.resolvedDt))}</div>` : ""}</td>
          <td>${consAcceptance(f)}</td><td>${consButtons(f)}</td></tr>`).join("") || empty(6, "No consistency finding.");
  }

  function renderValRisks() {
    const rows = (state.valuation || {}).risks || [];
    document.getElementById("argValRisks").innerHTML = rows.map(r => `
      <tr><td>${esc(r.riskNumber || "#" + r.riskRegisterId)}<div class="arg-note">${esc(r.riskTitle)}</div></td><td>${esc(r.riskStatus)}</td>
          <td>${esc(r.inherentRating || "--")} / ${esc(r.residualRating || "--")}</td>
          <td>${r.riskAssetValueCategory ? `${esc(r.riskAssetValueCategory)} (${esc(valNum(r.riskAssetValueScore))})` : "--"}<div class="arg-note">highest of the risk's assets</div></td>
          <td>${esc(dateTime(r.riskAssessedDt))}</td>
          <td>${Number(r.reviewSuggested) ? `<span class="arg-chip arg-tc-warn">Review suggested</span><div class="arg-note">Asset Value changed ${esc(dateTime(r.lastValueChangeDt))}</div>` : "--"}</td></tr>`).join("")
      || empty(6, "No risk is linked to this asset.");
  }

  async function consAction(id, action, from) {
    const list = from === "list" ? state.consList : ((state.valuation || {}).findings || []);
    const f = list.find(x => x.findingId === id);
    if (!f) return;
    state.consFrom = from;
    if (action === "ACCEPT") { await openConsAccept(f); return; }
    let note = null;
    if (action === "REJECT" || action === "REVOKE") {
      note = await window.gracUi.promptRequired(action === "REJECT" ? "Why is the acceptance rejected?" : "Why is the acceptance revoked? The finding reopens.",
        { title: action === "REJECT" ? "Reject acceptance" : "Revoke acceptance", inputLabel: "Reason" });
      if (!note) return;
    } else if (!await window.gracUi.confirm(action === "APPROVE" ? "Approve this accepted inconsistency until its review date?" : "Withdraw the acceptance request?")) return;
    const res = await api("POST", `/consistency/findings/${id}/action`, {
      organizationId: state.organizationId, action, note, expectedRecordVersion: f.recordVersion ?? null
    });
    await afterConsChange(res, { ACCEPTED: "Inconsistency accepted.", OPEN: action === "REJECT" ? "Acceptance rejected." : action === "REVOKE" ? "Acceptance revoked." : "Request withdrawn." }[res.data && res.data.result]);
  }

  async function openConsAccept(f) {
    await ensureLookups(["MASTER:EMPLOYEE"]);
    state.consFinding = f;
    const approval = f.severity === "ERROR" || f.severity === "APPROVAL_REQUIRED";
    document.getElementById("argConsNote").textContent = `${f.ruleCode}: ${f.message}. `
      + (approval ? "This severity needs approval by another person with approval rights; evidence is required." : "The acceptance applies at once.")
      + (f.maxOverrideDays ? ` The review date must be within ${f.maxOverrideDays} days.` : "") + " The finding reopens when the review date passes.";
    document.getElementById("argConsEvidenceLabel").textContent = approval ? "Evidence *" : "Evidence";
    document.getElementById("argConsOwner").innerHTML = `<option value="">Select</option>`
      + (state.lookups["MASTER:EMPLOYEE"] || []).map(e => `<option value="${esc(e.value)}">${esc(e.label)}</option>`).join("");
    ["argConsRationale", "argConsEvidence", "argConsReview"].forEach(x => { document.getElementById(x).value = ""; });
    const msg = document.getElementById("argConsMessage"); msg.hidden = true; msg.textContent = "";
    document.getElementById("argConsModal").hidden = false;
  }

  async function submitConsAccept() {
    const f = state.consFinding, msg = document.getElementById("argConsMessage");
    const res = await api("POST", `/consistency/findings/${f.findingId}/action`, {
      organizationId: state.organizationId, action: "ACCEPT", rationale: val("argConsRationale") || null, evidence: val("argConsEvidence") || null,
      ownerEmployeeId: Number(val("argConsOwner")) || null, reviewDate: val("argConsReview") || null, expectedRecordVersion: f.recordVersion ?? null
    });
    if (!res.ok) { msg.textContent = res.error; msg.hidden = false; return; }
    document.getElementById("argConsModal").hidden = true;
    await afterConsChange(res, res.data.result === "PENDING_APPROVAL" ? "Acceptance requested; another person with approval rights decides it." : "Inconsistency accepted.");
  }

  async function afterConsChange(res, okText) {
    if (state.consFrom === "list") {
      await loadConsList();
      if (!res.ok) await window.gracUi.alert(res.error, { type: "error" });
      return;
    }
    if (!res.ok) { showMessage(res.error, "error"); if (res.status !== 409) return; }
    await openAsset(state.asset.assetId);
    selectTab("valuation");
    if (res.ok) showMessage(okText || "Done.", "success");
  }

  async function runConsistency(oneAsset) {
    const res = await api("POST", "/consistency/run", { organizationId: state.organizationId, assetId: oneAsset && state.asset ? state.asset.assetId : null });
    if (oneAsset) {
      if (!res.ok) { showMessage(res.error, "error"); return; }
      await openAsset(state.asset.assetId);
      selectTab("valuation");
      showMessage(`Consistency re-evaluated: ${res.data.result}.`, "success");
      return;
    }
    await loadConsList();
    const el = document.getElementById("argConsCounts");
    el.textContent = (res.ok ? `Re-evaluated: ${res.data.result}. ` : `${res.error} `) + el.textContent;
  }

  async function openConsList() {
    document.getElementById("argConsListModal").hidden = false;
    await loadConsList();
  }

  async function loadConsList() {
    const body = document.getElementById("argConsListBody");
    if (!state.organizationId) { body.innerHTML = empty(7, "Select an organization."); return; }
    body.innerHTML = empty(7, "Loading...");
    const qs = new URLSearchParams({ organizationId: state.organizationId, pageNumber: 1, pageSize: 200 });
    if (val("argConsStatus")) qs.set("status", val("argConsStatus"));
    if (val("argConsSeverity")) qs.set("severity", val("argConsSeverity"));
    if (val("argConsSearch")) qs.set("search", val("argConsSearch"));
    const res = await api("GET", `/consistency/findings?${qs}`);
    if (!res.ok) { body.innerHTML = empty(7, res.error); return; }
    const d = res.data.data || {};
    state.consList = d.rows || [];
    const counts = d.counts || [];
    const sum = s => counts.filter(c => c.status === s).reduce((n, c) => n + Number(c.findingCount || 0), 0);
    document.getElementById("argConsCounts").textContent = `Open ${sum("OPEN")}, awaiting approval ${sum("PENDING_APPROVAL")}, accepted ${sum("ACCEPTED")}`
        + (d.totalRows > state.consList.length ? `. Showing the first ${state.consList.length} of ${d.totalRows}.` : ".");
    body.innerHTML = state.consList.map(f => `
      <tr><td>${esc(f.assetName)}<div class="arg-note">#${esc(f.assetId)}</div></td>
          <td>${esc(f.ruleCode)} v${esc(f.ruleVersionNo)}: ${esc(f.message)}${consFacts(f.factsJson) ? `<div class="arg-note">${esc(consFacts(f.factsJson))}</div>` : ""}</td>
          <td>${esc(CONS_SEV[f.severity] || f.severity)}</td><td>${esc(CONS_STATUS[f.status] || f.status)}</td>
          <td>${esc(dateTime(f.detectedDt))}</td><td>${consAcceptance(f)}</td>
          <td>${consButtons(f)} <button class="pm-button" type="button" data-arg-cons-asset="${esc(f.assetId)}">Open</button></td></tr>`).join("")
      || empty(7, "No finding.");
  }
""")
print('ui-b patched')
