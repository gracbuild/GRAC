# Builds the 439 re-issued bodies from the 438 sources (b439/src_*.sql):
# verbatim copy + marked 439 changes. Every replacement must match once.
import sys
B = '/home/claude/b439/'
out = {}

def tx(name, pairs):
    s = open(B + 'src_' + name + '.sql', encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (name, a[:70], s.count(a))
        s = s.replace(a, b)
    out[name] = s

# ---------------------------------------------------------------- settings
tx('fn_asset_activity_settings', [(
"""           s.campaign_owner_employee_id AS CampaignOwnerEmployeeId
      FROM""",
"""           s.campaign_owner_employee_id AS CampaignOwnerEmployeeId,
           -- 439: results, dispositions and restricted use (NULL setting = template default)
           CAST(t.result_required AS BIT) AS ResultRequired,
           CAST(ISNULL(s.result_review_required, t.default_result_review) AS BIT) AS ResultReviewRequired,
           CAST(ISNULL(s.disposition_approval_required, t.default_disposition_approval) AS BIT) AS DispositionApprovalRequired,
           ISNULL(s.restrict_on_overdue, ISNULL(t.default_restrict_on_overdue, N'NONE')) AS RestrictOnOverdue,
           CAST(ISNULL(s.restrict_on_fail, t.default_restrict_on_fail) AS BIT) AS RestrictOnFail,
           t.retest_days AS RetestDays
      FROM""")])

# ---------------------------------------------------------------- task sync
tx('sp_asset_activity_task_sync', [
("""    BEGIN TRAN;
    UPDATE o""",
"""    -- 439: a result activity is completed by its approved result, not by the
    -- task; a task closed first leaves the occurrence open and flagged (D71).
    UPDATE o
       SET needs_reconciliation = 1,
           reconciliation_reason = N'The Task Centre task was closed without an approved result; record and approve the result.',
           updated_by = @actor, updated_dt = SYSUTCDATETIME()
      FROM grac_practice.asset_activity_occurrence o
      JOIN grac_practice.asset_activity_template tp ON tp.template_code = o.template_code
      JOIN grac_practice.practice_task t ON t.task_id = o.task_id
      JOIN grac_practice.entity_status_master s ON s.entity_status_id = t.current_status_id
     WHERE o.organization_id = @organization_id AND o.status = N'OPEN' AND tp.result_required = 1
       AND s.status_code <> N'Cancelled' AND (s.status_code = N'Closed' OR t.completed_dt IS NOT NULL)
       AND o.needs_reconciliation = 0
       AND ISNULL(o.reconciliation_reason, N'') <> N'The Task Centre task was closed without an approved result; record and approve the result.';

    BEGIN TRAN;
    UPDATE o"""),
("""      JOIN grac_practice.entity_status_master s ON s.entity_status_id = t.current_status_id
     WHERE o.organization_id = @organization_id AND o.status = N'OPEN'
       AND (s.status_code IN (N'Closed', N'Cancelled') OR t.completed_dt IS NOT NULL);""",
"""      JOIN grac_practice.entity_status_master s ON s.entity_status_id = t.current_status_id
      JOIN grac_practice.asset_activity_template tp ON tp.template_code = o.template_code     -- 439
     WHERE o.organization_id = @organization_id AND o.status = N'OPEN'
       AND (s.status_code IN (N'Closed', N'Cancelled') OR t.completed_dt IS NOT NULL)
       AND (s.status_code = N'Cancelled' OR tp.result_required = 0);                          -- 439"""),
])

# ---------------------------------------------------------------- schedule sync
tx('sp_asset_activity_schedule_sync', [
("""        field_last DATE NULL, expiry DATE NULL, occ_due DATE NULL, occ_done DATE NULL, open_due DATE NULL,
        PRIMARY KEY (asset_id, template_code));""",
"""        field_last DATE NULL, expiry DATE NULL, occ_due DATE NULL, occ_done DATE NULL, open_due DATE NULL,
        occ_status NVARCHAR(12) NULL, occ_outcome NVARCHAR(12) NULL, occ_review DATE NULL,       -- 439
        open_revised DATE NULL, retest_days INT NULL,                                             -- 439
        PRIMARY KEY (asset_id, template_code));"""),
("""                field_last, expiry, occ_due, occ_done, open_due)
    SELECT""",
"""                field_last, expiry, occ_due, occ_done, open_due,
                occ_status, occ_outcome, occ_review, open_revised, retest_days)                -- 439
    SELECT"""),
("""           (SELECT o.due_date FROM grac_practice.asset_activity_occurrence o
             WHERE o.asset_id = a.asset_id AND o.template_code = t.template_code AND o.status = N'OPEN')
      FROM""",
"""           (SELECT o.due_date FROM grac_practice.asset_activity_occurrence o
             WHERE o.asset_id = a.asset_id AND o.template_code = t.template_code AND o.status = N'OPEN'),
           lo.status, lo.outcome, lo.review_date,                                                 -- 439
           (SELECT o.revised_due_date FROM grac_practice.asset_activity_occurrence o
             WHERE o.asset_id = a.asset_id AND o.template_code = t.template_code AND o.status = N'OPEN'),
           st.RetestDays
      FROM"""),
("""     OUTER APPLY (SELECT TOP 1 o.due_date, o.completed_dt
                    FROM grac_practice.asset_activity_occurrence o
                   WHERE o.asset_id = a.asset_id AND o.template_code = t.template_code AND o.status = N'COMPLETED'
                   ORDER BY o.due_date DESC, o.occurrence_id DESC) lo""",
"""     -- 439: the last finished occurrence is completed (with its approved
     -- result, if any) or waived (until its review date).
     OUTER APPLY (SELECT TOP 1 o.due_date, o.completed_dt, o.status, r.outcome, o.review_date
                    FROM grac_practice.asset_activity_occurrence o
                    LEFT JOIN grac_practice.asset_activity_result r ON r.occurrence_id = o.occurrence_id AND r.state = N'APPROVED'
                   WHERE o.asset_id = a.asset_id AND o.template_code = t.template_code AND o.status IN (N'COMPLETED', N'WAIVED')
                   ORDER BY o.due_date DESC, o.occurrence_id DESC) lo"""),
("""        status_code NVARCHAR(16) NOT NULL, contract_version_id BIGINT NULL, coverage_end DATE NULL);
    INSERT #out (asset_id, template_code, schedule_state, not_scheduled_reason, frequency_text, interval_value, interval_unit, basis,
                 last_done_date, next_due_date, due_source, status_code, contract_version_id, coverage_end)""",
"""        status_code NVARCHAR(16) NOT NULL, contract_version_id BIGINT NULL, coverage_end DATE NULL,
        revised_due_date DATE NULL);                                                                -- 439
    INSERT #out (asset_id, template_code, schedule_state, not_scheduled_reason, frequency_text, interval_value, interval_unit, basis,
                 last_done_date, next_due_date, due_source, status_code, contract_version_id, coverage_end,
                 revised_due_date)                                                                  -- 439"""),
("""           CASE WHEN z.state = N'NOT_APPLICABLE' THEN N'NOT_APPLICABLE'
                WHEN z.state = N'NOT_SCHEDULED' THEN N'NOT_SCHEDULED'
                WHEN i.activity_kind = N'RENEWAL' AND cv.version_id IS NOT NULL
                     AND ISNULL(cv.eff_end, CAST('9999-12-31' AS DATE)) >= n.next_due THEN N'COVERED'
                WHEN n.next_due < @today THEN N'OVERDUE'
                WHEN n.next_due <= DATEADD(DAY, i.due_soon_days, @today) THEN N'DUE_SOON'
                ELSE N'VALID' END,
           cv.version_id, cv.eff_end""",
"""           CASE WHEN z.state = N'NOT_APPLICABLE' THEN N'NOT_APPLICABLE'
                WHEN z.state = N'NOT_SCHEDULED' THEN N'NOT_SCHEDULED'
                WHEN n.source = N'FAILED_RESULT' THEN N'FAILED'                                          -- 439
                WHEN i.activity_kind = N'RENEWAL' AND cv.version_id IS NOT NULL
                     AND ISNULL(cv.eff_end, CAST('9999-12-31' AS DATE)) >= n.next_due THEN N'COVERED'
                WHEN n.source = N'WAIVED_REVIEW' AND n.next_due > DATEADD(DAY, i.due_soon_days, @today) THEN N'WAIVED'   -- 439
                WHEN ISNULL(i.open_revised, n.next_due) < @today THEN N'OVERDUE'                         -- 439: revised due
                WHEN ISNULL(i.open_revised, n.next_due) <= DATEADD(DAY, i.due_soon_days, @today) THEN N'DUE_SOON'
                ELSE N'VALID' END,
           cv.version_id, cv.eff_end,
           CASE WHEN z.state = N'SCHEDULED' THEN i.open_revised END                                    -- 439"""),
("""     CROSS APPLY (SELECT
            CASE WHEN i.activity_kind = N'RENEWAL' THEN i.expiry
                 WHEN i.occ_done IS NOT NULL""",
"""     -- 439: a waiver lasts until its review date while nothing newer was
     -- recorded on the register; a failed result is re-tested after the
     -- re-test days (D72, D74).
     CROSS APPLY (SELECT CASE WHEN i.occ_status = N'WAIVED' AND i.occ_review IS NOT NULL
                               AND ((i.activity_kind = N'RENEWAL' AND (i.expiry IS NULL OR i.expiry <= i.occ_due))
                                    OR (i.activity_kind = N'EXECUTION' AND (i.field_last IS NULL OR i.field_last <= i.occ_due)))
                              THEN 1 ELSE 0 END AS waived,
                         CASE WHEN i.activity_kind = N'EXECUTION' AND i.occ_status = N'COMPLETED' AND i.occ_outcome = N'FAIL'
                               AND i.occ_done IS NOT NULL AND (i.field_last IS NULL OR i.occ_done >= i.field_last)
                              THEN 1 ELSE 0 END AS failed) w
     CROSS APPLY (SELECT
            CASE WHEN w.waived = 1 THEN i.occ_review                                                   -- 439
                 WHEN w.failed = 1 THEN DATEADD(DAY, ISNULL(i.retest_days, 0), i.occ_done)             -- 439
                 WHEN i.activity_kind = N'RENEWAL' THEN i.expiry
                 WHEN i.occ_done IS NOT NULL"""),
("""            CASE WHEN i.activity_kind = N'RENEWAL' THEN NULL
                 WHEN i.occ_done IS NOT NULL AND (i.field_last IS NULL OR i.occ_done >= i.field_last) THEN i.occ_done
                 ELSE i.field_last END AS last_done,
            CASE WHEN i.activity_kind = N'RENEWAL' THEN N'EXPIRY_FIELD'""",
"""            CASE WHEN i.activity_kind = N'RENEWAL' THEN NULL
                 WHEN i.occ_done IS NOT NULL AND (i.field_last IS NULL OR i.occ_done >= i.field_last) THEN i.occ_done
                 ELSE i.field_last END AS last_done,
            CASE WHEN w.waived = 1 THEN N'WAIVED_REVIEW'                                               -- 439
                 WHEN w.failed = 1 THEN N'FAILED_RESULT'                                               -- 439
                 WHEN i.activity_kind = N'RENEWAL' THEN N'EXPIRY_FIELD'"""),
("""            CASE WHEN ISNULL(i.required_val, N'') <> N'Yes' THEN N'NOT_APPLICABLE'
                 WHEN i.activity_kind = N'RENEWAL' AND i.expiry IS NULL THEN N'NOT_SCHEDULED'""",
"""            CASE WHEN ISNULL(i.required_val, N'') <> N'Yes' THEN N'NOT_APPLICABLE'
                 WHEN w.waived = 1 THEN N'SCHEDULED'                                                   -- 439
                 WHEN i.activity_kind = N'RENEWAL' AND i.expiry IS NULL THEN N'NOT_SCHEDULED'"""),
("""            CASE WHEN ISNULL(i.required_val, N'') <> N'Yes' THEN NULL
                 WHEN i.activity_kind = N'RENEWAL' AND i.expiry IS NULL""",
"""            CASE WHEN ISNULL(i.required_val, N'') <> N'Yes' THEN NULL
                 WHEN w.waived = 1 THEN NULL                                                           -- 439
                 WHEN i.activity_kind = N'RENEWAL' AND i.expiry IS NULL"""),
("""        (organization_id, asset_id, template_code, schedule_state, not_scheduled_reason, frequency_text, interval_value, interval_unit,
         basis, last_done_date, next_due_date, due_source, status_code, contract_version_id, coverage_end)
    SELECT @organization_id, asset_id, template_code, schedule_state, not_scheduled_reason, frequency_text, interval_value, interval_unit,
           basis, last_done_date, next_due_date, due_source, status_code, contract_version_id, coverage_end
      FROM #out;""",
"""        (organization_id, asset_id, template_code, schedule_state, not_scheduled_reason, frequency_text, interval_value, interval_unit,
         basis, last_done_date, next_due_date, due_source, status_code, contract_version_id, coverage_end,
         revised_due_date)                                                                                 -- 439
    SELECT @organization_id, asset_id, template_code, schedule_state, not_scheduled_reason, frequency_text, interval_value, interval_unit,
           basis, last_done_date, next_due_date, due_source, status_code, contract_version_id, coverage_end,
           revised_due_date
      FROM #out;"""),
])

# ---------------------------------------------------------------- generate
tx('sp_asset_activity_generate', [
("""    INSERT grac_practice.asset_activity_occurrence
        (organization_id, asset_id, template_code, due_date, sequence_no, occurrence_key, decision, decision_reason,
         contract_version_id, status, entered_by)""",
"""    INSERT grac_practice.asset_activity_occurrence
        (organization_id, asset_id, template_code, due_date, sequence_no, occurrence_key, decision, decision_reason,
         contract_version_id, status, entered_by, is_retest)                                       -- 439"""),
("""    SELECT @organization_id, s.asset_id, s.template_code, s.next_due_date, q.seq,
           CONCAT(N'AA-', s.template_code, N'-', s.asset_id, N'-', CONVERT(NVARCHAR(8), s.next_due_date, 112), N'-', q.seq),
           CASE WHEN s.status_code = N'COVERED' THEN N'CONTRACT_COVERED' ELSE N'ASSET_TASK' END,
           CASE WHEN s.status_code = N'COVERED'""",
"""    SELECT @organization_id, s.asset_id, s.template_code, s.next_due_date, q.seq,
           CONCAT(N'AA-', s.template_code, N'-', s.asset_id, N'-', CONVERT(NVARCHAR(8), s.next_due_date, 112), N'-', q.seq),
           CASE WHEN s.status_code = N'COVERED' THEN N'CONTRACT_COVERED' ELSE N'ASSET_TASK' END,
           CASE WHEN s.status_code = N'FAILED' THEN N'Re-test after a failed result (BRD 7.1.6). ' ELSE N'' END   -- 439
           + CASE WHEN s.due_source = N'WAIVED_REVIEW' THEN N'Review date of a waived occurrence (BRD 7.1.5). ' ELSE N'' END
           + CASE WHEN s.status_code = N'COVERED'"""),
("""           s.contract_version_id,
           CASE WHEN s.status_code = N'COVERED' THEN N'COVERED' ELSE N'OPEN' END, @actor
      FROM""",
"""           s.contract_version_id,
           CASE WHEN s.status_code = N'COVERED' THEN N'COVERED' ELSE N'OPEN' END, @actor,
           CASE WHEN s.status_code = N'FAILED' THEN 1 ELSE 0 END                                     -- 439
      FROM"""),
("""                          AND (z.status = N'OPEN' OR (z.due_date = s.next_due_date AND z.status IN (N'COMPLETED', N'COVERED'))));""",
"""                          AND (z.status = N'OPEN' OR (z.due_date = s.next_due_date AND z.status IN (N'COMPLETED', N'COVERED', N'WAIVED')
                                                       AND NOT (s.status_code = N'FAILED' AND z.status = N'COMPLETED' AND z.is_retest = 0))));   -- 439"""),
])

# ---------------------------------------------------------------- run
tx('sp_asset_activity_run', [
("""    @error_text      NVARCHAR(MAX) = NULL OUTPUT
AS""",
"""    @error_text      NVARCHAR(MAX) = NULL OUTPUT,
    @reviews         INT           = NULL OUTPUT      -- 439: restrictive-use reviews raised
AS"""),
("""    SELECT @tasks = 0, @opened = 0, @completed = 0, @errors = 0, @error_text = NULL;""",
"""    SELECT @tasks = 0, @opened = 0, @completed = 0, @errors = 0, @error_text = NULL, @reviews = 0;"""),
("""         @opened = @opened OUTPUT, @tasks = @tasks OUTPUT, @errors = @errors OUTPUT, @error_text = @error_text OUTPUT;
END""",
"""         @opened = @opened OUTPUT, @tasks = @tasks OUTPUT, @errors = @errors OUTPUT, @error_text = @error_text OUTPUT;
    -- 439: restrictive-use reviews (9.1.9).
    DECLARE @resolved INT;
    EXEC grac_practice.sp_asset_restrictive_review_sync @organization_id = @organization_id, @actor = @actor,
         @raised = @reviews OUTPUT, @resolved = @resolved OUTPUT;
END"""),
])

# ---------------------------------------------------------------- stored values
tx('fn_asset_stored_values', [
("""              WHEN t.status_field_key = N'maintenance_status' THEN
                   CASE s.status_code WHEN N'VALID' THEN N'Not Due' WHEN N'DUE_SOON' THEN N'Due Soon' WHEN N'OVERDUE' THEN N'Overdue' END
              ELSE CASE s.status_code WHEN N'VALID' THEN N'Valid' WHEN N'DUE_SOON' THEN N'Due Soon' WHEN N'OVERDUE' THEN N'Overdue'
                                      WHEN N'NOT_APPLICABLE' THEN N'N/A' END END)""",
"""              WHEN t.status_field_key = N'maintenance_status' THEN
                   CASE s.status_code WHEN N'VALID' THEN N'Not Due' WHEN N'DUE_SOON' THEN N'Due Soon' WHEN N'OVERDUE' THEN N'Overdue'
                                      WHEN N'FAILED' THEN N'Overdue' END                                   -- 439
              ELSE CASE s.status_code WHEN N'VALID' THEN N'Valid' WHEN N'DUE_SOON' THEN N'Due Soon' WHEN N'OVERDUE' THEN N'Overdue'
                                      WHEN N'NOT_APPLICABLE' THEN N'N/A' WHEN N'FAILED' THEN N'Failed' END END)   -- 439: Failed"""),
])

# ---------------------------------------------------------------- parties
tx('sp_asset_notification_parties', [
("""    DECLARE @org BIGINT, @otype NVARCHAR(30), @oid BIGINT, @asset BIGINT;
    SELECT @org = organization_id, @otype = object_type, @oid = object_id, @asset = asset_id
      FROM""",
"""    DECLARE @org BIGINT, @otype NVARCHAR(30), @oid BIGINT, @asset BIGINT, @ref BIGINT;              -- 439: @ref
    SELECT @org = organization_id, @otype = object_type, @oid = object_id, @asset = asset_id, @ref = ref_id
      FROM"""),
("""    ELSE IF @otype IN (N'ASSET_MODEL', N'ASSET_OS', N'ASSET_FIRMWARE')""",
"""    ELSE IF @otype = N'ASSET_EVIDENCE'                                                 -- 439
    BEGIN
        -- Evidence owner: the owner field named by the evidence catalogue
        -- (a person), else the asset owner (9.1 evidence / certificate expiry).
        INSERT @raw (party_code, val)
        SELECT TOP 1 N'ACTIVITY_OWNER', x.val
          FROM (SELECT 0 AS rk, LEFT(v.value_text, 100) AS val
                  FROM grac_practice.asset_field_definition fd
                  JOIN grac_practice.asset_evidence_field ef ON ef.field_key = fd.field_key
                  JOIN grac_practice.asset_field_definition f ON f.field_key = ef.owner_field_key
                  JOIN grac_practice.asset_field_value v ON v.asset_id = @asset AND v.field_definition_id = f.field_definition_id
                 WHERE fd.field_definition_id = @ref
                UNION ALL
                SELECT 1, r.val FROM @raw r WHERE r.party_code = N'ASSET_OWNER') x
         ORDER BY x.rk;
    END
    ELSE IF @otype IN (N'ASSET_MODEL', N'ASSET_OS', N'ASSET_FIRMWARE')"""),
])

# ---------------------------------------------------------------- sweep
tx('sp_asset_notification_sweep', [
("""    -- 438: recurring asset activities -- open asset-task occurrences by due date.
    INSERT #due (occurrence_key, activity_code, object_type, object_id, ref_id, asset_id, contract_id, trigger_date,
                 object_ref, object_title, severity_code)
    SELECT CONCAT(tp.notification_activity_code, N':ACT:', ao.occurrence_id, N':', CONVERT(NVARCHAR(8), ao.due_date, 112)),
           tp.notification_activity_code, N'ACTIVITY', ao.occurrence_id, NULL, ao.asset_id, cv.contract_id, ao.due_date,
           a.asset_name, CONCAT(tp.template_name, N' of ', a.asset_name),
           grac_practice.fn_asset_ntf_asset_severity(ao.asset_id)
      FROM grac_practice.asset_activity_occurrence ao
      JOIN grac_practice.asset_activity_template tp ON tp.template_code = ao.template_code
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = ao.asset_id
      LEFT JOIN grac_practice.asset_contract_version cv ON cv.version_id = ao.contract_version_id
     WHERE ao.organization_id = @org AND ao.status = N'OPEN' AND ao.decision = N'ASSET_TASK';""",
"""    -- 438: recurring asset activities -- open asset-task occurrences by due date.
    -- 439: by the approved revised due date when rescheduled (the old
    -- occurrence is superseded, not deleted); a re-test after a failed
    -- result with the fail policy on is Critical (9.1.4).
    INSERT #due (occurrence_key, activity_code, object_type, object_id, ref_id, asset_id, contract_id, trigger_date,
                 object_ref, object_title, severity_code)
    SELECT CONCAT(tp.notification_activity_code, N':ACT:', ao.occurrence_id, N':',
                  CONVERT(NVARCHAR(8), ISNULL(ao.revised_due_date, ao.due_date), 112)),                -- 439
           tp.notification_activity_code, N'ACTIVITY', ao.occurrence_id, NULL, ao.asset_id, cv.contract_id,
           ISNULL(ao.revised_due_date, ao.due_date),                                                   -- 439
           a.asset_name, CONCAT(tp.template_name, CASE WHEN ao.is_retest = 1 THEN N' re-test' ELSE N'' END, N' of ', a.asset_name),
           CASE WHEN ao.is_retest = 1 AND st.RestrictOnFail = 1 THEN N'CRITICAL'                        -- 439
                ELSE grac_practice.fn_asset_ntf_asset_severity(ao.asset_id) END
      FROM grac_practice.asset_activity_occurrence ao
      JOIN grac_practice.asset_activity_template tp ON tp.template_code = ao.template_code
      JOIN grac_practice.fn_asset_activity_settings(@org) st ON st.TemplateCode = ao.template_code      -- 439
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = ao.asset_id
      LEFT JOIN grac_practice.asset_contract_version cv ON cv.version_id = ao.contract_version_id
     WHERE ao.organization_id = @org AND ao.status = N'OPEN' AND ao.decision = N'ASSET_TASK';

    -- 439: evidence / certificate expiry (9.1.7) -- the evidence date fields of
    -- assets in use.
    INSERT #due (occurrence_key, activity_code, object_type, object_id, ref_id, asset_id, contract_id, trigger_date,
                 object_ref, object_title, severity_code)
    SELECT CONCAT(N'EVIDENCE_EXPIRY:EV:', u.asset_id, N':', fd.field_definition_id, N':', CONVERT(NVARCHAR(8), v.value_date, 112)),
           N'EVIDENCE_EXPIRY', N'ASSET_EVIDENCE', u.asset_id, fd.field_definition_id, u.asset_id, NULL, v.value_date,
           u.asset_name, CONCAT(ef.evidence_name, N' of ', u.asset_name, N' expires'), u.severity_code
      FROM @in_use u
      JOIN grac_practice.asset_field_value v ON v.asset_id = u.asset_id AND v.value_date IS NOT NULL
      JOIN grac_practice.asset_field_definition fd ON fd.field_definition_id = v.field_definition_id
      JOIN grac_practice.asset_evidence_field ef ON ef.field_key = fd.field_key AND ef.is_active = 1;"""),
])


# ---------------------------------------------------------------- config / settings readers-writers
tx('sp_asset_activity_config_get', [
("""           t.default_lead_days AS DefaultLeadDays, t.default_due_soon_days AS DefaultDueSoonDays,
           CASE WHEN s.organization_id IS NULL THEN 0 ELSE 1 END AS IsCustomized""",
"""           t.default_lead_days AS DefaultLeadDays, t.default_due_soon_days AS DefaultDueSoonDays,
           CASE WHEN s.organization_id IS NULL THEN 0 ELSE 1 END AS IsCustomized,
           -- 439: results, dispositions, restricted use
           st.ResultRequired, st.ResultReviewRequired, st.DispositionApprovalRequired, st.RestrictOnOverdue, st.RestrictOnFail,
           st.RetestDays, t.certificate_number_field_key AS CertificateNumberFieldKey,
           t.certificate_expiry_field_key AS CertificateExpiryFieldKey,
           t.default_result_review AS DefaultResultReview, t.default_disposition_approval AS DefaultDispositionApproval,
           ISNULL(t.default_restrict_on_overdue, N'NONE') AS DefaultRestrictOnOverdue, t.default_restrict_on_fail AS DefaultRestrictOnFail"""),
("""     ORDER BY employee_name;
END""",
"""     ORDER BY employee_name;
    -- 439: 3. the evidence date fields (evidence expiry notifications and reviews).
    SELECT ef.field_key AS FieldKey, ef.evidence_name AS EvidenceName, fd.display_label AS FieldLabel,
           ef.owner_field_key AS OwnerFieldKey, ef.restrict_on_expiry AS RestrictOnExpiry, ef.is_active AS IsActive
      FROM grac_practice.asset_evidence_field ef
      LEFT JOIN grac_practice.asset_field_definition fd ON fd.field_key = ef.field_key
     ORDER BY ef.display_order;
END"""),
])

tx('sp_asset_activity_setting_save', [
("""    @campaign_owner_employee_id BIGINT        = NULL,
    @actor                      NVARCHAR(100) = N'system'""",
"""    @campaign_owner_employee_id BIGINT        = NULL,
    @result_review_required        BIT           = NULL,     -- 439: NULL = the template default
    @disposition_approval_required BIT           = NULL,
    @restrict_on_overdue           NVARCHAR(100) = NULL,     -- ALL | NONE | CRITICAL,HIGH,MEDIUM,LOW
    @restrict_on_fail              BIT           = NULL,
    @actor                      NVARCHAR(100) = N'system'"""),
("""        THROW 54654, 'The campaign owner must be an active employee of the organization.', 1;""",
"""        THROW 54654, 'The campaign owner must be an active employee of the organization.', 1;
    -- 439: restricted-use policy on overdue.
    SET @restrict_on_overdue = NULLIF(UPPER(REPLACE(LTRIM(RTRIM(@restrict_on_overdue)), N' ', N'')), N'');
    IF @restrict_on_overdue IS NOT NULL AND @restrict_on_overdue NOT IN (N'ALL', N'NONE')
       AND EXISTS (SELECT 1 FROM STRING_SPLIT(@restrict_on_overdue, N',') x
                    WHERE x.value NOT IN (N'CRITICAL', N'HIGH', N'MEDIUM', N'LOW'))
        THROW 54691, 'The restricted-use policy is All, None or a list of Critical, High, Medium, Low.', 1;"""),
("""    DECLARE @before NVARCHAR(MAX) = (SELECT is_active AS isActive, lead_days AS leadDays, due_soon_days AS dueSoonDays,
                                            grouping_mode AS groupingMode, campaign_owner_employee_id AS campaignOwnerEmployeeId
                                       FROM""",
"""    DECLARE @before NVARCHAR(MAX) = (SELECT is_active AS isActive, lead_days AS leadDays, due_soon_days AS dueSoonDays,
                                            grouping_mode AS groupingMode, campaign_owner_employee_id AS campaignOwnerEmployeeId,
                                            result_review_required AS resultReviewRequired,                  -- 439
                                            disposition_approval_required AS dispositionApprovalRequired,
                                            restrict_on_overdue AS restrictOnOverdue, restrict_on_fail AS restrictOnFail
                                       FROM"""),
("""        campaign_owner_employee_id = @campaign_owner_employee_id, updated_by = @actor, updated_dt = SYSUTCDATETIME()
    WHEN NOT MATCHED THEN
        INSERT (organization_id, template_code, is_active, lead_days, due_soon_days, grouping_mode, campaign_owner_employee_id, entered_by)
        VALUES (@organization_id, @template_code, ISNULL(@is_active, 1), @lead_days, @due_soon_days, @grouping_mode,
                @campaign_owner_employee_id, @actor);""",
"""        campaign_owner_employee_id = @campaign_owner_employee_id, updated_by = @actor, updated_dt = SYSUTCDATETIME(),
        result_review_required = @result_review_required, disposition_approval_required = @disposition_approval_required,   -- 439
        restrict_on_overdue = @restrict_on_overdue, restrict_on_fail = @restrict_on_fail
    WHEN NOT MATCHED THEN
        INSERT (organization_id, template_code, is_active, lead_days, due_soon_days, grouping_mode, campaign_owner_employee_id, entered_by,
                result_review_required, disposition_approval_required, restrict_on_overdue, restrict_on_fail)            -- 439
        VALUES (@organization_id, @template_code, ISNULL(@is_active, 1), @lead_days, @due_soon_days, @grouping_mode,
                @campaign_owner_employee_id, @actor,
                @result_review_required, @disposition_approval_required, @restrict_on_overdue, @restrict_on_fail);"""),
("""                    @grouping_mode AS groupingMode, @campaign_owner_employee_id AS campaignOwnerEmployeeId FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),""",
"""                    @grouping_mode AS groupingMode, @campaign_owner_employee_id AS campaignOwnerEmployeeId,
                    @result_review_required AS resultReviewRequired, @disposition_approval_required AS dispositionApprovalRequired,   -- 439
                    @restrict_on_overdue AS restrictOnOverdue, @restrict_on_fail AS restrictOnFail FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),"""),
])

tx('sp_asset_activity_schedules', [
("""           s.due_source AS DueSource, s.status_code AS StatusCode,""",
"""           s.due_source AS DueSource, s.status_code AS StatusCode, s.revised_due_date AS RevisedDueDate,   -- 439"""),
("""     ORDER BY CASE s.status_code WHEN N'OVERDUE' THEN 0 WHEN N'DUE_SOON' THEN 1 WHEN N'VALID' THEN 2 WHEN N'COVERED' THEN 3
                                 WHEN N'NOT_SCHEDULED' THEN 4 ELSE 5 END,""",
"""     ORDER BY CASE s.status_code WHEN N'FAILED' THEN 0 WHEN N'OVERDUE' THEN 0 WHEN N'DUE_SOON' THEN 1 WHEN N'VALID' THEN 2   -- 439: FAILED
                                 WHEN N'WAIVED' THEN 3 WHEN N'COVERED' THEN 3 WHEN N'NOT_SCHEDULED' THEN 4 ELSE 5 END,"""),
])

tx('sp_asset_activity_occurrences', [
("""    @campaign_id     BIGINT        = NULL,
    @search          NVARCHAR(200) = NULL,""",
"""    @campaign_id     BIGINT        = NULL,
    @search          NVARCHAR(200) = NULL,
    @awaiting_decision BIT         = 0,        -- 439: a submitted result or a pending disposition"""),
("""           CONVERT(BIGINT, o.record_version) AS RecordVersion,
           COUNT(*) OVER () AS TotalRows""",
"""           CONVERT(BIGINT, o.record_version) AS RecordVersion,
           o.revised_due_date AS RevisedDueDate, o.review_date AS ReviewDate, o.is_retest AS IsRetest,          -- 439
           rs.state AS ResultState, rs.outcome AS ResultOutcome, pd.disposition_type AS PendingDispositionType,
           COUNT(*) OVER () AS TotalRows"""),
("""      LEFT JOIN grac_practice.organization_employee cb ON cb.employee_id = o.completed_by_employee_id
     WHERE""",
"""      LEFT JOIN grac_practice.organization_employee cb ON cb.employee_id = o.completed_by_employee_id
      LEFT JOIN grac_practice.asset_activity_result rs ON rs.occurrence_id = o.occurrence_id                         -- 439
      LEFT JOIN grac_practice.asset_activity_disposition pd ON pd.occurrence_id = o.occurrence_id AND pd.status = N'PENDING'
     WHERE"""),
("""       AND (@search IS NULL OR a.asset_name LIKE N'%' + @search + N'%' OR o.occurrence_key LIKE N'%' + @search + N'%')
     ORDER BY o.due_date, o.occurrence_id""",
"""       AND (@search IS NULL OR a.asset_name LIKE N'%' + @search + N'%' OR o.occurrence_key LIKE N'%' + @search + N'%')
       AND (ISNULL(@awaiting_decision, 0) = 0 OR rs.state = N'SUBMITTED' OR pd.disposition_id IS NOT NULL)          -- 439
     ORDER BY o.due_date, o.occurrence_id"""),
])

for n, s in out.items():
    open(B + 'new_' + n + '.sql', 'w', encoding='utf-8', newline='').write(s)
print('re-issues built:', len(out))
