CREATE OR ALTER PROCEDURE grac_practice.sp_asset_ci_impact
    @organization_id         BIGINT,
    @ci_kind                 NVARCHAR(12),
    @ci_id                   BIGINT,
    @direction               NVARCHAR(10)  = N'DOWNSTREAM',
    @max_depth               INT           = 5,
    @critical_only           BIT           = 0,
    @preview_relationship_id BIGINT        = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET @ci_kind = UPPER(LTRIM(RTRIM(ISNULL(@ci_kind, N''))));
    SET @direction = UPPER(LTRIM(RTRIM(ISNULL(@direction, N'DOWNSTREAM'))));
    SET @max_depth = CASE WHEN ISNULL(@max_depth, 5) < 1 THEN 1 WHEN @max_depth > 10 THEN 10 ELSE @max_depth END;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54701, 'Organization not found.', 1;
    IF @direction NOT IN (N'DOWNSTREAM', N'UPSTREAM')
       OR NOT EXISTS (SELECT 1 FROM grac_practice.fn_asset_ci_catalog(@organization_id) WHERE CiKind = @ci_kind AND CiId = @ci_id)
        THROW 54720, 'Select a configuration item of this organization and the direction (downstream or upstream).', 1;

    CREATE TABLE #edge (rel BIGINT NOT NULL, type_code NVARCHAR(30) NOT NULL, crit BIT NOT NULL,
                        dk NVARCHAR(12) NOT NULL, di BIGINT NOT NULL, pk NVARCHAR(12) NOT NULL, pi BIGINT NOT NULL);
    INSERT #edge (rel, type_code, crit, dk, di, pk, pi)
    SELECT RelationshipId, TypeCode, IsCritical, DependentKind, DependentId, ProviderKind, ProviderId
      FROM grac_practice.fn_asset_relationship_edges(@organization_id, 1)
     WHERE ISNULL(@critical_only, 0) = 0 OR IsCritical = 1;
    IF @preview_relationship_id IS NOT NULL
        INSERT #edge (rel, type_code, crit, dk, di, pk, pi)
        SELECT e.RelationshipId, e.TypeCode, e.IsCritical, e.DependentKind, e.DependentId, e.ProviderKind, e.ProviderId
          FROM grac_practice.fn_asset_relationship_edges(@organization_id, 0) e
         WHERE e.RelationshipId = @preview_relationship_id
           AND NOT EXISTS (SELECT 1 FROM #edge x WHERE x.rel = e.RelationshipId);

    CREATE TABLE #seen (k NVARCHAR(12) NOT NULL, i BIGINT NOT NULL, lvl INT NOT NULL, rel BIGINT NULL,
                        from_k NVARCHAR(12) NULL, from_i BIGINT NULL, PRIMARY KEY (k, i));
    INSERT #seen (k, i, lvl) VALUES (@ci_kind, @ci_id, 0);
    DECLARE @lvl INT = 0;
    WHILE @lvl < @max_depth
    BEGIN
        -- one row per newly reached CI: the lowest relationship id reaching it from this level
        INSERT #seen (k, i, lvl, rel, from_k, from_i)
        SELECT x.k, x.i, @lvl + 1, x.rel, x.from_k, x.from_i
          FROM (SELECT CASE WHEN @direction = N'DOWNSTREAM' THEN e.dk ELSE e.pk END AS k,
                       CASE WHEN @direction = N'DOWNSTREAM' THEN e.di ELSE e.pi END AS i,
                       e.rel, s.k AS from_k, s.i AS from_i,
                       ROW_NUMBER() OVER (PARTITION BY CASE WHEN @direction = N'DOWNSTREAM' THEN e.dk ELSE e.pk END,
                                                       CASE WHEN @direction = N'DOWNSTREAM' THEN e.di ELSE e.pi END
                                          ORDER BY e.crit DESC, e.rel) AS rn
                  FROM #edge e
                  JOIN #seen s ON s.lvl = @lvl
                              AND ((@direction = N'DOWNSTREAM' AND s.k = e.pk AND s.i = e.pi)
                                   OR (@direction = N'UPSTREAM' AND s.k = e.dk AND s.i = e.di))) x
         WHERE x.rn = 1
           AND NOT EXISTS (SELECT 1 FROM #seen z WHERE z.k = x.k AND z.i = x.i);
        IF @@ROWCOUNT = 0 BREAK;
        SET @lvl = @lvl + 1;
    END

    SELECT s.k AS CiKind, s.i AS CiId, c.CiName, c.CiClass, c.CiStatus, s.lvl AS ImpactLevel, s.rel AS ViaRelationshipId,
           e.type_code AS ViaTypeCode,
           CASE WHEN @direction = N'DOWNSTREAM' THEN
                     CASE t.dependent_side WHEN N'SOURCE' THEN t.type_name ELSE t.inverse_label END
                ELSE CASE t.dependent_side WHEN N'SOURCE' THEN t.inverse_label ELSE t.type_name END END AS ViaLabel,
           e.crit AS ViaCritical, s.from_k AS FromKind, s.from_i AS FromId, fc.CiName AS FromName,
           CAST(CASE WHEN e.rel = @preview_relationship_id THEN 1 ELSE 0 END AS BIT) AS ViaPreview
      FROM #seen s
      JOIN #edge e ON e.rel = s.rel
      JOIN grac_practice.asset_relationship_type t ON t.type_code = e.type_code
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) c ON c.CiKind = s.k AND c.CiId = s.i
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) fc ON fc.CiKind = s.from_k AND fc.CiId = s.from_i
     WHERE s.lvl > 0
     ORDER BY s.lvl, c.CiKind, c.CiName;

    SELECT @ci_kind AS CiKind, @ci_id AS CiId, (SELECT CiName FROM grac_practice.fn_asset_ci_catalog(@organization_id)
                                                  WHERE CiKind = @ci_kind AND CiId = @ci_id) AS CiName,
           @direction AS Direction, @max_depth AS MaxDepth,
           (SELECT COUNT(*) FROM #seen WHERE lvl > 0) AS ReachedCount,
           (SELECT COUNT(*) FROM #seen s JOIN #edge e ON e.rel = s.rel WHERE s.lvl > 0 AND e.crit = 1) AS CriticalCount,
           (SELECT MAX(lvl) FROM #seen) AS DeepestLevel;

    -- 441: business services reached.
    SELECT s.i AS ServiceId, b.service_code AS ServiceCode, b.service_name AS ServiceName, b.service_type AS ServiceType,
           b.status AS ServiceStatus, s.lvl AS ImpactLevel, cm.criticality_code AS CriticalityCode, b.rto_hours AS RtoHours,
           b.rpo_hours AS RpoHours, b.mtpd_hours AS MtpdHours, bo.employee_name AS BusinessOwnerName,
           sm.employee_name AS ServiceManagerName, cn.Consumers
      FROM #seen s
      JOIN grac_practice.business_service b ON b.service_id = s.i
      LEFT JOIN grac_practice.criticality_master cm ON cm.criticality_id = b.criticality_id
      LEFT JOIN grac_practice.organization_employee bo ON bo.employee_id = b.business_owner_employee_id
      LEFT JOIN grac_practice.organization_employee sm ON sm.employee_id = b.service_manager_employee_id
     OUTER APPLY (SELECT STRING_AGG(c.ConsumerName, N', ') AS Consumers
                    FROM grac_practice.fn_business_service_consumers(b.service_id) c) cn
     WHERE s.k = N'SERVICE' AND s.lvl > 0
     ORDER BY s.lvl, b.service_name;
END
GO
