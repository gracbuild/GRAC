import sys
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w447/new'
A=R+'/src/PracticeManagement.Api/'
def edit(path, old, new, count=1):
    s=open(path).read()
    assert s.count(old)==count, (path, old[:80], s.count(old))
    open(path,'w').write(s.replace(old,new))

edit(A+'Models/AssetConfigModels.cs', """public sealed record AssetValuationRecalcRunRequest(long OrganizationId, string? Reason, int? ExpectedAffected);
""", """public sealed record AssetValuationRecalcRunRequest(long OrganizationId, string? Reason, int? ExpectedAffected);

// ---------------------------------------------------------------------
// CIA and criticality consistency rules (migration 447)
// ---------------------------------------------------------------------
/// <summary>One condition: conditions with the same GroupNo are ANDed, groups are ORed (421 semantics).
/// OperatorCode EQ | NEQ | IN | NOT_IN (values separated by |) | EMPTY | NOT_EMPTY | GT | GTE | LT | LTE |
/// DATE_BEFORE_TODAY | DATE_AFTER_TODAY | DATE_WITHIN_DAYS.</summary>
public sealed record AssetConsistencyConditionItem(int? GroupNo, string? OperandKey, string? OperatorCode, string? CompareValue);

/// <summary>New rule (RuleId null -> version 1 Draft) or a Draft change. ScopeKind TENANT | CATEGORY | SUBCATEGORY |
/// ASSET_TYPE | SERVICE (+ ScopeRefId); Severity INFO | WARNING | ERROR | APPROVAL_REQUIRED; ActionCode WARN |
/// REQUIRE_RATIONALE | CREATE_TASK | BLOCK_TRANSITION.</summary>
public sealed record AssetConsistencyRuleSaveRequest(
    long                                 OrganizationId,
    long?                                RuleId,
    string?                              RuleName,
    string?                              Description,
    string?                              ScopeKind,
    long?                                ScopeRefId,
    string?                              Severity,
    string?                              ActionCode,
    bool?                                OverrideAllowed,
    int?                                 MaxOverrideDays,
    DateTime?                            EffectiveFrom,
    DateTime?                            EffectiveTo,
    string?                              ChangeReason,
    List<AssetConsistencyConditionItem>? Conditions,
    long?                                ExpectedRecordVersion);

/// <summary>ACTIVATE | RETIRE (reason) | NEW_VERSION (reason) | DISCARD.</summary>
public sealed record AssetConsistencyRuleActionRequest(long OrganizationId, string? Action, string? Reason, long? ExpectedRecordVersion);

/// <summary>ACCEPT (rationale, owner, review date; evidence for Error / Approval Required) | WITHDRAW |
/// APPROVE | REJECT (note) | REVOKE (note).</summary>
public sealed record AssetConsistencyFindingActionRequest(
    long      OrganizationId,
    string?   Action,
    string?   Rationale,
    string?   Evidence,
    long?     OwnerEmployeeId,
    DateTime? ReviewDate,
    string?   Note,
    long?     ExpectedRecordVersion);

/// <summary>Re-evaluate one asset (AssetId) or the whole organization.</summary>
public sealed record AssetConsistencyRunRequest(long OrganizationId, long? AssetId);
""")

S=A+'Services/AssetConfigService.cs'
edit(S, """    Task<AssetLifecycleResult> RunValuationRecalcAsync(AssetValuationRecalcRunRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
}
""", """    Task<AssetLifecycleResult> RunValuationRecalcAsync(AssetValuationRecalcRunRequest request, long? actorEmployeeId, string actor, CancellationToken ct);

    // 447 -- CIA and criticality consistency rules
    Task<object> ListConsistencyRulesAsync(long organizationId, CancellationToken ct);
    Task<object?> GetConsistencyRuleAsync(long organizationId, long ruleId, CancellationToken ct);
    Task<object> GetConsistencyOperandsAsync(long organizationId, CancellationToken ct);
    Task<object?> PreviewConsistencyRuleAsync(long organizationId, long ruleId, CancellationToken ct);
    Task<AssetLifecycleResult> SaveConsistencyRuleAsync(AssetConsistencyRuleSaveRequest request, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> ConsistencyRuleActionAsync(long ruleId, AssetConsistencyRuleActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<object> ListConsistencyFindingsAsync(long organizationId, string? status, string? severity, long? assetId, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<AssetLifecycleResult> ConsistencyFindingActionAsync(long findingId, AssetConsistencyFindingActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> RunConsistencyAsync(AssetConsistencyRunRequest request, string actor, CancellationToken ct);
}
""")
edit(S, """            var current = await ReadRowsAsync(reader, ct);
            var history = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
            return new { current = current.Count > 0 ? current[0] : null, history };""", """            var current = await ReadRowsAsync(reader, ct);
            var empty = new List<Dictionary<string, object?>>();
            var history  = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var risks    = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;   // 447
            var findings = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;   // 447
            return new { current = current.Count > 0 ? current[0] : null, history, risks, findings };""")
edit(S, """    public async Task<object> GetBusinessServiceTreeAsync(""", """    // ----------------------------------------------------------------
    // 447 -- CIA and criticality consistency rules
    // ----------------------------------------------------------------
    public async Task<object> ListConsistencyRulesAsync(long organizationId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_consistency_rules");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        return await ReadRowsAsync(reader, ct);
    }

    public async Task<object?> GetConsistencyRuleAsync(long organizationId, long ruleId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_consistency_rule_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@rule_id",         DbType.Int64, ruleId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var empty = new List<Dictionary<string, object?>>();
            var rule       = await ReadRowsAsync(reader, ct);
            var conditions = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var versions   = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            return new { rule = rule.Count > 0 ? rule[0] : null, conditions, versions };
        }
        catch (SqlException ex) when (ex.Number == 53011) { return null; }
    }

    public async Task<object> GetConsistencyOperandsAsync(long organizationId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_consistency_operands");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var operands = await ReadRowsAsync(reader, ct);
        var scopes = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
        return new { operands, scopes };
    }

    public async Task<object?> PreviewConsistencyRuleAsync(long organizationId, long ruleId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_consistency_rule_preview");
            command.CommandTimeout = 120;   // evaluates every asset of the organization
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@rule_id",         DbType.Int64, ruleId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var summary = await ReadRowsAsync(reader, ct);
            var assets = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
            return new { summary = summary.Count > 0 ? summary[0] : null, assets };
        }
        catch (SqlException ex) when (ex.Number == 53011) { return null; }
    }

    public Task<AssetLifecycleResult> SaveConsistencyRuleAsync(AssetConsistencyRuleSaveRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_consistency_rule_save", "ruleId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,   request.OrganizationId);
            AddParam(command, "@rule_id",                 DbType.Int64,   request.RuleId);
            AddParam(command, "@rule_name",               DbType.String,  Blank(request.RuleName), 200);
            AddParam(command, "@description",             DbType.String,  Blank(request.Description), 1000);
            AddParam(command, "@scope_kind",              DbType.String,  Blank(request.ScopeKind) ?? "TENANT", 12);
            AddParam(command, "@scope_ref_id",            DbType.Int64,   request.ScopeRefId);
            AddParam(command, "@severity",                DbType.String,  Blank(request.Severity), 20);
            AddParam(command, "@action_code",             DbType.String,  Blank(request.ActionCode), 20);
            AddParam(command, "@override_allowed",        DbType.Boolean, request.OverrideAllowed ?? true);
            AddParam(command, "@max_override_days",       DbType.Int32,   request.MaxOverrideDays);
            AddParam(command, "@effective_from",          DbType.Date,    request.EffectiveFrom?.Date);
            AddParam(command, "@effective_to",            DbType.Date,    request.EffectiveTo?.Date);
            AddParam(command, "@change_reason",           DbType.String,  Blank(request.ChangeReason), 1000);
            AddParam(command, "@conditions_json",         DbType.String,  System.Text.Json.JsonSerializer.Serialize(
                (request.Conditions ?? new List<AssetConsistencyConditionItem>()).Select(c => new
                {
                    groupNo = c.GroupNo ?? 1, operandKey = c.OperandKey, operatorCode = c.OperatorCode, compareValue = c.CompareValue
                })));
            AddParam(command, "@expected_record_version", DbType.Int64,   request.ExpectedRecordVersion);
            AddParam(command, "@actor",                   DbType.String,  actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> ConsistencyRuleActionAsync(long ruleId, AssetConsistencyRuleActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_consistency_rule_action", "ruleId", command =>
        {
            command.CommandTimeout = 300;   // ACTIVATE / RETIRE re-evaluate the organization
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@rule_id",                 DbType.Int64,  ruleId);
            AddParam(command, "@action",                  DbType.String, Blank(request.Action), 12);
            AddParam(command, "@reason",                  DbType.String, Blank(request.Reason), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public async Task<object> ListConsistencyFindingsAsync(long organizationId, string? status, string? severity, long? assetId, string? search,
        int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_consistency_findings");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 20);
        AddParam(command, "@severity",        DbType.String, Blank(severity), 20);
        AddParam(command, "@asset_id",        DbType.Int64,  assetId);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        var counts = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize, counts };
    }

    public Task<AssetLifecycleResult> ConsistencyFindingActionAsync(long findingId, AssetConsistencyFindingActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_consistency_finding_action", "findingId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@finding_id",              DbType.Int64,  findingId);
            AddParam(command, "@action",                  DbType.String, Blank(request.Action), 12);
            AddParam(command, "@rationale",               DbType.String, Blank(request.Rationale), 1000);
            AddParam(command, "@evidence",                DbType.String, Blank(request.Evidence), 1000);
            AddParam(command, "@owner_employee_id",       DbType.Int64,  request.OwnerEmployeeId);
            AddParam(command, "@review_date",             DbType.Date,   request.ReviewDate?.Date);
            AddParam(command, "@note",                    DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> RunConsistencyAsync(AssetConsistencyRunRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_consistency_run", "organizationId", command =>
        {
            command.CommandTimeout = 300;
            AddParam(command, "@organization_id", DbType.Int64,  request.OrganizationId);
            AddParam(command, "@asset_id",        DbType.Int64,  request.AssetId);
            AddParam(command, "@actor",           DbType.String, actor, 100);
        }, ct);

    public async Task<object> GetBusinessServiceTreeAsync(""")

C=A+'Controllers/AssetConfigController.cs'
edit(C, """//   POST valuation/recalculation                     controlled recalculation run (reason, expectedAffected)
//
""", """//   POST valuation/recalculation                     controlled recalculation run (reason, expectedAffected)
//   GET  register/{id}/valuation now also returns risks (linked risks, review flag) and findings (447)
//   GET  valuation/consistency/rules?organizationId=  consistency rules, every version (447)
//   GET  valuation/consistency/rules/{id}?organizationId=   rule, conditions, versions
//   GET  valuation/consistency/rules/{id}/preview?organizationId=   in-scope and matching assets (bulk preview)
//   GET  valuation/consistency/operands?organizationId=   operands and scope choices
//   POST valuation/consistency/rules                 new rule (v1 Draft) or Draft change
//   POST valuation/consistency/rules/{id}/action     ACTIVATE | RETIRE | NEW_VERSION | DISCARD
//   GET  register/consistency/findings?organizationId=&status=&severity=&assetId=&search=&pageNumber=&pageSize=
//   POST register/consistency/findings/{id}/action   ACCEPT | WITHDRAW | APPROVE | REJECT | REVOKE
//   POST register/consistency/run                    re-evaluate one asset or the organization
//
""")
edit(C, """    // 446: 53000 (asset), 53007 (organization) -> 404;""", """    // ---------------------------------------------------------------- 447: consistency rules
    [HttpGet("valuation/consistency/rules")]
    public Task<IActionResult> ConsistencyRules([FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListConsistencyRulesAsync(organizationId.Value, ct), "consistency rules");
    }

    [HttpGet("valuation/consistency/rules/{ruleId:long}")]
    public Task<IActionResult> ConsistencyRule(long ruleId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetConsistencyRuleAsync(o, ruleId, ct), "Consistency rule not found.", "consistency rule");

    [HttpGet("valuation/consistency/rules/{ruleId:long}/preview")]
    public Task<IActionResult> ConsistencyRulePreview(long ruleId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.PreviewConsistencyRuleAsync(o, ruleId, ct), "Consistency rule not found.", "consistency preview");

    [HttpGet("valuation/consistency/operands")]
    public Task<IActionResult> ConsistencyOperands([FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.GetConsistencyOperandsAsync(organizationId.Value, ct), "consistency operands");
    }

    [HttpPost("valuation/consistency/rules")]
    public async Task<IActionResult> SaveConsistencyRule([FromBody] AssetConsistencyRuleSaveRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveConsistencyRuleAsync(request, Actor, ct), ConsistencyNotFound, ConsistencyConflict);
    }

    [HttpPost("valuation/consistency/rules/{ruleId:long}/action")]
    public async Task<IActionResult> ConsistencyRuleAction(long ruleId, [FromBody] AssetConsistencyRuleActionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Action)) return BadRequest(new { error = "action is required." });
        return ResultWritten(await service.ConsistencyRuleActionAsync(ruleId, request, ActorEmployeeId, Actor, ct), ConsistencyNotFound, ConsistencyConflict);
    }

    [HttpGet("register/consistency/findings")]
    public Task<IActionResult> ConsistencyFindings([FromQuery] long? organizationId, [FromQuery] string? status, [FromQuery] string? severity,
        [FromQuery] long? assetId, [FromQuery] string? search, [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListConsistencyFindingsAsync(organizationId.Value, status, severity, assetId, search,
            pageNumber ?? 1, pageSize ?? 25, ct), "consistency findings");
    }

    [HttpPost("register/consistency/findings/{findingId:long}/action")]
    public async Task<IActionResult> ConsistencyFindingAction(long findingId, [FromBody] AssetConsistencyFindingActionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Action)) return BadRequest(new { error = "action is required." });
        return ResultWritten(await service.ConsistencyFindingActionAsync(findingId, request, ActorEmployeeId, Actor, ct), ConsistencyNotFound, ConsistencyConflict);
    }

    [HttpPost("register/consistency/run")]
    public async Task<IActionResult> RunConsistency([FromBody] AssetConsistencyRunRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.RunConsistencyAsync(request, Actor, ct), ConsistencyNotFound, ConsistencyConflict);
    }

    // 447: 53010 (organization), 53011 (rule), 53030 (finding) -> 404; 53013 / 53036 (changed by someone else),
    //      53019 (a Draft exists) -> 409; others -> 400.
    private static readonly int[] ConsistencyNotFound = { 53010, 53011, 53030 };
    private static readonly int[] ConsistencyConflict = { 53013, 53019, 53036 };

    // 446: 53000 (asset), 53007 (organization) -> 404;""")
# 53037 from lifecycle transition -> 409? It is a gate refusal like 54560 -> 400 (unchanged mapping).
print('api patched')
