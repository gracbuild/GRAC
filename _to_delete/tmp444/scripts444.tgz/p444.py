# 444: API + Web proxy for asset merges.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    open(path, 'w', encoding='utf-8', newline='').write(s)
API = "src/PracticeManagement.Api/"
WEB = "src/PracticeManagement.Web/"

edit(API + "Models/AssetConfigModels.cs", [(
"""public sealed record AssetStaleReviewActionRequest(long OrganizationId, string? Action, string? SourceOutcome, string? Note, long? ExpectedRecordVersion);
""",
"""public sealed record AssetStaleReviewActionRequest(long OrganizationId, string? Action, string? SourceOutcome, string? Note, long? ExpectedRecordVersion);

// ---------------------------------------------------------------------
// Asset merge (migration 444)
// ---------------------------------------------------------------------
/// <summary>Draft merge: survivor, 1-10 duplicates, reason, field choices (field key -> duplicate asset id).</summary>
public sealed record AssetMergeSaveRequest(
    long                      OrganizationId,
    long?                     EventId,
    long                      SurvivorAssetId,
    List<long>?               DuplicateAssetIds,
    string?                   Reason,
    Dictionary<string, long>? FieldChoices,
    long?                     ExpectedRecordVersion);

/// <summary>SUBMIT | CANCEL | APPROVE | REJECT | EXECUTE | RECOVER (note required for CANCEL, REJECT, RECOVER).</summary>
public sealed record AssetMergeActionRequest(long OrganizationId, string? Action, string? Note, long? ExpectedRecordVersion);
""")])

edit(API + "Services/AssetConfigService.cs", [
("""//   sp_asset_stale_* / sp_asset_discovery_candidate_get (443 -- stale review, candidate registration)
""",
"""//   sp_asset_stale_* / sp_asset_discovery_candidate_get (443 -- stale review, candidate registration)
//   sp_asset_merge_* (444 -- merge events, plan, approval, execution, recovery)
"""),
("""    Task<AssetLifecycleResult> StaleReviewActionAsync(long reviewId, AssetStaleReviewActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
""",
"""    Task<AssetLifecycleResult> StaleReviewActionAsync(long reviewId, AssetStaleReviewActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);

    // 444 -- Asset merge
    Task<object> ListMergesAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<object?> GetMergeAsync(long organizationId, long eventId, CancellationToken ct);
    Task<AssetLifecycleResult> SaveMergeAsync(AssetMergeSaveRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> MergeActionAsync(long eventId, AssetMergeActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
"""),
("""    public async Task<object> GetBusinessServiceTreeAsync(""",
"""    // ----------------------------------------------------------------
    // 444 -- Asset merge
    // ----------------------------------------------------------------
    public async Task<object> ListMergesAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_merge_events");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 20);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object?> GetMergeAsync(long organizationId, long eventId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_merge_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@event_id",        DbType.Int64, eventId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var merge = await ReadRowsAsync(reader, ct);
            if (merge.Count == 0) return null;
            var empty = new List<Dictionary<string, object?>>();
            var assets = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var approvals = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var blockers = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var plan = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var outcomes = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var fields = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var impact = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            return new { merge = merge[0], assets, approvals, blockers, plan, outcomes, fields, impact };
        }
        catch (SqlException ex) when (ex.Number == 52902) { return null; }
    }

    public Task<AssetLifecycleResult> SaveMergeAsync(AssetMergeSaveRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_merge_save", "eventId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@event_id",                DbType.Int64,  request.EventId);
            AddParam(command, "@survivor_asset_id",       DbType.Int64,  request.SurvivorAssetId);
            AddParam(command, "@duplicates_json",         DbType.String,
                System.Text.Json.JsonSerializer.Serialize(request.DuplicateAssetIds ?? new List<long>()));
            AddParam(command, "@reason",                  DbType.String, Blank(request.Reason), 1000);
            AddParam(command, "@field_choices_json",      DbType.String,
                request.FieldChoices is { Count: > 0 } choices ? System.Text.Json.JsonSerializer.Serialize(choices) : null);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> MergeActionAsync(long eventId, AssetMergeActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_merge_action", "eventId", command =>
        {
            command.CommandTimeout = 300;   // EXECUTE / RECOVER walk every object of up to 10 duplicates
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@event_id",                DbType.Int64,  eventId);
            AddParam(command, "@action",                  DbType.String, Blank(request.Action), 10);
            AddParam(command, "@note",                    DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public async Task<object> GetBusinessServiceTreeAsync("""),
])

edit(API + "Controllers/AssetConfigController.cs", [
("""//   POST discovery/stale/reviews/{id}/action         CONFIRM_SOURCE | REVIEW_DEPENDENCIES | DISMISS | REQUEST_DECOMMISSION
""",
"""//   POST discovery/stale/reviews/{id}/action         CONFIRM_SOURCE | REVIEW_DEPENDENCIES | DISMISS | REQUEST_DECOMMISSION
//   GET  discovery/merges?organizationId=&status=&search=&pageNumber=&pageSize=   merge events (444)
//   GET  discovery/merges/{id}?organizationId=       event, assets, approvals, blockers, plan, outcomes, fields, impact
//   POST discovery/merges                            new / changed draft merge
//   POST discovery/merges/{id}/action                SUBMIT | CANCEL | APPROVE | REJECT | EXECUTE | RECOVER
"""),
("""    private static readonly int[] StaleConflict = { 54785 };
""",
"""    private static readonly int[] StaleConflict = { 54785 };

    // ---------------------------------------------------------------- 444: asset merge
    [HttpGet("discovery/merges")]
    public Task<IActionResult> Merges([FromQuery] long? organizationId, [FromQuery] string? status, [FromQuery] string? search,
        [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListMergesAsync(organizationId.Value, status, search, pageNumber ?? 1, pageSize ?? 25, ct), "merges");
    }

    [HttpGet("discovery/merges/{eventId:long}")]
    public Task<IActionResult> Merge(long eventId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetMergeAsync(o, eventId, ct), "Merge not found.", "merge");

    [HttpPost("discovery/merges")]
    public async Task<IActionResult> SaveMerge([FromBody] AssetMergeSaveRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (request.SurvivorAssetId <= 0) return BadRequest(new { error = "survivorAssetId is required." });
        return ResultWritten(await service.SaveMergeAsync(request, ActorEmployeeId, Actor, ct), MergeNotFound, MergeConflict);
    }

    [HttpPost("discovery/merges/{eventId:long}/action")]
    public async Task<IActionResult> MergeAction(long eventId, [FromBody] AssetMergeActionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Action)) return BadRequest(new { error = "action is required." });
        return ResultWritten(await service.MergeActionAsync(eventId, request, ActorEmployeeId, Actor, ct), MergeNotFound, MergeConflict);
    }

    // 444: 52900 (organization), 52901 (asset), 52902 (merge) -> 404; 52903 (stale) -> 409.
    private static readonly int[] MergeNotFound = { 52900, 52901, 52902 };
    private static readonly int[] MergeConflict = { 52903 };
"""),
])

edit(WEB + "Controllers/AssetConfigController.cs", [
("""//                                      REQUEST_DECOMMISSION also needs asset-register EDIT (lifecycle move)
""",
"""//                                      REQUEST_DECOMMISSION also needs asset-register EDIT (lifecycle move)
//                                      444: merges (draft) EDIT; merges/{id}/action APPROVE / REJECT / RECOVER
//                                      -> APPROVE, SUBMIT / CANCEL -> EDIT, EXECUTE -> EDIT + asset-register EDIT;
//                                      RECOVER also needs asset-register EDIT
"""),
("""            : isDiscovery && lower.StartsWith("discovery/stale/reviews/") && lower.EndsWith("/action")   // 443
""",
"""            : isDiscovery && lower.StartsWith("discovery/merges/") && lower.EndsWith("/action")   // 444
            ? (exceptionAction is "APPROVE" or "REJECT" ? Can(area, "APPROVE")
               : exceptionAction == "RECOVER" ? Can(area, "APPROVE") && Can(RegisterArea, "EDIT")
               : exceptionAction == "EXECUTE" ? Can(area, "EDIT") && Can(RegisterArea, "EDIT")
               : Can(area, "EDIT"))
            : isDiscovery && lower == "discovery/merges"                                              // 444
            ? Can(area, "EDIT")
            : isDiscovery && lower.StartsWith("discovery/stale/reviews/") && lower.EndsWith("/action")   // 443
"""),
])
print("p444 ok")
