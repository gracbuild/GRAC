-- =====================================================================
-- 8. Menu: Asset & Contract -> Business Services (also carried in 274)
-- =====================================================================
MERGE grac_practice.menu_master AS t
USING (VALUES
    (N'business-services', N'Business Services', N'Practice/Index/business-services', 362, N'sitemap', N'Asset & Contract')
) AS s(menu_key, menu_name, menu_url, display_order, icon_class, module_type)
ON t.menu_key = s.menu_key
WHEN MATCHED AND (ISNULL(t.menu_name, N'') <> s.menu_name OR ISNULL(t.menu_url, N'') <> s.menu_url
               OR t.display_order <> s.display_order OR ISNULL(t.icon_class, N'') <> s.icon_class
               OR ISNULL(t.module_type, N'') <> s.module_type OR t.status <> N'Active') THEN UPDATE SET
    menu_name = s.menu_name, menu_url = s.menu_url, display_order = s.display_order, icon_class = s.icon_class,
    module_type = s.module_type, status = N'Active', updated_by = N'seed-441', updated_dt = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (menu_key, menu_name, menu_url, display_order, icon_class, module_type, status, entered_by)
    VALUES (s.menu_key, s.menu_name, s.menu_url, s.display_order, s.icon_class, s.module_type, N'Active', N'seed-441');
PRINT CONCAT('441: menu row upserted: ', @@ROWCOUNT);
GO

UPDATE c
   SET parent_menu_id = p.menu_id, updated_by = N'seed-441', updated_dt = SYSUTCDATETIME()
  FROM grac_practice.menu_master c
  JOIN grac_practice.menu_master p ON p.menu_key = N'nav-asset-contract'
 WHERE c.menu_key = N'business-services' AND ISNULL(c.parent_menu_id, -1) <> p.menu_id;
GO

DECLARE @active_rs INT = (
    SELECT TOP 1 record_status_id FROM grac_practice.record_status_master
     WHERE status_code = N'Active' OR status_name = N'Active' ORDER BY record_status_id);
IF @active_rs IS NULL SET @active_rs = 1;
INSERT grac_practice.organization_role_menu_permission
    (role_id, menu_id, can_view, can_add, can_edit, can_delete, can_approve, status, record_status_id, entered_by, entered_dt)
SELECT r.role_id, m.menu_id, 1, 1, 1, 0, 1, N'Active', @active_rs, N'seed-441', SYSUTCDATETIME()
  FROM grac_practice.organization_role r
  JOIN grac_practice.menu_master m ON m.menu_key = N'business-services'
 WHERE r.role_name = N'Admin' AND r.status = N'Active'
   AND NOT EXISTS (SELECT 1 FROM grac_practice.organization_role_menu_permission e
                    WHERE e.role_id = r.role_id AND e.menu_id = m.menu_id);
PRINT CONCAT('441: Admin grants inserted: ', @@ROWCOUNT);
GO

-- =====================================================================
-- Verification
-- =====================================================================
SELECT '441-a service tables' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.business_service','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.business_service_consumer','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.business_service_history','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.business_service_setting','U') IS NOT NULL
            THEN 'PASS' ELSE 'FAIL' END AS Result
UNION ALL
SELECT '441-b relationships: role column, CONTRACT kind, Supports Service active',
       CASE WHEN COL_LENGTH('grac_practice.asset_relationship', 'service_role') IS NOT NULL
             AND EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_asset_rel_skind' AND definition LIKE '%CONTRACT%')
             AND EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_asset_rel_tkind' AND definition LIKE '%CONTRACT%')
             AND EXISTS (SELECT 1 FROM grac_practice.asset_relationship_type
                          WHERE type_code = N'SUPPORTS_SERVICE' AND is_active = 1 AND source_kinds LIKE N'%SERVICE%')
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '441-c functions and procedures present',
       CASE WHEN OBJECT_ID('grac_practice.fn_business_service_consumers') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_business_service_conflicts') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_duration_hours') IS NOT NULL
             AND (SELECT COUNT(*) FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'grac_practice'
                   AND name IN ('sp_business_service_history_add', 'sp_business_service_save', 'sp_business_service_retire_apply',
                                'sp_business_service_transition', 'sp_business_service_retirement_decide',
                                'sp_business_service_setting_save', 'sp_business_service_config_get', 'sp_business_services',
                                'sp_business_service_get', 'sp_business_service_conflicts', 'sp_business_service_tree')) = 11
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '441-d re-issues carry the 441 additions',
       CASE WHEN OBJECT_DEFINITION(OBJECT_ID('grac_practice.fn_asset_ci_catalog')) LIKE '%business_service%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.fn_asset_ci_catalog')) LIKE '%asset_contract%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_relationship_save')) LIKE '%service_role%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_relationship_action')) LIKE '%serviceRole%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_relationship_history_add')) LIKE '%serviceRole%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_relationships')) LIKE '%ServiceRole%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_relationship_get')) LIKE '%ServiceRole%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_ci_impact')) LIKE '%fn_business_service_consumers%'
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '441-e duration parsing ("4 hours", "30 minutes", "2 days")',
       CASE WHEN grac_practice.fn_asset_duration_hours(N'4 hours') = 4
             AND grac_practice.fn_asset_duration_hours(N'30 minutes') = 0.5
             AND grac_practice.fn_asset_duration_hours(N'2 days') = 48
             AND grac_practice.fn_asset_duration_hours(N'daily') IS NULL
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '441-f menu row Active under Asset & Contract',
       CASE WHEN EXISTS (SELECT 1 FROM grac_practice.menu_master c
                           JOIN grac_practice.menu_master p ON p.menu_id = c.parent_menu_id AND p.menu_key = N'nav-asset-contract'
                          WHERE c.menu_key = N'business-services' AND c.status = N'Active') THEN 'PASS' ELSE 'FAIL' END;
GO

-- =====================================================================
-- UAT (after deploying the API + Web build; re-login for the menu grant)
--   Needs: users R (requests) and A (approves) with business-services and
--   asset-relationships; application APP1 (criticality Medium); asset DB1
--   with RPO "24 hours"; a department FIN.
--   1. Business Services -> New: PAY "Payments", Customer-facing,
--      criticality High, RTO 4, RPO 1, MTPD 8, consumer FIN and external
--      "Retail customers" -> Draft. RTO 10 with MTPD 8 -> refused (54740).
--   2. Design -> Active without owner -> refused (54743); with an owner but
--      no supporting item -> refused (54744).
--   3. Supporting items -> add APP1 (role "Payment application"), DB1
--      (critical, High), then approve both in Asset Relationships. Activate.
--   4. Conflicts: APP1 rated Medium for a High service; DB1 RPO 24 h > 1 h.
--   5. New service CORE (Shared); add PAY as a supporting service of CORE
--      -> Hierarchy shows CORE above PAY. Asset Relationships -> Impact of
--      DB1 downstream lists PAY and CORE; the service list shows owners, RTO
--      / RPO / MTPD and consumers.
--   6. PAY -> Retiring (note) -> Retired without the review notes ->
--      refused (54746); with them -> waits for approval; R cannot approve
--      (54748); with the CORE mapping critical -> refused (54745) until it
--      is accepted for retirement. A approves -> Retired; its relationships
--      are retired and stay in their history.
-- =====================================================================
