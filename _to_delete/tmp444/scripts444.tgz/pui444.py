# 444: Asset Discovery screen -- Merges tab and merge window; Merge action on duplicate reviews.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    open(path, 'w', encoding='utf-8', newline='').write(s)
V = "src/PracticeManagement.Web/Views/Practice/Partials/asset-discovery.cshtml"
J = "src/PracticeManagement.Web/wwwroot/js/AssetConfig/asset-discovery.js"

edit(V, [
("""    review, then dismiss or request decommission -- 5.6.3 Retire / Stale).
""",
"""    review, then dismiss or request decommission -- 5.6.3 Retire / Stale).
    444: "Merges" -- survivor and duplicates, impact, field comparison,
    plan, blockers, approval (two people for critical CIs), execution with
    per-object outcomes and recovery (5.6.3 Merge, 19.4); a Potential
    duplicate in the queue opens a merge of its two assets.
"""),
("""            <button role="tab" data-adc-main="STALE" aria-selected="false">Stale assets</button>
""",
"""            <button role="tab" data-adc-main="STALE" aria-selected="false">Stale assets</button>
            <button role="tab" data-adc-main="MERGES" aria-selected="false">Merges</button>
"""),
("""        @* ---------------- settings ---------------- *@
        <div class="pm-tab-panel" data-adc-mainpanel="SETTINGS" hidden>
""",
"""        @* ---------------- merges (444) ---------------- *@
        <div class="pm-tab-panel" data-adc-mainpanel="MERGES" hidden>
            <div class="pm-toolbar">
                <select id="adcMgStatus" title="Status">
                    <option value="">Open</option><option value="EXECUTED">Executed</option><option value="RECOVERED">Recovered</option>
                    <option value="REJECTED">Rejected</option><option value="CANCELLED">Cancelled</option><option value="ALL">All</option>
                </select>
                <input type="search" id="adcMgSearch" placeholder="Search asset" maxlength="200" />
                @if (adcCanEdit)
                {
                    <button class="pm-button primary" id="adcMgNew" type="button"><i class="fa-solid fa-code-merge"></i> New merge</button>
                }
            </div>
            <p class="adc-note">A merge keeps the survivor and its ID; the duplicates' current relationships, source links, open items, coverage, risk and practice mappings move to it, their identifiers stay searchable as aliases and the duplicates are archived with their history. Approval by another person (two for critical CIs); execution can be recovered (BRD 5.6.3, 19.4).</p>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Merge</th><th>Survivor</th><th>Duplicates</th><th>Status</th><th>Approvals</th><th>Requested</th></tr></thead>
                    <tbody id="adcMgBody"></tbody>
                </table>
            </div>
            <div id="adcMgPager"></div>
        </div>

        @* ---------------- settings ---------------- *@
        <div class="pm-tab-panel" data-adc-mainpanel="SETTINGS" hidden>
"""),
("""@* ======================= Stale review window (443) ======================= *@
""",
"""@* ======================= Merge window (444) ======================= *@
<div class="pm-modal" id="adcMergeModal" hidden>
    <div class="pm-modal-panel pm-modal-wide">
        <header>
            <h2 id="adcMgTitle">Merge</h2>
            <button class="pm-modal-close" type="button" data-close-adc="adcMergeModal" aria-label="Close">&times;</button>
        </header>
        <div class="adc-info" id="adcMgInfo"></div>
        <p class="pm-message" id="adcMgMessage" role="status" aria-live="polite" hidden></p>

        <form id="adcMgForm" class="pm-form-grid">
            <label><span>Find survivor</span><input type="search" id="adcMgSurvSearch" maxlength="200" /></label>
            <label><span>Survivor (kept) *</span><select id="adcMgSurv"><option value="">--</option></select></label>
            <label><span>Find duplicate</span><input type="search" id="adcMgDupSearch" maxlength="200" /></label>
            <label><span>Duplicate</span><select id="adcMgDupSel"><option value="">--</option></select></label>
            <div class="full">
                <button class="pm-button" type="button" id="adcMgDupAdd"><i class="fa-solid fa-plus"></i> Add duplicate</button>
                <div class="pm-table-wrap">
                    <table>
                        <thead><tr><th>Duplicates (archived after the merge)</th><th></th></tr></thead>
                        <tbody id="adcMgDupBody"></tbody>
                    </table>
                </div>
            </div>
            <label class="full"><span>Reason *</span><textarea id="adcMgReason" rows="2" maxlength="1000"></textarea></label>
            <footer class="pm-modal-footer full">
                <button type="submit" class="pm-button primary"><i class="fa-solid fa-floppy-disk"></i> Save draft</button>
            </footer>
        </form>

        <div id="adcMgActionWrap" hidden>
            <label class="full"><span>Note (required to reject, cancel or recover)</span><textarea id="adcMgNote" rows="2" maxlength="1000"></textarea></label>
            <div class="pm-modal-footer" id="adcMgActions"></div>
        </div>

        <div id="adcMgDetail" hidden>
            <h3 class="adc-sub">Blockers</h3>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Duplicate</th><th>Open item</th></tr></thead>
                    <tbody id="adcMgBlockBody"></tbody>
                </table>
            </div>
            <h3 class="adc-sub">Impact</h3>
            <div class="pm-table-wrap">
                <table>
                    <thead id="adcMgImpactHead"></thead>
                    <tbody id="adcMgImpactBody"></tbody>
                </table>
            </div>
            <h3 class="adc-sub">Field values</h3>
            <p class="adc-note">The survivor keeps its values; empty survivor values are filled from the first duplicate holding one. Tick a duplicate value to take it instead (saved with the draft).</p>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Field</th><th>Survivor</th><th>Duplicate value</th><th>Take</th></tr></thead>
                    <tbody id="adcMgFieldBody"></tbody>
                </table>
            </div>
            <h3 class="adc-sub" id="adcMgPlanTitle">Plan</h3>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Duplicate</th><th>Domain</th><th>Item</th><th>Outcome</th><th>Detail</th></tr></thead>
                    <tbody id="adcMgPlanBody"></tbody>
                </table>
            </div>
            <h3 class="adc-sub">Approvals</h3>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Decision</th><th>By</th><th>When</th><th>Note</th></tr></thead>
                    <tbody id="adcMgApprBody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

@* ======================= Stale review window (443) ======================= *@
"""),
])

edit(J, [
("""// discovery/stale/settings, discovery/stale/reviews, .../{id}/action.
""",
"""// discovery/stale/settings, discovery/stale/reviews, .../{id}/action.
// 444: Merges -- discovery/merges, discovery/merges/{id}, discovery/merges
// (draft save), discovery/merges/{id}/action; a Potential duplicate opens a
// new merge of its two assets. Plan, blockers and every rule are SQL's.
"""),
("""  const DEP_KIND = {""",
"""  const MERGE = { DRAFT: ["Draft", "adc-st-ended"], PENDING_APPROVAL: ["Pending approval", "adc-st-wait"], APPROVED: ["Approved", "adc-st-open"],
                  EXECUTED: ["Executed", "adc-st-active"], RECOVERED: ["Recovered", "adc-st-wait"], REJECTED: ["Rejected", "adc-st-bad"],
                  CANCELLED: ["Cancelled", "adc-st-ended"] };   // 444
  const PLAN = { MOVE: ["Move", "adc-st-open"], END: ["End", "adc-st-wait"], RESOLVE: ["Resolve", "adc-st-active"], KEEP: ["Keep", "adc-st-ended"],
                 BLOCK: ["Blocked", "adc-st-bad"], MOVED: ["Moved", "adc-st-open"], ENDED: ["Ended", "adc-st-wait"], RESOLVED: ["Resolved", "adc-st-active"],
                 KEPT: ["Kept", "adc-st-ended"], FILLED: ["Filled", "adc-st-open"], REPLACED: ["Replaced", "adc-st-wait"], ALIASED: ["Alias", "adc-st-ended"],
                 ARCHIVED: ["Archived", "adc-st-ended"] };
  const OBJECT = { RELATIONSHIP: "Relationship", DISCOVERY_LINK: "Source record", ATTRIBUTE_SOURCE: "Source value", RECON_EXCEPTION: "Reconciliation",
                   COVERAGE: "Contract coverage", OCCURRENCE: "Activity", RESTRICTIVE_REVIEW: "Restrictive review", RISK_MAP: "Risk mapping",
                   RISK_LINK: "Risk link", PRACTICE_RESOLUTION: "Practice resolution", FIELD: "Field", ALIAS: "Alias", ASSET_RECORD: "Asset record" };
  const DEP_KIND = {"""),
("""  const state = { organizationId: null, config: null, mainTab: "SOURCES", batPager: null, qPager: null, cPager: null, stPager: null, stale: null,
""",
"""  const state = { organizationId: null, config: null, mainTab: "SOURCES", batPager: null, qPager: null, cPager: null, stPager: null, stale: null,
                  mgPager: null, merge: null, mergeDups: [], mergeChoices: {},   // 444
"""),
("""    state.stPager = g ? g.attach({ hostId: "adcStPager", onChange: refreshStale }) : null;
""",
"""    state.stPager = g ? g.attach({ hostId: "adcStPager", onChange: refreshStale }) : null;
    state.mgPager = g ? g.attach({ hostId: "adcMgPager", onChange: refreshMerges }) : null;
"""),
("""      const g = ev.target.closest("button[data-adc-register]");   // 443
      if (g) { registerCandidate(Number(g.dataset.adcRegister)); return; }
""",
"""      const g = ev.target.closest("button[data-adc-register]");   // 443
      if (g) { registerCandidate(Number(g.dataset.adcRegister)); return; }
      const mg = ev.target.closest("button[data-adc-merge-pair]");   // 444
      if (mg) { const [s, d] = mg.dataset.adcMergePair.split(":").map(Number); openMergeNew(s, [d]); return; }
"""),
("""    // stale assets (443)
""",
"""    // merges (444)
    let tm = null;
    document.getElementById("adcMgStatus").addEventListener("change", () => { state.mgPager?.reset(true); refreshMerges(); });
    document.getElementById("adcMgSearch").addEventListener("input", () => { clearTimeout(tm); tm = setTimeout(() => { state.mgPager?.reset(true); refreshMerges(); }, 300); });
    document.getElementById("adcMgNew")?.addEventListener("click", () => openMergeNew(null, []));
    document.getElementById("adcMgBody").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-adc-merge]");
      if (b) openMerge(Number(b.dataset.adcMerge));
    });
    let tsv = null, tdp = null;
    document.getElementById("adcMgSurvSearch").addEventListener("input", () => { clearTimeout(tsv); tsv = setTimeout(() => fillAssetPicker("adcMgSurvSearch", "adcMgSurv"), 300); });
    document.getElementById("adcMgDupSearch").addEventListener("input", () => { clearTimeout(tdp); tdp = setTimeout(() => fillAssetPicker("adcMgDupSearch", "adcMgDupSel"), 300); });
    document.getElementById("adcMgDupAdd").addEventListener("click", addMergeDuplicate);
    document.getElementById("adcMgDupBody").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-adc-dup-remove]");
      if (b) { state.mergeDups.splice(Number(b.dataset.adcDupRemove), 1); renderMergeDups(); }
    });
    document.getElementById("adcMgForm").addEventListener("submit", ev => { ev.preventDefault(); saveMerge(); });
    document.getElementById("adcMgActions").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-adc-merge-action]");
      if (b) mergeAction(b.dataset.adcMergeAction);
    });
    document.getElementById("adcMgFieldBody").addEventListener("change", ev => {
      const c = ev.target.closest("input[data-adc-choice]");
      if (!c) return;
      const [key, asset] = [c.dataset.adcChoice, Number(c.value)];
      if (c.checked) {
        state.mergeChoices[key] = asset;
        document.querySelectorAll(`#adcMgFieldBody input[data-adc-choice]`).forEach(o => { if (o !== c && o.dataset.adcChoice === key) o.checked = false; });
      } else delete state.mergeChoices[key];
    });
    // stale assets (443)
"""),
("""    [state.batPager, state.qPager, state.cPager, state.stPager].forEach(p => p?.reset(true));
""",
"""    [state.batPager, state.qPager, state.cPager, state.stPager, state.mgPager].forEach(p => p?.reset(true));
"""),
("""    else if (name === "STALE") await refreshStale();
""",
"""    else if (name === "STALE") await refreshStale();
    else if (name === "MERGES") await refreshMerges();
"""),
("""          + (canRegister ? ` <button class="pm-button" type="button" data-adc-register="${e.exceptionId}" title="Register a new Draft asset from this record"><i class="fa-solid fa-plus"></i> Register</button>` : "")
""",
"""          + (canRegister ? ` <button class="pm-button" type="button" data-adc-register="${e.exceptionId}" title="Register a new Draft asset from this record"><i class="fa-solid fa-plus"></i> Register</button>` : "")
          + (e.status === "OPEN" && CAN_EDIT && e.exceptionKind === "DUPLICATE" && e.assetId && e.otherAssetId   // 444
             ? ` <button class="pm-button" type="button" data-adc-merge-pair="${e.assetId}:${e.otherAssetId}" title="Prepare a merge of the two assets"><i class="fa-solid fa-code-merge"></i> Merge</button>` : "")
"""),
("""  // ------------------------------------------------------------------ stale assets (443)
""",
"""  // ------------------------------------------------------------------ merges (444)
  async function refreshMerges() {
    const body = document.getElementById("adcMgBody");
    if (!state.organizationId) { body.innerHTML = empty(6, "Select an organization."); state.mgPager?.clear(); return; }
    body.innerHTML = empty(6, "Loading...");
    const qs = new URLSearchParams({ organizationId: state.organizationId,
      pageNumber: state.mgPager ? state.mgPager.page() : 1, pageSize: state.mgPager ? state.mgPager.size() : 25 });
    if (val("adcMgStatus")) qs.set("status", val("adcMgStatus"));
    if (val("adcMgSearch")) qs.set("search", val("adcMgSearch"));
    const res = await api("GET", `/discovery/merges?${qs}`);
    if (!res.ok) { body.innerHTML = empty(6, res.error); state.mgPager?.clear(); return; }
    const rows = res.data.data.rows || [];
    state.mgPager?.setTotal(res.data.data.totalRows, rows.length);
    body.innerHTML = rows.map(m => {
      const [sl, sc] = MERGE[m.status] || [m.status, ""];
      return `<tr><td><button class="pm-link-button" type="button" data-adc-merge="${m.eventId}">Merge #${esc(m.eventId)}</button></td>
        <td>${esc(m.survivorName)}</td><td>${esc(m.duplicateNames || "--")}<div class="adc-note">${esc(m.duplicateCount)} asset(s)</div></td>
        <td><span class="adc-chip ${sc}">${esc(sl)}</span></td>
        <td>${esc(m.approvals)} / ${esc(m.approvalsRequired)}${m.isCritical ? ' <span class="adc-chip adc-st-bad">Critical</span>' : ""}</td>
        <td>${esc(m.requestedBy || "")}<div class="adc-note">${esc(dateTime(m.requestedDt))}</div></td></tr>`;
    }).join("") || empty(6, "No merges.");
  }

  // Asset picker from relationships/ci-lookup (kind ASSET, usable only).
  async function fillAssetPicker(searchId, selectId, keep) {
    const sel = document.getElementById(selectId);
    const qs = new URLSearchParams({ organizationId: state.organizationId, kind: "ASSET" });
    if (val(searchId)) qs.set("search", val(searchId));
    const res = await api("GET", `/relationships/ci-lookup?${qs}`);
    const rows = res.ok ? (res.data.data || []).filter(c => c.isUsable) : [];
    const extra = keep && !rows.some(c => c.ciId === keep.id) ? `<option value="${keep.id}">${esc(keep.name)}</option>` : "";
    sel.innerHTML = `<option value="">--</option>` + extra + rows.map(c => `<option value="${c.ciId}">${esc(c.ciName)}${c.ciClass ? " - " + esc(c.ciClass) : ""}</option>`).join("");
    if (keep) sel.value = String(keep.id);
    if (!res.ok) show("adcMgMessage", res.error);
  }

  function renderMergeDups() {
    const canEdit = CAN_EDIT && (!state.merge || state.merge.merge.status === "DRAFT");
    document.getElementById("adcMgDupBody").innerHTML = state.mergeDups.map((d, i) => `<tr><td>${esc(d.name)} <span class="adc-note">#${esc(d.id)}</span></td>
        <td>${canEdit ? `<button class="pm-link-button" type="button" data-adc-dup-remove="${i}">Remove</button>` : ""}</td></tr>`).join("")
      || empty(2, "Add at least one duplicate.");
  }

  function addMergeDuplicate() {
    const sel = document.getElementById("adcMgDupSel"), id = Number(sel.value);
    if (!id) return;
    if (String(id) === val("adcMgSurv")) { show("adcMgMessage", "The survivor cannot also be a duplicate."); return; }
    if (state.mergeDups.some(d => d.id === id)) return;
    if (state.mergeDups.length >= 10) { show("adcMgMessage", "A merge holds at most 10 duplicates."); return; }
    state.mergeDups.push({ id, name: sel.options[sel.selectedIndex].textContent });
    hide("adcMgMessage");
    renderMergeDups();
  }

  // New (unsaved) merge, optionally prefilled from a duplicate review.
  async function openMergeNew(survivorId, duplicateIds) {
    state.merge = null; state.mergeChoices = {};
    hide("adcMgMessage");
    document.getElementById("adcMgTitle").textContent = "New merge";
    document.getElementById("adcMgInfo").innerHTML = "";
    document.getElementById("adcMgForm").hidden = !CAN_EDIT;
    document.getElementById("adcMgActionWrap").hidden = true;
    document.getElementById("adcMgDetail").hidden = true;
    ["adcMgSurvSearch", "adcMgDupSearch", "adcMgReason"].forEach(id => { document.getElementById(id).value = ""; });
    const names = await assetNames([survivorId, ...duplicateIds].filter(Boolean));
    state.mergeDups = duplicateIds.map(id => ({ id, name: names[id] || "#" + id }));
    await fillAssetPicker("adcMgSurvSearch", "adcMgSurv", survivorId ? { id: survivorId, name: names[survivorId] || "#" + survivorId } : null);
    await fillAssetPicker("adcMgDupSearch", "adcMgDupSel");
    renderMergeDups();
    document.getElementById("adcMergeModal").hidden = false;
  }

  // Names of the assets prefilled from a duplicate review (the queue row holds them).
  async function assetNames(ids) {
    const out = {};
    (state.queue || []).forEach(e => { if (e.assetId) out[e.assetId] = e.assetName; if (e.otherAssetId) out[e.otherAssetId] = e.otherAssetName; });
    return ids.reduce((m, id) => { m[id] = out[id]; return m; }, {});
  }

  async function saveMerge() {
    const survivor = num("adcMgSurv");
    if (!survivor) { show("adcMgMessage", "Choose the survivor."); return; }
    const m = state.merge && state.merge.merge;
    const res = await api("POST", "/discovery/merges", {
      organizationId: state.organizationId, eventId: m ? m.eventId : null, survivorAssetId: survivor,
      duplicateAssetIds: state.mergeDups.map(d => d.id), reason: val("adcMgReason"),
      fieldChoices: Object.keys(state.mergeChoices).length ? state.mergeChoices : null, expectedRecordVersion: m ? m.recordVersion : null
    });
    if (!res.ok) { show("adcMgMessage", res.error); return; }
    await openMerge(res.data.id);
    show("adcMgMessage", "Draft saved. Review the impact, fields, plan and blockers, then submit it for approval.", "success");
    await refreshMerges();
  }

  async function openMerge(id) {
    const res = await api("GET", `/discovery/merges/${id}?organizationId=${state.organizationId}`);
    if (!res.ok) { showMessage(res.error); return; }
    const d = res.data.data, m = d.merge;
    state.merge = d;
    hide("adcMgMessage");
    const [sl, sc] = MERGE[m.status] || [m.status, ""];
    document.getElementById("adcMgTitle").textContent = `Merge #${m.eventId} - ${m.survivorName}`;
    const item = (l, v) => `<div><span>${esc(l)}</span>${v}</div>`;
    document.getElementById("adcMgInfo").innerHTML =
      item("Status", `<span class="adc-chip ${sc}">${esc(sl)}</span>${m.isCritical ? ' <span class="adc-chip adc-st-bad">Critical</span>' : ""}`) +
      item("Approvals", `${esc(m.approvals)} / ${esc(m.approvalsRequired)}`) + item("Requested", `${esc(m.requestedBy || "")} ${esc(dateTime(m.requestedDt))}`) +
      item("Reason", esc(m.reason || "--")) +
      (m.executedDt ? item("Executed", `${esc(m.executedBy || "")} ${esc(dateTime(m.executedDt))}`) : "") +
      (m.recoveredDt ? item("Recovered", `${esc(m.recoveredBy || "")} ${esc(dateTime(m.recoveredDt))} - ${esc(m.recoveryReason || "")}`) : "") +
      (m.decidedNote ? item("Decision note", esc(m.decidedNote)) : "");
    const draft = m.status === "DRAFT";
    const assets = d.assets || [];
    state.mergeDups = assets.filter(a => a.memberRole !== "SURVIVOR").map(a => ({ id: a.assetId, name: a.assetName }));
    state.mergeChoices = {};
    try { Object.assign(state.mergeChoices, JSON.parse(m.fieldChoicesJson || "{}")); } catch (_) { /* none */ }
    document.getElementById("adcMgForm").hidden = !(draft && CAN_EDIT);
    if (draft && CAN_EDIT) {
      document.getElementById("adcMgReason").value = m.reason || "";
      await fillAssetPicker("adcMgSurvSearch", "adcMgSurv", { id: m.survivorAssetId, name: m.survivorName });
      await fillAssetPicker("adcMgDupSearch", "adcMgDupSel");
    }
    renderMergeDups();
    // actions the status allows; the proxy and SQL check the permission and the people
    const acts = [];
    if (draft && CAN_EDIT) acts.push(["SUBMIT", "Submit for approval", "primary"]);
    if (m.status === "PENDING_APPROVAL" && CAN_APPROVE) acts.push(["APPROVE", "Approve", "primary"], ["REJECT", "Reject", ""]);
    if (m.status === "APPROVED" && CAN_EDIT) acts.push(["EXECUTE", "Execute merge", "primary"]);
    if (m.status === "EXECUTED" && CAN_APPROVE) acts.push(["RECOVER", "Recover", ""]);
    if (["DRAFT", "PENDING_APPROVAL", "APPROVED"].includes(m.status) && CAN_EDIT) acts.push(["CANCEL", "Cancel merge", ""]);
    document.getElementById("adcMgActions").innerHTML = acts.map(([a, l, c]) => `<button class="pm-button ${c}" type="button" data-adc-merge-action="${a}">${esc(l)}</button>`).join("");
    document.getElementById("adcMgActionWrap").hidden = !acts.length;
    document.getElementById("adcMgNote").value = "";
    const nameOf = id => (assets.find(a => a.assetId === id) || {}).assetName || "#" + id;
    // blockers
    document.getElementById("adcMgBlockBody").innerHTML = (d.blockers || []).map(b => `<tr><td>${esc(nameOf(b.assetId))}</td><td>${esc(b.detail)}</td></tr>`).join("")
      || empty(2, ["DRAFT", "PENDING_APPROVAL", "APPROVED"].includes(m.status) ? "None." : "--");
    // impact: one column per asset
    document.getElementById("adcMgImpactHead").innerHTML = `<tr><th>Item</th>${assets.map(a => `<th>${esc(a.assetName)}<div class="adc-note">${a.memberRole === "SURVIVOR" ? "survivor" : "duplicate"} - ${esc(a.statusName)}${a.criticalityName ? ", " + esc(a.criticalityName) : ""}</div></th>`).join("")}</tr>`;
    const items = [...new Map((d.impact || []).map(i => [i.impactItem, i.sortOrder])).entries()].sort((x, y) => x[1] - y[1]).map(x => x[0]);
    document.getElementById("adcMgImpactBody").innerHTML = items.map(it => `<tr><td>${esc(it)}</td>${assets.map(a => {
      const r = (d.impact || []).find(i => i.assetId === a.assetId && i.impactItem === it);
      return `<td>${esc(r ? r.itemCount : 0)}</td>`; }).join("")}</tr>`).join("") || empty(1, "--");
    // fields (open merges)
    const canChoose = draft && CAN_EDIT;
    document.getElementById("adcMgFieldBody").innerHTML = (d.fields || []).map(f => `<tr><td>${esc(f.fieldLabel)}</td>
        <td>${esc(f.survivorDisplay ?? "(empty)")}</td><td>${esc(f.duplicateDisplay ?? "")}<div class="adc-note">${esc(nameOf(f.duplicateAssetId))}</div></td>
        <td>${f.isMergeable && f.isDifferent ? `<input type="checkbox" data-adc-choice="${esc(f.fieldKey)}" value="${f.duplicateAssetId}"${state.mergeChoices[f.fieldKey] === f.duplicateAssetId ? " checked" : ""}${canChoose ? "" : " disabled"} />`
            : (f.survivorDisplay == null && f.isMergeable ? '<span class="adc-note">filled</span>' : "")}</td></tr>`).join("")
      || empty(4, ["DRAFT", "PENDING_APPROVAL", "APPROVED"].includes(m.status) ? "No duplicate values." : "--");
    // plan (open) or outcomes (executed / recovered)
    const open = ["DRAFT", "PENDING_APPROVAL", "APPROVED"].includes(m.status);
    document.getElementById("adcMgPlanTitle").textContent = open ? "Plan" : "Outcomes";
    const rows = open ? (d.plan || []) : (d.outcomes || []);
    document.getElementById("adcMgPlanBody").innerHTML = rows.map(p => {
      const [pl, pc] = PLAN[p.outcome] || [p.outcome, ""];
      const rec = !open && p.outcome !== "KEPT" ? (p.recovered ? ' <span class="adc-chip adc-st-active">Recovered</span>' : (p.recoveryNote ? `<div class="adc-note">${esc(p.recoveryNote)}</div>` : "")) : "";
      return `<tr><td>${esc(nameOf(p.duplicateAssetId))}</td><td>${esc(p.domain || OBJECT[p.objectKind] || p.objectKind)}</td>
        <td>${esc(OBJECT[p.objectKind] || p.objectKind)}: ${esc(p.objectLabel || "")}</td><td><span class="adc-chip ${pc}">${esc(pl)}</span>${rec}</td>
        <td>${esc(p.detail || "")}${!open && (p.beforeValue || p.afterValue) && p.objectKind === "FIELD" ? `<div class="adc-note">${esc(p.beforeValue ?? "(empty)")} -> ${esc(p.afterValue ?? "")}</div>` : ""}</td></tr>`;
    }).join("") || empty(5, "Nothing refers to the duplicates.");
    document.getElementById("adcMgApprBody").innerHTML = (d.approvals || []).map(a => `<tr><td>${esc(label(a.decision))}</td><td>${esc(a.approver)}</td>
        <td>${esc(dateTime(a.decidedDt))}</td><td>${esc(a.note || "")}</td></tr>`).join("") || empty(4, "None yet.");
    document.getElementById("adcMgDetail").hidden = false;
    document.getElementById("adcMergeModal").hidden = false;
  }

  function sameChoices(current, savedJson) {
    let saved = {};
    try { saved = JSON.parse(savedJson || "{}") || {}; } catch (_) { saved = {}; }
    const a = Object.keys(current), b = Object.keys(saved);
    return a.length === b.length && a.every(k => Number(saved[k]) === Number(current[k]));
  }

  async function mergeAction(action) {
    const m = state.merge && state.merge.merge;
    if (!m) return;
    const asks = { EXECUTE: "Execute the merge now? The duplicates are archived and their items move to the survivor.",
                   RECOVER: "Recover this merge? Items are moved back where they were not changed since." };
    if (asks[action] && window.gracUi && window.gracUi.confirm && !(await window.gracUi.confirm(asks[action]))) return;
    if (action === "SUBMIT" && !sameChoices(state.mergeChoices, m.fieldChoicesJson)) {
      show("adcMgMessage", "Save the draft first: the field choices changed.");
      return;
    }
    const res = await api("POST", `/discovery/merges/${m.eventId}/action`, {
      organizationId: state.organizationId, action, note: val("adcMgNote"), expectedRecordVersion: m.recordVersion
    });
    if (!res.ok) { show("adcMgMessage", res.error); return; }
    await openMerge(m.eventId);
    const done = { SUBMIT: "Submitted for approval.", APPROVE: res.data.result === "FIRST_APPROVAL" ? "First approval recorded; a second approver is needed." : "Approved.",
                   REJECT: "Rejected.", CANCEL: "Cancelled.", EXECUTE: "Merge executed; see the outcomes.", RECOVER: "Merge recovered; see the outcome notes." };
    show("adcMgMessage", done[action], "success");
    await refreshMerges();
  }

  // ------------------------------------------------------------------ stale assets (443)
"""),
])
print("pui444 ok")
