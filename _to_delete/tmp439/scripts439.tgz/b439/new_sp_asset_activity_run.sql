CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_run
    @organization_id BIGINT,
    @actor           NVARCHAR(100) = N'scheduler',
    @tasks           INT           = NULL OUTPUT,
    @opened          INT           = NULL OUTPUT,
    @completed       INT           = NULL OUTPUT,
    @errors          INT           = NULL OUTPUT,
    @error_text      NVARCHAR(MAX) = NULL OUTPUT,
    @reviews         INT           = NULL OUTPUT      -- 439: restrictive-use reviews raised
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;
    SELECT @tasks = 0, @opened = 0, @completed = 0, @errors = 0, @error_text = NULL, @reviews = 0;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54650, 'Organization not found.', 1;
    EXEC grac_practice.sp_asset_activity_task_sync @organization_id = @organization_id, @actor = @actor, @completed = @completed OUTPUT;
    EXEC grac_practice.sp_asset_activity_schedule_sync @organization_id = @organization_id;
    EXEC grac_practice.sp_asset_activity_generate @organization_id = @organization_id, @actor = @actor,
         @opened = @opened OUTPUT, @tasks = @tasks OUTPUT, @errors = @errors OUTPUT, @error_text = @error_text OUTPUT;
    -- 439: restrictive-use reviews (9.1.9).
    DECLARE @resolved INT;
    EXEC grac_practice.sp_asset_restrictive_review_sync @organization_id = @organization_id, @actor = @actor,
         @raised = @reviews OUTPUT, @resolved = @resolved OUTPUT;
END
GO
