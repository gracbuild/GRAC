// =====================================================================
// OrgAssuranceQuestionController
//
// Phase 2 Assurance Management -- Stage 2 Question Builder API.
//
// Route: /api/practice/org-assurance
// Sub-routes:
//   GET    /admin-question-types
//   GET    /question-sets?organizationId=&search=&page=&pageSize=
//   POST   /question-sets                  Create / update
//   GET    /question-sets/{id}?organizationId=
//   DELETE /question-sets/{id}?organizationId=&actor=
//   GET    /question-sets/{id}/questions?organizationId=
//   POST   /questions                       Create / update
//   GET    /questions/{id}?organizationId=
//   DELETE /questions/{id}?organizationId=&actor=
//   516 Question Repository:
//   GET    /question-categories?organizationId=           categories + subcategories
//   POST   /question-categories                           add / rename
//   DELETE /question-categories/{id}?organizationId=&actor=
//   POST   /question-subcategories                        add / rename / move
//   DELETE /question-subcategories/{id}?organizationId=&actor=
//   GET    /question-repository?organizationId=&search=&categoryId=&subcategoryId=&status=&excludeSetId=&page=&pageSize=
//   GET    /question-repository/{id}?organizationId=
//   POST   /question-repository                           create / update
//   DELETE /question-repository/{id}?organizationId=&actor=
//   POST   /question-sets/{id}/questions/from-repository  add picked questions to a set
//
// Shares the base route with OrgAssuranceDefinitionController.
// ASP.NET Core routes by the specific action template, so the split
// controllers coexist cleanly.
// =====================================================================
using Microsoft.AspNetCore.Mvc;
using PracticeManagement.Api.Models;
using PracticeManagement.Api.Services;

namespace PracticeManagement.Api.Controllers;

[ApiController]
[Route("api/practice/org-assurance")]
public sealed class OrgAssuranceQuestionController(
    IOrgAssuranceQuestionService service,
    ILogger<OrgAssuranceQuestionController> logger) : ControllerBase
{
    // ================================================================
    // Admin question types
    // ================================================================
    [HttpGet("admin-question-types")]
    public async Task<IActionResult> ListAdminQuestionTypes(CancellationToken cancellationToken)
    {
        try
        {
            var rows = await service.ListAdminQuestionTypesAsync(cancellationToken);
            return Ok(new { data = rows });
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "OrgAssuranceQuestionController.ListAdminQuestionTypes failed");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    // ================================================================
    // Question Sets
    // ================================================================
    [HttpGet("question-sets")]
    public async Task<IActionResult> ListSets(
        [FromQuery] long?   organizationId,
        [FromQuery] string? search,
        [FromQuery] int page     = 1,
        [FromQuery] int pageSize = 25,
        CancellationToken cancellationToken = default)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });

        try
        {
            var result = await service.ListSetsAsync(
                new OrgAssuranceQuestionSetListQuery(organizationId.Value, search, page, pageSize),
                cancellationToken);
            return Ok(result);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "OrgAssuranceQuestionController.ListSets failed");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    [HttpGet("question-sets/{id:long}")]
    public async Task<IActionResult> GetSet(
        long id,
        [FromQuery] long? organizationId,
        CancellationToken cancellationToken)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });

        try
        {
            var detail = await service.GetSetAsync(organizationId.Value, id, cancellationToken);
            return detail is null
                ? NotFound(new { error = "Question set not found." })
                : Ok(new { data = detail });
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "OrgAssuranceQuestionController.GetSet failed for id {Id}", id);
            return StatusCode(500, new { error = ex.Message });
        }
    }

    [HttpPost("question-sets")]
    public async Task<IActionResult> SaveSet(
        [FromBody] OrgAssuranceQuestionSetSaveRequest body,
        CancellationToken cancellationToken)
    {
        if (body is null) return BadRequest(new { error = "Request body is required." });
        if (body.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });

        var result = await service.SaveSetAsync(body, cancellationToken);
        return result.Success
            ? Ok(new { questionSetId = result.QuestionSetId })
            : BadRequest(new { error = result.Error, reasonCode = result.ReasonCode });
    }

    [HttpDelete("question-sets/{id:long}")]
    public async Task<IActionResult> DeleteSet(
        long id,
        [FromQuery] long?   organizationId,
        [FromQuery] string? actor,
        CancellationToken cancellationToken)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });

        var result = await service.DeleteSetAsync(organizationId.Value, id, actor, cancellationToken);
        return result.Success
            ? Ok(new { questionSetId = result.Id })
            : BadRequest(new { error = result.Error, reasonCode = result.ReasonCode });
    }

    // ================================================================
    // Questions
    // ================================================================
    [HttpGet("question-sets/{id:long}/questions")]
    public async Task<IActionResult> ListQuestions(
        long id,
        [FromQuery] long? organizationId,
        CancellationToken cancellationToken)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });

        try
        {
            var rows = await service.ListQuestionsAsync(organizationId.Value, id, cancellationToken);
            return Ok(new { data = rows });
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "OrgAssuranceQuestionController.ListQuestions failed for set {Id}", id);
            return StatusCode(500, new { error = ex.Message });
        }
    }

    [HttpGet("questions/{id:long}")]
    public async Task<IActionResult> GetQuestion(
        long id,
        [FromQuery] long? organizationId,
        CancellationToken cancellationToken)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });

        try
        {
            var row = await service.GetQuestionAsync(organizationId.Value, id, cancellationToken);
            return row is null
                ? NotFound(new { error = "Question not found." })
                : Ok(new { data = row });
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "OrgAssuranceQuestionController.GetQuestion failed for id {Id}", id);
            return StatusCode(500, new { error = ex.Message });
        }
    }

    [HttpPost("questions")]
    public async Task<IActionResult> SaveQuestion(
        [FromBody] OrgAssuranceQuestionSaveRequest body,
        CancellationToken cancellationToken)
    {
        if (body is null) return BadRequest(new { error = "Request body is required." });
        if (body.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (body.QuestionSetId  <= 0) return BadRequest(new { error = "questionSetId is required." });

        var result = await service.SaveQuestionAsync(body, cancellationToken);
        return result.Success
            ? Ok(new { questionId = result.QuestionId })
            : BadRequest(new { error = result.Error, reasonCode = result.ReasonCode });
    }

    [HttpDelete("questions/{id:long}")]
    public async Task<IActionResult> DeleteQuestion(
        long id,
        [FromQuery] long?   organizationId,
        [FromQuery] string? actor,
        CancellationToken cancellationToken)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });

        var result = await service.DeleteQuestionAsync(organizationId.Value, id, actor, cancellationToken);
        return result.Success
            ? Ok(new { questionId = result.Id })
            : BadRequest(new { error = result.Error, reasonCode = result.ReasonCode });
    }

    // ================================================================
    // Question Repository (migration 516)
    // ================================================================
    [HttpGet("question-categories")]
    public async Task<IActionResult> ListQuestionCategories(
        [FromQuery] long? organizationId, CancellationToken cancellationToken)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });
        try
        {
            var tree = await service.ListCategoriesAsync(organizationId.Value, cancellationToken);
            return Ok(new { categories = tree.Categories, subcategories = tree.Subcategories });
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "OrgAssuranceQuestionController.ListQuestionCategories failed");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    [HttpPost("question-categories")]
    public async Task<IActionResult> SaveQuestionCategory(
        [FromBody] OrgAssuranceQuestionCategorySaveRequest body, CancellationToken cancellationToken)
    {
        if (body is null) return BadRequest(new { error = "Request body is required." });
        if (body.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        var result = await service.SaveCategoryAsync(body, cancellationToken);
        return result.Success
            ? Ok(new { categoryId = result.Id })
            : BadRequest(new { error = result.Error, reasonCode = result.ReasonCode });
    }

    [HttpDelete("question-categories/{id:long}")]
    public async Task<IActionResult> DeleteQuestionCategory(
        long id, [FromQuery] long? organizationId, [FromQuery] string? actor, CancellationToken cancellationToken)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });
        var result = await service.DeleteCategoryAsync(organizationId.Value, id, actor, cancellationToken);
        return result.Success
            ? Ok(new { categoryId = result.Id })
            : BadRequest(new { error = result.Error, reasonCode = result.ReasonCode });
    }

    [HttpPost("question-subcategories")]
    public async Task<IActionResult> SaveQuestionSubcategory(
        [FromBody] OrgAssuranceQuestionSubcategorySaveRequest body, CancellationToken cancellationToken)
    {
        if (body is null) return BadRequest(new { error = "Request body is required." });
        if (body.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (body.CategoryId     <= 0) return BadRequest(new { error = "categoryId is required." });
        var result = await service.SaveSubcategoryAsync(body, cancellationToken);
        return result.Success
            ? Ok(new { subcategoryId = result.Id })
            : BadRequest(new { error = result.Error, reasonCode = result.ReasonCode });
    }

    [HttpDelete("question-subcategories/{id:long}")]
    public async Task<IActionResult> DeleteQuestionSubcategory(
        long id, [FromQuery] long? organizationId, [FromQuery] string? actor, CancellationToken cancellationToken)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });
        var result = await service.DeleteSubcategoryAsync(organizationId.Value, id, actor, cancellationToken);
        return result.Success
            ? Ok(new { subcategoryId = result.Id })
            : BadRequest(new { error = result.Error, reasonCode = result.ReasonCode });
    }

    [HttpGet("question-repository")]
    public async Task<IActionResult> ListRepositoryQuestions(
        [FromQuery] long?   organizationId,
        [FromQuery] string? search,
        [FromQuery] long?   categoryId,
        [FromQuery] long?   subcategoryId,
        [FromQuery] string? status,
        [FromQuery] long?   excludeSetId,
        [FromQuery] int page     = 1,
        [FromQuery] int pageSize = 25,
        CancellationToken cancellationToken = default)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });
        try
        {
            var result = await service.ListRepositoryQuestionsAsync(
                new OrgAssuranceRepositoryQuestionListQuery(organizationId.Value, search, categoryId,
                    subcategoryId, status, excludeSetId, page, pageSize),
                cancellationToken);
            return Ok(result);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "OrgAssuranceQuestionController.ListRepositoryQuestions failed");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    [HttpGet("question-repository/{id:long}")]
    public async Task<IActionResult> GetRepositoryQuestion(
        long id, [FromQuery] long? organizationId, CancellationToken cancellationToken)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });
        try
        {
            var row = await service.GetRepositoryQuestionAsync(organizationId.Value, id, cancellationToken);
            return row is null
                ? NotFound(new { error = "Question not found in the repository." })
                : Ok(new { data = row });
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "OrgAssuranceQuestionController.GetRepositoryQuestion failed for id {Id}", id);
            return StatusCode(500, new { error = ex.Message });
        }
    }

    [HttpPost("question-repository")]
    public async Task<IActionResult> SaveRepositoryQuestion(
        [FromBody] OrgAssuranceRepositoryQuestionSaveRequest body, CancellationToken cancellationToken)
    {
        if (body is null) return BadRequest(new { error = "Request body is required." });
        if (body.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (body.CategoryId     <= 0) return BadRequest(new { error = "Category is required.", reasonCode = "CATEGORY_REQUIRED" });
        var result = await service.SaveRepositoryQuestionAsync(body, cancellationToken);
        return result.Success
            ? Ok(new { repositoryQuestionId = result.Id })
            : BadRequest(new { error = result.Error, reasonCode = result.ReasonCode });
    }

    [HttpDelete("question-repository/{id:long}")]
    public async Task<IActionResult> DeleteRepositoryQuestion(
        long id, [FromQuery] long? organizationId, [FromQuery] string? actor, CancellationToken cancellationToken)
    {
        if (organizationId is null or <= 0)
            return BadRequest(new { error = "organizationId is required." });
        var result = await service.DeleteRepositoryQuestionAsync(organizationId.Value, id, actor, cancellationToken);
        return result.Success
            ? Ok(new { repositoryQuestionId = result.Id })
            : BadRequest(new { error = result.Error, reasonCode = result.ReasonCode });
    }

    // Question Set <- Repository: the only way a question enters a set.
    [HttpPost("question-sets/{id:long}/questions/from-repository")]
    public async Task<IActionResult> AddQuestionsFromRepository(
        long id, [FromBody] OrgAssuranceSetAddFromRepositoryRequest body, CancellationToken cancellationToken)
    {
        if (body is null) return BadRequest(new { error = "Request body is required." });
        if (body.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        var result = await service.AddToSetFromRepositoryAsync(id, body, cancellationToken);
        return result.Success
            ? Ok(new { questionSetId = id, addedCount = result.Id })
            : BadRequest(new { error = result.Error, reasonCode = result.ReasonCode });
    }
}
