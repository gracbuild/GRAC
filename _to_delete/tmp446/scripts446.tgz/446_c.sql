-- =====================================================================
-- 4. Store a calculation (history + current result). Never raises for an
--    asset it cannot see (merged-away assets have no Asset Value), so the
--    asset form save and the scheduler are not blocked by it.
--      AUTO        applies when the ratings or method changed, or nothing
--                  was stored yet (5.1.18.5.7 "saving valid CIA ratings
--                  shall automatically calculate"); a new configuration
--                  version alone waits for a controlled recalculation
--                  (5.1.18.5.6 / 5.1.18.5.9 "not silently changed").
--      CONTROLLED  applies any difference (recalculation run, single
--                  asset, method override).
--    @out_status: NOT_RATED / INCOMPLETE / INVALID / VALID, or OUT_OF_DATE
--    when AUTO left a configuration change for the controlled run.
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_valuation_apply
    @organization_id   BIGINT,
    @asset_id          BIGINT,
    @mode              NVARCHAR(12)   = N'AUTO',
    @source            NVARCHAR(30)   = N'FORM',
    @reason_text       NVARCHAR(1000) = NULL,
    @run_id            BIGINT         = NULL,
    @actor_employee_id BIGINT         = NULL,
    @actor             NVARCHAR(100)  = N'system',
    @out_status        NVARCHAR(20)   = NULL OUTPUT,
    @out_message       NVARCHAR(500)  = NULL OUTPUT,
    @out_changed       BIT            = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @mode = CASE WHEN UPPER(ISNULL(@mode, N'')) = N'CONTROLLED' THEN N'CONTROLLED' ELSE N'AUTO' END;
    SET @reason_text = NULLIF(LTRIM(RTRIM(@reason_text)), N'');
    SELECT @out_status = NULL, @out_message = NULL, @out_changed = 0;

    DECLARE @found BIT = 0, @is_current BIT, @not_calc BIT, @cfg_changed BIT, @val_changed BIT,
            @cfg BIGINT, @ver INT, @c NVARCHAR(40), @i NVARCHAR(40), @a NVARCHAR(40),
            @ovr NVARCHAR(30), @mused NVARCHAR(30), @msrc NVARCHAR(10),
            @raw DECIMAL(18, 6), @score DECIMAL(18, 4), @cat NVARCHAR(100), @band BIGINT,
            @status NVARCHAR(20), @msg NVARCHAR(500),
            @p_cfg BIGINT, @p_ver INT, @p_c NVARCHAR(40), @p_i NVARCHAR(40), @p_a NVARCHAR(40), @p_mused NVARCHAR(30),
            @p_score DECIMAL(18, 4), @p_cat NVARCHAR(100), @p_status NVARCHAR(20), @p_msg NVARCHAR(500);
    SELECT @found = 1, @is_current = s.IsCurrent, @not_calc = s.NotCalculated, @cfg_changed = s.ConfigChanged,
           @val_changed = s.ValuesChanged, @cfg = s.ConfigId, @ver = s.ConfigVersionNo,
           @c = s.Confidentiality, @i = s.Integrity, @a = s.Availability,
           @ovr = s.MethodOverride, @mused = s.MethodUsed, @msrc = s.MethodSource,
           @raw = s.RawScore, @score = s.AssetValueScore, @cat = s.AssetValueCategory, @band = s.BandId,
           @status = s.ValidationStatus, @msg = s.ValidationMessage,
           @p_cfg = s.StoredConfigId, @p_ver = s.StoredConfigVersionNo, @p_c = s.StoredConfidentiality,
           @p_i = s.StoredIntegrity, @p_a = s.StoredAvailability, @p_mused = s.StoredMethodUsed,
           @p_score = s.StoredScore, @p_cat = s.StoredCategory, @p_status = s.StoredStatus, @p_msg = s.StoredMessage
      FROM grac_practice.fn_asset_valuation_state(@organization_id) s
     WHERE s.AssetId = @asset_id;
    IF @found = 0 RETURN;

    IF @is_current = 1 OR (@mode = N'AUTO' AND @not_calc = 0 AND @val_changed = 0)
    BEGIN
        IF @is_current = 1
        BEGIN
            SELECT @out_status = ISNULL(@p_status, @status), @out_message = CASE WHEN @p_status IS NULL THEN @msg ELSE @p_msg END;
        END
        ELSE
        BEGIN
            SELECT @out_status = N'OUT_OF_DATE',
                   @out_message = CONCAT(N'Asset Value was calculated with valuation configuration version ',
                                         ISNULL(CAST(@p_ver AS NVARCHAR(12)), N'(none)'), N'; the Active version is ',
                                         ISNULL(CAST(@ver AS NVARCHAR(12)), N'(none)'),
                                         N'. It changes with a controlled recalculation (Asset Valuation, Recalculation tab).');
        END
        RETURN;
    END

    -- Only a VALID calculation keeps a score and category (5.1.18.5.7).
    DECLARE @keep BIT = CASE WHEN @status = N'VALID' THEN 1 ELSE 0 END, @hist BIGINT;
    BEGIN TRAN;
    INSERT grac_practice.asset_valuation_history
        (organization_id, asset_id, source, run_id, reason_text,
         prev_config_id, prev_config_version, prev_confidentiality, prev_integrity, prev_availability, prev_method_used,
         prev_score, prev_category, prev_status,
         new_config_id, new_config_version, confidentiality, integrity, availability, method_override, method_used, method_source,
         raw_score, new_score, new_category, new_band_id, new_status, message, actor_employee_id, entered_by)
    VALUES (@organization_id, @asset_id, @source, @run_id, @reason_text,
            @p_cfg, @p_ver, @p_c, @p_i, @p_a, @p_mused, @p_score, @p_cat, @p_status,
            @cfg, @ver, @c, @i, @a, @ovr, @mused, @msrc,
            @raw, CASE WHEN @keep = 1 THEN @score END, CASE WHEN @keep = 1 THEN @cat END, CASE WHEN @keep = 1 THEN @band END,
            @status, @msg, @actor_employee_id, @actor);
    SET @hist = SCOPE_IDENTITY();

    MERGE grac_practice.asset_valuation_result AS t
    USING (SELECT @asset_id AS asset_id) AS src
       ON t.asset_id = src.asset_id
    WHEN MATCHED THEN
        UPDATE SET config_id = @cfg, config_version_no = @ver, confidentiality = @c, integrity = @i, availability = @a,
                   method_override = @ovr, method_used = @mused, method_source = @msrc, raw_score = @raw,
                   asset_value_score = CASE WHEN @keep = 1 THEN @score END,
                   asset_value_category = CASE WHEN @keep = 1 THEN @cat END,
                   band_id = CASE WHEN @keep = 1 THEN @band END,
                   validation_status = @status, validation_message = @msg, source = @source, run_id = @run_id,
                   last_history_id = @hist, calculated_by = @actor, calculated_dt = SYSUTCDATETIME()
    WHEN NOT MATCHED BY TARGET THEN
        INSERT (asset_id, organization_id, config_id, config_version_no, confidentiality, integrity, availability,
                method_override, method_used, method_source, raw_score, asset_value_score, asset_value_category, band_id,
                validation_status, validation_message, source, run_id, last_history_id, calculated_by)
        VALUES (@asset_id, @organization_id, @cfg, @ver, @c, @i, @a, @ovr, @mused, @msrc, @raw,
                CASE WHEN @keep = 1 THEN @score END, CASE WHEN @keep = 1 THEN @cat END, CASE WHEN @keep = 1 THEN @band END,
                @status, @msg, @source, @run_id, @hist, @actor);
    COMMIT;

    SELECT @out_status = @status, @out_message = @msg, @out_changed = 1;
END
GO

-- Scheduler step: AUTO recalculation for ratings changed outside the asset
-- form (merge, split, discovery) and first calculations (D137).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_valuation_sync
    @organization_id BIGINT,
    @actor           NVARCHAR(100) = N'scheduler',
    @updated         INT           = NULL OUTPUT,
    @errors          INT           = NULL OUTPUT,
    @error_text      NVARCHAR(MAX) = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'scheduler');
    SELECT @updated = 0, @errors = 0, @error_text = NULL;

    DECLARE @list TABLE (asset_id BIGINT NOT NULL PRIMARY KEY);
    INSERT @list (asset_id)
    SELECT s.AssetId FROM grac_practice.fn_asset_valuation_state(@organization_id) s
     WHERE s.NotCalculated = 1 OR s.ValuesChanged = 1;

    DECLARE @aid BIGINT, @st NVARCHAR(20), @ms NVARCHAR(500), @ch BIT;
    DECLARE val_cur CURSOR LOCAL STATIC FOR SELECT asset_id FROM @list ORDER BY asset_id;
    OPEN val_cur;
    FETCH NEXT FROM val_cur INTO @aid;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            SET @ch = 0;
            EXEC grac_practice.sp_asset_valuation_apply
                 @organization_id = @organization_id, @asset_id = @aid, @mode = N'AUTO', @source = N'SCHEDULER',
                 @actor = @actor, @out_status = @st OUTPUT, @out_message = @ms OUTPUT, @out_changed = @ch OUTPUT;
            IF @ch = 1 SET @updated = @updated + 1;
        END TRY
        BEGIN CATCH
            IF XACT_STATE() <> 0 ROLLBACK;
            SET @errors = @errors + 1;
            SET @error_text = LEFT(CONCAT(@error_text, CASE WHEN @error_text IS NULL THEN N'' ELSE CHAR(10) END,
                                          N'Asset ', @aid, N' (asset value): ', ERROR_MESSAGE()), 4000);
        END CATCH
        FETCH NEXT FROM val_cur INTO @aid;
    END
    CLOSE val_cur;
    DEALLOCATE val_cur;
END
GO
PRINT '446: sp_asset_valuation_apply and sp_asset_valuation_sync created.';
GO

-- =====================================================================
-- 5. Asset-level method override (5.1.18.5.3: disabled by default; an
--    authorized role and a reason when enabled -- the Web proxy requires
--    asset-register APPROVE). NULL or the configured method removes the
--    override. Stored as the Asset Valuation Method field value of the asset.
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_valuation_method_set
    @organization_id   BIGINT,
    @asset_id          BIGINT,
    @method            NVARCHAR(30)   = NULL,
    @reason_text       NVARCHAR(1000) = NULL,
    @actor_employee_id BIGINT         = NULL,
    @actor             NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @method = NULLIF(UPPER(LTRIM(RTRIM(@method))), N'');
    SET @reason_text = NULLIF(LTRIM(RTRIM(@reason_text)), N'');

    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset
                    WHERE asset_id = @asset_id AND organization_id = @organization_id AND merged_into_asset_id IS NULL)
        THROW 53000, 'Asset not found for this organization.', 1;
    DECLARE @cfg_method NVARCHAR(30), @allowed BIT;
    SELECT TOP (1) @cfg_method = valuation_method, @allowed = override_allowed
      FROM grac_practice.asset_valuation_config
     WHERE organization_id = @organization_id AND is_active_version = 1
     ORDER BY config_id DESC;
    IF @cfg_method IS NULL
        THROW 53001, 'There is no Active valuation configuration. Activate one on Asset Valuation first.', 1;
    IF @method IS NOT NULL AND @method NOT IN (N'MAXIMUM', N'WEIGHTED_AVERAGE', N'SUMMATION')
        THROW 53002, 'Choose Maximum, Weighted Average or Summation.', 1;
    IF @method = @cfg_method SET @method = NULL;
    IF @method IS NOT NULL AND @allowed = 0
        THROW 53003, 'Asset-level method override is not enabled in the Active valuation configuration.', 1;
    IF @reason_text IS NULL
        THROW 53004, 'A reason is required.', 1;

    DECLARE @def INT = (SELECT field_definition_id FROM grac_practice.asset_field_definition WHERE field_key = N'asset_valuation_method');
    DECLARE @before NVARCHAR(30) = (SELECT LEFT(value_text, 30) FROM grac_practice.asset_field_value
                                     WHERE asset_id = @asset_id AND field_definition_id = @def);
    DECLARE @st NVARCHAR(20), @ms NVARCHAR(500), @ch BIT, @src NVARCHAR(30) = N'METHOD_OVERRIDE';

    BEGIN TRAN;
    IF @method IS NULL
    BEGIN
        DELETE FROM grac_practice.asset_field_value WHERE asset_id = @asset_id AND field_definition_id = @def;
    END
    ELSE IF @before IS NULL
    BEGIN
        INSERT grac_practice.asset_field_value (asset_id, field_definition_id, value_text, entered_by)
        VALUES (@asset_id, @def, @method, @actor);
    END
    ELSE
    BEGIN
        UPDATE grac_practice.asset_field_value
           SET value_text = @method, value_number = NULL, value_date = NULL, value_ref = NULL,
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE asset_id = @asset_id AND field_definition_id = @def;
    END
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-valuation', @asset_id, N'METHOD_OVERRIDE',
            (SELECT @before AS methodOverride FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            (SELECT @method AS methodOverride, @cfg_method AS configuredMethod, @reason_text AS reason
                FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    EXEC grac_practice.sp_asset_valuation_apply
         @organization_id = @organization_id, @asset_id = @asset_id, @mode = N'CONTROLLED', @source = @src,
         @reason_text = @reason_text, @actor_employee_id = @actor_employee_id, @actor = @actor,
         @out_status = @st OUTPUT, @out_message = @ms OUTPUT, @out_changed = @ch OUTPUT;
    COMMIT;

    SELECT @asset_id AS AssetId, N'SAVED' AS Result, @st AS ValidationStatus, @ms AS ValidationMessage, @ch AS Changed;
END
GO

-- One asset, now (D138). Moving an asset to a newer configuration version
-- needs a reason; a ratings change does not.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_valuation_recalculate
    @organization_id   BIGINT,
    @asset_id          BIGINT,
    @reason_text       NVARCHAR(1000) = NULL,
    @actor_employee_id BIGINT         = NULL,
    @actor             NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @reason_text = NULLIF(LTRIM(RTRIM(@reason_text)), N'');
    DECLARE @found BIT = 0, @cfg_changed BIT, @state NVARCHAR(30);
    SELECT @found = 1, @cfg_changed = s.ConfigChanged, @state = s.StateCode
      FROM grac_practice.fn_asset_valuation_state(@organization_id) s
     WHERE s.AssetId = @asset_id;
    IF @found = 0 THROW 53000, 'Asset not found for this organization.', 1;
    IF @cfg_changed = 1 AND @reason_text IS NULL
        THROW 53004, 'A reason is required to recalculate this asset with the Active configuration version.', 1;

    DECLARE @st NVARCHAR(20), @ms NVARCHAR(500), @ch BIT;
    BEGIN TRAN;
    EXEC grac_practice.sp_asset_valuation_apply
         @organization_id = @organization_id, @asset_id = @asset_id, @mode = N'CONTROLLED', @source = N'MANUAL',
         @reason_text = @reason_text, @actor_employee_id = @actor_employee_id, @actor = @actor,
         @out_status = @st OUTPUT, @out_message = @ms OUTPUT, @out_changed = @ch OUTPUT;
    IF @ch = 1
        INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
        VALUES (N'asset-valuation', @asset_id, N'RECALCULATE',
                (SELECT @state AS state FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
                (SELECT @st AS validationStatus, @reason_text AS reason FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
                N'Active', @actor);
    COMMIT;

    SELECT @asset_id AS AssetId, CASE WHEN @ch = 1 THEN N'RECALCULATED' ELSE N'UNCHANGED' END AS Result,
           @st AS ValidationStatus, @ms AS ValidationMessage, @ch AS Changed;
END
GO
PRINT '446: method override and single-asset recalculation created.';
GO

-- =====================================================================
-- 6. Controlled recalculation (5.1.18.5.7 / 5.1.18.5.8): impact analysis
--    first, then a run with a reason, against the count the preview showed.
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_valuation_recalc_preview
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53007, 'Organization not found.', 1;

    SELECT s.AssetId, s.AssetName, s.StateCode, s.StoredConfigVersionNo, s.StoredScore, s.StoredCategory, s.StoredStatus,
           s.ConfigVersionNo, s.ValidationStatus, s.ValidationMessage,
           CASE WHEN s.ValidationStatus = N'VALID' THEN s.AssetValueScore END AS NewScore,
           CASE WHEN s.ValidationStatus = N'VALID' THEN s.AssetValueCategory END AS NewCategory
      INTO #aff
      FROM grac_practice.fn_asset_valuation_state(@organization_id) s
     WHERE s.IsCurrent = 0;

    -- 1. Summary
    SELECT c.config_id AS ActiveConfigId, c.version_no AS ActiveVersionNo, c.valuation_method AS ValuationMethod,
           c.override_allowed AS OverrideAllowed,
           (SELECT COUNT(*) FROM #aff) AS AffectedAssets,
           (SELECT COUNT(*) FROM #aff WHERE StateCode = N'NOT_CALCULATED') AS NotCalculated,
           (SELECT COUNT(*) FROM #aff WHERE StateCode IN (N'CONFIG_CHANGED', N'CONFIG_AND_VALUES')) AS ConfigChanged,
           (SELECT COUNT(*) FROM #aff WHERE StateCode = N'VALUES_CHANGED') AS ValuesChanged,
           (SELECT COUNT(*) FROM #aff WHERE ISNULL(StoredCategory, N'') <> ISNULL(NewCategory, N'')) AS CategoryChanges,
           (SELECT COUNT(*) FROM #aff WHERE ValidationStatus IN (N'INCOMPLETE', N'INVALID')) AS NotValidAfter,
           (SELECT COUNT(DISTINCT m.risk_register_id)
              FROM grac_practice.risk_dependency_map m
              JOIN grac_practice.dependency_type_master dt ON dt.dependency_type_id = m.dependency_type_id
                                                          AND (dt.dependency_type_code = N'ASSET' OR dt.dependency_type_name = N'Asset')
             WHERE m.organization_id = @organization_id
               AND m.dependency_object_id IN (SELECT AssetId FROM #aff)) AS LinkedRisks,
           (SELECT COUNT(*) FROM grac_practice.asset_valuation_result r
             WHERE r.organization_id = @organization_id AND r.validation_status = N'VALID') AS ValuedAssets,
           (SELECT COUNT(*) FROM grac_practice.asset_valuation_recalc_run r
             WHERE r.organization_id = @organization_id AND r.status = N'RUNNING') AS RunsInProgress
      FROM grac_practice.organization o
      LEFT JOIN grac_practice.asset_valuation_config c ON c.organization_id = o.organization_id AND c.is_active_version = 1
     WHERE o.organization_id = @organization_id;

    -- 2. Category moves
    SELECT StoredStatus AS FromStatus, StoredCategory AS FromCategory, ValidationStatus AS ToStatus, NewCategory AS ToCategory,
           COUNT(*) AS AssetCount
      FROM #aff
     GROUP BY StoredStatus, StoredCategory, ValidationStatus, NewCategory
     ORDER BY COUNT(*) DESC, StoredCategory, NewCategory;

    -- 3. Affected assets (first 500)
    SELECT TOP (500) f.AssetId, f.AssetName, f.StateCode, f.StoredConfigVersionNo, f.StoredScore, f.StoredCategory, f.StoredStatus,
           f.ConfigVersionNo, f.NewScore, f.NewCategory, f.ValidationStatus AS NewStatus, f.ValidationMessage AS Message,
           ISNULL(rl.RiskCount, 0) AS RiskCount
      FROM #aff f
      LEFT JOIN grac_practice.fn_asset_valuation_risk_links(@organization_id) rl ON rl.AssetId = f.AssetId
     ORDER BY CASE WHEN ISNULL(f.StoredCategory, N'') <> ISNULL(f.NewCategory, N'') THEN 0 ELSE 1 END, f.AssetName;

    -- 4. Recent runs
    SELECT TOP (20) r.run_id AS RunId, r.status AS Status, cv.version_no AS ConfigVersionNo, r.reason_text AS Reason,
           r.affected_count AS AffectedCount, r.updated_count AS UpdatedCount, r.error_count AS ErrorCount,
           r.error_text AS ErrorText, r.started_dt AS StartedDt, r.finished_dt AS FinishedDt, r.entered_by AS EnteredBy
      FROM grac_practice.asset_valuation_recalc_run r
      LEFT JOIN grac_practice.asset_valuation_config cv ON cv.config_id = r.config_id
     WHERE r.organization_id = @organization_id
     ORDER BY r.run_id DESC;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_valuation_recalc_run
    @organization_id   BIGINT,
    @reason_text       NVARCHAR(1000) = NULL,
    @expected_affected INT            = NULL,
    @actor_employee_id BIGINT         = NULL,
    @actor             NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @reason_text = NULLIF(LTRIM(RTRIM(@reason_text)), N'');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53007, 'Organization not found.', 1;
    IF @reason_text IS NULL
        THROW 53004, 'A reason is required for a recalculation run.', 1;

    DECLARE @res NVARCHAR(255) = CONCAT(N'grac_practice.asset_valuation_recalc.', @organization_id), @lock INT;
    EXEC @lock = sp_getapplock @Resource = @res, @LockMode = N'Exclusive', @LockOwner = N'Session', @LockTimeout = 0;
    IF @lock < 0
        THROW 53006, 'Another recalculation run is in progress for this organization.', 1;

    DECLARE @run BIGINT, @n INT = 0, @updated INT = 0, @errors INT = 0, @err NVARCHAR(MAX) = NULL,
            @aid BIGINT, @st NVARCHAR(20), @ms NVARCHAR(500), @ch BIT, @cfg BIGINT, @msg NVARCHAR(400);
    DECLARE @list TABLE (asset_id BIGINT NOT NULL PRIMARY KEY);
    BEGIN TRY
        INSERT @list (asset_id)
        SELECT s.AssetId FROM grac_practice.fn_asset_valuation_state(@organization_id) s WHERE s.IsCurrent = 0;
        SET @n = (SELECT COUNT(*) FROM @list);
        IF @expected_affected IS NOT NULL AND @expected_affected <> @n
        BEGIN
            SET @msg = CONCAT(N'The affected assets changed since the preview (', @expected_affected, N' then, ', @n,
                              N' now). Review the impact again and rerun.');
            THROW 53005, @msg, 1;
        END
        SET @cfg = (SELECT TOP (1) config_id FROM grac_practice.asset_valuation_config
                     WHERE organization_id = @organization_id AND is_active_version = 1 ORDER BY config_id DESC);
        INSERT grac_practice.asset_valuation_recalc_run (organization_id, config_id, reason_text, affected_count, actor_employee_id, entered_by)
        VALUES (@organization_id, @cfg, @reason_text, @n, @actor_employee_id, @actor);
        SET @run = SCOPE_IDENTITY();

        DECLARE run_cur CURSOR LOCAL STATIC FOR SELECT asset_id FROM @list ORDER BY asset_id;
        OPEN run_cur;
        FETCH NEXT FROM run_cur INTO @aid;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            BEGIN TRY
                SET @ch = 0;
                EXEC grac_practice.sp_asset_valuation_apply
                     @organization_id = @organization_id, @asset_id = @aid, @mode = N'CONTROLLED', @source = N'RECALC_RUN',
                     @reason_text = @reason_text, @run_id = @run, @actor_employee_id = @actor_employee_id, @actor = @actor,
                     @out_status = @st OUTPUT, @out_message = @ms OUTPUT, @out_changed = @ch OUTPUT;
                IF @ch = 1 SET @updated = @updated + 1;
            END TRY
            BEGIN CATCH
                IF XACT_STATE() <> 0 ROLLBACK;
                SET @errors = @errors + 1;
                SET @err = LEFT(CONCAT(@err, CASE WHEN @err IS NULL THEN N'' ELSE CHAR(10) END,
                                       N'Asset ', @aid, N': ', ERROR_MESSAGE()), 4000);
            END CATCH
            FETCH NEXT FROM run_cur INTO @aid;
        END
        CLOSE run_cur;
        DEALLOCATE run_cur;

        UPDATE grac_practice.asset_valuation_recalc_run
           SET status = CASE WHEN @errors > 0 THEN N'COMPLETED_WITH_ERRORS' ELSE N'COMPLETED' END,
               updated_count = @updated, error_count = @errors, error_text = @err, finished_dt = SYSUTCDATETIME()
         WHERE run_id = @run;
        INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
        VALUES (N'asset-valuation-run', @run, N'RECALCULATE', NULL,
                (SELECT @cfg AS configId, @n AS affected, @updated AS updated, @errors AS errors, @reason_text AS reason
                    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
                N'Active', @actor);
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK;
        IF CURSOR_STATUS('local', 'run_cur') >= -1
        BEGIN
            IF CURSOR_STATUS('local', 'run_cur') >= 0 CLOSE run_cur;
            DEALLOCATE run_cur;
        END
        EXEC sp_releaseapplock @Resource = @res, @LockOwner = N'Session';
        IF @run IS NOT NULL
            UPDATE grac_practice.asset_valuation_recalc_run
               SET status = N'FAILED', updated_count = @updated, error_count = @errors + 1, finished_dt = SYSUTCDATETIME(),
                   error_text = LEFT(CONCAT(@err, CASE WHEN @err IS NULL THEN N'' ELSE CHAR(10) END, ERROR_MESSAGE()), 4000)
             WHERE run_id = @run;
        THROW;
    END CATCH
    EXEC sp_releaseapplock @Resource = @res, @LockOwner = N'Session';

    SELECT r.run_id AS RunId, r.status AS Result, r.affected_count AS AffectedCount, r.updated_count AS UpdatedCount,
           r.error_count AS ErrorCount, r.error_text AS ErrorText
      FROM grac_practice.asset_valuation_recalc_run r WHERE r.run_id = @run;
END
GO

-- One asset: current value, state against the Active configuration, history.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_valuation_get
    @organization_id BIGINT,
    @asset_id        BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset
                    WHERE asset_id = @asset_id AND organization_id = @organization_id AND merged_into_asset_id IS NULL)
        THROW 53000, 'Asset not found for this organization.', 1;

    -- 1. State
    SELECT s.AssetId, s.ConfigId, s.ConfigVersionNo, c.valuation_method AS ConfiguredMethod, c.override_allowed AS OverrideAllowed,
           s.Confidentiality, s.Integrity, s.Availability, s.MethodOverride, s.MethodUsed, s.MethodSource,
           CASE WHEN s.ValidationStatus = N'VALID' THEN s.AssetValueScore END AS AssetValueScore,
           CASE WHEN s.ValidationStatus = N'VALID' THEN s.AssetValueCategory END AS AssetValueCategory,
           s.ValidationStatus, s.ValidationMessage,
           s.StoredConfigId, s.StoredConfigVersionNo, s.StoredConfidentiality, s.StoredIntegrity, s.StoredAvailability, s.StoredMethodUsed, s.StoredMethodSource, s.StoredScore, s.StoredCategory,
           s.StoredStatus, s.StoredMessage, s.StoredSource, s.CalculatedBy, s.CalculatedDt,
           s.StateCode, s.IsCurrent, s.ConfigChanged, s.ValuesChanged, s.NotCalculated,
           b.treatment_guidance AS TreatmentGuidance
      FROM grac_practice.fn_asset_valuation_state(@organization_id) s
      LEFT JOIN grac_practice.asset_valuation_config c ON c.config_id = s.ConfigId
      LEFT JOIN grac_practice.asset_valuation_result r ON r.asset_id = s.AssetId
      LEFT JOIN grac_practice.asset_value_band b ON b.band_id = r.band_id
     WHERE s.AssetId = @asset_id;

    -- 2. History (newest first)
    SELECT TOP (100) h.history_id AS HistoryId, h.source AS Source, h.run_id AS RunId, h.reason_text AS Reason,
           h.prev_config_version AS PrevConfigVersionNo, h.prev_confidentiality AS PrevConfidentiality,
           h.prev_integrity AS PrevIntegrity, h.prev_availability AS PrevAvailability, h.prev_method_used AS PrevMethodUsed,
           h.prev_score AS PrevScore, h.prev_category AS PrevCategory, h.prev_status AS PrevStatus,
           h.new_config_version AS ConfigVersionNo, h.confidentiality AS Confidentiality, h.integrity AS Integrity,
           h.availability AS Availability, h.method_used AS MethodUsed, h.method_source AS MethodSource,
           h.new_score AS Score, h.new_category AS Category, h.new_status AS Status, h.message AS Message,
           h.entered_by AS EnteredBy, h.entered_dt AS EnteredDt
      FROM grac_practice.asset_valuation_history h
     WHERE h.asset_id = @asset_id AND h.organization_id = @organization_id
     ORDER BY h.history_id DESC;
END
GO
PRINT '446: recalculation preview / run and asset valuation reader created.';
GO

