-- =====================================================================
-- 10. Results (7.1.2, 7.1.6; D69-D72)
-- =====================================================================
-- Applies an approved result (inside the transaction of the caller): the
-- occurrence is completed on the performed date; the register is updated --
-- Pass: last date (never moved back), certificate number and expiry;
-- Renewed: the expiry date; Fail / Not renewed: nothing (the schedule
-- turns Failed / Overdue). A reconciliation flag raised because the task
-- was closed first is cleared.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_result_apply
    @result_id BIGINT,
    @actor     NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @occ BIGINT, @asset BIGINT, @outcome NVARCHAR(12), @performed DATE, @cert_no NVARCHAR(100), @cert_exp DATE,
            @new_exp DATE, @sub_emp BIGINT, @last_key NVARCHAR(100), @cert_no_key NVARCHAR(100), @cert_exp_key NVARCHAR(100),
            @expiry_key NVARCHAR(100), @cur DATE, @val NVARCHAR(400);
    SELECT @occ = r.occurrence_id, @asset = o.asset_id, @outcome = r.outcome, @performed = r.performed_date,
           @cert_no = r.certificate_number, @cert_exp = r.certificate_expiry, @new_exp = r.new_expiry,
           @sub_emp = r.submitted_by_employee_id, @last_key = t.last_date_field_key,
           @cert_no_key = t.certificate_number_field_key, @cert_exp_key = t.certificate_expiry_field_key,
           @expiry_key = t.expiry_field_key
      FROM grac_practice.asset_activity_result r
      JOIN grac_practice.asset_activity_occurrence o ON o.occurrence_id = r.occurrence_id
      JOIN grac_practice.asset_activity_template t ON t.template_code = o.template_code
     WHERE r.result_id = @result_id AND r.state = N'APPROVED';
    IF @occ IS NULL RETURN;

    UPDATE grac_practice.asset_activity_occurrence
       SET status = N'COMPLETED', completed_dt = CAST(@performed AS DATETIME2), completed_by_employee_id = @sub_emp,
           closed_dt = SYSUTCDATETIME(),
           needs_reconciliation = CASE WHEN reconciliation_reason LIKE N'The Task Centre task was closed without an approved result%'
                                       THEN 0 ELSE needs_reconciliation END,
           updated_by = @actor, updated_dt = SYSUTCDATETIME()
     WHERE occurrence_id = @occ AND status = N'OPEN';
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-activity-occurrence', @occ, N'COMPLETED', N'{"status":"OPEN"}',
            (SELECT N'COMPLETED' AS status, @outcome AS outcome, @performed AS performedDate FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);

    IF @outcome = N'PASS' AND @last_key IS NOT NULL
    BEGIN
        SET @cur = (SELECT v.value_date FROM grac_practice.asset_field_value v
                      JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id AND f.field_key = @last_key
                     WHERE v.asset_id = @asset);
        IF @cur IS NULL OR @cur < @performed
        BEGIN
            SET @val = CONVERT(NVARCHAR(10), @performed, 23);
            EXEC grac_practice.sp_asset_field_value_set @asset_id = @asset, @field_key = @last_key, @value = @val, @actor = @actor;
        END
    END
    IF @outcome = N'PASS' AND @cert_no_key IS NOT NULL AND @cert_no IS NOT NULL
    BEGIN
        SET @val = @cert_no;
        EXEC grac_practice.sp_asset_field_value_set @asset_id = @asset, @field_key = @cert_no_key, @value = @val, @actor = @actor;
    END
    IF @outcome = N'PASS' AND @cert_exp_key IS NOT NULL AND @cert_exp IS NOT NULL
    BEGIN
        SET @val = CONVERT(NVARCHAR(10), @cert_exp, 23);
        EXEC grac_practice.sp_asset_field_value_set @asset_id = @asset, @field_key = @cert_exp_key, @value = @val, @actor = @actor;
    END
    IF @outcome = N'RENEWED' AND @expiry_key IS NOT NULL AND @new_exp IS NOT NULL
    BEGIN
        SET @val = CONVERT(NVARCHAR(10), @new_exp, 23);
        EXEC grac_practice.sp_asset_field_value_set @asset_id = @asset, @field_key = @expiry_key, @value = @val, @actor = @actor;
    END
END
GO

-- Save (draft) or submit the result of an open asset-task occurrence.
-- Submitted: approved at once when the organization does not require a
-- reviewer for the activity, else waiting for another person (D70).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_result_save
    @organization_id         BIGINT,
    @occurrence_id           BIGINT,
    @outcome                 NVARCHAR(12)   = NULL,     -- PASS | FAIL (execution), RENEWED | NOT_RENEWED (renewal)
    @performed_date          DATE           = NULL,
    @certificate_number      NVARCHAR(100)  = NULL,
    @certificate_expiry      DATE           = NULL,
    @new_expiry              DATE           = NULL,
    @evidence_reference      NVARCHAR(400)  = NULL,
    @result_note             NVARCHAR(2000) = NULL,
    @submit                  BIT            = 0,
    @expected_record_version BIGINT         = NULL,     -- of the result
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @outcome = NULLIF(UPPER(LTRIM(RTRIM(@outcome))), N'');
    SET @certificate_number = NULLIF(LTRIM(RTRIM(@certificate_number)), N'');
    SET @evidence_reference = NULLIF(LTRIM(RTRIM(@evidence_reference)), N'');
    SET @result_note = NULLIF(LTRIM(RTRIM(@result_note)), N'');
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    DECLARE @found BIT = 0, @status NVARCHAR(12), @decision NVARCHAR(20), @tpl NVARCHAR(40), @kind NVARCHAR(12), @asset BIGINT,
            @cert_key NVARCHAR(100), @expiry_key NVARCHAR(100), @review BIT, @cur_exp DATE;
    SELECT @found = 1, @status = o.status, @decision = o.decision, @tpl = o.template_code, @kind = t.activity_kind,
           @asset = o.asset_id, @cert_key = t.certificate_number_field_key, @expiry_key = t.expiry_field_key
      FROM grac_practice.asset_activity_occurrence o
      JOIN grac_practice.asset_activity_template t ON t.template_code = o.template_code
     WHERE o.occurrence_id = @occurrence_id AND o.organization_id = @organization_id;
    IF @found = 0 THROW 54670, 'Activity occurrence not found for this organization.', 1;
    IF @status <> N'OPEN' OR @decision <> N'ASSET_TASK'
        THROW 54671, 'A result is recorded only on an open asset task occurrence.', 1;
    SET @review = (SELECT ResultReviewRequired FROM grac_practice.fn_asset_activity_settings(@organization_id) WHERE TemplateCode = @tpl);

    DECLARE @rid BIGINT, @rstate NVARCHAR(12), @rv BIGINT, @before NVARCHAR(MAX);
    SELECT @rid = result_id, @rstate = state, @rv = CONVERT(BIGINT, record_version),
           @before = (SELECT r2.state AS state, r2.outcome AS outcome, r2.performed_date AS performedDate
                        FROM grac_practice.asset_activity_result r2 WHERE r2.result_id = r.result_id
                         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
      FROM grac_practice.asset_activity_result r
     WHERE r.occurrence_id = @occurrence_id;
    IF @rstate IN (N'SUBMITTED', N'APPROVED')
        THROW 54678, 'The result is waiting for review or already approved; it cannot be changed.', 1;
    IF @expected_record_version IS NOT NULL AND @rv IS NOT NULL AND @expected_record_version <> @rv
        THROW 54680, 'The result was changed by someone else; reload it and try again.', 1;

    IF @outcome IS NOT NULL
       AND NOT ((@kind = N'EXECUTION' AND @outcome IN (N'PASS', N'FAIL')) OR (@kind = N'RENEWAL' AND @outcome IN (N'RENEWED', N'NOT_RENEWED')))
        THROW 54672, 'The outcome is Pass or Fail for this activity, Renewed or Not renewed for a renewal.', 1;
    IF @performed_date > @today
        THROW 54673, 'The performed date cannot be in the future.', 1;
    IF @certificate_expiry IS NOT NULL AND @performed_date IS NOT NULL AND @certificate_expiry <= @performed_date
        THROW 54675, 'The certificate expiry must follow the performed (certificate issue) date.', 1;
    IF ISNULL(@submit, 0) = 1
    BEGIN
        IF @outcome IS NULL
            THROW 54672, 'Select the outcome before submitting.', 1;
        IF @performed_date IS NULL
            THROW 54673, 'Enter the performed date before submitting.', 1;
        IF @outcome = N'PASS' AND @cert_key IS NOT NULL AND @certificate_number IS NULL
            THROW 54674, 'The certificate number is required after a successful result.', 1;
        IF @outcome = N'RENEWED'
        BEGIN
            SET @cur_exp = (SELECT v.value_date FROM grac_practice.asset_field_value v
                              JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id
                                                                         AND f.field_key = @expiry_key
                             WHERE v.asset_id = @asset);
            IF @new_expiry IS NULL OR @new_expiry <= @performed_date OR (@cur_exp IS NOT NULL AND @new_expiry <= @cur_exp)
                THROW 54676, 'Enter the new expiry date: after the performed date and after the current expiry.', 1;
        END
        IF @outcome IN (N'FAIL', N'NOT_RENEWED') AND @result_note IS NULL
            THROW 54677, 'Describe the failure or the reason it was not renewed in the note.', 1;
    END

    DECLARE @new_state NVARCHAR(12) = CASE WHEN ISNULL(@submit, 0) = 0 THEN N'DRAFT'
                                           WHEN ISNULL(@review, 0) = 1 THEN N'SUBMITTED' ELSE N'APPROVED' END;
    BEGIN TRAN;
    IF @rid IS NULL
    BEGIN
        INSERT grac_practice.asset_activity_result
            (organization_id, occurrence_id, state, outcome, performed_date, certificate_number, certificate_expiry, new_expiry,
             evidence_reference, result_note, entered_by)
        VALUES (@organization_id, @occurrence_id, N'DRAFT', @outcome, @performed_date, @certificate_number, @certificate_expiry,
                @new_expiry, @evidence_reference, @result_note, @actor);
        SET @rid = SCOPE_IDENTITY();
    END
    ELSE
        UPDATE grac_practice.asset_activity_result
           SET outcome = @outcome, performed_date = @performed_date, certificate_number = @certificate_number,
               certificate_expiry = @certificate_expiry, new_expiry = @new_expiry, evidence_reference = @evidence_reference,
               result_note = @result_note, updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE result_id = @rid;

    UPDATE grac_practice.asset_activity_result
       SET state = @new_state,
           submitted_by = CASE WHEN @new_state = N'DRAFT' THEN submitted_by ELSE @actor END,
           submitted_by_employee_id = CASE WHEN @new_state = N'DRAFT' THEN submitted_by_employee_id ELSE @actor_employee_id END,
           submitted_dt = CASE WHEN @new_state = N'DRAFT' THEN submitted_dt ELSE SYSUTCDATETIME() END,
           decided_by = CASE WHEN @new_state = N'APPROVED' THEN @actor ELSE NULL END,
           decided_by_employee_id = CASE WHEN @new_state = N'APPROVED' THEN @actor_employee_id ELSE NULL END,
           decided_dt = CASE WHEN @new_state = N'APPROVED' THEN SYSUTCDATETIME() ELSE NULL END,
           decision_note = CASE WHEN @new_state = N'APPROVED' THEN N'No reviewer is required for this activity by the organization settings.'
                                ELSE NULL END
     WHERE result_id = @rid;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-activity-result', @rid, CASE @new_state WHEN N'DRAFT' THEN N'SAVE' ELSE N'SUBMIT' END, @before,
            (SELECT @new_state AS state, @outcome AS outcome, @performed_date AS performedDate, @certificate_number AS certificateNumber,
                    @certificate_expiry AS certificateExpiry, @new_expiry AS newExpiry, @evidence_reference AS evidenceReference
                FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    IF @new_state = N'APPROVED'
        EXEC grac_practice.sp_asset_activity_result_apply @result_id = @rid, @actor = @actor;
    COMMIT;
    SELECT @occurrence_id AS OccurrenceId, @new_state AS Result;
END
GO

-- Approve or return a submitted result. The person who submitted it
-- cannot decide it (segregation of duties).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_result_decide
    @organization_id         BIGINT,
    @occurrence_id           BIGINT,
    @decision                NVARCHAR(10),       -- APPROVE | RETURN
    @decision_note           NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @decision = UPPER(LTRIM(RTRIM(ISNULL(@decision, N''))));
    SET @decision_note = NULLIF(LTRIM(RTRIM(@decision_note)), N'');
    DECLARE @found BIT = 0, @ostatus NVARCHAR(12);
    SELECT @found = 1, @ostatus = status FROM grac_practice.asset_activity_occurrence
     WHERE occurrence_id = @occurrence_id AND organization_id = @organization_id;
    IF @found = 0 THROW 54670, 'Activity occurrence not found for this organization.', 1;
    DECLARE @rid BIGINT, @rstate NVARCHAR(12), @rv BIGINT, @sub_by NVARCHAR(100), @sub_emp BIGINT;
    SELECT @rid = result_id, @rstate = state, @rv = CONVERT(BIGINT, record_version), @sub_by = submitted_by,
           @sub_emp = submitted_by_employee_id
      FROM grac_practice.asset_activity_result WHERE occurrence_id = @occurrence_id;
    IF @decision NOT IN (N'APPROVE', N'RETURN')
        THROW 54681, 'The decision must be Approve or Return.', 1;
    IF @rid IS NULL OR @rstate <> N'SUBMITTED'
        THROW 54678, 'There is no submitted result waiting for review.', 1;
    IF @ostatus <> N'OPEN'
        THROW 54671, 'The occurrence is no longer open.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 54680, 'The result was changed by someone else; reload it and try again.', 1;
    IF @sub_by = @actor OR (@sub_emp IS NOT NULL AND @sub_emp = @actor_employee_id)
        THROW 54679, 'Segregation of duties: the person who submitted the result cannot review it.', 1;
    IF @decision = N'RETURN' AND @decision_note IS NULL
        THROW 54677, 'Give the reason for returning the result.', 1;

    DECLARE @new_state NVARCHAR(12) = CASE @decision WHEN N'APPROVE' THEN N'APPROVED' ELSE N'RETURNED' END;
    BEGIN TRAN;
    UPDATE grac_practice.asset_activity_result
       SET state = @new_state, decided_by = @actor, decided_by_employee_id = @actor_employee_id, decided_dt = SYSUTCDATETIME(),
           decision_note = @decision_note, updated_by = @actor, updated_dt = SYSUTCDATETIME()
     WHERE result_id = @rid;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-activity-result', @rid, @decision, N'{"state":"SUBMITTED"}',
            (SELECT @new_state AS state, @decision_note AS note FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), N'Active', @actor);
    IF @new_state = N'APPROVED'
        EXEC grac_practice.sp_asset_activity_result_apply @result_id = @rid, @actor = @actor;
    COMMIT;
    SELECT @occurrence_id AS OccurrenceId, @new_state AS Result;
END
GO
PRINT '439: result procedures created.';
GO

-- =====================================================================
-- 11. Dispositions (7.1.5; D73-D76)
-- =====================================================================
-- Applies an approved disposition (inside the transaction of the caller).
--   Reschedule: the occurrence keeps its due date and gets the revised due
--     date; an open task gets it as its approved extended due date (the
--     192 invariant sla_due_at = COALESCE(extended, standard)) with a task
--     activity entry; notifications move with it (437 sweep re-issued).
--   Waive / Not applicable / Exception: the occurrence is Waived until the
--     review date; an Open / Assigned / In progress task is cancelled with
--     the reason; a task in another state is left to its owner (noted).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_disposition_apply
    @disposition_id    BIGINT,
    @actor_employee_id BIGINT        = NULL,
    @actor             NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @occ BIGINT, @type NVARCHAR(16), @reason NVARCHAR(1000), @revised DATE, @review DATE, @task BIGINT,
            @task_status NVARCHAR(60), @old_due DATETIME2, @new_due DATETIME2, @note NVARCHAR(400), @remark NVARCHAR(MAX),
            @from NVARCHAR(400), @to NVARCHAR(400), @reason_text NVARCHAR(1000);
    SELECT @occ = d.occurrence_id, @type = d.disposition_type, @reason = d.reason, @revised = d.revised_due_date,
           @review = d.review_date, @task = o.task_id
      FROM grac_practice.asset_activity_disposition d
      JOIN grac_practice.asset_activity_occurrence o ON o.occurrence_id = d.occurrence_id
     WHERE d.disposition_id = @disposition_id AND d.status = N'APPROVED';
    IF @occ IS NULL RETURN;
    SELECT @task_status = s.status_code, @old_due = t.sla_due_at
      FROM grac_practice.practice_task t
      JOIN grac_practice.entity_status_master s ON s.entity_status_id = t.current_status_id
     WHERE t.task_id = @task;

    IF @type = N'RESCHEDULE'
    BEGIN
        UPDATE grac_practice.asset_activity_occurrence
           SET revised_due_date = @revised, updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE occurrence_id = @occ;
        IF @task IS NOT NULL AND @task_status NOT IN (N'Closed', N'Cancelled')
        BEGIN
            SET @new_due = CAST(@revised AS DATETIME2);
            UPDATE grac_practice.practice_task
               SET approved_extended_due_at = @new_due, sla_due_at = @new_due, sla_source_code = N'EXTENDED',
                   updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE task_id = @task;
            SELECT @remark = CONCAT(N'Asset activity rescheduled (approved disposition ', @disposition_id, N'): ', @reason),
                   @from = CONVERT(NVARCHAR(30), @old_due, 126), @to = CONVERT(NVARCHAR(30), @new_due, 126);
            EXEC grac_practice.sp_task_activity_add @task_id = @task, @activity_type_code = N'SlaExtensionApproved',
                 @remark = @remark, @from_value = @from, @to_value = @to,
                 @actor_employee_id = @actor_employee_id, @caller_display_name = @actor;
            SET @note = CONCAT(N'Task due date moved to ', CONVERT(NVARCHAR(10), @revised, 23), N'.');
        END
        ELSE IF @task IS NOT NULL
            SET @note = CONCAT(N'The task is ', @task_status, N'; its due date was not changed.');
    END
    ELSE
    BEGIN
        UPDATE grac_practice.asset_activity_occurrence
           SET status = N'WAIVED', review_date = @review, closed_dt = SYSUTCDATETIME(), needs_reconciliation = 0,
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE occurrence_id = @occ AND status = N'OPEN';
        IF @task IS NOT NULL AND @task_status IN (N'Open', N'Assigned', N'InProgress')
        BEGIN
            SET @reason_text = LEFT(CONCAT(CASE @type WHEN N'WAIVE' THEN N'Waived' WHEN N'NOT_APPLICABLE' THEN N'Not applicable'
                                                      ELSE N'Exception' END,
                                           N' until ', CONVERT(NVARCHAR(10), @review, 23), N': ', @reason), 1000);
            EXEC grac_practice.sp_task_transition @task_id = @task, @to_status_code = N'Cancelled',
                 @actor_employee_id = @actor_employee_id, @reason_code = N'ASSET_DISPOSITION', @reason_text = @reason_text;
            SET @note = N'Task cancelled.';
        END
        ELSE IF @task IS NOT NULL AND @task_status NOT IN (N'Closed', N'Cancelled')
            SET @note = CONCAT(N'The task is ', @task_status, N'; close or cancel it in Task Centre.');
    END
    UPDATE grac_practice.asset_activity_disposition SET task_note = @note WHERE disposition_id = @disposition_id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-activity-occurrence', @occ, @type, NULL,
            (SELECT @disposition_id AS dispositionId, @revised AS revisedDueDate, @review AS reviewDate, @note AS taskNote
                FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
END
GO

-- Request a reschedule, waiver, not-applicable or exception outcome for an
-- open occurrence: reason always; revised due date (reschedule) or review
-- date (the others). Approved at once when the organization does not
-- require approval for the activity.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_disposition_request
    @organization_id         BIGINT,
    @occurrence_id           BIGINT,
    @disposition_type        NVARCHAR(16),
    @reason                  NVARCHAR(1000) = NULL,
    @revised_due_date        DATE           = NULL,
    @review_date             DATE           = NULL,
    @expected_record_version BIGINT         = NULL,     -- of the occurrence
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @disposition_type = UPPER(LTRIM(RTRIM(ISNULL(@disposition_type, N''))));
    SET @reason = NULLIF(LTRIM(RTRIM(@reason)), N'');
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    DECLARE @found BIT = 0, @status NVARCHAR(12), @due DATE, @eff_due DATE, @tpl NVARCHAR(40), @rv BIGINT, @approval BIT;
    SELECT @found = 1, @status = status, @due = due_date, @eff_due = ISNULL(revised_due_date, due_date), @tpl = template_code,
           @rv = CONVERT(BIGINT, record_version)
      FROM grac_practice.asset_activity_occurrence
     WHERE occurrence_id = @occurrence_id AND organization_id = @organization_id;
    IF @found = 0 THROW 54670, 'Activity occurrence not found for this organization.', 1;
    IF @status <> N'OPEN' THROW 54671, 'Only an open occurrence can be rescheduled, waived or excepted.', 1;
    IF @disposition_type NOT IN (N'RESCHEDULE', N'WAIVE', N'NOT_APPLICABLE', N'EXCEPTION')
        THROW 54682, 'The outcome is Reschedule, Waive, Not applicable or Exception.', 1;
    IF @reason IS NULL THROW 54677, 'Enter the reason.', 1;
    IF @disposition_type = N'RESCHEDULE' AND (@revised_due_date IS NULL OR @revised_due_date < @today OR @revised_due_date = @eff_due)
        THROW 54683, 'Enter a revised due date from today on, different from the current due date.', 1;
    IF @disposition_type <> N'RESCHEDULE' AND (@review_date IS NULL OR @review_date <= @today)
        THROW 54684, 'Enter the review date (after today) until which the outcome applies.', 1;
    IF EXISTS (SELECT 1 FROM grac_practice.asset_activity_disposition WHERE occurrence_id = @occurrence_id AND status = N'PENDING')
        THROW 54685, 'A request is already waiting for approval on this occurrence.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 54680, 'The occurrence was changed by someone else; reload it and try again.', 1;
    SET @approval = (SELECT DispositionApprovalRequired FROM grac_practice.fn_asset_activity_settings(@organization_id)
                      WHERE TemplateCode = @tpl);

    DECLARE @id BIGINT, @new_status NVARCHAR(12) = CASE WHEN ISNULL(@approval, 1) = 1 THEN N'PENDING' ELSE N'APPROVED' END;
    BEGIN TRAN;
    INSERT grac_practice.asset_activity_disposition
        (organization_id, occurrence_id, disposition_type, reason, previous_due_date, revised_due_date, review_date, status,
         requested_by, requested_by_employee_id, decided_by, decided_by_employee_id, decided_dt, decision_note)
    VALUES (@organization_id, @occurrence_id, @disposition_type, @reason, @eff_due,
            CASE WHEN @disposition_type = N'RESCHEDULE' THEN @revised_due_date END,
            CASE WHEN @disposition_type <> N'RESCHEDULE' THEN @review_date END,
            @new_status, @actor, @actor_employee_id,
            CASE WHEN @new_status = N'APPROVED' THEN @actor END,
            CASE WHEN @new_status = N'APPROVED' THEN @actor_employee_id END,
            CASE WHEN @new_status = N'APPROVED' THEN SYSUTCDATETIME() END,
            CASE WHEN @new_status = N'APPROVED' THEN N'No approval is required for this activity by the organization settings.' END);
    SET @id = SCOPE_IDENTITY();
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-activity-disposition', @id, N'REQUEST', NULL,
            (SELECT @occurrence_id AS occurrenceId, @disposition_type AS dispositionType, @reason AS reason,
                    @revised_due_date AS revisedDueDate, @review_date AS reviewDate, @new_status AS status
                FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    IF @new_status = N'APPROVED'
        EXEC grac_practice.sp_asset_activity_disposition_apply @disposition_id = @id, @actor_employee_id = @actor_employee_id, @actor = @actor;
    COMMIT;
    SELECT @id AS DispositionId, @new_status AS Result;
END
GO

-- Approve / reject (another person; reject needs a note) or withdraw (the
-- requester) a pending disposition.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_disposition_decide
    @organization_id         BIGINT,
    @disposition_id          BIGINT,
    @decision                NVARCHAR(10),       -- APPROVE | REJECT | WITHDRAW
    @decision_note           NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @decision = UPPER(LTRIM(RTRIM(ISNULL(@decision, N''))));
    SET @decision_note = NULLIF(LTRIM(RTRIM(@decision_note)), N'');
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    DECLARE @found BIT = 0, @status NVARCHAR(12), @rv BIGINT, @req_by NVARCHAR(100), @req_emp BIGINT, @type NVARCHAR(16),
            @revised DATE, @review DATE, @ostatus NVARCHAR(12);
    SELECT @found = 1, @status = d.status, @rv = CONVERT(BIGINT, d.record_version), @req_by = d.requested_by,
           @req_emp = d.requested_by_employee_id, @type = d.disposition_type, @revised = d.revised_due_date,
           @review = d.review_date, @ostatus = o.status
      FROM grac_practice.asset_activity_disposition d
      JOIN grac_practice.asset_activity_occurrence o ON o.occurrence_id = d.occurrence_id
     WHERE d.disposition_id = @disposition_id AND d.organization_id = @organization_id;
    IF @found = 0 THROW 54686, 'Disposition request not found for this organization.', 1;
    IF @decision NOT IN (N'APPROVE', N'REJECT', N'WITHDRAW')
        THROW 54681, 'The decision must be Approve, Reject or Withdraw.', 1;
    IF @status <> N'PENDING'
        THROW 54687, 'This request is no longer waiting for a decision.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 54680, 'The request was changed by someone else; reload it and try again.', 1;
    IF @decision = N'WITHDRAW' AND @req_by <> @actor
        THROW 54687, 'Only the person who made the request can withdraw it.', 1;
    IF @decision IN (N'APPROVE', N'REJECT')
       AND (@req_by = @actor OR (@req_emp IS NOT NULL AND @req_emp = @actor_employee_id))
        THROW 54679, 'Segregation of duties: the person who made the request cannot approve or reject it.', 1;
    IF @decision = N'REJECT' AND @decision_note IS NULL
        THROW 54677, 'Give the reason for rejecting the request.', 1;
    IF @decision = N'APPROVE' AND @ostatus <> N'OPEN'
        THROW 54671, 'The occurrence is no longer open; reject or withdraw the request.', 1;
    IF @decision = N'APPROVE' AND @type = N'RESCHEDULE' AND @revised < @today
        THROW 54683, 'The revised due date has passed; reject the request and raise a new one.', 1;
    IF @decision = N'APPROVE' AND @type <> N'RESCHEDULE' AND @review <= @today
        THROW 54684, 'The review date has passed; reject the request and raise a new one.', 1;

    DECLARE @new_status NVARCHAR(12) = CASE @decision WHEN N'APPROVE' THEN N'APPROVED' WHEN N'REJECT' THEN N'REJECTED'
                                                      ELSE N'WITHDRAWN' END;
    BEGIN TRAN;
    UPDATE grac_practice.asset_activity_disposition
       SET status = @new_status, decided_by = @actor, decided_by_employee_id = @actor_employee_id, decided_dt = SYSUTCDATETIME(),
           decision_note = @decision_note
     WHERE disposition_id = @disposition_id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-activity-disposition', @disposition_id, @decision, N'{"status":"PENDING"}',
            (SELECT @new_status AS status, @decision_note AS note FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), N'Active', @actor);
    IF @new_status = N'APPROVED'
        EXEC grac_practice.sp_asset_activity_disposition_apply @disposition_id = @disposition_id,
             @actor_employee_id = @actor_employee_id, @actor = @actor;
    COMMIT;
    SELECT @disposition_id AS DispositionId, @new_status AS Result;
END
GO
PRINT '439: disposition procedures created.';
GO

-- =====================================================================
-- 12. Restrictive-use review decisions (9.1.9; D78)
-- =====================================================================
-- Actions by trigger (BRD 9.1.9 / 7.1.2 / 7.1.3):
--   activity failed / overdue  CONTROLLED_USE, RESTRICTED_USE, REMOVED_FROM_SERVICE,
--                              EXCEPTION_APPROVED, NO_ACTION_REQUIRED
--   licence (renewal) expired  DISABLE, UNINSTALL, REPLACE, PURCHASE, RESTRICTED_USE,
--                              EXCEPTION_APPROVED
--   evidence expired           RESTRICTED_USE, REMOVED_FROM_SERVICE, EXCEPTION_APPROVED,
--                              NO_ACTION_REQUIRED
-- A decided review can be decided again while its cause lasts. The decision
-- does not change the asset lifecycle status (the Lifecycle tab does).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_restrictive_review_decide
    @organization_id         BIGINT,
    @review_id               BIGINT,
    @decision_code           NVARCHAR(30),
    @decision_note           NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @decision_code = UPPER(LTRIM(RTRIM(ISNULL(@decision_code, N''))));
    SET @decision_note = NULLIF(LTRIM(RTRIM(@decision_note)), N'');
    DECLARE @found BIT = 0, @status NVARCHAR(10), @rv BIGINT, @kind NVARCHAR(10), @trigger NVARCHAR(10), @before NVARCHAR(MAX);
    SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version), @kind = source_kind, @trigger = trigger_code,
           @before = (SELECT r2.status AS status, r2.decision_code AS decisionCode, r2.decision_note AS note
                        FROM grac_practice.asset_restrictive_review r2 WHERE r2.review_id = r.review_id
                         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
      FROM grac_practice.asset_restrictive_review r
     WHERE r.review_id = @review_id AND r.organization_id = @organization_id;
    IF @found = 0 THROW 54688, 'Restrictive-use review not found for this organization.', 1;
    IF @status = N'RESOLVED' THROW 54690, 'This review was resolved because its cause cleared.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 54680, 'The review was changed by someone else; reload it and try again.', 1;
    IF NOT ((@kind = N'ACTIVITY' AND @trigger IN (N'FAILED', N'OVERDUE')
             AND @decision_code IN (N'CONTROLLED_USE', N'RESTRICTED_USE', N'REMOVED_FROM_SERVICE', N'EXCEPTION_APPROVED', N'NO_ACTION_REQUIRED'))
         OR (@kind = N'ACTIVITY' AND @trigger = N'EXPIRED'
             AND @decision_code IN (N'DISABLE', N'UNINSTALL', N'REPLACE', N'PURCHASE', N'RESTRICTED_USE', N'EXCEPTION_APPROVED'))
         OR (@kind = N'EVIDENCE'
             AND @decision_code IN (N'RESTRICTED_USE', N'REMOVED_FROM_SERVICE', N'EXCEPTION_APPROVED', N'NO_ACTION_REQUIRED')))
        THROW 54689, 'That action is not available for this review.', 1;
    IF @decision_note IS NULL THROW 54677, 'Record the reason for the decision.', 1;

    BEGIN TRAN;
    UPDATE grac_practice.asset_restrictive_review
       SET status = N'DECIDED', decision_code = @decision_code, decision_note = @decision_note, decided_by = @actor,
           decided_by_employee_id = @actor_employee_id, decided_dt = SYSUTCDATETIME(), updated_by = @actor, updated_dt = SYSUTCDATETIME()
     WHERE review_id = @review_id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-restrictive-review', @review_id, N'DECIDE', @before,
            (SELECT N'DECIDED' AS status, @decision_code AS decisionCode, @decision_note AS note FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @review_id AS ReviewId, N'DECIDED' AS Result;
END
GO
PRINT '439: review decision created.';
GO

-- =====================================================================
-- 13. Readers
-- =====================================================================
-- One occurrence: 1. header  2. result (0 or 1 row)  3. dispositions
-- 4. restrictive-use reviews of the asset and activity.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_occurrence_get
    @organization_id BIGINT,
    @occurrence_id   BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_activity_occurrence
                    WHERE occurrence_id = @occurrence_id AND organization_id = @organization_id)
        THROW 54670, 'Activity occurrence not found for this organization.', 1;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    SELECT o.occurrence_id AS OccurrenceId, o.occurrence_key AS OccurrenceKey, o.asset_id AS AssetId, a.asset_name AS AssetName,
           o.template_code AS TemplateCode, t.template_name AS TemplateName, t.activity_kind AS ActivityKind,
           o.due_date AS DueDate, o.revised_due_date AS RevisedDueDate,
           DATEDIFF(DAY, @today, ISNULL(o.revised_due_date, o.due_date)) AS DaysToDue, o.review_date AS ReviewDate,
           o.is_retest AS IsRetest, o.decision AS Decision, o.decision_reason AS DecisionReason, o.status AS Status,
           c.contract_number AS ContractNumber, v.version_no AS ContractVersionNo, o.task_id AS TaskId, pt.task_number AS TaskNumber,
           ts.status_name AS TaskStatusName, ae.employee_name AS TaskOwnerName, o.task_error AS TaskError,
           o.needs_reconciliation AS NeedsReconciliation, o.reconciliation_reason AS ReconciliationReason,
           o.completed_dt AS CompletedDt, cb.employee_name AS CompletedByName,
           st.ResultRequired, st.ResultReviewRequired, st.DispositionApprovalRequired,
           t.certificate_number_field_key AS CertificateNumberFieldKey, t.certificate_expiry_field_key AS CertificateExpiryFieldKey,
           CONVERT(BIGINT, o.record_version) AS RecordVersion
      FROM grac_practice.asset_activity_occurrence o
      JOIN grac_practice.asset_activity_template t ON t.template_code = o.template_code
      JOIN grac_practice.fn_asset_activity_settings(@organization_id) st ON st.TemplateCode = o.template_code
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = o.asset_id
      LEFT JOIN grac_practice.asset_contract_version v ON v.version_id = o.contract_version_id
      LEFT JOIN grac_practice.asset_contract c ON c.contract_id = v.contract_id
      LEFT JOIN grac_practice.practice_task pt ON pt.task_id = o.task_id
      LEFT JOIN grac_practice.entity_status_master ts ON ts.entity_status_id = pt.current_status_id
      LEFT JOIN grac_practice.organization_employee ae ON ae.employee_id = pt.assigned_to_employee_id
      LEFT JOIN grac_practice.organization_employee cb ON cb.employee_id = o.completed_by_employee_id
     WHERE o.occurrence_id = @occurrence_id;

    SELECT r.result_id AS ResultId, r.state AS State, r.outcome AS Outcome, r.performed_date AS PerformedDate,
           r.certificate_number AS CertificateNumber, r.certificate_expiry AS CertificateExpiry, r.new_expiry AS NewExpiry,
           r.evidence_reference AS EvidenceReference, r.result_note AS ResultNote, r.submitted_by AS SubmittedBy,
           se.employee_name AS SubmittedByName, r.submitted_dt AS SubmittedDt, r.decided_by AS DecidedBy,
           de.employee_name AS DecidedByName, r.decided_dt AS DecidedDt, r.decision_note AS DecisionNote,
           CONVERT(BIGINT, r.record_version) AS RecordVersion
      FROM grac_practice.asset_activity_result r
      LEFT JOIN grac_practice.organization_employee se ON se.employee_id = r.submitted_by_employee_id
      LEFT JOIN grac_practice.organization_employee de ON de.employee_id = r.decided_by_employee_id
     WHERE r.occurrence_id = @occurrence_id;

    SELECT d.disposition_id AS DispositionId, d.disposition_type AS DispositionType, d.reason AS Reason,
           d.previous_due_date AS PreviousDueDate, d.revised_due_date AS RevisedDueDate, d.review_date AS ReviewDate,
           d.status AS Status, d.requested_by AS RequestedBy, re.employee_name AS RequestedByName, d.requested_dt AS RequestedDt,
           d.decided_by AS DecidedBy, de.employee_name AS DecidedByName, d.decided_dt AS DecidedDt, d.decision_note AS DecisionNote,
           d.task_note AS TaskNote, CONVERT(BIGINT, d.record_version) AS RecordVersion
      FROM grac_practice.asset_activity_disposition d
      LEFT JOIN grac_practice.organization_employee re ON re.employee_id = d.requested_by_employee_id
      LEFT JOIN grac_practice.organization_employee de ON de.employee_id = d.decided_by_employee_id
     WHERE d.occurrence_id = @occurrence_id
     ORDER BY d.disposition_id DESC;

    SELECT rr.review_id AS ReviewId, rr.trigger_code AS TriggerCode, rr.trigger_date AS TriggerDate, rr.title AS Title,
           rr.status AS Status, rr.decision_code AS DecisionCode, rr.decision_note AS DecisionNote, rr.decided_dt AS DecidedDt,
           rr.resolved_dt AS ResolvedDt
      FROM grac_practice.asset_activity_occurrence o
      JOIN grac_practice.asset_restrictive_review rr ON rr.asset_id = o.asset_id AND rr.source_kind = N'ACTIVITY'
                                                    AND rr.source_code = o.template_code
     WHERE o.occurrence_id = @occurrence_id
     ORDER BY rr.review_id DESC;
END
GO

-- Restrictive-use reviews (recalculated first). @status: NULL = active
-- (open and decided), OPEN, DECIDED, RESOLVED, ALL.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_restrictive_reviews
    @organization_id BIGINT,
    @status          NVARCHAR(10)  = NULL,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25,
    @actor           NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54692, 'Organization not found.', 1;
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    DECLARE @done INT, @raised INT, @resolved INT;
    EXEC grac_practice.sp_asset_activity_task_sync @organization_id = @organization_id, @actor = @actor, @completed = @done OUTPUT;
    EXEC grac_practice.sp_asset_activity_schedule_sync @organization_id = @organization_id;
    EXEC grac_practice.sp_asset_restrictive_review_sync @organization_id = @organization_id, @actor = @actor,
         @raised = @raised OUTPUT, @resolved = @resolved OUTPUT;

    SELECT r.review_id AS ReviewId, r.asset_id AS AssetId, a.asset_name AS AssetName, r.source_kind AS SourceKind,
           r.source_code AS SourceCode, COALESCE(t.template_name, ef.evidence_name, r.source_code) AS SourceName,
           t.activity_kind AS ActivityKind, r.trigger_code AS TriggerCode, r.trigger_date AS TriggerDate, r.title AS Title,
           r.severity_code AS SeverityCode, r.occurrence_id AS OccurrenceId, r.status AS Status, r.decision_code AS DecisionCode,
           r.decision_note AS DecisionNote, r.decided_by AS DecidedBy, de.employee_name AS DecidedByName, r.decided_dt AS DecidedDt,
           r.resolved_dt AS ResolvedDt, r.resolved_reason AS ResolvedReason, r.entered_dt AS RaisedDt,
           CONVERT(BIGINT, r.record_version) AS RecordVersion,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_restrictive_review r
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = r.asset_id
      LEFT JOIN grac_practice.asset_activity_template t ON r.source_kind = N'ACTIVITY' AND t.template_code = r.source_code
      LEFT JOIN grac_practice.asset_evidence_field ef ON r.source_kind = N'EVIDENCE' AND ef.field_key = r.source_code
      LEFT JOIN grac_practice.organization_employee de ON de.employee_id = r.decided_by_employee_id
     WHERE r.organization_id = @organization_id
       AND ((@status IS NULL AND r.status IN (N'OPEN', N'DECIDED')) OR @status = N'ALL' OR r.status = @status)
       AND (@search IS NULL OR a.asset_name LIKE N'%' + @search + N'%' OR r.title LIKE N'%' + @search + N'%')
     ORDER BY CASE r.status WHEN N'OPEN' THEN 0 WHEN N'DECIDED' THEN 1 ELSE 2 END,
              CASE r.severity_code WHEN N'CRITICAL' THEN 0 WHEN N'HIGH' THEN 1 WHEN N'MEDIUM' THEN 2 ELSE 3 END,
              r.trigger_date, r.review_id
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO
PRINT '439: readers created.';
GO
