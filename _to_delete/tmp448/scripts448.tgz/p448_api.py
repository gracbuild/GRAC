import sys
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w448/new'
A=R+'/src/PracticeManagement.Api/'
def edit(path, old, new, count=1):
    s=open(path).read(); assert s.count(old)==count, (path, old[:80], s.count(old)); open(path,'w').write(s.replace(old,new))
edit(A+'Models/AssetConfigModels.cs', """/// <summary>Re-evaluate one asset (AssetId) or the whole organization.</summary>
public sealed record AssetConsistencyRunRequest(long OrganizationId, long? AssetId);
""", """/// <summary>Re-evaluate one asset (AssetId) or the whole organization.</summary>
public sealed record AssetConsistencyRunRequest(long OrganizationId, long? AssetId);

// ---------------------------------------------------------------------
// Asset privacy (migration 448)
// ---------------------------------------------------------------------
/// <summary>Organization (AssetTypeId null) or asset-type setting of one privacy requirement. Enforcement OFF | WARN |
/// BLOCK; null removes the row (back to the organization / catalogue default).</summary>
public sealed record AssetPrivacySettingRequest(long OrganizationId, int? AssetTypeId, string? RequirementCode, string? Enforcement,
    bool? ExceptionAllowed, int? MaxExceptionDays);

/// <summary>Privacy exception for an open gap of one requirement: reason, compensating controls, owner, expiry.</summary>
public sealed record AssetPrivacyExceptionRequest(long OrganizationId, long AssetId, string? RequirementCode, string? Reason,
    string? CompensatingControls, long? OwnerEmployeeId, DateTime? ExpiryDate);

/// <summary>APPROVE | REJECT (note) | WITHDRAW | REVOKE (note).</summary>
public sealed record AssetPrivacyExceptionActionRequest(long OrganizationId, string? Action, string? Note, long? ExpectedRecordVersion);

/// <summary>Privacy review: REVIEWED with NextDate (next review). Retention review: DELETE / ARCHIVE (evidence),
/// LEGAL_HOLD (NextDate = next verification), EXTEND (note, NextDate = kept until; approver).</summary>
public sealed record AssetPrivacyReviewCompleteRequest(long OrganizationId, string? Outcome, string? Note, string? Evidence,
    DateTime? NextDate, long? ExpectedRecordVersion);

/// <summary>Refresh reviews and exception expiry for one asset or the organization.</summary>
public sealed record AssetPrivacyRunRequest(long OrganizationId, long? AssetId);
""")
S=A+'Services/AssetConfigService.cs'
edit(S, """    Task<AssetLifecycleResult> RunConsistencyAsync(AssetConsistencyRunRequest request, string actor, CancellationToken ct);
}
""", """    Task<AssetLifecycleResult> RunConsistencyAsync(AssetConsistencyRunRequest request, string actor, CancellationToken ct);

    // 448 -- Asset privacy
    Task<object> ListPrivacyAssetsAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<object?> GetPrivacyAssetAsync(long organizationId, long assetId, CancellationToken ct);
    Task<object> ListPrivacyExceptionsAsync(long organizationId, string? status, int pageNumber, int pageSize, CancellationToken ct);
    Task<object> ListPrivacyReviewsAsync(long organizationId, string? status, string? kind, int pageNumber, int pageSize, CancellationToken ct);
    Task<object> GetPrivacyRequirementsAsync(long organizationId, CancellationToken ct);
    Task<AssetLifecycleResult> SavePrivacySettingAsync(AssetPrivacySettingRequest request, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> RequestPrivacyExceptionAsync(AssetPrivacyExceptionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> PrivacyExceptionActionAsync(long exceptionId, AssetPrivacyExceptionActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> CompletePrivacyReviewAsync(long reviewId, AssetPrivacyReviewCompleteRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> RunPrivacyAsync(AssetPrivacyRunRequest request, string actor, CancellationToken ct);
}
""")
edit(S, """    public async Task<object> GetBusinessServiceTreeAsync(""", """    // ----------------------------------------------------------------
    // 448 -- Asset privacy
    // ----------------------------------------------------------------
    public async Task<object> ListPrivacyAssetsAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_privacy_assets");
        command.CommandTimeout = 120;   // evaluates every asset of the organization
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 20);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        var counts = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize, counts };
    }

    public async Task<object?> GetPrivacyAssetAsync(long organizationId, long assetId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_privacy_asset_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@asset_id",        DbType.Int64, assetId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var empty = new List<Dictionary<string, object?>>();
            var status     = await ReadRowsAsync(reader, ct);
            var gaps       = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var exceptions = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var reviews    = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            return new { status = status.Count > 0 ? status[0] : null, gaps, exceptions, reviews };
        }
        catch (SqlException ex) when (ex.Number == 53051) { return null; }
    }

    public async Task<object> ListPrivacyExceptionsAsync(long organizationId, string? status, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_privacy_exceptions");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 20);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object> ListPrivacyReviewsAsync(long organizationId, string? status, string? kind, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_privacy_reviews");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 10);
        AddParam(command, "@kind",            DbType.String, Blank(kind), 10);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object> GetPrivacyRequirementsAsync(long organizationId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_privacy_requirements");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var empty = new List<Dictionary<string, object?>>();
        var requirements = await ReadRowsAsync(reader, ct);
        var overrides    = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var assetTypes   = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var employees    = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        return new { requirements, overrides, assetTypes, employees };
    }

    public Task<AssetLifecycleResult> SavePrivacySettingAsync(AssetPrivacySettingRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_privacy_setting_save", "settingId", command =>
        {
            AddParam(command, "@organization_id",    DbType.Int64,   request.OrganizationId);
            AddParam(command, "@asset_type_id",      DbType.Int32,   request.AssetTypeId);
            AddParam(command, "@requirement_code",   DbType.String,  Blank(request.RequirementCode), 30);
            AddParam(command, "@enforcement",        DbType.String,  Blank(request.Enforcement), 10);
            AddParam(command, "@exception_allowed",  DbType.Boolean, request.ExceptionAllowed ?? true);
            AddParam(command, "@max_exception_days", DbType.Int32,   request.MaxExceptionDays);
            AddParam(command, "@actor",              DbType.String,  actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> RequestPrivacyExceptionAsync(AssetPrivacyExceptionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_privacy_exception_request", "exceptionId", command =>
        {
            AddParam(command, "@organization_id",       DbType.Int64,  request.OrganizationId);
            AddParam(command, "@asset_id",              DbType.Int64,  request.AssetId);
            AddParam(command, "@requirement_code",      DbType.String, Blank(request.RequirementCode), 30);
            AddParam(command, "@reason",                DbType.String, Blank(request.Reason), 1000);
            AddParam(command, "@compensating_controls", DbType.String, Blank(request.CompensatingControls), 1000);
            AddParam(command, "@owner_employee_id",     DbType.Int64,  request.OwnerEmployeeId);
            AddParam(command, "@expiry_date",           DbType.Date,   request.ExpiryDate?.Date);
            AddParam(command, "@actor_employee_id",     DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                 DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> PrivacyExceptionActionAsync(long exceptionId, AssetPrivacyExceptionActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_privacy_exception_action", "exceptionId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@exception_id",            DbType.Int64,  exceptionId);
            AddParam(command, "@action",                  DbType.String, Blank(request.Action), 12);
            AddParam(command, "@note",                    DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> CompletePrivacyReviewAsync(long reviewId, AssetPrivacyReviewCompleteRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_privacy_review_complete", "reviewId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@review_id",               DbType.Int64,  reviewId);
            AddParam(command, "@outcome",                 DbType.String, Blank(request.Outcome), 12);
            AddParam(command, "@note",                    DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@evidence",                DbType.String, Blank(request.Evidence), 1000);
            AddParam(command, "@next_date",               DbType.Date,   request.NextDate?.Date);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> RunPrivacyAsync(AssetPrivacyRunRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_privacy_run", "organizationId", command =>
        {
            command.CommandTimeout = 300;
            AddParam(command, "@organization_id", DbType.Int64,  request.OrganizationId);
            AddParam(command, "@asset_id",        DbType.Int64,  request.AssetId);
            AddParam(command, "@actor",           DbType.String, actor, 100);
        }, ct);

    public async Task<object> GetBusinessServiceTreeAsync(""")
C=A+'Controllers/AssetConfigController.cs'
edit(C, """//   POST register/consistency/run                    re-evaluate one asset or the organization
//
""", """//   POST register/consistency/run                    re-evaluate one asset or the organization
//   GET  register/{id}/privacy?organizationId=       privacy status, gaps, exceptions, reviews of an asset (448)
//   GET  privacy/assets?organizationId=&status=&search=&pageNumber=&pageSize=   privacy register + counts
//   GET  privacy/assets/{id}?organizationId=         as register/{id}/privacy
//   GET  privacy/exceptions?organizationId=&status=&pageNumber=&pageSize=
//   GET  privacy/reviews?organizationId=&status=&kind=&pageNumber=&pageSize=
//   GET  privacy/requirements?organizationId=        requirements with settings, overrides, asset types, employees
//   POST privacy/requirements                        organization / asset-type setting of one requirement
//   POST privacy/exceptions                          request an exception for an open gap
//   POST privacy/exceptions/{id}/action              APPROVE | REJECT | WITHDRAW | REVOKE
//   POST privacy/reviews/{id}/complete               REVIEWED | DELETE | ARCHIVE | LEGAL_HOLD | EXTEND
//   POST privacy/run                                 refresh reviews and exception expiry
//
""")
edit(C, """    // 447: 53010 (organization), 53011 (rule), 53030 (finding) -> 404;""", """    // ---------------------------------------------------------------- 448: asset privacy
    [HttpGet("register/{assetId:long}/privacy")]
    public Task<IActionResult> AssetPrivacy(long assetId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetPrivacyAssetAsync(o, assetId, ct), "Asset not found.", "asset privacy");

    [HttpGet("privacy/assets")]
    public Task<IActionResult> PrivacyAssets([FromQuery] long? organizationId, [FromQuery] string? status, [FromQuery] string? search,
        [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListPrivacyAssetsAsync(organizationId.Value, status, search, pageNumber ?? 1, pageSize ?? 25, ct), "privacy assets");
    }

    [HttpGet("privacy/assets/{assetId:long}")]
    public Task<IActionResult> PrivacyAsset(long assetId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetPrivacyAssetAsync(o, assetId, ct), "Asset not found.", "privacy asset");

    [HttpGet("privacy/exceptions")]
    public Task<IActionResult> PrivacyExceptions([FromQuery] long? organizationId, [FromQuery] string? status,
        [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListPrivacyExceptionsAsync(organizationId.Value, status, pageNumber ?? 1, pageSize ?? 25, ct), "privacy exceptions");
    }

    [HttpGet("privacy/reviews")]
    public Task<IActionResult> PrivacyReviews([FromQuery] long? organizationId, [FromQuery] string? status, [FromQuery] string? kind,
        [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListPrivacyReviewsAsync(organizationId.Value, status, kind, pageNumber ?? 1, pageSize ?? 25, ct), "privacy reviews");
    }

    [HttpGet("privacy/requirements")]
    public Task<IActionResult> PrivacyRequirements([FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.GetPrivacyRequirementsAsync(organizationId.Value, ct), "privacy requirements");
    }

    [HttpPost("privacy/requirements")]
    public async Task<IActionResult> SavePrivacySetting([FromBody] AssetPrivacySettingRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SavePrivacySettingAsync(request, Actor, ct), PrivacyNotFound, PrivacyConflict);
    }

    [HttpPost("privacy/exceptions")]
    public async Task<IActionResult> RequestPrivacyException([FromBody] AssetPrivacyExceptionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (request.AssetId <= 0) return BadRequest(new { error = "assetId is required." });
        return ResultWritten(await service.RequestPrivacyExceptionAsync(request, ActorEmployeeId, Actor, ct), PrivacyNotFound, PrivacyConflict);
    }

    [HttpPost("privacy/exceptions/{exceptionId:long}/action")]
    public async Task<IActionResult> PrivacyExceptionAction(long exceptionId, [FromBody] AssetPrivacyExceptionActionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Action)) return BadRequest(new { error = "action is required." });
        return ResultWritten(await service.PrivacyExceptionActionAsync(exceptionId, request, ActorEmployeeId, Actor, ct), PrivacyNotFound, PrivacyConflict);
    }

    [HttpPost("privacy/reviews/{reviewId:long}/complete")]
    public async Task<IActionResult> CompletePrivacyReview(long reviewId, [FromBody] AssetPrivacyReviewCompleteRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Outcome)) return BadRequest(new { error = "outcome is required." });
        return ResultWritten(await service.CompletePrivacyReviewAsync(reviewId, request, ActorEmployeeId, Actor, ct), PrivacyNotFound, PrivacyConflict);
    }

    [HttpPost("privacy/run")]
    public async Task<IActionResult> RunPrivacy([FromBody] AssetPrivacyRunRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.RunPrivacyAsync(request, Actor, ct), PrivacyNotFound, PrivacyConflict);
    }

    // 448: 53050 (organization), 53051 (asset), 53052 (requirement), 53054 (asset type), 53056 (exception), 53064 (review)
    //      -> 404; 53060 (live exception exists), 53063 / 53069 (changed by someone else) -> 409; others -> 400.
    private static readonly int[] PrivacyNotFound = { 53050, 53051, 53052, 53054, 53056, 53064 };
    private static readonly int[] PrivacyConflict = { 53060, 53063, 53069 };

    // 447: 53010 (organization), 53011 (rule), 53030 (finding) -> 404;""")
print('api patched')
