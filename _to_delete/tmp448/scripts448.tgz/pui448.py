#!/usr/bin/env python3
# 448 UI patch: installs the Asset Privacy screen and adds the read-only
# Privacy tab to the Asset Register. Run from /home/claude/w448 on new/.
import shutil, sys

W = "new/src/PracticeManagement.Web/"
shutil.copyfile("asset-privacy.cshtml", W + "Views/Practice/Partials/asset-privacy.cshtml")
shutil.copyfile("asset-privacy.js", W + "wwwroot/js/AssetConfig/asset-privacy.js")

def patch(path, pairs):
    p = W + path
    s = open(p, encoding="utf-8").read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{path}: expected 1 match, got {n}: {old[:70]!r}")
        s = s.replace(old, new)
    open(p, "w", encoding="utf-8", newline="").write(s)

# ------------------------------------------------------------------ cshtml
patch("Views/Practice/Partials/asset-register.cshtml", [
("""    "Consistency findings" in the list toolbar is the organization worklist.
""",
"""    "Consistency findings" in the list toolbar is the organization worklist.

    448 (BRD 5.1.10 / 5.1.15 / 5.1.16 / 5.1.17 / 5.2.15 / 5.2.16): the
    Privacy tab shows the asset's privacy status, open privacy requirement
    gaps, exceptions and privacy / retention reviews (read-only). Exceptions
    and reviews are acted on in Asset Privacy ("Open in Asset Privacy").
"""),
("""                <button role="tab" data-arg-tab="valuation" aria-selected="false" id="argValTab" hidden>Valuation</button>
""",
"""                <button role="tab" data-arg-tab="valuation" aria-selected="false" id="argValTab" hidden>Valuation</button>
                <button role="tab" data-arg-tab="privacy" aria-selected="false" id="argPrivTab" hidden>Privacy</button>
"""),
("""            <div class="pm-tab-panel" data-arg-panel="valuation" hidden id="argValPanel">
""",
"""            <div class="pm-tab-panel" data-arg-panel="privacy" hidden id="argPrivPanel">
                <div class="arg-tech-head">
                    <p class="arg-note" id="argPrivState"></p>
                    <div class="arg-pending-actions">
                        <button class="pm-button" type="button" id="argPrivOpen"><i class="fa-solid fa-user-shield"></i> Open in Asset Privacy</button>
                    </div>
                </div>
                <div class="arg-section">
                    <h3>Requirement gaps</h3>
                    <div class="pm-table-wrap">
                        <table>
                            <thead><tr><th>Requirement</th><th>Gap</th><th>Enforcement</th><th>Exception</th></tr></thead>
                            <tbody id="argPrivGaps"></tbody>
                        </table>
                    </div>
                </div>
                <div class="arg-section">
                    <h3>Exceptions</h3>
                    <div class="pm-table-wrap">
                        <table>
                            <thead><tr><th>Requirement</th><th>Status</th><th>Reason / controls</th><th>Owner</th><th>Expiry</th></tr></thead>
                            <tbody id="argPrivExceptions"></tbody>
                        </table>
                    </div>
                </div>
                <div class="arg-section">
                    <h3>Reviews</h3>
                    <div class="pm-table-wrap">
                        <table>
                            <thead><tr><th>Review</th><th>Due</th><th>Status</th><th>Outcome</th></tr></thead>
                            <tbody id="argPrivReviews"></tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="pm-tab-panel" data-arg-panel="valuation" hidden id="argValPanel">
"""),
])

# ------------------------------------------------------------------ js
JS = "wwwroot/js/AssetConfig/asset-register.js"
patch(JS, [
("""// register/consistency/run; register/consistency/findings is the worklist.
""",
"""// register/consistency/run; register/consistency/findings is the worklist.
// 448: Privacy tab -- register/{id}/privacy (status, gaps, exceptions,
// reviews), read-only; "Open in Asset Privacy" goes to the asset-privacy
// screen with ?organizationId=&assetId=, where they are acted on.
"""),
("""    consFinding: null, consFrom: null, consList: []   // 447
""",
"""    consFinding: null, consFrom: null, consList: [],  // 447
    privacy: null     // 448: { status, gaps, exceptions, reviews }
"""),
("""    document.getElementById("argValOverride")?.addEventListener("click", openValOverride);
""",
"""    document.getElementById("argValOverride")?.addEventListener("click", openValOverride);
    document.getElementById("argPrivOpen").addEventListener("click", openPrivacyScreen);   // 448
"""),
("""    state.valuation = null;
    state.custody = null;
""",
"""    state.valuation = null;
    document.getElementById("argPrivTab").hidden = true;       // 448
    state.privacy = null;
    state.custody = null;
"""),
("""    await loadValuation();  // 446
    await loadWorkflows();
""",
"""    await loadValuation();  // 446
    await loadPrivacy();    // 448
    await loadWorkflows();
"""),
("""  // ------------------------------------------------------------------ consistency findings (447)
""",
"""  // ------------------------------------------------------------------ privacy (448)
  const PRIV_STATUS = { NON_COMPLIANT: ["Non-compliant", "arg-ph-exception"], INCOMPLETE: ["Incomplete", "arg-tc-warn"], UNDETERMINED: ["Undetermined", "arg-tc-warn"],
                        CONDITIONAL: ["Conditional", "arg-tc-warn"], COMPLIANT: ["Compliant", "arg-ph-operation"], NOT_APPLICABLE: ["Not applicable", "arg-ph-retirement"] };
  const PRIV_GAP = { FAILED: "Failed", MISSING: "Missing", PARTIAL: "Partial" };
  const PRIV_ENF = { OFF: "Off", WARN: "Warn", BLOCK: "Block" };
  const PRIV_EXC = { PENDING_APPROVAL: "Awaiting approval", APPROVED: "Approved", REJECTED: "Rejected", WITHDRAWN: "Withdrawn", REVOKED: "Revoked", EXPIRED: "Expired" };
  const PRIV_REV = { OPEN: "Open", COMPLETED: "Completed", CANCELLED: "Cancelled" };
  const PRIV_KIND = { PRIVACY: "Privacy / DPIA review", RETENTION: "Retention end" };
  const PRIV_OUTCOME = { REVIEWED: "Reviewed", DELETE: "Data deleted", ARCHIVE: "Data archived", LEGAL_HOLD: "Legal hold verified", EXTEND: "Retention extended" };

  async function loadPrivacy() {
    if (!state.asset) return;
    const res = await api("GET", `/${state.asset.assetId}/privacy?organizationId=${state.organizationId}`);
    if (!res.ok) return;
    state.privacy = res.data.data || {};
    document.getElementById("argPrivTab").hidden = false;
    renderPrivacy();
  }

  function renderPrivacy() {
    const d = state.privacy || {}, s = d.status || {};
    const st = PRIV_STATUS[s.privacyStatus] || [s.privacyStatus || "--", "arg-ph-retirement"];
    document.getElementById("argPrivState").innerHTML = `Privacy status: <span class="arg-chip ${st[1]}">${esc(st[0])}</span>`
      + ` <span class="arg-note">Privacy owner ${esc(s.privacyOwnerName || "--")}; privacy review ${esc(date(s.privacyReviewDate) || "--")}`
      + `; retention end ${esc(date(s.retentionDueDate) || "--")}${String(s.legalHold || "").toUpperCase() === "YES" ? "; legal hold" : ""}</span>`;
    document.getElementById("argPrivGaps").innerHTML = (d.gaps || []).map(g => `
      <tr><td>${esc(g.requirementName)}</td><td>${esc(PRIV_GAP[g.gapKind] || g.gapKind)}: ${esc(g.message)}</td>
          <td>${esc(PRIV_ENF[g.enforcement] || g.enforcement)}${g.enforcement === "BLOCK" ? `<div class="arg-note">blocks ${g.blockTarget === "ACTIVE" ? "a move to Active" : "Disposed / Archived"}</div>` : ""}</td>
          <td>${Number(g.isExcepted) ? `Excepted until ${esc(date(g.exceptionExpiry))}` : "--"}</td></tr>`).join("")
      || empty(4, s.privacyStatus === "NOT_APPLICABLE" ? "Personal data is not processed." : "No gap.");
    document.getElementById("argPrivExceptions").innerHTML = (d.exceptions || []).map(x => `
      <tr><td>${esc(x.requirementName)}</td><td>${esc(PRIV_EXC[x.status] || x.status)}${x.decidedBy ? `<div class="arg-note">${esc(x.decidedBy)} ${esc(dateTime(x.decidedDt))}</div>` : ""}</td>
          <td>${esc(x.reason)}<div class="arg-note">${esc(x.compensatingControls)}</div></td>
          <td>${esc(x.ownerName || "--")}</td><td>${esc(date(x.expiryDate))}</td></tr>`).join("")
      || empty(5, "No exception.");
    document.getElementById("argPrivReviews").innerHTML = (d.reviews || []).map(r => `
      <tr><td>${esc(PRIV_KIND[r.reviewKind] || r.reviewKind)}</td><td>${esc(date(r.dueDate))}</td><td>${esc(PRIV_REV[r.status] || r.status)}</td>
          <td>${esc(PRIV_OUTCOME[r.outcome] || "--")}${r.extendedUntil ? `<div class="arg-note">until ${esc(date(r.extendedUntil))}</div>` : ""}${r.note ? `<div class="arg-note">${esc(r.note)}</div>` : ""}</td></tr>`).join("")
      || empty(4, "No review.");
  }

  function openPrivacyScreen() {
    if (!state.asset) return;
    const qs = new URLSearchParams({ organizationId: state.organizationId, assetId: state.asset.assetId });
    window.location.href = U(`/Practice/Index/asset-privacy?${qs}`);
  }

  // ------------------------------------------------------------------ consistency findings (447)
"""),
])
print("pui448 ok")
