import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (a[:60], s.count(a))
    s = s.replace(a, b)

rep("batch ingestion with per-record results, the reconciliation queue and data confidence (`442`).",
    "batch ingestion with per-record results, the reconciliation queue and data confidence (`442`), Phase 7.4a discovery follow-up -- candidate registration as a Draft asset and the stale-asset review leading to a decommission request (`443`).")
rep("| 7.4 | Discovery follow-up (5.6.3): asset merge and split with history, stale-asset retirement after source confirmation, creating a register asset from a new candidate | | 7.3 |",
    "| 7.4a **(done)** | Discovery follow-up (5.6.3): New candidate -> Register on the Asset Register form (prefilled from the observation, saved as Draft, then linked -- REGISTER action); aging rule; stale-asset list and review (source confirmation, dependency review with snapshot, dismiss or request decommission through the lifecycle move to Pending Decommission) | 443 | 7.3 |\n"
    "| 7.4b | Asset merge (5.6.3, 19.4): survivor and duplicates, preview (fields, sources, history, relationships, attachments, tasks), impact analysis (services, contracts, risks, attestations, tasks), validation, approval with two-person control for critical CIs, execution with per-object outcomes, aliases, recovery event | | 7.4a |\n"
    "| 7.4c | Asset split (5.6.3, 19.4): resulting records, allocation of observations / relationships / evidence / history, approval, controlled recombine | | 7.4b |")
rep("""| D33 | **Cancel keeps the asset status** (433)""",
"""| D109 | **Candidate registration** (443): Asset Discovery -> Register (New candidate or Manual review) opens Asset Register -> New asset with the observed values prefilled (list values matched by value or label; multi-select values not prefilled; dates cut to yyyy-mm-dd). The form's own validation applies and the asset is saved as **Draft**, so activation keeps every lifecycle gate ("do not activate until validation rules pass"). After the save the record is linked with the new REGISTER action (exception New candidate / Manual review; the asset must be Draft and have no source link yet), which works as Link (confirmed link, field precedence -- an edited value becomes a conflict) and closes the exception as Registered. Needs asset-register ADD and asset-discovery EDIT. | BRD 5.6.3 Create Candidate. | Yes. |
| D110 | **Aging rule**: per organization, default 90 days (1-3650). An asset is stale when it has source links, none is fresh (expected interval x stale multiplier, 442) and no source has observed it for the aging period; assets already Pending Decommission or later are not listed, and assets no source ever linked are never stale. | BRD 5.6.3 "aging rule". | Yes -- 90 days is a starting value. |
| D111 | **Stale review**: opened by a user on a stale asset (one open review per asset; the stale list is the work queue -- no automatic review or task). Step 1 source confirmation by the source owner: Absent (continue) or Still present (review closed as dismissed -- a connector / scope matter). Step 2 dependency review with a note; the dependency list is kept as a snapshot with its blocker count. Then Dismiss (still in use; not listed again for one aging period) or Request decommission. | BRD 5.6.3 "source confirmation and dependency review before retirement". | Yes. |
| D112 | **Dependency review items**: relationships where other items rely on the asset (critical ones not accepted for retirement are blockers), active contract coverage, open activity occurrences, open workflow cases, a lifecycle change awaiting approval (blocker -- the move would be refused), open reconciliation exceptions and mapped risks. Blockers do not stop the request to Pending Decommission; the 440 gate still refuses sanitization / disposal while critical dependants remain. | BRD 5.6.3, 19.3 impact analysis. | Yes. |
| D113 | **Request decommission** runs the Asset Register lifecycle move to Pending Decommission (sp_asset_lifecycle_transition: reason = the decision note, reference "Stale review SR-n", evidence = last observation, source confirmation and dependency review); its gates and approval apply (the 429 matrix has Active -> Pending Decommission with a reason, no approval). Needs source Absent, the dependency review and no observation by any source since the review opened; the proxy also requires asset-register EDIT. | BRD 5.6.3, 19.5 "confidence alone shall not authorize retirement". | Yes. |
| D114 | **Merge / split inventory** (for 7.4b / 7.4c): asset references found -- field values, lifecycle changes, firmware / OS installations and technology exceptions, assignment history, attestations and attestation state, verification exceptions, workflow cases, contract coverage and renewal items, notification occurrences / outbox, activity schedules / occurrences / restrictive reviews, relationships (CI kind ASSET), discovery links / attribute sources / observations / exceptions / duplicate decisions, risk asset maps and `risk_register.linked_asset_id`, risk dependency maps, practice-instance dependency resolutions and event scope (generic dependency type Asset), stale reviews, Task Centre subjects and audit traces. Unique keys (current installation, current assignment, attestation state, open workflow case, open occurrence per template, schedule per template, coverage per version and type) decide what can move. | BRD 19.4 "preview ... impact analysis". | Yes -- scope of 7.4b. |
| D33 | **Cancel keeps the asset status** (433)""")
rep("""### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""",
"""### Discovery follow-up (443)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `discovery/exceptions/{id}/candidate?organizationId=` | `{exception, attributes}` -- observed values naming a dictionary field, for the register form | `sp_asset_discovery_candidate_get` |
| POST | `discovery/exceptions/{id}/resolve` | adds `action: REGISTER` with `assetId` (the Draft asset just registered) -> REGISTERED | `sp_asset_reconciliation_resolve` (re-issued) |
| GET | `discovery/stale?organizationId=&view=&search=&pageNumber=&pageSize=` | `{settings (retireAfterDays, staleMultiplier), rows}`; view empty = stale assets and open reviews, CLOSED = closed reviews | `sp_asset_stale_reviews` (`fn_asset_stale_state`) |
| GET | `discovery/stale/assets/{assetId}?organizationId=` | `{asset (stale state + open review), links, dependencies, reviews}` | `sp_asset_stale_review_get` (`fn_asset_stale_dependencies`) |
| POST | `discovery/stale/settings` | `{organizationId, retireAfterDays}` | `sp_asset_stale_setting_save` |
| POST | `discovery/stale/reviews` | `{organizationId, assetId}` -> OPENED | `sp_asset_stale_review_open` |
| POST | `discovery/stale/reviews/{id}/action` | `{organizationId, action: CONFIRM_SOURCE \\| REVIEW_DEPENDENCIES \\| DISMISS \\| REQUEST_DECOMMISSION, sourceOutcome?: ABSENT \\| PRESENT, note, expectedRecordVersion?}` | `sp_asset_stale_review_action` (-> `sp_asset_lifecycle_transition`) |

Proxy: GETs asset-discovery VIEW; stale settings, reviews and actions EDIT; REQUEST_DECOMMISSION also asset-register EDIT. Errors `54780-54793`; 54780 / 54781 / 54784 -> 404, 54785 -> 409; lifecycle refusals of the decommission request keep their own numbers (5497x, 54719).

### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""")
rep("""## 8. Verification (static -- no compiler or database on this machine)""",
"""### Phase 7.4a files (443)
| Layer | File | Change |
|---|---|---|
| DB | `database/443_asset_discovery_followup.sql` (+ rollback restoring the 442 body) | `asset_stale_setting`, `asset_stale_review`; `fn_asset_stale_state`, `fn_asset_stale_dependencies`; aging rule, review open / action, readers; candidate reader. Re-issued: `sp_asset_reconciliation_resolve` (REGISTER). No menu change. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 6 routes; stale setting / open / action requests; the action reads the last result set. |
| Web | `Controllers/AssetConfigController.cs` | Stale permissions (decommission request also needs asset-register EDIT). |
| Web | `Partials/asset-discovery.cshtml`, `js/AssetConfig/asset-discovery.js` | Stale assets tab and review window; Register action in the queue; Registered resolution. |
| Web | `js/AssetConfig/asset-register.js` | `?discoveryException=` opens New asset prefilled from the observation and links the record after the save. |

## 8. Verification (static -- no compiler or database on this machine)""")
s = s.rstrip('\n') + """

443 got the same sweep (clean), the semicolon-before-ELSE scan (one IF / ELSE pair of reader branches wrapped in BEGIN / END before delivery), the aggregate rule (freshness computed per link in a CROSS APPLY), OPENJSON keys compared with `COLLATE DATABASE_DEFAULT` (the 442 lesson), the parameter check of the internal `sp_asset_lifecycle_transition` call against its 440 signature, a diff of the re-issued `sp_asset_reconciliation_resolve` against its 442 source (only lines marked `-- 443`), the C#-to-procedure parameter and string-size cross-check for the 6 bound procedures, the JS-to-alias and HTML-id / duplicate-id checks, `node --check` of both scripts, brace / parenthesis / bracket balance of the four edited C# files and the ASCII check. Its verification block checks the tables, the functions and six procedures, the re-issue and that the functions run. Not compiled or executed. Not yet done: merge (7.4b) and split (7.4c); Phase 8.
"""
open(p, 'w', encoding='utf-8', newline='').write(s)
print('doc ok')
