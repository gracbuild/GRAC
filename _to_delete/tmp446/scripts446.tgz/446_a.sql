-- =====================================================================
-- 446  Asset Value per asset -- automatic CIA valuation, validation
--      status, history, asset-level method override, controlled
--      recalculation with impact analysis
--      (Asset & Contract Management, Phase 8 increment 1)
--
-- REQUEST
-- -------
--   BRD v1.7 5.1.18 (Asset Value and CIA Valuation Framework),
--   5.1.18.3 (risk integration -- the stored value is what the risk
--   module reads), 5.1.18.4 (acceptance), 5.1.18.5.3 (method override),
--   5.1.18.5.6 (asset-type defaults), 5.1.18.5.7 (automatic calculation
--   and recalculation), 5.1.18.5.8 (version used, audit, impact
--   analysis, historical calculations unchanged), 5.1.18.5.9 ("CIA
--   changes automatically recalculate"; "existing assets are not
--   silently changed"). Plan: docs/asset-contract-management.md
--   (Phase 8.1, D132-D141).
--
-- WHAT THIS DOES
-- --------------
--   1. asset_valuation_result: the current Asset Value of each asset --
--      the CIA ratings and method used, score, category, band, the
--      valuation configuration (and so the CIA scale, method, band and
--      criticality version) used, a validation status (NOT_RATED,
--      INCOMPLETE, INVALID, VALID) and message, source and actor.
--      asset_valuation_history: every calculation, previous and new
--      values, source, reason, run, actor, time (append-only).
--      asset_valuation_recalc_run: controlled recalculation runs.
--   2. fn_asset_value_calc_method: the 422 calculation with an explicit
--      method (asset-level override); fn_asset_value_calc (422) now calls
--      it, so there is one formula.
--   3. fn_asset_valuation_eval: the Asset Value of each asset under the
--      Active configuration now; fn_asset_valuation_state: that compared
--      with the stored result -- current, values changed (CIA / method
--      changed by the form, a merge, a split, discovery), configuration
--      changed (a new version was activated), or never calculated.
--   4. sp_asset_valuation_apply: stores a calculation. AUTO mode (asset
--      form save, scheduler) applies only when the ratings or method
--      changed or nothing was stored; CONTROLLED mode (single-asset
--      recalculation, recalculation run) applies any difference.
--   5. sp_asset_register_save (435) re-issued: recalculates after a save,
--      warns when the result is incomplete / invalid / waiting for a
--      recalculation run, refuses a changed Asset Valuation Method that
--      differs from the configured method (overrides go through
--      sp_asset_valuation_method_set: enabled in the configuration, an
--      approver, a reason), and no longer takes a template default for the
--      method (the configuration supplies it).
--   6. sp_asset_scheduler_run (438) re-issued: per organization,
--      sp_asset_valuation_sync applies AUTO recalculations for ratings
--      changed outside the form.
--   7. fn_asset_stored_values (439) re-issued: Asset Value Score and
--      Asset Value Category show the stored VALID result (read-only).
--   8. Readers: sp_asset_valuation_get (one asset: current, state,
--      history), sp_asset_valuation_recalc_preview (impact analysis:
--      affected assets, category moves, linked risks, runs);
--      writers: sp_asset_valuation_recalculate (one asset),
--      sp_asset_valuation_recalc_run (all affected assets, reason,
--      expected count from the preview).
--
-- NOT DONE HERE: CIA / criticality consistency rules and the risk-score
--   refresh (8.2); defaults inherited from category / subcategory
--   (templates already carry per-asset-type defaults); per-scope
--   configurations (one per organization, as 422).
--
-- ERROR NUMBERS: 53000-53009
--   53000 asset not found                53001 no Active configuration
--   53002 invalid valuation method       53003 method override not enabled
--   53004 reason required                53005 affected assets changed
--                                              since the preview
--   53006 another recalculation running  53007 organization not found
--
-- ALSO EDITED: API (AssetConfig service / controller / models), Web
--   proxy, asset-register.cshtml / .js (Valuation section),
--   asset-valuation-config.cshtml / .js (Recalculation tab), docs.
-- DEPENDS ON: 422, 428, 435, 438, 439 (and 265 for the risk links).
-- Rollback: 446_asset_valuation_rollback.sql (restores the 422, 435,
--   438 and 439 bodies, drops the 446 objects).
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.asset_valuation_config','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_cia_scale_level','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_value_band','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_field_value','U') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_value_calc') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_coverage_summary') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_coverage_gaps') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_assignment_snapshot','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_tech_install_apply','P') IS NULL
   OR OBJECT_ID('grac_practice.asset_activity_schedule','U') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_activity_run','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_notification_sweep','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_contract_renewal_start','P') IS NULL
   OR OBJECT_ID('grac_practice.asset_scheduler_run','U') IS NULL
   OR COL_LENGTH('grac_practice.asset_scheduler_run','tasks_created') IS NULL
   OR COL_LENGTH('grac_practice.organization_dependency_asset','template_id') IS NULL
   OR COL_LENGTH('grac_practice.organization_dependency_asset','merged_into_asset_id') IS NULL
   OR OBJECT_ID('grac_practice.risk_dependency_map','U') IS NULL
   OR COL_LENGTH('grac_practice.dependency_type_master','dependency_type_code') IS NULL
   OR NOT EXISTS (SELECT 1 FROM grac_practice.asset_field_definition WHERE field_key = N'asset_value_score')
BEGIN
    RAISERROR('ABORT (446): run 265, 422, 428, 435, 438, 439 and 444 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Tables
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_valuation_recalc_run','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_valuation_recalc_run (
        run_id            BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_asset_val_run PRIMARY KEY,
        organization_id   BIGINT         NOT NULL
            CONSTRAINT fk_pm_asset_val_run_org REFERENCES grac_practice.organization(organization_id),
        config_id         BIGINT         NULL
            CONSTRAINT fk_pm_asset_val_run_cfg REFERENCES grac_practice.asset_valuation_config(config_id),
        reason_text       NVARCHAR(1000) NOT NULL,
        status            NVARCHAR(30)   NOT NULL CONSTRAINT df_pm_asset_val_run_status DEFAULT N'RUNNING'
            CONSTRAINT ck_pm_asset_val_run_status CHECK (status IN (N'RUNNING', N'COMPLETED', N'COMPLETED_WITH_ERRORS', N'FAILED')),
        affected_count    INT            NOT NULL CONSTRAINT df_pm_asset_val_run_aff DEFAULT 0,
        updated_count     INT            NOT NULL CONSTRAINT df_pm_asset_val_run_upd DEFAULT 0,
        error_count       INT            NOT NULL CONSTRAINT df_pm_asset_val_run_err DEFAULT 0,
        error_text        NVARCHAR(4000) NULL,
        actor_employee_id BIGINT         NULL,
        started_dt        DATETIME2      NOT NULL CONSTRAINT df_pm_asset_val_run_sdt DEFAULT SYSUTCDATETIME(),
        finished_dt       DATETIME2      NULL,
        entered_by        NVARCHAR(100)  NOT NULL
    );
    CREATE INDEX ix_pm_asset_val_run_org ON grac_practice.asset_valuation_recalc_run(organization_id, run_id DESC);
    PRINT '446: asset_valuation_recalc_run created.';
END
GO

IF OBJECT_ID('grac_practice.asset_valuation_history','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_valuation_history (
        history_id          BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_asset_val_hist PRIMARY KEY,
        organization_id     BIGINT         NOT NULL,
        asset_id            BIGINT         NOT NULL
            CONSTRAINT fk_pm_asset_val_hist_asset REFERENCES grac_practice.organization_dependency_asset(asset_id),
        source              NVARCHAR(30)   NOT NULL
            CONSTRAINT ck_pm_asset_val_hist_source CHECK (source IN (N'FORM', N'SCHEDULER', N'MANUAL', N'RECALC_RUN', N'METHOD_OVERRIDE')),
        run_id              BIGINT         NULL
            CONSTRAINT fk_pm_asset_val_hist_run REFERENCES grac_practice.asset_valuation_recalc_run(run_id),
        reason_text         NVARCHAR(1000) NULL,
        prev_config_id      BIGINT         NULL,
        prev_config_version INT            NULL,
        prev_confidentiality NVARCHAR(40)  NULL,
        prev_integrity      NVARCHAR(40)   NULL,
        prev_availability   NVARCHAR(40)   NULL,
        prev_method_used    NVARCHAR(30)   NULL,
        prev_score          DECIMAL(18, 4) NULL,
        prev_category       NVARCHAR(100)  NULL,
        prev_status         NVARCHAR(20)   NULL,
        new_config_id       BIGINT         NULL,
        new_config_version  INT            NULL,
        confidentiality     NVARCHAR(40)   NULL,
        integrity           NVARCHAR(40)   NULL,
        availability        NVARCHAR(40)   NULL,
        method_override     NVARCHAR(30)   NULL,
        method_used         NVARCHAR(30)   NULL,
        method_source       NVARCHAR(10)   NULL,
        raw_score           DECIMAL(18, 6) NULL,
        new_score           DECIMAL(18, 4) NULL,
        new_category        NVARCHAR(100)  NULL,
        new_band_id         BIGINT         NULL,
        new_status          NVARCHAR(20)   NOT NULL,
        message             NVARCHAR(500)  NULL,
        actor_employee_id   BIGINT         NULL,
        entered_by          NVARCHAR(100)  NOT NULL,
        entered_dt          DATETIME2      NOT NULL CONSTRAINT df_pm_asset_val_hist_edt DEFAULT SYSUTCDATETIME()
    );
    CREATE INDEX ix_pm_asset_val_hist_asset ON grac_practice.asset_valuation_history(asset_id, history_id DESC);
    CREATE INDEX ix_pm_asset_val_hist_run ON grac_practice.asset_valuation_history(run_id) WHERE run_id IS NOT NULL;
    PRINT '446: asset_valuation_history created.';
END
GO

IF OBJECT_ID('grac_practice.asset_valuation_result','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_valuation_result (
        asset_id           BIGINT         NOT NULL CONSTRAINT pk_pm_asset_val_result PRIMARY KEY
            CONSTRAINT fk_pm_asset_val_result_asset REFERENCES grac_practice.organization_dependency_asset(asset_id),
        organization_id    BIGINT         NOT NULL,
        config_id          BIGINT         NULL
            CONSTRAINT fk_pm_asset_val_result_cfg REFERENCES grac_practice.asset_valuation_config(config_id),
        config_version_no  INT            NULL,
        confidentiality    NVARCHAR(40)   NULL,
        integrity          NVARCHAR(40)   NULL,
        availability       NVARCHAR(40)   NULL,
        method_override    NVARCHAR(30)   NULL,
        method_used        NVARCHAR(30)   NULL,
        method_source      NVARCHAR(10)   NULL
            CONSTRAINT ck_pm_asset_val_result_msrc CHECK (method_source IS NULL OR method_source IN (N'CONFIG', N'OVERRIDE')),
        raw_score          DECIMAL(18, 6) NULL,
        asset_value_score  DECIMAL(18, 4) NULL,
        asset_value_category NVARCHAR(100) NULL,
        band_id            BIGINT         NULL,
        validation_status  NVARCHAR(20)   NOT NULL
            CONSTRAINT ck_pm_asset_val_result_status CHECK (validation_status IN (N'NOT_RATED', N'INCOMPLETE', N'INVALID', N'VALID')),
        validation_message NVARCHAR(500)  NULL,
        source             NVARCHAR(30)   NOT NULL,
        run_id             BIGINT         NULL,
        last_history_id    BIGINT         NULL,
        calculated_by      NVARCHAR(100)  NOT NULL,
        calculated_dt      DATETIME2      NOT NULL CONSTRAINT df_pm_asset_val_result_cdt DEFAULT SYSUTCDATETIME(),
        record_version     ROWVERSION     NOT NULL
    );
    CREATE INDEX ix_pm_asset_val_result_org ON grac_practice.asset_valuation_result(organization_id, validation_status, asset_value_category);
    PRINT '446: asset_valuation_result created.';
END
GO

