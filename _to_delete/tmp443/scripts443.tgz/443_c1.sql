
-- =====================================================================
-- 5. Candidate registration (5.6.3 Create Candidate; D109)
-- =====================================================================
-- Feeds the Asset Register form: 1. the exception  2. the observed values
-- that name a dictionary field (the form maps list values by label).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_candidate_get
    @organization_id BIGINT,
    @exception_id    BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @payload NVARCHAR(MAX), @found BIT = 0;
    SELECT @found = 1, @payload = o.payload_json
      FROM grac_practice.asset_reconciliation_exception e
      JOIN grac_practice.asset_discovery_observation o ON o.observation_id = e.observation_id
     WHERE e.exception_id = @exception_id AND e.organization_id = @organization_id;
    IF @found = 0 THROW 54773, 'Reconciliation exception not found for this organization.', 1;
    SELECT e.exception_id AS ExceptionId, e.exception_kind AS ExceptionKind, e.status AS Status, s.source_name AS SourceName,
           e.external_key AS ExternalKey, o.observed_dt AS ObservedDt, e.match_score AS MatchScore, e.asset_id AS AssetId,
           a.asset_name AS AssetName, CAST(CASE WHEN @payload IS NULL THEN 0 ELSE 1 END AS BIT) AS HasPayload,
           CONVERT(BIGINT, e.record_version) AS RecordVersion
      FROM grac_practice.asset_reconciliation_exception e
      JOIN grac_practice.asset_discovery_source s ON s.source_id = e.source_id
      JOIN grac_practice.asset_discovery_observation o ON o.observation_id = e.observation_id
      LEFT JOIN grac_practice.organization_dependency_asset a ON a.asset_id = e.asset_id
     WHERE e.exception_id = @exception_id;
    SELECT f.field_key AS FieldKey, f.display_label AS FieldLabel, f.data_type_code AS DataTypeCode, f.lookup_source AS LookupSource,
           LEFT(CAST(j.[value] AS NVARCHAR(MAX)), 400) AS ObservedValue
      FROM OPENJSON(ISNULL(@payload, N'{}')) j
      -- OPENJSON keys are Latin1_General_BIN2: compare in the database collation (Msg 468)
      JOIN grac_practice.asset_field_definition f ON f.field_key = j.[key] COLLATE DATABASE_DEFAULT
     WHERE j.[type] IN (1, 2) AND NULLIF(LTRIM(RTRIM(CAST(j.[value] AS NVARCHAR(MAX)))), N'') IS NOT NULL
     ORDER BY f.display_label;
END
GO
