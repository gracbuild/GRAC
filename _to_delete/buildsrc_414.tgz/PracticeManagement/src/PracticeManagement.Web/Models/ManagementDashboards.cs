// =====================================================================
// ManagementDashboards  (migrations 413 / 414)
//
// The parent-menu landing dashboards and the child screens each of their
// sections summarises. One map, read by:
//   * PracticeController -- a dashboard page is open to anyone who may
//     VIEW at least one of its child screens (it has no menu row, so no
//     grant of its own), and only the sections whose child the caller
//     may VIEW are shown;
//   * ManagementDashboardController (Web proxy) -- the same rule for the
//     data read.
// A dashboard summarises its children; it never shows what the child
// page itself would refuse.
// =====================================================================
namespace PracticeManagement.Web.Models;

public static class ManagementDashboards
{
    /// <summary>Dashboard screen key -> (section key, child screen key).</summary>
    public static readonly IReadOnlyDictionary<string, (string Section, string ChildScreen)[]> Sections =
        new Dictionary<string, (string, string)[]>(StringComparer.OrdinalIgnoreCase)
        {
            ["governance-dashboard"] =
            [
                ("frameworks", "organization-controls"),
                ("practices",  "organization-requirements"),
                ("instances",  "resolve")
            ],
            ["issues-actions-dashboard"] =
            [
                ("gaps",       "gaps"),
                ("tasks",      "tasks"),
                ("exceptions", "exception-centre")
            ],
            ["audit-assurance-dashboard"] =
            [
                ("audits",   "org-assurance-executions"),
                ("findings", "org-assurance-observations"),
                ("plans",    "org-assurance-plans")
            ]
        };

    /// <summary>API module key (route segment) of a dashboard screen:
    /// "governance-dashboard" -> "governance".</summary>
    public static string ModuleOf(string screenKey) =>
        screenKey.EndsWith("-dashboard", StringComparison.OrdinalIgnoreCase)
            ? screenKey[..^"-dashboard".Length]
            : screenKey;

    public static bool IsDashboard(string? screenKey) =>
        !string.IsNullOrWhiteSpace(screenKey) && Sections.ContainsKey(screenKey);

    /// <summary>The sections whose child screen passes <paramref name="canView"/>.</summary>
    public static string[] AllowedSections(string screenKey, Func<string, bool> canView) =>
        Sections.TryGetValue(screenKey, out var sections)
            ? sections.Where(s => canView(s.ChildScreen)).Select(s => s.Section).ToArray()
            : [];
}
