import sys
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w450/new'
A=R+'/src/PracticeManagement.Api/'
def edit(path, old, new, count=1):
    s=open(path).read(); assert s.count(old)==count, (path, old[:80], s.count(old)); open(path,'w').write(s.replace(old,new))

# ---------------------------------------------------------------- models
edit(A+'Models/AssetConfigModels.cs', """/// <summary>Refresh reviews and exception expiry for one asset or the organization.</summary>
public sealed record AssetPrivacyRunRequest(long OrganizationId, long? AssetId);
""", """/// <summary>Refresh reviews and exception expiry for one asset or the organization.</summary>
public sealed record AssetPrivacyRunRequest(long OrganizationId, long? AssetId);

// ---------------------------------------------------------------------
// Asset governance KPIs (migration 450)
// ---------------------------------------------------------------------
/// <summary>One KPI of the organization: enabled, weight 0-100, target / warning 0-100 (higher-is-better: warning not
/// above target; lower-is-better: not below), period in days for KPIs that have one. Reset = back to the defaults.</summary>
public sealed record AssetGovernanceSettingRequest(long OrganizationId, string? KpiCode, bool? Reset, bool? IsEnabled, int? Weight,
    decimal? TargetValue, decimal? WarningValue, int? PeriodDays);

/// <summary>Overall score thresholds and how long record-level detail of a snapshot is kept (days).</summary>
public sealed record AssetGovernanceOrgSettingRequest(long OrganizationId, decimal? OverallTarget, decimal? OverallWarning,
    int? ItemRetentionDays);

/// <summary>Relationships an asset type requires (Relationship Completeness). New when RuleId is null: asset type,
/// relationship type and AssetSide (SOURCE | TARGET) are then required and fixed afterwards.</summary>
public sealed record AssetGovernanceRelationshipRuleRequest(long OrganizationId, long? RuleId, int? AssetTypeId,
    string? RelationshipTypeCode, string? AssetSide, int? MinCount, bool? IsActive);

/// <summary>Take a snapshot now (a new version of today only when the results changed).</summary>
public sealed record AssetGovernanceSnapshotRequest(long OrganizationId);
""")

# ---------------------------------------------------------------- service
S=A+'Services/AssetConfigService.cs'
edit(S, """    Task<AssetLifecycleResult> RunPrivacyAsync(AssetPrivacyRunRequest request, string actor, CancellationToken ct);
}
""", """    Task<AssetLifecycleResult> RunPrivacyAsync(AssetPrivacyRunRequest request, string actor, CancellationToken ct);

    // 450 -- Asset governance KPIs
    Task<object?> GetGovernanceAsync(long organizationId, long? snapshotId, int trendDays, CancellationToken ct);
    Task<object?> ListGovernanceItemsAsync(long organizationId, long snapshotId, string kpiCode, string? outcome, string? search,
        int pageNumber, int pageSize, CancellationToken ct);
    Task<object> ListGovernanceSnapshotsAsync(long organizationId, int pageNumber, int pageSize, CancellationToken ct);
    Task<object> GetGovernanceSettingsAsync(long organizationId, CancellationToken ct);
    Task<AssetLifecycleResult> SaveGovernanceSettingAsync(AssetGovernanceSettingRequest request, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> SaveGovernanceOrgSettingAsync(AssetGovernanceOrgSettingRequest request, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> SaveGovernanceRelationshipRuleAsync(AssetGovernanceRelationshipRuleRequest request, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> TakeGovernanceSnapshotAsync(AssetGovernanceSnapshotRequest request, string actor, CancellationToken ct);
}
""")
edit(S, """    public async Task<object> GetBusinessServiceTreeAsync(""", """    // ----------------------------------------------------------------
    // 450 -- Asset governance KPIs
    // ----------------------------------------------------------------
    public async Task<object?> GetGovernanceAsync(long organizationId, long? snapshotId, int trendDays, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_governance_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@snapshot_id",     DbType.Int64, snapshotId);
            AddParam(command, "@trend_days",      DbType.Int32, trendDays);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var empty = new List<Dictionary<string, object?>>();
            var snapshot = await ReadRowsAsync(reader, ct);
            var kpis     = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var trend    = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            return new { snapshot = snapshot.Count > 0 ? snapshot[0] : null, kpis, trend };
        }
        catch (SqlException ex) when (ex.Number is 53080 or 53083) { return null; }
    }

    public async Task<object?> ListGovernanceItemsAsync(long organizationId, long snapshotId, string kpiCode, string? outcome, string? search,
        int pageNumber, int pageSize, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_governance_items");
            AddParam(command, "@organization_id", DbType.Int64,  organizationId);
            AddParam(command, "@snapshot_id",     DbType.Int64,  snapshotId);
            AddParam(command, "@kpi_code",        DbType.String, Blank(kpiCode), 30);
            AddParam(command, "@outcome",         DbType.String, Blank(outcome), 8);
            AddParam(command, "@search",          DbType.String, Blank(search), 200);
            AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
            AddParam(command, "@page_size",       DbType.Int32,  pageSize);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var rows = await ReadRowsAsync(reader, ct);
            var totals = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
            return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize, totals };
        }
        catch (SqlException ex) when (ex.Number is 53080 or 53081 or 53083) { return null; }
    }

    public async Task<object> ListGovernanceSnapshotsAsync(long organizationId, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_governance_snapshots");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        AddParam(command, "@page_number",     DbType.Int32, pageNumber);
        AddParam(command, "@page_size",       DbType.Int32, pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object> GetGovernanceSettingsAsync(long organizationId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_governance_settings");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var empty = new List<Dictionary<string, object?>>();
        var kpis              = await ReadRowsAsync(reader, ct);
        var overall           = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var relationshipRules = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var assetTypes        = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var relationshipTypes = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var services          = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        return new { kpis, overall = overall.Count > 0 ? overall[0] : null, relationshipRules, assetTypes, relationshipTypes,
                     services = services.Count > 0 ? services[0] : null };
    }

    public Task<AssetLifecycleResult> SaveGovernanceSettingAsync(AssetGovernanceSettingRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_governance_setting_save", "organizationId", command =>
        {
            AddParam(command, "@organization_id", DbType.Int64,   request.OrganizationId);
            AddParam(command, "@kpi_code",        DbType.String,  Blank(request.KpiCode), 30);
            AddParam(command, "@reset",           DbType.Boolean, request.Reset ?? false);
            AddParam(command, "@is_enabled",      DbType.Boolean, request.IsEnabled ?? true);
            AddParam(command, "@weight",          DbType.Int32,   request.Weight);
            AddParam(command, "@target_value",    DbType.Decimal, request.TargetValue);
            AddParam(command, "@warning_value",   DbType.Decimal, request.WarningValue);
            AddParam(command, "@period_days",     DbType.Int32,   request.PeriodDays);
            AddParam(command, "@actor",           DbType.String,  actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> SaveGovernanceOrgSettingAsync(AssetGovernanceOrgSettingRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_governance_org_setting_save", "organizationId", command =>
        {
            AddParam(command, "@organization_id",     DbType.Int64,   request.OrganizationId);
            AddParam(command, "@overall_target",      DbType.Decimal, request.OverallTarget);
            AddParam(command, "@overall_warning",     DbType.Decimal, request.OverallWarning);
            AddParam(command, "@item_retention_days", DbType.Int32,   request.ItemRetentionDays);
            AddParam(command, "@actor",               DbType.String,  actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> SaveGovernanceRelationshipRuleAsync(AssetGovernanceRelationshipRuleRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_governance_relationship_rule_save", "ruleId", command =>
        {
            AddParam(command, "@organization_id",        DbType.Int64,   request.OrganizationId);
            AddParam(command, "@rule_id",                DbType.Int64,   request.RuleId);
            AddParam(command, "@asset_type_id",          DbType.Int32,   request.AssetTypeId);
            AddParam(command, "@relationship_type_code", DbType.String,  Blank(request.RelationshipTypeCode), 30);
            AddParam(command, "@asset_side",             DbType.String,  Blank(request.AssetSide), 6);
            AddParam(command, "@min_count",              DbType.Int32,   request.MinCount ?? 1);
            AddParam(command, "@is_active",              DbType.Boolean, request.IsActive ?? true);
            AddParam(command, "@actor",                  DbType.String,  actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> TakeGovernanceSnapshotAsync(AssetGovernanceSnapshotRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_governance_snapshot_take", "snapshotId", command =>
        {
            command.CommandTimeout = 600;   // every KPI over every record of the organization
            AddParam(command, "@organization_id", DbType.Int64,  request.OrganizationId);
            AddParam(command, "@source_code",     DbType.String, "MANUAL", 10);
            AddParam(command, "@actor",           DbType.String, actor, 100);
        }, ct);

    public async Task<object> GetBusinessServiceTreeAsync(""")

# ---------------------------------------------------------------- controller
C=A+'Controllers/AssetConfigController.cs'
edit(C, """//   POST privacy/run                                 refresh reviews and exception expiry
""", """//   POST privacy/run                                 refresh reviews and exception expiry
//   GET  governance?organizationId=&snapshotId=&trendDays=   KPI scorecard of a snapshot (default: current) + trend (450)
//   GET  governance/items?organizationId=&snapshotId=&kpiCode=&outcome=&search=&pageNumber=&pageSize=   record drill-down
//   GET  governance/snapshots?organizationId=&pageNumber=&pageSize=   every snapshot version
//   GET  governance/settings?organizationId=         KPI settings, overall thresholds, relationship requirements
//   POST governance/settings                         one KPI (enabled, weight, thresholds, period) or reset
//   POST governance/settings/overall                 overall thresholds and record-detail retention
//   POST governance/relationship-rules               relationship requirement of an asset type
//   POST governance/snapshot                         take a snapshot now
""")
edit(C, """    // 448: 53050 (organization), 53051 (asset), 53052 (requirement), 53054 (asset type), 53056 (exception), 53064 (review)""", """    // ---------------------------------------------------------------- 450: asset governance KPIs
    [HttpGet("governance")]
    public Task<IActionResult> Governance([FromQuery] long? organizationId, [FromQuery] long? snapshotId, [FromQuery] int? trendDays,
        CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetGovernanceAsync(o, snapshotId, trendDays ?? 90, ct), "Snapshot not found.", "governance");

    [HttpGet("governance/items")]
    public Task<IActionResult> GovernanceItems([FromQuery] long? organizationId, [FromQuery] long? snapshotId, [FromQuery] string? kpiCode,
        [FromQuery] string? outcome, [FromQuery] string? search, [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (snapshotId is null or <= 0 || string.IsNullOrWhiteSpace(kpiCode))
            return Task.FromResult<IActionResult>(BadRequest(new { error = "snapshotId and kpiCode are required." }));
        return ReadOrNotFound(organizationId, o => service.ListGovernanceItemsAsync(o, snapshotId.Value, kpiCode!, outcome, search,
            pageNumber ?? 1, pageSize ?? 25, ct), "Snapshot or KPI not found.", "governance items");
    }

    [HttpGet("governance/snapshots")]
    public Task<IActionResult> GovernanceSnapshots([FromQuery] long? organizationId, [FromQuery] int? pageNumber, [FromQuery] int? pageSize,
        CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListGovernanceSnapshotsAsync(organizationId.Value, pageNumber ?? 1, pageSize ?? 25, ct), "governance snapshots");
    }

    [HttpGet("governance/settings")]
    public Task<IActionResult> GovernanceSettings([FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.GetGovernanceSettingsAsync(organizationId.Value, ct), "governance settings");
    }

    [HttpPost("governance/settings")]
    public async Task<IActionResult> SaveGovernanceSetting([FromBody] AssetGovernanceSettingRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.KpiCode)) return BadRequest(new { error = "kpiCode is required." });
        return ResultWritten(await service.SaveGovernanceSettingAsync(request, Actor, ct), GovernanceNotFound, GovernanceConflict);
    }

    [HttpPost("governance/settings/overall")]
    public async Task<IActionResult> SaveGovernanceOrgSetting([FromBody] AssetGovernanceOrgSettingRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveGovernanceOrgSettingAsync(request, Actor, ct), GovernanceNotFound, GovernanceConflict);
    }

    [HttpPost("governance/relationship-rules")]
    public async Task<IActionResult> SaveGovernanceRelationshipRule([FromBody] AssetGovernanceRelationshipRuleRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveGovernanceRelationshipRuleAsync(request, Actor, ct), GovernanceNotFound, GovernanceConflict);
    }

    [HttpPost("governance/snapshot")]
    public async Task<IActionResult> TakeGovernanceSnapshot([FromBody] AssetGovernanceSnapshotRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.TakeGovernanceSnapshotAsync(request, Actor, ct), GovernanceNotFound, GovernanceConflict);
    }

    // 450: 53080 (organization), 53081 (KPI), 53083 (snapshot), 53084 (asset type), 53085 (relationship type),
    //      53086 (relationship requirement) -> 404; 53088 (requirement exists) -> 409; others -> 400.
    private static readonly int[] GovernanceNotFound = { 53080, 53081, 53083, 53084, 53085, 53086 };
    private static readonly int[] GovernanceConflict = { 53088 };

    // 448: 53050 (organization), 53051 (asset), 53052 (requirement), 53054 (asset type), 53056 (exception), 53064 (review)""")
print('api patched')
