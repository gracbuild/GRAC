-- =====================================================================
-- 442  Asset discovery and reconciliation: source profiles, field
--      precedence, identification rules, observations, matching outcomes,
--      reconciliation queue, data confidence and freshness
--      (Asset & Contract Management, Phase 7 increment 3)
--
-- REQUEST
-- -------
--   BRD v1.7 5.6 "Asset Discovery and Reconciliation": ingest asset
--   observations from approved discovery, endpoint, identity, cloud,
--   network, security, ERP and specialist systems and reconcile them to
--   governed asset records without silently overwriting approved data.
--   5.6.1 source profile (ID / name, type, authoritative domains, schedule /
--   mode, tenant / scope, field mapping version, source priority by field,
--   health / last run, owner / credential reference, retention); 5.6.2
--   identification and matching (cloud resource ID, serial + make / model,
--   asset tag / finance asset ID, device / directory ID, hostname + domain,
--   MAC, IP as a low-confidence signal; composite rules, normalization,
--   strong identifiers above mutable ones; a score from matched
--   attributes, conflicts and source trust; thresholds for Auto Match,
--   Suggested Match, Manual Review, New Candidate, Conflict); 5.6.3
--   outcomes (create candidate, update existing by precedence, no change,
--   conflict with both values kept plus exception and owner task,
--   potential duplicate review); 5.6.4 confidence and freshness (identity,
--   attribute, freshness, conflict, verification; Verified / Probable /
--   Unverified / Stale / Conflicting); 5.6.5 acceptance criteria (idempotent
--   repeats, identical rules for UI / import / API, traceability to the
--   observation and rule version, low-confidence changes never overwrite,
--   per-record results for partial batches). Plan:
--   docs/asset-contract-management.md (Phase 7.3, D97-D107).
--
-- WHAT THIS DOES
-- --------------
--   1. Discovery sources (per organization) with field precedence (golden /
--      contributing source per field and priority), trust, expected
--      observation interval, retention and health.
--   2. Identification rules (per organization, defaults seeded on first
--      use) and reconciliation settings (score thresholds, stale multiplier,
--      verification window, conflict tasks) with a rule-set version.
--   3. Ingestion (sp_asset_discovery_ingest): one batch per source and
--      batch reference (a repeated reference returns the first batch); each
--      record reconciled on its own (a failed record never undoes the
--      others); per-record results; retention applied to the source.
--   4. Reconciliation of an observation: an unchanged repeat is No change;
--      otherwise every active rule is scored against the register and the
--      source links; Auto Match updates the asset by field precedence,
--      Suggested / Manual review / New candidate / Potential duplicate open
--      a reconciliation exception; a value the source may not overwrite is a
--      Conflict exception (both values kept) with an owner task.
--   5. Reconciliation queue: link (apply), ignore, not a duplicate, accept
--      the observed value or keep the current one.
--   6. Data confidence per asset (fn_asset_discovery_confidence): identity
--      score, freshness, open conflicts, verification -> Verified / Probable
--      / Unverified / Stale / Conflicting.
--   7. Asset Discovery screen (menu row, readers / writers); Task Centre
--      task type Asset Reconciliation.
--
-- NOT DONE HERE: merge and split of assets, stale-asset retirement with
--   source confirmation (Phase 7.4); connectors that pull from external
--   systems (batches are posted by import or API); creating a register asset
--   from a new candidate (register it, then link the candidate); updating
--   make / model / lookup fields from observations (recorded only);
--   relationship observations.
--
-- ERROR NUMBERS: 54760-54779
--   54760 organization not found          54761 source not found
--   54762 source code / name              54763 source type / mode
--   54764 trust / interval / retention    54765 owner
--   54766 field precedence                54767 rule not found
--   54768 rule definition                 54769 thresholds
--   54770 source inactive                 54771 batch reference / records
--   54772 too many records                54773 exception not found
--   54774 changed by someone else         54775 exception not open
--   54776 action not valid                54777 asset
--   54778 note required                   54779 batch not found
--
-- ALSO EDITED: API (AssetConfig service / controller / models), Web proxy,
--   PracticeScreen + Manage.cshtml + appsettings, asset-discovery.cshtml /
--   .js (new), 274 (menu), docs.
-- DEPENDS ON: 196, 420, 425, 428, 438.
-- Rollback: 442_asset_discovery_rollback.sql
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.sp_asset_field_value_set','P') IS NULL
   OR OBJECT_ID('grac_practice.asset_make','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_model','U') IS NULL
   OR OBJECT_ID('grac_practice.sp_task_open','P') IS NULL
   OR NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_practice_task_source_type' AND definition LIKE '%Asset''%')
BEGIN
    RAISERROR('ABORT (442): run 196, 420, 425, 428 and 438 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Task type for conflict tasks
-- =====================================================================
MERGE grac_practice.task_type_master AS t
USING (VALUES (N'AssetReconciliation', N'Asset Reconciliation', N'Resolve a discovery conflict on an asset record', 72, N'Medium', 1, 91))
   AS s(type_code, type_name, description, default_sla_hours, default_priority, is_system_only, display_order)
ON t.type_code = s.type_code
WHEN NOT MATCHED BY TARGET THEN
    INSERT (type_code, type_name, description, default_sla_hours, default_priority, is_system_only, display_order, entered_by)
    VALUES (s.type_code, s.type_name, s.description, s.default_sla_hours, s.default_priority, s.is_system_only, s.display_order, N'seed-442');
PRINT CONCAT('442: task type inserted: ', @@ROWCOUNT);
GO

-- =====================================================================
-- 2. Sources and field precedence (5.6.1)
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_discovery_source','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_discovery_source (
        source_id                  BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_adisc_src PRIMARY KEY,
        organization_id            BIGINT         NOT NULL
            CONSTRAINT fk_pm_adisc_src_org REFERENCES grac_practice.organization(organization_id),
        source_code                NVARCHAR(40)   NOT NULL,
        source_name                NVARCHAR(200)  NOT NULL,
        source_type                NVARCHAR(12)   NOT NULL
            CONSTRAINT ck_pm_adisc_src_type CHECK (source_type IN (N'DISCOVERY', N'ENDPOINT', N'IDENTITY', N'CLOUD', N'NETWORK', N'SECURITY',
                                                                   N'ERP', N'BIOMEDICAL', N'FLEET', N'CUSTOM')),
        collection_mode            NVARCHAR(8)    NOT NULL
            CONSTRAINT ck_pm_adisc_src_mode CHECK (collection_mode IN (N'POLLING', N'WEBHOOK', N'BATCH', N'FILE', N'API')),
        scope_text                 NVARCHAR(400)  NULL,     -- accounts, subscriptions, sites, networks
        mapping_version            NVARCHAR(40)   NULL,     -- approved field mapping version
        owner_employee_id          BIGINT         NULL
            CONSTRAINT fk_pm_adisc_src_owner REFERENCES grac_practice.organization_employee(employee_id),
        credential_reference       NVARCHAR(200)  NULL,     -- a vault reference, never a secret
        trust_level                INT            NOT NULL CONSTRAINT ck_pm_adisc_src_trust CHECK (trust_level BETWEEN 1 AND 100),
        expected_interval_hours    INT            NOT NULL CONSTRAINT ck_pm_adisc_src_int CHECK (expected_interval_hours BETWEEN 1 AND 8760),
        raw_retention_days         INT            NOT NULL CONSTRAINT ck_pm_adisc_src_raw CHECK (raw_retention_days BETWEEN 1 AND 3650),
        observation_retention_days INT            NOT NULL CONSTRAINT ck_pm_adisc_src_obs CHECK (observation_retention_days BETWEEN 1 AND 3650),
        is_active                  BIT            NOT NULL,
        last_batch_id              BIGINT         NULL,
        last_run_dt                DATETIME2      NULL,
        last_run_status            NVARCHAR(10)   NULL,
        entered_by                 NVARCHAR(100)  NOT NULL CONSTRAINT df_pm_adisc_src_eby DEFAULT N'system',
        entered_dt                 DATETIME2      NOT NULL CONSTRAINT df_pm_adisc_src_edt DEFAULT SYSUTCDATETIME(),
        updated_by                 NVARCHAR(100)  NULL,
        updated_dt                 DATETIME2      NULL,
        record_version             ROWVERSION     NOT NULL,
        CONSTRAINT uq_pm_adisc_src_code UNIQUE (organization_id, source_code),
        CONSTRAINT uq_pm_adisc_src_name UNIQUE (organization_id, source_name)
    );
    PRINT '442: asset_discovery_source created.';
END
GO

IF OBJECT_ID('grac_practice.asset_discovery_priority','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_discovery_priority (
        source_id   BIGINT        NOT NULL
            CONSTRAINT fk_pm_adisc_pri_src REFERENCES grac_practice.asset_discovery_source(source_id),
        field_key   NVARCHAR(100) NOT NULL,
        source_role NVARCHAR(12)  NOT NULL
            CONSTRAINT ck_pm_adisc_pri_role CHECK (source_role IN (N'GOLDEN', N'CONTRIBUTING', N'IGNORED')),
        priority    INT           NOT NULL CONSTRAINT ck_pm_adisc_pri_pri CHECK (priority BETWEEN 1 AND 999),
        CONSTRAINT pk_pm_adisc_pri PRIMARY KEY (source_id, field_key)
    );
    PRINT '442: asset_discovery_priority created.';
END
GO

-- =====================================================================
-- 3. Identification rules and settings (5.6.2)
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_identification_rule','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_identification_rule (
        rule_id         BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_aid_rule PRIMARY KEY,
        organization_id BIGINT        NOT NULL
            CONSTRAINT fk_pm_aid_rule_org REFERENCES grac_practice.organization(organization_id),
        rule_name       NVARCHAR(120) NOT NULL,
        attribute_keys  NVARCHAR(400) NOT NULL,     -- comma list of field keys; @source_key = the record ID at the source
        strength        NVARCHAR(10)  NOT NULL
            CONSTRAINT ck_pm_aid_rule_str CHECK (strength IN (N'STRONG', N'SUPPORTING', N'WEAK')),
        weight          INT           NOT NULL CONSTRAINT ck_pm_aid_rule_w CHECK (weight BETWEEN 1 AND 100),
        is_active       BIT           NOT NULL,
        display_order   INT           NOT NULL,
        entered_by      NVARCHAR(100) NOT NULL CONSTRAINT df_pm_aid_rule_eby DEFAULT N'system',
        entered_dt      DATETIME2     NOT NULL CONSTRAINT df_pm_aid_rule_edt DEFAULT SYSUTCDATETIME(),
        updated_by      NVARCHAR(100) NULL,
        updated_dt      DATETIME2     NULL,
        CONSTRAINT uq_pm_aid_rule_name UNIQUE (organization_id, rule_name)
    );
    PRINT '442: asset_identification_rule created.';
END
GO

IF OBJECT_ID('grac_practice.asset_discovery_setting','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_discovery_setting (
        organization_id       BIGINT        NOT NULL CONSTRAINT pk_pm_adisc_set PRIMARY KEY
            CONSTRAINT fk_pm_adisc_set_org REFERENCES grac_practice.organization(organization_id),
        auto_match_score      INT           NOT NULL,
        suggested_score       INT           NOT NULL,
        manual_review_score   INT           NOT NULL,
        stale_multiplier      INT           NOT NULL CONSTRAINT ck_pm_adisc_set_stale CHECK (stale_multiplier BETWEEN 1 AND 100),
        verification_days     INT           NOT NULL CONSTRAINT ck_pm_adisc_set_ver CHECK (verification_days BETWEEN 1 AND 3650),
        create_conflict_tasks BIT           NOT NULL,
        rule_set_version      INT           NOT NULL,
        updated_by            NVARCHAR(100) NOT NULL,
        updated_dt            DATETIME2     NOT NULL CONSTRAINT df_pm_adisc_set_udt DEFAULT SYSUTCDATETIME(),
        CONSTRAINT ck_pm_adisc_set_thr CHECK (auto_match_score <= 100 AND auto_match_score > suggested_score
                                              AND suggested_score > manual_review_score AND manual_review_score >= 1)
    );
    PRINT '442: asset_discovery_setting created.';
END
GO

-- =====================================================================
-- 4. Batches, observations, links, attribute sources (5.6.3-5.6.5)
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_discovery_batch','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_discovery_batch (
        batch_id         BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_adisc_batch PRIMARY KEY,
        organization_id  BIGINT        NOT NULL,
        source_id        BIGINT        NOT NULL
            CONSTRAINT fk_pm_adisc_batch_src REFERENCES grac_practice.asset_discovery_source(source_id),
        batch_reference  NVARCHAR(100) NOT NULL,
        channel          NVARCHAR(10)  NOT NULL CONSTRAINT ck_pm_adisc_batch_ch CHECK (channel IN (N'UI', N'IMPORT', N'API')),
        status           NVARCHAR(10)  NOT NULL
            CONSTRAINT ck_pm_adisc_batch_status CHECK (status IN (N'RUNNING', N'COMPLETED', N'PARTIAL', N'FAILED')),
        record_count     INT           NOT NULL CONSTRAINT df_pm_adisc_batch_rc DEFAULT 0,
        updated_count    INT           NOT NULL CONSTRAINT df_pm_adisc_batch_uc DEFAULT 0,
        no_change_count  INT           NOT NULL CONSTRAINT df_pm_adisc_batch_nc DEFAULT 0,
        exception_count  INT           NOT NULL CONSTRAINT df_pm_adisc_batch_xc DEFAULT 0,
        error_count      INT           NOT NULL CONSTRAINT df_pm_adisc_batch_ec DEFAULT 0,
        rule_set_version INT           NOT NULL,
        received_dt      DATETIME2     NOT NULL CONSTRAINT df_pm_adisc_batch_rdt DEFAULT SYSUTCDATETIME(),
        completed_dt     DATETIME2     NULL,
        entered_by       NVARCHAR(100) NOT NULL,
        CONSTRAINT uq_pm_adisc_batch_ref UNIQUE (source_id, batch_reference)
    );
    PRINT '442: asset_discovery_batch created.';
END
GO

IF OBJECT_ID('grac_practice.asset_discovery_observation','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_discovery_observation (
        observation_id   BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_adisc_obs PRIMARY KEY,
        organization_id  BIGINT         NOT NULL,
        batch_id         BIGINT         NOT NULL
            CONSTRAINT fk_pm_adisc_obs_batch REFERENCES grac_practice.asset_discovery_batch(batch_id),
        source_id        BIGINT         NOT NULL,
        record_no        INT            NOT NULL,
        external_key     NVARCHAR(200)  NULL,
        observed_dt      DATETIME2      NOT NULL,
        payload_json     NVARCHAR(MAX)  NULL,      -- normalized attributes; cleared after the raw retention
        payload_hash     VARBINARY(32)  NULL,
        outcome          NVARCHAR(20)   NULL
            CONSTRAINT ck_pm_adisc_obs_outcome CHECK (outcome IS NULL OR outcome IN (N'UPDATED', N'NO_CHANGE', N'SUGGESTED', N'MANUAL_REVIEW',
                                                                                    N'NEW_CANDIDATE', N'POTENTIAL_DUPLICATE', N'ERROR')),
        match_score      INT            NULL,
        matched_asset_id BIGINT         NULL,
        second_asset_id  BIGINT         NULL,
        second_score     INT            NULL,
        matched_rules    NVARCHAR(400)  NULL,
        result_text      NVARCHAR(1000) NULL,
        rule_set_version INT            NOT NULL,
        entered_dt       DATETIME2      NOT NULL CONSTRAINT df_pm_adisc_obs_edt DEFAULT SYSUTCDATETIME()
    );
    CREATE INDEX ix_pm_adisc_obs_batch ON grac_practice.asset_discovery_observation(batch_id, record_no);
    CREATE INDEX ix_pm_adisc_obs_key ON grac_practice.asset_discovery_observation(source_id, external_key);
    PRINT '442: asset_discovery_observation created.';
END
GO

IF OBJECT_ID('grac_practice.asset_discovery_link','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_discovery_link (
        link_id             BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_adisc_link PRIMARY KEY,
        organization_id     BIGINT        NOT NULL,
        asset_id            BIGINT        NOT NULL
            CONSTRAINT fk_pm_adisc_link_asset REFERENCES grac_practice.organization_dependency_asset(asset_id),
        source_id           BIGINT        NOT NULL
            CONSTRAINT fk_pm_adisc_link_src REFERENCES grac_practice.asset_discovery_source(source_id),
        external_key        NVARCHAR(200) NOT NULL,
        identity_score      INT           NOT NULL,
        link_method         NVARCHAR(10)  NOT NULL CONSTRAINT ck_pm_adisc_link_m CHECK (link_method IN (N'AUTO', N'CONFIRMED')),
        first_seen_dt       DATETIME2     NOT NULL,
        last_seen_dt        DATETIME2     NOT NULL,
        last_observation_id BIGINT        NULL,
        last_payload_hash   VARBINARY(32) NULL,
        CONSTRAINT uq_pm_adisc_link_key UNIQUE (source_id, external_key)
    );
    CREATE INDEX ix_pm_adisc_link_asset ON grac_practice.asset_discovery_link(asset_id);
    PRINT '442: asset_discovery_link created.';
END
GO

IF OBJECT_ID('grac_practice.asset_attribute_source','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_attribute_source (
        asset_id       BIGINT        NOT NULL
            CONSTRAINT fk_pm_aattr_src_asset REFERENCES grac_practice.organization_dependency_asset(asset_id),
        field_key      NVARCHAR(100) NOT NULL,
        source_id      BIGINT        NOT NULL
            CONSTRAINT fk_pm_aattr_src_src REFERENCES grac_practice.asset_discovery_source(source_id),
        observed_value NVARCHAR(400) NULL,
        observed_dt    DATETIME2     NOT NULL,
        observation_id BIGINT        NOT NULL,
        applied        BIT           NOT NULL,
        CONSTRAINT pk_pm_aattr_src PRIMARY KEY (asset_id, field_key, source_id)
    );
    PRINT '442: asset_attribute_source created.';
END
GO

IF OBJECT_ID('grac_practice.asset_reconciliation_exception','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_reconciliation_exception (
        exception_id     BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_arec_exc PRIMARY KEY,
        organization_id  BIGINT         NOT NULL,
        exception_kind   NVARCHAR(16)   NOT NULL
            CONSTRAINT ck_pm_arec_exc_kind CHECK (exception_kind IN (N'SUGGESTED_MATCH', N'MANUAL_REVIEW', N'NEW_CANDIDATE', N'DUPLICATE', N'CONFLICT')),
        observation_id   BIGINT         NOT NULL
            CONSTRAINT fk_pm_arec_exc_obs REFERENCES grac_practice.asset_discovery_observation(observation_id),
        source_id        BIGINT         NOT NULL,
        external_key     NVARCHAR(200)  NULL,
        asset_id         BIGINT         NULL,
        other_asset_id   BIGINT         NULL,
        field_key        NVARCHAR(100)  NULL,
        current_value    NVARCHAR(400)  NULL,
        observed_value   NVARCHAR(400)  NULL,
        match_score      INT            NULL,
        status           NVARCHAR(10)   NOT NULL CONSTRAINT ck_pm_arec_exc_status CHECK (status IN (N'OPEN', N'RESOLVED')),
        resolution       NVARCHAR(20)   NULL,
        resolution_note  NVARCHAR(1000) NULL,
        resolved_by      NVARCHAR(100)  NULL,
        resolved_dt      DATETIME2      NULL,
        task_id          BIGINT         NULL,
        raised_count     INT            NOT NULL CONSTRAINT df_pm_arec_exc_rc DEFAULT 1,
        entered_dt       DATETIME2      NOT NULL CONSTRAINT df_pm_arec_exc_edt DEFAULT SYSUTCDATETIME(),
        updated_dt       DATETIME2      NULL,
        record_version   ROWVERSION     NOT NULL
    );
    CREATE INDEX ix_pm_arec_exc_org ON grac_practice.asset_reconciliation_exception(organization_id, status, exception_kind);
    CREATE INDEX ix_pm_arec_exc_key ON grac_practice.asset_reconciliation_exception(source_id, external_key, status);
    PRINT '442: asset_reconciliation_exception created.';
END
GO

IF OBJECT_ID('grac_practice.asset_duplicate_decision','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_duplicate_decision (
        asset_id_low  BIGINT         NOT NULL,
        asset_id_high BIGINT         NOT NULL,
        note          NVARCHAR(1000) NOT NULL,
        decided_by    NVARCHAR(100)  NOT NULL,
        decided_dt    DATETIME2      NOT NULL CONSTRAINT df_pm_adup_dt DEFAULT SYSUTCDATETIME(),
        CONSTRAINT pk_pm_adup PRIMARY KEY (asset_id_low, asset_id_high)
    );
    PRINT '442: asset_duplicate_decision created.';
END
GO
