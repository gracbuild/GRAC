import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (a[:60], s.count(a))
    s = s.replace(a, b)

rep("evidence expiry and restrictive-use reviews (`439`).",
    "evidence expiry and restrictive-use reviews (`439`), Phase 7.1 CMDB relationships -- relationship types, governed effective-dated relationships, impact analysis and the retirement gate (`440`).")
rep("| 7 | CMDB relationships, business services, impact analysis, discovery & reconciliation | | 4 |",
    "| 7.1 **(done)** | CMDB relationships (5.4): the twelve relationship types with permitted kinds, cardinality, loop rule and dependent side; effective-dated relationships between assets, applications, processes, vendors and locations -- Proposed / Active / Disputed / Inactive / Retired, critical dependency, weight, confidence, owner / verifier, evidence and change references, version history; approval (another person for critical), pending changes and retirement of critical relationships, dispute / confirm; circular-dependency blocking and loop flagging; impact analysis upstream / downstream with depth and no double counting; retirement gate on the asset lifecycle; Asset Relationships screen | 440 | 4 |\n"
    "| 7.2 | Business services (5.5): service hierarchy, owners, criticality / CIA, RTO / RPO / MTPD, supporting assets and services (Supports Service), supplier / contract dependencies, activation and retirement rules, conflict warnings, service impact | | 7.1 |\n"
    "| 7.3 | Discovery and reconciliation (5.6): source profiles, observations, identification / matching rules, outcomes (candidate, update, conflict, duplicate, merge / split, stale), confidence and freshness | | 7.1 |")
rep("""| D33 | **Cancel keeps the asset status** (433)""",
"""| D79 | **Relationship types** (440) are a global master of the twelve BRD 5.4 types. Each states its label and inverse label, the kinds it permits as source and target, its cardinality (many, one target per source -- Hosted On, Located In; one source per target -- Contains; one to one -- Replaces), its loop rule (Block; Allow and flag -- Protects, Backed Up By; Allow -- Connected To, Monitored By) and its dependent side for impact (Depends On, Hosted On, Runs On, Backed Up By, Located In: the source depends on the target; Contains, Protects, Stores Data For, Supports Service: the target depends on the source; Connected To, Monitored By, Replaces: no impact). Supports Service stays inactive until business services exist (7.2). Organizations cannot add types yet. | BRD 5.4, 5.4.2. | Yes. |
| D80 | **Configuration items** are the existing organization records: assets (usable unless Disposed / Archived), applications, processes, vendors and locations (usable while Active). Racks, rooms and enclosures are assets or register option values; Located In targets an enclosure asset or a site, and the register location field stays the authoritative site. | BRD 5.4. | Yes. |
| D81 | **Relationship lifecycle**: a new relationship is Proposed (source Manual, Unverified) and becomes Active (Verified) when a holder of APPROVE approves it -- another person than the proposer for a critical one. A rejected or withdrawn proposal is Retired with its note. Active -> Disputed (note) -> Confirmed (APPROVE) or Retired. An Active relationship whose effective-to date passed becomes Inactive. Type and endpoints are fixed once proposed (retire and propose again to reassign). Every change is a numbered history row with a snapshot. | BRD 5.4.1, 5.4.4. | Yes. |
| D82 | **Critical changes**: changing an active relationship that is or becomes critical, and retiring an active critical relationship, wait for approval as a pending change; the relationship stays Active as it was until another person approves (the requester can withdraw; a holder of APPROVE can reject). The impact preview in the relationship window shows what depends on its provider end (including a proposal). | BRD 5.4.2 "changes to critical relationships require impact preview and approval". | Yes. |
| D83 | **Loops**: for types with impact, the check walks the dependency graph of every proposed, active and disputed relationship of every impact type; Block refuses a relationship whose provider already depends on its dependent, Flag records it as a loop. Types without impact check loops among relationships of the same type (Replaces). Cardinality also counts proposed, active and disputed relationships. Checks run on proposal and again on approval. | BRD 5.4.2. | Yes. |
| D84 | **Impact analysis** walks Active, currently effective relationships breadth first: downstream = what is affected when the item fails, upstream = what it relies on; depth 1-10 (default 5); each item once at its nearest level, reached through its critical relationship first; critical-only walks critical dependencies only. The impact weight is recorded but not yet combined into a score (Phase 8 risk / dashboards). | BRD 5.4.2, 5.5.2. | Yes. |
| D85 | **Source and confidence**: relationships entered on the screen are Manual with an optional confidence (0-100); discovered, imported, API and inferred relationships and calculated confidence come with discovery (7.3). | BRD 5.4.1, 5.6. | Yes. |
| D86 | **Retirement gate**: moving an asset to Sanitization Pending, Disposal Approval, Disposed or Archived is refused while active critical relationships depend on it, naming them; a dependency is cleared by retiring it (reassign = retire and propose a new one) or accepting it for retirement (APPROVE, note). Checked when the lifecycle change is requested, not again when a pending lifecycle change is approved. | BRD 5.4.2, 5.4.3. | Yes. |
| D87 | **Not in 7.1**: service, risk, change and continuity reviews raised by a relationship change (5.4.4 -- with services, risk and dashboards); a relationships tab on the asset itself (the Asset Relationships screen filters by item); graphical topology. | BRD 5.4.4. | Yes. |
| D33 | **Cancel keeps the asset status** (433)""")
rep("""### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""",
"""### CMDB relationships (440)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `relationships/config?organizationId=` | `{types, employees}` | `sp_asset_relationship_config_get` |
| GET | `relationships/ci-lookup?organizationId=&kind=&search=` | Up to 50 items (`ciKind, ciId, ciName, ciClass, ciStatus, isUsable`) | `sp_asset_ci_lookup` |
| GET | `relationships?organizationId=&ciKind=&ciId=&typeCode=&status=&criticalOnly=&pendingOnly=&search=&pageNumber=&pageSize=` | Relationships (status empty = proposed, active, disputed; ALL; or one status); expired ones turned Inactive first | `sp_asset_relationships` |
| GET | `relationships/{id}?organizationId=` | `{relationship, history[]}` | `sp_asset_relationship_get` |
| POST | `relationships` | `{organizationId, relationshipId?, relationshipTypeCode, sourceKind, sourceId, targetKind, targetId, isCritical, dependencyCriticality?, impactWeight?, effectiveFrom?, effectiveTo?, confidencePct?, ownerEmployeeId?, verifierEmployeeId?, evidenceReference?, changeReference?, reason?, expectedRecordVersion?}` -> `result` PROPOSED / UPDATED / PENDING_APPROVAL | `sp_asset_relationship_save` |
| POST | `relationships/{id}/action` | `{organizationId, action: APPROVE \\| REJECT \\| WITHDRAW \\| DISPUTE \\| CONFIRM \\| RETIRE \\| ACCEPT_RETIREMENT, note?, expectedRecordVersion?}` | `sp_asset_relationship_action` |
| GET | `relationships/impact?organizationId=&ciKind=&ciId=&direction=DOWNSTREAM\\|UPSTREAM&maxDepth=&criticalOnly=&previewRelationshipId=` | `{rows: [ciKind, ciId, ciName, impactLevel, viaRelationshipId, viaLabel, viaCritical, fromName, ...], summary}` | `sp_asset_ci_impact` |

Proxy area `asset-relationships`: GETs VIEW (organization required); proposal ADD, change EDIT; APPROVE / REJECT / CONFIRM / ACCEPT_RETIREMENT -> APPROVE, DISPUTE / RETIRE / WITHDRAW -> EDIT. Errors `54701-54720`; 54701 / 54709 -> 404, 54710 / 54712 -> 409; 54719 is raised by the asset lifecycle transition (register `transition`).

### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""")
rep("""## 8. Verification (static -- no compiler or database on this machine)""",
"""### Phase 7.1 files (440)
| Layer | File | Change |
|---|---|---|
| DB | `database/440_asset_relationships.sql` (+ rollback restoring the 435 transition body) | Relationship types, relationships, history; CI catalogue, edges and blocker functions; check, history, sync, save, action, impact and readers; menu row. Re-issued: `sp_asset_lifecycle_transition` (retirement gate). |
| DB | `database/274_menu_master_seed.sql` | `asset-relationships` (361) under `nav-asset-contract`. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 7 routes; save and action requests. |
| API / Web | `appsettings.json` (both) | `asset-relationships:*` for PM_ORG_ADMIN. |
| Web | `Controllers/AssetConfigController.cs`, `Models/PracticeScreen.cs`, `Views/Practice/Manage.cshtml` | Relationship permissions; Asset Relationships screen. |
| Web | `Partials/asset-relationships.cshtml`, `js/AssetConfig/asset-relationships.js` (new) | Relationships (filters by item, type, status, critical, waiting), relationship window (propose / change / actions / impact preview / history), impact analysis, relationship types. |

## 8. Verification (static -- no compiler or database on this machine)""")
s = s.rstrip('\n') + """

440 got the same sweep (clean; one semicolon before ELSE replaced by a single CASE assignment), the reserved-alias and outer-reference-aggregate scans (none), a parameter-name check of every internal EXEC, a diff of the re-issued lifecycle transition against its 435 body (one marked block added), the C#-to-procedure parameter cross-check for all 7 bound procedures (writes return the numeric RelationshipId), the JS-to-alias, HTML-id and duplicate-id checks, `node --check`, brace / parenthesis / bracket balance of the five edited C# files, both `appsettings.json` parse, the ASCII check and the Razor scan. Loops and impact use a breadth-first walk with a visited set (no recursive CTE, so dense graphs cannot multiply paths). Its verification block checks the types, the tables and the current-relationship index, the functions and ten procedures, both lifecycle gates (435 coverage and 440 retirement) and the menu row. Not compiled or executed. Not yet done: business services (7.2), discovery and reconciliation (7.3), relationship-triggered service / risk / continuity reviews, graphical topology.
"""
open(p, 'w', encoding='utf-8', newline='').write(s)
print('doc ok')
