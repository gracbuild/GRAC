-- =====================================================================
-- 441  Business services: service register, consumers, supporting assets /
--      services / suppliers / contracts, activation and retirement rules,
--      continuity conflicts and service impact (Asset & Contract
--      Management, Phase 7 increment 2)
--
-- REQUEST
-- -------
--   BRD v1.7 5.5 "Business Service Mapping": a governed business-service
--   hierarchy mapped to the applications, data, infrastructure, facilities,
--   suppliers and contracts it needs. Service fields: ID / name, type
--   (business, customer-facing, technical, shared, supporting), description
--   / purpose, business / service owner, legal entity / units (consumers and
--   accountable organization), criticality / CIA, RTO / RPO / MTPD, service
--   hours / SLA, data / privacy classification, supporting assets /
--   services (effective-dated mappings), supplier / contract dependencies,
--   status Draft, Design, Active, Degraded, Suspended, Retiring, Retired,
--   review date. 5.5.1: a service may depend on several child services and
--   assets, each mapping keeping role, criticality, effective dates and
--   source; service impact shows directly and indirectly affected services,
--   processes, locations, customers, owners and continuity objectives;
--   criticality and RTO / RPO conflicts with supporting assets create
--   validation warnings; no activation without an owner and the minimum
--   supporting relationships; retirement needs dependency migration,
--   consumer review, contract assessment and approval. 5.5.2 acceptance
--   criteria (topology history kept). Plan: docs/asset-contract-management.md
--   (Phase 7.2, D88-D96).
--
-- WHAT THIS DOES
-- --------------
--   1. business_service (per organization) with history and consumers
--      (departments, business functions, locations or named external
--      customers); business_service_setting (minimum supporting
--      relationships for activation, approval of retirement).
--   2. Relationships (440): Supports Service is activated -- assets,
--      applications, processes, vendors, contracts and child services
--      support a service; contracts become relationship endpoints; every
--      relationship gets an optional role ("primary database").
--      Re-issued: fn_asset_ci_catalog (+ services, contracts),
--      sp_asset_relationship_save / _action / _history_add /
--      sp_asset_relationships / _get (+ role), sp_asset_ci_impact (+ the
--      affected services with owners, objectives and consumers).
--   3. Status rules: activation needs a business owner and the minimum
--      supporting relationships; Retiring -> Retired needs no remaining
--      critical dependants, a consumer review and a contract assessment, and
--      another person approval (where configured); a retired service ends
--      its supporting relationships.
--   4. Conflicts (fn_business_service_conflicts): supporting item rated less
--      critical than the service, supporting asset RPO longer than the
--      service RPO, child service with a longer RTO / RPO or lower
--      criticality, supporting item no longer in use, disputed mapping,
--      active service without owner or support, review date passed.
--   5. Business Services screen (menu row, readers / writers).
--
-- NOT DONE HERE: tasks raised from conflicts (warnings only); review-date
--   reminders through the 437 profiles; service dashboards and exports
--   (Phase 8); comparison of the asset recovery tier (an option list)
--   with the service RTO; CIA rating scales other than 1-5.
--
-- ERROR NUMBERS: 54730-54759
--   54730 organization not found         54731 service not found
--   54732 changed by someone else        54733 code / name required
--   54734 code or name already used      54735 service type
--   54736 owner / manager                54737 accountable department
--   54738 criticality                    54739 CIA rating
--   54740 RTO / RPO / MTPD               54741 status change not allowed
--   54742 note required                  54743 activation needs an owner
--   54744 activation needs support       54745 retirement blocked (dependants)
--   54746 retirement review notes        54747 no pending retirement / one pending
--   54748 segregation of duties          54749 consumer
--   54750 setting                        54751 a retired service is history
--
-- ALSO EDITED: API (AssetConfig service / controller / models), Web proxy,
--   PracticeScreen + Manage.cshtml + appsettings, business-services.cshtml /
--   .js (new), asset-relationships.cshtml / .js (role, contract and service
--   kinds), 274 (menu), docs.
-- DEPENDS ON: 434, 440.
-- Rollback: 441_business_services_rollback.sql
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.sp_asset_relationship_save','P') IS NULL
   OR OBJECT_ID('grac_practice.asset_relationship','U') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_relationship_edges') IS NULL
   OR OBJECT_ID('grac_practice.asset_contract','U') IS NULL
   OR COL_LENGTH('grac_practice.asset_contract','current_version_id') IS NULL
   OR COL_LENGTH('grac_practice.asset_contract_version','contract_owner_id') IS NULL
BEGIN
    RAISERROR('ABORT (441): run 434 and 440 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Business services (5.5)
-- =====================================================================
IF OBJECT_ID('grac_practice.business_service','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.business_service (
        service_id                  BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_bsvc PRIMARY KEY,
        organization_id             BIGINT         NOT NULL
            CONSTRAINT fk_pm_bsvc_org REFERENCES grac_practice.organization(organization_id),
        service_code                NVARCHAR(40)   NOT NULL,
        service_name                NVARCHAR(200)  NOT NULL,
        service_type                NVARCHAR(16)   NOT NULL
            CONSTRAINT ck_pm_bsvc_type CHECK (service_type IN (N'BUSINESS', N'CUSTOMER_FACING', N'TECHNICAL', N'SHARED', N'SUPPORTING')),
        description                 NVARCHAR(2000) NULL,
        customer_outcome            NVARCHAR(1000) NULL,
        business_owner_employee_id  BIGINT         NULL
            CONSTRAINT fk_pm_bsvc_owner REFERENCES grac_practice.organization_employee(employee_id),
        service_manager_employee_id BIGINT         NULL
            CONSTRAINT fk_pm_bsvc_manager REFERENCES grac_practice.organization_employee(employee_id),
        accountable_department_id   BIGINT         NULL
            CONSTRAINT fk_pm_bsvc_dept REFERENCES grac_practice.organization_department(department_id),
        criticality_id              INT            NULL
            CONSTRAINT fk_pm_bsvc_crit REFERENCES grac_practice.criticality_master(criticality_id),
        confidentiality_rating      TINYINT        NULL CONSTRAINT ck_pm_bsvc_c CHECK (confidentiality_rating BETWEEN 1 AND 5),
        integrity_rating            TINYINT        NULL CONSTRAINT ck_pm_bsvc_i CHECK (integrity_rating BETWEEN 1 AND 5),
        availability_rating         TINYINT        NULL CONSTRAINT ck_pm_bsvc_a CHECK (availability_rating BETWEEN 1 AND 5),
        rto_hours                   DECIMAL(9, 2)  NULL,
        rpo_hours                   DECIMAL(9, 2)  NULL,
        mtpd_hours                  DECIMAL(9, 2)  NULL,
        service_hours               NVARCHAR(200)  NULL,
        sla_text                    NVARCHAR(1000) NULL,
        data_classification         NVARCHAR(100)  NULL,
        privacy_classification      NVARCHAR(100)  NULL,
        status                      NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_bsvc_status CHECK (status IN (N'DRAFT', N'DESIGN', N'ACTIVE', N'DEGRADED', N'SUSPENDED', N'RETIRING', N'RETIRED')),
        review_date                 DATE           NULL,
        version_no                  INT            NOT NULL CONSTRAINT df_pm_bsvc_vno DEFAULT 1,
        status_note                 NVARCHAR(1000) NULL,
        pending_retirement          BIT            NOT NULL CONSTRAINT df_pm_bsvc_pret DEFAULT 0,
        consumer_review_note        NVARCHAR(1000) NULL,
        contract_assessment_note    NVARCHAR(1000) NULL,
        pending_by                  NVARCHAR(100)  NULL,
        pending_by_employee_id      BIGINT         NULL,
        pending_dt                  DATETIME2      NULL,
        retired_dt                  DATETIME2      NULL,
        entered_by                  NVARCHAR(100)  NOT NULL CONSTRAINT df_pm_bsvc_eby DEFAULT N'system',
        entered_dt                  DATETIME2      NOT NULL CONSTRAINT df_pm_bsvc_edt DEFAULT SYSUTCDATETIME(),
        updated_by                  NVARCHAR(100)  NULL,
        updated_dt                  DATETIME2      NULL,
        record_version              ROWVERSION     NOT NULL,
        CONSTRAINT uq_pm_bsvc_code UNIQUE (organization_id, service_code),
        CONSTRAINT uq_pm_bsvc_name UNIQUE (organization_id, service_name),
        CONSTRAINT ck_pm_bsvc_obj CHECK ((rto_hours IS NULL OR rto_hours >= 0) AND (rpo_hours IS NULL OR rpo_hours >= 0)
                                         AND (mtpd_hours IS NULL OR mtpd_hours >= 0)
                                         AND (rto_hours IS NULL OR mtpd_hours IS NULL OR rto_hours <= mtpd_hours))
    );
    CREATE INDEX ix_pm_bsvc_org ON grac_practice.business_service(organization_id, status);
    PRINT '441: business_service created.';
END
GO

IF OBJECT_ID('grac_practice.business_service_consumer','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.business_service_consumer (
        consumer_id      BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_bsvc_cons PRIMARY KEY,
        service_id       BIGINT        NOT NULL
            CONSTRAINT fk_pm_bsvc_cons_svc REFERENCES grac_practice.business_service(service_id),
        consumer_kind    NVARCHAR(18)  NOT NULL
            CONSTRAINT ck_pm_bsvc_cons_kind CHECK (consumer_kind IN (N'DEPARTMENT', N'BUSINESS_FUNCTION', N'LOCATION', N'EXTERNAL')),
        consumer_ref_id  BIGINT        NULL,          -- department / business function / location id
        consumer_name    NVARCHAR(200) NULL,          -- external customer or partner
        note             NVARCHAR(400) NULL,
        entered_by       NVARCHAR(100) NOT NULL CONSTRAINT df_pm_bsvc_cons_eby DEFAULT N'system',
        entered_dt       DATETIME2     NOT NULL CONSTRAINT df_pm_bsvc_cons_edt DEFAULT SYSUTCDATETIME(),
        CONSTRAINT ck_pm_bsvc_cons_ref CHECK ((consumer_kind = N'EXTERNAL' AND consumer_name IS NOT NULL)
                                              OR (consumer_kind <> N'EXTERNAL' AND consumer_ref_id IS NOT NULL))
    );
    CREATE INDEX ix_pm_bsvc_cons_svc ON grac_practice.business_service_consumer(service_id);
    PRINT '441: business_service_consumer created.';
END
GO

IF OBJECT_ID('grac_practice.business_service_history','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.business_service_history (
        history_id        BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_bsvc_hist PRIMARY KEY,
        service_id        BIGINT         NOT NULL
            CONSTRAINT fk_pm_bsvc_hist_svc REFERENCES grac_practice.business_service(service_id),
        organization_id   BIGINT         NOT NULL,
        version_no        INT            NOT NULL,
        action_code       NVARCHAR(20)   NOT NULL,
        status            NVARCHAR(10)   NOT NULL,
        snapshot_json     NVARCHAR(MAX)  NOT NULL,
        note              NVARCHAR(1000) NULL,
        actor             NVARCHAR(100)  NOT NULL,
        actor_employee_id BIGINT         NULL,
        entered_dt        DATETIME2      NOT NULL CONSTRAINT df_pm_bsvc_hist_edt DEFAULT SYSUTCDATETIME()
    );
    CREATE INDEX ix_pm_bsvc_hist_svc ON grac_practice.business_service_history(service_id, history_id);
    PRINT '441: business_service_history created.';
END
GO

IF OBJECT_ID('grac_practice.business_service_setting','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.business_service_setting (
        organization_id              BIGINT        NOT NULL CONSTRAINT pk_pm_bsvc_set PRIMARY KEY
            CONSTRAINT fk_pm_bsvc_set_org REFERENCES grac_practice.organization(organization_id),
        min_supporting_relationships INT           NOT NULL
            CONSTRAINT ck_pm_bsvc_set_min CHECK (min_supporting_relationships BETWEEN 0 AND 50),
        retirement_approval_required BIT           NOT NULL,
        updated_by                   NVARCHAR(100) NOT NULL,
        updated_dt                   DATETIME2     NOT NULL CONSTRAINT df_pm_bsvc_set_udt DEFAULT SYSUTCDATETIME()
    );
    PRINT '441: business_service_setting created.';
END
GO

-- =====================================================================
-- 2. Relationships (440): contracts as endpoints, a role per mapping,
--    Supports Service active
-- =====================================================================
IF COL_LENGTH('grac_practice.asset_relationship', 'service_role') IS NULL
    ALTER TABLE grac_practice.asset_relationship ADD service_role NVARCHAR(100) NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_asset_rel_skind' AND definition LIKE '%CONTRACT%')
BEGIN
    ALTER TABLE grac_practice.asset_relationship DROP CONSTRAINT ck_pm_asset_rel_skind;
    ALTER TABLE grac_practice.asset_relationship WITH CHECK ADD CONSTRAINT ck_pm_asset_rel_skind
        CHECK (source_kind IN (N'ASSET', N'APPLICATION', N'PROCESS', N'VENDOR', N'LOCATION', N'SERVICE', N'CONTRACT'));
    ALTER TABLE grac_practice.asset_relationship DROP CONSTRAINT ck_pm_asset_rel_tkind;
    ALTER TABLE grac_practice.asset_relationship WITH CHECK ADD CONSTRAINT ck_pm_asset_rel_tkind
        CHECK (target_kind IN (N'ASSET', N'APPLICATION', N'PROCESS', N'VENDOR', N'LOCATION', N'SERVICE', N'CONTRACT'));
    PRINT '441: relationship kinds widened (CONTRACT).';
END
GO

UPDATE grac_practice.asset_relationship_type
   SET is_active = 1, inactive_reason = NULL, source_kinds = N'ASSET,APPLICATION,PROCESS,VENDOR,CONTRACT,SERVICE',
       description = N'Asset, application, process, supplier, contract or child service contributes to a business service.'
 WHERE type_code = N'SUPPORTS_SERVICE' AND (is_active = 0 OR source_kinds <> N'ASSET,APPLICATION,PROCESS,VENDOR,CONTRACT,SERVICE');
PRINT CONCAT('441: Supports Service activated: ', @@ROWCOUNT);
GO
