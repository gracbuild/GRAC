import sys
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w446/new'
P=R+'/docs/asset-contract-management.md'
def edit(old, new, count=1):
    s=open(P).read()
    assert s.count(old)==count, (old[:80], s.count(old))
    open(P,'w').write(s.replace(old,new))

edit("""Phase 7.4c asset split -- resulting Draft records, allocation of items and field values, approval, execution and recovery (`445`).""",
"""Phase 7.4c asset split -- resulting Draft records, allocation of items and field values, approval, execution and recovery (`445`), Phase 8.1 Asset Value per asset -- automatic CIA valuation with validation status and history, method override, controlled recalculation with impact analysis (`446`).""")

edit("""| 8 | CIA valuation & risk profiles, privacy, dashboards, report catalogue, exports | | 4-7 |
""", """| 8.1 **(done)** | Asset Value per asset (5.1.18, 5.1.18.5.3-5.1.18.5.9): score, category, band, method and configuration version stored per asset with a validation status (Not rated / Incomplete / Invalid / Valid) and append-only history; calculated on every save that changes the ratings or method and by the scheduler for ratings changed elsewhere; a new configuration version never changes stored values by itself -- impact analysis (affected assets, category moves, linked risks) and a controlled recalculation run with a reason; single-asset recalculation; asset-level method override (enabled in the configuration, approver, reason); Valuation tab on the Asset Register, Recalculation view on Asset Valuation | 446 | 7 |
| 8.2-8.5 | CIA / criticality consistency rules and risk profiles (19.7, 5.1.18.3), privacy, governance metrics and dashboards, report catalogue, exports | | 8.1 |
""")

edit("""| D131 | **Not in 7.4c**: allocation of history (lifecycle, custody, attestations, results, renewals, notifications); creating the resulting records inside the split; bulk splits. | BRD 19.4. | Yes. |
""", """| D131 | **Not in 7.4c**: allocation of history (lifecycle, custody, attestations, results, renewals, notifications); creating the resulting records inside the split; bulk splits. | BRD 19.4. | Yes. |
| D132 | **Stored Asset Value** (446): one current row per asset (`asset_valuation_result`) plus append-only history. The row keeps the valuation configuration id and version used -- one 422 configuration holds the CIA scale, method, bands and criticality scale, so that one id is "the CIA scale, method, band and criticality version" of 5.1.18.5.8. Only a VALID calculation keeps a score and category; Incomplete (a rating missing), Invalid (a rating not on the Active scale, weights not totalling 100 for a Weighted Average override, no band covering the score, no Active configuration) and Not rated (no rating) keep none and show the reason. Merged-away assets have no Asset Value. | BRD 5.1.18.5.7 "shall not silently retain an invalid result", 5.1.18.5.8. | Yes. |
| D133 | **Method override**: the Asset Valuation Method field of the asset holds the override. A value that differs from the configured method is an override; it applies only while the Active configuration permits overrides (otherwise the configured method is used and the reason is shown). It is set or removed only from the Valuation tab (asset-register APPROVE = the authorized role; reason required, audited); the asset form refuses a changed method that differs from the configured one, but may clear it. `fn_asset_value_calc_method` is the 422 formula with an explicit method; `fn_asset_value_calc` now calls it (one formula). | BRD 5.1.18.5.3 "disabled by default and requires an authorized role and reason when enabled". | Yes. |
| D134 | **No template default for the method**: a new asset does not take a template default for Asset Valuation Method -- the configuration supplies the method. CIA (and criticality) defaults per asset type stay template field defaults, applied to new assets only, so changing them never rewrites existing ratings. Inheritance from category / subcategory templates is not built. | BRD 5.1.18.5.6. | Yes. |
| D135 | **Automatic vs controlled**: a save that changes the ratings or method, or the first calculation, recalculates at once with the Active configuration (source Asset form). A newly activated configuration version alone never changes stored values: such assets show "a newer configuration version is Active" until a controlled recalculation moves them. A save of other fields does not move them. | BRD 5.1.18.5.7 "controlled recalculation according to effective-date and migration rules"; 5.1.18.5.9 "existing assets are not silently changed". | Yes. |
| D136 | **Controlled recalculation run** (Asset Valuation -> Recalculation): impact analysis lists every asset whose stored value differs from what the Active configuration gives (why, stored vs new, category moves, linked risks through `risk_dependency_map`, not-valid-after count); the run needs asset-valuation-config APPROVE and a reason, is checked against the affected count shown (409 if it moved), runs one at a time per organization, and records each asset in its history with the run id. Old history rows are never changed. | BRD 5.1.18.5.8 "impact analysis for affected assets, risks..."; "historical calculations remain unchanged". | Yes. |
| D137 | **Ratings changed outside the form** (merge field choices, split copies, discovery precedence updates) are picked up by the existing scheduler (TaskNotificationWorker -> `sp_asset_scheduler_run` -> `sp_asset_valuation_sync`, source Scheduler) rather than by re-issuing those procedures; until then the asset shows "ratings changed". A single asset can also be recalculated at once from its Valuation tab (asset-register EDIT; a reason when it moves to a newer configuration version). | Keeps 442 / 444 / 445 unchanged; same worker as 437 / 438. | Yes. |
| D138 | **Asset Value Score / Category** on the form are the stored VALID result (read-only SYSTEM fields, through `fn_asset_stored_values`). | BRD 5.1.18.5.7 "read-only to normal users". | Yes. |
| D139 | **Error numbers 53000-53009** (free range; 529xx is used by 444 / 445). | -- | Yes. |
| D140 | **Risk scoring** is not changed here: the stored Asset Value is what 8.2 hands to the risk module (5.1.18.3) together with the CIA / criticality consistency rules (19.7). | BRD 5.1.18.3, 19.7. | Yes. |
| D141 | **Not in 8.1**: per-scope configurations (entity / category / asset type -- one per organization, as 422); approval of an individual override beyond the approver role; recalculation scheduled for a future effective date (activation is immediate in 422). | BRD 5.1.18.5.3 scope, 5.1.18.5.8. | Yes. |
""")

edit("""Proxy: as merges. Errors `52900-52917`; 52915 resulting records 1-5, 52916 resulting record not a new Draft, 52917 allocation invalid.
""", """Proxy: as merges. Errors `52900-52917`; 52915 resulting records 1-5, 52916 resulting record not a new Draft, 52917 allocation invalid.

### Asset Value per asset (446)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `register/{id}/valuation?organizationId=` | `{current, history}` -- stored value, what the Active configuration gives now, state (CURRENT / NOT_CALCULATED / VALUES_CHANGED / CONFIG_CHANGED / CONFIG_AND_VALUES), treatment guidance; last 100 calculations | `sp_asset_valuation_get` (`fn_asset_valuation_state`) |
| POST | `register/{id}/valuation/recalculate` | `{organizationId, reason?}` -> RECALCULATED / UNCHANGED (reason required when the asset moves to a newer configuration version) | `sp_asset_valuation_recalculate` (-> `sp_asset_valuation_apply`) |
| POST | `register/{id}/valuation/method` | `{organizationId, method?: MAXIMUM \\| WEIGHTED_AVERAGE \\| SUMMATION, reason}` -- null or the configured method removes the override | `sp_asset_valuation_method_set` |
| GET | `valuation/recalculation?organizationId=` | `{summary, moves, assets (first 500), runs}` -- impact analysis of the Active version | `sp_asset_valuation_recalc_preview` |
| POST | `valuation/recalculation` | `{organizationId, reason, expectedAffected}` -> run id, COMPLETED / COMPLETED_WITH_ERRORS | `sp_asset_valuation_recalc_run` |

The asset form save (`sp_asset_register_save`, re-issued) recalculates after saving and returns a WARNING when the result is incomplete, invalid or waiting for a recalculation run; the scheduler (`sp_asset_scheduler_run`, re-issued) runs `sp_asset_valuation_sync`. Proxy: GETs asset-register VIEW / asset-valuation-config VIEW; recalculate asset-register EDIT; method override asset-register APPROVE; run asset-valuation-config APPROVE (10-minute proxy timeout). Errors `53000-53007`: 53000 asset / 53007 organization -> 404; 53005 affected assets changed since the preview / 53006 run in progress -> 409; 53001 no Active configuration, 53002 invalid method, 53003 override not enabled, 53004 reason required -> 400.
""")

edit("""| Web | `Partials/asset-discovery.cshtml`, `js/AssetConfig/asset-discovery.js` | Splits tab and split window (results, allocation, impact, blockers, outcomes, approvals); event actions shared with merges. |
""", """| Web | `Partials/asset-discovery.cshtml`, `js/AssetConfig/asset-discovery.js` | Splits tab and split window (results, allocation, impact, blockers, outcomes, approvals); event actions shared with merges. |

### Phase 8.1 files (446)
| Layer | File | Change |
|---|---|---|
| DB | `database/446_asset_valuation.sql` (+ rollback restoring the 422, 435, 438 and 439 bodies) | `asset_valuation_result`, `asset_valuation_history`, `asset_valuation_recalc_run`; `fn_asset_value_calc_method`, `fn_asset_valuation_eval`, `fn_asset_valuation_state`, `fn_asset_valuation_risk_links`; `sp_asset_valuation_apply / _sync / _method_set / _recalculate / _recalc_preview / _recalc_run / _get`. Re-issued: `fn_asset_value_calc` (422), `sp_asset_register_save` (435), `sp_asset_scheduler_run` (438), `fn_asset_stored_values` (439). |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 5 routes; 3 request records; 404 / 409 mapping. |
| Web | `Controllers/AssetConfigController.cs` | Valuation permissions; run timeout. |
| Web | `Partials/asset-register.cshtml`, `js/AssetConfig/asset-register.js` | Valuation tab (stored vs now, history, Recalculate, Override method dialog). |
| Web | `Partials/asset-valuation-config.cshtml`, `js/AssetConfig/asset-valuation-config.js` | Recalculation view (impact summary, category moves, affected assets, runs, Run recalculation); activation message points to it. |
""")

s=open(P).read()
tail="""Not compiled or executed. Phase 7 is complete; next: Phase 8 (CIA valuation and risk profiles, privacy, dashboards, report catalogue, exports).
"""
assert s.endswith(tail)
s += """
446 got the same sweep (clean -- three comment apostrophes reworded), the semicolon-before-ELSE scan (one IF / ELSE of the apply procedure wrapped in BEGIN / END before delivery), a declared-variable scan of every new batch, the aggregate rule (the rating pivot aggregates inner columns only), the parameter check of every internal EXEC against its signature (`sp_asset_valuation_apply`, `sp_asset_valuation_sync`), a diff of the three re-issued bodies against their 435 / 438 / 439 sources (only lines marked `-- 446` added) and of the rollback bodies (byte-identical to the sources), the C#-to-procedure parameter and string-size cross-check for the 5 bound procedures, the JS-to-alias and HTML-id / duplicate-id checks on both screens, `node --check` on both scripts, brace / parenthesis / bracket balance of the four edited C# files, the ASCII check and a re-run of every patch script on the base files reproducing the delivered copies. Its verification block checks the tables, functions and procedures, the four re-issues, that the 422 calculator and the method function agree for every Active configuration, and that the state function runs for every organization. Not compiled or executed. Next: 8.2 (CIA / criticality consistency rules and risk profiles).
"""
open(P,'w').write(s)
print('doc patched')
