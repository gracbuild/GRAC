import sys
R = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w453/new'
W = R + '/src/PracticeManagement.Web/'
def edit(path, old, new, count=1):
    p = W + path
    s = open(p).read(); assert s.count(old) == count, (path, old[:80], s.count(old)); open(p, 'w').write(s.replace(old, new))

V = 'Views/Practice/Partials/asset-reports.cshtml'
J = 'wwwroot/js/AssetConfig/asset-reports.js'

# ================================================================ partial
edit(V, """    "Settings" (EDIT) sets per report whether it is enabled, a higher
    classification and the export policy.
""", """    "Settings" (EDIT) sets per report whether it is enabled, a higher
    classification and the export policy.

    453 (BRD 13.4 schedule / retention / distribution, 13.4.1 delivery):
    "Schedules" lists the report schedules (VIEW) and, with EDIT, creates
    and changes them -- report, fixed filters (a window of the last N days
    for date-range reports), frequency, how long delivered files are kept
    and the distribution list (employees and roles) -- runs one now and
    shows every delivery with the result per recipient (delivered, skipped
    with the reason the authorization check gave at delivery time, failed).
    "My deliveries" lists the files delivered to the user; Download checks
    again, records the download as an export and writes the CSV with the
    same watermark heading.
""")
edit(V, """            <button role="tab" data-arp-main="EXPORTS" aria-selected="false">Export history</button>
""", """            <button role="tab" data-arp-main="EXPORTS" aria-selected="false">Export history</button>
            <button role="tab" data-arp-main="MINE" aria-selected="false">My deliveries</button>
            <button role="tab" data-arp-main="SCHEDULES" aria-selected="false">Schedules</button>
""")
edit(V, """        @* ---------------- settings ---------------- *@""", """        @* ---------------- my deliveries (453) ---------------- *@
        <div class="pm-tab-panel" data-arp-mainpanel="MINE" hidden>
            <p class="arp-note">Reports delivered to you by a schedule. A file is kept for the period its schedule sets; downloading checks your permission again and is recorded like an export.</p>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Delivered</th><th>Report</th><th>Classification</th><th>Rows</th><th>Available until</th><th>Downloads</th><th>Filters</th><th></th></tr></thead>
                    <tbody id="arpMine"></tbody>
                </table>
            </div>
            <div id="arpMinePager"></div>
        </div>

        @* ---------------- schedules (453) ---------------- *@
        <div class="pm-tab-panel" data-arp-mainpanel="SCHEDULES" hidden>
            <p class="arp-note">Each schedule delivers one report to its distribution list on its days. Every recipient is checked when the report is delivered: an active employee of the organization with VIEW on Asset Reports and on the screen the report is based on, and Asset Reports APPROVE when the export policy needs an approver. Each recipient receives the rows their own permissions allow.</p>
            @if (arpCanEdit)
            {
                <div class="pm-toolbar">
                    <button class="pm-button primary" id="arpSchNew" type="button"><i class="fa-solid fa-plus"></i> New schedule</button>
                </div>
            }
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Schedule</th><th>Report</th><th>Frequency</th><th>Recipients</th><th>Next run</th><th>Last run</th><th>Active</th><th></th></tr></thead>
                    <tbody id="arpSchedules"></tbody>
                </table>
            </div>

            @if (arpCanEdit)
            {
                <div id="arpSchForm" class="arp-form" hidden>
                    <h3 class="arp-sub" id="arpSchFormTitle">New schedule</h3>
                    <div class="pm-toolbar">
                        <label class="arp-field"><span>Report</span><select id="arpSchReport"></select></label>
                        <label class="arp-field"><span>Name</span><input type="text" id="arpSchName" maxlength="160" /></label>
                        <label class="arp-field"><span>Frequency</span>
                            <select id="arpSchFrequency">
                                <option value="DAILY">Daily</option>
                                <option value="WEEKLY">Weekly</option>
                                <option value="MONTHLY">Monthly</option>
                            </select>
                        </label>
                        <label class="arp-field" id="arpSchDowField"><span>Weekday</span>
                            <select id="arpSchDow">
                                <option value="1">Monday</option><option value="2">Tuesday</option><option value="3">Wednesday</option>
                                <option value="4">Thursday</option><option value="5">Friday</option><option value="6">Saturday</option>
                                <option value="7">Sunday</option>
                            </select>
                        </label>
                        <label class="arp-field" id="arpSchDomField"><span>Day of month</span><input type="number" id="arpSchDom" min="1" max="28" step="1" /></label>
                        <label class="arp-field"><span>Keep files (days)</span><input type="number" id="arpSchRetention" min="1" max="3650" step="1" /></label>
                        <label class="arp-field"><span>Active</span><input type="checkbox" id="arpSchActive" /></label>
                    </div>
                    <div class="pm-toolbar">
                        <label class="arp-field" data-arp-sch-filter="SEARCH"><span>Search</span><input type="text" id="arpSchSearch" maxlength="200" /></label>
                        <label class="arp-field" data-arp-sch-filter="STATUS"><span id="arpSchStatusLabel">Status</span><select id="arpSchStatus"></select></label>
                        <label class="arp-field" data-arp-sch-filter="ASSET_TYPE"><span>Asset type</span><select id="arpSchAssetType"></select></label>
                        <label class="arp-field" data-arp-sch-filter="DAYS"><span>Next / last days</span><input type="number" id="arpSchDays" min="1" max="3650" step="1" /></label>
                        <label class="arp-field" data-arp-sch-filter="DATE_RANGE"><span id="arpSchWindowLabel">Last days</span><input type="number" id="arpSchWindow" min="1" max="3650" step="1" /></label>
                    </div>
                    <div class="pm-toolbar">
                        <select id="arpSchEmp" title="Employee"></select>
                        <button class="pm-button" type="button" id="arpSchAddEmp"><i class="fa-solid fa-user-plus"></i> Add employee</button>
                        <select id="arpSchRole" title="Role"></select>
                        <button class="pm-button" type="button" id="arpSchAddRole"><i class="fa-solid fa-users"></i> Add role</button>
                    </div>
                    <div class="arp-recipients" id="arpSchRecipients"></div>
                    <div class="pm-toolbar">
                        <button class="pm-button primary" type="button" id="arpSchSave"><i class="fa-solid fa-floppy-disk"></i> Save</button>
                        <button class="pm-button" type="button" id="arpSchCancel">Cancel</button>
                    </div>
                </div>
            }

            <div id="arpRunPanel" hidden>
                <h3 class="arp-sub" id="arpRunTitle">Deliveries</h3>
                <div class="pm-table-wrap">
                    <table>
                        <thead><tr><th>Started</th><th>Run</th><th>Status</th><th>Delivered</th><th>Skipped</th><th>Failed</th><th>Filters</th><th></th></tr></thead>
                        <tbody id="arpRuns"></tbody>
                    </table>
                </div>
                <div id="arpRunPager"></div>
                <h3 class="arp-sub" id="arpRunRecipientsTitle" hidden>Distribution result</h3>
                <div class="pm-table-wrap" id="arpRunRecipientsWrap" hidden>
                    <table>
                        <thead><tr><th>Recipient</th><th>Status</th><th>Reason</th><th>Rows</th><th>Delivered</th><th>Downloads</th><th>File</th></tr></thead>
                        <tbody id="arpRunRecipients"></tbody>
                    </table>
                </div>
            </div>
        </div>

        @* ---------------- settings ---------------- *@""")
edit(V, """    .arp-field { display: inline-flex; flex-direction: column; font-size: 11px; color: var(--fg-secondary); gap: 2px; }
""", """    .arp-field { display: inline-flex; flex-direction: column; font-size: 11px; color: var(--fg-secondary); gap: 2px; }
    .arp-sub { font-size: 13px; font-weight: 600; color: var(--fg-strong); margin: 16px 0 8px; }
    .arp-form { border-top: 1px solid var(--neutral-200); margin-top: 12px; padding-top: 4px; }
    .arp-recipients { display: flex; flex-wrap: wrap; gap: 6px; margin: 0 0 8px; }
    .arp-recipient { display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; border-radius: var(--radius-pill); background: var(--neutral-100); font-size: 12px; }
    .arp-st-delivered, .arp-st-completed { background: var(--success-100); color: var(--success-700); }
    .arp-st-skipped, .arp-st-partial, .arp-st-running, .arp-st-pending { background: var(--warning-50); color: var(--warning-700); }
    .arp-st-failed { background: var(--danger-100); color: var(--danger-700); }
""")

# ================================================================ script
edit(J, """// heading), reports/exports (history), reports/settings (EDIT).
""", """// heading), reports/exports (history), reports/settings (EDIT).
// 453: reports/schedules (list; POST create / change and .../run EDIT),
// reports/deliveries (+ /{id}/recipients: distribution results),
// reports/deliveries/mine and reports/deliveries/recipients/{id}/download
// (the caller delivered files; the download is recorded as an export).
""")
edit(J, """  const state = { organizationId: null, mainTab: "CATALOGUE", catalogue: null, reportCode: null, result: null,
                  pager: null, exportPager: null };
""", """  const state = { organizationId: null, mainTab: "CATALOGUE", catalogue: null, reportCode: null, result: null,
                  pager: null, exportPager: null,
                  minePager: null, runPager: null, schedules: null, editing: null, recipients: [], runScheduleId: null };   // 453
  const FREQ = { DAILY: "Daily", WEEKLY: "Weekly", MONTHLY: "Monthly" };
  const WEEKDAY = ["", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
""")
edit(J, """    state.exportPager = g ? g.attach({ hostId: "arpExportPager", onChange: refreshExports }) : null;
""", """    state.exportPager = g ? g.attach({ hostId: "arpExportPager", onChange: refreshExports }) : null;
    state.minePager = g ? g.attach({ hostId: "arpMinePager", onChange: refreshMine }) : null;   // 453
    state.runPager = g ? g.attach({ hostId: "arpRunPager", onChange: refreshRuns }) : null;
""")
edit(J, """    document.getElementById("arpSettings")?.addEventListener("click", ev => {""", """    // 453: my deliveries and schedules
    document.getElementById("arpMine").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-arp-download]");
      if (b) downloadDelivery(Number(b.dataset.arpDownload), b);
    });
    document.getElementById("arpSchedules").addEventListener("click", ev => {
      const e = ev.target.closest("button[data-arp-sch-edit]");
      if (e) { openScheduleForm(Number(e.dataset.arpSchEdit)); return; }
      const r = ev.target.closest("button[data-arp-sch-run]");
      if (r) { runScheduleNow(Number(r.dataset.arpSchRun), r); return; }
      const h = ev.target.closest("button[data-arp-sch-history]");
      if (h) { state.runScheduleId = Number(h.dataset.arpSchHistory); state.runPager?.reset(true); refreshRuns(); }
    });
    document.getElementById("arpRuns").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-arp-run]");
      if (b) showRunRecipients(Number(b.dataset.arpRun));
    });
    document.getElementById("arpSchNew")?.addEventListener("click", () => openScheduleForm(null));
    document.getElementById("arpSchCancel")?.addEventListener("click", closeScheduleForm);
    document.getElementById("arpSchSave")?.addEventListener("click", saveSchedule);
    document.getElementById("arpSchReport")?.addEventListener("change", () => renderScheduleFilters(null));
    document.getElementById("arpSchFrequency")?.addEventListener("change", renderScheduleDays);
    document.getElementById("arpSchAddEmp")?.addEventListener("click", () => addRecipient("EMPLOYEE", "arpSchEmp"));
    document.getElementById("arpSchAddRole")?.addEventListener("click", () => addRecipient("ROLE", "arpSchRole"));
    document.getElementById("arpSchRecipients")?.addEventListener("click", ev => {
      const b = ev.target.closest("button[data-arp-rcp-remove]");
      if (b) { state.recipients.splice(Number(b.dataset.arpRcpRemove), 1); renderRecipients(); }
    });
    document.getElementById("arpSettings")?.addEventListener("click", ev => {""")
edit(J, """    state.catalogue = null; state.result = null;
    hideMessage();
    [state.pager, state.exportPager].forEach(p => p?.reset(true));
""", """    state.catalogue = null; state.result = null;
    state.schedules = null; state.runScheduleId = null;   // 453
    hideMessage();
    [state.pager, state.exportPager, state.minePager, state.runPager].forEach(p => p?.reset(true));
""")
edit(J, """    else if (name === "SETTINGS") renderSettings();
  }
""", """    else if (name === "SETTINGS") renderSettings();
    else if (name === "MINE") await refreshMine();          // 453
    else if (name === "SCHEDULES") await loadSchedules();   // 453
  }
""")
# shared status options (report filter and schedule form)
edit(J, """    const status = document.getElementById("arpStatus");
    const options = r.statusOptions === "@ASSET_STATUS"
      ? ((state.catalogue && state.catalogue.assetStatuses) || []).map(s => [s.code, s.name])
      : String(r.statusOptions || "").split("|").filter(Boolean).map(x => x.split("="));
    status.innerHTML = `<option value="">${esc((r.statusLabel || "Status") + ": all")}</option>`
      + options.map(([v, l]) => `<option value="${esc(v)}">${esc(l)}</option>`).join("");
    const types = document.getElementById("arpAssetType");
    if (!types.options.length || types.dataset.org !== String(state.organizationId)) {
      types.innerHTML = `<option value="">All asset types</option>` + ((state.catalogue && state.catalogue.assetTypes) || [])
        .map(t => `<option value="${esc(t.assetTypeId)}">${esc(t.assetTypeName)}</option>`).join("");
      types.dataset.org = String(state.organizationId);
    }
""", """    fillStatus(document.getElementById("arpStatus"), r);
    const types = document.getElementById("arpAssetType");
    if (!types.options.length || types.dataset.org !== String(state.organizationId)) fillAssetTypes(types);
""")
edit(J, """  // The filters the report takes, as sent to the API and recorded with an export.""", """  // The status options of a report (its own list, or the asset lifecycle statuses) -- report filter and schedule form.
  function fillStatus(sel, r) {
    const options = r.statusOptions === "@ASSET_STATUS"
      ? ((state.catalogue && state.catalogue.assetStatuses) || []).map(s => [s.code, s.name])
      : String(r.statusOptions || "").split("|").filter(Boolean).map(x => x.split("="));
    sel.innerHTML = `<option value="">${esc((r.statusLabel || "Status") + ": all")}</option>`
      + options.map(([v, l]) => `<option value="${esc(v)}">${esc(l)}</option>`).join("");
  }
  function fillAssetTypes(sel) {
    sel.innerHTML = `<option value="">All asset types</option>` + ((state.catalogue && state.catalogue.assetTypes) || [])
      .map(t => `<option value="${esc(t.assetTypeId)}">${esc(t.assetTypeName)}</option>`).join("");
    sel.dataset.org = String(state.organizationId);
  }

  // The filters the report takes, as sent to the API and recorded with an export.""")
# shared CSV writer (export and delivered file)
edit(J, """      const d = res.data.data || {}, h = d.export || {}, cols = d.columns || [], rows = d.rows || [];
      // Text starting with = + - @ is prefixed with ' so a spreadsheet does not run it as a formula.
      const q = v => { let s = String(v ?? ""); if (typeof v === "string" && /^[=+\\-@\\t\\r]/.test(s)) s = "'" + s; return `"${s.replace(/"/g, '""')}"`; };
      const lines = [
        [`Classification: ${h.classification}`, "Handle and share this file according to its classification."].map(q).join(","),
        ["Report", `${h.reportName} (${h.reportCode})`].map(q).join(","), ["Report version", h.reportVersion].map(q).join(","),
        ["Organization", h.organizationName].map(q).join(","), ["Exported by", h.exportedBy].map(q).join(","),
        ["Exported at (UTC)", h.exportedDt].map(q).join(","), ["Export ID", h.exportId].map(q).join(","),
        ["Filters", filterText(h.filtersJson)].map(q).join(","), ["Rows", h.rowCount].map(q).join(","), "",
        cols.map(c => q(label(c))).join(",")
      ];
      rows.forEach(row => lines.push(cols.map(c => q(csvValue(row[c]))).join(",")));
      const blob = new Blob([lines.join("\\r\\n")], { type: "text/csv;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `${String(h.reportCode || r.reportCode).toLowerCase()}-${state.organizationId}-${String(h.exportedDt || "").substring(0, 10)}-${String(h.classification || "").toLowerCase()}.csv`;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      showMessage(`Exported ${rows.length} rows (export ${h.exportId}, ${h.classification}).`, "success");
    } finally { btn.disabled = false; }
  }
""", """      const d = res.data.data || {}, h = d.export || {}, rows = d.rows || [];
      writeCsv(h, d.columns || [], rows);
      showMessage(`Exported ${rows.length} rows (export ${h.exportId}, ${h.classification}).`, "success");
    } finally { btn.disabled = false; }
  }

  // The file: the recorded export heading (watermark), then the columns. A delivered file also states when it was
  // generated. Text starting with = + - @ is prefixed with ' so a spreadsheet does not run it as a formula.
  function writeCsv(h, cols, rows) {
    const q = v => { let s = String(v ?? ""); if (typeof v === "string" && /^[=+\\-@\\t\\r]/.test(s)) s = "'" + s; return `"${s.replace(/"/g, '""')}"`; };
    const lines = [
      [`Classification: ${h.classification}`, "Handle and share this file according to its classification."].map(q).join(","),
      ["Report", `${h.reportName} (${h.reportCode})`].map(q).join(","), ["Report version", h.reportVersion].map(q).join(","),
      ["Organization", h.organizationName].map(q).join(",")
    ];
    if (h.generatedDt) lines.push(["Generated at (UTC)", h.generatedDt].map(q).join(","));
    lines.push(["Exported by", h.exportedBy].map(q).join(","), ["Exported at (UTC)", h.exportedDt].map(q).join(","),
      ["Export ID", h.exportId].map(q).join(","), ["Filters", filterText(h.filtersJson)].map(q).join(","),
      ["Rows", h.rowCount].map(q).join(","), "", cols.map(c => q(label(c))).join(","));
    rows.forEach(row => lines.push(cols.map(c => q(csvValue(row[c]))).join(",")));
    const blob = new Blob([lines.join("\\r\\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${String(h.reportCode || "report").toLowerCase()}-${state.organizationId}-${String(h.exportedDt || "").substring(0, 10)}-${String(h.classification || "").toLowerCase()}.csv`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
""")
edit(J, """  // ------------------------------------------------------------------ settings
""", """  // ------------------------------------------------------------------ my deliveries (453)
  async function refreshMine() {
    const body = document.getElementById("arpMine");
    if (!state.organizationId) { body.innerHTML = empty(8, "Select an organization."); state.minePager?.clear(); return; }
    body.innerHTML = empty(8, "Loading...");
    const qs = new URLSearchParams({ organizationId: state.organizationId,
      pageNumber: state.minePager ? state.minePager.page() : 1, pageSize: state.minePager ? state.minePager.size() : 25 });
    const res = await api("GET", `/deliveries/mine?${qs}`);
    if (!res.ok) { body.innerHTML = empty(8, res.error); state.minePager?.clear(); return; }
    const d = res.data.data || {}, rows = d.rows || [];
    state.minePager?.setTotal(d.totalRows, rows.length);
    body.innerHTML = rows.map(x => `
      <tr><td>${esc(dateTime(x.deliveredDt))}</td><td>${esc(x.reportName)}<div class="arp-note">${esc(x.scheduleName)} &middot; version ${esc(x.reportVersion)}</div></td>
          <td>${clsChip(x.classification)}</td><td>${esc(x.rowCount)}</td>
          <td>${x.isAvailable ? esc(dateTime(x.availableUntilDt)) : "Removed (retention)"}</td><td>${esc(x.downloadCount)}</td>
          <td>${esc(filterText(x.filtersJson))}</td>
          <td>${x.isAvailable ? `<button class="pm-button" type="button" data-arp-download="${esc(x.deliveryRecipientId)}"><i class="fa-solid fa-file-csv"></i> Download</button>` : ""}</td></tr>`).join("")
      || empty(8, "No report has been delivered to you in this organization.");
  }

  async function downloadDelivery(id, btn) {
    btn.disabled = true;
    hideMessage();
    try {
      const res = await api("POST", `/deliveries/recipients/${id}/download`, { organizationId: state.organizationId });
      if (!res.ok) { showMessage(res.error, "error"); return; }
      const d = res.data.data || {}, h = d.export || {}, rows = d.rows || [];
      writeCsv(h, d.columns || [], rows);
      showMessage(`Downloaded ${rows.length} rows (export ${h.exportId}, ${h.classification}).`, "success");
      await refreshMine();
    } finally { btn.disabled = false; }
  }

  // ------------------------------------------------------------------ schedules (453)
  async function loadSchedules() {
    const body = document.getElementById("arpSchedules");
    if (!state.organizationId) { body.innerHTML = empty(8, "Select an organization."); return; }
    body.innerHTML = empty(8, "Loading...");
    const res = await api("GET", `/schedules?${new URLSearchParams({ organizationId: state.organizationId })}`);
    if (!res.ok) { body.innerHTML = empty(8, res.error); return; }
    state.schedules = res.data.data || { schedules: [], recipients: [], employees: [], roles: [] };
    renderSchedules();
    if (state.runScheduleId) await refreshRuns();
  }

  function frequencyText(s) {
    return s.frequency === "WEEKLY" ? `Weekly, ${WEEKDAY[s.dayOfWeek] || ""}` : s.frequency === "MONTHLY" ? `Monthly, day ${s.dayOfMonth}` : FREQ[s.frequency] || s.frequency;
  }

  function renderSchedules() {
    const body = document.getElementById("arpSchedules");
    const list = (state.schedules && state.schedules.schedules) || [];
    body.innerHTML = list.map(s => `
      <tr><td>${esc(s.scheduleName)}<div class="arp-note">Files kept ${esc(s.retentionDays)} days</div></td>
          <td>${esc(s.reportName)}<div class="arp-note">${esc(s.familyName)}</div></td><td>${esc(frequencyText(s))}</td>
          <td>${esc(s.recipients || "")}</td><td>${esc(s.isActive ? date(s.nextRunDate) : "--")}</td>
          <td>${s.lastStatus ? `${stChip(s.lastStatus)}<div class="arp-note">${esc(dateTime(s.lastRunDt))}: ${esc(s.lastDelivered)} delivered, ${esc(s.lastSkipped)} skipped, ${esc(s.lastFailed)} failed</div>` : "--"}</td>
          <td>${s.isActive ? "Yes" : "No"}</td>
          <td>${CAN_EDIT ? `<button class="pm-button" type="button" data-arp-sch-edit="${esc(s.scheduleId)}">Edit</button>
                            <button class="pm-button" type="button" data-arp-sch-run="${esc(s.scheduleId)}"><i class="fa-solid fa-play"></i> Run now</button>` : ""}
              <button class="pm-button" type="button" data-arp-sch-history="${esc(s.scheduleId)}">Deliveries</button></td></tr>`).join("")
      || empty(8, "No schedule for the reports you may view.");
  }

  function openScheduleForm(id) {
    const form = document.getElementById("arpSchForm");
    if (!form || !state.schedules) return;
    const s = id ? (state.schedules.schedules || []).find(x => x.scheduleId === id) : null;
    state.editing = s;
    document.getElementById("arpSchFormTitle").textContent = s ? `Edit schedule: ${s.scheduleName}` : "New schedule";
    const sel = document.getElementById("arpSchReport");
    sel.innerHTML = reports().filter(r => r.isAvailable && r.isEnabled)
      .map(r => `<option value="${esc(r.reportCode)}">${esc(r.familyName)} - ${esc(r.reportName)}</option>`).join("");
    if (s) sel.value = s.reportCode;
    sel.disabled = !!s;   // the report of a schedule is fixed
    document.getElementById("arpSchName").value = s ? s.scheduleName : "";
    document.getElementById("arpSchFrequency").value = s ? s.frequency : "WEEKLY";
    document.getElementById("arpSchDow").value = String(s && s.dayOfWeek ? s.dayOfWeek : 1);
    document.getElementById("arpSchDom").value = s && s.dayOfMonth ? s.dayOfMonth : 1;
    document.getElementById("arpSchRetention").value = s ? s.retentionDays : 90;
    document.getElementById("arpSchActive").checked = s ? !!s.isActive : true;
    document.getElementById("arpSchEmp").innerHTML = (state.schedules.employees || [])
      .map(e => `<option value="${esc(e.employeeId)}">${esc(e.employeeName)}${e.email ? " (" + esc(e.email) + ")" : ""}</option>`).join("");
    document.getElementById("arpSchRole").innerHTML = (state.schedules.roles || [])
      .map(r => `<option value="${esc(r.roleId)}">${esc(r.roleName)}</option>`).join("");
    state.recipients = s ? (state.schedules.recipients || []).filter(r => r.scheduleId === s.scheduleId)
      .map(r => ({ kind: r.recipientKind, id: r.recipientKind === "ROLE" ? r.roleId : r.employeeId, name: r.name })) : [];
    renderScheduleFilters(s);
    renderScheduleDays();
    renderRecipients();
    form.hidden = false;
    form.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function closeScheduleForm() {
    const form = document.getElementById("arpSchForm");
    if (form) form.hidden = true;
    state.editing = null;
  }

  // The filters of the chosen report; a date-range report takes a window of the last N days instead of fixed dates.
  function renderScheduleFilters(s) {
    const r = report(val("arpSchReport"));
    const keys = r ? String(r.filterKeys || "").split(",") : [];
    document.querySelectorAll("[data-arp-sch-filter]").forEach(el => { el.hidden = !keys.includes(el.dataset.arpSchFilter); });
    if (!r) return;
    fillStatus(document.getElementById("arpSchStatus"), r);
    fillAssetTypes(document.getElementById("arpSchAssetType"));
    document.getElementById("arpSchStatusLabel").textContent = r.statusLabel || "Status";
    document.getElementById("arpSchWindowLabel").textContent = `${r.dateLabel || "Date"}: last days`;
    document.getElementById("arpSchSearch").value = s && s.searchText ? s.searchText : "";
    document.getElementById("arpSchStatus").value = s && s.statusCode ? s.statusCode : "";
    document.getElementById("arpSchAssetType").value = s && s.assetTypeId ? String(s.assetTypeId) : "";
    document.getElementById("arpSchDays").value = s && s.days ? s.days : (r.defaultDays || "");
    document.getElementById("arpSchWindow").value = s && s.dateWindowDays ? s.dateWindowDays : "";
  }

  function renderScheduleDays() {
    const f = val("arpSchFrequency");
    document.getElementById("arpSchDowField").hidden = f !== "WEEKLY";
    document.getElementById("arpSchDomField").hidden = f !== "MONTHLY";
  }

  function addRecipient(kind, selectId) {
    const sel = document.getElementById(selectId);
    const id = Number(sel.value);
    if (!id || state.recipients.some(r => r.kind === kind && r.id === id)) return;
    state.recipients.push({ kind, id, name: sel.options[sel.selectedIndex].textContent });
    renderRecipients();
  }

  function renderRecipients() {
    const host = document.getElementById("arpSchRecipients");
    host.innerHTML = state.recipients.map((r, i) => `<span class="arp-recipient">${esc(r.name)}${r.kind === "ROLE" ? " (role)" : ""}
        <button class="pm-link-button" type="button" data-arp-rcp-remove="${i}" aria-label="Remove">&times;</button></span>`).join("")
      || `<span class="arp-note">No recipient yet.</span>`;
  }

  async function saveSchedule() {
    const r = report(val("arpSchReport"));
    if (!r) return;
    const keys = String(r.filterKeys || "").split(",");
    const num = id => (val(id) === "" ? null : Number(val(id)));
    const s = state.editing;
    const res = await api("POST", "/schedules", {
      organizationId: state.organizationId, scheduleId: s ? s.scheduleId : null, reportCode: r.reportCode,
      scheduleName: val("arpSchName"), frequency: val("arpSchFrequency"),
      dayOfWeek: val("arpSchFrequency") === "WEEKLY" ? num("arpSchDow") : null,
      dayOfMonth: val("arpSchFrequency") === "MONTHLY" ? num("arpSchDom") : null,
      retentionDays: num("arpSchRetention"), isActive: document.getElementById("arpSchActive").checked,
      search: keys.includes("SEARCH") ? val("arpSchSearch") || null : null,
      status: keys.includes("STATUS") ? val("arpSchStatus") || null : null,
      assetTypeId: keys.includes("ASSET_TYPE") ? num("arpSchAssetType") : null,
      days: keys.includes("DAYS") ? num("arpSchDays") : null,
      dateWindowDays: keys.includes("DATE_RANGE") ? num("arpSchWindow") : null,
      recipients: state.recipients.map(x => ({ kind: x.kind, id: x.id })),
      expectedRecordVersion: s ? s.recordVersion : null
    });
    if (!res.ok) { showMessage(res.error, "error"); return; }
    showMessage("Schedule saved.", "success");
    closeScheduleForm();
    await loadSchedules();
  }

  async function runScheduleNow(id, btn) {
    btn.disabled = true;
    hideMessage();
    try {
      const res = await api("POST", `/schedules/${id}/run`, { organizationId: state.organizationId });
      if (!res.ok) { showMessage(res.error, "error"); return; }
      const p = res.data.data || {};
      showMessage(`Delivered ${p.delivered || 0} file(s); ${p.skipped || 0} recipient(s) skipped, ${p.failed || 0} failed.`, "success");
      state.runScheduleId = id;
      state.runPager?.reset(true);
      await loadSchedules();
    } finally { btn.disabled = false; }
  }

  async function refreshRuns() {
    const panel = document.getElementById("arpRunPanel"), body = document.getElementById("arpRuns");
    if (!state.organizationId || !state.runScheduleId) { panel.hidden = true; return; }
    panel.hidden = false;
    ["arpRunRecipientsTitle", "arpRunRecipientsWrap"].forEach(x => { document.getElementById(x).hidden = true; });
    const s = ((state.schedules && state.schedules.schedules) || []).find(x => x.scheduleId === state.runScheduleId);
    document.getElementById("arpRunTitle").textContent = `Deliveries${s ? ": " + s.scheduleName : ""}`;
    body.innerHTML = empty(8, "Loading...");
    const qs = new URLSearchParams({ organizationId: state.organizationId, scheduleId: state.runScheduleId,
      pageNumber: state.runPager ? state.runPager.page() : 1, pageSize: state.runPager ? state.runPager.size() : 25 });
    const res = await api("GET", `/deliveries?${qs}`);
    if (!res.ok) { body.innerHTML = empty(8, res.error); state.runPager?.clear(); return; }
    const d = res.data.data || {}, rows = d.rows || [];
    state.runPager?.setTotal(d.totalRows, rows.length);
    body.innerHTML = rows.map(x => `
      <tr><td>${esc(dateTime(x.startedDt))}</td><td>${esc(x.triggerCode === "MANUAL" ? "Run now" : "Scheduled")}<div class="arp-note">${esc(x.startedBy)} &middot; version ${esc(x.reportVersion)}</div></td>
          <td>${stChip(x.status)}</td><td>${esc(x.deliveredCount)}</td><td>${esc(x.skippedCount)}</td><td>${esc(x.failedCount)}</td>
          <td>${esc(filterText(x.filtersJson))}</td>
          <td><button class="pm-button" type="button" data-arp-run="${esc(x.deliveryId)}">Recipients</button></td></tr>`).join("")
      || empty(8, "Not delivered yet.");
  }

  async function showRunRecipients(deliveryId) {
    const title = document.getElementById("arpRunRecipientsTitle"), wrap = document.getElementById("arpRunRecipientsWrap");
    const body = document.getElementById("arpRunRecipients");
    title.hidden = false; wrap.hidden = false;
    body.innerHTML = empty(7, "Loading...");
    const res = await api("GET", `/deliveries/${deliveryId}/recipients?${new URLSearchParams({ organizationId: state.organizationId })}`);
    if (!res.ok) { body.innerHTML = empty(7, res.error); return; }
    body.innerHTML = ((res.data.data || {}).rows || []).map(x => `
      <tr><td>${esc(x.recipientName)}${x.viaRoleName ? `<div class="arp-note">via ${esc(x.viaRoleName)}</div>` : ""}</td>
          <td>${stChip(x.status)}</td><td>${esc(x.reason || "")}</td><td>${esc(x.rowCount ?? "")}</td>
          <td>${esc(dateTime(x.deliveredDt))}</td><td>${esc(x.downloadCount)}</td>
          <td>${x.purgedDt ? `Removed ${esc(dateTime(x.purgedDt))}` : x.status === "DELIVERED" ? "Kept" : ""}</td></tr>`).join("")
      || empty(7, "No recipient.");
  }

  // ------------------------------------------------------------------ settings
""")
edit(J, """  function clsChip(c) { return c ? `<span class="arp-chip ${CLS[c] || ""}">${esc(c)}</span>` : ""; }
""", """  function clsChip(c) { return c ? `<span class="arp-chip ${CLS[c] || ""}">${esc(c)}</span>` : ""; }
  function stChip(s) { return s ? `<span class="arp-chip arp-st-${esc(String(s).toLowerCase())}">${esc(s)}</span>` : ""; }   // 453
  function date(v) { return v ? String(v).substring(0, 10) : ""; }   // SQL DATE values: yyyy-mm-dd
""")
print('ui patched')
