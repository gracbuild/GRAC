import sys
R = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w448/new'
P = R + '/docs/asset-contract-management.md'
def edit(old, new, count=1):
    s = open(P).read(); assert s.count(old) == count, (old[:80], s.count(old)); open(P, 'w').write(s.replace(old, new))

edit("""and the Asset Value read by the risk module (`447`).""",
"""and the Asset Value read by the risk module (`447`), Phase 8.3 privacy -- requirement settings, privacy status and gaps per asset, privacy exceptions, privacy and retention reviews with notifications, and the Active / disposal gates (`448`).""")

edit("""| 8.3-8.5 | Privacy, governance metrics and dashboards, report catalogue, exports | | 8.2 |
""", """| 8.3 **(done)** | Privacy (5.1.10, 5.1.15 / 5.2.7, 5.1.16, 5.1.17, 5.2.15, 5.2.16, 9.1.7): requirement catalogue (12 requirements) with organization and asset-type enforcement (Off / Warn / Block), exception permission and longest exception; privacy status per asset (Not applicable, Undetermined, Non-compliant, Incomplete, Conditional, Compliant) and gaps per requirement from the 5.1.10 fields; computed retention end; privacy exceptions (reason, compensating controls, owner, expiry, approval by another person, expiry); privacy and retention reviews kept by the save and the scheduler, completed with Reviewed / Delete / Archive / Legal hold / Extend; privacy notifications; BLOCK gaps stop a move to Active, a blocking sanitization gap stops Disposed / Archived; Asset Privacy screen and a Privacy tab on the Asset Register | 448 | 8.2 |
| 8.4 | Governance metrics / KPIs (19.8) and dashboards (13.x, 19.10) | | 8.3 |
| 8.5 | Report catalogue (13.4) and exports | | 8.4 |
""")

edit("""| D141 | **Not in 8.1**:""", """| D154 | **Privacy requirement catalogue** (448): 12 global requirements derived from the BRD -- DPDP / GDPR applicability, privacy owner and assessment, processing details (categories, subjects, operations, activity, purpose), special / health / children data, DPIA / PIA, masking, encryption, retention, third parties and transfers, privacy review, residual privacy risk (all Warn by default, they block a move to Active when set to Block) and sanitization (Block by default, blocks Disposed / Archived). An organization row and an asset-type row (wins over the organization row) set enforcement Off / Warn / Block, whether an exception may be requested and the longest exception in days. | BRD 5.1.15 / 5.2.7, 5.1.16, 5.1.17, 5.2.15. | Yes -- labels and defaults can be changed per organization. |
| D155 | **Applicability**: Personal data processed = Yes or Unknown -> the requirements apply (5.2.7 "Yes or Unknown"); No -> Not applicable; not recorded -> Undetermined. | BRD 5.1.15 / 5.2.7. | Yes. |
| D156 | **Gaps**: each requirement is checked against the asset's 5.1.10 field values and gives Missing (not recorded), Partial (Under Assessment, Pending, Partially, Unknown) or Failed (contradiction or failure -- e.g. high-risk processing with DPIA required No, DPIA rejected / expired, encryption required but not implemented, retention ended without a decision, review date passed). An approved, unexpired exception marks the gap Excepted. | BRD 5.1.16 "Privacy Compliant blocked when required masking, encryption, retention or assessment is incomplete". | Yes. |
| D157 | **Privacy status** (computed, never stored): Not applicable; Undetermined; Non-compliant (any failed gap not excepted); Incomplete (any missing gap); Conditional (only partial or excepted gaps); Compliant (no gap). The 5.1.10 Privacy Assessment Status field stays what the assessor records; the computed status is shown next to it. | BRD 5.1.16; 5.1.17 matrix. | Yes. |
| D158 | **Retention end**: Retention Period (`QUANTITY_UNIT`, e.g. "7 years"; days, weeks, months or years up to 100 years) from the Retention Trigger basis -- Creation (registration date), Closure (first completed move to Disposed / Archived), Contract end (end date of the version in force of the asset's Primary Support Contract); moved to the latest date recorded by a completed Legal hold or Extend retention review. An unreadable period is a Failed retention gap. | BRD 5.1.10 retention fields, 5.2.16. | Yes. |
| D159 | **Employment end / Last activity** retention triggers are recorded but no retention end is computed -- the application has no source date for them; the Retention review is then not generated (shown as no retention end). | -- | Yes -- add a basis date field later if needed. |
| D160 | **Reviews**: one open Privacy review per asset (due = Privacy Review Date, assets not Disposed / Archived) and one open Retention review (due = retention end) kept by `sp_asset_privacy_sync` after every save and by the scheduler; a completed review covering the date is not reopened; a review no longer due is cancelled with a reason. Privacy review -> Reviewed with the next review date (written to the asset field through `sp_asset_field_value_set`). Retention review -> Delete or Archive (evidence required), Legal hold verified (Legal Hold Status Yes, keep-until date after the current end), Extend (reason, keep-until date after the current end; asset-privacy APPROVE). | BRD 5.2.16, 9.1.7 "retention expiry decision -- deletion, archival, legal-hold verification or approved extension". | Yes. |
| D161 | **Exceptions**: only for an open, non-excepted gap whose requirement allows them; reason, compensating controls, owner and expiry required; expiry within the longest exception when set; one live exception per asset and requirement. Approve / Reject / Revoke need asset-privacy APPROVE and a different person from the requester (53061); Withdraw needs EDIT. Approved exceptions expire on the scheduler pass (the gap reappears). | BRD 5.2.15 blocking behaviour with exception; 19.7 pattern (D147). | Yes. |
| D162 | **Gates**: on a move to Active the open, not-excepted Block gaps of the requirements that target Active refuse the move (53070); on a move to Disposed / Archived the open, not-excepted Block gaps of the requirements that target disposal (sanitization) refuse it (53071). Warn gaps come back as save warnings. A save is never refused by a privacy gap. | BRD 5.1.16. | Yes. |
| D163 | **Notifications** (437 framework, existing activities): PRIVACY_REVIEW from open privacy reviews and approved exceptions (expiry), RETENTION_REVIEW from open retention reviews; recipient Activity owner = privacy owner (else asset owner) for reviews, the exception owner for exceptions; Exception approver = the person who approved it. Lead times and escalation are the organization's notification profiles. | BRD 9.1.7. | Yes. |
| D164 | **No field masking on screens or exports**: the 5.1.10 masking fields describe the asset's own controls; the application's field-level permissions are unchanged. | -- | Yes. |
| D165 | **Processor-contract reviews** are not generated separately: contract end and renewal already notify the contract owner (436 / 437). | -- | Yes. |
| D166 | **Error numbers 53050-53079; menu Asset & Contract -> Asset Privacy (364); no new dictionary field** (the 5.1.10 fields from 420 are used as they are). Not in 8.3: privacy dashboards and reports (8.4 / 8.5 read `sp_asset_privacy_assets`, `_exceptions`, `_reviews`). | -- | Yes. |
| D141 | **Not in 8.1**:""")

edit("""### Rule semantics (421 -- the BRD is silent on these, so they are stated here)
""", """### Asset privacy (448)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `register/{id}/privacy?organizationId=` | `{status, gaps, exceptions, reviews}` of an asset | `sp_asset_privacy_asset_get` |
| GET | `privacy/assets?organizationId=&status=&search=&pageNumber=&pageSize=` | `{rows, totalRows, page, pageSize, counts}` -- status empty = all except Not applicable; ALL | `sp_asset_privacy_assets` (`fn_asset_privacy_status`) |
| GET | `privacy/assets/{id}?organizationId=` | as `register/{id}/privacy` | `sp_asset_privacy_asset_get` |
| GET | `privacy/exceptions?organizationId=&status=&pageNumber=&pageSize=` | exception worklist | `sp_asset_privacy_exceptions` |
| GET | `privacy/reviews?organizationId=&status=&kind=&pageNumber=&pageSize=` | review worklist with overdue flag, privacy owner, legal hold | `sp_asset_privacy_reviews` |
| GET | `privacy/requirements?organizationId=` | `{requirements, overrides, assetTypes, employees}` | `sp_asset_privacy_requirements` |
| POST | `privacy/requirements` | `{organizationId, assetTypeId?, requirementCode, enforcement (null removes the row), exceptionAllowed, maxExceptionDays?}` -> SAVED / RESET | `sp_asset_privacy_setting_save` |
| POST | `privacy/exceptions` | `{organizationId, assetId, requirementCode, reason, compensatingControls, ownerEmployeeId, expiryDate}` -> PENDING_APPROVAL | `sp_asset_privacy_exception_request` |
| POST | `privacy/exceptions/{id}/action` | `{organizationId, action: APPROVE \\| REJECT \\| WITHDRAW \\| REVOKE, note?, expectedRecordVersion?}` | `sp_asset_privacy_exception_action` |
| POST | `privacy/reviews/{id}/complete` | `{organizationId, outcome: REVIEWED \\| DELETE \\| ARCHIVE \\| LEGAL_HOLD \\| EXTEND, note?, evidence?, nextDate?, expectedRecordVersion?}` | `sp_asset_privacy_review_complete` (-> `sp_asset_privacy_sync`) |
| POST | `privacy/run` | `{organizationId, assetId?}` -> "n review(s) opened, n closed, n exception(s) expired" | `sp_asset_privacy_run` |

Re-issued: `sp_asset_register_save` (privacy sync after the save; a summary warning and one warning per Block gap), `sp_asset_lifecycle_transition` (53070 / 53071), `sp_asset_scheduler_run` (privacy sync per organization), `sp_asset_notification_sweep` and `sp_asset_notification_parties` (439 bodies; PRIVACY_REVIEW / PRIVACY_EXCEPTION objects). Proxy: GETs asset-privacy VIEW (`register/{id}/privacy` asset-register VIEW); requirement settings, exception request, Withdraw, review completion, Run asset-privacy EDIT; Approve, Reject, Revoke and Extend asset-privacy APPROVE. Errors `53050-53072`: 53050 / 53051 / 53052 / 53054 / 53056 / 53064 -> 404; 53060 / 53063 / 53069 -> 409.

### Rule semantics (421 -- the BRD is silent on these, so they are stated here)
""")

edit("""| Web | `Partials/asset-register.cshtml`, `js/AssetConfig/asset-register.js` | Valuation tab: consistency findings (accept / approve / reject / withdraw / revoke, re-evaluate) and linked risks; Consistency findings worklist. |
""", """| Web | `Partials/asset-register.cshtml`, `js/AssetConfig/asset-register.js` | Valuation tab: consistency findings (accept / approve / reject / withdraw / revoke, re-evaluate) and linked risks; Consistency findings worklist. |

### Phase 8.3 files (448)
| Layer | File | Change |
|---|---|---|
| DB | `database/448_asset_privacy.sql` (+ rollback restoring the 439 and 447 bodies) | `asset_privacy_requirement` (12 seeded), `asset_privacy_setting`, `asset_privacy_exception`, `asset_privacy_review`; notification object types PRIVACY_REVIEW / PRIVACY_EXCEPTION; `fn_asset_privacy_values`, `_retention_calc`, `_gaps`, `_status`; `sp_asset_privacy_sync / _run / _requirements / _setting_save / _exception_request / _exception_action / _review_complete / _assets / _asset_get / _exceptions / _reviews`. Re-issued: `sp_asset_register_save`, `sp_asset_scheduler_run`, `sp_asset_lifecycle_transition` (447), `sp_asset_notification_sweep`, `sp_asset_notification_parties` (439). Menu row 364 and Admin grants. |
| DB | `database/274_menu_master_seed.sql` | asset-privacy row (fresh installs). |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs`, `appsettings.json` | 11 routes; 5 request records; PM_ORG_ADMIN gets `asset-privacy:*`. |
| Web | `Controllers/AssetConfigController.cs`, `Models/PracticeScreen.cs`, `Views/Practice/Manage.cshtml`, `appsettings.json` | asset-privacy area and permissions; screen entry. |
| Web | `Partials/asset-privacy.cshtml`, `js/AssetConfig/asset-privacy.js` (new) | Asset Privacy: Assets (status counts, gaps, detail with exception request), Exceptions, Reviews (complete), Requirements (organization and asset-type settings); opens an asset from `?organizationId=&assetId=`. |
| Web | `Partials/asset-register.cshtml`, `js/AssetConfig/asset-register.js` | Privacy tab (read-only status, gaps, exceptions, reviews; Open in Asset Privacy). |
""")

s = open(P).read()
tail = "Not compiled or executed. Next: 8.3 (privacy).\n"
assert s.endswith(tail)
s += """
448 got the same sweep (clean), the semicolon-before-ELSE scan, a declared-variable scan of every batch, the collation rule (`COLLATE DATABASE_DEFAULT` on table-variable string columns), the DATEADD overflow guard in the retention arithmetic (period capped per unit), the parameter check of every internal EXEC (`sp_asset_field_value_set`, `sp_asset_privacy_sync`), a diff of the five re-issued bodies against their 439 / 447 sources (only lines marked `-- 448`) and of the rollback bodies (identical to the sources), the C#-to-procedure parameter and string-size cross-check for the 10 bound procedures (no unknown or missing parameters), the JS-to-alias and HTML-id / duplicate-id checks on Asset Privacy and the Asset Register, `node --check`, brace / parenthesis / bracket balance of the five edited C# files, JSON parse of both appsettings files, the ASCII check and a re-run of every patch script on the base files reproducing the delivered copies. Its verification block checks the tables, functions, procedures, the five re-issues and the notification wiring, the retention arithmetic (7 years from 2026-01-15 -> 2033-01-15, 18 months -> 2027-07-15, "forever" and "500 years" invalid), that the status function runs for every organization and the menu row. Not compiled or executed. Next: 8.4 (governance metrics and dashboards).
"""
open(P, 'w').write(s)
print('doc patched')
