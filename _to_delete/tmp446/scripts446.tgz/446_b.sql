-- =====================================================================
-- 2. Calculation with an explicit method (D133). fn_asset_value_calc
--    (422) is re-issued to call it with the configured method, so the
--    Calculator tab, the register and the risk module share one formula.
-- =====================================================================
CREATE OR ALTER FUNCTION grac_practice.fn_asset_value_calc_method
(
    @config_id BIGINT,
    @method    NVARCHAR(30),   -- NULL = the configured method
    @c         INT,
    @i         INT,
    @a         INT
)
RETURNS TABLE
AS
RETURN
    SELECT x.raw_score AS RawScore, r.score AS AssetValueScore, b.category_label AS AssetValueCategory, b.band_id AS BandId
      FROM grac_practice.asset_valuation_config cfg
     CROSS APPLY (SELECT ISNULL(@method, cfg.valuation_method) AS method) m
     CROSS APPLY (SELECT CAST(CASE m.method
                    WHEN N'MAXIMUM'          THEN (SELECT MAX(v) FROM (VALUES (@c), (@i), (@a)) t(v))
                    WHEN N'SUMMATION'        THEN @c + @i + @a
                    ELSE (@c * cfg.weight_c + @i * cfg.weight_i + @a * cfg.weight_a) / 100.0
                  END AS DECIMAL(18, 6)) AS raw_score) x
     CROSS APPLY (SELECT CAST(CASE cfg.rounding_mode
                    WHEN N'ROUND_DOWN' THEN ROUND(x.raw_score, cfg.decimal_places, 1)
                    WHEN N'ROUND_UP'   THEN CEILING(x.raw_score * POWER(10.0, cfg.decimal_places)) / POWER(10.0, cfg.decimal_places)
                    ELSE ROUND(x.raw_score, cfg.decimal_places)
                  END AS DECIMAL(18, 4)) AS score) r
      OUTER APPLY (SELECT TOP (1) vb.band_id, vb.category_label
                     FROM grac_practice.asset_value_band vb
                    WHERE vb.config_id = cfg.config_id AND r.score BETWEEN vb.min_score AND vb.max_score
                    ORDER BY vb.min_score) b
     WHERE cfg.config_id = @config_id
       AND m.method IN (N'MAXIMUM', N'WEIGHTED_AVERAGE', N'SUMMATION')
       AND @c IS NOT NULL AND @i IS NOT NULL AND @a IS NOT NULL;
GO

-- 422 signature and columns unchanged; the formula now lives in fn_asset_value_calc_method.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_value_calc
(
    @config_id BIGINT,
    @c         INT,
    @i         INT,
    @a         INT
)
RETURNS TABLE
AS
RETURN
    SELECT f.RawScore, f.AssetValueScore, f.AssetValueCategory, f.BandId
      FROM grac_practice.fn_asset_value_calc_method(@config_id, NULL, @c, @i, @a) f;
GO
PRINT '446: fn_asset_value_calc_method created; fn_asset_value_calc re-issued.';
GO

-- =====================================================================
-- 3. The Asset Value of each asset under the Active configuration now
--    (5.1.18.5.7: incomplete or failed calculations get a visible status
--    and no score), and how that compares with what is stored.
-- =====================================================================
CREATE OR ALTER FUNCTION grac_practice.fn_asset_valuation_eval (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT a.asset_id AS AssetId, a.asset_name AS AssetName, cfg.config_id AS ConfigId, cfg.version_no AS ConfigVersionNo,
           v.c_text AS Confidentiality, v.i_text AS Integrity, v.a_text AS Availability,
           o.method_override AS MethodOverride, m.method_used AS MethodUsed, m.method_source AS MethodSource,
           k.RawScore, k.AssetValueScore, k.AssetValueCategory, k.BandId,
           s.status AS ValidationStatus, s.message AS ValidationMessage
      FROM grac_practice.organization_dependency_asset a
     OUTER APPLY (SELECT TOP (1) c.config_id, c.version_no, c.valuation_method, c.override_allowed,
                         c.weight_c + c.weight_i + c.weight_a AS weight_total
                    FROM grac_practice.asset_valuation_config c
                   WHERE c.organization_id = a.organization_id AND c.is_active_version = 1
                   ORDER BY c.config_id DESC) cfg
     OUTER APPLY (SELECT LEFT(MAX(CASE WHEN d.field_key = N'confidentiality_rating' THEN fv.value_text END), 40) AS c_text,
                         LEFT(MAX(CASE WHEN d.field_key = N'integrity_rating' THEN fv.value_text END), 40) AS i_text,
                         LEFT(MAX(CASE WHEN d.field_key = N'availability_rating' THEN fv.value_text END), 40) AS a_text,
                         LEFT(MAX(CASE WHEN d.field_key = N'asset_valuation_method' THEN fv.value_text END), 30) AS m_text
                    FROM grac_practice.asset_field_value fv
                    JOIN grac_practice.asset_field_definition d ON d.field_definition_id = fv.field_definition_id
                   WHERE fv.asset_id = a.asset_id
                     AND d.field_key IN (N'confidentiality_rating', N'integrity_rating', N'availability_rating', N'asset_valuation_method')) v
     CROSS APPLY (SELECT TRY_CONVERT(INT, v.c_text) AS c, TRY_CONVERT(INT, v.i_text) AS i, TRY_CONVERT(INT, v.a_text) AS av,
                         CASE WHEN EXISTS (SELECT 1 FROM grac_practice.asset_cia_scale_level l
                                            WHERE l.config_id = cfg.config_id AND l.dimension_code = N'C'
                                              AND CAST(l.score AS NVARCHAR(40)) = v.c_text) THEN 1 ELSE 0 END AS c_ok,
                         CASE WHEN EXISTS (SELECT 1 FROM grac_practice.asset_cia_scale_level l
                                            WHERE l.config_id = cfg.config_id AND l.dimension_code = N'I'
                                              AND CAST(l.score AS NVARCHAR(40)) = v.i_text) THEN 1 ELSE 0 END AS i_ok,
                         CASE WHEN EXISTS (SELECT 1 FROM grac_practice.asset_cia_scale_level l
                                            WHERE l.config_id = cfg.config_id AND l.dimension_code = N'A'
                                              AND CAST(l.score AS NVARCHAR(40)) = v.a_text) THEN 1 ELSE 0 END AS a_ok) n
     -- An override is a recorded method that differs from the configured one (D133).
     CROSS APPLY (SELECT CASE WHEN v.m_text IN (N'MAXIMUM', N'WEIGHTED_AVERAGE', N'SUMMATION')
                               AND v.m_text <> cfg.valuation_method THEN v.m_text END AS method_override) o
     CROSS APPLY (SELECT CASE WHEN o.method_override IS NOT NULL AND cfg.override_allowed = 1 THEN o.method_override
                              ELSE cfg.valuation_method END AS method_used,
                         CASE WHEN cfg.config_id IS NULL THEN NULL
                              WHEN o.method_override IS NOT NULL AND cfg.override_allowed = 1 THEN N'OVERRIDE'
                              ELSE N'CONFIG' END AS method_source) m
     OUTER APPLY (SELECT f.RawScore, f.AssetValueScore, f.AssetValueCategory, f.BandId
                    FROM grac_practice.fn_asset_value_calc_method(cfg.config_id, m.method_used, n.c, n.i, n.av) f
                   WHERE n.c_ok = 1 AND n.i_ok = 1 AND n.a_ok = 1
                     AND NOT (m.method_used = N'WEIGHTED_AVERAGE' AND cfg.weight_total <> 100)) k
     CROSS APPLY (SELECT CASE
                    WHEN v.c_text IS NULL AND v.i_text IS NULL AND v.a_text IS NULL THEN N'NOT_RATED'
                    WHEN cfg.config_id IS NULL THEN N'INVALID'
                    WHEN v.c_text IS NULL OR v.i_text IS NULL OR v.a_text IS NULL THEN N'INCOMPLETE'
                    WHEN n.c_ok = 0 OR n.i_ok = 0 OR n.a_ok = 0 THEN N'INVALID'
                    WHEN m.method_used = N'WEIGHTED_AVERAGE' AND cfg.weight_total <> 100 THEN N'INVALID'
                    WHEN k.AssetValueCategory IS NULL THEN N'INVALID'
                    ELSE N'VALID' END AS status,
                  CASE
                    WHEN v.c_text IS NULL AND v.i_text IS NULL AND v.a_text IS NULL THEN NULL
                    WHEN cfg.config_id IS NULL THEN N'There is no Active valuation configuration, so Asset Value cannot be calculated.'
                    WHEN v.c_text IS NULL OR v.i_text IS NULL OR v.a_text IS NULL
                        THEN CONCAT(N'Rating missing: ', CONCAT_WS(N', ',
                                 CASE WHEN v.c_text IS NULL THEN N'Confidentiality' END,
                                 CASE WHEN v.i_text IS NULL THEN N'Integrity' END,
                                 CASE WHEN v.a_text IS NULL THEN N'Availability' END), N'.')
                    WHEN n.c_ok = 0 OR n.i_ok = 0 OR n.a_ok = 0
                        THEN CONCAT(N'Not on the CIA scale of configuration version ', cfg.version_no, N': ', CONCAT_WS(N', ',
                                 CASE WHEN n.c_ok = 0 THEN CONCAT(N'Confidentiality ', v.c_text) END,
                                 CASE WHEN n.i_ok = 0 THEN CONCAT(N'Integrity ', v.i_text) END,
                                 CASE WHEN n.a_ok = 0 THEN CONCAT(N'Availability ', v.a_text) END), N'.')
                    WHEN m.method_used = N'WEIGHTED_AVERAGE' AND cfg.weight_total <> 100
                        THEN CONCAT(N'The Weighted Average weights of configuration version ', cfg.version_no,
                                    N' total ', cfg.weight_total, N' percent, not 100.')
                    WHEN k.AssetValueCategory IS NULL
                        THEN CONCAT(N'No value band of configuration version ', cfg.version_no, N' covers the score ',
                                    k.AssetValueScore, N' (', m.method_used, N').')
                    WHEN o.method_override IS NOT NULL AND cfg.override_allowed = 0
                        THEN CONCAT(N'The asset-level method ', o.method_override, N' is recorded, but configuration version ',
                                    cfg.version_no, N' does not permit overrides; the configured method is used.')
                    ELSE NULL END AS message) s
     WHERE a.organization_id = @organization_id AND a.merged_into_asset_id IS NULL;
GO

CREATE OR ALTER FUNCTION grac_practice.fn_asset_valuation_state (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT e.AssetId, e.AssetName, e.ConfigId, e.ConfigVersionNo, e.Confidentiality, e.Integrity, e.Availability,
           e.MethodOverride, e.MethodUsed, e.MethodSource, e.RawScore, e.AssetValueScore, e.AssetValueCategory, e.BandId,
           e.ValidationStatus, e.ValidationMessage,
           r.config_id AS StoredConfigId, r.config_version_no AS StoredConfigVersionNo,
           r.confidentiality AS StoredConfidentiality, r.integrity AS StoredIntegrity, r.availability AS StoredAvailability,
           r.method_used AS StoredMethodUsed, r.method_source AS StoredMethodSource,
           r.asset_value_score AS StoredScore, r.asset_value_category AS StoredCategory,
           r.validation_status AS StoredStatus, r.validation_message AS StoredMessage,
           r.source AS StoredSource, r.calculated_by AS CalculatedBy, r.calculated_dt AS CalculatedDt,
           x.not_calculated AS NotCalculated, x.config_changed AS ConfigChanged, x.values_changed AS ValuesChanged,
           CASE WHEN x.not_calculated = 1 THEN N'NOT_CALCULATED'
                WHEN x.config_changed = 1 AND x.values_changed = 1 THEN N'CONFIG_AND_VALUES'
                WHEN x.config_changed = 1 THEN N'CONFIG_CHANGED'
                WHEN x.values_changed = 1 THEN N'VALUES_CHANGED'
                ELSE N'CURRENT' END AS StateCode,
           CASE WHEN x.not_calculated = 0 AND x.config_changed = 0 AND x.values_changed = 0 THEN 1 ELSE 0 END AS IsCurrent
      FROM grac_practice.fn_asset_valuation_eval(@organization_id) e
      LEFT JOIN grac_practice.asset_valuation_result r ON r.asset_id = e.AssetId
     CROSS APPLY (SELECT
            CASE WHEN r.asset_id IS NULL AND e.ValidationStatus <> N'NOT_RATED' THEN 1 ELSE 0 END AS not_calculated,
            -- A new Active version (or none) -- not for assets that are unrated either way.
            CASE WHEN r.asset_id IS NOT NULL AND ISNULL(r.config_id, -1) <> ISNULL(e.ConfigId, -1)
                      AND NOT (r.validation_status = N'NOT_RATED' AND e.ValidationStatus = N'NOT_RATED') THEN 1 ELSE 0 END AS config_changed,
            -- Ratings or method changed by the form, a merge, a split or discovery.
            CASE WHEN r.asset_id IS NOT NULL
                      AND (   ISNULL(r.confidentiality, N'') <> ISNULL(e.Confidentiality, N'')
                           OR ISNULL(r.integrity, N'') <> ISNULL(e.Integrity, N'')
                           OR ISNULL(r.availability, N'') <> ISNULL(e.Availability, N'')
                           OR ISNULL(r.method_override, N'') <> ISNULL(e.MethodOverride, N'')) THEN 1 ELSE 0 END AS values_changed) x;
GO

-- Risks linked to an asset (265 risk_dependency_map, category Asset -- as 443).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_valuation_risk_links (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT m.dependency_object_id AS AssetId, COUNT(DISTINCT m.risk_register_id) AS RiskCount
      FROM grac_practice.risk_dependency_map m
      JOIN grac_practice.dependency_type_master dt ON dt.dependency_type_id = m.dependency_type_id
                                                  AND (dt.dependency_type_code = N'ASSET' OR dt.dependency_type_name = N'Asset')
     WHERE m.organization_id = @organization_id
     GROUP BY m.dependency_object_id;
GO
PRINT '446: valuation evaluation, state and risk-link functions created.';
GO

