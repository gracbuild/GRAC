
-- =====================================================================
-- 4. Writers (5.4.1, 5.4.2; D81-D86)
-- =====================================================================
-- Propose a relationship (new -> Proposed) or change one. A Proposed or
-- Disputed relationship is changed in place. An Active one is changed in
-- place unless it is, or becomes, critical: then the change waits for
-- approval (pending change) and the relationship stays Active as it is.
-- Type and endpoints are fixed once proposed (retire and propose again).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationship_save
    @organization_id         BIGINT,
    @relationship_id         BIGINT         = NULL,
    @relationship_type_code  NVARCHAR(30)   = NULL,
    @source_kind             NVARCHAR(12)   = NULL,
    @source_id               BIGINT         = NULL,
    @target_kind             NVARCHAR(12)   = NULL,
    @target_id               BIGINT         = NULL,
    @is_critical             BIT            = 0,
    @dependency_criticality  NVARCHAR(10)   = NULL,
    @impact_weight           DECIMAL(5, 2)  = NULL,
    @effective_from          DATE           = NULL,
    @effective_to            DATE           = NULL,
    @confidence_pct          INT            = NULL,
    @owner_employee_id       BIGINT         = NULL,
    @verifier_employee_id    BIGINT         = NULL,
    @evidence_reference      NVARCHAR(400)  = NULL,
    @change_reference        NVARCHAR(200)  = NULL,
    @reason                  NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @relationship_type_code = UPPER(LTRIM(RTRIM(ISNULL(@relationship_type_code, N''))));
    SET @source_kind = UPPER(LTRIM(RTRIM(ISNULL(@source_kind, N''))));
    SET @target_kind = UPPER(LTRIM(RTRIM(ISNULL(@target_kind, N''))));
    SET @is_critical = ISNULL(@is_critical, 0);
    SET @dependency_criticality = NULLIF(UPPER(LTRIM(RTRIM(@dependency_criticality))), N'');
    SET @evidence_reference = NULLIF(LTRIM(RTRIM(@evidence_reference)), N'');
    SET @change_reference = NULLIF(LTRIM(RTRIM(@change_reference)), N'');
    SET @reason = NULLIF(LTRIM(RTRIM(@reason)), N'');
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    SET @effective_from = ISNULL(@effective_from, @today);

    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54701, 'Organization not found.', 1;
    IF @effective_to IS NOT NULL AND @effective_to < @effective_from
        THROW 54714, 'The effective-to date must be on or after the effective-from date.', 1;
    IF @dependency_criticality IS NOT NULL AND @dependency_criticality NOT IN (N'CRITICAL', N'HIGH', N'MEDIUM', N'LOW')
        THROW 54717, 'The dependency criticality is Critical, High, Medium or Low.', 1;
    IF @is_critical = 1 AND @dependency_criticality IS NULL
        THROW 54717, 'Select the dependency criticality of a critical dependency.', 1;
    IF @impact_weight IS NOT NULL AND @impact_weight NOT BETWEEN 0 AND 100
        THROW 54717, 'The impact weight is between 0 and 100.', 1;
    IF @confidence_pct IS NOT NULL AND @confidence_pct NOT BETWEEN 0 AND 100
        THROW 54717, 'The confidence is between 0 and 100.', 1;
    IF (@owner_employee_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM grac_practice.organization_employee
                                                        WHERE employee_id = @owner_employee_id AND organization_id = @organization_id
                                                          AND status = N'Active'))
       OR (@verifier_employee_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM grac_practice.organization_employee
                                                              WHERE employee_id = @verifier_employee_id AND organization_id = @organization_id
                                                                AND status = N'Active'))
        THROW 54718, 'The owner and the verifier must be active employees of the organization.', 1;

    DECLARE @loop BIT, @id BIGINT, @result NVARCHAR(20);
    IF @relationship_id IS NULL
    BEGIN
        EXEC grac_practice.sp_asset_relationship_check @organization_id = @organization_id, @relationship_id = NULL,
             @type_code = @relationship_type_code, @source_kind = @source_kind, @source_id = @source_id,
             @target_kind = @target_kind, @target_id = @target_id, @out_loop = @loop OUTPUT;
        BEGIN TRAN;
        INSERT grac_practice.asset_relationship
            (organization_id, relationship_type_code, source_kind, source_id, target_kind, target_id, is_critical,
             dependency_criticality, impact_weight, status, effective_from, effective_to, source_code, confidence_pct,
             owner_employee_id, verifier_employee_id, evidence_reference, change_reference, reason, in_loop,
             proposed_by, proposed_by_employee_id, entered_by)
        VALUES (@organization_id, @relationship_type_code, @source_kind, @source_id, @target_kind, @target_id, @is_critical,
                @dependency_criticality, @impact_weight, N'PROPOSED', @effective_from, @effective_to, N'MANUAL', @confidence_pct,
                @owner_employee_id, @verifier_employee_id, @evidence_reference, @change_reference, @reason, ISNULL(@loop, 0),
                @actor, @actor_employee_id, @actor);
        SET @id = SCOPE_IDENTITY();
        EXEC grac_practice.sp_asset_relationship_history_add @relationship_id = @id, @action_code = N'PROPOSE', @note = @reason,
             @actor = @actor, @actor_employee_id = @actor_employee_id;
        COMMIT;
        SELECT @id AS RelationshipId, N'PROPOSED' AS Result;
        RETURN;
    END

    DECLARE @found BIT = 0, @status NVARCHAR(10), @rv BIGINT, @was_critical BIT, @pending NVARCHAR(10);
    SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version), @was_critical = is_critical, @pending = pending_action
      FROM grac_practice.asset_relationship WHERE relationship_id = @relationship_id AND organization_id = @organization_id;
    IF @found = 0 THROW 54709, 'Relationship not found for this organization.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 54710, 'The relationship was changed by someone else; reload it and try again.', 1;
    IF @status IN (N'INACTIVE', N'RETIRED')
        THROW 54711, 'An inactive or retired relationship is kept for history and cannot be changed.', 1;
    IF @pending IS NOT NULL
        THROW 54712, 'A change of this relationship is waiting for approval; approve, reject or withdraw it first.', 1;
    IF @status = N'ACTIVE' AND @reason IS NULL
        THROW 54713, 'Enter the reason for changing an active relationship.', 1;

    BEGIN TRAN;
    IF @status = N'ACTIVE' AND (@was_critical = 1 OR @is_critical = 1)
    BEGIN
        UPDATE grac_practice.asset_relationship
           SET pending_action = N'UPDATE', pending_reason = @reason, pending_by = @actor, pending_by_employee_id = @actor_employee_id,
               pending_dt = SYSUTCDATETIME(),
               pending_json = (SELECT @is_critical AS isCritical, @dependency_criticality AS dependencyCriticality,
                                      @impact_weight AS impactWeight, @effective_from AS effectiveFrom, @effective_to AS effectiveTo,
                                      @confidence_pct AS confidencePct, @owner_employee_id AS ownerEmployeeId,
                                      @verifier_employee_id AS verifierEmployeeId, @evidence_reference AS evidenceReference,
                                      @change_reference AS changeReference, @reason AS reason
                                  FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER),
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
        EXEC grac_practice.sp_asset_relationship_history_add @relationship_id = @relationship_id, @action_code = N'CHANGE_REQUEST',
             @note = @reason, @actor = @actor, @actor_employee_id = @actor_employee_id;
        SET @result = N'PENDING_APPROVAL';
    END
    ELSE
    BEGIN
        UPDATE grac_practice.asset_relationship
           SET is_critical = @is_critical, dependency_criticality = @dependency_criticality, impact_weight = @impact_weight,
               effective_from = @effective_from, effective_to = @effective_to, confidence_pct = @confidence_pct,
               owner_employee_id = @owner_employee_id, verifier_employee_id = @verifier_employee_id,
               evidence_reference = @evidence_reference, change_reference = @change_reference, reason = @reason,
               version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
        EXEC grac_practice.sp_asset_relationship_history_add @relationship_id = @relationship_id, @action_code = N'UPDATE',
             @note = @reason, @actor = @actor, @actor_employee_id = @actor_employee_id;
        SET @result = N'UPDATED';
    END
    COMMIT;
    SELECT @relationship_id AS RelationshipId, @result AS Result;
END
GO

-- Actions (D82-D86):
--   APPROVE            Proposed -> Active (checks repeated); or applies the
--                      pending change / retirement. A critical relationship
--                      or change is approved by another person.
--   REJECT             a proposal (-> Retired) or a pending change; note.
--   WITHDRAW           the proposer withdraws the proposal (-> Retired) or
--                      the requester the pending change.
--   DISPUTE            Active -> Disputed; note.
--   CONFIRM            Disputed -> Active; note.
--   RETIRE             Active / Disputed / Inactive -> Retired, effective to
--                      today at the latest; an active critical one waits for
--                      approval; note.
--   ACCEPT_RETIREMENT  an active critical dependency is accepted as an
--                      exception for the retirement of the CI it relies on.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationship_action
    @organization_id         BIGINT,
    @relationship_id         BIGINT,
    @action                  NVARCHAR(20),
    @note                    NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @action = UPPER(LTRIM(RTRIM(ISNULL(@action, N''))));
    SET @note = NULLIF(LTRIM(RTRIM(@note)), N'');
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    DECLARE @found BIT = 0, @status NVARCHAR(10), @rv BIGINT, @critical BIT, @pending NVARCHAR(10), @pending_json NVARCHAR(MAX),
            @pending_by NVARCHAR(100), @pending_emp BIGINT, @pending_reason NVARCHAR(1000), @proposed_by NVARCHAR(100),
            @proposed_emp BIGINT, @type NVARCHAR(30), @sk NVARCHAR(12), @si BIGINT, @tk NVARCHAR(12), @ti BIGINT;
    SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version), @critical = is_critical, @pending = pending_action,
           @pending_json = pending_json, @pending_by = pending_by, @pending_emp = pending_by_employee_id,
           @pending_reason = pending_reason, @proposed_by = proposed_by, @proposed_emp = proposed_by_employee_id,
           @type = relationship_type_code, @sk = source_kind, @si = source_id, @tk = target_kind, @ti = target_id
      FROM grac_practice.asset_relationship WHERE relationship_id = @relationship_id AND organization_id = @organization_id;
    IF @found = 0 THROW 54709, 'Relationship not found for this organization.', 1;
    IF @action NOT IN (N'APPROVE', N'REJECT', N'WITHDRAW', N'DISPUTE', N'CONFIRM', N'RETIRE', N'ACCEPT_RETIREMENT')
        THROW 54715, 'The action is Approve, Reject, Withdraw, Dispute, Confirm, Retire or Accept for retirement.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 54710, 'The relationship was changed by someone else; reload it and try again.', 1;
    IF @action IN (N'REJECT', N'DISPUTE', N'CONFIRM', N'RETIRE', N'ACCEPT_RETIREMENT') AND @note IS NULL
        THROW 54713, 'Enter the note for this action.', 1;

    DECLARE @result NVARCHAR(20), @loop BIT, @hist NVARCHAR(20) = @action;
    BEGIN TRAN;
    IF @action = N'APPROVE' AND @status = N'PROPOSED'
    BEGIN
        IF @critical = 1 AND (@proposed_by = @actor OR (@proposed_emp IS NOT NULL AND @proposed_emp = @actor_employee_id))
            THROW 54716, 'Segregation of duties: the person who proposed a critical relationship cannot approve it.', 1;
        EXEC grac_practice.sp_asset_relationship_check @organization_id = @organization_id, @relationship_id = @relationship_id,
             @type_code = @type, @source_kind = @sk, @source_id = @si, @target_kind = @tk, @target_id = @ti, @out_loop = @loop OUTPUT;
        UPDATE grac_practice.asset_relationship
           SET status = N'ACTIVE', verification_status = N'VERIFIED', in_loop = ISNULL(@loop, 0), approved_by = @actor,
               approved_by_employee_id = @actor_employee_id, approved_dt = SYSUTCDATETIME(), status_note = @note,
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
        SET @result = N'ACTIVE';
    END
    ELSE IF @action = N'APPROVE' AND @pending IS NOT NULL
    BEGIN
        IF @pending_by = @actor OR (@pending_emp IS NOT NULL AND @pending_emp = @actor_employee_id)
            THROW 54716, 'Segregation of duties: the person who requested the change cannot approve it.', 1;
        IF @pending = N'UPDATE'
        BEGIN
            UPDATE r
               SET is_critical = ISNULL(j.isCritical, 0), dependency_criticality = j.dependencyCriticality, impact_weight = j.impactWeight,
                   effective_from = j.effectiveFrom, effective_to = j.effectiveTo, confidence_pct = j.confidencePct,
                   owner_employee_id = j.ownerEmployeeId, verifier_employee_id = j.verifierEmployeeId,
                   evidence_reference = j.evidenceReference, change_reference = j.changeReference, reason = j.reason,
                   version_no = version_no + 1
              FROM grac_practice.asset_relationship r
             CROSS APPLY OPENJSON(@pending_json) WITH (
                    isCritical BIT, dependencyCriticality NVARCHAR(10), impactWeight DECIMAL(5, 2), effectiveFrom DATE,
                    effectiveTo DATE, confidencePct INT, ownerEmployeeId BIGINT, verifierEmployeeId BIGINT,
                    evidenceReference NVARCHAR(400), changeReference NVARCHAR(200), reason NVARCHAR(1000)) j
             WHERE r.relationship_id = @relationship_id;
            SET @result = N'UPDATED';
            SET @hist = N'APPROVE_CHANGE';
        END
        ELSE
        BEGIN
            UPDATE grac_practice.asset_relationship
               SET status = N'RETIRED', status_note = @pending_reason, version_no = version_no + 1,
                   effective_to = CASE WHEN effective_to IS NULL OR effective_to > @today THEN
                                           CASE WHEN effective_from > @today THEN effective_from ELSE @today END
                                       ELSE effective_to END
             WHERE relationship_id = @relationship_id;
            SET @result = N'RETIRED';
            SET @hist = N'APPROVE_RETIRE';
        END
        UPDATE grac_practice.asset_relationship
           SET pending_action = NULL, pending_json = NULL, pending_reason = NULL, pending_by = NULL, pending_by_employee_id = NULL,
               pending_dt = NULL, approved_by = @actor, approved_by_employee_id = @actor_employee_id, approved_dt = SYSUTCDATETIME(),
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
    END
    ELSE IF @action IN (N'REJECT', N'WITHDRAW') AND (@status = N'PROPOSED' OR @pending IS NOT NULL)
    BEGIN
        IF @action = N'WITHDRAW'
           AND ((@pending IS NOT NULL AND ISNULL(@pending_by, N'') <> @actor)
                OR (@pending IS NULL AND @proposed_by <> @actor))
            THROW 54716, 'Only the person who proposed the relationship or requested the change can withdraw it.', 1;
        IF @pending IS NOT NULL
        BEGIN
            UPDATE grac_practice.asset_relationship
               SET pending_action = NULL, pending_json = NULL, pending_reason = NULL, pending_by = NULL, pending_by_employee_id = NULL,
                   pending_dt = NULL, status_note = ISNULL(@note, N'Withdrawn by the requester.'),
                   updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE relationship_id = @relationship_id;
            SET @result = @status;
            SET @hist = CONCAT(@action, N'_CHANGE');
        END
        ELSE
        BEGIN
            UPDATE grac_practice.asset_relationship
               SET status = N'RETIRED', status_note = ISNULL(@note, N'Withdrawn by the proposer.'), version_no = version_no + 1,
                   updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE relationship_id = @relationship_id;
            SET @result = N'RETIRED';
        END
    END
    ELSE IF @action = N'DISPUTE' AND @status = N'ACTIVE' AND @pending IS NULL
    BEGIN
        UPDATE grac_practice.asset_relationship
           SET status = N'DISPUTED', status_note = @note, version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
        SET @result = N'DISPUTED';
    END
    ELSE IF @action = N'CONFIRM' AND @status = N'DISPUTED'
    BEGIN
        UPDATE grac_practice.asset_relationship
           SET status = N'ACTIVE', verification_status = N'VERIFIED', status_note = @note, version_no = version_no + 1,
               approved_by = @actor, approved_by_employee_id = @actor_employee_id, approved_dt = SYSUTCDATETIME(),
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
        SET @result = N'ACTIVE';
    END
    ELSE IF @action = N'RETIRE' AND @status IN (N'ACTIVE', N'DISPUTED', N'INACTIVE') AND @pending IS NULL
    BEGIN
        IF @status = N'ACTIVE' AND @critical = 1
        BEGIN
            UPDATE grac_practice.asset_relationship
               SET pending_action = N'RETIRE', pending_json = NULL, pending_reason = @note, pending_by = @actor,
                   pending_by_employee_id = @actor_employee_id, pending_dt = SYSUTCDATETIME(),
                   updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE relationship_id = @relationship_id;
            SET @result = N'PENDING_APPROVAL';
            SET @hist = N'RETIRE_REQUEST';
        END
        ELSE
        BEGIN
            UPDATE grac_practice.asset_relationship
               SET status = N'RETIRED', status_note = @note, version_no = version_no + 1,
                   effective_to = CASE WHEN effective_to IS NULL OR effective_to > @today THEN
                                           CASE WHEN effective_from > @today THEN effective_from ELSE @today END
                                       ELSE effective_to END,
                   updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE relationship_id = @relationship_id;
            SET @result = N'RETIRED';
        END
    END
    ELSE IF @action = N'ACCEPT_RETIREMENT' AND @status = N'ACTIVE' AND @critical = 1
    BEGIN
        UPDATE grac_practice.asset_relationship
           SET retirement_accepted = 1, retirement_note = @note, retirement_accepted_by = @actor,
               retirement_accepted_dt = SYSUTCDATETIME(), updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
        SET @result = N'ACCEPTED';
    END
    ELSE
        THROW 54715, 'This action is not available for the relationship in its current status.', 1;

    EXEC grac_practice.sp_asset_relationship_history_add @relationship_id = @relationship_id, @action_code = @hist, @note = @note,
         @actor = @actor, @actor_employee_id = @actor_employee_id;
    COMMIT;
    SELECT @relationship_id AS RelationshipId, @result AS Result;
END
GO
PRINT '440: writers created.';
GO
