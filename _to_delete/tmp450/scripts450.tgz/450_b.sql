
-- =====================================================================
-- 4. Effective settings, population and the record rows of each KPI
-- =====================================================================
-- Effective setting per KPI: the organization row, else the catalogue
-- default. A KPI without a period keeps PeriodDays NULL.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_governance_effective (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT k.kpi_code AS KpiCode, k.kpi_name AS KpiName, k.direction AS Direction, k.display_order AS DisplayOrder,
           CAST(ISNULL(s.is_enabled, 1) AS BIT) AS IsEnabled, ISNULL(s.weight, k.default_weight) AS Weight,
           ISNULL(s.target_value, k.default_target) AS TargetValue, ISNULL(s.warning_value, k.default_warning) AS WarningValue,
           CASE WHEN k.default_period_days IS NULL THEN NULL ELSE ISNULL(s.period_days, k.default_period_days) END AS PeriodDays,
           CAST(CASE WHEN s.kpi_code IS NULL THEN 0 ELSE 1 END AS BIT) AS IsCustomised
      FROM grac_practice.asset_governance_kpi k
      LEFT JOIN grac_practice.asset_governance_setting s ON s.organization_id = @organization_id AND s.kpi_code = k.kpi_code;
GO

-- Assets of the organization and whether they are in use (D169): record
-- active, lifecycle status not Draft / Disposed / Archived. ExclusionReason
-- is NULL for an asset in use.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_governance_assets (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT a.asset_id AS AssetId, CAST(a.asset_name AS NVARCHAR(400)) AS AssetName, a.asset_type_id AS AssetTypeId,
           a.template_id AS TemplateId, a.owner_id AS OwnerId, ISNULL(s.status_code, N'ACTIVE') AS StatusCode,
           CAST(CASE WHEN ISNULL(a.status, N'Active') <> N'Active' THEN N'Not in use: the record is inactive (merged or deactivated).'
                     WHEN s.status_code = N'DRAFT' THEN N'Not in use: Draft.'
                     WHEN s.status_code IN (N'DISPOSED', N'ARCHIVED') THEN CONCAT(N'Not in use: ', s.status_name, N'.')
                END AS NVARCHAR(200)) AS ExclusionReason
      FROM grac_practice.organization_dependency_asset a
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
     WHERE a.organization_id = @organization_id;
GO

-- One row per record of a KPI (@kpi_code NULL = every KPI): PASS / FAIL /
-- EXCLUDED, its numerator and denominator contribution and the reason.
-- The score of a KPI is SUM(Numerator) / SUM(Denominator) x 100 over the
-- rows that are not EXCLUDED (D170). Each branch reads the records its
-- module keeps; see asset_governance_kpi for the definitions.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_governance_items (@organization_id BIGINT, @kpi_code NVARCHAR(30))
RETURNS TABLE
AS
RETURN
    -- 1. Attestation Compliance (431 / 432): occurrences due in the period.
    SELECT CAST(N'ATTESTATION_COMPLIANCE' AS NVARCHAR(30)) AS KpiCode, CAST(N'ATTESTATION' AS NVARCHAR(16)) AS RecordKind,
           t.attestation_id AS RecordId,
           CAST(CONCAT(a.asset_name, N' - ', LOWER(t.attestation_type), N' attestation due ', CONVERT(NVARCHAR(10), t.due_date, 23)) AS NVARCHAR(400)) AS RecordName,
           CAST(o.outcome AS NVARCHAR(8)) AS Outcome,
           CASE WHEN o.outcome = N'PASS' THEN 1 ELSE 0 END AS Numerator,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE 1 END AS Denominator,
           CAST(CASE o.outcome
                WHEN N'EXCLUDED' THEN N'Cancelled.'
                WHEN N'FAIL' THEN CONCAT(N'Not confirmed: ',
                     CASE t.status WHEN N'GENERATED' THEN N'generated' WHEN N'PENDING' THEN N'pending' WHEN N'IN_PROGRESS' THEN N'in progress'
                                   WHEN N'DISPUTED' THEN N'disputed' WHEN N'OVERDUE' THEN N'overdue' WHEN N'ESCALATED' THEN N'escalated'
                                   WHEN N'EXCEPTION' THEN N'verification exception open' ELSE LOWER(t.status) END,
                     CASE WHEN t.status IN (N'GENERATED', N'PENDING', N'IN_PROGRESS') AND t.due_date < CAST(SYSUTCDATETIME() AS DATE)
                          THEN N' (past its due date)' ELSE N'' END, N'.')
                END AS NVARCHAR(1000)) AS Reason
      FROM grac_practice.asset_attestation t
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = t.asset_id
     CROSS APPLY (SELECT e.PeriodDays AS p FROM grac_practice.fn_asset_governance_effective(@organization_id) e
                   WHERE e.KpiCode = N'ATTESTATION_COMPLIANCE') pd
     CROSS APPLY (SELECT CASE WHEN t.status = N'CANCELLED' THEN N'EXCLUDED'
                              WHEN t.status IN (N'CONFIRMED', N'CLOSED', N'RESOLVED') THEN N'PASS'
                              ELSE N'FAIL' END AS outcome) o
     WHERE (@kpi_code IS NULL OR @kpi_code = N'ATTESTATION_COMPLIANCE')
       AND t.organization_id = @organization_id
       AND t.due_date BETWEEN DATEADD(DAY, 1 - pd.p, CAST(SYSUTCDATETIME() AS DATE)) AND CAST(SYSUTCDATETIME() AS DATE)

    UNION ALL
    -- 2. Metadata Completeness (421 / 428): the form engine on the stored values.
    SELECT N'METADATA_COMPLETENESS', N'ASSET', p.AssetId, p.AssetName, o.outcome,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE ev.done END,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE ev.mand END,
           CAST(CASE WHEN p.ExclusionReason IS NOT NULL THEN p.ExclusionReason
                     WHEN p.TemplateId IS NULL THEN N'No asset form: created before asset types.'
                     WHEN ISNULL(ev.mand, 0) = 0 THEN N'Its asset form makes no field mandatory.'
                     WHEN o.outcome = N'FAIL' THEN CONCAT(ev.mand - ev.done, N' of ', ev.mand, N' mandatory fields empty: ', ev.missing, N'.')
                END AS NVARCHAR(1000))
      FROM grac_practice.fn_asset_governance_assets(@organization_id) p
     OUTER APPLY (SELECT CONCAT(N'{', STRING_AGG(CAST(CONCAT(N'"', STRING_ESCAPE(v.FieldKey, 'json'), N'":',
                                          CASE WHEN LEFT(LTRIM(v.Value), 1) = N'[' AND ISJSON(v.Value) = 1 THEN v.Value
                                               ELSE CONCAT(N'"', STRING_ESCAPE(v.Value, 'json'), N'"') END) AS NVARCHAR(MAX)), N','), N'}') AS j
                    FROM grac_practice.fn_asset_stored_values(p.AssetId) v
                   WHERE p.ExclusionReason IS NULL AND p.TemplateId IS NOT NULL
                     AND NULLIF(NULLIF(LTRIM(RTRIM(v.Value)), N''), N'[]') IS NOT NULL) sv
     OUTER APPLY (SELECT SUM(e.IsMandatory) AS mand,
                         SUM(CASE WHEN e.IsMandatory = 1 AND e.ValueSupplied = 1 THEN 1 ELSE 0 END) AS done,
                         STRING_AGG(CASE WHEN e.IsMandatory = 1 AND e.ValueSupplied = 0 THEN CAST(e.DisplayLabel AS NVARCHAR(MAX)) END, N', ')
                             WITHIN GROUP (ORDER BY e.SectionOrder, e.FieldOrder) AS missing
                    FROM grac_practice.fn_asset_form_evaluate(p.TemplateId, ISNULL(sv.j, N'{}')) e
                   WHERE p.ExclusionReason IS NULL AND p.TemplateId IS NOT NULL) ev
     CROSS APPLY (SELECT CASE WHEN p.ExclusionReason IS NOT NULL OR p.TemplateId IS NULL OR ISNULL(ev.mand, 0) = 0 THEN N'EXCLUDED'
                              WHEN ev.done = ev.mand THEN N'PASS' ELSE N'FAIL' END AS outcome) o
     WHERE (@kpi_code IS NULL OR @kpi_code = N'METADATA_COMPLETENESS')

    UNION ALL
    -- 3. Ownership Completeness (428 owner, 431 custodian).
    SELECT N'OWNERSHIP_COMPLETENESS', N'ASSET', p.AssetId, p.AssetName, o.outcome,
           CASE WHEN o.outcome = N'PASS' THEN 1 ELSE 0 END,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE 1 END,
           CAST(CASE WHEN p.ExclusionReason IS NOT NULL THEN p.ExclusionReason
                     WHEN o.outcome = N'FAIL' THEN CONCAT_WS(N' ', x.owner_issue, x.cust_issue) END AS NVARCHAR(1000))
      FROM grac_practice.fn_asset_governance_assets(@organization_id) p
     OUTER APPLY (SELECT TOP (1) NULLIF(LTRIM(RTRIM(v.value_text)), N'') AS cust
                    FROM grac_practice.asset_field_value v
                    JOIN grac_practice.asset_field_definition d ON d.field_definition_id = v.field_definition_id AND d.field_key = N'custodian'
                   WHERE v.asset_id = p.AssetId) c
     CROSS APPLY (SELECT
            CASE WHEN p.OwnerId IS NULL THEN N'No asset owner.'
                 WHEN NOT EXISTS (SELECT 1 FROM grac_practice.organization_employee e
                                   WHERE e.employee_id = p.OwnerId AND e.organization_id = @organization_id AND e.status = N'Active')
                      THEN N'The asset owner is not an active employee of the organization.' END AS owner_issue,
            CASE WHEN c.cust IS NULL
                      THEN CASE WHEN EXISTS (SELECT 1 FROM grac_practice.asset_form_template_field f
                                               JOIN grac_practice.asset_field_definition d
                                                 ON d.field_definition_id = f.field_definition_id AND d.field_key = N'custodian'
                                              WHERE f.template_id = p.TemplateId AND f.is_mandatory = 1)
                                THEN N'No custodian (the asset form requires one).' END
                 WHEN c.cust LIKE N'E:%' AND EXISTS (SELECT 1 FROM grac_practice.organization_employee e
                                                      WHERE e.employee_id = TRY_CONVERT(BIGINT, SUBSTRING(c.cust, 3, 38))
                                                        AND e.organization_id = @organization_id AND e.status = N'Active') THEN NULL
                 WHEN c.cust LIKE N'T:%' AND EXISTS (SELECT 1 FROM grac_practice.organization_team tm
                                                      WHERE tm.team_id = TRY_CONVERT(BIGINT, SUBSTRING(c.cust, 3, 38))
                                                        AND tm.organization_id = @organization_id AND tm.status = N'Active') THEN NULL
                 ELSE N'The custodian is not an active employee or team of the organization.' END AS cust_issue) x
     CROSS APPLY (SELECT CASE WHEN p.ExclusionReason IS NOT NULL THEN N'EXCLUDED'
                              WHEN x.owner_issue IS NULL AND x.cust_issue IS NULL THEN N'PASS' ELSE N'FAIL' END AS outcome) o
     WHERE (@kpi_code IS NULL OR @kpi_code = N'OWNERSHIP_COMPLETENESS')

    UNION ALL
    -- 4a. Relationship Completeness -- assets of a type with a requirement (440).
    SELECT N'RELATIONSHIP_COMPLETENESS', N'ASSET', p.AssetId, p.AssetName, o.outcome,
           CASE WHEN o.outcome = N'PASS' THEN 1 ELSE 0 END,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE 1 END,
           CAST(CASE WHEN p.ExclusionReason IS NOT NULL THEN p.ExclusionReason
                     WHEN o.outcome = N'FAIL' THEN CONCAT(q.unmet, N'.') END AS NVARCHAR(1000))
      FROM grac_practice.fn_asset_governance_assets(@organization_id) p
     CROSS APPLY (SELECT COUNT(*) AS rules, SUM(m.ok) AS met,
                         STRING_AGG(CASE WHEN m.ok = 0 THEN CAST(CONCAT(N'Needs ', r.min_count, N' active "',
                                         CASE r.asset_side WHEN N'SOURCE' THEN rt.type_name ELSE rt.inverse_label END,
                                         N'" relationship(s), has ', c.n) AS NVARCHAR(MAX)) END, N'; ') AS unmet
                    FROM grac_practice.asset_governance_relationship_rule r
                    JOIN grac_practice.asset_relationship_type rt ON rt.type_code = r.relationship_type_code
                   CROSS APPLY (SELECT COUNT(*) AS n
                                  FROM grac_practice.asset_relationship x
                                 WHERE x.organization_id = @organization_id AND x.relationship_type_code = r.relationship_type_code
                                   AND x.status = N'ACTIVE' AND x.effective_from <= CAST(SYSUTCDATETIME() AS DATE)
                                   AND (x.effective_to IS NULL OR x.effective_to >= CAST(SYSUTCDATETIME() AS DATE))
                                   AND ((r.asset_side = N'SOURCE' AND x.source_kind = N'ASSET' AND x.source_id = p.AssetId)
                                        OR (r.asset_side = N'TARGET' AND x.target_kind = N'ASSET' AND x.target_id = p.AssetId))) c
                   CROSS APPLY (SELECT CASE WHEN c.n >= r.min_count THEN 1 ELSE 0 END AS ok) m
                   WHERE r.organization_id = @organization_id AND r.is_active = 1 AND r.asset_type_id = p.AssetTypeId) q
     CROSS APPLY (SELECT CASE WHEN p.ExclusionReason IS NOT NULL THEN N'EXCLUDED'
                              WHEN q.met = q.rules THEN N'PASS' ELSE N'FAIL' END AS outcome) o
     WHERE (@kpi_code IS NULL OR @kpi_code = N'RELATIONSHIP_COMPLETENESS') AND q.rules > 0

    UNION ALL
    -- 4b. Relationship Completeness -- business services in operation (441 minimum supporting relationships).
    SELECT N'RELATIONSHIP_COMPLETENESS', N'SERVICE', b.service_id, CAST(CONCAT(b.service_code, N' - ', b.service_name) AS NVARCHAR(400)),
           o.outcome,
           CASE WHEN o.outcome = N'PASS' THEN 1 ELSE 0 END,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE 1 END,
           CAST(CASE o.outcome
                WHEN N'EXCLUDED' THEN CONCAT(N'Service not in operation (', LOWER(b.status), N').')
                WHEN N'FAIL' THEN CONCAT(N'Needs ', st.mn, N' active "Is supported by" relationship(s), has ', c.n, N'.') END AS NVARCHAR(1000))
      FROM grac_practice.business_service b
     CROSS APPLY (SELECT ISNULL((SELECT bs.min_supporting_relationships FROM grac_practice.business_service_setting bs
                                  WHERE bs.organization_id = @organization_id), 1) AS mn) st
     CROSS APPLY (SELECT COUNT(*) AS n
                    FROM grac_practice.asset_relationship x
                   WHERE x.organization_id = @organization_id AND x.relationship_type_code = N'SUPPORTS_SERVICE'
                     AND x.target_kind = N'SERVICE' AND x.target_id = b.service_id AND x.status = N'ACTIVE'
                     AND x.effective_from <= CAST(SYSUTCDATETIME() AS DATE)
                     AND (x.effective_to IS NULL OR x.effective_to >= CAST(SYSUTCDATETIME() AS DATE))) c
     CROSS APPLY (SELECT CASE WHEN b.status NOT IN (N'ACTIVE', N'DEGRADED') THEN N'EXCLUDED'
                              WHEN c.n >= st.mn THEN N'PASS' ELSE N'FAIL' END AS outcome) o
     WHERE (@kpi_code IS NULL OR @kpi_code = N'RELATIONSHIP_COMPLETENESS')
       AND b.organization_id = @organization_id AND st.mn > 0

    UNION ALL
    -- 5. Coverage Compliance (435): assets of a type with a Required coverage requirement.
    SELECT N'COVERAGE_COMPLIANCE', N'ASSET', p.AssetId, p.AssetName, o.outcome,
           CASE WHEN o.outcome = N'PASS' THEN 1 ELSE 0 END,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE 1 END,
           CAST(CASE WHEN p.ExclusionReason IS NOT NULL THEN p.ExclusionReason
                     WHEN o.outcome = N'FAIL' THEN g.msg END AS NVARCHAR(1000))
      FROM grac_practice.fn_asset_governance_assets(@organization_id) p
     CROSS APPLY (SELECT COUNT(*) AS req FROM grac_practice.asset_coverage_requirement r
                   WHERE r.organization_id = @organization_id AND r.asset_type_id = p.AssetTypeId AND r.requirement_level = N'REQUIRED') q
      LEFT JOIN (SELECT cg.AssetId, COUNT(*) AS gaps, STRING_AGG(CAST(cg.Message AS NVARCHAR(MAX)), N' ') AS msg
                   FROM grac_practice.fn_asset_coverage_gaps(@organization_id) cg
                  GROUP BY cg.AssetId) g ON g.AssetId = p.AssetId
     CROSS APPLY (SELECT CASE WHEN p.ExclusionReason IS NOT NULL THEN N'EXCLUDED'
                              WHEN ISNULL(g.gaps, 0) = 0 THEN N'PASS' ELSE N'FAIL' END AS outcome) o
     WHERE (@kpi_code IS NULL OR @kpi_code = N'COVERAGE_COMPLIANCE') AND q.req > 0

    UNION ALL
    -- 6. Technology Support Compliance (430 classification).
    SELECT N'TECHNOLOGY_SUPPORT', N'ASSET', p.AssetId, p.AssetName, o.outcome,
           CASE WHEN o.outcome = N'PASS' THEN 1 ELSE 0 END,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE 1 END,
           CAST(CASE WHEN p.ExclusionReason IS NOT NULL THEN p.ExclusionReason
                     WHEN o.outcome = N'FAIL' THEN t.why END AS NVARCHAR(1000))
      FROM grac_practice.fn_asset_governance_assets(@organization_id) p
      JOIN (SELECT ts.AssetId,
                   SUM(CASE WHEN ts.Classification <> N'NOT_APPLICABLE' THEN 1 ELSE 0 END) AS app,
                   SUM(CASE WHEN ts.Classification IN (N'UNSUPPORTED', N'UNKNOWN') THEN 1 ELSE 0 END) AS bad,
                   STRING_AGG(CASE WHEN ts.Classification IN (N'UNSUPPORTED', N'UNKNOWN')
                                   THEN CAST(CONCAT(CASE ts.Kind WHEN N'FIRMWARE' THEN N'Firmware' ELSE N'Operating system' END,
                                                    CASE ts.Classification WHEN N'UNKNOWN' THEN N' unknown: ' ELSE N' unsupported: ' END,
                                                    ISNULL(ts.CurrentLabel + N' - ', N''), ts.ClassificationReason) AS NVARCHAR(MAX)) END, N' ') AS why
              FROM grac_practice.fn_asset_technology_status(@organization_id, NULL) ts
             GROUP BY ts.AssetId) t ON t.AssetId = p.AssetId
     CROSS APPLY (SELECT CASE WHEN p.ExclusionReason IS NOT NULL THEN N'EXCLUDED'
                              WHEN t.bad = 0 THEN N'PASS' ELSE N'FAIL' END AS outcome) o
     WHERE (@kpi_code IS NULL OR @kpi_code = N'TECHNOLOGY_SUPPORT') AND t.app > 0

    UNION ALL
    -- 7. Exception Health (430, 432, 439, 447, 448): overdue or expired exceptions.
    SELECT N'EXCEPTION_HEALTH', N'ASSET', p.AssetId, p.AssetName, o.outcome,
           CASE WHEN o.outcome = N'PASS' THEN 1 ELSE 0 END,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE 1 END,
           CAST(CASE WHEN p.ExclusionReason IS NOT NULL THEN p.ExclusionReason
                     WHEN o.outcome = N'FAIL' THEN ex.msg END AS NVARCHAR(1000))
      FROM grac_practice.fn_asset_governance_assets(@organization_id) p
      LEFT JOIN (SELECT f.asset_id, COUNT(*) AS n, STRING_AGG(f.msg, N' ') AS msg
                   FROM (
                        -- technology: expired and still relied on, or in use and past its review date
                        SELECT ts.AssetId AS asset_id,
                               CAST(CONCAT(N'Technology exception #', e.exception_id, N' (',
                                           CASE ts.Kind WHEN N'FIRMWARE' THEN N'firmware' ELSE N'operating system' END, N') ',
                                           CASE WHEN ts.Classification = N'UNSUPPORTED'
                                                THEN CONCAT(N'expired on ', CONVERT(NVARCHAR(10), e.expiry_date, 23), N' and the version is still unsupported.')
                                                ELSE CONCAT(N'was due for review on ', CONVERT(NVARCHAR(10), e.review_date, 23), N'.') END) AS NVARCHAR(MAX)) AS msg
                          FROM grac_practice.fn_asset_technology_status(@organization_id, NULL) ts
                          JOIN grac_practice.asset_technology_exception e
                            ON e.organization_id = @organization_id AND e.technology_kind = ts.Kind AND e.status = N'APPROVED'
                           AND ((ts.Kind = N'FIRMWARE' AND e.firmware_release_id = ts.CurrentReleaseId)
                                OR (ts.Kind = N'OS' AND e.os_release_id = ts.CurrentReleaseId))
                           AND (e.asset_id = ts.AssetId OR (e.asset_id IS NULL AND e.model_id = ts.ModelId))
                         WHERE (ts.Classification = N'UNSUPPORTED' AND e.expiry_date < CAST(SYSUTCDATETIME() AS DATE))
                            OR (e.exception_id = ts.ExceptionId AND e.review_date < CAST(SYSUTCDATETIME() AS DATE))
                        UNION ALL
                        -- verification exception past its resolution due date (432 overdue rule)
                        SELECT x.asset_id,
                               CAST(CONCAT(N'Verification exception #', x.exception_id, N' was due for resolution on ',
                                           CONVERT(NVARCHAR(10), x.resolution_due, 23), N'.') AS NVARCHAR(MAX))
                          FROM grac_practice.asset_verification_exception x
                          JOIN grac_practice.entity_status_master s ON s.entity_status_id = x.current_status_id
                         WHERE x.organization_id = @organization_id AND s.is_terminal = 0
                           AND s.status_code NOT IN (N'RESOLVED', N'AWAITING_EVIDENCE')
                           AND x.resolution_due < CAST(SYSUTCDATETIME() AS DATE)
                        UNION ALL
                        -- approved activity exception past its review date (439), not replaced by a later decision
                        SELECT ao.asset_id,
                               CAST(CONCAT(N'Activity exception #', d.disposition_id, N' was due for review on ',
                                           CONVERT(NVARCHAR(10), d.review_date, 23), N'.') AS NVARCHAR(MAX))
                          FROM grac_practice.asset_activity_disposition d
                          JOIN grac_practice.asset_activity_occurrence ao ON ao.occurrence_id = d.occurrence_id
                         WHERE d.organization_id = @organization_id AND d.disposition_type = N'EXCEPTION' AND d.status = N'APPROVED'
                           AND d.review_date < CAST(SYSUTCDATETIME() AS DATE)
                           AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_activity_disposition d2
                                            WHERE d2.occurrence_id = d.occurrence_id AND d2.disposition_id > d.disposition_id
                                              AND d2.status = N'APPROVED')
                        UNION ALL
                        -- consistency acceptance past its review date, or reopened by it and not accepted again (447)
                        SELECT cf.asset_id,
                               CAST(CONCAT(N'Consistency finding #', cf.finding_id,
                                           CASE WHEN cf.status = N'ACCEPTED'
                                                THEN CONCAT(N' acceptance passed its review date ', CONVERT(NVARCHAR(10), cf.review_date, 23), N'.')
                                                ELSE N' was accepted, passed its review date and is open again.' END) AS NVARCHAR(MAX))
                          FROM grac_practice.asset_consistency_finding cf
                         WHERE cf.organization_id = @organization_id
                           AND ((cf.status = N'ACCEPTED' AND cf.review_date < CAST(SYSUTCDATETIME() AS DATE))
                                OR (cf.status = N'OPEN' AND cf.reopened_count > 0))
                        UNION ALL
                        -- privacy exception past its expiry, or expired while the gap is still open (448)
                        SELECT px.asset_id,
                               CAST(CONCAT(N'Privacy exception #', px.exception_id, N' (', rq.requirement_name, N') ',
                                           CASE WHEN px.status = N'APPROVED'
                                                THEN CONCAT(N'passed its expiry date ', CONVERT(NVARCHAR(10), px.expiry_date, 23), N'.')
                                                ELSE N'expired and the gap is still open.' END) AS NVARCHAR(MAX))
                          FROM grac_practice.asset_privacy_exception px
                          JOIN grac_practice.asset_privacy_requirement rq ON rq.requirement_code = px.requirement_code
                         WHERE px.organization_id = @organization_id
                           AND ((px.status = N'APPROVED' AND px.expiry_date < CAST(SYSUTCDATETIME() AS DATE))
                                OR (px.status = N'EXPIRED'
                                    AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_privacy_exception py
                                                     WHERE py.asset_id = px.asset_id AND py.requirement_code = px.requirement_code
                                                       AND py.exception_id > px.exception_id
                                                       AND py.status IN (N'PENDING_APPROVAL', N'APPROVED', N'EXPIRED'))
                                    AND EXISTS (SELECT 1 FROM grac_practice.fn_asset_privacy_gaps(@organization_id, px.asset_id) pg
                                                 WHERE pg.RequirementCode = px.requirement_code AND pg.IsExcepted = 0)))
                        ) f
                  GROUP BY f.asset_id) ex ON ex.asset_id = p.AssetId
     CROSS APPLY (SELECT CASE WHEN p.ExclusionReason IS NOT NULL THEN N'EXCLUDED'
                              WHEN ISNULL(ex.n, 0) = 0 THEN N'PASS' ELSE N'FAIL' END AS outcome) o
     WHERE (@kpi_code IS NULL OR @kpi_code = N'EXCEPTION_HEALTH')

    UNION ALL
    -- 8. Discovery Freshness (442 / 443 freshness rule): assets linked to a source.
    SELECT N'DISCOVERY_FRESHNESS', N'ASSET', p.AssetId, p.AssetName, o.outcome,
           CASE WHEN o.outcome = N'PASS' THEN 1 ELSE 0 END,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE 1 END,
           CAST(CASE WHEN p.ExclusionReason IS NOT NULL THEN p.ExclusionReason
                     WHEN o.outcome = N'FAIL' THEN CONCAT(N'No source observed it within its expected interval x ', st.sm,
                                                          N'; last observed ', CONVERT(NVARCHAR(16), l.last_seen, 120), N' UTC.') END AS NVARCHAR(1000))
      FROM grac_practice.fn_asset_governance_assets(@organization_id) p
     CROSS APPLY (SELECT ISNULL((SELECT MAX(x.stale_multiplier) FROM grac_practice.asset_discovery_setting x
                                  WHERE x.organization_id = @organization_id), 3) AS sm) st
     -- the freshness flag is computed per link first (Msg 8124, as 442 / 443).
     CROSS APPLY (SELECT COUNT(*) AS links, MAX(k.last_seen_dt) AS last_seen, SUM(fr.is_fresh) AS fresh
                    FROM grac_practice.asset_discovery_link k
                    JOIN grac_practice.asset_discovery_source src ON src.source_id = k.source_id
                   CROSS APPLY (SELECT CASE WHEN k.last_seen_dt >= DATEADD(HOUR, -src.expected_interval_hours * st.sm, SYSUTCDATETIME())
                                            THEN 1 ELSE 0 END AS is_fresh) fr
                   WHERE k.asset_id = p.AssetId) l
     CROSS APPLY (SELECT CASE WHEN p.ExclusionReason IS NOT NULL THEN N'EXCLUDED'
                              WHEN ISNULL(l.fresh, 0) > 0 THEN N'PASS' ELSE N'FAIL' END AS outcome) o
     WHERE (@kpi_code IS NULL OR @kpi_code = N'DISCOVERY_FRESHNESS') AND l.links > 0

    UNION ALL
    -- 9. Reconciliation Backlog Rate (442): raised in the period, or still open. Lower is better.
    SELECT N'RECONCILIATION_BACKLOG', N'RECONCILIATION', e.exception_id,
           CAST(CONCAT(CASE e.exception_kind WHEN N'SUGGESTED_MATCH' THEN N'Suggested match' WHEN N'MANUAL_REVIEW' THEN N'Manual review'
                                             WHEN N'NEW_CANDIDATE' THEN N'New candidate' WHEN N'DUPLICATE' THEN N'Potential duplicate'
                                             ELSE N'Conflict' END, N' - ',
                       COALESCE(a.asset_name, e.external_key, CONCAT(N'observation #', e.observation_id)),
                       CASE WHEN e.field_key IS NULL THEN N'' ELSE CONCAT(N' [', e.field_key, N']') END,
                       N' (', src.source_name, N')') AS NVARCHAR(400)),
           CASE WHEN e.status = N'OPEN' THEN N'FAIL' ELSE N'PASS' END,
           CASE WHEN e.status = N'OPEN' THEN 1 ELSE 0 END,
           1,
           CAST(CASE WHEN e.status = N'OPEN'
                     THEN CONCAT(N'Open since ', CONVERT(NVARCHAR(10), e.entered_dt, 23),
                                 CASE WHEN e.raised_count > 1 THEN CONCAT(N'; observed ', e.raised_count, N' times') ELSE N'' END, N'.')
                     ELSE CONCAT(N'Resolved ', CONVERT(NVARCHAR(10), e.resolved_dt, 23),
                                 CASE WHEN e.resolution IS NULL THEN N'' ELSE CONCAT(N' (', LOWER(e.resolution), N')') END, N'.') END AS NVARCHAR(1000))
      FROM grac_practice.asset_reconciliation_exception e
      JOIN grac_practice.asset_discovery_source src ON src.source_id = e.source_id
      LEFT JOIN grac_practice.organization_dependency_asset a ON a.asset_id = e.asset_id
     CROSS APPLY (SELECT ef.PeriodDays AS p FROM grac_practice.fn_asset_governance_effective(@organization_id) ef
                   WHERE ef.KpiCode = N'RECONCILIATION_BACKLOG') pd
     WHERE (@kpi_code IS NULL OR @kpi_code = N'RECONCILIATION_BACKLOG')
       AND e.organization_id = @organization_id
       AND (e.status = N'OPEN' OR e.entered_dt >= DATEADD(DAY, -pd.p, SYSUTCDATETIME()))

    UNION ALL
    -- 10. Connector Availability (442): expected intervals of each active source with a completed batch.
    SELECT N'CONNECTOR_AVAILABILITY', N'SOURCE', s.source_id, CAST(CONCAT(s.source_code, N' - ', s.source_name) AS NVARCHAR(400)),
           o.outcome,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE r.ok END,
           CASE WHEN o.outcome = N'EXCLUDED' THEN 0 ELSE sl.slots END,
           CAST(CASE o.outcome
                WHEN N'EXCLUDED' THEN CASE WHEN s.is_active = 0 THEN N'Inactive source.' ELSE N'Added less than one expected interval ago.' END
                WHEN N'FAIL' THEN CONCAT(sl.slots - r.ok, N' of ', sl.slots, N' expected runs (every ', s.expected_interval_hours,
                                         N' h) had no completed batch',
                                         CASE WHEN s.last_run_dt IS NULL THEN N'; never run'
                                              ELSE CONCAT(N'; last run ', CONVERT(NVARCHAR(16), s.last_run_dt, 120), N' UTC, ',
                                                          LOWER(ISNULL(s.last_run_status, N'unknown'))) END, N'.') END AS NVARCHAR(1000))
      FROM grac_practice.asset_discovery_source s
     CROSS APPLY (SELECT ef.PeriodDays AS p FROM grac_practice.fn_asset_governance_effective(@organization_id) ef
                   WHERE ef.KpiCode = N'CONNECTOR_AVAILABILITY') pd
     CROSS APPLY (SELECT CASE WHEN s.entered_dt > DATEADD(DAY, -pd.p, SYSUTCDATETIME()) THEN s.entered_dt
                              ELSE DATEADD(DAY, -pd.p, SYSUTCDATETIME()) END AS ws) w
     CROSS APPLY (SELECT DATEDIFF(HOUR, w.ws, SYSUTCDATETIME()) / s.expected_interval_hours AS slots) sl
     -- the interval of each batch is computed per row first (Msg 8124).
     CROSS APPLY (SELECT COUNT(DISTINCT bi.slot) AS ok
                    FROM grac_practice.asset_discovery_batch b
                   CROSS APPLY (SELECT DATEDIFF(HOUR, w.ws, b.received_dt) / s.expected_interval_hours AS slot) bi
                   WHERE b.source_id = s.source_id AND b.status = N'COMPLETED' AND b.received_dt >= w.ws AND bi.slot < sl.slots) r
     CROSS APPLY (SELECT CASE WHEN s.is_active = 0 OR sl.slots < 1 THEN N'EXCLUDED'
                              WHEN r.ok >= sl.slots THEN N'PASS' ELSE N'FAIL' END AS outcome) o
     WHERE (@kpi_code IS NULL OR @kpi_code = N'CONNECTOR_AVAILABILITY')
       AND s.organization_id = @organization_id;
GO
PRINT '450: KPI functions created.';
GO
