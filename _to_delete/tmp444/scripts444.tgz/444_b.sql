
-- =====================================================================
-- 3. Blockers, plan, field comparison, impact (D116-D118)
-- =====================================================================
-- What stops merging @duplicate into @survivor: invalid assets, and open
-- items of the duplicate that cannot move silently (19.4 "open workflow
-- items shall be explicitly reassigned or linked") -- they are finished,
-- cancelled or withdrawn first.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_merge_blockers (@organization_id BIGINT, @survivor BIGINT, @duplicate BIGINT)
RETURNS TABLE
AS
RETURN
    WITH a AS (
        SELECT x.asset_id, x.asset_name, x.merged_into_asset_id, ISNULL(s.status_code, N'ACTIVE') AS status_code
          FROM grac_practice.organization_dependency_asset x
          LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = x.current_status_id
         WHERE x.organization_id = @organization_id AND x.asset_id IN (@survivor, @duplicate))
    SELECT CAST(N'SAME_ASSET' AS NVARCHAR(30)) AS BlockerCode,
           CAST(N'The survivor cannot also be a duplicate.' AS NVARCHAR(600)) AS Detail
     WHERE @survivor = @duplicate
    UNION ALL
    SELECT N'NOT_FOUND', CAST(CONCAT(N'Asset #', v.id, N' is not an asset of this organization.') AS NVARCHAR(600))
      FROM (VALUES (@survivor), (@duplicate)) v(id)
     WHERE NOT EXISTS (SELECT 1 FROM a WHERE a.asset_id = v.id)
    UNION ALL
    SELECT N'NOT_IN_USE', CAST(CONCAT(a.asset_name, N' is ', LOWER(a.status_code), N' or already merged.') AS NVARCHAR(600))
      FROM a WHERE a.status_code IN (N'DISPOSED', N'ARCHIVED') OR a.merged_into_asset_id IS NOT NULL
    UNION ALL
    SELECT N'PENDING_LIFECYCLE', CAST(CONCAT(N'Lifecycle change ', c.from_status_code, N' -> ', c.to_status_code,
                                             N' awaits approval; approve, reject or cancel it.') AS NVARCHAR(600))
      FROM grac_practice.asset_lifecycle_change c WHERE c.asset_id = @duplicate AND c.change_status = N'PENDING_APPROVAL'
    UNION ALL
    SELECT N'OPEN_WORKFLOW', CAST(CONCAT(N'Workflow case #', w.case_id, N' (', w.workflow_code, N') is open; complete or cancel it.') AS NVARCHAR(600))
      FROM grac_practice.asset_workflow_case w WHERE w.asset_id = @duplicate AND w.case_status = N'OPEN'
    UNION ALL
    SELECT N'OPEN_ATTESTATION', CAST(CONCAT(N'Attestation #', t.attestation_id, N' is ', LOWER(t.status), N'; complete or cancel it.') AS NVARCHAR(600))
      FROM grac_practice.asset_attestation t
     WHERE t.asset_id = @duplicate AND t.status NOT IN (N'CONFIRMED', N'RESOLVED', N'CLOSED', N'CANCELLED')
    UNION ALL
    SELECT N'OPEN_VERIFICATION', CAST(CONCAT(N'Verification exception #', e.exception_id, N' is ', LOWER(s.status_code), N'; resolve or cancel it.') AS NVARCHAR(600))
      FROM grac_practice.asset_verification_exception e
      JOIN grac_practice.entity_status_master s ON s.entity_status_id = e.current_status_id
     WHERE e.asset_id = @duplicate AND s.status_code NOT IN (N'RESOLVED', N'CLOSED', N'CANCELLED')
    UNION ALL
    SELECT N'PENDING_TECH_EXCEPTION', CAST(CONCAT(N'Technology exception #', x.exception_id, N' awaits approval; decide or withdraw it.') AS NVARCHAR(600))
      FROM grac_practice.asset_technology_exception x WHERE x.asset_id = @duplicate AND x.status = N'PENDING_APPROVAL'
    UNION ALL
    SELECT N'OPEN_STALE_REVIEW', CAST(N'A stale review is open; dismiss or complete it.' AS NVARCHAR(600))
      FROM grac_practice.asset_stale_review r WHERE r.asset_id = @duplicate AND r.status = N'OPEN'
    UNION ALL
    SELECT N'OCCURRENCE_CONFLICT', CAST(CONCAT(N'Both assets have an open "', o.template_code, N'" activity; complete or cancel one.') AS NVARCHAR(600))
      FROM grac_practice.asset_activity_occurrence o
     WHERE o.asset_id = @duplicate AND o.status = N'OPEN'
       AND EXISTS (SELECT 1 FROM grac_practice.asset_activity_occurrence o2
                    WHERE o2.asset_id = @survivor AND o2.template_code = o.template_code AND o2.status = N'OPEN')
    UNION ALL
    SELECT N'RESTRICTIVE_CONFLICT', CAST(CONCAT(N'Both assets have an active restrictive-use review "', rr.title, N'"; decide one.') AS NVARCHAR(600))
      FROM grac_practice.asset_restrictive_review rr
     WHERE rr.asset_id = @duplicate AND rr.status IN (N'OPEN', N'DECIDED')
       AND EXISTS (SELECT 1 FROM grac_practice.asset_restrictive_review r2
                    WHERE r2.asset_id = @survivor AND r2.status IN (N'OPEN', N'DECIDED') AND r2.source_kind = rr.source_kind
                      AND r2.source_code = rr.source_code AND r2.trigger_code = rr.trigger_code);
GO

-- The plan for one duplicate: every object that refers to it and what an
-- execution does with it now (preview and execution read the same rows).
--   MOVE     repointed to the survivor
--   END      relationship retired: it would join the survivor to itself or
--            duplicate a current survivor relationship
--   RESOLVE  open duplicate review of the survivor / duplicate pair closed
--   KEEP     stays with the merged record (the survivor already holds the
--            equivalent, or it belongs to a closed contract version)
CREATE OR ALTER FUNCTION grac_practice.fn_asset_merge_plan (@organization_id BIGINT, @survivor BIGINT, @duplicate BIGINT)
RETURNS TABLE
AS
RETURN
    -- relationships (5.4): new endpoints computed first
    SELECT CAST(N'RELATIONSHIP' AS NVARCHAR(20)) AS ObjectKind, r.relationship_id AS ObjectId,
           CAST(NULL AS NVARCHAR(200)) AS ObjectKey,
           CAST(CONCAT(t.type_name, N': ', CASE WHEN r.source_kind = N'ASSET' AND r.source_id = @duplicate THEN N'(this asset)'
                                                ELSE ISNULL(cs.CiName, CONCAT(r.source_kind, N' #', r.source_id)) END,
                       N' -> ', CASE WHEN r.target_kind = N'ASSET' AND r.target_id = @duplicate THEN N'(this asset)'
                                     ELSE ISNULL(ct.CiName, CONCAT(r.target_kind, N' #', r.target_id)) END) AS NVARCHAR(400)) AS ObjectLabel,
           CAST(CASE WHEN n.ns_kind = N'ASSET' AND n.ns_id = @survivor AND n.nt_kind = N'ASSET' AND n.nt_id = @survivor THEN N'END'
                     WHEN EXISTS (SELECT 1 FROM grac_practice.asset_relationship q
                                   WHERE q.organization_id = r.organization_id AND q.relationship_id <> r.relationship_id
                                     AND q.relationship_type_code = r.relationship_type_code AND q.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')
                                     AND q.source_kind = n.ns_kind AND q.source_id = n.ns_id AND q.target_kind = n.nt_kind AND q.target_id = n.nt_id)
                          THEN N'END' ELSE N'MOVE' END AS NVARCHAR(10)) AS Outcome,
           CAST(CONCAT(LOWER(r.status), CASE WHEN r.is_critical = 1 THEN N', critical' ELSE N'' END,
                       CASE WHEN n.ns_kind = N'ASSET' AND n.ns_id = @survivor AND n.nt_kind = N'ASSET' AND n.nt_id = @survivor
                            THEN N' (joins the two merged assets)' ELSE N'' END) AS NVARCHAR(600)) AS Detail,
           CAST(N'Relationships and services' AS NVARCHAR(40)) AS Domain
      FROM grac_practice.asset_relationship r
      JOIN grac_practice.asset_relationship_type t ON t.type_code = r.relationship_type_code
     CROSS APPLY (SELECT CASE WHEN r.source_kind = N'ASSET' AND r.source_id = @duplicate THEN N'ASSET' ELSE r.source_kind END AS ns_kind,
                         CASE WHEN r.source_kind = N'ASSET' AND r.source_id = @duplicate THEN @survivor ELSE r.source_id END AS ns_id,
                         CASE WHEN r.target_kind = N'ASSET' AND r.target_id = @duplicate THEN N'ASSET' ELSE r.target_kind END AS nt_kind,
                         CASE WHEN r.target_kind = N'ASSET' AND r.target_id = @duplicate THEN @survivor ELSE r.target_id END AS nt_id) n
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) cs ON cs.CiKind = r.source_kind AND cs.CiId = r.source_id
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) ct ON ct.CiKind = r.target_kind AND ct.CiId = r.target_id
     WHERE r.organization_id = @organization_id AND r.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')
       AND ((r.source_kind = N'ASSET' AND r.source_id = @duplicate) OR (r.target_kind = N'ASSET' AND r.target_id = @duplicate))
    UNION ALL
    -- discovery source links (442)
    SELECT N'DISCOVERY_LINK', l.link_id, l.external_key, CAST(CONCAT(s.source_name, N': ', l.external_key) AS NVARCHAR(400)),
           N'MOVE', CAST(CONCAT(N'last seen ', CONVERT(NVARCHAR(16), l.last_seen_dt, 120)) AS NVARCHAR(600)), N'Discovery and integrations'
      FROM grac_practice.asset_discovery_link l
      JOIN grac_practice.asset_discovery_source s ON s.source_id = l.source_id
     WHERE l.asset_id = @duplicate
    UNION ALL
    -- values reported per source (442)
    SELECT N'ATTRIBUTE_SOURCE', x.source_id, x.field_key, CAST(CONCAT(s.source_name, N': ', x.field_key) AS NVARCHAR(400)),
           CASE WHEN EXISTS (SELECT 1 FROM grac_practice.asset_attribute_source y
                              WHERE y.asset_id = @survivor AND y.field_key = x.field_key AND y.source_id = x.source_id)
                THEN N'KEEP' ELSE N'MOVE' END,
           CAST(LEFT(x.observed_value, 400) AS NVARCHAR(600)), N'Discovery and integrations'
      FROM grac_practice.asset_attribute_source x
      JOIN grac_practice.asset_discovery_source s ON s.source_id = x.source_id
     WHERE x.asset_id = @duplicate
    UNION ALL
    -- open reconciliation exceptions (442)
    SELECT N'RECON_EXCEPTION', e.exception_id, NULL,
           CAST(CONCAT(e.exception_kind, CASE WHEN e.field_key IS NULL THEN N'' ELSE N' - ' + e.field_key END) AS NVARCHAR(400)),
           CASE WHEN e.exception_kind = N'DUPLICATE'
                 AND ((e.asset_id = @duplicate AND e.other_asset_id = @survivor) OR (e.asset_id = @survivor AND e.other_asset_id = @duplicate))
                THEN N'RESOLVE' ELSE N'MOVE' END,
           CAST(N'open' AS NVARCHAR(600)), N'Tasks and open items'
      FROM grac_practice.asset_reconciliation_exception e
     WHERE e.organization_id = @organization_id AND e.status = N'OPEN' AND (e.asset_id = @duplicate OR e.other_asset_id = @duplicate)
    UNION ALL
    -- contract coverage (435): lines of contract versions still in force or in preparation move
    SELECT N'COVERAGE', cv.coverage_id, cv.coverage_type,
           CAST(CONCAT(k.contract_number, N' ', k.contract_name, N' v', v.version_no, N' - ', cv.coverage_type) AS NVARCHAR(400)),
           CASE WHEN vs.status_code NOT IN (N'DRAFT', N'IN_REVIEW', N'PENDING_APPROVAL', N'APPROVED', N'ACTIVE') THEN N'KEEP'
                WHEN EXISTS (SELECT 1 FROM grac_practice.asset_contract_coverage c2
                              WHERE c2.version_id = cv.version_id AND c2.asset_id = @survivor AND c2.coverage_type = cv.coverage_type)
                THEN N'KEEP' ELSE N'MOVE' END,
           CAST(CONCAT(LOWER(vs.status_code), N' version, ', LOWER(cv.coverage_state)) AS NVARCHAR(600)), N'Contracts'
      FROM grac_practice.asset_contract_coverage cv
      JOIN grac_practice.asset_contract_version v ON v.version_id = cv.version_id
      JOIN grac_practice.entity_status_master vs ON vs.entity_status_id = v.current_status_id
      JOIN grac_practice.asset_contract k ON k.contract_id = cv.contract_id
     WHERE cv.asset_id = @duplicate AND k.organization_id = @organization_id
    UNION ALL
    -- open activity occurrences (438) -- their Task Centre tasks follow
    SELECT N'OCCURRENCE', o.occurrence_id, o.template_code,
           CAST(CONCAT(tp.template_name, N' due ', CONVERT(NVARCHAR(10), o.due_date, 23)) AS NVARCHAR(400)),
           CASE WHEN EXISTS (SELECT 1 FROM grac_practice.asset_activity_occurrence o2
                              WHERE o2.asset_id = @survivor AND o2.template_code = o.template_code AND o2.status = N'OPEN')
                THEN N'BLOCK' ELSE N'MOVE' END,
           CAST(CASE WHEN o.task_id IS NULL THEN N'open' ELSE CONCAT(N'open, task #', o.task_id) END AS NVARCHAR(600)), N'Tasks and open items'
      FROM grac_practice.asset_activity_occurrence o
      JOIN grac_practice.asset_activity_template tp ON tp.template_code = o.template_code
     WHERE o.asset_id = @duplicate AND o.status = N'OPEN' AND o.organization_id = @organization_id
    UNION ALL
    -- active restrictive-use reviews (439)
    SELECT N'RESTRICTIVE_REVIEW', rr.review_id, rr.review_key, CAST(rr.title AS NVARCHAR(400)),
           CASE WHEN EXISTS (SELECT 1 FROM grac_practice.asset_restrictive_review r2
                              WHERE r2.asset_id = @survivor AND r2.status IN (N'OPEN', N'DECIDED') AND r2.source_kind = rr.source_kind
                                AND r2.source_code = rr.source_code AND r2.trigger_code = rr.trigger_code)
                THEN N'BLOCK' ELSE N'MOVE' END,
           CAST(LOWER(rr.status) AS NVARCHAR(600)), N'Tasks and open items'
      FROM grac_practice.asset_restrictive_review rr
     WHERE rr.asset_id = @duplicate AND rr.status IN (N'OPEN', N'DECIDED') AND rr.organization_id = @organization_id
    UNION ALL
    -- risk dependency mappings, category Asset (265)
    SELECT N'RISK_MAP', m.risk_dependency_map_id, NULL, CAST(CONCAT(r.risk_number, N' ', r.risk_title) AS NVARCHAR(400)),
           CASE WHEN EXISTS (SELECT 1 FROM grac_practice.risk_dependency_map m2
                              WHERE m2.risk_register_id = m.risk_register_id AND m2.dependency_type_id = m.dependency_type_id
                                AND m2.dependency_object_id = @survivor)
                THEN N'KEEP' ELSE N'MOVE' END,
           CAST(CONCAT(N'risk status ', r.status_code) AS NVARCHAR(600)), N'Risks'
      FROM grac_practice.risk_dependency_map m
      JOIN grac_practice.dependency_type_master dt ON dt.dependency_type_id = m.dependency_type_id
                                                  AND (dt.dependency_type_code = N'ASSET' OR dt.dependency_type_name = N'Asset')
      JOIN grac_practice.risk_register r ON r.risk_register_id = m.risk_register_id
     WHERE m.dependency_object_id = @duplicate AND m.organization_id = @organization_id
    UNION ALL
    -- risks whose linked asset is the duplicate (205)
    SELECT N'RISK_LINK', r.risk_register_id, NULL, CAST(CONCAT(r.risk_number, N' ', r.risk_title) AS NVARCHAR(400)), N'MOVE',
           CAST(CONCAT(N'risk status ', r.status_code) AS NVARCHAR(600)), N'Risks'
      FROM grac_practice.risk_register r
     WHERE r.linked_asset_id = @duplicate AND r.organization_id = @organization_id
    UNION ALL
    -- practice dependency resolutions, category Asset (002 Operationalize)
    SELECT N'PRACTICE_RESOLUTION', p.resolution_id, NULL,
           CAST(CONCAT(N'Practice instance #', p.practice_instance_id, N' - ', p.resolved_dependency_name) AS NVARCHAR(400)),
           CASE WHEN EXISTS (SELECT 1 FROM grac_practice.practice_dependency_resolution p2
                              WHERE p2.organization_id = p.organization_id AND p2.practice_instance_id = p.practice_instance_id
                                AND p2.dependency_type_id = p.dependency_type_id AND p2.resolved_dependency_id = @survivor)
                THEN N'KEEP' ELSE N'MOVE' END,
           CAST(p.resolution_status AS NVARCHAR(600)), N'Practices and obligations'
      FROM grac_practice.practice_dependency_resolution p
      JOIN grac_practice.dependency_type_master dt ON dt.dependency_type_id = p.dependency_type_id
                                                  AND (dt.dependency_type_code = N'ASSET' OR dt.dependency_type_name = N'Asset')
     WHERE p.resolved_dependency_id = @duplicate AND p.organization_id = @organization_id;
GO

-- Field comparison of one duplicate with the survivor (value fields; user-
-- entered types only are mergeable). Make / model show their names.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_merge_fields (@survivor BIGINT, @duplicate BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT f.field_key AS FieldKey, f.display_label AS FieldLabel, f.data_type_code AS DataTypeCode,
           sv.value_text AS SurvivorValue, dv.value_text AS DuplicateValue,
           CAST(COALESCE(sm.make_name, so.model_name, LEFT(sv.value_text, 400)) AS NVARCHAR(400)) AS SurvivorDisplay,
           CAST(COALESCE(dm.make_name, dd.model_name, LEFT(dv.value_text, 400)) AS NVARCHAR(400)) AS DuplicateDisplay,
           CAST(CASE WHEN dt.is_user_entered = 1 AND f.is_system_field = 0 THEN 1 ELSE 0 END AS BIT) AS IsMergeable,
           CAST(CASE WHEN sv.value_text IS NULL THEN 0 WHEN dv.value_text IS NULL THEN 0
                     WHEN sv.value_text = dv.value_text THEN 0 ELSE 1 END AS BIT) AS IsDifferent
      FROM grac_practice.asset_field_definition f
      JOIN grac_practice.asset_field_data_type_master dt ON dt.data_type_code = f.data_type_code
      LEFT JOIN grac_practice.asset_field_value sv ON sv.asset_id = @survivor AND sv.field_definition_id = f.field_definition_id
      LEFT JOIN grac_practice.asset_field_value dv ON dv.asset_id = @duplicate AND dv.field_definition_id = f.field_definition_id
      LEFT JOIN grac_practice.asset_make sm ON f.data_type_code = N'MAKE' AND sm.make_id = TRY_CONVERT(INT, sv.value_text)
      LEFT JOIN grac_practice.asset_model so ON f.data_type_code = N'MODEL' AND so.model_id = TRY_CONVERT(BIGINT, sv.value_text)
      LEFT JOIN grac_practice.asset_make dm ON f.data_type_code = N'MAKE' AND dm.make_id = TRY_CONVERT(INT, dv.value_text)
      LEFT JOIN grac_practice.asset_model dd ON f.data_type_code = N'MODEL' AND dd.model_id = TRY_CONVERT(BIGINT, dv.value_text)
     WHERE f.storage_kind = N'VALUE' AND (sv.asset_id IS NOT NULL OR dv.asset_id IS NOT NULL);
GO

-- Impact per asset (19.4 impact analysis): what refers to it, by domain --
-- what moves (plan) and what stays as history with the merged record.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_merge_impact (@organization_id BIGINT, @asset_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT CAST(N'Business services supported' AS NVARCHAR(60)) AS ImpactItem,
           (SELECT COUNT(*) FROM grac_practice.asset_relationship r
             WHERE r.organization_id = @organization_id AND r.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')
               AND ((r.source_kind = N'ASSET' AND r.source_id = @asset_id AND r.target_kind = N'SERVICE')
                    OR (r.target_kind = N'ASSET' AND r.target_id = @asset_id AND r.source_kind = N'SERVICE'))) AS ItemCount, 10 AS SortOrder
    UNION ALL SELECT N'Current relationships', (SELECT COUNT(*) FROM grac_practice.asset_relationship r
             WHERE r.organization_id = @organization_id AND r.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')
               AND ((r.source_kind = N'ASSET' AND r.source_id = @asset_id) OR (r.target_kind = N'ASSET' AND r.target_id = @asset_id))), 20
    UNION ALL SELECT N'Contract coverage lines', (SELECT COUNT(*) FROM grac_practice.asset_contract_coverage c WHERE c.asset_id = @asset_id), 30
    UNION ALL SELECT N'Risks (mapped or linked)', (SELECT COUNT(*) FROM grac_practice.risk_dependency_map m
              JOIN grac_practice.dependency_type_master dt ON dt.dependency_type_id = m.dependency_type_id
                                                          AND (dt.dependency_type_code = N'ASSET' OR dt.dependency_type_name = N'Asset')
             WHERE m.dependency_object_id = @asset_id AND m.organization_id = @organization_id)
            + (SELECT COUNT(*) FROM grac_practice.risk_register r WHERE r.linked_asset_id = @asset_id AND r.organization_id = @organization_id), 40
    UNION ALL SELECT N'Attestations', (SELECT COUNT(*) FROM grac_practice.asset_attestation t WHERE t.asset_id = @asset_id), 50
    UNION ALL SELECT N'Open tasks (activities, reconciliation)',
            (SELECT COUNT(*) FROM grac_practice.asset_activity_occurrence o WHERE o.asset_id = @asset_id AND o.status = N'OPEN' AND o.task_id IS NOT NULL)
            + (SELECT COUNT(*) FROM grac_practice.asset_reconciliation_exception e
                WHERE (e.asset_id = @asset_id OR e.other_asset_id = @asset_id) AND e.status = N'OPEN' AND e.task_id IS NOT NULL), 60
    UNION ALL SELECT N'Practice dependency resolutions', (SELECT COUNT(*) FROM grac_practice.practice_dependency_resolution p
              JOIN grac_practice.dependency_type_master dt ON dt.dependency_type_id = p.dependency_type_id
                                                          AND (dt.dependency_type_code = N'ASSET' OR dt.dependency_type_name = N'Asset')
             WHERE p.resolved_dependency_id = @asset_id AND p.organization_id = @organization_id), 70
    UNION ALL SELECT N'Discovery source records (integrations)', (SELECT COUNT(*) FROM grac_practice.asset_discovery_link l WHERE l.asset_id = @asset_id), 80
    UNION ALL SELECT N'History kept: lifecycle changes', (SELECT COUNT(*) FROM grac_practice.asset_lifecycle_change c WHERE c.asset_id = @asset_id), 90
    UNION ALL SELECT N'History kept: custody records', (SELECT COUNT(*) FROM grac_practice.asset_assignment_history h WHERE h.asset_id = @asset_id), 91
    UNION ALL SELECT N'History kept: completed activities', (SELECT COUNT(*) FROM grac_practice.asset_activity_occurrence o
                                                               WHERE o.asset_id = @asset_id AND o.status <> N'OPEN'), 92
    UNION ALL SELECT N'History kept: workflow cases', (SELECT COUNT(*) FROM grac_practice.asset_workflow_case w WHERE w.asset_id = @asset_id), 93;
GO
PRINT '444: merge blockers, plan, fields and impact functions created.';
GO
