
-- =====================================================================
-- 8. Readers
-- =====================================================================
-- Merge list. @status: NULL = open (Draft, Pending approval, Approved),
-- ALL, or one status.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_merge_events
    @organization_id BIGINT,
    @status          NVARCHAR(20)  = NULL,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    SELECT e.event_id AS EventId, e.status AS Status, e.survivor_asset_id AS SurvivorAssetId, s.asset_name AS SurvivorName,
           d.names AS DuplicateNames, d.cnt AS DuplicateCount, e.is_critical AS IsCritical, e.approvals_required AS ApprovalsRequired,
           (SELECT COUNT(*) FROM grac_practice.asset_merge_split_approval p WHERE p.event_id = e.event_id AND p.decision = N'APPROVE') AS Approvals,
           e.reason AS Reason, e.requested_by AS RequestedBy, e.requested_dt AS RequestedDt, e.executed_dt AS ExecutedDt,
           e.recovered_dt AS RecoveredDt, e.closed_dt AS ClosedDt, CONVERT(BIGINT, e.record_version) AS RecordVersion,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_merge_split_event e
      JOIN grac_practice.organization_dependency_asset s ON s.asset_id = e.survivor_asset_id
     CROSS APPLY (SELECT COUNT(*) AS cnt, LEFT(STRING_AGG(CAST(a.asset_name AS NVARCHAR(MAX)), N', '), 600) AS names
                    FROM grac_practice.asset_merge_split_member m
                    JOIN grac_practice.organization_dependency_asset a ON a.asset_id = m.asset_id
                   WHERE m.event_id = e.event_id) d
     WHERE e.organization_id = @organization_id AND e.event_kind = N'MERGE'
       AND ((@status IS NULL AND e.status IN (N'DRAFT', N'PENDING_APPROVAL', N'APPROVED')) OR @status = N'ALL' OR e.status = @status)
       AND (@search IS NULL OR s.asset_name LIKE N'%' + @search + N'%' OR d.names LIKE N'%' + @search + N'%')
     ORDER BY e.event_id DESC
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- One merge: 1. event  2. assets (survivor first)  3. approvals
-- 4. blockers  5. plan (open merges)  6. outcomes (executed / recovered)
-- 7. field comparison (open merges)  8. impact per asset.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_merge_get
    @organization_id BIGINT,
    @event_id        BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @survivor BIGINT, @status NVARCHAR(20), @choices NVARCHAR(MAX);
    SELECT @survivor = survivor_asset_id, @status = status, @choices = field_choices_json
      FROM grac_practice.asset_merge_split_event
     WHERE event_id = @event_id AND organization_id = @organization_id AND event_kind = N'MERGE';
    IF @survivor IS NULL THROW 52902, 'Merge not found for this organization.', 1;
    DECLARE @open BIT = CASE WHEN @status IN (N'DRAFT', N'PENDING_APPROVAL', N'APPROVED') THEN 1 ELSE 0 END;
    SELECT e.event_id AS EventId, e.status AS Status, e.survivor_asset_id AS SurvivorAssetId, s.asset_name AS SurvivorName,
           e.reason AS Reason, e.field_choices_json AS FieldChoicesJson, e.is_critical AS IsCritical, e.approvals_required AS ApprovalsRequired,
           (SELECT COUNT(*) FROM grac_practice.asset_merge_split_approval p WHERE p.event_id = e.event_id AND p.decision = N'APPROVE') AS Approvals,
           e.requested_by AS RequestedBy, e.requested_by_employee_id AS RequestedByEmployeeId, e.requested_dt AS RequestedDt,
           e.submitted_dt AS SubmittedDt, e.decided_note AS DecidedNote, e.executed_by AS ExecutedBy, e.executed_dt AS ExecutedDt,
           e.recovered_by AS RecoveredBy, e.recovered_dt AS RecoveredDt, e.recovery_reason AS RecoveryReason, e.closed_dt AS ClosedDt,
           CONVERT(BIGINT, e.record_version) AS RecordVersion
      FROM grac_practice.asset_merge_split_event e
      JOIN grac_practice.organization_dependency_asset s ON s.asset_id = e.survivor_asset_id
     WHERE e.event_id = @event_id;
    SELECT x.asset_id AS AssetId, x.role_code AS MemberRole, x.seq AS SequenceNo, a.asset_name AS AssetName,
           ty.asset_type_name AS AssetTypeName, ISNULL(st.status_name, N'Active') AS StatusName, c.criticality_name AS CriticalityName,
           ow.employee_name AS OwnerName, a.merged_into_asset_id AS MergedIntoAssetId
      FROM (SELECT @survivor AS asset_id, N'SURVIVOR' AS role_code, 0 AS seq
            UNION ALL SELECT asset_id, member_role, sequence_no FROM grac_practice.asset_merge_split_member WHERE event_id = @event_id) x
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = x.asset_id
      LEFT JOIN grac_practice.dependency_asset_type_master ty ON ty.asset_type_id = a.asset_type_id
      LEFT JOIN grac_practice.entity_status_master st ON st.entity_status_id = a.current_status_id
      LEFT JOIN grac_practice.criticality_master c ON c.criticality_id = a.criticality_id
      LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = a.owner_id
     ORDER BY x.seq;
    SELECT approval_id AS ApprovalId, decision AS Decision, note AS Note, approver AS Approver, decided_dt AS DecidedDt
      FROM grac_practice.asset_merge_split_approval WHERE event_id = @event_id ORDER BY approval_id;
    SELECT m.asset_id AS AssetId, b.BlockerCode, b.Detail
      FROM grac_practice.asset_merge_split_member m
     CROSS APPLY grac_practice.fn_asset_merge_blockers(@organization_id, @survivor, m.asset_id) b
     WHERE m.event_id = @event_id AND @open = 1
     ORDER BY m.sequence_no;
    SELECT m.asset_id AS DuplicateAssetId, p.ObjectKind, p.ObjectId, p.ObjectLabel, p.Outcome, p.Detail, p.Domain
      FROM grac_practice.asset_merge_split_member m
     CROSS APPLY grac_practice.fn_asset_merge_plan(@organization_id, @survivor, m.asset_id) p
     WHERE m.event_id = @event_id AND @open = 1
     ORDER BY m.sequence_no, p.Domain, p.ObjectKind, p.ObjectLabel;
    SELECT o.object_row_id AS ObjectRowId, o.from_asset_id AS DuplicateAssetId, o.object_kind AS ObjectKind, o.object_id AS ObjectId,
           o.object_label AS ObjectLabel, o.outcome AS Outcome, LEFT(o.before_value, 400) AS BeforeValue, LEFT(o.after_value, 400) AS AfterValue,
           o.detail AS Detail, o.recovered AS Recovered, o.recovery_note AS RecoveryNote
      FROM grac_practice.asset_merge_split_object o
     WHERE o.event_id = @event_id
     ORDER BY o.object_row_id;
    SELECT m.asset_id AS DuplicateAssetId, f.FieldKey, f.FieldLabel, f.SurvivorDisplay, f.DuplicateDisplay, f.IsMergeable, f.IsDifferent,
           CAST(CASE WHEN ch.chosen = m.asset_id THEN 1 ELSE 0 END AS BIT) AS IsChosen
      FROM grac_practice.asset_merge_split_member m
     CROSS APPLY grac_practice.fn_asset_merge_fields(@survivor, m.asset_id) f
     OUTER APPLY (SELECT TOP 1 TRY_CONVERT(BIGINT, j.[value]) AS chosen FROM OPENJSON(ISNULL(@choices, N'{}')) j
                   WHERE j.[key] COLLATE DATABASE_DEFAULT = f.FieldKey) ch
     WHERE m.event_id = @event_id AND @open = 1 AND f.DuplicateValue IS NOT NULL
     ORDER BY f.FieldLabel, m.sequence_no;
    SELECT x.asset_id AS AssetId, i.ImpactItem, i.ItemCount, i.SortOrder
      FROM (SELECT @survivor AS asset_id UNION SELECT asset_id FROM grac_practice.asset_merge_split_member WHERE event_id = @event_id) x
     CROSS APPLY grac_practice.fn_asset_merge_impact(@organization_id, x.asset_id) i
     ORDER BY x.asset_id, i.SortOrder;
END
GO
PRINT '444: merge readers created.';
GO
