# 438 -- API, worker, Web proxy, screens, Task Centre filter, 274. Run from the repository root.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    return s

A = 'src/PracticeManagement.Api/'
W = 'src/PracticeManagement.Web/'
files = {}

files[A + 'Models/AssetConfigModels.cs'] = edit(A + 'Models/AssetConfigModels.cs', [(
"""/// <summary>Outcome of a write: Success, the new/affected id, and on
/// failure the SQL error number + message so the controller can pick the""",
"""// ---------------------------------------------------------------------
// Recurring asset activities (migration 438)
// ---------------------------------------------------------------------
/// <summary>Organization settings of one activity template: active, task lead days,
/// due-soon days, INDIVIDUAL tasks or a monthly CAMPAIGN, campaign owner.</summary>
public sealed record AssetActivitySettingRequest(
    long    OrganizationId,
    string? TemplateCode,
    bool?   IsActive,
    int?    LeadDays,
    int?    DueSoonDays,
    string? GroupingMode,
    long?   CampaignOwnerEmployeeId);

/// <summary>Record the reconciliation of a flagged activity occurrence (BRD 7.1.5).</summary>
public sealed record AssetActivityReconcileRequest(long OrganizationId, string? Note, long? ExpectedRecordVersion);

/// <summary>Outcome of a write: Success, the new/affected id, and on
/// failure the SQL error number + message so the controller can pick the""")])

files[A + 'Services/AssetConfigService.cs'] = edit(A + 'Services/AssetConfigService.cs', [
("""//   notification profiles, escalation, occurrences, the scheduler pass run by TaskNotificationWorker)""",
"""//   notification profiles, escalation, occurrences, the scheduler pass run by TaskNotificationWorker)
//   sp_asset_activity_* (438 -- recurring asset activities: templates, schedules, occurrences, campaigns)"""),
("""    Task<int> ReadAllMyNotificationsAsync(long employeeId, CancellationToken ct);
}""",
"""    Task<int> ReadAllMyNotificationsAsync(long employeeId, CancellationToken ct);

    // 438 -- Recurring asset activities
    Task<object> GetActivityConfigAsync(long organizationId, CancellationToken ct);
    Task<AssetLifecycleResult> SaveActivitySettingAsync(AssetActivitySettingRequest request, string actor, CancellationToken ct);
    Task<object> ListActivitySchedulesAsync(long organizationId, string? templateCode, string? status, string? search, int pageNumber, int pageSize, string actor, CancellationToken ct);
    Task<object> ListActivityOccurrencesAsync(long organizationId, string? templateCode, string? status, bool reconcileOnly, long? campaignId, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<object> ListActivityCampaignsAsync(long organizationId, int pageNumber, int pageSize, CancellationToken ct);
    Task<AssetLifecycleResult> ReconcileActivityAsync(long occurrenceId, AssetActivityReconcileRequest request, string actor, CancellationToken ct);
}"""),
("""    /// <summary>The lifecycle (429) and technology (430) write procedures
    /// end with one row""",
"""    // ----------------------------------------------------------------
    // 438 -- Recurring asset activities
    // ----------------------------------------------------------------
    public async Task<object> GetActivityConfigAsync(long organizationId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_activity_config_get");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var templates = await ReadRowsAsync(reader, ct);
        var employees = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
        return new { templates, employees };
    }

    public Task<AssetLifecycleResult> SaveActivitySettingAsync(AssetActivitySettingRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_activity_setting_save", "organizationId", command =>
        {
            AddParam(command, "@organization_id",            DbType.Int64,   request.OrganizationId);
            AddParam(command, "@template_code",              DbType.String,  Blank(request.TemplateCode), 40);
            AddParam(command, "@is_active",                  DbType.Boolean, request.IsActive ?? true);
            AddParam(command, "@lead_days",                  DbType.Int32,   request.LeadDays);
            AddParam(command, "@due_soon_days",              DbType.Int32,   request.DueSoonDays);
            AddParam(command, "@grouping_mode",              DbType.String,  Blank(request.GroupingMode) ?? "INDIVIDUAL", 12);
            AddParam(command, "@campaign_owner_employee_id", DbType.Int64,   request.CampaignOwnerEmployeeId);
            AddParam(command, "@actor",                      DbType.String,  actor, 100);
        }, ct);

    public async Task<object> ListActivitySchedulesAsync(long organizationId, string? templateCode, string? status, string? search, int pageNumber, int pageSize, string actor, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_activity_schedules");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@template_code",   DbType.String, Blank(templateCode), 40);
        AddParam(command, "@status",          DbType.String, Blank(status), 16);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        AddParam(command, "@actor",           DbType.String, actor, 100);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object> ListActivityOccurrencesAsync(long organizationId, string? templateCode, string? status, bool reconcileOnly, long? campaignId, string? search, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_activity_occurrences");
        AddParam(command, "@organization_id", DbType.Int64,   organizationId);
        AddParam(command, "@template_code",   DbType.String,  Blank(templateCode), 40);
        AddParam(command, "@status",          DbType.String,  Blank(status), 12);
        AddParam(command, "@reconcile_only",  DbType.Boolean, reconcileOnly);
        AddParam(command, "@campaign_id",     DbType.Int64,   campaignId);
        AddParam(command, "@search",          DbType.String,  Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,   pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,   pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object> ListActivityCampaignsAsync(long organizationId, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_activity_campaigns");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        AddParam(command, "@page_number",     DbType.Int32, pageNumber);
        AddParam(command, "@page_size",       DbType.Int32, pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public Task<AssetLifecycleResult> ReconcileActivityAsync(long occurrenceId, AssetActivityReconcileRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_activity_reconcile", "occurrenceId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@occurrence_id",           DbType.Int64,  occurrenceId);
            AddParam(command, "@note",                    DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    /// <summary>The lifecycle (429) and technology (430) write procedures
    /// end with one row"""),
])

files[A + 'Controllers/AssetConfigController.cs'] = edit(A + 'Controllers/AssetConfigController.cs', [
("""//   POST notifications/mine/read-all
""",
"""//   POST notifications/mine/read-all
//   GET  activities/config?organizationId=          templates with organization settings, employees (438)
//   POST activities/settings                        save the settings of one template
//   GET  activities/schedules?organizationId=&templateCode=&status=&search=&pageNumber=&pageSize=
//   GET  activities/occurrences?organizationId=&templateCode=&status=&reconcileOnly=&campaignId=&search=&pageNumber=&pageSize=
//   GET  activities/campaigns?organizationId=&pageNumber=&pageSize=
//   POST activities/occurrences/{id}/reconcile      record the reconciliation of a flagged occurrence
//   POST activities/run                             run the scheduler now for the organization (as notifications/run)
"""),
("""    // 437: 54610 / 54611 / 54625 / 54630 -> 404; 54622 (active profile exists), 54623 (stale) -> 409.""",
"""    // ---------------------------------------------------------------- 438: recurring asset activities
    [HttpGet("activities/config")]
    public Task<IActionResult> ActivityConfig([FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.GetActivityConfigAsync(organizationId.Value, ct), "activity config");
    }

    [HttpPost("activities/settings")]
    public async Task<IActionResult> SaveActivitySetting([FromBody] AssetActivitySettingRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveActivitySettingAsync(request, Actor, ct), ActivityNotFound, ActivityConflict);
    }

    [HttpGet("activities/schedules")]
    public Task<IActionResult> ActivitySchedules([FromQuery] long? organizationId, [FromQuery] string? templateCode, [FromQuery] string? status,
        [FromQuery] string? search, [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListActivitySchedulesAsync(organizationId.Value, templateCode, status, search, pageNumber ?? 1, pageSize ?? 25, Actor, ct),
            "activity schedules");
    }

    [HttpGet("activities/occurrences")]
    public Task<IActionResult> ActivityOccurrences([FromQuery] long? organizationId, [FromQuery] string? templateCode, [FromQuery] string? status,
        [FromQuery] bool? reconcileOnly, [FromQuery] long? campaignId, [FromQuery] string? search, [FromQuery] int? pageNumber,
        [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListActivityOccurrencesAsync(organizationId.Value, templateCode, status, reconcileOnly ?? false, campaignId, search,
            pageNumber ?? 1, pageSize ?? 25, ct), "activity occurrences");
    }

    [HttpGet("activities/campaigns")]
    public Task<IActionResult> ActivityCampaigns([FromQuery] long? organizationId, [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListActivityCampaignsAsync(organizationId.Value, pageNumber ?? 1, pageSize ?? 25, ct), "activity campaigns");
    }

    [HttpPost("activities/occurrences/{occurrenceId:long}/reconcile")]
    public async Task<IActionResult> ReconcileActivity(long occurrenceId, [FromBody] AssetActivityReconcileRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.ReconcileActivityAsync(occurrenceId, request, Actor, ct), ActivityNotFound, ActivityConflict);
    }

    // The same scheduler pass as notifications/run, for the Asset Activities screen.
    [HttpPost("activities/run")]
    public Task<IActionResult> RunActivityScheduler([FromBody] AssetSchedulerRunRequest request, CancellationToken ct) =>
        RunScheduler(request, ct);

    // 438: 54650 / 54651 / 54655 -> 404; 54658 (stale) -> 409.
    private static readonly int[] ActivityNotFound = { 54650, 54651, 54655 };
    private static readonly int[] ActivityConflict = { 54658 };

    // 437: 54610 / 54611 / 54625 / 54630 -> 404; 54622 (active profile exists), 54623 (stale) -> 409."""),
])

files[A + 'Services/TaskNotificationWorker.cs'] = edit(A + 'Services/TaskNotificationWorker.cs', [
("""                        run.TryGetValue("errorCount", out var errors);
                        if (Convert.ToInt32(queued ?? 0) > 0 || Convert.ToInt32(renewals ?? 0) > 0 || Convert.ToInt32(errors ?? 0) > 0)
                            logger.LogInformation(
                                "Asset scheduler pass {Result}: {Queued} notification(s), {Renewals} renewal(s) started, {Errors} error(s).",
                                result, queued, renewals, errors);""",
"""                        run.TryGetValue("errorCount", out var errors);
                        run.TryGetValue("tasksCreated", out var tasks);   // 438: recurring asset activities
                        if (Convert.ToInt32(queued ?? 0) > 0 || Convert.ToInt32(renewals ?? 0) > 0 || Convert.ToInt32(errors ?? 0) > 0
                            || Convert.ToInt32(tasks ?? 0) > 0)
                            logger.LogInformation(
                                "Asset scheduler pass {Result}: {Queued} notification(s), {Renewals} renewal(s) started, {Tasks} activity task(s), {Errors} error(s).",
                                result, queued, renewals, tasks, errors);"""),
("""// AssetSchedulerEnabled=false leaves it to SQL Agent:""",
"""// 438 adds the recurring asset activities (calibration, maintenance,
// inspection, licence renewal tasks) to the same pass.
// AssetSchedulerEnabled=false leaves it to SQL Agent:"""),
])

for p in ('src/PracticeManagement.Api/appsettings.json', W + 'appsettings.json'):
    files[p] = edit(p, [(""""asset-contracts:*", "asset-notifications:*" ],""",
                         """"asset-contracts:*", "asset-notifications:*", "asset-activities:*" ],""")])

files[W + 'Controllers/AssetConfigController.cs'] = edit(W + 'Controllers/AssetConfigController.cs', [
("""//   notifications/mine... (437)        the caller's own notices: session only, no organization or menu
//                                      grant -- the API addresses them to the stamped employee""",
"""//   notifications/mine... (437)        the caller's own notices: session only, no organization or menu
//                                      grant -- the API addresses them to the stamped employee
//   activities... (438)                asset-activities: GET VIEW (organization required); POST
//                                      activities/settings, activities/occurrences/{id}/reconcile and
//                                      activities/run EDIT"""),
("""    private const string NotificationArea = "asset-notifications";   // 437""",
"""    private const string NotificationArea = "asset-notifications";   // 437
    private const string ActivityArea = "asset-activities";          // 438"""),
("""        else if (lower == "notifications/mine" || lower.StartsWith("notifications/mine/"))   // 437: own notices""",
"""        else if (lower.StartsWith("activities/"))                               // 438
        {
            if (!long.TryParse(Request.Query["organizationId"], out var orgId) || orgId <= 0)
                return BadRequest(new { error = "organizationId is required." });
            if (!HttpContext.IsOrganizationAllowed(orgId)) return OrganizationDenied();
            allowed = Can(ActivityArea, "VIEW");
        }
        else if (lower == "notifications/mine" || lower.StartsWith("notifications/mine/"))   // 437: own notices"""),
("""        var isNotification = lower.StartsWith("notifications/");                 // 437""",
"""        var isNotification = lower.StartsWith("notifications/");                 // 437
        var isActivity = lower.StartsWith("activities/");                        // 438"""),
("""        if (!isValuation && !isOptionList && !isTechCatalog && !isRegister && !isAttestation && !isContract && !isNotification
            && !lower.StartsWith("templates"))""",
"""        if (!isValuation && !isOptionList && !isTechCatalog && !isRegister && !isAttestation && !isContract && !isNotification
            && !isActivity && !lower.StartsWith("templates"))"""),
("""        var area = isNotification ? NotificationArea : isContract""",
"""        var area = isActivity ? ActivityArea : isNotification ? NotificationArea : isContract"""),
("""            : isNotification
            ? false""",
"""            : isNotification
            ? false
            : isActivity && (lower == "activities/settings" || lower == "activities/run"     // 438
                             || (lower.StartsWith("activities/occurrences/") && lower.EndsWith("/reconcile")))
            ? Can(area, "EDIT")
            : isActivity
            ? false"""),
])

files[W + 'Models/PracticeScreen.cs'] = edit(W + 'Models/PracticeScreen.cs', [(
"""        // Phase 6.1 (migration 437): notification profiles, escalation""",
"""        // Phase 6.2 (migration 438): recurring asset activities -- templates,
        // schedules, occurrences with Task Centre tasks, campaigns.
        new("asset-activities","Asset Activities","Recurring asset activities: calibration, preventive maintenance, statutory inspection and equipment licence renewal. Schedules come from the asset register; the scheduler opens one occurrence per asset and due date and creates its Task Centre task, or records that a contract covers it.","calendar-check",["Asset","Activity","Next due","Status","Task"], AssetContractGroup),
        // Phase 6.1 (migration 437): notification profiles, escalation""")])

files[W + 'Views/Practice/Manage.cshtml'] = edit(W + 'Views/Practice/Manage.cshtml', [(
"""        // Phase 6.1 (migration 437): asset notifications.
        "asset-notifications"
    };""",
"""        // Phase 6.1 (migration 437): asset notifications.
        "asset-notifications",
        // Phase 6.2 (migration 438): recurring asset activities.
        "asset-activities"
    };""")])

files[W + 'Views/Practice/Partials/tasks.cshtml'] = edit(W + 'Views/Practice/Partials/tasks.cshtml', [
("""           The list is ck_pm_practice_task_source_type as widened by
           migration 215, exactly: Gap / Exception / Risk / RiskRegister /
           ContinuousAssurance / EventAssurance / Custom. An option that
           is not in that CHECK would be a filter that can never match. *@""",
"""           The list is ck_pm_practice_task_source_type as widened by
           migration 215, exactly: Gap / Exception / Risk / RiskRegister /
           ContinuousAssurance / EventAssurance / Custom -- plus Asset
           (migration 438: recurring asset activities). An option that
           is not in that CHECK would be a filter that can never match. *@"""),
("""            <option value="Custom">Custom</option>
        </select>""",
"""            <option value="Custom">Custom</option>
            <option value="Asset">Asset activity</option>
        </select>"""),
("""        Custom:              'Custom'
    };""",
"""        Custom:              'Custom',
        Asset:               'Asset activity'   // 438
    };"""),
])

files[W + 'Views/Practice/Partials/asset-notifications.cshtml'] = edit(W + 'Views/Practice/Partials/asset-notifications.cshtml', [(
"""<th>Occurrences opened / closed</th><th>Notices</th><th>Errors</th>""",
"""<th>Occurrences opened / closed</th><th>Activity tasks</th><th>Notices</th><th>Errors</th>""")])

files[W + 'wwwroot/js/AssetConfig/asset-notifications.js'] = edit(W + 'wwwroot/js/AssetConfig/asset-notifications.js', [
("""        <td>${all ? "--" : esc(r.occurrencesOpened ?? 0) + " / " + esc(r.occurrencesClosed ?? 0)}</td><td>${n(r.notificationsQueued)}</td>""",
"""        <td>${all ? "--" : esc(r.occurrencesOpened ?? 0) + " / " + esc(r.occurrencesClosed ?? 0)}</td><td>${n(r.tasksCreated)}</td><td>${n(r.notificationsQueued)}</td>"""),
("""      : `Run ${statusLabel(r.result)}: ${r.notificationsQueued || 0} notice(s), ${r.renewalsStarted || 0} renewal(s) started, ${r.attestationsGenerated || 0} attestation(s), ${r.errorCount || 0} error(s).`,""",
"""      : `Run ${statusLabel(r.result)}: ${r.notificationsQueued || 0} notice(s), ${r.renewalsStarted || 0} renewal(s) started, ${r.attestationsGenerated || 0} attestation(s), ${r.tasksCreated || 0} activity task(s), ${r.errorCount || 0} error(s).`,"""),
("""    if (!state.organizationId) { body.innerHTML = empty(9, "Select an organization."); return; }
    body.innerHTML = empty(9, "Loading...");
    const res = await api("GET", `/runs?organizationId=${state.organizationId}`);
    if (!res.ok) { body.innerHTML = empty(9, res.error); return; }""",
"""    if (!state.organizationId) { body.innerHTML = empty(10, "Select an organization."); return; }
    body.innerHTML = empty(10, "Loading...");
    const res = await api("GET", `/runs?organizationId=${state.organizationId}`);
    if (!res.ok) { body.innerHTML = empty(10, res.error); return; }"""),
("""    }).join("") || empty(9, "The scheduler has not run yet.");""", """    }).join("") || empty(10, "The scheduler has not run yet.");"""),
])

D = 'database/274_menu_master_seed.sql'
files[D] = edit(D, [
("""--   437 -- 'asset-notifications' (359, Asset Notifications) under
--     'nav-asset-contract'.
""",
"""--   437 -- 'asset-notifications' (359, Asset Notifications) under
--     'nav-asset-contract'.
--   438 -- 'asset-activities' (360, Asset Activities) under
--     'nav-asset-contract'.
"""),
("""    (N'asset-notifications'           , N'Asset Notifications'               , N'Practice/Index/asset-notifications'         ,  359, N'bell-concierge'        , N'Asset & Contract'           , N'Active')   -- 437""",
"""    (N'asset-notifications'           , N'Asset Notifications'               , N'Practice/Index/asset-notifications'         ,  359, N'bell-concierge'        , N'Asset & Contract'           , N'Active'),  -- 437
    (N'asset-activities'              , N'Asset Activities'                  , N'Practice/Index/asset-activities'            ,  360, N'calendar-check'        , N'Asset & Contract'           , N'Active')   -- 438"""),
("""    (N'asset-notifications'           , N'nav-asset-contract')   -- 437""",
"""    (N'asset-notifications'           , N'nav-asset-contract'),  -- 437
    (N'asset-activities'              , N'nav-asset-contract')   -- 438"""),
])

for p, s in files.items():
    open(p, 'w', encoding='utf-8', newline='').write(s)
print('438 ok', len(files))
