# 441 -- API, Web proxy, screen registry, appsettings, 274, Asset Relationships screen (role, contract / service kinds).
# Run from the repository root.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    return s

A = 'src/PracticeManagement.Api/'
W = 'src/PracticeManagement.Web/'
files = {}

files[A + 'Models/AssetConfigModels.cs'] = edit(A + 'Models/AssetConfigModels.cs', [
("""    string?   ChangeReference,
    string?   Reason,
    long?     ExpectedRecordVersion);

/// <summary>Relationship action:""",
"""    string?   ChangeReference,
    string?   Reason,
    long?     ExpectedRecordVersion,
    string?   ServiceRole = null);   // 441: role of the mapping ("primary database")

/// <summary>Relationship action:"""),
("""/// <summary>Outcome of a write: Success, the new/affected id, and on
/// failure the SQL error number + message so the controller can pick the""",
"""// ---------------------------------------------------------------------
// Business services (migration 441)
// ---------------------------------------------------------------------
/// <summary>One consumer of a service: DEPARTMENT | BUSINESS_FUNCTION | LOCATION (ConsumerRefId)
/// or EXTERNAL (ConsumerName).</summary>
public sealed record BusinessServiceConsumerItem(string? ConsumerKind, long? ConsumerRefId, string? ConsumerName, string? Note);

/// <summary>Create (ServiceId null, Draft) or change a business service (BRD 5.5). Consumers
/// null keeps the current list; an empty list clears it. Ratings 1-5; hours for RTO / RPO / MTPD.</summary>
public sealed record BusinessServiceSaveRequest(
    long      OrganizationId,
    long?     ServiceId,
    string?   ServiceCode,
    string?   ServiceName,
    string?   ServiceType,
    string?   Description,
    string?   CustomerOutcome,
    long?     BusinessOwnerEmployeeId,
    long?     ServiceManagerEmployeeId,
    long?     AccountableDepartmentId,
    int?      CriticalityId,
    byte?     ConfidentialityRating,
    byte?     IntegrityRating,
    byte?     AvailabilityRating,
    decimal?  RtoHours,
    decimal?  RpoHours,
    decimal?  MtpdHours,
    string?   ServiceHours,
    string?   SlaText,
    string?   DataClassification,
    string?   PrivacyClassification,
    DateTime? ReviewDate,
    List<BusinessServiceConsumerItem>? Consumers,
    long?     ExpectedRecordVersion);

/// <summary>Status change of a service; retiring from Retiring needs the consumer review and
/// contract assessment notes (BRD 5.5.1).</summary>
public sealed record BusinessServiceTransitionRequest(
    long    OrganizationId,
    string? ToStatus,
    string? Note,
    string? ConsumerReviewNote,
    string? ContractAssessmentNote,
    long?   ExpectedRecordVersion);

/// <summary>Organization settings: minimum active supporting relationships for activation and
/// whether a retirement needs another person approval.</summary>
public sealed record BusinessServiceSettingRequest(long OrganizationId, int? MinSupportingRelationships, bool? RetirementApprovalRequired);

/// <summary>Outcome of a write: Success, the new/affected id, and on
/// failure the SQL error number + message so the controller can pick the"""),
])

files[A + 'Services/AssetConfigService.cs'] = edit(A + 'Services/AssetConfigService.cs', [
("""//   sp_asset_relationship_* / sp_asset_ci_* (440 -- CMDB relationships, CI lookup, impact analysis)""",
"""//   sp_asset_relationship_* / sp_asset_ci_* (440 -- CMDB relationships, CI lookup, impact analysis)
//   sp_business_service* (441 -- business services, consumers, status rules, conflicts, hierarchy)"""),
("""    Task<object> GetImpactAsync(long organizationId, string ciKind, long ciId, string direction, int maxDepth, bool criticalOnly, long? previewRelationshipId, CancellationToken ct);
}""",
"""    Task<object> GetImpactAsync(long organizationId, string ciKind, long ciId, string direction, int maxDepth, bool criticalOnly, long? previewRelationshipId, CancellationToken ct);

    // 441 -- Business services
    Task<object> GetBusinessServiceConfigAsync(long organizationId, CancellationToken ct);
    Task<object> ListBusinessServicesAsync(long organizationId, string? status, string? serviceType, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<object?> GetBusinessServiceAsync(long organizationId, long serviceId, CancellationToken ct);
    Task<AssetLifecycleResult> SaveBusinessServiceAsync(BusinessServiceSaveRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> TransitionBusinessServiceAsync(long serviceId, BusinessServiceTransitionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> DecideBusinessServiceRetirementAsync(long serviceId, AssetLifecycleDecisionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> SaveBusinessServiceSettingAsync(BusinessServiceSettingRequest request, string actor, CancellationToken ct);
    Task<object> ListBusinessServiceConflictsAsync(long organizationId, long? serviceId, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<object> GetBusinessServiceTreeAsync(long organizationId, CancellationToken ct);
}"""),
("""            AddParam(command, "@change_reference",        DbType.String,  Blank(request.ChangeReference), 200);
            AddParam(command, "@reason",                  DbType.String,  Blank(request.Reason), 1000);""",
"""            AddParam(command, "@change_reference",        DbType.String,  Blank(request.ChangeReference), 200);
            AddParam(command, "@service_role",            DbType.String,  Blank(request.ServiceRole), 100);   // 441
            AddParam(command, "@reason",                  DbType.String,  Blank(request.Reason), 1000);"""),
("""        var rows = await ReadRowsAsync(reader, ct);
        var summary = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
        return new { rows, summary = summary.Count > 0 ? summary[0] : null };
    }""",
"""        var rows = await ReadRowsAsync(reader, ct);
        var summary = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
        var services = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();   // 441
        return new { rows, summary = summary.Count > 0 ? summary[0] : null, services };
    }

    // ----------------------------------------------------------------
    // 441 -- Business services
    // ----------------------------------------------------------------
    public async Task<object> GetBusinessServiceConfigAsync(long organizationId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_business_service_config_get");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var settings = await ReadRowsAsync(reader, ct);
        var empty = new List<Dictionary<string, object?>>();
        var employees = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var departments = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var businessFunctions = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var locations = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var criticalities = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        return new { settings = settings.Count > 0 ? settings[0] : null, employees, departments, businessFunctions, locations, criticalities };
    }

    public async Task<object> ListBusinessServicesAsync(long organizationId, string? status, string? serviceType, string? search, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_business_services");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 10);
        AddParam(command, "@service_type",    DbType.String, Blank(serviceType), 16);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object?> GetBusinessServiceAsync(long organizationId, long serviceId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_business_service_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@service_id",      DbType.Int64, serviceId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var header = await ReadRowsAsync(reader, ct);
            if (header.Count == 0) return null;
            var empty = new List<Dictionary<string, object?>>();
            var consumers = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var supporting = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var supports = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var conflicts = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var history = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            return new { service = header[0], consumers, supporting, supports, conflicts, history };
        }
        catch (SqlException ex) when (ex.Number == 54731) { return null; }
    }

    public Task<AssetLifecycleResult> SaveBusinessServiceAsync(BusinessServiceSaveRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_business_service_save", "serviceId", command =>
        {
            AddParam(command, "@organization_id",             DbType.Int64,   request.OrganizationId);
            AddParam(command, "@service_id",                  DbType.Int64,   request.ServiceId);
            AddParam(command, "@service_code",                DbType.String,  Blank(request.ServiceCode), 40);
            AddParam(command, "@service_name",                DbType.String,  Blank(request.ServiceName), 200);
            AddParam(command, "@service_type",                DbType.String,  Blank(request.ServiceType), 16);
            AddParam(command, "@description",                 DbType.String,  Blank(request.Description), 2000);
            AddParam(command, "@customer_outcome",            DbType.String,  Blank(request.CustomerOutcome), 1000);
            AddParam(command, "@business_owner_employee_id",  DbType.Int64,   request.BusinessOwnerEmployeeId);
            AddParam(command, "@service_manager_employee_id", DbType.Int64,   request.ServiceManagerEmployeeId);
            AddParam(command, "@accountable_department_id",   DbType.Int64,   request.AccountableDepartmentId);
            AddParam(command, "@criticality_id",              DbType.Int32,   request.CriticalityId);
            AddParam(command, "@confidentiality_rating",      DbType.Byte,    request.ConfidentialityRating);
            AddParam(command, "@integrity_rating",            DbType.Byte,    request.IntegrityRating);
            AddParam(command, "@availability_rating",         DbType.Byte,    request.AvailabilityRating);
            AddParam(command, "@rto_hours",                   DbType.Decimal, request.RtoHours);
            AddParam(command, "@rpo_hours",                   DbType.Decimal, request.RpoHours);
            AddParam(command, "@mtpd_hours",                  DbType.Decimal, request.MtpdHours);
            AddParam(command, "@service_hours",               DbType.String,  Blank(request.ServiceHours), 200);
            AddParam(command, "@sla_text",                    DbType.String,  Blank(request.SlaText), 1000);
            AddParam(command, "@data_classification",         DbType.String,  Blank(request.DataClassification), 100);
            AddParam(command, "@privacy_classification",      DbType.String,  Blank(request.PrivacyClassification), 100);
            AddParam(command, "@review_date",                 DbType.Date,    request.ReviewDate?.Date);
            AddParam(command, "@consumers_json",              DbType.String,
                request.Consumers is null ? null : System.Text.Json.JsonSerializer.Serialize(request.Consumers.Select(c => new
                {
                    consumerKind = c.ConsumerKind, consumerRefId = c.ConsumerRefId, consumerName = c.ConsumerName, note = c.Note
                })));
            AddParam(command, "@expected_record_version",     DbType.Int64,   request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",           DbType.Int64,   actorEmployeeId);
            AddParam(command, "@actor",                       DbType.String,  actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> TransitionBusinessServiceAsync(long serviceId, BusinessServiceTransitionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_business_service_transition", "serviceId", command =>
        {
            AddParam(command, "@organization_id",          DbType.Int64,  request.OrganizationId);
            AddParam(command, "@service_id",               DbType.Int64,  serviceId);
            AddParam(command, "@to_status",                DbType.String, Blank(request.ToStatus), 10);
            AddParam(command, "@note",                     DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@consumer_review_note",     DbType.String, Blank(request.ConsumerReviewNote), 1000);
            AddParam(command, "@contract_assessment_note", DbType.String, Blank(request.ContractAssessmentNote), 1000);
            AddParam(command, "@expected_record_version",  DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",        DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                    DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> DecideBusinessServiceRetirementAsync(long serviceId, AssetLifecycleDecisionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_business_service_retirement_decide", "serviceId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@service_id",              DbType.Int64,  serviceId);
            AddParam(command, "@decision",                DbType.String, request.Decision, 10);
            AddParam(command, "@decision_note",           DbType.String, Blank(request.DecisionNote), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> SaveBusinessServiceSettingAsync(BusinessServiceSettingRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_business_service_setting_save", "organizationId", command =>
        {
            AddParam(command, "@organization_id",              DbType.Int64,   request.OrganizationId);
            AddParam(command, "@min_supporting_relationships", DbType.Int32,   request.MinSupportingRelationships);
            AddParam(command, "@retirement_approval_required", DbType.Boolean, request.RetirementApprovalRequired ?? true);
            AddParam(command, "@actor",                        DbType.String,  actor, 100);
        }, ct);

    public async Task<object> ListBusinessServiceConflictsAsync(long organizationId, long? serviceId, string? search, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_business_service_conflicts");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@service_id",      DbType.Int64,  serviceId);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object> GetBusinessServiceTreeAsync(long organizationId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_business_service_tree");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var services = await ReadRowsAsync(reader, ct);
        var links = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
        return new { services, links };
    }"""),
])

files[A + 'Controllers/AssetConfigController.cs'] = edit(A + 'Controllers/AssetConfigController.cs', [
("""//   GET  relationships/impact?organizationId=&ciKind=&ciId=&direction=&maxDepth=&criticalOnly=&previewRelationshipId=
""",
"""//   GET  relationships/impact?organizationId=&ciKind=&ciId=&direction=&maxDepth=&criticalOnly=&previewRelationshipId=
//        (441: adds the business services reached)
//   GET  business-services/config?organizationId=    settings, employees, departments, business functions, locations, criticalities (441)
//   GET  business-services?organizationId=&status=&serviceType=&search=&pageNumber=&pageSize=
//   GET  business-services/{id}?organizationId=      service, consumers, supporting items, supports, conflicts, history
//   POST business-services                           create (serviceId null) or change a service
//   POST business-services/{id}/transition           status change
//   POST business-services/{id}/retirement-decision  APPROVE | REJECT | WITHDRAW a pending retirement
//   POST business-services/settings                  organization settings
//   GET  business-services/conflicts?organizationId=&serviceId=&search=&pageNumber=&pageSize=
//   GET  business-services/tree?organizationId=      service hierarchy
"""),
("""    // 440: 54701 (organization), 54709 (relationship) -> 404; 54710 (stale), 54712 (pending change) -> 409.""",
"""    // ---------------------------------------------------------------- 441: business services
    [HttpGet("business-services/config")]
    public Task<IActionResult> BusinessServiceConfig([FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.GetBusinessServiceConfigAsync(organizationId.Value, ct), "business service config");
    }

    [HttpGet("business-services")]
    public Task<IActionResult> BusinessServices([FromQuery] long? organizationId, [FromQuery] string? status, [FromQuery] string? serviceType,
        [FromQuery] string? search, [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListBusinessServicesAsync(organizationId.Value, status, serviceType, search, pageNumber ?? 1, pageSize ?? 25, ct),
            "business services");
    }

    [HttpGet("business-services/{serviceId:long}")]
    public Task<IActionResult> BusinessService(long serviceId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetBusinessServiceAsync(o, serviceId, ct), "Business service not found.", "business service");

    [HttpPost("business-services")]
    public async Task<IActionResult> SaveBusinessService([FromBody] BusinessServiceSaveRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveBusinessServiceAsync(request, ActorEmployeeId, Actor, ct), ServiceNotFound, ServiceConflict);
    }

    [HttpPost("business-services/{serviceId:long}/transition")]
    public async Task<IActionResult> TransitionBusinessService(long serviceId, [FromBody] BusinessServiceTransitionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.TransitionBusinessServiceAsync(serviceId, request, ActorEmployeeId, Actor, ct), ServiceNotFound, ServiceConflict);
    }

    [HttpPost("business-services/{serviceId:long}/retirement-decision")]
    public async Task<IActionResult> DecideBusinessServiceRetirement(long serviceId, [FromBody] AssetLifecycleDecisionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Decision)) return BadRequest(new { error = "decision is required." });
        return ResultWritten(await service.DecideBusinessServiceRetirementAsync(serviceId, request, ActorEmployeeId, Actor, ct), ServiceNotFound, ServiceConflict);
    }

    [HttpPost("business-services/settings")]
    public async Task<IActionResult> SaveBusinessServiceSetting([FromBody] BusinessServiceSettingRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveBusinessServiceSettingAsync(request, Actor, ct), ServiceNotFound, ServiceConflict);
    }

    [HttpGet("business-services/conflicts")]
    public Task<IActionResult> BusinessServiceConflicts([FromQuery] long? organizationId, [FromQuery] long? serviceId, [FromQuery] string? search,
        [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListBusinessServiceConflictsAsync(organizationId.Value, serviceId, search, pageNumber ?? 1, pageSize ?? 25, ct),
            "business service conflicts");
    }

    [HttpGet("business-services/tree")]
    public Task<IActionResult> BusinessServiceTree([FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.GetBusinessServiceTreeAsync(organizationId.Value, ct), "business service tree");
    }

    // 441: 54730 (organization), 54731 (service) -> 404; 54732 (stale), 54747 (retirement pending / none) -> 409.
    private static readonly int[] ServiceNotFound = { 54730, 54731 };
    private static readonly int[] ServiceConflict = { 54732, 54747 };

    // 440: 54701 (organization), 54709 (relationship) -> 404; 54710 (stale), 54712 (pending change) -> 409."""),
])

files[W + 'Controllers/AssetConfigController.cs'] = edit(W + 'Controllers/AssetConfigController.cs', [
("""//                                      (segregation of duties and the withdrawing requester in SQL)""",
"""//                                      (segregation of duties and the withdrawing requester in SQL)
//   business-services... (441)         business-services: GET VIEW (organization required); POST
//                                      business-services ADD for a new service, EDIT for a change (serviceId);
//                                      /transition and settings EDIT; /retirement-decision APPROVE / REJECT
//                                      -> APPROVE, WITHDRAW -> EDIT (segregation of duties in SQL). The
//                                      supporting-item mappings go through relationships... (440 rules)"""),
("""    private const string RelationshipArea = "asset-relationships";   // 440""",
"""    private const string RelationshipArea = "asset-relationships";   // 440
    private const string ServiceArea = "business-services";          // 441"""),
("""        else if (lower == "relationships" || lower.StartsWith("relationships/"))   // 440
        {""",
"""        else if (lower == "business-services" || lower.StartsWith("business-services/"))   // 441
        {
            if (!long.TryParse(Request.Query["organizationId"], out var orgId) || orgId <= 0)
                return BadRequest(new { error = "organizationId is required." });
            if (!HttpContext.IsOrganizationAllowed(orgId)) return OrganizationDenied();
            allowed = Can(ServiceArea, "VIEW");
        }
        else if (lower == "relationships" || lower.StartsWith("relationships/"))   // 440
        {"""),
("""        var isRelationship = lower == "relationships" || lower.StartsWith("relationships/");   // 440""",
"""        var isRelationship = lower == "relationships" || lower.StartsWith("relationships/");   // 440
        var isService = lower == "business-services" || lower.StartsWith("business-services/");   // 441"""),
("""            && !isActivity && !isRelationship && !lower.StartsWith("templates"))""",
"""            && !isActivity && !isRelationship && !isService && !lower.StartsWith("templates"))"""),
("""        var area = isRelationship ? RelationshipArea : isActivity""",
"""        var area = isService ? ServiceArea : isRelationship ? RelationshipArea : isActivity"""),
("""        long relationshipId = 0;                                // 440: relationship save -- ADD vs EDIT""",
"""        long relationshipId = 0;                                // 440: relationship save -- ADD vs EDIT
        long serviceId = 0;                                     // 441: service save -- ADD vs EDIT"""),
("""            if (doc.RootElement.TryGetProperty("relationshipId", out var rid) && rid.ValueKind == JsonValueKind.Number)
                rid.TryGetInt64(out relationshipId);""",
"""            if (doc.RootElement.TryGetProperty("relationshipId", out var rid) && rid.ValueKind == JsonValueKind.Number)
                rid.TryGetInt64(out relationshipId);
            if (doc.RootElement.TryGetProperty("serviceId", out var sid) && sid.ValueKind == JsonValueKind.Number)
                sid.TryGetInt64(out serviceId);"""),
("""            : isRelationship
            ? false""",
"""            : isRelationship
            ? false
            : isService && lower == "business-services"                // 441: new service ADD, change EDIT
            ? Can(area, serviceId > 0 ? "EDIT" : "ADD")
            : isService && lower.EndsWith("/retirement-decision")
            ? (decision is "APPROVE" or "REJECT" ? Can(area, "APPROVE") : Can(area, "EDIT"))
            : isService && (lower.EndsWith("/transition") || lower == "business-services/settings")
            ? Can(area, "EDIT")
            : isService
            ? false"""),
])

files[W + 'Models/PracticeScreen.cs'] = edit(W + 'Models/PracticeScreen.cs', [(
"""        // Phase 7.1 (migration 440): CMDB relationships -- types, governed""",
"""        // Phase 7.2 (migration 441): business services -- register, consumers,
        // supporting items, status rules, conflicts, hierarchy.
        new("business-services","Business Services","Business services and what they run on: owners, criticality and CIA, RTO / RPO / MTPD, consumers, supporting assets, applications, suppliers, contracts and child services, activation and retirement rules, continuity conflicts and the service hierarchy.","sitemap",["Service","Type","Status","Owner","Support"], AssetContractGroup),
        // Phase 7.1 (migration 440): CMDB relationships -- types, governed""")])

files[W + 'Views/Practice/Manage.cshtml'] = edit(W + 'Views/Practice/Manage.cshtml', [(
"""        // Phase 7.1 (migration 440): CMDB relationships.
        "asset-relationships"
    };""",
"""        // Phase 7.1 (migration 440): CMDB relationships.
        "asset-relationships",
        // Phase 7.2 (migration 441): business services.
        "business-services"
    };""")])

for p in (A + 'appsettings.json', W + 'appsettings.json'):
    files[p] = edit(p, [(""""asset-activities:*", "asset-relationships:*" ],""",
                         """"asset-activities:*", "asset-relationships:*", "business-services:*" ],""")])

D = 'database/274_menu_master_seed.sql'
files[D] = edit(D, [
("""--   440 -- 'asset-relationships' (361, Asset Relationships) under
--     'nav-asset-contract'.
""",
"""--   440 -- 'asset-relationships' (361, Asset Relationships) under
--     'nav-asset-contract'.
--   441 -- 'business-services' (362, Business Services) under
--     'nav-asset-contract'.
"""),
("""    (N'asset-relationships'           , N'Asset Relationships'               , N'Practice/Index/asset-relationships'         ,  361, N'diagram-project'       , N'Asset & Contract'           , N'Active')   -- 440""",
"""    (N'asset-relationships'           , N'Asset Relationships'               , N'Practice/Index/asset-relationships'         ,  361, N'diagram-project'       , N'Asset & Contract'           , N'Active'),  -- 440
    (N'business-services'             , N'Business Services'                 , N'Practice/Index/business-services'           ,  362, N'sitemap'               , N'Asset & Contract'           , N'Active')   -- 441"""),
("""    (N'asset-relationships'           , N'nav-asset-contract')   -- 440""",
"""    (N'asset-relationships'           , N'nav-asset-contract'),  -- 440
    (N'business-services'             , N'nav-asset-contract')   -- 441"""),
])

# Asset Relationships screen: role field, contract / service kinds, services in the impact result.
V = W + 'Views/Practice/Partials/asset-relationships.cshtml'
J = W + 'wwwroot/js/AssetConfig/asset-relationships.js'
files[V] = edit(V, [
("""    each CI once at its nearest level. "Relationship types" shows the rules.""",
"""    each CI once at its nearest level. "Relationship types" shows the rules.
    441: business services and contracts are items too (Supports Service);
    a relationship carries an optional role; the impact analysis also lists
    the business services reached with owners and continuity objectives."""),
("""            <label><span>Change reference</span><input type="text" id="arlRmChange" maxlength="200" /></label>""",
"""            <label><span>Change reference</span><input type="text" id="arlRmChange" maxlength="200" /></label>
            <label class="full"><span>Role (for example "primary database")</span><input type="text" id="arlRmRole" maxlength="100" /></label>"""),
("""                    <tbody id="arlImpBody"></tbody>
                </table>
            </div>""",
"""                    <tbody id="arlImpBody"></tbody>
                </table>
            </div>
            <h3 class="arl-sub">Business services reached</h3>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Level</th><th>Service</th><th>Status</th><th>Criticality</th><th>RTO / RPO / MTPD (h)</th><th>Owner / manager</th><th>Consumers</th></tr></thead>
                    <tbody id="arlImpSvcBody"></tbody>
                </table>
            </div>"""),
])
files[J] = edit(J, [
("""  const KINDS = { ASSET: "Asset", APPLICATION: "Application", PROCESS: "Process", VENDOR: "Vendor", LOCATION: "Location", SERVICE: "Business service" };""",
"""  const KINDS = { ASSET: "Asset", APPLICATION: "Application", PROCESS: "Process", VENDOR: "Vendor", LOCATION: "Location", SERVICE: "Business service",
                  CONTRACT: "Contract" };   // 441: services and contracts"""),
("""      Object.entries(KINDS).filter(([k]) => k !== "SERVICE").forEach(([k, l]) => sel.insertAdjacentHTML("beforeend", `<option value="${k}">${esc(l)}</option>`));""",
"""      Object.entries(KINDS).forEach(([k, l]) => sel.insertAdjacentHTML("beforeend", `<option value="${k}">${esc(l)}</option>`));"""),
("""      ["arlRmSrcSearch", "arlRmTgtSearch", "arlRmWeight", "arlRmConfidence", "arlRmTo", "arlRmEvidence", "arlRmChange", "arlRmReason"].forEach(x => { document.getElementById(x).value = ""; });""",
"""      ["arlRmSrcSearch", "arlRmTgtSearch", "arlRmWeight", "arlRmConfidence", "arlRmTo", "arlRmEvidence", "arlRmChange", "arlRmRole", "arlRmReason"].forEach(x => { document.getElementById(x).value = ""; });"""),
("""    document.getElementById("arlRmChange").value = r.changeReference || "";""",
"""    document.getElementById("arlRmChange").value = r.changeReference || "";
    document.getElementById("arlRmRole").value = r.serviceRole || "";   // 441"""),
("""      evidenceReference: val("arlRmEvidence") || null, changeReference: val("arlRmChange") || null, reason: val("arlRmReason") || null,""",
"""      evidenceReference: val("arlRmEvidence") || null, changeReference: val("arlRmChange") || null, reason: val("arlRmReason") || null,
      serviceRole: val("arlRmRole") || null,   // 441"""),
("""        <td><button class="pm-link-button" type="button" data-arl-open="${r.relationshipId}">${esc(r.typeName)}</button>
            <div class="arl-note">#${esc(r.relationshipId)} v${esc(r.versionNo)}${r.inLoop ? " - loop (flagged)" : ""}</div></td>""",
"""        <td><button class="pm-link-button" type="button" data-arl-open="${r.relationshipId}">${esc(r.typeName)}</button>
            <div class="arl-note">#${esc(r.relationshipId)} v${esc(r.versionNo)}${r.inLoop ? " - loop (flagged)" : ""}${r.serviceRole ? " - " + esc(r.serviceRole) : ""}</div></td>"""),
("""    body.querySelectorAll("button[data-arl-open]").forEach(b => b.addEventListener("click", () => openRelationship(Number(b.dataset.arlOpen))));""",
"""    body.querySelectorAll("button[data-arl-open]").forEach(b => b.addEventListener("click", () => openRelationship(Number(b.dataset.arlOpen))));
    // 441: business services reached.
    document.getElementById("arlImpSvcBody").innerHTML = (res.data.data.services || []).map(v => `<tr><td>${esc(v.impactLevel)}</td>
        <td>${esc(v.serviceName)}<div class="arl-note">${esc(v.serviceCode)} - ${esc(label(v.serviceType))}</div></td><td>${esc(label(v.serviceStatus))}</td>
        <td>${esc(v.criticalityCode || "--")}</td><td>${esc(v.rtoHours ?? "-")} / ${esc(v.rpoHours ?? "-")} / ${esc(v.mtpdHours ?? "-")}</td>
        <td>${esc(v.businessOwnerName || "--")}<div class="arl-note">${esc(v.serviceManagerName || "")}</div></td><td>${esc(v.consumers || "--")}</td></tr>`).join("")
      || empty(7, "No business service reached.");"""),
("""    if (!state.organizationId || !ci) { body.innerHTML = empty(6, "Select an item."); return; }""",
"""    document.getElementById("arlImpSvcBody").innerHTML = "";   // 441
    if (!state.organizationId || !ci) { body.innerHTML = empty(6, "Select an item."); return; }"""),
])

for p, s in files.items():
    open(p, 'w', encoding='utf-8', newline='').write(s)
print('441 ok', len(files))
