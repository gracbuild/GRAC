D='/home/claude/w447/db/'
def body(fname, header):
    s=open(D+fname).read()
    i=s.index(header); j=s.index('\nGO\n', i)
    return s[i:j+1]
def ins_after(b, anchor, text):
    assert b.count(anchor)==1, (anchor[:70], b.count(anchor)); return b.replace(anchor, anchor+text)
def ins_before(b, anchor, text):
    assert b.count(anchor)==1, (anchor[:70], b.count(anchor)); return b.replace(anchor, text+anchor)
src={}
# ---------------- register save (446)
rs=body('446_asset_valuation.sql','CREATE OR ALTER PROCEDURE grac_practice.sp_asset_register_save'); src['rs']=rs
rs2=ins_after(rs, """         @out_status = @val_status OUTPUT, @out_message = @val_message OUTPUT, @out_changed = @val_changed OUTPUT;   -- 446
""", """    -- 447: CIA / criticality consistency of the saved asset (19.7).
    DECLARE @cons_o INT, @cons_r INT, @cons_x INT;                                             -- 447
    EXEC grac_practice.sp_asset_consistency_evaluate                                           -- 447
         @organization_id = @organization_id, @asset_id = @out_asset_id, @actor = @actor,      -- 447
         @out_opened = @cons_o OUTPUT, @out_resolved = @cons_r OUTPUT, @out_reopened = @cons_x OUTPUT;   -- 447
""")
rs2=ins_before(rs2, """    SET @out_result = N'SAVED';
""", """    INSERT @issues (severity, field_key, message)                                              -- 447
    SELECT N'WARNING', NULL,                                                                   -- 447
           LEFT(CONCAT(N'Consistency (', CASE f.severity WHEN N'INFO' THEN N'information' WHEN N'WARNING' THEN N'warning'   -- 447
                                                         WHEN N'ERROR' THEN N'error' ELSE N'approval required' END, N'): ', f.message,   -- 447
                       CASE WHEN f.status = N'PENDING_APPROVAL' THEN N' -- acceptance awaiting approval.'          -- 447
                            WHEN f.action_code = N'BLOCK_TRANSITION' THEN N' -- blocks a move to Active until corrected or accepted.'   -- 447
                            WHEN f.action_code = N'REQUIRE_RATIONALE' THEN N' -- record a rationale on the Valuation tab.'   -- 447
                            WHEN f.action_code = N'CREATE_TASK' THEN N' -- a task was opened.' ELSE N'.' END), 500)   -- 447
      FROM grac_practice.asset_consistency_finding f                                           -- 447
     WHERE f.asset_id = @out_asset_id AND f.status IN (N'OPEN', N'PENDING_APPROVAL');          -- 447
""")
src['rs2']=rs2
# ---------------- scheduler (446)
sc=body('446_asset_valuation.sql','CREATE OR ALTER PROCEDURE grac_practice.sp_asset_scheduler_run'); src['sc']=sc
sc2=ins_after(sc, """    DECLARE @vu INT;                                                                       -- 446
""", """    DECLARE @co INT, @cr INT, @cx INT;                                                     -- 447
""")
sc2=ins_before(sc2, """        -- 438: recurring asset activities (before the sweep, so new occurrences notify).
""", """        -- 447: consistency findings follow ratings, valuations and expired acceptances (19.7).
        BEGIN TRY                                                                          -- 447
            EXEC grac_practice.sp_asset_consistency_evaluate @organization_id = @org, @actor = @actor,   -- 447
                 @out_opened = @co OUTPUT, @out_resolved = @cr OUTPUT, @out_reopened = @cx OUTPUT;   -- 447
        END TRY                                                                            -- 447
        BEGIN CATCH                                                                        -- 447
            IF XACT_STATE() <> 0 ROLLBACK;                                                 -- 447
            SET @errors = @errors + 1;                                                     -- 447
            SET @err = LEFT(CONCAT(@err, CASE WHEN @err IS NULL THEN N'' ELSE CHAR(10) END,   -- 447
                                   N'Organization ', @org, N' (consistency rules): ', ERROR_MESSAGE()), 8000);   -- 447
        END CATCH                                                                          -- 447

""")
src['sc2']=sc2
# ---------------- lifecycle transition (440)
lt=body('440_asset_relationships.sql','CREATE OR ALTER PROCEDURE grac_practice.sp_asset_lifecycle_transition'); src['lt']=lt
lt2=ins_before(lt, """    -- 440: retiring the asset is blocked while active critical relationships
""", """    -- 447: open consistency findings with action Block transition (19.7, D148).
    IF @to_status_code = N'ACTIVE'                                                             -- 447
    BEGIN                                                                                      -- 447
        DECLARE @cons_o INT, @cons_r INT, @cons_x INT;                                         -- 447
        EXEC grac_practice.sp_asset_consistency_evaluate                                       -- 447
             @organization_id = @organization_id, @asset_id = @asset_id, @actor = @actor,      -- 447
             @out_opened = @cons_o OUTPUT, @out_resolved = @cons_r OUTPUT, @out_reopened = @cons_x OUTPUT;   -- 447
        DECLARE @cons NVARCHAR(1000) = (SELECT LEFT(STRING_AGG(CAST(f.message AS NVARCHAR(MAX)), N'; '), 900)   -- 447
                                          FROM grac_practice.asset_consistency_finding f       -- 447
                                         WHERE f.asset_id = @asset_id AND f.action_code = N'BLOCK_TRANSITION'   -- 447
                                           AND f.status IN (N'OPEN', N'PENDING_APPROVAL'));    -- 447
        IF @cons IS NOT NULL                                                                   -- 447
        BEGIN                                                                                  -- 447
            DECLARE @cons_msg NVARCHAR(1400) = CONCAT(N'The asset cannot become Active while consistency findings are open: ', @cons,   -- 447
                N'. Correct the asset or get the inconsistency accepted (Asset Register, Valuation tab) first.');   -- 447
            THROW 53037, @cons_msg, 1;                                                         -- 447
        END                                                                                    -- 447
    END                                                                                        -- 447
""")
src['lt2']=lt2
# ---------------- valuation get (446)
vg=body('446_asset_valuation.sql','CREATE OR ALTER PROCEDURE grac_practice.sp_asset_valuation_get'); src['vg']=vg
anchor="""     WHERE h.asset_id = @asset_id AND h.organization_id = @organization_id
     ORDER BY h.history_id DESC;
"""
vg2=ins_after(vg, anchor, """
    -- 3. Linked risks with the Asset Value the risk module reads and a review flag (447, 5.1.18.3).
    SELECT r.risk_register_id AS RiskRegisterId, r.risk_number AS RiskNumber, r.risk_title AS RiskTitle,   -- 447
           r.status_code AS RiskStatus, r.inherent_rating_name AS InherentRating, r.residual_rating_name AS ResidualRating,   -- 447
           rv.RiskAssessedDt, rv.AssetValueCategory AS RiskAssetValueCategory, rv.AssetValueScore AS RiskAssetValueScore,   -- 447
           rv.LastValueChangeDt, ISNULL(rv.ReviewSuggested, 0) AS ReviewSuggested                -- 447
      FROM grac_practice.risk_dependency_map m                                                 -- 447
      JOIN grac_practice.dependency_type_master dt ON dt.dependency_type_id = m.dependency_type_id   -- 447
                                                  AND (dt.dependency_type_code = N'ASSET' OR dt.dependency_type_name = N'Asset')   -- 447
      JOIN grac_practice.risk_register r ON r.risk_register_id = m.risk_register_id            -- 447
      LEFT JOIN grac_practice.fn_asset_risk_value(@organization_id) rv ON rv.RiskRegisterId = r.risk_register_id   -- 447
     WHERE m.dependency_object_id = @asset_id AND m.organization_id = @organization_id         -- 447
     ORDER BY ISNULL(rv.ReviewSuggested, 0) DESC, r.risk_register_id DESC;                    -- 447

    -- 4. Consistency findings of the asset, current first (447, 19.7).
    SELECT TOP (50) f.finding_id AS FindingId, f.rule_code AS RuleCode, cr.version_no AS RuleVersionNo, f.message AS Message,   -- 447
           f.severity AS Severity, f.action_code AS ActionCode, f.status AS Status, f.facts_json AS FactsJson,   -- 447
           f.detected_dt AS DetectedDt, f.resolved_dt AS ResolvedDt, f.rationale AS Rationale, f.evidence AS Evidence,   -- 447
           f.owner_employee_id AS OwnerEmployeeId, oe.employee_name AS OwnerName, f.review_date AS ReviewDate,   -- 447
           f.requested_by AS RequestedBy, f.requested_dt AS RequestedDt, f.decided_by AS DecidedBy, f.decided_dt AS DecidedDt,   -- 447
           f.decision_note AS DecisionNote, f.task_id AS TaskId, cr.override_allowed AS OverrideAllowed,   -- 447
           cr.max_override_days AS MaxOverrideDays, CONVERT(BIGINT, f.record_version) AS RecordVersion   -- 447
      FROM grac_practice.asset_consistency_finding f                                           -- 447
      JOIN grac_practice.asset_consistency_rule cr ON cr.rule_id = f.rule_id                   -- 447
      LEFT JOIN grac_practice.organization_employee oe ON oe.employee_id = f.owner_employee_id   -- 447
     WHERE f.asset_id = @asset_id AND f.organization_id = @organization_id                     -- 447
     ORDER BY CASE WHEN f.status = N'RESOLVED' THEN 1 ELSE 0 END, f.detected_dt DESC, f.finding_id DESC;   -- 447
""")
src['vg2']=vg2
for k,v in src.items(): open('/home/claude/w447/part_'+k+'.sql','w').write(v)
print({k:v.count('\n') for k,v in src.items()})
