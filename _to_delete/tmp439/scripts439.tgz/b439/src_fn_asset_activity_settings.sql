CREATE OR ALTER FUNCTION grac_practice.fn_asset_activity_settings (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT t.template_code AS TemplateCode, t.template_name AS TemplateName, t.activity_kind AS ActivityKind,
           CAST(ISNULL(s.is_active, 1) AS BIT) AS IsActive, ISNULL(s.lead_days, t.default_lead_days) AS LeadDays,
           ISNULL(s.due_soon_days, t.default_due_soon_days) AS DueSoonDays, ISNULL(s.grouping_mode, N'INDIVIDUAL') AS GroupingMode,
           s.campaign_owner_employee_id AS CampaignOwnerEmployeeId
      FROM grac_practice.asset_activity_template t
      LEFT JOIN grac_practice.asset_activity_setting s ON s.organization_id = @organization_id AND s.template_code = t.template_code;
GO
