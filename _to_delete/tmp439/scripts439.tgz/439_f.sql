-- =====================================================================
-- Verification
-- =====================================================================
SELECT '439-a template defaults and organization overrides' AS Check_,
       CASE WHEN COL_LENGTH('grac_practice.asset_activity_template', 'default_restrict_on_overdue') IS NOT NULL
             AND COL_LENGTH('grac_practice.asset_activity_setting', 'restrict_on_fail') IS NOT NULL
             AND EXISTS (SELECT 1 FROM grac_practice.asset_activity_template
                          WHERE template_code = N'CALIBRATION' AND default_result_review = 1 AND retest_days = 7
                            AND certificate_number_field_key = N'calibration_certificate_number'
                            AND default_restrict_on_overdue = N'CRITICAL,HIGH' AND default_restrict_on_fail = 1)
             AND EXISTS (SELECT 1 FROM grac_practice.asset_activity_template
                          WHERE template_code = N'EQUIPMENT_LICENCE' AND default_restrict_on_overdue = N'ALL')
            THEN 'PASS' ELSE 'FAIL' END AS Result
UNION ALL
SELECT '439-b occurrence / schedule columns and widened vocabularies',
       CASE WHEN COL_LENGTH('grac_practice.asset_activity_occurrence', 'revised_due_date') IS NOT NULL
             AND COL_LENGTH('grac_practice.asset_activity_occurrence', 'is_retest') IS NOT NULL
             AND COL_LENGTH('grac_practice.asset_activity_schedule', 'revised_due_date') IS NOT NULL
             AND EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_asset_act_occ_status' AND definition LIKE '%WAIVED%')
             AND EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_asset_ntf_occ_obj' AND definition LIKE '%ASSET_EVIDENCE%')
             AND EXISTS (SELECT 1 FROM grac_practice.asset_notification_activity
                          WHERE activity_code = N'EVIDENCE_EXPIRY' AND source_available = 1)
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '439-c result, disposition, evidence and review tables',
       CASE WHEN OBJECT_ID('grac_practice.asset_activity_result','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_activity_disposition','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_restrictive_review','U') IS NOT NULL
             AND (SELECT COUNT(*) FROM grac_practice.asset_evidence_field) >= 7
             AND EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_pm_asset_act_disp_pending' AND is_unique = 1)
             AND EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_pm_asset_rr_active' AND is_unique = 1)
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '439-d procedures present',
       CASE WHEN (SELECT COUNT(*) FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'grac_practice'
                   AND name IN ('sp_asset_activity_result_apply', 'sp_asset_activity_result_save', 'sp_asset_activity_result_decide',
                                'sp_asset_activity_disposition_apply', 'sp_asset_activity_disposition_request',
                                'sp_asset_activity_disposition_decide', 'sp_asset_restrictive_review_sync',
                                'sp_asset_restrictive_review_decide', 'sp_asset_activity_occurrence_get',
                                'sp_asset_restrictive_reviews')) = 10
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '439-e re-issues carry the 439 additions',
       CASE WHEN EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('grac_practice.fn_asset_activity_settings')
                                                     AND name = 'RestrictOnOverdue')
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_activity_task_sync')) LIKE '%result_required%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_activity_schedule_sync')) LIKE '%FAILED_RESULT%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_activity_generate')) LIKE '%is_retest%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_activity_run')) LIKE '%sp_asset_restrictive_review_sync%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.fn_asset_stored_values')) LIKE '%Failed%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.fn_asset_stored_values')) LIKE '%coverage_status%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_notification_parties')) LIKE '%ASSET_EVIDENCE%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_notification_sweep')) LIKE '%EVIDENCE_EXPIRY:EV:%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_notification_sweep')) LIKE '%revised_due_date%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_activity_config_get')) LIKE '%asset_evidence_field%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_activity_setting_save')) LIKE '%restrict_on_overdue%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_activity_schedules')) LIKE '%revised_due_date%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_activity_occurrences')) LIKE '%awaiting_decision%'
            THEN 'PASS' ELSE 'FAIL' END;
GO

-- =====================================================================
-- UAT (after deploying the API + Web build)
--   Needs: users R (records results) and V (reviewer / approver), both with
--   asset-activities; asset A (criticality High) with an open Calibration
--   occurrence and task; asset C with an open Equipment licence renewal
--   task; a vehicle V1 in use with Insurance expiry in 10 days.
--   1. Asset Activities -> Occurrences -> A -> Result: Pass, performed
--      today, no certificate number -> refused (54674). Add the number and
--      expiry, Submit -> Submitted (Calibration needs a reviewer). R tries
--      to approve -> refused (54679). V approves -> occurrence Completed;
--      Register: last calibration date, certificate number / expiry set,
--      Calibration status Valid; next date = performed + 12 months.
--   2. Next occurrence of A (or another asset): Result Fail with a note,
--      approved by V -> schedule Failed, Calibration status Failed, a
--      re-test occurrence opens due performed + 7 days (Critical
--      notification); Restrictive reviews tab shows "Calibration failed"
--      for A. Decide Restricted use with a note -> Decided. Pass the
--      re-test -> the review is Resolved on the next run.
--   3. Close a Calibration task in Task Centre before any result: Run now
--      -> the occurrence stays open, flagged "closed without an approved
--      result".
--   4. Occurrence -> Reschedule to a date 20 days later with a reason (R):
--      Pending; V approves -> due date shown as revised; Task Centre task
--      due date moved (activity "SlaExtensionApproved"); the reminder
--      occurrence in Asset Notifications is superseded and a new one opens.
--   5. Occurrence -> Waive until a date with a reason, approved -> status
--      Waived, task Cancelled; schedule Waived until the review date.
--   6. C -> Result Renewed with a new expiry -> licence expiry updated,
--      schedule next = new expiry. Another licence left Not renewed and
--      expired -> review "Equipment licence renewal expired" with the
--      licence actions (Disable / Uninstall / Replace / Purchase / Restrict /
--      Exception).
--   7. V1: Asset Notifications -> occurrences show "Vehicle insurance of V1
--      expires" (Evidence / certificate expiry); after the date passes a
--      review "Vehicle insurance expired" is raised.
--   8. Templates -> Calibration settings: reviewer off -> a submitted
--      result is approved at once; approval off -> a reschedule applies at
--      once; overdue policy NONE -> no overdue reviews.
-- =====================================================================
