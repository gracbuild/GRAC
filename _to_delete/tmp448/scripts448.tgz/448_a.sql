-- =====================================================================
-- 448  Asset privacy -- requirement settings, privacy status and gaps,
--      privacy exceptions, privacy and retention reviews, privacy
--      notifications, lifecycle gates, Asset Privacy screen
--      (Asset & Contract Management, Phase 8 increment 3)
--
-- REQUEST
-- -------
--   BRD v1.7 5.1.10 (privacy and personal data fields), 5.1.15 / 5.2.7
--   ("personal data processed = Yes or Unknown requires categories,
--   subjects, purpose, assessment, masking, encryption, retention and
--   third-party fields"), 5.1.16 ("Privacy Compliant blocked when required
--   masking, encryption, retention or assessment is incomplete";
--   "Disposed / Archived blocked until required sanitization, certificate
--   and approval exist"), 5.1.17 (personal-data-bearing asset matrix),
--   5.2.15 (privacy requirement mapping: personal data, special / health
--   data, DPIA / PIA, masking / encryption with blocking behaviour,
--   retention and disposal), 5.2.16 / 9.1.7 (privacy review, retention
--   expiry decision -- deletion, archival, legal-hold verification or
--   approved extension -- and privacy-exception expiry reminders).
--   Plan: docs/asset-contract-management.md (Phase 8.3, D154-D166).
--
-- WHAT THIS DOES
-- --------------
--   1. asset_privacy_requirement (global catalogue, 12 requirements from
--      5.1.10 / 5.1.16 / 5.1.17 / 5.2.15) and asset_privacy_setting
--      (organization and asset-type enforcement OFF / WARN / BLOCK,
--      whether an exception may be requested, longest exception).
--   2. fn_asset_privacy_values / _retention_calc / _gaps / _status: the
--      privacy facts of each asset (its 5.1.10 field values), the computed
--      retention end, the gaps per requirement (missing, partial, failed;
--      excepted when an approved exception covers it) and the privacy
--      status: Not applicable, Undetermined, Non-compliant, Incomplete,
--      Conditional, Compliant -- never Compliant while a required control
--      is incomplete (5.1.16).
--   3. asset_privacy_exception: requested with reason, compensating
--      controls, owner and expiry; approved by another person (asset-
--      privacy APPROVE); withdrawn, rejected, revoked; expires.
--   4. asset_privacy_review: one open Privacy review (due = privacy review
--      date) and one open Retention review (due = retention end, or the
--      latest extension) per asset, kept by sp_asset_privacy_sync;
--      completed with Reviewed (next review date written to the asset),
--      Delete, Archive, Legal-hold verified or Extend (approver).
--   5. Notifications (437 framework): PRIVACY_REVIEW from open privacy
--      reviews and approved exceptions, RETENTION_REVIEW from open
--      retention reviews -- sp_asset_notification_sweep and
--      sp_asset_notification_parties (439) re-issued.
--   6. Re-issued (447): sp_asset_register_save (privacy gaps as warnings,
--      reviews refreshed), sp_asset_lifecycle_transition (BLOCK gaps stop
--      a move to Active; a blocking sanitization gap stops Disposed /
--      Archived), sp_asset_scheduler_run (privacy sync per organization
--      before the notification sweep).
--   7. Menu Asset & Contract -> Asset Privacy (364; also carried in 274).
--
-- NOT DONE HERE: masking of field values on screens or exports (the
--   5.1.10 masking fields describe the asset controls); processor-contract
--   reviews (contract expiry already notifies the contract owner);
--   retention start for Employment end / Last activity (no source data);
--   privacy dashboards and reports (8.4 / 8.5).
--
-- ERROR NUMBERS: 53050-53079
--   53050 organization not found        53051 asset not found
--   53052 unknown requirement           53053 enforcement invalid
--   53054 asset type invalid            53056 exception not found
--   53057 the requirement allows no exception
--   53058 reason / controls / owner / expiry required
--   53059 expiry out of range           53060 an active exception exists
--   53061 approver is the requester     53062 action not allowed now
--   53063 exception changed by someone else
--   53064 review not found              53065 review not open
--   53066 outcome invalid or incomplete 53067 next date invalid
--   53069 review changed by someone else
--   53070 privacy gaps block a move to Active
--   53071 sanitization blocks a move to Disposed / Archived
--   53072 invalid action
--
-- ALSO EDITED: API (AssetConfig service / controller / models), Web
--   proxy (asset-privacy area), PracticeScreen + Manage.cshtml +
--   appsettings (new screen), new asset-privacy.cshtml / .js,
--   asset-register.cshtml / .js (Privacy tab), 274 (menu), docs.
-- DEPENDS ON: 420, 421, 431, 437, 439, 447.
-- Rollback: 448_asset_privacy_rollback.sql (restores the 439 and 447
--   bodies, drops the 448 objects and the menu row).
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.asset_consistency_finding','U') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_consistency_evaluate','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_valuation_sync','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_field_value_set','P') IS NULL
   OR OBJECT_ID('grac_practice.asset_notification_occurrence','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_notification_activity','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_evidence_field','U') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_activity_settings') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_ntf_asset_severity') IS NULL
   OR OBJECT_ID('grac_practice.asset_lifecycle_change','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_contract_version','U') IS NULL
   OR NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_asset_ntf_occ_obj' AND definition LIKE '%ASSET_EVIDENCE%')
   OR NOT EXISTS (SELECT 1 FROM grac_practice.asset_notification_activity WHERE activity_code = N'PRIVACY_REVIEW')
   OR NOT EXISTS (SELECT 1 FROM grac_practice.asset_notification_activity WHERE activity_code = N'RETENTION_REVIEW')
   OR NOT EXISTS (SELECT 1 FROM grac_practice.asset_field_definition WHERE field_key = N'personal_data_processed')
   OR NOT EXISTS (SELECT 1 FROM grac_practice.asset_field_definition WHERE field_key = N'privacy_review_date')
BEGIN
    RAISERROR('ABORT (448): run 420, 421, 431, 437, 439 and 447 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Requirement catalogue (global) and settings (organization / type)
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_privacy_requirement','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_privacy_requirement (
        requirement_code    NVARCHAR(30)   NOT NULL CONSTRAINT pk_pm_aprv_req PRIMARY KEY,
        requirement_name    NVARCHAR(160)  NOT NULL,
        description         NVARCHAR(600)  NOT NULL,
        brd_reference       NVARCHAR(60)   NOT NULL,
        default_enforcement NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_aprv_req_enf CHECK (default_enforcement IN (N'OFF', N'WARN', N'BLOCK')),
        block_target        NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_aprv_req_block CHECK (block_target IN (N'ACTIVE', N'DISPOSAL')),
        display_order       INT            NOT NULL,
        entered_by          NVARCHAR(100)  NOT NULL CONSTRAINT df_pm_aprv_req_eby DEFAULT N'system',
        entered_dt          DATETIME2      NOT NULL CONSTRAINT df_pm_aprv_req_edt DEFAULT SYSUTCDATETIME()
    );
    PRINT '448: asset_privacy_requirement created.';
END
GO

MERGE grac_practice.asset_privacy_requirement AS t
USING (VALUES
    (N'LAW_APPLICABILITY',  N'DPDP / GDPR applicability', N'DPDP and GDPR applicability recorded; Under Assessment is partial.', N'5.1.10', N'WARN', N'ACTIVE', 10),
    (N'ASSESSMENT',         N'Privacy owner and assessment', N'Privacy owner and privacy assessment status recorded; Pending / Conditional partial, Non-Compliant failed.', N'5.1.10, 5.1.17', N'WARN', N'ACTIVE', 20),
    (N'PROCESSING_DETAILS', N'Categories, subjects, operations, activity and purpose', N'Personal data categories, data subjects, processing operations, processing activity and purpose recorded.', N'5.1.10, 5.1.15, 5.1.17', N'WARN', N'ACTIVE', 30),
    (N'SPECIAL_DATA',       N'Special-category, health and children data', N'Special-category / health and children data recorded; Yes requires a DPIA / PIA (enhanced requirements).', N'5.1.5, 5.2.15', N'WARN', N'ACTIVE', 40),
    (N'DPIA',               N'DPIA / PIA', N'High-risk processing and DPIA / PIA required recorded; a required DPIA / PIA Approved (not started / in progress partial, rejected / expired failed).', N'5.1.10, 5.2.15', N'WARN', N'ACTIVE', 50),
    (N'MASKING',            N'Masking', N'Masking applicability recorded; when applicable, implemented with method and coverage (partially implemented partial, not implemented failed).', N'5.1.10, 5.1.16, 5.2.15', N'WARN', N'ACTIVE', 60),
    (N'ENCRYPTION',         N'Encryption', N'Encryption requirement recorded; when required, implemented (partially partial, not implemented failed).', N'5.1.10, 5.1.16, 5.2.15', N'WARN', N'ACTIVE', 70),
    (N'RETENTION',          N'Retention and legal hold', N'Retention policy, period, trigger and legal hold recorded; a valid period; a decision recorded once retention ends.', N'5.1.10, 5.1.16, 5.2.15, 9.1.7', N'WARN', N'ACTIVE', 80),
    (N'THIRD_PARTY',        N'Third-party access and cross-border transfer', N'Third-party access recorded; processor named and cross-border transfer recorded when Yes; transfer countries when transfer is Yes.', N'5.1.10', N'WARN', N'ACTIVE', 90),
    (N'REVIEW',             N'Privacy review', N'Privacy review date recorded and not passed.', N'5.1.10, 5.2.16, 9.1.7', N'WARN', N'ACTIVE', 100),
    (N'RESIDUAL_RISK',      N'Residual privacy risk', N'Residual privacy risk recorded after an approved or conditional assessment.', N'5.1.10', N'WARN', N'ACTIVE', 110),
    (N'SANITIZATION',       N'Deletion / sanitization before disposal', N'Deletion / sanitization required recorded; when required, method, date and evidence recorded before the asset is Disposed or Archived.', N'5.1.10, 5.1.16', N'BLOCK', N'DISPOSAL', 120)
) AS s(requirement_code, requirement_name, description, brd_reference, default_enforcement, block_target, display_order)
ON t.requirement_code = s.requirement_code
WHEN MATCHED AND (t.requirement_name <> s.requirement_name OR t.description <> s.description OR t.brd_reference <> s.brd_reference
               OR t.default_enforcement <> s.default_enforcement OR t.block_target <> s.block_target OR t.display_order <> s.display_order) THEN
    UPDATE SET requirement_name = s.requirement_name, description = s.description, brd_reference = s.brd_reference,
               default_enforcement = s.default_enforcement, block_target = s.block_target, display_order = s.display_order
WHEN NOT MATCHED BY TARGET THEN
    INSERT (requirement_code, requirement_name, description, brd_reference, default_enforcement, block_target, display_order, entered_by)
    VALUES (s.requirement_code, s.requirement_name, s.description, s.brd_reference, s.default_enforcement, s.block_target, s.display_order, N'seed-448');
PRINT CONCAT('448: privacy requirements upserted: ', @@ROWCOUNT);
GO

IF OBJECT_ID('grac_practice.asset_privacy_setting','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_privacy_setting (
        setting_id         BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_aprv_set PRIMARY KEY,
        organization_id    BIGINT        NOT NULL
            CONSTRAINT fk_pm_aprv_set_org REFERENCES grac_practice.organization(organization_id),
        asset_type_id      INT           NULL,
        requirement_code   NVARCHAR(30)  NOT NULL
            CONSTRAINT fk_pm_aprv_set_req REFERENCES grac_practice.asset_privacy_requirement(requirement_code),
        enforcement        NVARCHAR(10)  NOT NULL
            CONSTRAINT ck_pm_aprv_set_enf CHECK (enforcement IN (N'OFF', N'WARN', N'BLOCK')),
        exception_allowed  BIT           NOT NULL CONSTRAINT df_pm_aprv_set_exc DEFAULT 1,
        max_exception_days INT           NULL
            CONSTRAINT ck_pm_aprv_set_days CHECK (max_exception_days IS NULL OR max_exception_days BETWEEN 1 AND 1095),
        entered_by         NVARCHAR(100) NOT NULL,
        entered_dt         DATETIME2     NOT NULL CONSTRAINT df_pm_aprv_set_edt DEFAULT SYSUTCDATETIME(),
        updated_by         NVARCHAR(100) NULL,
        updated_dt         DATETIME2     NULL
    );
    CREATE UNIQUE INDEX ux_pm_aprv_set_org ON grac_practice.asset_privacy_setting(organization_id, requirement_code) WHERE asset_type_id IS NULL;
    CREATE UNIQUE INDEX ux_pm_aprv_set_type ON grac_practice.asset_privacy_setting(organization_id, asset_type_id, requirement_code) WHERE asset_type_id IS NOT NULL;
    PRINT '448: asset_privacy_setting created.';
END
GO

-- =====================================================================
-- 2. Exceptions and reviews
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_privacy_exception','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_privacy_exception (
        exception_id          BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_aprv_exc PRIMARY KEY,
        organization_id       BIGINT         NOT NULL,
        asset_id              BIGINT         NOT NULL
            CONSTRAINT fk_pm_aprv_exc_asset REFERENCES grac_practice.organization_dependency_asset(asset_id),
        requirement_code      NVARCHAR(30)   NOT NULL
            CONSTRAINT fk_pm_aprv_exc_req REFERENCES grac_practice.asset_privacy_requirement(requirement_code),
        status                NVARCHAR(20)   NOT NULL
            CONSTRAINT ck_pm_aprv_exc_status CHECK (status IN (N'PENDING_APPROVAL', N'APPROVED', N'REJECTED', N'WITHDRAWN', N'REVOKED', N'EXPIRED')),
        reason                NVARCHAR(1000) NOT NULL,
        compensating_controls NVARCHAR(1000) NOT NULL,
        owner_employee_id     BIGINT         NOT NULL,
        expiry_date           DATE           NOT NULL,
        gap_snapshot          NVARCHAR(MAX)  NULL,
        requested_by          NVARCHAR(100)  NOT NULL,
        requested_employee_id BIGINT         NULL,
        requested_dt          DATETIME2      NOT NULL CONSTRAINT df_pm_aprv_exc_rdt DEFAULT SYSUTCDATETIME(),
        decided_by            NVARCHAR(100)  NULL,
        decided_employee_id   BIGINT         NULL,
        decided_dt            DATETIME2      NULL,
        decision_note         NVARCHAR(1000) NULL,
        closed_dt             DATETIME2      NULL,
        record_version        ROWVERSION     NOT NULL
    );
    CREATE UNIQUE INDEX ux_pm_aprv_exc_live ON grac_practice.asset_privacy_exception(asset_id, requirement_code)
        WHERE status IN (N'PENDING_APPROVAL', N'APPROVED');
    CREATE INDEX ix_pm_aprv_exc_org ON grac_practice.asset_privacy_exception(organization_id, status);
    PRINT '448: asset_privacy_exception created.';
END
GO

IF OBJECT_ID('grac_practice.asset_privacy_review','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_privacy_review (
        review_id             BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_aprv_rev PRIMARY KEY,
        organization_id       BIGINT         NOT NULL,
        asset_id              BIGINT         NOT NULL
            CONSTRAINT fk_pm_aprv_rev_asset REFERENCES grac_practice.organization_dependency_asset(asset_id),
        review_kind           NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_aprv_rev_kind CHECK (review_kind IN (N'PRIVACY', N'RETENTION')),
        due_date              DATE           NOT NULL,
        status                NVARCHAR(10)   NOT NULL CONSTRAINT df_pm_aprv_rev_status DEFAULT N'OPEN'
            CONSTRAINT ck_pm_aprv_rev_status CHECK (status IN (N'OPEN', N'COMPLETED', N'CANCELLED')),
        outcome               NVARCHAR(12)   NULL
            CONSTRAINT ck_pm_aprv_rev_outcome CHECK (outcome IS NULL OR outcome IN (N'REVIEWED', N'DELETE', N'ARCHIVE', N'LEGAL_HOLD', N'EXTEND')),
        note                  NVARCHAR(1000) NULL,
        evidence              NVARCHAR(1000) NULL,
        next_date             DATE           NULL,
        extended_until        DATE           NULL,
        completed_by          NVARCHAR(100)  NULL,
        completed_employee_id BIGINT         NULL,
        completed_dt          DATETIME2      NULL,
        cancel_reason         NVARCHAR(400)  NULL,
        entered_by            NVARCHAR(100)  NOT NULL,
        entered_dt            DATETIME2      NOT NULL CONSTRAINT df_pm_aprv_rev_edt DEFAULT SYSUTCDATETIME(),
        updated_by            NVARCHAR(100)  NULL,
        updated_dt            DATETIME2      NULL,
        record_version        ROWVERSION     NOT NULL
    );
    CREATE UNIQUE INDEX ux_pm_aprv_rev_open ON grac_practice.asset_privacy_review(asset_id, review_kind) WHERE status = N'OPEN';
    CREATE INDEX ix_pm_aprv_rev_org ON grac_practice.asset_privacy_review(organization_id, status, due_date);
    PRINT '448: asset_privacy_review created.';
END
GO

-- =====================================================================
-- 3. Notification objects (437 framework): privacy reviews and exceptions
-- =====================================================================
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
                WHERE name = 'ck_pm_asset_ntf_occ_obj' AND definition LIKE '%PRIVACY_REVIEW%')
BEGIN
    IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_asset_ntf_occ_obj')
        ALTER TABLE grac_practice.asset_notification_occurrence DROP CONSTRAINT ck_pm_asset_ntf_occ_obj;
    ALTER TABLE grac_practice.asset_notification_occurrence WITH NOCHECK
        ADD CONSTRAINT ck_pm_asset_ntf_occ_obj
            CHECK (object_type IN (N'CONTRACT_VERSION', N'ASSET_MODEL', N'ASSET_OS', N'ASSET_FIRMWARE',
                                   N'TECH_EXCEPTION', N'ATTESTATION', N'ACTIVITY', N'ASSET_EVIDENCE',
                                   N'PRIVACY_REVIEW', N'PRIVACY_EXCEPTION'));                -- 448
    PRINT '448: notification object types widened (PRIVACY_REVIEW, PRIVACY_EXCEPTION).';
END
GO

UPDATE grac_practice.asset_notification_activity
   SET source_available = 1,
       source_note = CASE activity_code
           WHEN N'PRIVACY_REVIEW' THEN N'Raised from open privacy reviews (privacy review date) and approved privacy exceptions (expiry) -- 448.'
           ELSE N'Raised from open retention reviews (retention end or extension) -- 448.' END
 WHERE activity_code IN (N'PRIVACY_REVIEW', N'RETENTION_REVIEW') AND source_available = 0;
PRINT CONCAT('448: privacy notification activities have a source now: ', @@ROWCOUNT);
GO

