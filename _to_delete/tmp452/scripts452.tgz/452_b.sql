
-- =====================================================================
-- 3. Shared report sources (one rule per thing, reused by every report)
-- =====================================================================
-- Register rows: the status rule of sp_asset_register_list (current
-- status, else the legacy map), its search (name, ID, active alias -- 444)
-- and asset type filter, and "in use" from fn_asset_governance_assets
-- (450: active record, not Draft / Disposed / Archived).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_report_assets (@organization_id BIGINT, @search NVARCHAR(200), @asset_type_id INT)
RETURNS TABLE
AS
RETURN
    SELECT a.asset_id AS AssetId, a.asset_name AS AssetName, a.asset_type_id AS AssetTypeId, t.asset_type_name AS AssetTypeName,
           c.asset_category_name AS CategoryName, sc.subcategory_name AS SubcategoryName,
           st.status_code AS StatusCode, sm.status_name AS StatusName, ph.phase_name AS PhaseName,
           a.owner_id AS OwnerId, e.employee_name AS OwnerName, l.location_name AS LocationName, cr.criticality_name AS CriticalityName,
           CAST(CASE WHEN g.ExclusionReason IS NULL THEN 1 ELSE 0 END AS BIT) AS InUse,
           a.entered_dt AS EnteredDt, ISNULL(a.updated_dt, a.entered_dt) AS LastChanged
      FROM grac_practice.organization_dependency_asset a
      JOIN grac_practice.fn_asset_governance_assets(@organization_id) g ON g.AssetId = a.asset_id
      LEFT JOIN grac_practice.entity_status_master cs ON cs.entity_status_id = a.current_status_id
      LEFT JOIN grac_practice.asset_legacy_status_map ls ON ls.legacy_lifecycle_status = ISNULL(a.lifecycle_status, N'Commissioned')
     CROSS APPLY (SELECT COALESCE(cs.status_code, ls.status_code) AS status_code) st
      LEFT JOIN grac_practice.dependency_asset_category_master c ON c.asset_category_id = a.asset_category_id
      LEFT JOIN grac_practice.dependency_asset_subcategory_master sc ON sc.subcategory_id = a.asset_subcategory_id
      LEFT JOIN grac_practice.dependency_asset_type_master t ON t.asset_type_id = a.asset_type_id
      LEFT JOIN grac_practice.entity_status_master sm ON sm.entity_type = N'Asset' AND sm.status_code = st.status_code
      LEFT JOIN grac_practice.asset_lifecycle_status_phase ph ON ph.status_code = st.status_code
      LEFT JOIN grac_practice.organization_employee e ON e.employee_id = a.owner_id
      LEFT JOIN grac_practice.organization_location l ON l.location_id = a.location_id
      LEFT JOIN grac_practice.criticality_master cr ON cr.criticality_id = a.criticality_id
     WHERE a.organization_id = @organization_id
       AND (@asset_type_id IS NULL OR a.asset_type_id = @asset_type_id)
       AND (@search IS NULL OR a.asset_name LIKE N'%' + @search + N'%' OR CAST(a.asset_id AS NVARCHAR(30)) = @search
            OR EXISTS (SELECT 1 FROM grac_practice.asset_alias al
                        WHERE al.asset_id = a.asset_id AND al.is_active = 1 AND al.alias_value LIKE N'%' + @search + N'%'));
GO

-- Contracts with the version in force: the columns and search (number,
-- name, vendor) of sp_asset_contract_list; the owner of the version in
-- force, else of the latest version (same rule as the list).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_report_contracts (@organization_id BIGINT, @search NVARCHAR(200))
RETURNS TABLE
AS
RETURN
    SELECT c.contract_id AS ContractId, c.contract_number AS ContractNumber, c.contract_name AS ContractName,
           vd.vendor_name AS VendorName, ISNULL(opt.OptionLabel, c.contract_type) AS ContractType, c.contract_status AS ContractStatus,
           c.current_version_id AS CurrentVersionId, cv.version_no AS VersionInForce,
           cv.effective_start AS EffectiveStart, cv.effective_end AS EffectiveEnd, cv.notice_date AS NoticeDate, cv.decision_date AS DecisionDate,
           cv.contract_value AS ContractValue, cv.currency_code AS CurrencyCode, ow.employee_name AS ContractOwner
      FROM grac_practice.asset_contract c
      JOIN grac_practice.organization_dependency_vendor vd ON vd.vendor_id = c.vendor_id
      LEFT JOIN grac_practice.asset_contract_version cv ON cv.version_id = c.current_version_id
     OUTER APPLY (SELECT TOP 1 v.contract_owner_id FROM grac_practice.asset_contract_version v
                   WHERE v.contract_id = c.contract_id ORDER BY v.version_no DESC) lv
      LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = COALESCE(cv.contract_owner_id, lv.contract_owner_id)
     OUTER APPLY (SELECT TOP 1 o.OptionLabel FROM grac_practice.fn_asset_field_options(@organization_id) o
                   WHERE o.OptionGroup = N'asset_field.coverage_type' AND o.OptionValue = c.contract_type) opt
     WHERE c.organization_id = @organization_id
       AND (@search IS NULL OR c.contract_number LIKE N'%' + @search + N'%' OR c.contract_name LIKE N'%' + @search + N'%'
            OR vd.vendor_name LIKE N'%' + @search + N'%');
GO

-- CMDB relationships with both ends resolved through the CI catalogue
-- (440 / 441 rule: an endpoint is usable until disposed / archived /
-- retired / terminated or inactive).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_report_relationships (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT r.relationship_id AS RelationshipId, r.relationship_type_code AS TypeCode, rt.type_name AS RelationshipName,
           r.source_kind AS SourceKind, r.source_id AS SourceId, sc.CiName AS SourceName, ISNULL(sc.IsUsable, 0) AS SourceUsable,
           r.target_kind AS TargetKind, r.target_id AS TargetId, tc.CiName AS TargetName, ISNULL(tc.IsUsable, 0) AS TargetUsable,
           r.is_critical AS IsCritical, r.dependency_criticality AS DependencyCriticality, r.status AS Status,
           r.effective_from AS EffectiveFrom, r.effective_to AS EffectiveTo, r.source_code AS RecordSource,
           r.confidence_pct AS ConfidencePct, r.verification_status AS Verification, r.pending_action AS PendingAction,
           ow.employee_name AS OwnerName
      FROM grac_practice.asset_relationship r
      JOIN grac_practice.asset_relationship_type rt ON rt.type_code = r.relationship_type_code
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) sc ON sc.CiKind = r.source_kind AND sc.CiId = r.source_id
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) tc ON tc.CiKind = r.target_kind AND tc.CiId = r.target_id
      LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = r.owner_employee_id
     WHERE r.organization_id = @organization_id;
GO
PRINT '452: shared report sources created.';
GO

-- =====================================================================
-- 4. Family procedures. Called by sp_asset_report_run only, which has
--    checked the report, the permission and the filters, cleared the
--    filters the report does not take and set the paging. One result set
--    per report; TotalRows on every row (the paging contract of the list
--    procedures).
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_asset
    @report_code     NVARCHAR(40),
    @organization_id BIGINT,
    @search          NVARCHAR(200) = NULL,
    @status          NVARCHAR(60)  = NULL,
    @asset_type_id   INT           = NULL,
    @date_from       DATE          = NULL,
    @date_to         DATE          = NULL,
    @days            INT           = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    IF @report_code = N'ASSET_REGISTER'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.CategoryName AS Category, x.SubcategoryName AS Subcategory, x.AssetTypeName AS AssetType,
               x.StatusName AS LifecycleStatus, x.PhaseName AS Phase, x.OwnerName AS Owner, x.LocationName AS Location,
               x.CriticalityName AS Criticality, vr.asset_value_category AS AssetValue, cv.CoverageStatusLabel AS Coverage,
               CASE WHEN x.InUse = 1 THEN N'Yes' ELSE N'No' END AS InUse, x.LastChanged,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x
          LEFT JOIN grac_practice.asset_valuation_result vr ON vr.asset_id = x.AssetId AND vr.validation_status = N'VALID'
         OUTER APPLY grac_practice.fn_asset_coverage_summary(@organization_id, x.AssetId) cv
         WHERE (@status IS NULL OR x.StatusCode = @status)
         ORDER BY x.AssetName, x.AssetId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'ASSET_OWNERSHIP'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus,
               ow.employee_name AS Owner, COALESCE(ce.employee_name, ct.team_name + N' (team)') AS Custodian,
               d.department_name AS Department, l.location_name AS Site, h.building AS Building, h.floor AS Floor, h.room AS Room,
               h.effective_from AS AssignedSince, h.change_source AS ChangeSource,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x
          LEFT JOIN grac_practice.asset_assignment_history h ON h.asset_id = x.AssetId AND h.is_current = 1
         CROSS APPLY (SELECT ISNULL(h.asset_owner_id, x.OwnerId) AS owner_id) o
          LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = o.owner_id
          LEFT JOIN grac_practice.organization_employee ce ON h.custodian LIKE N'E:%' AND ce.employee_id = TRY_CONVERT(BIGINT, SUBSTRING(h.custodian, 3, 38))
          LEFT JOIN grac_practice.organization_team ct ON h.custodian LIKE N'T:%' AND ct.team_id = TRY_CONVERT(BIGINT, SUBSTRING(h.custodian, 3, 38))
          LEFT JOIN grac_practice.organization_department d ON d.department_id = h.department_id
          LEFT JOIN grac_practice.organization_location l ON l.location_id = h.location_id
         WHERE @status IS NULL
            OR (@status = N'NO_OWNER' AND o.owner_id IS NULL)
            OR (@status = N'NO_CUSTODIAN' AND h.custodian IS NULL)
            OR (@status = N'ASSIGNED' AND o.owner_id IS NOT NULL AND h.custodian IS NOT NULL)
         ORDER BY x.AssetName, x.AssetId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'ASSET_LIFECYCLE'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus, x.PhaseName AS Phase,
               COALESCE(sc.since_dt, x.EnteredDt) AS InStatusSince,
               DATEDIFF(DAY, COALESCE(sc.since_dt, x.EnteredDt), SYSUTCDATETIME()) AS DaysInStatus,
               ps.status_name AS PendingChangeTo, pc.requested_by AS PendingRequestedBy, pc.requested_dt AS PendingRequestedDt,
               x.OwnerName AS Owner, CASE WHEN x.InUse = 1 THEN N'Yes' ELSE N'No' END AS InUse,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x
         OUTER APPLY (SELECT MAX(COALESCE(c.decided_dt, c.requested_dt)) AS since_dt
                        FROM grac_practice.asset_lifecycle_change c
                       WHERE c.asset_id = x.AssetId AND c.to_status_code = x.StatusCode
                         AND c.change_status IN (N'COMPLETED', N'APPROVED')) sc
          LEFT JOIN grac_practice.asset_lifecycle_change pc ON pc.asset_id = x.AssetId AND pc.change_status = N'PENDING_APPROVAL'
          LEFT JOIN grac_practice.entity_status_master ps ON ps.entity_type = N'Asset' AND ps.status_code = pc.to_status_code
         WHERE (@status IS NULL OR x.StatusCode = @status)
         ORDER BY x.AssetName, x.AssetId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'ASSET_MISSING_DATA'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus, x.OwnerName AS Owner,
               gi.Denominator AS MandatoryFields, gi.Denominator - gi.Numerator AS EmptyFields, gi.Reason AS Detail,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x
          JOIN grac_practice.fn_asset_governance_items(@organization_id, N'METADATA_COMPLETENESS') gi
            ON gi.RecordKind = N'ASSET' AND gi.RecordId = x.AssetId AND gi.Outcome = N'FAIL'
         ORDER BY gi.Denominator - gi.Numerator DESC, x.AssetName, x.AssetId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'ASSET_MOVEMENT'
    BEGIN
        ;WITH mv AS (
            SELECT hh.assignment_id, hh.asset_id, hh.asset_owner_id, hh.custodian, hh.department_id, hh.location_id,
                   hh.building, hh.floor, hh.room, hh.effective_from, hh.effective_to, hh.is_current, hh.change_source,
                   hh.entered_by, hh.entered_dt,
                   LAG(hh.location_id) OVER (PARTITION BY hh.asset_id ORDER BY hh.effective_from, hh.assignment_id) AS prev_location_id,
                   LAG(hh.asset_owner_id) OVER (PARTITION BY hh.asset_id ORDER BY hh.effective_from, hh.assignment_id) AS prev_owner_id,
                   LAG(hh.custodian) OVER (PARTITION BY hh.asset_id ORDER BY hh.effective_from, hh.assignment_id) AS prev_custodian
              FROM grac_practice.asset_assignment_history hh
             WHERE hh.organization_id = @organization_id
        )
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, mv.effective_from AS EffectiveFrom, mv.effective_to AS EffectiveTo,
               pl.location_name AS PreviousSite, l.location_name AS Site, mv.building AS Building, mv.floor AS Floor, mv.room AS Room,
               po.employee_name AS PreviousOwner, ow.employee_name AS Owner,
               COALESCE(pce.employee_name, pct.team_name + N' (team)') AS PreviousCustodian,
               COALESCE(ce.employee_name, ct.team_name + N' (team)') AS Custodian,
               d.department_name AS Department, mv.change_source AS ChangeSource, mv.entered_by AS RecordedBy, mv.entered_dt AS RecordedDt,
               CASE WHEN mv.is_current = 1 THEN N'Yes' ELSE N'No' END AS IsCurrent,
               COUNT(*) OVER () AS TotalRows
          FROM mv
          JOIN grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x ON x.AssetId = mv.asset_id
          LEFT JOIN grac_practice.organization_location pl ON pl.location_id = mv.prev_location_id
          LEFT JOIN grac_practice.organization_location l ON l.location_id = mv.location_id
          LEFT JOIN grac_practice.organization_employee po ON po.employee_id = mv.prev_owner_id
          LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = mv.asset_owner_id
          LEFT JOIN grac_practice.organization_employee pce ON mv.prev_custodian LIKE N'E:%' AND pce.employee_id = TRY_CONVERT(BIGINT, SUBSTRING(mv.prev_custodian, 3, 38))
          LEFT JOIN grac_practice.organization_team pct ON mv.prev_custodian LIKE N'T:%' AND pct.team_id = TRY_CONVERT(BIGINT, SUBSTRING(mv.prev_custodian, 3, 38))
          LEFT JOIN grac_practice.organization_employee ce ON mv.custodian LIKE N'E:%' AND ce.employee_id = TRY_CONVERT(BIGINT, SUBSTRING(mv.custodian, 3, 38))
          LEFT JOIN grac_practice.organization_team ct ON mv.custodian LIKE N'T:%' AND ct.team_id = TRY_CONVERT(BIGINT, SUBSTRING(mv.custodian, 3, 38))
          LEFT JOIN grac_practice.organization_department d ON d.department_id = mv.department_id
         WHERE (@date_from IS NULL OR mv.effective_from >= @date_from)
           AND (@date_to IS NULL OR mv.effective_from <= @date_to)
         ORDER BY mv.effective_from DESC, mv.assignment_id DESC
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'ASSET_DISPOSAL'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus, x.OwnerName AS Owner,
               pv.dsreq AS DeletionSanitizationRequired, pv.sreq AS SanitizationRequired, pv.smeth AS SanitizationMethod,
               pv.sdate AS SanitizationDate, CASE WHEN pv.sev IS NULL THEN N'No' ELSE N'Yes' END AS EvidenceRecorded,
               CAST(NULLIF(CONCAT_WS(N', ',
                    CASE WHEN pv.dsreq IS NULL THEN N'deletion / sanitization required' END,
                    CASE WHEN (pv.sreq = N'YES' OR pv.dsreq = N'YES') AND pv.smeth IS NULL THEN N'method' END,
                    CASE WHEN (pv.sreq = N'YES' OR pv.dsreq = N'YES') AND pv.sdate IS NULL THEN N'date' END,
                    CASE WHEN (pv.sreq = N'YES' OR pv.dsreq = N'YES') AND pv.sev IS NULL THEN N'evidence' END), N'') AS NVARCHAR(200)) AS NotRecorded,
               ps.status_name AS PendingChangeTo,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x
         OUTER APPLY grac_practice.fn_asset_privacy_values(@organization_id, x.AssetId) pv
          LEFT JOIN grac_practice.asset_lifecycle_change pc ON pc.asset_id = x.AssetId AND pc.change_status = N'PENDING_APPROVAL'
          LEFT JOIN grac_practice.entity_status_master ps ON ps.entity_type = N'Asset' AND ps.status_code = pc.to_status_code
         WHERE x.StatusCode IN (N'PENDING_DECOMMISSION', N'SANITIZATION_PENDING', N'DISPOSAL_APPROVAL', N'DISPOSED', N'ARCHIVED')
           AND (@status IS NULL OR x.StatusCode = @status)
         ORDER BY x.AssetName, x.AssetId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE
        THROW 53101, 'Unknown report for the Asset family.', 1;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_attestation
    @report_code     NVARCHAR(40),
    @organization_id BIGINT,
    @search          NVARCHAR(200) = NULL,
    @status          NVARCHAR(60)  = NULL,
    @asset_type_id   INT           = NULL,
    @date_from       DATE          = NULL,
    @date_to         DATE          = NULL,
    @days            INT           = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    IF @report_code IN (N'ATT_COMPLIANCE', N'ATT_OVERDUE')
    BEGIN
        -- Display status of the attestation list (431): open and past due = Overdue.
        SELECT t.attestation_id AS AttestationId, x.AssetId, x.AssetName, x.AssetTypeName AS AssetType,
               t.attestation_type AS AttestationType, t.assignee_role AS AssigneeRole,
               COALESCE(e.employee_name, tm.team_name + N' (team)') AS Assignee, t.due_date AS DueDate, ds.display_status AS DisplayStatus,
               CASE WHEN t.due_date < @today AND ds.display_status IN (N'OVERDUE', N'ESCALATED')
                    THEN DATEDIFF(DAY, t.due_date, @today) ELSE 0 END AS DaysOverdue,
               t.response AS Response, t.response_dt AS RespondedDt, t.closed_dt AS ClosedDt,
               CASE WHEN t.status = N'CANCELLED' THEN N'Excluded'
                    WHEN t.status IN (N'CONFIRMED', N'CLOSED', N'RESOLVED') THEN N'Yes' ELSE N'No' END AS Compliant,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.asset_attestation t
          JOIN grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x ON x.AssetId = t.asset_id
         CROSS APPLY (SELECT CASE WHEN t.status IN (N'GENERATED', N'PENDING', N'IN_PROGRESS') AND t.due_date < @today
                                  THEN N'OVERDUE' ELSE t.status END AS display_status) ds
          LEFT JOIN grac_practice.organization_employee e ON e.employee_id = t.assignee_employee_id
          LEFT JOIN grac_practice.organization_team tm ON tm.team_id = t.assignee_team_id
         WHERE t.organization_id = @organization_id
           AND (@report_code = N'ATT_COMPLIANCE' OR ds.display_status IN (N'OVERDUE', N'ESCALATED'))
           AND (@status IS NULL OR ds.display_status = @status)
           AND (@date_from IS NULL OR t.due_date >= @date_from)
           AND (@date_to IS NULL OR t.due_date <= @date_to)
         ORDER BY t.due_date DESC, t.attestation_id DESC
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code IN (N'ATT_EXCEPTIONS', N'ATT_LOST_DAMAGED', N'ATT_SLA')
    BEGIN
        -- One display shape of the exception list (432): SLA state and escalation level.
        SELECT v.ExceptionId, v.AssetId, v.AssetName, v.AssetTypeName AS AssetType, x.StatusName AS AssetLifecycleStatus,
               v.AttestationId, v.Category, v.Severity, v.CriticalityName AS Criticality, v.Description,
               v.ReportedByName AS ReportedBy, v.ReportedDt, DATEDIFF(DAY, v.ReportedDt, SYSUTCDATETIME()) AS AgeDays,
               v.InvestigatorName AS Investigator, v.StatusName AS Status,
               v.StartDueDate, v.StartedDt, CASE WHEN v.StartOverdue = 1 THEN N'Yes' ELSE N'No' END AS StartOverdue,
               v.ResolutionDue, v.PausedDays, v.OverdueDays, v.EscalationLevel,
               v.Outcome, v.ResolutionNarrative, v.ResolvedByName AS ResolvedBy, v.ResolvedDt, v.ApprovedByName AS ApprovedBy, v.ClosedDt,
               v.SecRemoteLockWipe AS RemoteLockWipe, v.SecCredentialReview AS CredentialReview,
               v.SecPrivacyAssessment AS PrivacyAssessment, v.SecAccessRevocation AS AccessRevocation, v.SecMonitoring AS Monitoring,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_verification_exception_view(@organization_id, NULL) v
          JOIN grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x ON x.AssetId = v.AssetId
         WHERE (@report_code <> N'ATT_EXCEPTIONS'
                OR ((@status IS NULL OR v.StatusCode = @status)
                    AND (@date_from IS NULL OR CAST(v.ReportedDt AS DATE) >= @date_from)
                    AND (@date_to IS NULL OR CAST(v.ReportedDt AS DATE) <= @date_to)))
           AND (@report_code <> N'ATT_LOST_DAMAGED'
                OR ((v.Category IN (N'ASSET_LOST', N'ASSET_DAMAGED', N'ASSET_NOT_FOUND') OR v.Outcome IN (N'LOST_CONFIRMED', N'DAMAGE_CONFIRMED'))
                    AND (@status IS NULL
                         OR (@status = N'OPEN' AND v.StatusCode NOT IN (N'CLOSED', N'CANCELLED'))
                         OR (@status = N'CONFIRMED' AND v.Outcome IN (N'LOST_CONFIRMED', N'DAMAGE_CONFIRMED')))))
           AND (@report_code <> N'ATT_SLA'
                OR (v.StatusCode NOT IN (N'CLOSED', N'CANCELLED')
                    AND (@status IS NULL
                         OR (@status = N'BREACHED' AND (v.StartOverdue = 1 OR v.OverdueDays > 0))
                         OR (@status = N'ON_TRACK' AND v.StartOverdue = 0 AND v.OverdueDays = 0))))
         ORDER BY v.OverdueDays DESC, v.ReportedDt DESC, v.ExceptionId DESC
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE
        THROW 53101, 'Unknown report for the Attestation family.', 1;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_cmdb
    @report_code     NVARCHAR(40),
    @organization_id BIGINT,
    @search          NVARCHAR(200) = NULL,
    @status          NVARCHAR(60)  = NULL,
    @asset_type_id   INT           = NULL,
    @date_from       DATE          = NULL,
    @date_to         DATE          = NULL,
    @days            INT           = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    IF @report_code IN (N'CMDB_RELATIONSHIPS', N'CMDB_CRITICAL')
    BEGIN
        SELECT r.RelationshipId, r.SourceKind, r.SourceName, r.RelationshipName AS Relationship, r.TargetKind, r.TargetName,
               CASE WHEN r.IsCritical = 1 THEN N'Yes' ELSE N'No' END AS Critical, r.DependencyCriticality, r.Status,
               r.EffectiveFrom, r.EffectiveTo, r.RecordSource, r.ConfidencePct, r.Verification, r.OwnerName AS Owner,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_relationships(@organization_id) r
         WHERE (@search IS NULL OR r.SourceName LIKE N'%' + @search + N'%' OR r.TargetName LIKE N'%' + @search + N'%'
                OR r.RelationshipName LIKE N'%' + @search + N'%')
           AND (@report_code <> N'CMDB_RELATIONSHIPS' OR @status IS NULL OR r.Status = @status)
           AND (@report_code <> N'CMDB_CRITICAL'
                OR (r.Status = N'ACTIVE' AND (r.IsCritical = 1 OR r.DependencyCriticality IN (N'CRITICAL', N'HIGH'))
                    AND (@status IS NULL OR r.DependencyCriticality = @status)))
         ORDER BY r.SourceName, r.RelationshipName, r.TargetName, r.RelationshipId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'CMDB_QUALITY'
    BEGIN
        SELECT r.RelationshipId, q.issue_label AS Issue, r.SourceKind, r.SourceName, r.RelationshipName AS Relationship,
               r.TargetKind, r.TargetName, r.Status, r.Verification, r.EffectiveTo, r.ConfidencePct, r.PendingAction, r.OwnerName AS Owner,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_relationships(@organization_id) r
         CROSS APPLY (VALUES
                (N'DISPUTED', N'Disputed', CASE WHEN r.Status = N'DISPUTED' THEN 1 ELSE 0 END),
                (N'PROPOSED', N'Awaiting approval', CASE WHEN r.Status = N'PROPOSED' THEN 1 ELSE 0 END),
                (N'UNVERIFIED', N'Active, unverified', CASE WHEN r.Status = N'ACTIVE' AND r.Verification = N'UNVERIFIED' THEN 1 ELSE 0 END),
                (N'EXPIRED', N'Active past end date', CASE WHEN r.Status = N'ACTIVE' AND r.EffectiveTo < @today THEN 1 ELSE 0 END),
                (N'UNUSABLE', N'Endpoint not usable', CASE WHEN r.Status = N'ACTIVE' AND (r.SourceUsable = 0 OR r.TargetUsable = 0) THEN 1 ELSE 0 END),
                (N'PENDING_CHANGE', N'Change awaiting approval', CASE WHEN r.PendingAction IS NOT NULL THEN 1 ELSE 0 END),
                (N'LOW_CONFIDENCE', N'Confidence below 50',
                    CASE WHEN r.ConfidencePct < 50 AND r.Status NOT IN (N'INACTIVE', N'RETIRED') THEN 1 ELSE 0 END)
             ) q(issue_code, issue_label, hit)
         WHERE q.hit = 1 AND (@status IS NULL OR q.issue_code = @status)
           AND (@search IS NULL OR r.SourceName LIKE N'%' + @search + N'%' OR r.TargetName LIKE N'%' + @search + N'%'
                OR r.RelationshipName LIKE N'%' + @search + N'%')
         ORDER BY q.issue_code, r.SourceName, r.RelationshipId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'CMDB_ORPHANS'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus, x.OwnerName AS Owner,
               x.LocationName AS Location, x.CriticalityName AS Criticality,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x
         WHERE x.InUse = 1
           AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_relationship r
                            WHERE r.organization_id = @organization_id AND r.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')
                              AND ((r.source_kind = N'ASSET' AND r.source_id = x.AssetId)
                                   OR (r.target_kind = N'ASSET' AND r.target_id = x.AssetId)))
         ORDER BY x.AssetName, x.AssetId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'CMDB_TOPOLOGY'
    BEGIN
        SELECT b.service_code AS ServiceCode, b.service_name AS ServiceName, b.service_type AS ServiceType, b.status AS ServiceStatus,
               bo.employee_name AS BusinessOwner, r.SourceKind AS SupportingKind, r.SourceName AS SupportingItem,
               r.Status AS RelationshipStatus, CASE WHEN r.IsCritical = 1 THEN N'Yes' WHEN r.IsCritical = 0 THEN N'No' END AS Critical,
               r.DependencyCriticality,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.business_service b
          LEFT JOIN grac_practice.fn_asset_report_relationships(@organization_id) r
            ON r.TypeCode = N'SUPPORTS_SERVICE' AND r.TargetKind = N'SERVICE' AND r.TargetId = b.service_id
           AND r.Status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')
          LEFT JOIN grac_practice.organization_employee bo ON bo.employee_id = b.business_owner_employee_id
         WHERE b.organization_id = @organization_id
           AND (@status IS NULL OR b.status = @status)
           AND (@search IS NULL OR b.service_name LIKE N'%' + @search + N'%' OR b.service_code LIKE N'%' + @search + N'%'
                OR r.SourceName LIKE N'%' + @search + N'%')
         ORDER BY b.service_name, b.service_id, r.SourceKind, r.SourceName
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE
        THROW 53101, 'Unknown report for the CMDB and Service family.', 1;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_discovery
    @report_code     NVARCHAR(40),
    @organization_id BIGINT,
    @search          NVARCHAR(200) = NULL,
    @status          NVARCHAR(60)  = NULL,
    @asset_type_id   INT           = NULL,
    @date_from       DATE          = NULL,
    @date_to         DATE          = NULL,
    @days            INT           = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @kind NVARCHAR(16) = CASE @report_code WHEN N'DSC_CONFLICTS' THEN N'CONFLICT'
                                                   WHEN N'DSC_DUPLICATES' THEN N'DUPLICATE' ELSE @status END;

    IF @report_code = N'DSC_COVERAGE'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus,
               dc.LinkCount, dc.FreshLinkCount, dc.IdentityScore, dc.LastObservedDt, dc.OpenConflictCount,
               dc.AttributeDisagreementCount, dc.LastVerifiedDate, dc.OverallStatus AS DataConfidence,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_discovery_confidence(@organization_id) dc
          JOIN grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x ON x.AssetId = dc.AssetId
         WHERE (@status IS NULL OR dc.OverallStatus = @status)
         ORDER BY x.AssetName, x.AssetId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'DSC_STALE'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, ss.StatusName AS LifecycleStatus, ss.LinkCount,
               ss.LastObservedDt, ss.DaysUnseen, ss.RetireAfterDays AS AgingRuleDays,
               CASE WHEN ss.IsStale = 1 THEN N'Yes' ELSE N'No' END AS Stale, ss.OpenReviewId, ss.LastDismissedDt,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_stale_state(@organization_id) ss
          JOIN grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x ON x.AssetId = ss.AssetId
         WHERE ss.IsListed = 1
         ORDER BY ss.DaysUnseen DESC, x.AssetName
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'DSC_SOURCES'
    BEGIN
        -- Health: the source list rule (442).
        SELECT s.source_code AS SourceCode, s.source_name AS SourceName, s.source_type AS SourceType, s.collection_mode AS CollectionMode,
               ow.employee_name AS Owner, CASE WHEN s.is_active = 1 THEN N'Yes' ELSE N'No' END AS Active,
               s.expected_interval_hours AS ExpectedIntervalHours, s.last_run_dt AS LastRunDt, s.last_run_status AS LastRunStatus,
               DATEADD(HOUR, s.expected_interval_hours, s.last_run_dt) AS NextRunDueDt, h.health AS Health,
               b.batches AS Batches, b.failed AS FailedBatches, b.records AS Records, b.updated AS Updated,
               b.exceptions AS Exceptions, b.errors AS Errors,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.asset_discovery_source s
          LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = s.owner_employee_id
         CROSS APPLY (SELECT CASE WHEN s.last_run_dt IS NULL THEN N'NEVER'
                                  WHEN s.last_run_status = N'FAILED' THEN N'FAILED'
                                  WHEN s.last_run_status = N'PARTIAL'
                                       OR DATEADD(HOUR, s.expected_interval_hours, s.last_run_dt) < SYSUTCDATETIME() THEN N'WARNING'
                                  ELSE N'SUCCESS' END AS health) h
         OUTER APPLY (SELECT COUNT(*) AS batches, SUM(CASE WHEN bt.status = N'FAILED' THEN 1 ELSE 0 END) AS failed,
                             ISNULL(SUM(bt.record_count), 0) AS records, ISNULL(SUM(bt.updated_count), 0) AS updated,
                             ISNULL(SUM(bt.exception_count), 0) AS exceptions, ISNULL(SUM(bt.error_count), 0) AS errors
                        FROM grac_practice.asset_discovery_batch bt
                       WHERE bt.source_id = s.source_id AND bt.received_dt >= DATEADD(DAY, -@days, SYSUTCDATETIME())) b
         WHERE s.organization_id = @organization_id
           AND (@status IS NULL OR h.health = @status)
           AND (@search IS NULL OR s.source_name LIKE N'%' + @search + N'%' OR s.source_code LIKE N'%' + @search + N'%')
         ORDER BY s.source_name
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code IN (N'DSC_RECON', N'DSC_CONFLICTS', N'DSC_DUPLICATES')
    BEGIN
        SELECT e.exception_id AS ExceptionId, e.exception_kind AS Kind, src.source_name AS Source, e.external_key AS ExternalKey,
               a.asset_name AS Asset, oa.asset_name AS OtherAsset, e.field_key AS FieldKey,
               e.current_value AS CurrentValue, e.observed_value AS ObservedValue, e.match_score AS MatchScore,
               e.raised_count AS RaisedCount, e.entered_dt AS RaisedDt, DATEDIFF(DAY, e.entered_dt, SYSUTCDATETIME()) AS AgeDays,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.asset_reconciliation_exception e
          JOIN grac_practice.asset_discovery_source src ON src.source_id = e.source_id
          LEFT JOIN grac_practice.organization_dependency_asset a ON a.asset_id = e.asset_id
          LEFT JOIN grac_practice.organization_dependency_asset oa ON oa.asset_id = e.other_asset_id
         WHERE e.organization_id = @organization_id AND e.status = N'OPEN'
           AND (@kind IS NULL OR e.exception_kind = @kind)
           AND (@search IS NULL OR a.asset_name LIKE N'%' + @search + N'%' OR oa.asset_name LIKE N'%' + @search + N'%'
                OR e.external_key LIKE N'%' + @search + N'%' OR e.field_key LIKE N'%' + @search + N'%')
         ORDER BY e.entered_dt, e.exception_id
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'DSC_MERGE_SPLIT'
    BEGIN
        SELECT ev.event_id AS EventId, ev.event_kind AS Kind, sv.asset_name AS SurvivingAsset, m.member_count AS MemberCount,
               m.members AS Members, ev.status AS Status, CASE WHEN ev.is_critical = 1 THEN N'Yes' ELSE N'No' END AS Critical,
               ev.reason AS Reason, ev.requested_by AS RequestedBy, ev.requested_dt AS RequestedDt,
               ev.executed_by AS ExecutedBy, ev.executed_dt AS ExecutedDt, ev.recovered_by AS RecoveredBy, ev.recovered_dt AS RecoveredDt,
               ev.recovery_reason AS RecoveryReason,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.asset_merge_split_event ev
          JOIN grac_practice.organization_dependency_asset sv ON sv.asset_id = ev.survivor_asset_id
         OUTER APPLY (SELECT COUNT(*) AS member_count,
                             STRING_AGG(CAST(ma.asset_name AS NVARCHAR(MAX)), N'; ') WITHIN GROUP (ORDER BY mm.sequence_no) AS members
                        FROM grac_practice.asset_merge_split_member mm
                        JOIN grac_practice.organization_dependency_asset ma ON ma.asset_id = mm.asset_id
                       WHERE mm.event_id = ev.event_id) m
         WHERE ev.organization_id = @organization_id
           AND (@status IS NULL OR ev.status = @status)
           AND (@date_from IS NULL OR CAST(ev.requested_dt AS DATE) >= @date_from)
           AND (@date_to IS NULL OR CAST(ev.requested_dt AS DATE) <= @date_to)
           AND (@search IS NULL OR sv.asset_name LIKE N'%' + @search + N'%' OR m.members LIKE N'%' + @search + N'%')
         ORDER BY ev.requested_dt DESC, ev.event_id DESC
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE
        THROW 53101, 'Unknown report for the Discovery and Data Quality family.', 1;
END
GO
PRINT '452: Asset, Attestation, CMDB and Discovery report procedures created.';
GO
