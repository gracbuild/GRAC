# Third-Party Management -- lifecycle redesign (target design and phase plan)

Source: "GRAC Third-Party Management Lifecycle Redesign -- Functional &
Technical Change Document v1.4" (attached 2026-11-07).
Status: **for review.** Section 18 of the source says the architecture,
schema, APIs, screens and retirement plan must be reviewed before they are
built. This document is that review pack. Phase 1 is built in migration
521 (section 12). Phases 2 to 6 are designs only until they are approved.

Decisions taken with the product owner on 2026-11-07:

| # | Question | Answer |
|---|---|---|
| Q1 | What happens to the TPRM module already built (486-490, 507)? | **Restructure it.** The core model moves to the new lifecycle. Pieces that already fit (configuration layers, versioned templates, questionnaires, evidence linking, audit, the dashboard frame) are kept. |
| Q2 | What is delivered in this round? | This design, plus Phase 1. |
| Q3 | Is there TPRM data in UAT that must be kept? | No, test data only. Tables may be reshaped, with no data migration. |
| Q4 | What happens to the vendor function under Organization -> Dependencies? | It stays untouched in this round. Section 14 is the data-disposition plan; retiring it is a separate decision. |

## Contents

1. Principles carried into the design
2. Where the current module stands against the target
3. Lifecycle and state models
4. Logical entities -> physical objects
5. Rules engines (qualification, consolidation, exposure comparison)
6. Integration with GRAC shared capabilities
7. Navigation and screens
8. Authorization and segregation of duties
9. API surface
10. Reporting
11. Phase plan
12. Phase 1 as built (migration 521)
13. What happens to each current TPRM object
14. Legacy vendor (Settings -> Dependencies): data-disposition plan
15. Open points for review

---

## 1. Principles carried into the design

* **The vendor is the identity, the engagement is the exposure, and the
  TPRR is the consolidated risk record** (source section 19). These are
  three separate records. None of them is folded into another.
* **Registration is not a risk approval.** Registering a vendor never
  qualifies it, never admits it to the TPRR and never starts an
  assessment.
* **Qualification is a gate, not a score.** It runs on rules (mandatory
  triggers, combinations, exclusions and escalations) over Yes / No /
  Not Applicable / Unable to Determine answers. It is kept apart from the
  weighted inherent-risk model.
* **One TPRR record per vendor per organization.** Further qualifying
  engagements attach to that record; they never create a second one.
  Consolidation must not average away a critical engagement.
* **An approved rating is never overwritten silently.** A change produces
  a change event. A reassessment the system raises can be downgraded or
  waived only with a written rationale and a designated approval.
* **No second engine.** Risk treatment and acceptance, evidence, issues
  and actions, audit trace and notifications use the GRAC capabilities
  that already exist (section 6).
* **No dependency on legacy vendor objects.** Nothing in TPM reads or
  writes `organization_dependency_vendor` (source section 17).
* House rules stay the same: procedures own every rule (`grac_practice`
  schema). The API binds parameters and shapes results. The Web tier
  checks the session, the organization and the menu grant, then proxies.
  Every change writes an audit row.

## 2. Where the current module stands against the target

| Target capability | Current TPRM (486-490, 507) | Gap |
|---|---|---|
| Vendor Registry as the authoritative identity | `tprm_third_party` is a full identity record, but it is **linked to the legacy vendor** (`vendor_id`), offers "Import from vendors", and its status is **driven by engagement stages** | Remove the legacy link. Status gets controlled transitions of its own (Draft / Active / Inactive / Suspended / Archived). Duplicate matches are reviewed and recorded instead of just confirmed. **Phase 1** |
| Duplicate detection on configurable attributes | Fixed rules (identifiers, normalised name), with the legacy vendor name also checked | The match attributes become organization-configurable. **Phase 1** |
| Engagement with full exposure attributes | Has scope items (functions, processes, applications, data, access, locations, fourth parties), criticality, data exposure, service model, RTO / RPO | Add service recipient, substitutability, customer impact and exit dependencies. **Phase 1** |
| Qualification & materiality gate | **None.** Every engagement goes straight to inherent risk | New. **Phase 2** |
| Consolidated TPRR | **None.** Risk, due diligence and the decision are per engagement | New TPRR record. Inherent risk, controls, residual risk and the decision move from the engagement to the TPRR, with engagement exposure kept. **Phase 3** |
| New engagement for an existing TPRR vendor | Material change on a live engagement flags reassessment | Exposure comparison against the consolidated profile, giving NO_MATERIAL_CHANGE / IMPACT_REVIEW_REQUIRED / INHERENT_REASSESSMENT_REQUIRED. **Phase 3** |
| Core + service-specific due diligence | Questionnaire applicability already uses core / service category / tier / data / access | Split into a vendor-level core round (TPRR) and engagement-level service modules. **Phase 4** |
| Contracts & SLAs | Engagement holds a contract reference, with an optional link to `asset_contract` | TPM-owned contract, clause obligation and service-level records. **Phase 4** |
| Subcontractors | Fourth parties are scope items | Subcontractor records with an approval and a service chain. **Phase 5** |
| Exit | EXIT_CHECK items on the engagement | Exit plan with transition tasks and closure evidence. **Phase 5** |
| Monitoring & reassessment | Monitoring sweep, reviews, triggers | Change events feed the reassessment path; outputs create GRAC actions. **Phase 5** |
| Regulatory overlays | `is_regulatory` / source fields on library and questions | Overlays per regime, with the rule-set source and version kept per decision. **Phases 2 and 6** |

## 3. Lifecycle and state models

### 3.1 Vendor (Vendor Registry) -- Phase 1

States (reference list `TP_STATUS`, meanings fixed, labels configurable):

```
            register                 activate (complete + duplicates reviewed)
  (new) ----------------> DRAFT ------------------------------> ACTIVE
                            |                                  |   ^
                            | archive                  suspend |   | reinstate
                            v                                  v   |
                         ARCHIVED <---- archive ---- INACTIVE <-- SUSPENDED
                            |                         ^   |
                            +--- restore -------------+   +--- reactivate --> ACTIVE
                                 (to DRAFT if never active)
```

| From -> To | Gate (procedure `fn_tprm_vendor_transitions`) | Permission |
|---|---|---|
| DRAFT -> ACTIVE | Legal name, vendor type, primary service category, country, relationship owner and a primary contact are present. Every current possible duplicate has a recorded review. | Vendor Registry EDIT |
| ACTIVE -> SUSPENDED | Reason | APPROVE |
| SUSPENDED -> ACTIVE | Reason | APPROVE |
| ACTIVE / SUSPENDED -> INACTIVE | No open engagement | APPROVE |
| INACTIVE -> ACTIVE | Reason | APPROVE |
| DRAFT / INACTIVE -> ARCHIVED | No open engagement | APPROVE |
| ARCHIVED -> DRAFT / INACTIVE | Restore. DRAFT if the vendor was never active, else INACTIVE | APPROVE |

Every transition records the actor, time, previous and new state, a
reason (mandatory) and an optional evidence reference in
`tprm_third_party_status_history`, and writes `practice_audit_trace`. A new
engagement may be opened only for a DRAFT or ACTIVE vendor.

### 3.2 Engagement -- Phase 1 attributes, Phase 2 / 3 pipeline

Target pipeline (source section 15):

```
DRAFT -> UNDER_QUALIFICATION -> [FURTHER_REVIEW] -> NOT_CANDIDATE   (stays in the registry, rationale kept)
                                                -> ADMITTED (to TPRR)
ADMITTED -> ONBOARDING -> ACTIVE -> SUSPENDED -> EXITING -> TERMINATED
any pre-ACTIVE state -> CANCELLED
```

The risk stages that the engagement carries today (`RISK_ASSESSED`,
`DUE_DILIGENCE`, `PENDING_DECISION`, `APPROVED`) move to the TPRR record
in Phase 3. Until then they keep working on the engagement unchanged.
This is a deliberate interim state, written down in section 13.

### 3.3 Qualification -- Phase 2

```
DRAFT -> SUBMITTED -> system recommendation (POTENTIAL_CANDIDATE | FURTHER_REVIEW | NOT_CANDIDATE)
      -> DECIDED (ADMIT | NOT_CANDIDATE | RETURN_FOR_FURTHER_REVIEW)   decider <> submitter
```

### 3.4 TPRR record -- Phase 3

```
OPEN (first engagement admitted) -> UNDER_ASSESSMENT -> PENDING_APPROVAL -> APPROVED
APPROVED -> REASSESSMENT_PENDING (change event) -> UNDER_ASSESSMENT ...
APPROVED -> CLOSED (no admitted engagement left open, exit complete)
```

The approved inherent and residual ratings stay on the record until a new
assessment is approved. A pending reassessment never replaces them.

## 4. Logical entities -> physical objects

The physical names keep the module prefix `tprm_`. Source section 12 says
the logical model "is not a mandate for a particular physical schema".
Keeping the prefix avoids renaming 60 procedures for no functional gain.

| Logical entity | Physical object | Phase | Note |
|---|---|---|---|
| TPM_Vendor | `tprm_third_party` (+ `_contact`, `_category`, `_status_history`) | 1 | Restructured: legacy `vendor_id` dropped, `duplicate_of_third_party_id` added, controlled states |
| (duplicate review) | `tprm_vendor_match_review` | 1 | New. One row per vendor pair, decision NOT_DUPLICATE / DUPLICATE, rationale |
| TPM_Engagement | `tprm_engagement` (+ `_scope`, `_link`, `_history`, `tprm_exposure_snapshot`) | 1 / 2 / 3 | Phase 1: new exposure attributes. Phase 2: pipeline status. Phase 3: risk columns move to the TPRR |
| TPM_Qualification | `tprm_qualification`, `tprm_qualification_response`, `tprm_qualification_rule_result`, `tprm_qualification_rule_set` (pinned versions) | 2 | New |
| (qualification configuration) | template kind `QUALIFICATION` in `tprm_template` / `tprm_template_version`, plus `tprm_qual_criterion`, `tprm_qual_rule` | 2 | Reuses the versioning, baseline and adopt mechanism (486 D1 / D2) |
| TPM_ThirdPartyRiskRecord | `tprm_tprr_record` | 3 | New. Unique active row per (organization, third party) |
| TPM_ThirdPartyEngagement | `tprm_tprr_engagement` | 3 | New. Admission history, qualification id, exposure contribution, comparison result |
| TPM_Assessment | `tprm_risk_assessment` (inherent / residual), `tprm_dd_assessment` (due diligence) | 3 / 4 | Re-keyed to `tprr_id`. The engagement-level module rounds keep `engagement_id` |
| TPM_AssessmentResponse | `tprm_risk_assessment_answer`, `tprm_dd_response` | 3 / 4 | Kept |
| TPM_RiskAssessment | `tprm_risk_assessment` + `_dimension` + new `tprm_risk_assessment_exposure` (per-engagement factor scores) | 3 | Consolidation input kept so traceability holds |
| TPM_ControlAssessment | `tprm_safeguard_assessment` | 3 | Gains applicability scope (VENDOR / ENGAGEMENT) |
| TPM_Review | `tprm_review` | 5 | Re-pointed to the TPRR record, optionally an engagement |
| TPM_Contract | `tprm_contract`, `tprm_contract_engagement`, `tprm_contract_obligation` | 4 | New, TPM-owned (section 13: `asset_contract` is keyed to the legacy vendor) |
| TPM_ServiceLevel | `tprm_service_level`, `tprm_service_level_result` | 4 | New |
| TPM_Subcontractor | `tprm_subcontractor`, `tprm_subcontractor_engagement` | 5 | New. Replaces FOURTH_PARTY scope items |
| TPM_ChangeEvent | `tprm_change_event` | 3 | New. Exposure comparison, decision, waiver approval |
| TPM_ExitPlan | `tprm_exit_plan`, `tprm_exit_task` | 5 | New. Takes over the EXIT_CHECK onboarding items |

## 5. Rules engines

### 5.1 Qualification (Phase 2)

* **Criteria** (per rule-set version): code, question text, category
  (business criticality, operational disruption, customer impact, data
  sensitivity / volume, system or premises access, privileged access,
  financial / prudential impact, reputation, substitutability,
  concentration, subcontracting, jurisdiction, regulatory relevance),
  which answers need a rationale (default Y, NA, UTD), which need
  evidence, and an optional prefill signal taken from the engagement.
  A prefilled answer is a suggestion; the assessor confirms it.
* **Rules** (per version), evaluated in the order below. Each rule's
  outcome is stored in `tprm_qualification_rule_result`.
  1. *Unable to Determine* on any criterion that an applicable rule reads
     -> **FURTHER_REVIEW**. It is never treated as No (source 5.1).
  2. `ESCALATION` (a listed answer pattern) -> **FURTHER_REVIEW**.
  3. `MANDATORY_TRIGGER` (one criterion Yes) -> **POTENTIAL_CANDIDATE**.
     This is the only case where a single Yes admits.
  4. `EXCLUSION` (pattern) -> **NOT_CANDIDATE**, unless rule 3 fired.
  5. `COMBINATION` (at least *n* Yes among listed criteria) ->
     **POTENTIAL_CANDIDATE**.
  6. Otherwise -> **NOT_CANDIDATE**.
* **Overlays.** A rule set has `overlay_kind` = ORGANIZATION_POLICY |
  REGULATORY | INDUSTRY, with `regime_code` and applicability (entity type,
  regulated status, jurisdiction). Every applicable active set is
  evaluated. The most conservative outcome wins (FURTHER_REVIEW >
  POTENTIAL_CANDIDATE > NOT_CANDIDATE). The source authority and version
  of each set are pinned on the qualification (source 14).
* **Decision.** A different person from the submitter, with
  `tprm-engagements` APPROVE, records ADMIT / NOT_CANDIDATE /
  RETURN_FOR_FURTHER_REVIEW with a rationale. Overriding the system
  recommendation needs a rationale and is flagged in reports.

### 5.2 TPRR consolidation (Phase 3)

* The inherent assessment runs on the TPRR with the weighted model
  (unchanged risk-model templates). Each factor's consolidated input is
  the **highest** exposure across the admitted engagements
  (`tprm_risk_assessment_exposure` keeps every engagement's value and
  which engagement set the maximum).
* Aggregation method per model version: WEIGHTED_AVERAGE |
  HIGHEST_DIMENSION | BLENDED (existing). New **critical override**: any
  engagement with criticality rank = top, or a configured materiality flag,
  sets a minimum band. The override is shown with its reason.
* Residual risk = inherent x (1 - verified control effect) per dimension
  (existing D8 / D9 rules), with controls applicable to the vendor or to
  one engagement.

### 5.3 Exposure comparison for a new engagement (Phase 3)

Input: the admitted engagement's signals (criticality rank, data rank,
access rank incl. privileged, customer impact rank, substitutability rank,
new jurisdictions, new subcontractors) against the **approved**
consolidated profile.

| Result | Default rule (configurable per organization in `tprm_comparison_rule`) | Behaviour |
|---|---|---|
| NO_MATERIAL_CHANGE | No signal above the approved maximum | Engagement attached. Approved rating kept. Result recorded |
| IMPACT_REVIEW_REQUIRED | One signal one rank above the maximum, or a new jurisdiction / subcontractor | Change event OPEN, routed to the TPRR owner. Rating unchanged until decided |
| INHERENT_REASSESSMENT_REQUIRED | Any signal two or more ranks above, new privileged access, or new regulated data | Change event + pending reassessment naming the engagement. The approved rating stays until the reassessment is approved |

Downgrading or waiving a system result needs a rationale and approval by
a holder of `tprm-tprr` APPROVE other than the requester (SoD).

## 6. Integration with GRAC shared capabilities

| Need | GRAC capability used | How |
|---|---|---|
| Evidence | Evidence Center (476 / 477) | `tprm_evidence_link` (exists) pins evidence items to qualification responses (Phase 2), due-diligence responses, controls, findings and contract obligations |
| Risk treatment / acceptance | Risk Centre | Existing `ThirdParty` risk source. Escalation becomes one candidate per **TPRR record** (Phase 3) |
| Issues, actions, remediation | Gap Register / Issues & Actions, Task Board | TPM findings raise gaps (exists). Monitoring outputs create tasks with owner, due date and SLA (Phase 5) |
| Audit trail | `practice_audit_trace` (`sp_tprm_audit`) | Every transition and decision (exists) |
| Notifications | My Notifications / TaskNotificationWorker | Reminders, overdue, escalation (Phase 5) |
| Practices / obligations | Practice instances, obligations, assurance findings | Engagement discovery through the **applications in scope** (Phase 1 removed the legacy vendor path) |
| Reporting | Management dashboard framework (414 / 507) | `sp_dashboard_tprm` reworked to the lifecycle (Phase 6) |

## 7. Navigation and screens

Root menu `nav-tprm`, renamed **Third-Party Management** in Phase 1. The
menu keys stay the same so that existing grants and drill links keep
working.

| Menu (source 11) | Key | Phase | Screen |
|---|---|---|---|
| Dashboard | `tprm-dashboard` | exists | Management dashboard (Phase 6 rework) |
| Vendor Registry | `tprm-third-parties` | 1 | Registry, profile, contacts, lifecycle, duplicate reviews, engagements |
| Engagements | `tprm-engagements` | 1 / 2 | Engagement register and workspace. Phase 2 adds the Qualification tab |
| TPRR (Third-Party Risk Register) | `tprm-tprr` | 3 | Consolidated record: engagements, exposure, inherent / residual risk, controls, decision, change events |
| Assessments & Due Diligence | `tprm-assessments` | 3 / 4 | Work queue of qualification, inherent, due-diligence and control assessments. It opens the owning record, so nothing is duplicated (source 11) |
| Reviews & Monitoring | `tprm-reviews` | exists (renamed in Phase 1) | Reviews, monitoring, change events (Phase 5) |
| Contracts & SLAs | `tprm-contracts` | 4 | Contracts, obligations, service levels, onboarding prerequisites |
| Configuration | `tprm-configuration` | exists | Lists, library, templates (risk models, questionnaires, qualification rule sets in Phase 2), rules, custom fields |

Each new screen follows the existing layout: compact page heading,
organization picker, `pm-panel` + `pm-toolbar`, `pm-table-wrap` grid with
the `pm-grid` pager, `pm-modal` dialogs, and the shared `_tprm-form-dialog`.

## 8. Authorization and segregation of duties

| Action | Screen grant | SoD enforced in SQL |
|---|---|---|
| Register / edit vendor | Vendor Registry ADD / EDIT | -- |
| Activate a draft vendor | Vendor Registry EDIT | -- |
| Suspend, reinstate, inactivate, archive, restore, mark duplicate | Vendor Registry APPROVE | -- |
| Engagement create / edit | Engagements ADD / EDIT | -- |
| Qualification answer / submit | Engagements EDIT | -- |
| Qualification decision (admit) | Engagements APPROVE | decider <> submitter |
| Inherent / control / residual assessment | TPRR EDIT | -- |
| Risk approval / acceptance | TPRR APPROVE + approval-rule role | not requester, not assessor, one person per level (existing D11) |
| Downgrade / waive a reassessment | TPRR APPROVE | approver <> requester |
| Monitoring run, review close | Reviews & Monitoring APPROVE / EDIT | -- |
| Configuration | Configuration ADD / EDIT, activation APPROVE, GRAC baseline PM_ADMIN | -- |

Approval matrices by risk tier, materiality, service category and
authority reuse `tprm_approval_rule` (486). Phase 3 adds the
service-category and materiality conditions.

## 9. API surface

Same pattern as today: Web `practice/api/tprm/...` proxies to API
`api/practice/tprm/...`. The API tier is generated from the procedure
signatures (`tools/tprm/gen_csharp.py`). Phase 1 changes are listed in
section 12.4. Later phases add:

* Phase 2: `GET/POST engagements/{id}/qualification`,
  `POST qualifications/{id}/responses`, `.../submit`, `.../decide`,
  `config/templates` with kind `QUALIFICATION`.
* Phase 3: `GET tprr`, `GET tprr/{id}`, `POST tprr/{id}/risk-assessments`,
  `POST change-events/{id}/decide`, decision routes re-keyed to the TPRR.
* Phase 4: `contracts`, `contracts/{id}`, `contracts/{id}/obligations`,
  `service-levels`, `engagements/{id}/modules` (service due diligence).
* Phase 5: `subcontractors`, `exit-plans`, `change-events`, monitoring.

## 10. Reporting (source 15) -- Phase 6

| View | Content | Data |
|---|---|---|
| Vendor Registry | Vendors by status, category, jurisdiction, owner | `tprm_third_party` |
| Engagement pipeline | Draft, under qualification, further review, qualified, not a candidate, active / terminated | engagement pipeline status |
| TPRR | Inherent / residual risk, criticality, category, owner, assessment currency | `tprm_tprr_record` |
| Assessment operations | DD completion, overdue, pending approvals, evidence gaps | assessments, evidence links |
| Monitoring | Upcoming reviews, SLA breaches, incidents, control failures, triggers | reviews, service levels, change events |
| Concentration | Exposure by vendor, service, process, geography, subcontractor chain | engagement scope, subcontractors |
| Exit readiness | Vendors without exit plans, overdue termination actions | exit plans |

## 11. Phase plan

| Phase | Migration (planned) | Content | Depends on |
|---|---|---|---|
| 1 Foundation | **521** (built) | Vendor Registry restructure, configurable duplicate detection with recorded reviews, controlled vendor states, legacy vendor decoupling, engagement exposure attributes, navigation | 486-490, 507 |
| 2 Qualification | 522 | Qualification rule sets (template kind), criteria and rules, overlays, engagement pipeline status, qualification workspace, decision | 1 |
| 3 TPRR and risk | 523-524 | TPRR record and engagement association, risk / control / residual / decision moved from engagement to TPRR, exposure comparison, change events, TPRR screen | 2 |
| 4 DD and contracts | 525-526 | Core vendor DD on the TPRR + engagement service modules, evidence linkage, contracts, obligations, SLAs, onboarding prerequisites | 3 |
| 5 Monitoring and exit | 527-528 | Reviews re-keyed, change triggers, reassessment, incidents, subcontractors, concentration, exit plans | 3, 4 |
| 6 Reporting and assurance | 529 | Dashboard rework, management reports, regulatory mapping, UAT hardening | all |

Each phase has its own migration and rollback, its own API regeneration
and UI change, and a section in `docs/tprm.md`.

## 12. Phase 1 as built (migration 521)

### 12.1 Database -- `521_tpm_vendor_registry_foundation.sql`

| Change | Detail |
|---|---|
| Vendor states | `TP_STATUS` meanings become DRAFT, ACTIVE, INACTIVE, SUSPENDED, ARCHIVED (baseline values replaced; organization values remapped; vendor rows remapped). `tprm_third_party.status` (Active / Archived) follows ARCHIVED |
| Transitions | `fn_tprm_vendor_transitions` (allowed targets + gate result); `sp_tprm_third_party_status` re-issued (target status + mandatory reason + optional evidence reference) |
| Engagement-driven status removed | `sp_tprm_third_party_sync_status` is kept as a no-op, so that the 488 / 489 callers that Phase 3 rewrites still compile |
| Duplicate detection | List `VENDOR_MATCH_ATTRIBUTE` (MEANING: REGISTRATION_NUMBER, TAX_ID, LEI, LEGAL_NAME, TRADING_NAME, SIMILAR_NAME, WEBSITE_DOMAIN, EMAIL_DOMAIN). An organization hides a value to switch that attribute off. `fn_tprm_third_party_matches` re-issued, driven by the list, with no legacy vendor branch |
| Duplicate review | New `tprm_vendor_match_review`. Registration that finds matches saves nothing until each match has a "not a duplicate" rationale (`@match_reviews_json`). `sp_tprm_vendor_match_review_save` records NOT_DUPLICATE / DUPLICATE on the detail page. DUPLICATE (a DRAFT or INACTIVE vendor with no open engagement, same gate as ARCHIVE) archives the vendor and sets `duplicate_of_third_party_id` (no merge); RESTORE of that vendor reverses the decision |
| Legacy decoupling | `tprm_third_party.vendor_id` (FK, unique index, column) dropped. `sp_tprm_vendor_discovery` / `sp_tprm_vendor_import` dropped. VENDOR link kind removed (rows deleted, CHECK rebuilt). Discovery re-issued to work from the **applications in scope** and practice-level risks. Monitoring sweep re-issued without the vendor branch. Custom-field reference kind VENDOR removed (fields converted to THIRD_PARTY) |
| Engagement attributes | `service_recipient`, `substitutability_code` (list `SUBSTITUTABILITY`), `customer_impact_code` (list `CUSTOMER_IMPACT`), `exit_dependencies`. A new engagement needs a DRAFT or ACTIVE vendor |
| Labels | Lists `TP_STATUS` / `PROVIDER_TYPE` renamed "Vendor lifecycle statuses" / "Vendor types" |
| Navigation | `nav-tprm` = "Third-Party Management"; children Dashboard, Vendor Registry, Engagements, Reviews & Monitoring, Configuration; module_type "Third-Party Management" (274 snapshot updated) |
| Guards | 488 and 489 abort when re-run after 521 (they would otherwise restore the legacy link) |
| 487 | Regenerated (`tools/tprm/gen_487.py`) so a re-run of the baseline seed carries the Phase 1 lists |

Error numbers: 58000-58049.

### 12.2 API

Regenerated (`tools/tprm/gen_csharp.py`, 521 added to the signature
sources):

* `GET lookups` -- set `vendors` removed.
* `GET third-parties/{id}` -- sets `transitions`, `matchReviews` added.
* `POST third-parties` -- `confirmDuplicates` replaced by `matchReviewsJson`.
* `POST third-parties/{id}/status` -- `statusCode`, `reason`,
  `evidenceReference` (`archive` removed).
* `POST third-parties/{id}/match-reviews` -- new.
* `GET vendors`, `POST vendors/{id}/import` -- removed.
* `POST engagements` -- `serviceRecipient`, `substitutabilityCode`,
  `customerImpactCode`, `exitDependencies` added.

### 12.3 Web

* `TprmController` -- vendor status transitions and match reviews: EDIT
  for activation, APPROVE for the rest; vendor routes removed.
* `PracticeScreen` / `ManagementDashboards` -- group "Third-Party
  Management"; screen titles Vendor Registry, Reviews & Monitoring,
  Configuration.
* Vendor Registry screen -- import removed; lifecycle actions offered
  from the allowed transitions; duplicate-review panel; "Duplicate
  reviews" tab; status history with the evidence reference.
* Engagements -- new attributes; legacy vendor link kind removed;
  discovery text updated.
* Configuration -- custom-field reference kind VENDOR removed.

## 13. What happens to each current TPRM object

| Object | Fate | Phase |
|---|---|---|
| Configuration (486): lists, library, templates, rules, delegations, custom fields | Kept and extended (qualification template kind, comparison rules) | 2-3 |
| Baseline seed (487) | Kept; regenerated as lists change | each |
| `tprm_third_party` + contact / category / history | Kept as TPM_Vendor (restructured) | 1 |
| `vendor_id`, vendor discovery / import, VENDOR links | **Removed** | 1 |
| `sp_tprm_third_party_sync_status` | No-op, then removed with its callers | 1 / 3 |
| `tprm_engagement` risk columns (`inherent_*`, `residual_*`, `dd_tier_code`, `acceptance_until`, `current_risk_assessment_id`, `risk_model_version_id`) | Move to `tprm_tprr_record`; engagement keeps exposure only | 3 |
| `tprm_engagement.stage_code` risk stages | Replaced by the engagement pipeline + TPRR state | 2 / 3 |
| `tprm_risk_assessment*` | Re-keyed to the TPRR, plus per-engagement exposure | 3 |
| `tprm_dd_*`, `tprm_safeguard_assessment` | Core round on the TPRR; service modules per engagement | 4 |
| `tprm_decision*`, Risk Centre escalation | Re-keyed to the TPRR | 3 |
| `tprm_onboarding_item` (ONBOARDING) | Kept as onboarding prerequisites (Contracts & SLAs) | 4 |
| `tprm_onboarding_item` (EXIT) | Replaced by `tprm_exit_task` | 5 |
| FOURTH_PARTY scope items | Replaced by `tprm_subcontractor` | 5 |
| `tprm_engagement.contract_id` -> `asset_contract` | Replaced by `tprm_contract` | 4 |
| `tprm_review`, monitoring sweep | Re-pointed to the TPRR; change events | 5 |
| `sp_dashboard_tprm` (507) | Reworked to the lifecycle views | 6 |
| Sample loader / profiles | Kept; samples follow the new states | each |

Interim state between Phase 1 and Phase 3: an engagement still carries
its own inherent risk, due diligence and decision, and that workflow
works as before. The qualification gate (Phase 2) is placed in front of
it. Phase 3 moves the workflow to the TPRR. The UAT data is test data
(Q3), so no migration of engagement-level assessments is planned.

## 14. Legacy vendor (Settings -> Dependencies): data-disposition plan

Not executed in this round (Q4). TPM no longer reads or writes any of these
objects after 521.

| Area | Objects that hold or read legacy vendors | Records to decide on |
|---|---|---|
| Dependencies (core) | `organization_dependency_vendor` (002), `organization_dependency_application.vendor_id`, `practice_dependency_resolution` (dependency type Vendor), dependency category sync (238, 497), Settings -> Dependencies Vendor tab | vendor rows, application ownership, resolutions on practice instances |
| Risk Centre | `risk_register.linked_vendor_id` (205 / 378), risk dependency map (265) | risks linked to vendors |
| Assurance | `org_assurance_execution_entity` dimension VENDOR (074) | audit scope entities and their observations |
| Asset & Contract | `asset_contract.vendor_id` (434), coverage (435), renewals (436), relationships (440), business services (441), reports (452) | contracts and their links |
| Users / ownership | ownership management (345), user scope reads (341, 366, 467) | owner assignments |
| Dashboards / seeds | governance dashboard (503), master seeds (023, 272) | none (derived) |

Disposition options, per area, to be decided separately:

1. **Retain read-only.** Keep the tables and screens and freeze edits. Lowest risk.
2. **Map to TPM.** For each legacy vendor, register a TPM vendor (with the
   duplicate review) and re-point the consumers (risk links, assurance
   scope, contracts) to TPM identifiers. Needs consumer changes in Risk
   Centre, Assurance and Asset & Contract.
3. **Export and archive.** Export to CSV / evidence, then remove the
   Vendor tab and dependency type.

Recommended order: (1) now; then (2) for Risk Centre and Assurance
together with Phase 5; Asset & Contract with Phase 4 contracts. Each
step needs its own approval and rollback.

## 15. Open points for review

1. **Engagement pipeline names** (section 3.2) -- confirm the codes and
   labels, especially whether NOT_CANDIDATE engagements may later be
   re-qualified (proposed: yes, as a new qualification round).
2. **Qualification precedence** (section 5.1) -- confirm "most
   conservative wins" across overlays.
3. **Comparison thresholds** (section 5.3) -- confirm the default ranks.
4. **Contracts** -- confirm TPM-owned contracts (section 4) rather than
   extending `asset_contract`.
5. **Monitoring outputs** -- confirm GRAC Task Board tasks for review
   actions (section 6).
6. **Legacy vendor** -- choose the disposition option per area
   (section 14).
