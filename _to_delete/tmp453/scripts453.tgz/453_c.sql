
-- =====================================================================
-- 5. Deliveries: start, store, finish
-- =====================================================================
-- Status of a delivery from its recipients: RUNNING while any is pending;
-- COMPLETED (all delivered), PARTIAL (some delivered), FAILED (none
-- delivered, one failed), SKIPPED (nobody passed the checks).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_delivery_finish
    @delivery_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE d
       SET recipient_count = c.total, delivered_count = c.delivered, skipped_count = c.skipped, failed_count = c.failed,
           status = CASE WHEN c.pending > 0 THEN N'RUNNING'
                         WHEN c.delivered > 0 AND c.skipped + c.failed = 0 THEN N'COMPLETED'
                         WHEN c.delivered > 0 THEN N'PARTIAL'
                         WHEN c.failed > 0 THEN N'FAILED'
                         ELSE N'SKIPPED' END,
           completed_dt = CASE WHEN c.pending > 0 THEN NULL ELSE ISNULL(d.completed_dt, SYSUTCDATETIME()) END
      FROM grac_practice.asset_report_delivery d
     CROSS APPLY (SELECT COUNT(*) AS total,
                         ISNULL(SUM(CASE WHEN r.status = N'DELIVERED' THEN 1 ELSE 0 END), 0) AS delivered,
                         ISNULL(SUM(CASE WHEN r.status = N'SKIPPED' THEN 1 ELSE 0 END), 0) AS skipped,
                         ISNULL(SUM(CASE WHEN r.status = N'FAILED' THEN 1 ELSE 0 END), 0) AS failed,
                         ISNULL(SUM(CASE WHEN r.status = N'PENDING' THEN 1 ELSE 0 END), 0) AS pending
                    FROM grac_practice.asset_report_delivery_recipient r
                   WHERE r.delivery_id = d.delivery_id) c
     WHERE d.delivery_id = @delivery_id;
END
GO

-- Starts deliveries: every active schedule due today (@schedule_id NULL,
-- SCHEDULED; one per schedule and day) or one schedule now (MANUAL, its
-- screen must be in the caller @allowed_areas). Housekeeping first:
-- recipients left pending for 6 hours fail as interrupted, and delivered
-- files past the retention of their schedule are removed (the
-- distribution result stays). Every recipient is checked AT DELIVERY TIME
-- (13.4.1): active employee with access to the organization, Asset
-- Reports VIEW, VIEW on the report screen, report enabled, export policy
-- (Approver needs Asset Reports APPROVE; Disabled delivers to nobody).
-- 1. the work: one row per recipient to produce (the API runs the report
--    under that recipient and stores the result)   2. the deliveries started
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_delivery_start
    @organization_id   BIGINT         = NULL,
    @schedule_id       BIGINT         = NULL,
    @trigger_code      NVARCHAR(10)   = N'SCHEDULED',
    @allowed_areas     NVARCHAR(2000) = NULL,
    @actor             NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @trigger_code = CASE WHEN @schedule_id IS NULL THEN N'SCHEDULED' ELSE N'MANUAL' END;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE), @now DATETIME2 = SYSUTCDATETIME();

    IF @schedule_id IS NOT NULL
    BEGIN
        DECLARE @m_area NVARCHAR(100);
        SELECT @m_area = d.view_area
          FROM grac_practice.asset_report_schedule s
          JOIN grac_practice.asset_report_definition d ON d.report_code = s.report_code
         WHERE s.schedule_id = @schedule_id AND s.organization_id = @organization_id;
        IF @m_area IS NULL
            THROW 53121, 'Schedule not found.', 1;
        IF CHARINDEX(N',' + @m_area + N',', N',' + REPLACE(ISNULL(@allowed_areas, N''), N' ', N'') + N',') = 0
            THROW 53123, 'You do not have permission to view the screen this report is based on.', 1;
    END

    -- Housekeeping: interrupted recipients, then retention.
    DECLARE @stale TABLE (delivery_id BIGINT NOT NULL);   -- one row per interrupted recipient
    UPDATE r
       SET status = N'FAILED', reason = N'Interrupted: the delivery pass stopped before the file was produced.'
    OUTPUT inserted.delivery_id INTO @stale (delivery_id)
      FROM grac_practice.asset_report_delivery_recipient r
      JOIN grac_practice.asset_report_delivery d ON d.delivery_id = r.delivery_id
     WHERE r.status = N'PENDING' AND d.started_dt < DATEADD(HOUR, -6, @now)
       AND (@organization_id IS NULL OR d.organization_id = @organization_id);
    DECLARE @sd BIGINT = (SELECT MIN(delivery_id) FROM @stale);
    WHILE @sd IS NOT NULL
    BEGIN
        EXEC grac_practice.sp_asset_report_delivery_finish @delivery_id = @sd;
        SET @sd = (SELECT MIN(delivery_id) FROM @stale WHERE delivery_id > @sd);
    END
    UPDATE r
       SET columns_json = NULL, rows_json = NULL, purged_dt = @now
      FROM grac_practice.asset_report_delivery_recipient r
      JOIN grac_practice.asset_report_delivery d ON d.delivery_id = r.delivery_id
     WHERE r.purged_dt IS NULL AND r.rows_json IS NOT NULL
       AND DATEADD(DAY, d.retention_days, ISNULL(r.delivered_dt, d.started_dt)) < @now
       AND (@organization_id IS NULL OR d.organization_id = @organization_id);

    -- Schedules to run.
    DECLARE @due TABLE (schedule_id BIGINT PRIMARY KEY);
    IF @schedule_id IS NOT NULL
    BEGIN
        INSERT @due (schedule_id) VALUES (@schedule_id);
    END
    ELSE
    BEGIN
        INSERT @due (schedule_id)
        SELECT s.schedule_id
          FROM grac_practice.asset_report_schedule s
         WHERE s.is_active = 1 AND s.next_run_date <= @today
           AND (@organization_id IS NULL OR s.organization_id = @organization_id)
           AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_report_delivery x
                            WHERE x.schedule_id = s.schedule_id AND x.run_date = @today AND x.trigger_code = N'SCHEDULED');
    END

    CREATE TABLE #rcp (
        employee_id    BIGINT         NOT NULL PRIMARY KEY,
        recipient_name NVARCHAR(200)  COLLATE DATABASE_DEFAULT NULL,
        via_role_name  NVARCHAR(200)  COLLATE DATABASE_DEFAULT NULL,
        in_org         BIT            NOT NULL DEFAULT 0,
        areas          NVARCHAR(2000) COLLATE DATABASE_DEFAULT NULL,
        reports_view   BIT            NOT NULL DEFAULT 0,
        reports_appr   BIT            NOT NULL DEFAULT 0
    );
    DECLARE @started TABLE (delivery_id BIGINT PRIMARY KEY);
    DECLARE @sch BIGINT, @org BIGINT, @code NVARCHAR(40), @area NVARCHAR(100), @available BIT, @enabled BIT, @policy NVARCHAR(10),
            @version INT, @rname NVARCHAR(120), @cls NVARCHAR(20), @search NVARCHAR(200), @status NVARCHAR(60), @atype INT,
            @days INT, @window INT, @retention INT, @freq NVARCHAR(10), @dow TINYINT, @dom TINYINT, @dlv BIGINT, @all_skip NVARCHAR(400);

    DECLARE sch_cur CURSOR LOCAL STATIC FOR SELECT schedule_id FROM @due ORDER BY schedule_id;
    OPEN sch_cur;
    FETCH NEXT FROM sch_cur INTO @sch;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SELECT @org = s.organization_id, @code = s.report_code, @area = d.view_area, @available = d.is_available, @enabled = e.IsEnabled,
               @policy = e.ExportPolicy, @version = d.version_no, @rname = d.report_name, @cls = e.Classification,
               @search = s.search_text, @status = s.status_code, @atype = s.asset_type_id, @days = s.days,
               @window = s.date_window_days, @retention = s.retention_days, @freq = s.frequency, @dow = s.day_of_week,
               @dom = s.day_of_month
          FROM grac_practice.asset_report_schedule s
          JOIN grac_practice.asset_report_definition d ON d.report_code = s.report_code
         CROSS APPLY (SELECT x.IsEnabled, x.ExportPolicy, x.Classification
                        FROM grac_practice.fn_asset_report_effective(s.organization_id) x WHERE x.ReportCode = s.report_code) e
         WHERE s.schedule_id = @sch;
        SET @all_skip = CASE WHEN @available = 0 OR @enabled = 0 THEN N'The report is not available or is disabled for the organization.'
                             WHEN @policy = N'DISABLED' THEN N'Export of this report is disabled by the organization policy.' END;

        BEGIN TRY
        BEGIN TRAN;
        INSERT grac_practice.asset_report_delivery (schedule_id, organization_id, report_code, report_version, report_name, classification,
                                                    filters_json, search_text, status_code, asset_type_id, date_from, date_to, days,
                                                    run_date, trigger_code, status, retention_days, started_by)
        SELECT @sch, @org, @code, @version, @rname, @cls,
               (SELECT @search AS search, @status AS status, @atype AS assetTypeId,
                       CONVERT(NVARCHAR(10), DATEADD(DAY, -@window, @today), 23) AS dateFrom,
                       CASE WHEN @window IS NOT NULL THEN CONVERT(NVARCHAR(10), @today, 23) END AS dateTo,
                       @days AS days FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
               @search, @status, @atype, DATEADD(DAY, -@window, @today), CASE WHEN @window IS NOT NULL THEN @today END, @days,
               @today, @trigger_code, N'RUNNING', @retention, @actor;
        SET @dlv = SCOPE_IDENTITY();

        -- Distribution list: named employees, and every active holder of a role (primary or assigned).
        TRUNCATE TABLE #rcp;
        INSERT #rcp (employee_id, recipient_name, via_role_name)
        SELECT x.employee_id, MAX(e.employee_name), MIN(x.via_role)
          FROM (SELECT r.employee_id, CAST(NULL AS NVARCHAR(200)) AS via_role
                  FROM grac_practice.asset_report_schedule_recipient r
                 WHERE r.schedule_id = @sch AND r.recipient_kind = N'EMPLOYEE'
                UNION ALL
                SELECT e2.employee_id, rl.role_name
                  FROM grac_practice.asset_report_schedule_recipient r
                  JOIN grac_practice.organization_role rl ON rl.role_id = r.role_id
                  JOIN grac_practice.organization_employee e2 ON e2.organization_id = @org AND e2.status = N'Active'
                       AND (e2.role_id = r.role_id
                            OR EXISTS (SELECT 1 FROM grac_practice.organization_employee_role er
                                        WHERE er.employee_id = e2.employee_id AND er.role_id = r.role_id AND er.status = N'Active'))
                 WHERE r.schedule_id = @sch AND r.recipient_kind = N'ROLE') x
          JOIN grac_practice.organization_employee e ON e.employee_id = x.employee_id
         GROUP BY x.employee_id;

        UPDATE c
           SET in_org = CASE WHEN EXISTS (SELECT 1 FROM grac_practice.fn_asset_report_employee_in_org(@org, c.employee_id)) THEN 1 ELSE 0 END,
               areas = a.areas, reports_view = ISNULL(a.rv, 0), reports_appr = ISNULL(a.ra, 0)
          FROM #rcp c
         OUTER APPLY (SELECT STRING_AGG(CASE WHEN p.CanView = 1 AND p.MenuKey <> N'asset-reports' THEN p.MenuKey END, N',') AS areas,
                             MAX(CASE WHEN p.MenuKey = N'asset-reports' AND p.CanView = 1 THEN 1 ELSE 0 END) AS rv,
                             MAX(CASE WHEN p.MenuKey = N'asset-reports' AND p.CanApprove = 1 THEN 1 ELSE 0 END) AS ra
                        FROM grac_practice.fn_asset_report_employee_access(c.employee_id) p
                       WHERE p.MenuKey = N'asset-reports'
                          OR p.MenuKey IN (SELECT v.view_area FROM grac_practice.asset_report_definition v)) a;

        INSERT grac_practice.asset_report_delivery_recipient (delivery_id, employee_id, recipient_name, via_role_name, status, reason,
                                                              allowed_areas, can_approve)
        SELECT @dlv, c.employee_id, c.recipient_name, c.via_role_name,
               CASE WHEN k.reason IS NULL THEN N'PENDING' ELSE N'SKIPPED' END, k.reason, c.areas, c.reports_appr
          FROM #rcp c
         CROSS APPLY (SELECT CASE WHEN @all_skip IS NOT NULL THEN @all_skip
                                  WHEN c.in_org = 0 THEN N'Not an active employee with access to the organization.'
                                  WHEN c.reports_view = 0 THEN N'No VIEW permission on Asset Reports.'
                                  WHEN CHARINDEX(N',' + @area + N',', N',' + ISNULL(c.areas, N'') + N',') = 0
                                       THEN CONCAT(N'No VIEW permission on the screen the report is based on (', @area, N').')
                                  WHEN @policy = N'APPROVER' AND c.reports_appr = 0
                                       THEN N'The export policy of this report needs Asset Reports APPROVE.' END AS reason) k;

        UPDATE grac_practice.asset_report_schedule
           SET last_delivery_id = @dlv,
               next_run_date = CASE WHEN @trigger_code = N'SCHEDULED'
                                    THEN (SELECT NextRunDate FROM grac_practice.fn_asset_report_next_run(@freq, @dow, @dom, DATEADD(DAY, 1, @today)))
                                    ELSE next_run_date END
         WHERE schedule_id = @sch;
        EXEC grac_practice.sp_asset_report_delivery_finish @delivery_id = @dlv;
        COMMIT;
        INSERT @started (delivery_id) VALUES (@dlv);
        END TRY
        BEGIN CATCH
            -- One schedule must not stop the others (a manual run reports its error).
            IF XACT_STATE() <> 0 ROLLBACK;
            IF @schedule_id IS NOT NULL THROW;
            INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
            VALUES (N'asset-report-schedule', @sch, N'DELIVERY_ERROR', NULL,
                    (SELECT ERROR_NUMBER() AS errorNumber, ERROR_MESSAGE() AS errorMessage FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
                    N'Active', @actor);
        END CATCH
        FETCH NEXT FROM sch_cur INTO @sch;
    END
    CLOSE sch_cur;
    DEALLOCATE sch_cur;

    SELECT r.delivery_recipient_id AS DeliveryRecipientId, r.delivery_id AS DeliveryId, d.organization_id AS OrganizationId,
           d.report_code AS ReportCode, r.employee_id AS EmployeeId, r.allowed_areas AS AllowedAreas, r.can_approve AS CanApprove,
           d.search_text AS Search, d.status_code AS Status, d.asset_type_id AS AssetTypeId, d.date_from AS DateFrom,
           d.date_to AS DateTo, d.days AS Days
      FROM grac_practice.asset_report_delivery_recipient r
      JOIN grac_practice.asset_report_delivery d ON d.delivery_id = r.delivery_id
      JOIN @started s ON s.delivery_id = d.delivery_id
     WHERE r.status = N'PENDING'
     ORDER BY r.delivery_id, r.delivery_recipient_id;

    SELECT d.delivery_id AS DeliveryId, d.schedule_id AS ScheduleId, d.status AS Status, d.recipient_count AS RecipientCount,
           d.skipped_count AS SkippedCount
      FROM grac_practice.asset_report_delivery d
      JOIN @started s ON s.delivery_id = d.delivery_id
     ORDER BY d.delivery_id;
END
GO

-- The result for one recipient: DELIVERED with the columns and rows (JSON
-- written by the API), or FAILED with the reason. Only a pending
-- recipient is written.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_delivery_store
    @delivery_recipient_id BIGINT,
    @status                NVARCHAR(10),
    @reason                NVARCHAR(1000) = NULL,
    @row_count             INT            = NULL,
    @columns_json          NVARCHAR(MAX)  = NULL,
    @rows_json             NVARCHAR(MAX)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @status = UPPER(@status);
    IF @status NOT IN (N'DELIVERED', N'FAILED')
       OR (@status = N'DELIVERED' AND (@row_count IS NULL OR ISJSON(@columns_json) = 0 OR ISJSON(@rows_json) = 0))
        THROW 53124, 'Delivery result invalid.', 1;
    DECLARE @dlv BIGINT = (SELECT delivery_id FROM grac_practice.asset_report_delivery_recipient
                            WHERE delivery_recipient_id = @delivery_recipient_id AND status = N'PENDING');
    IF @dlv IS NULL
        THROW 53126, 'Delivery recipient not found or no longer pending.', 1;
    BEGIN TRAN;
    UPDATE grac_practice.asset_report_delivery_recipient
       SET status = @status, reason = CASE WHEN @status = N'FAILED' THEN LEFT(@reason, 1000) END,
           row_count = CASE WHEN @status = N'DELIVERED' THEN @row_count END,
           columns_json = CASE WHEN @status = N'DELIVERED' THEN @columns_json END,
           rows_json = CASE WHEN @status = N'DELIVERED' THEN @rows_json END,
           delivered_dt = CASE WHEN @status = N'DELIVERED' THEN SYSUTCDATETIME() END
     WHERE delivery_recipient_id = @delivery_recipient_id;
    EXEC grac_practice.sp_asset_report_delivery_finish @delivery_id = @dlv;
    COMMIT;
    SELECT @delivery_recipient_id AS DeliveryRecipientId, @status AS Result;
END
GO

-- =====================================================================
-- 6. Readers and download
-- =====================================================================
-- Deliveries of the reports the caller may view (optionally of one schedule).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_deliveries
    @organization_id BIGINT,
    @allowed_areas   NVARCHAR(2000) = NULL,
    @schedule_id     BIGINT         = NULL,
    @page_number     INT            = 1,
    @page_size       INT            = 25
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53120, 'Organization not found.', 1;
    DECLARE @areas NVARCHAR(2004) = N',' + REPLACE(ISNULL(@allowed_areas, N''), N' ', N'') + N',';
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) NOT BETWEEN 1 AND 200 THEN 25 ELSE @page_size END;

    SELECT d.delivery_id AS DeliveryId, d.schedule_id AS ScheduleId, s.schedule_name AS ScheduleName, d.report_name AS ReportName,
           d.report_version AS ReportVersion, d.classification AS Classification, d.run_date AS RunDate, d.trigger_code AS TriggerCode,
           d.status AS Status, d.recipient_count AS RecipientCount, d.delivered_count AS DeliveredCount,
           d.skipped_count AS SkippedCount, d.failed_count AS FailedCount, d.filters_json AS FiltersJson,
           d.started_by AS StartedBy, d.started_dt AS StartedDt, d.completed_dt AS CompletedDt,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_report_delivery d
      JOIN grac_practice.asset_report_schedule s ON s.schedule_id = d.schedule_id
      JOIN grac_practice.asset_report_definition def ON def.report_code = d.report_code
     WHERE d.organization_id = @organization_id AND CHARINDEX(N',' + def.view_area + N',', @areas) > 0
       AND (@schedule_id IS NULL OR d.schedule_id = @schedule_id)
     ORDER BY d.started_dt DESC, d.delivery_id DESC
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- Distribution result of one delivery: every recipient with its status and
-- reason (no file content).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_delivery_recipients
    @organization_id BIGINT,
    @delivery_id     BIGINT,
    @allowed_areas   NVARCHAR(2000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_report_delivery d
                     JOIN grac_practice.asset_report_definition def ON def.report_code = d.report_code
                    WHERE d.delivery_id = @delivery_id AND d.organization_id = @organization_id
                      AND CHARINDEX(N',' + def.view_area + N',', N',' + REPLACE(ISNULL(@allowed_areas, N''), N' ', N'') + N',') > 0)
        THROW 53126, 'Delivery not found.', 1;
    SELECT r.delivery_recipient_id AS DeliveryRecipientId, r.employee_id AS EmployeeId, r.recipient_name AS RecipientName,
           r.via_role_name AS ViaRoleName, r.status AS Status, r.reason AS Reason, r.row_count AS [RowCount],
           r.delivered_dt AS DeliveredDt, r.download_count AS DownloadCount, r.first_downloaded_dt AS FirstDownloadedDt,
           r.purged_dt AS PurgedDt
      FROM grac_practice.asset_report_delivery_recipient r
     WHERE r.delivery_id = @delivery_id
     ORDER BY CASE r.status WHEN N'FAILED' THEN 1 WHEN N'SKIPPED' THEN 2 WHEN N'PENDING' THEN 3 ELSE 4 END, r.recipient_name;
END
GO

-- The caller own delivered files in the organization.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_my_deliveries
    @organization_id BIGINT,
    @employee_id     BIGINT,
    @page_number     INT = 1,
    @page_size       INT = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) NOT BETWEEN 1 AND 200 THEN 25 ELSE @page_size END;
    SELECT r.delivery_recipient_id AS DeliveryRecipientId, s.schedule_name AS ScheduleName, d.report_name AS ReportName,
           d.report_version AS ReportVersion, d.classification AS Classification, d.run_date AS RunDate, r.row_count AS [RowCount],
           r.delivered_dt AS DeliveredDt, DATEADD(DAY, d.retention_days, r.delivered_dt) AS AvailableUntilDt,
           CAST(CASE WHEN r.purged_dt IS NULL AND r.rows_json IS NOT NULL THEN 1 ELSE 0 END AS BIT) AS IsAvailable,
           r.download_count AS DownloadCount, d.filters_json AS FiltersJson,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_report_delivery_recipient r
      JOIN grac_practice.asset_report_delivery d ON d.delivery_id = r.delivery_id
      JOIN grac_practice.asset_report_schedule s ON s.schedule_id = d.schedule_id
     WHERE d.organization_id = @organization_id AND r.employee_id = @employee_id AND r.status = N'DELIVERED'
     ORDER BY r.delivered_dt DESC, r.delivery_recipient_id DESC
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- Download of a delivered file by its recipient. Checked again now: the
-- recipient, the file still kept, the report screen still viewable, the
-- report enabled and the export policy. Recorded as an export (452) with
-- the delivery reference; returns the export heading, the columns and the
-- rows.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_delivery_download
    @organization_id       BIGINT,
    @delivery_recipient_id BIGINT,
    @employee_id           BIGINT,
    @allowed_areas         NVARCHAR(2000) = NULL,
    @can_approve           BIT            = 0,
    @actor                 NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    DECLARE @rcp_status NVARCHAR(10), @purged DATETIME2, @has_rows BIT, @code NVARCHAR(40), @area NVARCHAR(100),
            @enabled BIT, @available BIT, @policy NVARCHAR(10);
    SELECT @rcp_status = r.status, @purged = r.purged_dt, @has_rows = CASE WHEN r.rows_json IS NULL THEN 0 ELSE 1 END,
           @code = d.report_code, @area = def.view_area, @enabled = e.IsEnabled, @available = def.is_available, @policy = e.ExportPolicy
      FROM grac_practice.asset_report_delivery_recipient r
      JOIN grac_practice.asset_report_delivery d ON d.delivery_id = r.delivery_id
      JOIN grac_practice.asset_report_definition def ON def.report_code = d.report_code
     CROSS APPLY (SELECT x.IsEnabled, x.ExportPolicy FROM grac_practice.fn_asset_report_effective(d.organization_id) x
                   WHERE x.ReportCode = d.report_code) e
     WHERE r.delivery_recipient_id = @delivery_recipient_id AND d.organization_id = @organization_id
       AND r.employee_id = @employee_id AND @employee_id IS NOT NULL;
    IF @code IS NULL
        THROW 53126, 'Delivered file not found.', 1;
    IF @rcp_status <> N'DELIVERED' OR @purged IS NOT NULL OR @has_rows = 0
        THROW 53127, 'The file is not available: it was not delivered or has been removed after its retention period.', 1;
    IF CHARINDEX(N',' + @area + N',', N',' + REPLACE(ISNULL(@allowed_areas, N''), N' ', N'') + N',') = 0
       OR @enabled = 0 OR @available = 0
       OR NOT (@policy = N'ALLOWED' OR (@policy = N'APPROVER' AND ISNULL(@can_approve, 0) = 1))
        THROW 53129, 'You may no longer download this report (screen permission, report disabled or export policy).', 1;

    DECLARE @id TABLE (export_id BIGINT NOT NULL);
    BEGIN TRAN;
    INSERT grac_practice.asset_report_export (organization_id, report_code, report_version, report_name, classification, filters_json,
                                              columns_json, row_count, exported_by, exported_employee_id, delivery_recipient_id)
    OUTPUT inserted.export_id INTO @id (export_id)
    SELECT d.organization_id, d.report_code, d.report_version, d.report_name, d.classification, d.filters_json,
           r.columns_json, r.row_count, @actor, @employee_id, r.delivery_recipient_id
      FROM grac_practice.asset_report_delivery_recipient r
      JOIN grac_practice.asset_report_delivery d ON d.delivery_id = r.delivery_id
     WHERE r.delivery_recipient_id = @delivery_recipient_id;
    UPDATE grac_practice.asset_report_delivery_recipient
       SET download_count = download_count + 1, first_downloaded_dt = ISNULL(first_downloaded_dt, SYSUTCDATETIME())
     WHERE delivery_recipient_id = @delivery_recipient_id;
    COMMIT;

    SELECT x.export_id AS ExportId, x.report_code AS ReportCode, x.report_name AS ReportName, x.report_version AS ReportVersion,
           x.classification AS Classification, o.organization_name AS OrganizationName, x.row_count AS [RowCount],
           COALESCE(emp.employee_name, x.exported_by) AS ExportedBy, x.exported_dt AS ExportedDt, x.filters_json AS FiltersJson,
           r.delivered_dt AS GeneratedDt, r.columns_json AS ColumnsJson, r.rows_json AS RowsJson
      FROM grac_practice.asset_report_export x
      JOIN @id i ON i.export_id = x.export_id
      JOIN grac_practice.organization o ON o.organization_id = x.organization_id
      JOIN grac_practice.asset_report_delivery_recipient r ON r.delivery_recipient_id = x.delivery_recipient_id
      LEFT JOIN grac_practice.organization_employee emp ON emp.employee_id = x.exported_employee_id;
END
GO
PRINT '453: delivery procedures created.';
GO
