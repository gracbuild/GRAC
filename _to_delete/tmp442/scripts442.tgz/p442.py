# 442 -- API, Web proxy, screen registry, appsettings, 274. Run from the repository root.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    return s

A = 'src/PracticeManagement.Api/'
W = 'src/PracticeManagement.Web/'
files = {}

files[A + 'Models/AssetConfigModels.cs'] = edit(A + 'Models/AssetConfigModels.cs', [(
"""/// <summary>Outcome of a write: Success, the new/affected id, and on
/// failure the SQL error number + message so the controller can pick the""",
"""// ---------------------------------------------------------------------
// Asset discovery and reconciliation (migration 442)
// ---------------------------------------------------------------------
/// <summary>Discovery source profile (BRD 5.6.1). SourceType DISCOVERY | ENDPOINT | IDENTITY | CLOUD |
/// NETWORK | SECURITY | ERP | BIOMEDICAL | FLEET | CUSTOM; CollectionMode POLLING | WEBHOOK | BATCH |
/// FILE | API. CredentialReference is a vault reference, never a secret.</summary>
public sealed record AssetDiscoverySourceRequest(
    long    OrganizationId,
    long?   SourceId,
    string? SourceCode,
    string? SourceName,
    string? SourceType,
    string? CollectionMode,
    string? ScopeText,
    string? MappingVersion,
    long?   OwnerEmployeeId,
    string? CredentialReference,
    int?    TrustLevel,
    int?    ExpectedIntervalHours,
    int?    RawRetentionDays,
    int?    ObservationRetentionDays,
    bool?   IsActive,
    long?   ExpectedRecordVersion);

/// <summary>Field precedence of a source: GOLDEN | CONTRIBUTING | IGNORED with a priority 1-999.</summary>
public sealed record AssetDiscoveryPriorityItem(string? FieldKey, string? SourceRole, int? Priority);
public sealed record AssetDiscoveryPrioritiesRequest(long OrganizationId, List<AssetDiscoveryPriorityItem>? Priorities);

/// <summary>Identification rule: comma list of dictionary field keys (or @source_key),
/// STRONG | SUPPORTING | WEAK, weight 1-100 (BRD 5.6.2).</summary>
public sealed record AssetIdentificationRuleRequest(
    long    OrganizationId,
    long?   RuleId,
    string? RuleName,
    string? AttributeKeys,
    string? Strength,
    int?    Weight,
    bool?   IsActive,
    int?    DisplayOrder);

public sealed record AssetDiscoverySettingRequest(
    long  OrganizationId,
    int?  AutoMatchScore,
    int?  SuggestedScore,
    int?  ManualReviewScore,
    int?  StaleMultiplier,
    int?  VerificationDays,
    bool? CreateConflictTasks);

/// <summary>A batch of observations: Records is the JSON array
/// [{"externalKey","observedAt","attributes":{fieldKey: value}}] passed to the procedure as is.
/// Channel UI | IMPORT | API; a repeated BatchReference returns the earlier batch.</summary>
public sealed record AssetDiscoveryIngestRequest(
    long                        OrganizationId,
    string?                     BatchReference,
    string?                     Channel,
    System.Text.Json.JsonElement? Records);

/// <summary>Reconciliation queue action: LINK | IGNORE | NOT_DUPLICATE | ACCEPT_OBSERVED | KEEP_CURRENT.</summary>
public sealed record AssetReconciliationResolveRequest(long OrganizationId, string? Action, long? AssetId, string? Note, long? ExpectedRecordVersion);

/// <summary>Outcome of a write: Success, the new/affected id, and on
/// failure the SQL error number + message so the controller can pick the""")])

files[A + 'Services/AssetConfigService.cs'] = edit(A + 'Services/AssetConfigService.cs', [
("""//   sp_business_service* (441 -- business services, consumers, status rules, conflicts, hierarchy)""",
"""//   sp_business_service* (441 -- business services, consumers, status rules, conflicts, hierarchy)
//   sp_asset_discovery_* / sp_asset_reconciliation_* (442 -- discovery sources, rules, ingestion, queue, confidence)"""),
("""    Task<object> GetBusinessServiceTreeAsync(long organizationId, CancellationToken ct);
}""",
"""    Task<object> GetBusinessServiceTreeAsync(long organizationId, CancellationToken ct);

    // 442 -- Asset discovery and reconciliation
    Task<object> GetDiscoveryConfigAsync(long organizationId, CancellationToken ct);
    Task<AssetLifecycleResult> SaveDiscoverySourceAsync(AssetDiscoverySourceRequest request, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> SaveDiscoveryPrioritiesAsync(long sourceId, AssetDiscoveryPrioritiesRequest request, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> SaveIdentificationRuleAsync(AssetIdentificationRuleRequest request, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> SaveDiscoverySettingAsync(AssetDiscoverySettingRequest request, string actor, CancellationToken ct);
    Task<(object? Data, int? ErrorNumber, string? Error)> IngestDiscoveryBatchAsync(long sourceId, AssetDiscoveryIngestRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<object> ListDiscoveryBatchesAsync(long organizationId, long? sourceId, int pageNumber, int pageSize, CancellationToken ct);
    Task<object?> GetDiscoveryBatchAsync(long organizationId, long batchId, CancellationToken ct);
    Task<object> ListReconciliationExceptionsAsync(long organizationId, string? status, string? kind, long? sourceId, long? assetId, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<AssetLifecycleResult> ResolveReconciliationExceptionAsync(long exceptionId, AssetReconciliationResolveRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<object> ListDiscoveryConfidenceAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<object?> GetDiscoveryAssetAsync(long organizationId, long assetId, CancellationToken ct);
}"""),
("""    public async Task<object> GetBusinessServiceTreeAsync(long organizationId, CancellationToken ct)
    {""",
"""    // ----------------------------------------------------------------
    // 442 -- Asset discovery and reconciliation
    // ----------------------------------------------------------------
    public async Task<object> GetDiscoveryConfigAsync(long organizationId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_discovery_config_get");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var settings = await ReadRowsAsync(reader, ct);
        var empty = new List<Dictionary<string, object?>>();
        var sources = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var priorities = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var rules = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var employees = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var fields = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        return new { settings = settings.Count > 0 ? settings[0] : null, sources, priorities, rules, employees, fields };
    }

    public Task<AssetLifecycleResult> SaveDiscoverySourceAsync(AssetDiscoverySourceRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_discovery_source_save", "sourceId", command =>
        {
            AddParam(command, "@organization_id",            DbType.Int64,   request.OrganizationId);
            AddParam(command, "@source_id",                  DbType.Int64,   request.SourceId);
            AddParam(command, "@source_code",                DbType.String,  Blank(request.SourceCode), 40);
            AddParam(command, "@source_name",                DbType.String,  Blank(request.SourceName), 200);
            AddParam(command, "@source_type",                DbType.String,  Blank(request.SourceType), 12);
            AddParam(command, "@collection_mode",            DbType.String,  Blank(request.CollectionMode), 8);
            AddParam(command, "@scope_text",                 DbType.String,  Blank(request.ScopeText), 400);
            AddParam(command, "@mapping_version",            DbType.String,  Blank(request.MappingVersion), 40);
            AddParam(command, "@owner_employee_id",          DbType.Int64,   request.OwnerEmployeeId);
            AddParam(command, "@credential_reference",       DbType.String,  Blank(request.CredentialReference), 200);
            AddParam(command, "@trust_level",                DbType.Int32,   request.TrustLevel);
            AddParam(command, "@expected_interval_hours",    DbType.Int32,   request.ExpectedIntervalHours);
            AddParam(command, "@raw_retention_days",         DbType.Int32,   request.RawRetentionDays);
            AddParam(command, "@observation_retention_days", DbType.Int32,   request.ObservationRetentionDays);
            AddParam(command, "@is_active",                  DbType.Boolean, request.IsActive ?? true);
            AddParam(command, "@expected_record_version",    DbType.Int64,   request.ExpectedRecordVersion);
            AddParam(command, "@actor",                      DbType.String,  actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> SaveDiscoveryPrioritiesAsync(long sourceId, AssetDiscoveryPrioritiesRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_discovery_priorities_save", "sourceId", command =>
        {
            AddParam(command, "@organization_id", DbType.Int64,  request.OrganizationId);
            AddParam(command, "@source_id",       DbType.Int64,  sourceId);
            AddParam(command, "@priorities_json", DbType.String, System.Text.Json.JsonSerializer.Serialize(
                (request.Priorities ?? new List<AssetDiscoveryPriorityItem>()).Select(p => new
                {
                    fieldKey = p.FieldKey, sourceRole = p.SourceRole, priority = p.Priority
                })));
            AddParam(command, "@actor",           DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> SaveIdentificationRuleAsync(AssetIdentificationRuleRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_identification_rule_save", "ruleId", command =>
        {
            AddParam(command, "@organization_id", DbType.Int64,   request.OrganizationId);
            AddParam(command, "@rule_id",         DbType.Int64,   request.RuleId);
            AddParam(command, "@rule_name",       DbType.String,  Blank(request.RuleName), 120);
            AddParam(command, "@attribute_keys",  DbType.String,  Blank(request.AttributeKeys), 400);
            AddParam(command, "@strength",        DbType.String,  Blank(request.Strength), 10);
            AddParam(command, "@weight",          DbType.Int32,   request.Weight);
            AddParam(command, "@is_active",       DbType.Boolean, request.IsActive ?? true);
            AddParam(command, "@display_order",   DbType.Int32,   request.DisplayOrder ?? 100);
            AddParam(command, "@actor",           DbType.String,  actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> SaveDiscoverySettingAsync(AssetDiscoverySettingRequest request, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_discovery_setting_save", "organizationId", command =>
        {
            AddParam(command, "@organization_id",       DbType.Int64,   request.OrganizationId);
            AddParam(command, "@auto_match_score",      DbType.Int32,   request.AutoMatchScore);
            AddParam(command, "@suggested_score",       DbType.Int32,   request.SuggestedScore);
            AddParam(command, "@manual_review_score",   DbType.Int32,   request.ManualReviewScore);
            AddParam(command, "@stale_multiplier",      DbType.Int32,   request.StaleMultiplier);
            AddParam(command, "@verification_days",     DbType.Int32,   request.VerificationDays);
            AddParam(command, "@create_conflict_tasks", DbType.Boolean, request.CreateConflictTasks ?? true);
            AddParam(command, "@actor",                 DbType.String,  actor, 100);
        }, ct);

    public async Task<(object? Data, int? ErrorNumber, string? Error)> IngestDiscoveryBatchAsync(long sourceId, AssetDiscoveryIngestRequest request, long? actorEmployeeId, string actor, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_discovery_ingest");
            command.CommandTimeout = 600;   // up to 5000 records, each reconciled on its own
            AddParam(command, "@organization_id",   DbType.Int64,  request.OrganizationId);
            AddParam(command, "@source_id",         DbType.Int64,  sourceId);
            AddParam(command, "@batch_reference",   DbType.String, Blank(request.BatchReference), 100);
            AddParam(command, "@channel",           DbType.String, Blank(request.Channel) ?? "UI", 10);
            AddParam(command, "@records_json",      DbType.String, request.Records is { } r ? r.GetRawText() : null);
            AddParam(command, "@actor_employee_id", DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",             DbType.String, actor, 100);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var batch = await ReadRowsAsync(reader, ct);
            var records = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
            return (new { batch = batch.Count > 0 ? batch[0] : null, records }, null, null);
        }
        catch (SqlException ex)
        {
            logger.LogWarning(ex, "AssetConfigService sp_asset_discovery_ingest refused ({Number})", ex.Number);
            return (null, ex.Number, ex.Message);
        }
    }

    public async Task<object> ListDiscoveryBatchesAsync(long organizationId, long? sourceId, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_discovery_batches");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        AddParam(command, "@source_id",       DbType.Int64, sourceId);
        AddParam(command, "@page_number",     DbType.Int32, pageNumber);
        AddParam(command, "@page_size",       DbType.Int32, pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object?> GetDiscoveryBatchAsync(long organizationId, long batchId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_discovery_batch_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@batch_id",        DbType.Int64, batchId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var batch = await ReadRowsAsync(reader, ct);
            if (batch.Count == 0) return null;
            var records = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
            return new { batch = batch[0], records };
        }
        catch (SqlException ex) when (ex.Number == 54779) { return null; }
    }

    public async Task<object> ListReconciliationExceptionsAsync(long organizationId, string? status, string? kind, long? sourceId, long? assetId, string? search, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_reconciliation_exceptions");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 10);
        AddParam(command, "@exception_kind",  DbType.String, Blank(kind), 16);
        AddParam(command, "@source_id",       DbType.Int64,  sourceId);
        AddParam(command, "@asset_id",        DbType.Int64,  assetId);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public Task<AssetLifecycleResult> ResolveReconciliationExceptionAsync(long exceptionId, AssetReconciliationResolveRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_reconciliation_resolve", "exceptionId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@exception_id",            DbType.Int64,  exceptionId);
            AddParam(command, "@action",                  DbType.String, Blank(request.Action), 20);
            AddParam(command, "@asset_id",                DbType.Int64,  request.AssetId);
            AddParam(command, "@note",                    DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public async Task<object> ListDiscoveryConfidenceAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_discovery_confidence");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 12);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    public async Task<object?> GetDiscoveryAssetAsync(long organizationId, long assetId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_discovery_asset_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@asset_id",        DbType.Int64, assetId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var confidence = await ReadRowsAsync(reader, ct);
            var empty = new List<Dictionary<string, object?>>();
            var links = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var attributes = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var exceptions = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            return new { confidence = confidence.Count > 0 ? confidence[0] : null, links, attributes, exceptions };
        }
        catch (SqlException ex) when (ex.Number == 54777) { return null; }
    }

    public async Task<object> GetBusinessServiceTreeAsync(long organizationId, CancellationToken ct)
    {"""),
])

files[A + 'Controllers/AssetConfigController.cs'] = edit(A + 'Controllers/AssetConfigController.cs', [
("""//   GET  business-services/tree?organizationId=      service hierarchy
""",
"""//   GET  business-services/tree?organizationId=      service hierarchy
//   GET  discovery/config?organizationId=            settings, sources with health, precedence, rules, employees, fields (442)
//   POST discovery/sources                           add / change a source
//   POST discovery/sources/{id}/priorities           field precedence of a source (replaces it)
//   POST discovery/sources/{id}/batches              ingest a batch (UI, import or API) -> batch + per-record results
//   POST discovery/rules                             add / change an identification rule
//   POST discovery/settings                          thresholds, stale multiplier, verification window, conflict tasks
//   GET  discovery/batches?organizationId=&sourceId=&pageNumber=&pageSize=
//   GET  discovery/batches/{id}?organizationId=      batch + records
//   GET  discovery/exceptions?organizationId=&status=&kind=&sourceId=&assetId=&search=&pageNumber=&pageSize=
//   POST discovery/exceptions/{id}/resolve           LINK | IGNORE | NOT_DUPLICATE | ACCEPT_OBSERVED | KEEP_CURRENT
//   GET  discovery/confidence?organizationId=&status=&search=&pageNumber=&pageSize=
//   GET  discovery/assets/{assetId}?organizationId=  confidence, links, values per source, open exceptions
"""),
("""    // 441: 54730 (organization), 54731 (service) -> 404; 54732 (stale), 54747 (retirement pending / none) -> 409.""",
"""    // ---------------------------------------------------------------- 442: discovery and reconciliation
    [HttpGet("discovery/config")]
    public Task<IActionResult> DiscoveryConfig([FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.GetDiscoveryConfigAsync(organizationId.Value, ct), "discovery config");
    }

    [HttpPost("discovery/sources")]
    public async Task<IActionResult> SaveDiscoverySource([FromBody] AssetDiscoverySourceRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveDiscoverySourceAsync(request, Actor, ct), DiscoveryNotFound, DiscoveryConflict);
    }

    [HttpPost("discovery/sources/{sourceId:long}/priorities")]
    public async Task<IActionResult> SaveDiscoveryPriorities(long sourceId, [FromBody] AssetDiscoveryPrioritiesRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveDiscoveryPrioritiesAsync(sourceId, request, Actor, ct), DiscoveryNotFound, DiscoveryConflict);
    }

    [HttpPost("discovery/sources/{sourceId:long}/batches")]
    public async Task<IActionResult> IngestDiscoveryBatch(long sourceId, [FromBody] AssetDiscoveryIngestRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        var (data, number, error) = await service.IngestDiscoveryBatchAsync(sourceId, request, ActorEmployeeId, Actor, ct);
        if (number is null) return Ok(new { success = true, data });
        var body = new { success = false, error, errorNumber = number };
        return number is int n && DiscoveryNotFound.Contains(n) ? NotFound(body) : BadRequest(body);
    }

    [HttpPost("discovery/rules")]
    public async Task<IActionResult> SaveIdentificationRule([FromBody] AssetIdentificationRuleRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveIdentificationRuleAsync(request, Actor, ct), DiscoveryNotFound, DiscoveryConflict);
    }

    [HttpPost("discovery/settings")]
    public async Task<IActionResult> SaveDiscoverySetting([FromBody] AssetDiscoverySettingRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveDiscoverySettingAsync(request, Actor, ct), DiscoveryNotFound, DiscoveryConflict);
    }

    [HttpGet("discovery/batches")]
    public Task<IActionResult> DiscoveryBatches([FromQuery] long? organizationId, [FromQuery] long? sourceId, [FromQuery] int? pageNumber,
        [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListDiscoveryBatchesAsync(organizationId.Value, sourceId, pageNumber ?? 1, pageSize ?? 25, ct), "discovery batches");
    }

    [HttpGet("discovery/batches/{batchId:long}")]
    public Task<IActionResult> DiscoveryBatch(long batchId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetDiscoveryBatchAsync(o, batchId, ct), "Discovery batch not found.", "discovery batch");

    [HttpGet("discovery/exceptions")]
    public Task<IActionResult> ReconciliationExceptions([FromQuery] long? organizationId, [FromQuery] string? status, [FromQuery] string? kind,
        [FromQuery] long? sourceId, [FromQuery] long? assetId, [FromQuery] string? search, [FromQuery] int? pageNumber, [FromQuery] int? pageSize,
        CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListReconciliationExceptionsAsync(organizationId.Value, status, kind, sourceId, assetId, search,
            pageNumber ?? 1, pageSize ?? 25, ct), "reconciliation exceptions");
    }

    [HttpPost("discovery/exceptions/{exceptionId:long}/resolve")]
    public async Task<IActionResult> ResolveReconciliationException(long exceptionId, [FromBody] AssetReconciliationResolveRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Action)) return BadRequest(new { error = "action is required." });
        return ResultWritten(await service.ResolveReconciliationExceptionAsync(exceptionId, request, ActorEmployeeId, Actor, ct),
            DiscoveryNotFound, DiscoveryConflict);
    }

    [HttpGet("discovery/confidence")]
    public Task<IActionResult> DiscoveryConfidence([FromQuery] long? organizationId, [FromQuery] string? status, [FromQuery] string? search,
        [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListDiscoveryConfidenceAsync(organizationId.Value, status, search, pageNumber ?? 1, pageSize ?? 25, ct),
            "data confidence");
    }

    [HttpGet("discovery/assets/{assetId:long}")]
    public Task<IActionResult> DiscoveryAsset(long assetId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetDiscoveryAssetAsync(o, assetId, ct), "Asset not found.", "discovery asset");

    // 442: 54760 (organization), 54761 (source), 54767 (rule), 54773 (exception), 54779 (batch) -> 404;
    //      54774 (stale) -> 409.
    private static readonly int[] DiscoveryNotFound = { 54760, 54761, 54767, 54773, 54779 };
    private static readonly int[] DiscoveryConflict = { 54774 };

    // 441: 54730 (organization), 54731 (service) -> 404; 54732 (stale), 54747 (retirement pending / none) -> 409."""),
])

files[W + 'Controllers/AssetConfigController.cs'] = edit(W + 'Controllers/AssetConfigController.cs', [
("""//                                      supporting-item mappings go through relationships... (440 rules)""",
"""//                                      supporting-item mappings go through relationships... (440 rules)
//   discovery... (442)                 asset-discovery: GET VIEW (organization required); POST sources,
//                                      sources/{id}/priorities, rules, settings and batches EDIT;
//                                      exceptions/{id}/resolve ACCEPT_OBSERVED -> APPROVE, other actions EDIT"""),
("""    private const string ServiceArea = "business-services";          // 441""",
"""    private const string ServiceArea = "business-services";          // 441
    private const string DiscoveryArea = "asset-discovery";          // 442"""),
("""        else if (lower == "business-services" || lower.StartsWith("business-services/"))   // 441
        {""",
"""        else if (lower.StartsWith("discovery/"))                                // 442
        {
            if (!long.TryParse(Request.Query["organizationId"], out var orgId) || orgId <= 0)
                return BadRequest(new { error = "organizationId is required." });
            if (!HttpContext.IsOrganizationAllowed(orgId)) return OrganizationDenied();
            allowed = Can(DiscoveryArea, "VIEW");
        }
        else if (lower == "business-services" || lower.StartsWith("business-services/"))   // 441
        {"""),
("""        var isService = lower == "business-services" || lower.StartsWith("business-services/");   // 441""",
"""        var isService = lower == "business-services" || lower.StartsWith("business-services/");   // 441
        var isDiscovery = lower.StartsWith("discovery/");                        // 442"""),
("""            && !isActivity && !isRelationship && !isService && !lower.StartsWith("templates"))""",
"""            && !isActivity && !isRelationship && !isService && !isDiscovery && !lower.StartsWith("templates"))"""),
("""        var area = isService ? ServiceArea : isRelationship""",
"""        var area = isDiscovery ? DiscoveryArea : isService ? ServiceArea : isRelationship"""),
("""            : isService
            ? false""",
"""            : isService
            ? false
            : isDiscovery && lower.StartsWith("discovery/exceptions/") && lower.EndsWith("/resolve")   // 442
            ? (exceptionAction == "ACCEPT_OBSERVED" ? Can(area, "APPROVE") : Can(area, "EDIT"))
            : isDiscovery && (lower == "discovery/sources" || lower == "discovery/rules" || lower == "discovery/settings"
                              || (lower.StartsWith("discovery/sources/") && (lower.EndsWith("/priorities") || lower.EndsWith("/batches"))))
            ? Can(area, "EDIT")
            : isDiscovery
            ? false"""),
])

files[W + 'Models/PracticeScreen.cs'] = edit(W + 'Models/PracticeScreen.cs', [(
"""        // Phase 7.2 (migration 441): business services -- register, consumers,""",
"""        // Phase 7.3 (migration 442): discovery and reconciliation -- sources,
        // rules, ingestion, reconciliation queue, data confidence.
        new("asset-discovery","Asset Discovery","Discovery and reconciliation: source profiles with field precedence and trust, identification rules and thresholds, batch import with per-record results, the reconciliation queue (suggested matches, reviews, new candidates, duplicates, conflicts) and data confidence and freshness per asset.","satellite-dish",["Source","Batch","Outcome","Asset","Confidence"], AssetContractGroup),
        // Phase 7.2 (migration 441): business services -- register, consumers,""")])

files[W + 'Views/Practice/Manage.cshtml'] = edit(W + 'Views/Practice/Manage.cshtml', [(
"""        // Phase 7.2 (migration 441): business services.
        "business-services"
    };""",
"""        // Phase 7.2 (migration 441): business services.
        "business-services",
        // Phase 7.3 (migration 442): discovery and reconciliation.
        "asset-discovery"
    };""")])

for p in (A + 'appsettings.json', W + 'appsettings.json'):
    files[p] = edit(p, [(""""asset-relationships:*", "business-services:*" ],""",
                         """"asset-relationships:*", "business-services:*", "asset-discovery:*" ],""")])

D = 'database/274_menu_master_seed.sql'
files[D] = edit(D, [
("""--   441 -- 'business-services' (362, Business Services) under
--     'nav-asset-contract'.
""",
"""--   441 -- 'business-services' (362, Business Services) under
--     'nav-asset-contract'.
--   442 -- 'asset-discovery' (363, Asset Discovery) under
--     'nav-asset-contract'.
"""),
("""    (N'business-services'             , N'Business Services'                 , N'Practice/Index/business-services'           ,  362, N'sitemap'               , N'Asset & Contract'           , N'Active')   -- 441""",
"""    (N'business-services'             , N'Business Services'                 , N'Practice/Index/business-services'           ,  362, N'sitemap'               , N'Asset & Contract'           , N'Active'),  -- 441
    (N'asset-discovery'               , N'Asset Discovery'                   , N'Practice/Index/asset-discovery'             ,  363, N'satellite-dish'        , N'Asset & Contract'           , N'Active')   -- 442"""),
("""    (N'business-services'             , N'nav-asset-contract')   -- 441""",
"""    (N'business-services'             , N'nav-asset-contract'),  -- 441
    (N'asset-discovery'               , N'nav-asset-contract')   -- 442"""),
])

for p, s in files.items():
    open(p, 'w', encoding='utf-8', newline='').write(s)
print('442 ok', len(files))
