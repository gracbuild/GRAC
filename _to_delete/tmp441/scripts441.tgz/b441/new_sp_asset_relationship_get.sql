CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationship_get
    @organization_id BIGINT,
    @relationship_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_relationship
                    WHERE relationship_id = @relationship_id AND organization_id = @organization_id)
        THROW 54709, 'Relationship not found for this organization.', 1;
    SELECT r.relationship_id AS RelationshipId, r.relationship_type_code AS TypeCode, t.type_name AS TypeName,
           t.inverse_label AS InverseLabel, t.dependent_side AS DependentSide, r.source_kind AS SourceKind, r.source_id AS SourceId,
           sc.CiName AS SourceName, sc.CiClass AS SourceClass, sc.CiStatus AS SourceStatus, r.target_kind AS TargetKind,
           r.target_id AS TargetId, tc.CiName AS TargetName, tc.CiClass AS TargetClass, tc.CiStatus AS TargetStatus,
           r.is_critical AS IsCritical, r.dependency_criticality AS DependencyCriticality, r.impact_weight AS ImpactWeight,
           r.service_role AS ServiceRole,                                                             -- 441
           r.status AS Status, r.effective_from AS EffectiveFrom, r.effective_to AS EffectiveTo, r.source_code AS SourceCode,
           r.confidence_pct AS ConfidencePct, r.verification_status AS VerificationStatus, r.owner_employee_id AS OwnerEmployeeId,
           ow.employee_name AS OwnerName, r.verifier_employee_id AS VerifierEmployeeId, vf.employee_name AS VerifierName,
           r.evidence_reference AS EvidenceReference, r.change_reference AS ChangeReference, r.reason AS Reason, r.in_loop AS InLoop,
           r.version_no AS VersionNo, r.proposed_by AS ProposedBy, r.proposed_dt AS ProposedDt, r.approved_by AS ApprovedBy,
           r.approved_dt AS ApprovedDt, r.pending_action AS PendingAction, r.pending_json AS PendingJson,
           r.pending_reason AS PendingReason, r.pending_by AS PendingBy, r.pending_dt AS PendingDt,
           r.retirement_accepted AS RetirementAccepted, r.retirement_note AS RetirementNote,
           r.retirement_accepted_by AS RetirementAcceptedBy, r.retirement_accepted_dt AS RetirementAcceptedDt,
           r.status_note AS StatusNote, CONVERT(BIGINT, r.record_version) AS RecordVersion
      FROM grac_practice.asset_relationship r
      JOIN grac_practice.asset_relationship_type t ON t.type_code = r.relationship_type_code
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) sc ON sc.CiKind = r.source_kind AND sc.CiId = r.source_id
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) tc ON tc.CiKind = r.target_kind AND tc.CiId = r.target_id
      LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = r.owner_employee_id
      LEFT JOIN grac_practice.organization_employee vf ON vf.employee_id = r.verifier_employee_id
     WHERE r.relationship_id = @relationship_id;
    SELECT h.history_id AS HistoryId, h.version_no AS VersionNo, h.action_code AS ActionCode, h.status AS Status,
           h.note AS Note, h.actor AS Actor, e.employee_name AS ActorName, h.entered_dt AS EnteredDt, h.snapshot_json AS SnapshotJson
      FROM grac_practice.asset_relationship_history h
      LEFT JOIN grac_practice.organization_employee e ON e.employee_id = h.actor_employee_id
     WHERE h.relationship_id = @relationship_id
     ORDER BY h.history_id DESC;
END
GO
