
-- =====================================================================
-- 5. Helpers, defaults, configuration writers
-- =====================================================================
-- Normalized identity value: trimmed upper case; a MAC loses its
-- separators; a hostname is compared by its short name (D99).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_norm (@field_key NVARCHAR(100), @value NVARCHAR(400))
RETURNS NVARCHAR(400)
AS
BEGIN
    DECLARE @v NVARCHAR(400) = UPPER(LTRIM(RTRIM(ISNULL(@value, N''))));
    IF @field_key = N'mac_address' SET @v = REPLACE(REPLACE(REPLACE(@v, N':', N''), N'-', N''), N'.', N'');
    IF @field_key = N'hostname' AND CHARINDEX(N'.', @v) > 1 SET @v = LEFT(@v, CHARINDEX(N'.', @v) - 1);
    RETURN NULLIF(@v, N'');
END
GO

-- Default identification rules and settings of an organization (BRD 5.6.2
-- table; D98-D99). Only adds what is missing.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_defaults_ensure
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_discovery_setting WHERE organization_id = @organization_id)
        INSERT grac_practice.asset_discovery_setting
            (organization_id, auto_match_score, suggested_score, manual_review_score, stale_multiplier, verification_days,
             create_conflict_tasks, rule_set_version, updated_by)
        VALUES (@organization_id, 90, 70, 40, 3, 365, 1, 1, N'seed-442');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_identification_rule WHERE organization_id = @organization_id)
        INSERT grac_practice.asset_identification_rule
            (organization_id, rule_name, attribute_keys, strength, weight, is_active, display_order, entered_by)
        SELECT @organization_id, r.rule_name, r.attribute_keys, r.strength, r.weight, 1, r.display_order, N'seed-442'
          FROM (VALUES (N'Cloud resource identifier', N'cloud_resource_identifier', N'STRONG', 100, 10),
                       (N'Serial number + make + model', N'serial_number,manufacturer_make,model', N'STRONG', 95, 20),
                       (N'Source record ID (device / directory ID)', N'@source_key', N'STRONG', 95, 30),
                       (N'Asset tag', N'asset_tag', N'STRONG', 90, 40),
                       (N'Finance asset number', N'finance_asset_number', N'STRONG', 85, 50),
                       (N'Serial number', N'serial_number', N'SUPPORTING', 75, 60),
                       (N'Hostname + domain', N'hostname,domain', N'SUPPORTING', 70, 70),
                       (N'MAC address', N'mac_address', N'SUPPORTING', 65, 80),
                       (N'Hostname', N'hostname', N'SUPPORTING', 50, 90),
                       (N'IP address', N'ip_address', N'WEAK', 25, 100)) AS r(rule_name, attribute_keys, strength, weight, display_order);
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_source_save
    @organization_id            BIGINT,
    @source_id                  BIGINT        = NULL,
    @source_code                NVARCHAR(40)  = NULL,
    @source_name                NVARCHAR(200) = NULL,
    @source_type                NVARCHAR(12)  = NULL,
    @collection_mode            NVARCHAR(8)   = NULL,
    @scope_text                 NVARCHAR(400) = NULL,
    @mapping_version            NVARCHAR(40)  = NULL,
    @owner_employee_id          BIGINT        = NULL,
    @credential_reference       NVARCHAR(200) = NULL,
    @trust_level                INT           = 80,
    @expected_interval_hours    INT           = 24,
    @raw_retention_days         INT           = 30,
    @observation_retention_days INT           = 365,
    @is_active                  BIT           = 1,
    @expected_record_version    BIGINT        = NULL,
    @actor                      NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @source_code = NULLIF(UPPER(LTRIM(RTRIM(@source_code))), N'');
    SET @source_name = NULLIF(LTRIM(RTRIM(@source_name)), N'');
    SET @source_type = UPPER(LTRIM(RTRIM(ISNULL(@source_type, N''))));
    SET @collection_mode = UPPER(LTRIM(RTRIM(ISNULL(@collection_mode, N''))));
    SET @scope_text = NULLIF(LTRIM(RTRIM(@scope_text)), N'');
    SET @mapping_version = NULLIF(LTRIM(RTRIM(@mapping_version)), N'');
    SET @credential_reference = NULLIF(LTRIM(RTRIM(@credential_reference)), N'');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54760, 'Organization not found.', 1;
    IF @source_code IS NULL OR @source_name IS NULL
        THROW 54762, 'Enter the source ID and name.', 1;
    IF EXISTS (SELECT 1 FROM grac_practice.asset_discovery_source
                WHERE organization_id = @organization_id AND source_id <> ISNULL(@source_id, -1)
                  AND (source_code = @source_code OR source_name = @source_name))
        THROW 54762, 'Another source already uses this source ID or name.', 1;
    IF @source_type NOT IN (N'DISCOVERY', N'ENDPOINT', N'IDENTITY', N'CLOUD', N'NETWORK', N'SECURITY', N'ERP', N'BIOMEDICAL', N'FLEET', N'CUSTOM')
       OR @collection_mode NOT IN (N'POLLING', N'WEBHOOK', N'BATCH', N'FILE', N'API')
        THROW 54763, 'Select the source type and the collection mode.', 1;
    IF ISNULL(@trust_level, 0) NOT BETWEEN 1 AND 100 OR ISNULL(@expected_interval_hours, 0) NOT BETWEEN 1 AND 8760
       OR ISNULL(@raw_retention_days, 0) NOT BETWEEN 1 AND 3650 OR ISNULL(@observation_retention_days, 0) NOT BETWEEN 1 AND 3650
       OR @raw_retention_days > @observation_retention_days
        THROW 54764, 'Trust 1-100, expected interval 1-8760 hours, retention 1-3650 days (raw payloads no longer than observations).', 1;
    IF @owner_employee_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM grac_practice.organization_employee
            WHERE employee_id = @owner_employee_id AND organization_id = @organization_id AND status = N'Active')
        THROW 54765, 'The source owner must be an active employee of the organization.', 1;
    DECLARE @id BIGINT = @source_id, @before NVARCHAR(MAX);
    IF @source_id IS NOT NULL
    BEGIN
        DECLARE @rv BIGINT;
        SELECT @rv = CONVERT(BIGINT, record_version),
               @before = (SELECT s2.source_code AS sourceCode, s2.source_name AS sourceName, s2.trust_level AS trustLevel,
                                 s2.is_active AS isActive FROM grac_practice.asset_discovery_source s2
                           WHERE s2.source_id = @source_id FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
          FROM grac_practice.asset_discovery_source WHERE source_id = @source_id AND organization_id = @organization_id;
        IF @rv IS NULL THROW 54761, 'Discovery source not found for this organization.', 1;
        IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
            THROW 54774, 'The source was changed by someone else; reload it and try again.', 1;
    END
    BEGIN TRAN;
    IF @id IS NULL
    BEGIN
        INSERT grac_practice.asset_discovery_source
            (organization_id, source_code, source_name, source_type, collection_mode, scope_text, mapping_version, owner_employee_id,
             credential_reference, trust_level, expected_interval_hours, raw_retention_days, observation_retention_days, is_active, entered_by)
        VALUES (@organization_id, @source_code, @source_name, @source_type, @collection_mode, @scope_text, @mapping_version,
                @owner_employee_id, @credential_reference, @trust_level, @expected_interval_hours, @raw_retention_days,
                @observation_retention_days, ISNULL(@is_active, 1), @actor);
        SET @id = SCOPE_IDENTITY();
    END
    ELSE
        UPDATE grac_practice.asset_discovery_source
           SET source_code = @source_code, source_name = @source_name, source_type = @source_type, collection_mode = @collection_mode,
               scope_text = @scope_text, mapping_version = @mapping_version, owner_employee_id = @owner_employee_id,
               credential_reference = @credential_reference, trust_level = @trust_level, expected_interval_hours = @expected_interval_hours,
               raw_retention_days = @raw_retention_days, observation_retention_days = @observation_retention_days,
               is_active = ISNULL(@is_active, 1), updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE source_id = @id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-discovery-source', @id, CASE WHEN @source_id IS NULL THEN N'CREATE' ELSE N'UPDATE' END, @before,
            (SELECT @source_code AS sourceCode, @source_name AS sourceName, @source_type AS sourceType, @collection_mode AS collectionMode,
                    @trust_level AS trustLevel, @expected_interval_hours AS expectedIntervalHours, ISNULL(@is_active, 1) AS isActive
                FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @id AS SourceId, CASE WHEN @source_id IS NULL THEN N'CREATED' ELSE N'SAVED' END AS Result;
END
GO

-- Field precedence of a source (replaces the list):
-- [{"fieldKey":"hostname","sourceRole":"GOLDEN","priority":1}, ...]. One
-- golden source per field in the organization (D100).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_priorities_save
    @organization_id BIGINT,
    @source_id       BIGINT,
    @priorities_json NVARCHAR(MAX),
    @actor           NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_discovery_source WHERE source_id = @source_id AND organization_id = @organization_id)
        THROW 54761, 'Discovery source not found for this organization.', 1;
    IF ISJSON(ISNULL(@priorities_json, N'')) = 0 THROW 54766, 'The field precedence list is not valid.', 1;
    DECLARE @p TABLE (field_key NVARCHAR(100) NOT NULL PRIMARY KEY, source_role NVARCHAR(12) NOT NULL, priority INT NOT NULL);
    INSERT @p (field_key, source_role, priority)
    SELECT LTRIM(RTRIM(j.fieldKey)), UPPER(LTRIM(RTRIM(ISNULL(j.sourceRole, N'CONTRIBUTING')))), ISNULL(j.priority, 100)
      FROM OPENJSON(@priorities_json) WITH (fieldKey NVARCHAR(100), sourceRole NVARCHAR(12), priority INT) j
     WHERE NULLIF(LTRIM(RTRIM(j.fieldKey)), N'') IS NOT NULL;
    IF EXISTS (SELECT 1 FROM @p p WHERE p.source_role NOT IN (N'GOLDEN', N'CONTRIBUTING', N'IGNORED') OR p.priority NOT BETWEEN 1 AND 999
                  OR NOT EXISTS (SELECT 1 FROM grac_practice.asset_field_definition f WHERE f.field_key = p.field_key))
        THROW 54766, 'Each entry names a dictionary field, a role (golden, contributing, ignored) and a priority 1-999.', 1;
    DECLARE @clash NVARCHAR(400) = (
        SELECT TOP 1 CONCAT(p.field_key, N' (', s.source_name, N')')
          FROM @p p
          JOIN grac_practice.asset_discovery_priority o ON o.field_key = p.field_key AND o.source_role = N'GOLDEN' AND o.source_id <> @source_id
          JOIN grac_practice.asset_discovery_source s ON s.source_id = o.source_id AND s.organization_id = @organization_id
         WHERE p.source_role = N'GOLDEN');
    IF @clash IS NOT NULL
    BEGIN
        DECLARE @msg NVARCHAR(600) = CONCAT(N'Another source is already the golden source of ', @clash, N'.');
        THROW 54766, @msg, 1;
    END
    BEGIN TRAN;
    DELETE FROM grac_practice.asset_discovery_priority WHERE source_id = @source_id;
    INSERT grac_practice.asset_discovery_priority (source_id, field_key, source_role, priority)
    SELECT @source_id, field_key, source_role, priority FROM @p;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-discovery-source', @source_id, N'PRECEDENCE', NULL, @priorities_json, N'Active', @actor);
    COMMIT;
    SELECT @source_id AS SourceId, N'SAVED' AS Result;
END
GO

-- Identification rule (new or changed). Attribute keys are dictionary
-- fields or @source_key. Every change bumps the rule-set version.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_identification_rule_save
    @organization_id BIGINT,
    @rule_id         BIGINT        = NULL,
    @rule_name       NVARCHAR(120) = NULL,
    @attribute_keys  NVARCHAR(400) = NULL,
    @strength        NVARCHAR(10)  = NULL,
    @weight          INT           = NULL,
    @is_active       BIT           = 1,
    @display_order   INT           = 100,
    @actor           NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @rule_name = NULLIF(LTRIM(RTRIM(@rule_name)), N'');
    SET @attribute_keys = NULLIF(LOWER(REPLACE(LTRIM(RTRIM(@attribute_keys)), N' ', N'')), N'');
    SET @strength = UPPER(LTRIM(RTRIM(ISNULL(@strength, N''))));
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54760, 'Organization not found.', 1;
    EXEC grac_practice.sp_asset_discovery_defaults_ensure @organization_id = @organization_id;
    IF @rule_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_identification_rule
                                             WHERE rule_id = @rule_id AND organization_id = @organization_id)
        THROW 54767, 'Identification rule not found for this organization.', 1;
    IF @rule_name IS NULL OR @attribute_keys IS NULL OR @strength NOT IN (N'STRONG', N'SUPPORTING', N'WEAK')
       OR ISNULL(@weight, 0) NOT BETWEEN 1 AND 100
       OR EXISTS (SELECT 1 FROM STRING_SPLIT(@attribute_keys, N',') x
                   WHERE x.value <> N'@source_key'
                     AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_field_definition f WHERE f.field_key = x.value))
       OR EXISTS (SELECT 1 FROM grac_practice.asset_identification_rule
                   WHERE organization_id = @organization_id AND rule_name = @rule_name AND rule_id <> ISNULL(@rule_id, -1))
        THROW 54768, 'Name the rule (unique), list dictionary field keys (or @source_key), choose the strength and a weight 1-100.', 1;
    DECLARE @id BIGINT = @rule_id;
    BEGIN TRAN;
    IF @id IS NULL
    BEGIN
        INSERT grac_practice.asset_identification_rule
            (organization_id, rule_name, attribute_keys, strength, weight, is_active, display_order, entered_by)
        VALUES (@organization_id, @rule_name, @attribute_keys, @strength, @weight, ISNULL(@is_active, 1), ISNULL(@display_order, 100), @actor);
        SET @id = SCOPE_IDENTITY();
    END
    ELSE
        UPDATE grac_practice.asset_identification_rule
           SET rule_name = @rule_name, attribute_keys = @attribute_keys, strength = @strength, weight = @weight,
               is_active = ISNULL(@is_active, 1), display_order = ISNULL(@display_order, 100), updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE rule_id = @id;
    UPDATE grac_practice.asset_discovery_setting
       SET rule_set_version = rule_set_version + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()
     WHERE organization_id = @organization_id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-identification-rule', @id, CASE WHEN @rule_id IS NULL THEN N'CREATE' ELSE N'UPDATE' END, NULL,
            (SELECT @rule_name AS ruleName, @attribute_keys AS attributeKeys, @strength AS strength, @weight AS weight,
                    ISNULL(@is_active, 1) AS isActive FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @id AS RuleId, CASE WHEN @rule_id IS NULL THEN N'CREATED' ELSE N'SAVED' END AS Result;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_setting_save
    @organization_id       BIGINT,
    @auto_match_score      INT,
    @suggested_score       INT,
    @manual_review_score   INT,
    @stale_multiplier      INT,
    @verification_days     INT,
    @create_conflict_tasks BIT,
    @actor                 NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54760, 'Organization not found.', 1;
    IF ISNULL(@auto_match_score, 0) > 100 OR ISNULL(@auto_match_score, 0) <= ISNULL(@suggested_score, 0)
       OR ISNULL(@suggested_score, 0) <= ISNULL(@manual_review_score, 0) OR ISNULL(@manual_review_score, 0) < 1
       OR ISNULL(@stale_multiplier, 0) NOT BETWEEN 1 AND 100 OR ISNULL(@verification_days, 0) NOT BETWEEN 1 AND 3650
        THROW 54769, 'Thresholds: auto match (up to 100) above suggested above manual review (at least 1); stale multiplier 1-100; verification 1-3650 days.', 1;
    EXEC grac_practice.sp_asset_discovery_defaults_ensure @organization_id = @organization_id;
    BEGIN TRAN;
    UPDATE grac_practice.asset_discovery_setting
       SET auto_match_score = @auto_match_score, suggested_score = @suggested_score, manual_review_score = @manual_review_score,
           stale_multiplier = @stale_multiplier, verification_days = @verification_days,
           create_conflict_tasks = ISNULL(@create_conflict_tasks, 1), rule_set_version = rule_set_version + 1,
           updated_by = @actor, updated_dt = SYSUTCDATETIME()
     WHERE organization_id = @organization_id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-discovery-setting', @organization_id, N'UPDATE', NULL,
            (SELECT @auto_match_score AS autoMatchScore, @suggested_score AS suggestedScore, @manual_review_score AS manualReviewScore,
                    @stale_multiplier AS staleMultiplier, @verification_days AS verificationDays,
                    ISNULL(@create_conflict_tasks, 1) AS createConflictTasks FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @organization_id AS OrganizationId, N'SAVED' AS Result;
END
GO
PRINT '442: helpers and configuration writers created.';
GO
