-- =====================================================================
-- 4. Privacy facts, retention, gaps and status (one evaluation for the
--    form save, lifecycle gates, scheduler, screens and reports)
-- =====================================================================
-- The 5.1.10 / 5.1.5 / 5.1.12 field values of each asset (empty and []
-- read as not recorded). Option values compare without case (YES = Yes).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_privacy_values (@organization_id BIGINT, @asset_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT a.asset_id AS AssetId, a.asset_name AS AssetName, a.asset_type_id AS AssetTypeId, s.status_code AS StatusCode,
           a.owner_id AS OwnerId, CAST(a.entered_dt AS DATE) AS RegisteredDate,
           NULLIF(NULLIF(p.pd, N''), N'[]') AS pd,     NULLIF(NULLIF(p.spc, N''), N'[]') AS spc,   NULLIF(NULLIF(p.chd, N''), N'[]') AS chd,
           NULLIF(NULLIF(p.dpdp, N''), N'[]') AS dpdp, NULLIF(NULLIF(p.gdpr, N''), N'[]') AS gdpr,
           NULLIF(NULLIF(p.powner, N''), N'[]') AS powner, NULLIF(NULLIF(p.pas, N''), N'[]') AS pas,
           NULLIF(NULLIF(p.pdc, N''), N'[]') AS pdc,   NULLIF(NULLIF(p.dsc, N''), N'[]') AS dsc,   NULLIF(NULLIF(p.pops, N''), N'[]') AS pops,
           NULLIF(NULLIF(p.pact, N''), N'[]') AS pact, NULLIF(NULLIF(p.ppur, N''), N'[]') AS ppur, NULLIF(NULLIF(p.hrp, N''), N'[]') AS hrp,
           NULLIF(NULLIF(p.dreq, N''), N'[]') AS dreq, NULLIF(NULLIF(p.dst, N''), N'[]') AS dst,
           NULLIF(NULLIF(p.mapp, N''), N'[]') AS mapp, NULLIF(NULLIF(p.mimp, N''), N'[]') AS mimp,
           NULLIF(NULLIF(p.mmeth, N''), N'[]') AS mmeth, NULLIF(NULLIF(p.mcov, N''), N'[]') AS mcov,
           NULLIF(NULLIF(p.ereq, N''), N'[]') AS ereq, NULLIF(NULLIF(p.eimp, N''), N'[]') AS eimp,
           NULLIF(NULLIF(p.rpol, N''), N'[]') AS rpol, NULLIF(NULLIF(p.rper, N''), N'[]') AS rper, NULLIF(NULLIF(p.rtrg, N''), N'[]') AS rtrg,
           NULLIF(NULLIF(p.lhold, N''), N'[]') AS lhold,
           NULLIF(NULLIF(p.tpa, N''), N'[]') AS tpa, NULLIF(NULLIF(p.proc_tp, N''), N'[]') AS proc_tp,
           NULLIF(NULLIF(p.cbt, N''), N'[]') AS cbt, NULLIF(NULLIF(p.tcty, N''), N'[]') AS tcty,
           NULLIF(NULLIF(p.dsreq, N''), N'[]') AS dsreq, p.rdate, NULLIF(NULLIF(p.rrisk, N''), N'[]') AS rrisk,
           NULLIF(NULLIF(p.sreq, N''), N'[]') AS sreq, NULLIF(NULLIF(p.smeth, N''), N'[]') AS smeth, p.sdate,
           NULLIF(NULLIF(p.sev, N''), N'[]') AS sev, NULLIF(NULLIF(p.psc, N''), N'[]') AS psc
      FROM grac_practice.organization_dependency_asset a
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
     OUTER APPLY (SELECT
            CAST(MAX(CASE WHEN d.field_key = N'personal_data_processed' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS pd,
            CAST(MAX(CASE WHEN d.field_key = N'special_category_or_health_data_processed' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS spc,
            CAST(MAX(CASE WHEN d.field_key = N'children_data_processed' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS chd,
            CAST(MAX(CASE WHEN d.field_key = N'dpdp_applicable' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS dpdp,
            CAST(MAX(CASE WHEN d.field_key = N'gdpr_applicable' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS gdpr,
            CAST(MAX(CASE WHEN d.field_key = N'privacy_owner' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS powner,
            CAST(MAX(CASE WHEN d.field_key = N'privacy_assessment_status' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS pas,
            CAST(MAX(CASE WHEN d.field_key = N'personal_data_categories' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS pdc,
            CAST(MAX(CASE WHEN d.field_key = N'data_subject_categories' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS dsc,
            CAST(MAX(CASE WHEN d.field_key = N'processing_operations' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS pops,
            CAST(MAX(CASE WHEN d.field_key = N'processing_activity' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS pact,
            CAST(MAX(CASE WHEN d.field_key = N'processing_purpose' THEN LEFT(LTRIM(RTRIM(v.value_text)), 400) END) AS NVARCHAR(400)) AS ppur,
            CAST(MAX(CASE WHEN d.field_key = N'high_risk_processing' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS hrp,
            CAST(MAX(CASE WHEN d.field_key = N'dpia_pia_required' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS dreq,
            CAST(MAX(CASE WHEN d.field_key = N'dpia_pia_status' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS dst,
            CAST(MAX(CASE WHEN d.field_key = N'masking_applicable' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS mapp,
            CAST(MAX(CASE WHEN d.field_key = N'masking_implemented' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS mimp,
            CAST(MAX(CASE WHEN d.field_key = N'masking_method' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS mmeth,
            CAST(MAX(CASE WHEN d.field_key = N'masking_coverage' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS mcov,
            CAST(MAX(CASE WHEN d.field_key = N'encryption_required' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS ereq,
            CAST(MAX(CASE WHEN d.field_key = N'encryption_implemented' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS eimp,
            CAST(MAX(CASE WHEN d.field_key = N'retention_policy' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS rpol,
            CAST(MAX(CASE WHEN d.field_key = N'retention_period' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS rper,
            CAST(MAX(CASE WHEN d.field_key = N'retention_trigger' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS rtrg,
            CAST(MAX(CASE WHEN d.field_key = N'legal_hold_status' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS lhold,
            CAST(MAX(CASE WHEN d.field_key = N'third_party_access' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS tpa,
            CAST(MAX(CASE WHEN d.field_key = N'processor_third_party' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS proc_tp,
            CAST(MAX(CASE WHEN d.field_key = N'cross_border_transfer' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS cbt,
            CAST(MAX(CASE WHEN d.field_key = N'transfer_countries' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS tcty,
            CAST(MAX(CASE WHEN d.field_key = N'deletion_sanitization_required' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS dsreq,
            MAX(CASE WHEN d.field_key = N'privacy_review_date' THEN v.value_date END) AS rdate,
            CAST(MAX(CASE WHEN d.field_key = N'residual_privacy_risk' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS rrisk,
            CAST(MAX(CASE WHEN d.field_key = N'sanitization_required' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS sreq,
            CAST(MAX(CASE WHEN d.field_key = N'sanitization_method' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS smeth,
            MAX(CASE WHEN d.field_key = N'sanitization_date' THEN v.value_date END) AS sdate,
            CAST(MAX(CASE WHEN d.field_key = N'sanitization_evidence' THEN LEFT(LTRIM(RTRIM(v.value_text)), 400) END) AS NVARCHAR(400)) AS sev,
            CAST(MAX(CASE WHEN d.field_key = N'primary_support_contract' THEN LTRIM(RTRIM(v.value_text)) END) AS NVARCHAR(400)) AS psc
           FROM grac_practice.asset_field_value v
           JOIN grac_practice.asset_field_definition d ON d.field_definition_id = v.field_definition_id
          WHERE v.asset_id = a.asset_id
            AND d.field_key IN (N'personal_data_processed', N'special_category_or_health_data_processed', N'children_data_processed',
                                N'dpdp_applicable', N'gdpr_applicable', N'privacy_owner', N'privacy_assessment_status',
                                N'personal_data_categories', N'data_subject_categories', N'processing_operations', N'processing_activity',
                                N'processing_purpose', N'high_risk_processing', N'dpia_pia_required', N'dpia_pia_status',
                                N'masking_applicable', N'masking_implemented', N'masking_method', N'masking_coverage',
                                N'encryption_required', N'encryption_implemented', N'retention_policy', N'retention_period',
                                N'retention_trigger', N'legal_hold_status', N'third_party_access', N'processor_third_party',
                                N'cross_border_transfer', N'transfer_countries', N'deletion_sanitization_required',
                                N'privacy_review_date', N'residual_privacy_risk', N'sanitization_required', N'sanitization_method',
                                N'sanitization_date', N'sanitization_evidence', N'primary_support_contract')) p
     WHERE a.organization_id = @organization_id AND a.merged_into_asset_id IS NULL
       AND (@asset_id IS NULL OR a.asset_id = @asset_id);
GO

-- Retention end (D158): "<n> day(s) | week(s) | month(s) | year(s)" from
-- the trigger date, at most 100 years -- Creation (registration date), Closure (first
-- completed move to Disposed / Archived), Contract end (end of the version
-- in force of the primary support contract). Employment end and Last
-- activity have no source date. A later extension (completed Extend /
-- Legal-hold review) moves the end.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_privacy_retention_calc
(
    @organization_id BIGINT,
    @asset_id        BIGINT,
    @period          NVARCHAR(400),
    @trigger         NVARCHAR(400),
    @registered      DATE,
    @contract        NVARCHAR(400)
)
RETURNS TABLE
AS
RETURN
    SELECT x.n AS RetentionNumber, u.unit AS RetentionUnit, b.basis_date AS RetentionBasisDate, f.formula_date AS FormulaDueDate,
           e.extended_until AS ExtendedUntil,
           CASE WHEN e.extended_until IS NOT NULL AND (f.formula_date IS NULL OR e.extended_until > f.formula_date) THEN e.extended_until
                ELSE f.formula_date END AS RetentionDueDate,
           CASE WHEN @period IS NOT NULL AND (x.n IS NULL OR x.n <= 0 OR u.unit IS NULL) THEN 1 ELSE 0 END AS PeriodInvalid
      FROM (SELECT TRY_CONVERT(INT, LEFT(@period, CHARINDEX(N' ', @period + N' ') - 1)) AS n,
                   LOWER(LTRIM(SUBSTRING(@period, CHARINDEX(N' ', @period + N' ') + 1, 50))) AS unit_text) x
     -- Units within 100 years only (DATEADD must not overflow).
     CROSS APPLY (SELECT CASE WHEN x.unit_text LIKE N'day%'   AND x.n BETWEEN 1 AND 36500 THEN N'DAY'
                              WHEN x.unit_text LIKE N'week%'  AND x.n BETWEEN 1 AND 5200  THEN N'WEEK'
                              WHEN x.unit_text LIKE N'month%' AND x.n BETWEEN 1 AND 1200  THEN N'MONTH'
                              WHEN x.unit_text LIKE N'year%'  AND x.n BETWEEN 1 AND 100   THEN N'YEAR' END AS unit) u
     CROSS APPLY (SELECT CASE UPPER(ISNULL(@trigger, N''))
                    WHEN N'CREATION' THEN @registered
                    WHEN N'CLOSURE' THEN (SELECT MIN(CAST(COALESCE(c.decided_dt, c.requested_dt) AS DATE))
                                            FROM grac_practice.asset_lifecycle_change c
                                           WHERE c.asset_id = @asset_id AND c.change_status = N'COMPLETED'
                                             AND c.to_status_code IN (N'DISPOSED', N'ARCHIVED'))
                    WHEN N'CONTRACT_END' THEN (SELECT TOP (1) cv.effective_end
                                                 FROM grac_practice.asset_contract k
                                                 JOIN grac_practice.asset_contract_version cv ON cv.version_id = k.current_version_id
                                                WHERE k.contract_id = TRY_CONVERT(BIGINT, @contract) AND k.organization_id = @organization_id)
                  END AS basis_date) b
     CROSS APPLY (SELECT CASE u.unit WHEN N'DAY' THEN DATEADD(DAY, x.n, b.basis_date) WHEN N'WEEK' THEN DATEADD(WEEK, x.n, b.basis_date)
                                     WHEN N'MONTH' THEN DATEADD(MONTH, x.n, b.basis_date) WHEN N'YEAR' THEN DATEADD(YEAR, x.n, b.basis_date) END AS formula_date) f
     OUTER APPLY (SELECT MAX(r.extended_until) AS extended_until
                    FROM grac_practice.asset_privacy_review r
                   WHERE r.asset_id = @asset_id AND r.review_kind = N'RETENTION' AND r.status = N'COMPLETED') e;
GO

-- Gaps per requirement. Applicable = personal data processed Yes or
-- Unknown; sanitization also applies to any asset with sanitization
-- required. Requirements set to OFF raise nothing; an approved, unexpired
-- exception marks the gap excepted.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_privacy_gaps (@organization_id BIGINT, @asset_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT v.AssetId, c.requirement_code AS RequirementCode, c.requirement_name AS RequirementName, g.kind AS GapKind,
           CAST(g.msg AS NVARCHAR(400)) AS Message, ISNULL(st.enforcement, c.default_enforcement) AS Enforcement,
           c.block_target AS BlockTarget, ISNULL(st.exception_allowed, 1) AS ExceptionAllowed, st.max_exception_days AS MaxExceptionDays,
           ex.exception_id AS ExceptionId, ex.expiry_date AS ExceptionExpiry,
           CASE WHEN ex.exception_id IS NULL THEN 0 ELSE 1 END AS IsExcepted, c.display_order AS DisplayOrder
      FROM grac_practice.fn_asset_privacy_values(@organization_id, @asset_id) v
     CROSS APPLY (SELECT CASE WHEN v.pd IN (N'YES', N'UNKNOWN') THEN 1 ELSE 0 END AS app,
                         CASE WHEN v.sreq = N'YES' OR v.dsreq = N'YES' THEN 1 ELSE 0 END AS san,
                         CASE WHEN v.spc = N'YES' OR v.chd = N'YES' OR v.hrp = N'YES' THEN 1 ELSE 0 END AS dpia_needed,
                         CAST(SYSUTCDATETIME() AS DATE) AS today) f
     OUTER APPLY grac_practice.fn_asset_privacy_retention_calc(@organization_id, v.AssetId, v.rper, v.rtrg, v.RegisteredDate, v.psc) rt
     CROSS APPLY (VALUES
        (N'LAW_APPLICABILITY', N'MISSING', CAST(N'DPDP / GDPR applicability is not recorded.' AS NVARCHAR(400)),
            CASE WHEN f.app = 1 AND (v.dpdp IS NULL OR v.gdpr IS NULL) THEN 1 ELSE 0 END),
        (N'LAW_APPLICABILITY', N'PARTIAL', N'DPDP / GDPR applicability is under assessment.',
            CASE WHEN f.app = 1 AND (v.dpdp = N'UNDER_ASSESSMENT' OR v.gdpr = N'UNDER_ASSESSMENT') THEN 1 ELSE 0 END),
        (N'ASSESSMENT', N'MISSING', N'The privacy owner or the privacy assessment is not recorded (or Not Assessed).',
            CASE WHEN f.app = 1 AND (v.powner IS NULL OR v.pas IS NULL OR v.pas = N'NOT_ASSESSED') THEN 1 ELSE 0 END),
        (N'ASSESSMENT', N'PARTIAL', N'The privacy assessment is pending or conditional.',
            CASE WHEN f.app = 1 AND v.pas IN (N'PENDING', N'CONDITIONAL') THEN 1 ELSE 0 END),
        (N'ASSESSMENT', N'FAILED', N'The privacy assessment found the asset non-compliant.',
            CASE WHEN f.app = 1 AND v.pas = N'NON_COMPLIANT' THEN 1 ELSE 0 END),
        (N'PROCESSING_DETAILS', N'MISSING',
            CONCAT(N'Not recorded: ', CONCAT_WS(N', ', CASE WHEN v.pdc IS NULL THEN N'personal data categories' END,
                                               CASE WHEN v.dsc IS NULL THEN N'data subject categories' END,
                                               CASE WHEN v.pops IS NULL THEN N'processing operations' END,
                                               CASE WHEN v.pact IS NULL THEN N'processing activity' END,
                                               CASE WHEN v.ppur IS NULL THEN N'processing purpose' END), N'.'),
            CASE WHEN f.app = 1 AND (v.pdc IS NULL OR v.dsc IS NULL OR v.pops IS NULL OR v.pact IS NULL OR v.ppur IS NULL) THEN 1 ELSE 0 END),
        (N'SPECIAL_DATA', N'MISSING', N'Special-category / health data or children data is not recorded.',
            CASE WHEN f.app = 1 AND (v.spc IS NULL OR v.chd IS NULL) THEN 1 ELSE 0 END),
        (N'SPECIAL_DATA', N'PARTIAL', N'Special-category / health data or children data is Unknown.',
            CASE WHEN f.app = 1 AND (v.spc = N'UNKNOWN' OR v.chd = N'UNKNOWN') THEN 1 ELSE 0 END),
        (N'SPECIAL_DATA', N'FAILED', N'Special-category, health or children data is processed but DPIA / PIA required is No.',
            CASE WHEN f.app = 1 AND (v.spc = N'YES' OR v.chd = N'YES') AND v.dreq = N'NO' THEN 1 ELSE 0 END),
        (N'DPIA', N'MISSING', N'High-risk processing or DPIA / PIA required is not recorded.',
            CASE WHEN f.app = 1 AND (v.hrp IS NULL OR v.dreq IS NULL) THEN 1 ELSE 0 END),
        (N'DPIA', N'FAILED', N'High-risk processing needs a DPIA / PIA but DPIA / PIA required is No.',
            CASE WHEN f.app = 1 AND v.hrp = N'YES' AND v.dreq = N'NO' THEN 1 ELSE 0 END),
        (N'DPIA', N'MISSING', N'The DPIA / PIA status is not recorded.',
            CASE WHEN f.app = 1 AND (v.dreq = N'YES' OR (f.dpia_needed = 1 AND v.dreq IS NULL)) AND v.dst IS NULL THEN 1 ELSE 0 END),
        (N'DPIA', N'PARTIAL', N'The DPIA / PIA is not started or in progress.',
            CASE WHEN f.app = 1 AND v.dreq = N'YES' AND v.dst IN (N'NOT_STARTED', N'IN_PROGRESS') THEN 1 ELSE 0 END),
        (N'DPIA', N'FAILED', N'The DPIA / PIA was rejected or has expired.',
            CASE WHEN f.app = 1 AND v.dreq = N'YES' AND v.dst IN (N'REJECTED', N'EXPIRED') THEN 1 ELSE 0 END),
        (N'MASKING', N'MISSING', N'Masking applicability is not recorded.',
            CASE WHEN f.app = 1 AND v.mapp IS NULL THEN 1 ELSE 0 END),
        (N'MASKING', N'PARTIAL', N'Masking applicability is under assessment.',
            CASE WHEN f.app = 1 AND v.mapp = N'UNDER_ASSESSMENT' THEN 1 ELSE 0 END),
        (N'MASKING', N'MISSING', N'Masking implementation, method or coverage is not recorded.',
            CASE WHEN f.app = 1 AND v.mapp = N'YES'
                      AND (v.mimp IS NULL OR (v.mimp IN (N'YES', N'PARTIALLY') AND (v.mmeth IS NULL OR v.mcov IS NULL))) THEN 1 ELSE 0 END),
        (N'MASKING', N'PARTIAL', N'Masking is partially implemented.',
            CASE WHEN f.app = 1 AND v.mapp = N'YES' AND v.mimp = N'PARTIALLY' THEN 1 ELSE 0 END),
        (N'MASKING', N'FAILED', N'Masking is applicable but not implemented.',
            CASE WHEN f.app = 1 AND v.mapp = N'YES' AND v.mimp = N'NO' THEN 1 ELSE 0 END),
        (N'ENCRYPTION', N'MISSING', N'The encryption requirement or its implementation is not recorded.',
            CASE WHEN f.app = 1 AND (v.ereq IS NULL OR (v.ereq = N'YES' AND v.eimp IS NULL)) THEN 1 ELSE 0 END),
        (N'ENCRYPTION', N'PARTIAL', N'Encryption is partially implemented.',
            CASE WHEN f.app = 1 AND v.ereq = N'YES' AND v.eimp = N'PARTIALLY' THEN 1 ELSE 0 END),
        (N'ENCRYPTION', N'FAILED', N'Encryption is required but not implemented.',
            CASE WHEN f.app = 1 AND v.ereq = N'YES' AND v.eimp = N'NO' THEN 1 ELSE 0 END),
        (N'RETENTION', N'MISSING',
            CONCAT(N'Not recorded: ', CONCAT_WS(N', ', CASE WHEN v.rpol IS NULL THEN N'retention policy' END,
                                               CASE WHEN v.rper IS NULL THEN N'retention period' END,
                                               CASE WHEN v.rtrg IS NULL THEN N'retention trigger' END,
                                               CASE WHEN v.lhold IS NULL THEN N'legal hold status' END), N'.'),
            CASE WHEN f.app = 1 AND (v.rpol IS NULL OR v.rper IS NULL OR v.rtrg IS NULL OR v.lhold IS NULL) THEN 1 ELSE 0 END),
        (N'RETENTION', N'FAILED', N'The retention period must be a positive number of days, weeks, months or years up to 100 years (for example 7 years).',
            CASE WHEN f.app = 1 AND rt.PeriodInvalid = 1 THEN 1 ELSE 0 END),
        (N'RETENTION', N'FAILED',
            CONCAT(N'Retention ended on ', CONVERT(NVARCHAR(10), rt.RetentionDueDate, 23),
                   N'; record the deletion, archival, legal-hold or extension decision (Asset Privacy, Reviews).'),
            CASE WHEN f.app = 1 AND rt.RetentionDueDate < f.today
                      AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_privacy_review r
                                       WHERE r.asset_id = v.AssetId AND r.review_kind = N'RETENTION' AND r.status = N'COMPLETED'
                                         AND r.due_date >= rt.RetentionDueDate) THEN 1 ELSE 0 END),
        (N'THIRD_PARTY', N'MISSING',
            CONCAT(N'Not recorded: ', CONCAT_WS(N', ', CASE WHEN v.tpa IS NULL THEN N'third-party access' END,
                                               CASE WHEN v.tpa = N'YES' AND v.proc_tp IS NULL THEN N'processor / third party' END,
                                               CASE WHEN v.tpa = N'YES' AND v.cbt IS NULL THEN N'cross-border transfer' END,
                                               CASE WHEN v.cbt = N'YES' AND v.tcty IS NULL THEN N'transfer countries' END), N'.'),
            CASE WHEN f.app = 1 AND (v.tpa IS NULL OR (v.tpa = N'YES' AND (v.proc_tp IS NULL OR v.cbt IS NULL))
                                      OR (v.cbt = N'YES' AND v.tcty IS NULL)) THEN 1 ELSE 0 END),
        (N'THIRD_PARTY', N'PARTIAL', N'Cross-border transfer is under assessment.',
            CASE WHEN f.app = 1 AND v.cbt = N'UNDER_ASSESSMENT' THEN 1 ELSE 0 END),
        (N'REVIEW', N'MISSING', N'The privacy review date is not recorded.',
            CASE WHEN f.app = 1 AND v.rdate IS NULL THEN 1 ELSE 0 END),
        (N'REVIEW', N'FAILED', CONCAT(N'The privacy review was due on ', CONVERT(NVARCHAR(10), v.rdate, 23), N'.'),
            CASE WHEN f.app = 1 AND v.rdate < f.today THEN 1 ELSE 0 END),
        (N'RESIDUAL_RISK', N'MISSING', N'Residual privacy risk is not recorded after the assessment.',
            CASE WHEN f.app = 1 AND v.pas IN (N'APPROVED', N'CONDITIONAL') AND v.rrisk IS NULL THEN 1 ELSE 0 END),
        (N'SANITIZATION', N'MISSING', N'Deletion / sanitization required is not recorded.',
            CASE WHEN f.app = 1 AND v.dsreq IS NULL THEN 1 ELSE 0 END),
        (N'SANITIZATION', N'MISSING',
            CONCAT(N'Sanitization is required; not recorded: ', CONCAT_WS(N', ', CASE WHEN v.smeth IS NULL THEN N'sanitization method' END,
                                                                         CASE WHEN v.sdate IS NULL THEN N'sanitization date' END,
                                                                         CASE WHEN v.sev IS NULL THEN N'sanitization evidence' END), N'.'),
            CASE WHEN f.san = 1 AND (v.smeth IS NULL OR v.sdate IS NULL OR v.sev IS NULL)
                      AND ISNULL(v.StatusCode, N'') IN (N'PENDING_DECOMMISSION', N'SANITIZATION_PENDING', N'DISPOSAL_APPROVAL',
                                                        N'DISPOSED', N'ARCHIVED') THEN 1 ELSE 0 END)
     ) g(code, kind, msg, hit)
      JOIN grac_practice.asset_privacy_requirement c ON c.requirement_code = g.code
     OUTER APPLY (SELECT TOP (1) s.enforcement, s.exception_allowed, s.max_exception_days
                    FROM grac_practice.asset_privacy_setting s
                   WHERE s.organization_id = @organization_id AND s.requirement_code = g.code
                     AND (s.asset_type_id = v.AssetTypeId OR s.asset_type_id IS NULL)
                   ORDER BY CASE WHEN s.asset_type_id IS NULL THEN 1 ELSE 0 END) st
     OUTER APPLY (SELECT TOP (1) x.exception_id, x.expiry_date
                    FROM grac_practice.asset_privacy_exception x
                   WHERE x.asset_id = v.AssetId AND x.requirement_code = g.code AND x.status = N'APPROVED'
                     AND x.expiry_date >= f.today) ex
     WHERE g.hit = 1 AND ISNULL(st.enforcement, c.default_enforcement) <> N'OFF';
GO

-- Privacy status per asset (5.1.16: never Compliant while a required
-- control is incomplete).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_privacy_status (@organization_id BIGINT, @asset_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT v.AssetId, v.AssetName, v.AssetTypeId, v.StatusCode, v.OwnerId,
           CASE WHEN v.pd IN (N'YES', N'UNKNOWN') THEN N'APPLICABLE' WHEN v.pd = N'NO' THEN N'NOT_APPLICABLE' ELSE N'UNDETERMINED' END AS Applicability,
           v.pd AS PersonalDataProcessed, TRY_CONVERT(BIGINT, v.powner) AS PrivacyOwnerId, v.pas AS AssessmentStatus,
           v.rdate AS PrivacyReviewDate, rt.RetentionDueDate, v.lhold AS LegalHold,
           ISNULL(g.Failed, 0) AS Failed, ISNULL(g.Missing, 0) AS Missing, ISNULL(g.Partial, 0) AS Partial,
           ISNULL(g.Excepted, 0) AS Excepted, ISNULL(g.Blocking, 0) AS Blocking,
           CASE WHEN v.pd = N'NO' THEN N'NOT_APPLICABLE'
                WHEN v.pd IS NULL THEN N'UNDETERMINED'
                WHEN ISNULL(g.Failed, 0) > 0 THEN N'NON_COMPLIANT'
                WHEN ISNULL(g.Missing, 0) > 0 THEN N'INCOMPLETE'
                WHEN ISNULL(g.Partial, 0) > 0 OR ISNULL(g.Excepted, 0) > 0 THEN N'CONDITIONAL'
                ELSE N'COMPLIANT' END AS PrivacyStatus
      FROM grac_practice.fn_asset_privacy_values(@organization_id, @asset_id) v
     OUTER APPLY grac_practice.fn_asset_privacy_retention_calc(@organization_id, v.AssetId, v.rper, v.rtrg, v.RegisteredDate, v.psc) rt
     OUTER APPLY (SELECT SUM(CASE WHEN x.IsExcepted = 0 AND x.GapKind = N'FAILED' THEN 1 ELSE 0 END) AS Failed,
                         SUM(CASE WHEN x.IsExcepted = 0 AND x.GapKind = N'MISSING' THEN 1 ELSE 0 END) AS Missing,
                         SUM(CASE WHEN x.IsExcepted = 0 AND x.GapKind = N'PARTIAL' THEN 1 ELSE 0 END) AS Partial,
                         SUM(CASE WHEN x.IsExcepted = 1 THEN 1 ELSE 0 END) AS Excepted,
                         SUM(CASE WHEN x.IsExcepted = 0 AND x.Enforcement = N'BLOCK' THEN 1 ELSE 0 END) AS Blocking
                    FROM grac_practice.fn_asset_privacy_gaps(@organization_id, v.AssetId) x) g;
GO
PRINT '448: privacy values, retention, gaps and status functions created.';
GO

