CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_config_get
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54650, 'Organization not found.', 1;
    SELECT t.template_code AS TemplateCode, t.template_name AS TemplateName, t.activity_kind AS ActivityKind, t.description AS Description,
           t.required_field_key AS RequiredFieldKey, t.frequency_field_key AS FrequencyFieldKey, t.basis_field_key AS BasisFieldKey,
           t.last_date_field_key AS LastDateFieldKey, t.expiry_field_key AS ExpiryFieldKey, t.owner_field_key AS OwnerFieldKey,
           t.coverage_types AS CoverageTypes, t.notification_activity_code AS NotificationActivityCode, na.activity_name AS NotificationActivityName,
           st.IsActive, st.LeadDays, st.DueSoonDays, st.GroupingMode, st.CampaignOwnerEmployeeId, ow.employee_name AS CampaignOwnerName,
           t.default_lead_days AS DefaultLeadDays, t.default_due_soon_days AS DefaultDueSoonDays,
           CASE WHEN s.organization_id IS NULL THEN 0 ELSE 1 END AS IsCustomized,
           -- 439: results, dispositions, restricted use
           st.ResultRequired, st.ResultReviewRequired, st.DispositionApprovalRequired, st.RestrictOnOverdue, st.RestrictOnFail,
           st.RetestDays, t.certificate_number_field_key AS CertificateNumberFieldKey,
           t.certificate_expiry_field_key AS CertificateExpiryFieldKey,
           t.default_result_review AS DefaultResultReview, t.default_disposition_approval AS DefaultDispositionApproval,
           ISNULL(t.default_restrict_on_overdue, N'NONE') AS DefaultRestrictOnOverdue, t.default_restrict_on_fail AS DefaultRestrictOnFail
      FROM grac_practice.asset_activity_template t
      JOIN grac_practice.fn_asset_activity_settings(@organization_id) st ON st.TemplateCode = t.template_code
      JOIN grac_practice.asset_notification_activity na ON na.activity_code = t.notification_activity_code
      LEFT JOIN grac_practice.asset_activity_setting s ON s.organization_id = @organization_id AND s.template_code = t.template_code
      LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = st.CampaignOwnerEmployeeId
     ORDER BY t.display_order;
    SELECT employee_id AS EmployeeId, employee_name AS EmployeeName
      FROM grac_practice.organization_employee
     WHERE organization_id = @organization_id AND status = N'Active'
     ORDER BY employee_name;
    -- 439: 3. the evidence date fields (evidence expiry notifications and reviews).
    SELECT ef.field_key AS FieldKey, ef.evidence_name AS EvidenceName, fd.display_label AS FieldLabel,
           ef.owner_field_key AS OwnerFieldKey, ef.restrict_on_expiry AS RestrictOnExpiry, ef.is_active AS IsActive
      FROM grac_practice.asset_evidence_field ef
      LEFT JOIN grac_practice.asset_field_definition fd ON fd.field_key = ef.field_key
     ORDER BY ef.display_order;
END
GO
