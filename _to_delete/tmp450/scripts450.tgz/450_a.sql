-- =====================================================================
-- 450  Asset governance KPIs -- formula definitions, organization
--      thresholds and weights, scored snapshots with record-level
--      drill-down, governance score, Asset Governance screen
--      (Asset & Contract Management, Phase 8 increment 4a)
--
-- REQUEST
-- -------
--   BRD v1.7 19.8 (Governance KPI formula definitions: Attestation
--   Compliance, Metadata Completeness, Ownership Completeness,
--   Relationship Completeness, Coverage Compliance, Technology Support
--   Compliance, Exception Health, Discovery Freshness, Reconciliation
--   Backlog Rate, Connector Availability; "every KPI definition includes
--   population / as-of logic, exclusions, zero-denominator behaviour,
--   rounding, thresholds and authorization"; "every score drills down to
--   exact numerator, denominator, excluded and failing records"; "late-
--   arriving data creates a new snapshot and preserves the prior
--   result"), 13.5 Governance dashboard ("overall score, component
--   scores, trends, threshold breaches and exact numerator / denominator
--   drill-down"), 19.10 Governance KPI Detail report ("formula,
--   population, numerator, denominator, exclusions and failures").
--   Plan: docs/asset-contract-management.md (Phase 8.4a, D167-D182).
--
-- WHAT THIS DOES
-- --------------
--   1. asset_governance_kpi -- the 10 KPIs with their formula, numerator,
--      denominator, population, as-of, exclusion, zero-denominator,
--      rounding and authorization text, direction (higher / lower is
--      better), default target / warning thresholds, weight and period.
--   2. asset_governance_setting (per organization and KPI: enabled,
--      weight, target, warning, period) and asset_governance_org_setting
--      (overall target / warning, record-detail retention).
--   3. asset_governance_relationship_rule -- which relationships an asset
--      type requires (type, side, minimum); business services use the 441
--      minimum supporting relationships.
--   4. fn_asset_governance_assets / fn_asset_governance_items: one row per
--      record of each KPI -- PASS, FAIL or EXCLUDED, its numerator and
--      denominator contribution and the reason -- computed from the
--      records the modules already keep (431, 421 / 428, 435, 430, 432,
--      439, 447, 448, 440 / 441, 442).
--   5. asset_governance_snapshot / _snapshot_kpi / _snapshot_item and
--      sp_asset_governance_snapshot_take: a snapshot stores every KPI row
--      and every record row; a later snapshot of the same date whose
--      results differ supersedes it (the prior one is kept); an unchanged
--      result creates nothing. Daily by the scheduler, on demand by EDIT.
--   6. Readers: sp_asset_governance_get (scorecard, trend),
--      _items (drill-down), _snapshots (history), _settings; writers
--      _setting_save, _org_setting_save, _relationship_rule_save.
--   7. sp_asset_scheduler_run (448 body) re-issued: one snapshot per
--      organization per day after the notification sweep.
--   8. Menu Asset & Contract -> Asset Governance (365; also in 274).
--
-- NOT DONE HERE: the Asset & Contract module dashboards (13.1 / 13.2 /
--   13.3 / 13.5 / 19.10 widgets -- Phase 8.4b); notifications on
--   threshold breaches; KPIs for business-service coverage (no service
--   coverage requirement exists); recomputing a past date (records keep
--   their current state, so a snapshot is always "as of when taken").
--
-- ERROR NUMBERS: 53080-53099
--   53080 organization not found        53081 unknown KPI
--   53082 threshold / weight / period invalid
--   53083 snapshot not found            53084 asset type not found
--   53085 relationship type not found or not for assets
--   53086 relationship rule not found   53087 side / minimum invalid
--   53088 a rule for this type, relationship and side exists
--   53089 retention / overall threshold invalid
--
-- ALSO EDITED: API (AssetConfig service / controller / models), Web
--   proxy (asset-governance area), PracticeScreen + Manage.cshtml +
--   appsettings (new screen), new asset-governance.cshtml / .js, 274
--   (menu), docs.
-- DEPENDS ON: 428, 430, 431, 432, 435, 439, 440, 441, 442, 447, 448.
-- Rollback: 450_asset_governance_kpis_rollback.sql (restores the 448
--   scheduler body, drops the 450 objects and the menu row).
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.sp_asset_privacy_sync','P') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_privacy_gaps') IS NULL
   OR OBJECT_ID('grac_practice.asset_privacy_exception','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_consistency_finding','U') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_form_evaluate') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_stored_values') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_technology_status') IS NULL
   OR OBJECT_ID('grac_practice.asset_technology_exception','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_attestation','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_verification_exception','U') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_coverage_gaps') IS NULL
   OR OBJECT_ID('grac_practice.asset_coverage_requirement','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_activity_disposition','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_relationship','U') IS NULL
   OR OBJECT_ID('grac_practice.business_service_setting','U') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_discovery_confidence') IS NULL
   OR OBJECT_ID('grac_practice.asset_reconciliation_exception','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_discovery_batch','U') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_scheduler_run','P') IS NULL
   OR OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) NOT LIKE '%sp_asset_privacy_sync%'
   OR COL_LENGTH('grac_practice.asset_consistency_finding', 'reopened_count') IS NULL
   OR COL_LENGTH('grac_practice.organization_dependency_asset', 'template_id') IS NULL
BEGIN
    RAISERROR('ABORT (450): run 428-448 first (450 re-issues the 448 scheduler body).', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. KPI catalogue (global) -- BRD 19.8
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_governance_kpi','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_governance_kpi (
        kpi_code            NVARCHAR(30)   NOT NULL CONSTRAINT pk_pm_agov_kpi PRIMARY KEY,
        kpi_name            NVARCHAR(120)  NOT NULL,
        formula_text        NVARCHAR(400)  NOT NULL,
        numerator_text      NVARCHAR(600)  NOT NULL,
        denominator_text    NVARCHAR(600)  NOT NULL,
        population_text     NVARCHAR(1000) NOT NULL,
        exclusions_text     NVARCHAR(1000) NOT NULL,
        as_of_text          NVARCHAR(600)  NOT NULL,
        record_label        NVARCHAR(40)   NOT NULL,     -- what one drill-down row is
        direction           NVARCHAR(6)    NOT NULL
            CONSTRAINT ck_pm_agov_kpi_dir CHECK (direction IN (N'HIGHER', N'LOWER')),
        default_target      DECIMAL(5, 1)  NOT NULL,
        default_warning     DECIMAL(5, 1)  NOT NULL,
        default_weight      INT            NOT NULL,
        default_period_days INT            NULL,         -- NULL: the KPI has no period
        brd_reference       NVARCHAR(60)   NOT NULL,
        display_order       INT            NOT NULL,
        entered_by          NVARCHAR(100)  NOT NULL CONSTRAINT df_pm_agov_kpi_eby DEFAULT N'system',
        entered_dt          DATETIME2      NOT NULL CONSTRAINT df_pm_agov_kpi_edt DEFAULT SYSUTCDATETIME()
    );
    PRINT '450: asset_governance_kpi created.';
END
GO

MERGE grac_practice.asset_governance_kpi AS t
USING (VALUES
    (N'ATTESTATION_COMPLIANCE', N'Attestation Compliance',
     N'Confirmed or approved-closed occurrences due in period / required occurrences due in period x 100',
     N'Attestation occurrences due in the period that are Confirmed (awaiting manager approval), Closed (verified) or Resolved (a dispute resolved and closed).',
     N'Attestation occurrences due in the period, except cancelled ones.',
     N'Every attestation occurrence (initial, periodic, transfer, return, event, campaign) of the organization whose due date falls in the period.',
     N'Cancelled occurrences.',
     N'Period = the last N days up to the snapshot date (due date between snapshot date - N + 1 and the snapshot date); status as at the snapshot.',
     N'Attestation occurrence', N'HIGHER', 95.0, 85.0, 10, 90, N'19.8, 5.3, 13.1', 10),
    (N'METADATA_COMPLETENESS', N'Metadata Completeness',
     N'Completed applicable mandatory fields / applicable mandatory fields x 100',
     N'Mandatory fields of each asset that hold a value.',
     N'Fields mandatory for each asset on its asset form -- marked mandatory, or made mandatory by a form rule, and visible -- evaluated on the stored values (the same engine as the asset form save).',
     N'Assets in use (registered, not Draft, not Disposed / Archived, record active) that have an asset form.',
     N'Assets not in use; assets created before asset types (no form); assets whose form makes no field mandatory.',
     N'Stored values as at the snapshot.',
     N'Asset (fields)', N'HIGHER', 95.0, 85.0, 10, NULL, N'19.8, 5.1, 5.2', 20),
    (N'OWNERSHIP_COMPLETENESS', N'Ownership Completeness',
     N'Assets with valid required owner / custodian / applicable active assets x 100',
     N'Assets whose asset owner is an active employee of the organization and whose custodian, when recorded or required, is an active employee or team.',
     N'Assets in use.',
     N'Assets in use (registered, not Draft, not Disposed / Archived, record active).',
     N'Assets not in use. The custodian is required when the asset form marks it mandatory.',
     N'Owner, custodian and employee / team status as at the snapshot.',
     N'Asset', N'HIGHER', 98.0, 90.0, 10, NULL, N'19.8, 5.3.1', 30),
    (N'RELATIONSHIP_COMPLETENESS', N'Relationship Completeness',
     N'In-scope records with required active relationships / records requiring relationships x 100',
     N'Records with at least the required number of Active, currently effective relationships of each required kind.',
     N'Assets whose asset type has a relationship requirement (Settings) and business services in operation (Active, Degraded) when the minimum supporting relationships is above 0.',
     N'Assets in use of an asset type with an active relationship requirement; business services in operation.',
     N'Assets of those types that are not in use; services in Draft, Design, Suspended, Retiring or Retired.',
     N'Relationships Active and effective on the snapshot date (effective from on or before, effective to empty or on / after).',
     N'Asset or business service', N'HIGHER', 90.0, 75.0, 10, NULL, N'19.8, 5.4, 5.5', 40),
    (N'COVERAGE_COMPLIANCE', N'Coverage Compliance',
     N'Assets with valid required coverage / assets requiring coverage x 100',
     N'Assets with a Covered or Expiring line of every coverage type their asset type requires, at least the minimum period long.',
     N'Assets whose asset type has a Required coverage requirement (435).',
     N'Assets in use of an asset type with a Required coverage requirement.',
     N'Assets of those types that are not in use. Business services have no coverage requirement in this application and are not counted.',
     N'Coverage line status (Covered, Expiring, Suspended, Excluded, Expired) on the snapshot date.',
     N'Asset', N'HIGHER', 95.0, 85.0, 10, NULL, N'19.8, 5.2.14, 7.4', 50),
    (N'TECHNOLOGY_SUPPORT', N'Technology Support Compliance',
     N'Supported approved technology or valid exception / technology-applicable assets x 100',
     N'Assets whose firmware and operating system are Current, Due Soon or covered by an approved, unexpired technology exception.',
     N'Assets with at least one technology that applies (the form has the firmware or operating-system field, or a version is recorded).',
     N'Assets in use with an applicable firmware or operating system.',
     N'Assets not in use; assets where neither technology applies. Unknown (no version recorded) and Unsupported fail.',
     N'Release status, compatibility and exceptions on the snapshot date (430 classification).',
     N'Asset', N'HIGHER', 95.0, 85.0, 10, NULL, N'19.8, 4.7, 13.2', 60),
    (N'EXCEPTION_HEALTH', N'Exception Health',
     N'Applicable assets without overdue / expired exceptions / applicable assets x 100',
     N'Assets with no overdue or expired exception.',
     N'Assets in use.',
     N'Assets in use. Failing: an expired technology exception the asset still relies on (still unsupported) or one past its review date; a verification exception past its resolution due date; an activity exception past its review date; a consistency acceptance past its review date or reopened by it; a privacy exception past its expiry, or expired while the gap is still open and not covered again.',
     N'Assets not in use.',
     N'Exception status and dates on the snapshot date.',
     N'Asset', N'HIGHER', 98.0, 90.0, 10, NULL, N'19.8, 4.7, 5.3.7, 7.1.5, 19.7, 5.2.15', 70),
    (N'DISCOVERY_FRESHNESS', N'Discovery Freshness',
     N'Discoverable assets observed within threshold / discoverable active assets x 100',
     N'Discoverable assets with at least one source link observed within that source expected interval x the stale multiplier (discovery settings).',
     N'Assets linked to at least one discovery source.',
     N'Assets in use linked to a discovery source (5.6.4).',
     N'Assets not in use.',
     N'Last observation of each link at the snapshot time (same freshness rule as Data confidence).',
     N'Asset', N'HIGHER', 90.0, 75.0, 10, NULL, N'19.8, 5.6.4', 80),
    (N'RECONCILIATION_BACKLOG', N'Reconciliation Backlog Rate',
     N'Open reconciliation exceptions / observations requiring reconciliation x 100',
     N'Reconciliation exceptions still Open.',
     N'Reconciliation exceptions raised in the period plus those raised earlier and still Open (each exception stands for the observations that required reconciliation; a repeat observation is counted on the same exception).',
     N'Reconciliation exceptions (suggested match, manual review, new candidate, duplicate, conflict) of the organization.',
     N'Exceptions resolved before the period.',
     N'Period = the last N days up to the snapshot time (raised on or after); status at the snapshot. Lower is better.',
     N'Reconciliation exception', N'LOWER', 5.0, 15.0, 10, 30, N'19.8, 5.6.3', 90),
    (N'CONNECTOR_AVAILABILITY', N'Connector Availability',
     N'Successful scheduled runs / scheduled runs x 100',
     N'Expected run intervals of each active source in the period that received a Completed batch.',
     N'Expected run intervals of each active source in the period -- the period (or the time since the source was added, if shorter) divided into whole intervals of the source expected interval.',
     N'Active discovery sources of the organization.',
     N'Inactive sources; sources added less than one expected interval ago. Partial, failed and running batches are not successful runs.',
     N'Period = the last N days up to the snapshot time.',
     N'Discovery source (runs)', N'HIGHER', 98.0, 90.0, 10, 30, N'19.8, 5.6.1, 13.5', 100)
) AS s(kpi_code, kpi_name, formula_text, numerator_text, denominator_text, population_text, exclusions_text, as_of_text,
       record_label, direction, default_target, default_warning, default_weight, default_period_days, brd_reference, display_order)
ON t.kpi_code = s.kpi_code
WHEN MATCHED THEN UPDATE SET
    kpi_name = s.kpi_name, formula_text = s.formula_text, numerator_text = s.numerator_text, denominator_text = s.denominator_text,
    population_text = s.population_text, exclusions_text = s.exclusions_text, as_of_text = s.as_of_text, record_label = s.record_label,
    direction = s.direction, default_target = s.default_target, default_warning = s.default_warning, default_weight = s.default_weight,
    default_period_days = s.default_period_days, brd_reference = s.brd_reference, display_order = s.display_order
WHEN NOT MATCHED BY TARGET THEN
    INSERT (kpi_code, kpi_name, formula_text, numerator_text, denominator_text, population_text, exclusions_text, as_of_text,
            record_label, direction, default_target, default_warning, default_weight, default_period_days, brd_reference,
            display_order, entered_by)
    VALUES (s.kpi_code, s.kpi_name, s.formula_text, s.numerator_text, s.denominator_text, s.population_text, s.exclusions_text,
            s.as_of_text, s.record_label, s.direction, s.default_target, s.default_warning, s.default_weight,
            s.default_period_days, s.brd_reference, s.display_order, N'seed-450');
PRINT CONCAT('450: KPI catalogue rows merged: ', @@ROWCOUNT);
GO

-- =====================================================================
-- 2. Organization settings
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_governance_setting','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_governance_setting (
        organization_id BIGINT        NOT NULL
            CONSTRAINT fk_pm_agov_set_org REFERENCES grac_practice.organization(organization_id),
        kpi_code        NVARCHAR(30)  NOT NULL
            CONSTRAINT fk_pm_agov_set_kpi REFERENCES grac_practice.asset_governance_kpi(kpi_code),
        is_enabled      BIT           NOT NULL,
        weight          INT           NOT NULL CONSTRAINT ck_pm_agov_set_w CHECK (weight BETWEEN 0 AND 100),
        target_value    DECIMAL(5, 1) NOT NULL CONSTRAINT ck_pm_agov_set_t CHECK (target_value BETWEEN 0 AND 100),
        warning_value   DECIMAL(5, 1) NOT NULL CONSTRAINT ck_pm_agov_set_wv CHECK (warning_value BETWEEN 0 AND 100),
        period_days     INT           NULL CONSTRAINT ck_pm_agov_set_p CHECK (period_days IS NULL OR period_days BETWEEN 1 AND 3650),
        entered_by      NVARCHAR(100) NOT NULL,
        entered_dt      DATETIME2     NOT NULL CONSTRAINT df_pm_agov_set_edt DEFAULT SYSUTCDATETIME(),
        updated_by      NVARCHAR(100) NULL,
        updated_dt      DATETIME2     NULL,
        CONSTRAINT pk_pm_agov_set PRIMARY KEY (organization_id, kpi_code)
    );
    PRINT '450: asset_governance_setting created.';
END
GO

IF OBJECT_ID('grac_practice.asset_governance_org_setting','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_governance_org_setting (
        organization_id       BIGINT        NOT NULL CONSTRAINT pk_pm_agov_org PRIMARY KEY
            CONSTRAINT fk_pm_agov_org_org REFERENCES grac_practice.organization(organization_id),
        overall_target        DECIMAL(5, 1) NOT NULL CONSTRAINT ck_pm_agov_org_t CHECK (overall_target BETWEEN 0 AND 100),
        overall_warning       DECIMAL(5, 1) NOT NULL CONSTRAINT ck_pm_agov_org_w CHECK (overall_warning BETWEEN 0 AND 100),
        item_retention_days   INT           NOT NULL CONSTRAINT ck_pm_agov_org_ret CHECK (item_retention_days BETWEEN 7 AND 3650),
        entered_by            NVARCHAR(100) NOT NULL,
        entered_dt            DATETIME2     NOT NULL CONSTRAINT df_pm_agov_org_edt DEFAULT SYSUTCDATETIME(),
        updated_by            NVARCHAR(100) NULL,
        updated_dt            DATETIME2     NULL,
        CONSTRAINT ck_pm_agov_org_tw CHECK (overall_warning <= overall_target)
    );
    PRINT '450: asset_governance_org_setting created.';
END
GO

-- Relationships an asset type requires (Relationship Completeness).
IF OBJECT_ID('grac_practice.asset_governance_relationship_rule','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_governance_relationship_rule (
        rule_id                BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_agov_rel PRIMARY KEY,
        organization_id        BIGINT        NOT NULL
            CONSTRAINT fk_pm_agov_rel_org REFERENCES grac_practice.organization(organization_id),
        asset_type_id          INT           NOT NULL
            CONSTRAINT fk_pm_agov_rel_type REFERENCES grac_practice.dependency_asset_type_master(asset_type_id),
        relationship_type_code NVARCHAR(30)  NOT NULL
            CONSTRAINT fk_pm_agov_rel_rtype REFERENCES grac_practice.asset_relationship_type(type_code),
        asset_side             NVARCHAR(6)   NOT NULL     -- the asset is the SOURCE or the TARGET of the relationship
            CONSTRAINT ck_pm_agov_rel_side CHECK (asset_side IN (N'SOURCE', N'TARGET')),
        min_count              INT           NOT NULL CONSTRAINT ck_pm_agov_rel_min CHECK (min_count BETWEEN 1 AND 50),
        is_active              BIT           NOT NULL,
        entered_by             NVARCHAR(100) NOT NULL,
        entered_dt             DATETIME2     NOT NULL CONSTRAINT df_pm_agov_rel_edt DEFAULT SYSUTCDATETIME(),
        updated_by             NVARCHAR(100) NULL,
        updated_dt             DATETIME2     NULL,
        CONSTRAINT uq_pm_agov_rel UNIQUE (organization_id, asset_type_id, relationship_type_code, asset_side)
    );
    PRINT '450: asset_governance_relationship_rule created.';
END
GO

-- =====================================================================
-- 3. Snapshots (append-only; a superseded snapshot is kept)
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_governance_snapshot','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_governance_snapshot (
        snapshot_id     BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_agov_snap PRIMARY KEY,
        organization_id BIGINT        NOT NULL
            CONSTRAINT fk_pm_agov_snap_org REFERENCES grac_practice.organization(organization_id),
        as_of_date      DATE          NOT NULL,
        version_no      INT           NOT NULL,      -- 1, 2, ... per organization and date
        is_current      BIT           NOT NULL,
        source_code     NVARCHAR(10)  NOT NULL
            CONSTRAINT ck_pm_agov_snap_src CHECK (source_code IN (N'SCHEDULER', N'MANUAL')),
        overall_score   DECIMAL(5, 1) NULL,
        overall_rag     NVARCHAR(6)   NOT NULL
            CONSTRAINT ck_pm_agov_snap_rag CHECK (overall_rag IN (N'GREEN', N'AMBER', N'RED', N'NA')),
        overall_target  DECIMAL(5, 1) NOT NULL,
        overall_warning DECIMAL(5, 1) NOT NULL,
        item_count      INT           NOT NULL,
        items_purged    BIT           NOT NULL CONSTRAINT df_pm_agov_snap_purged DEFAULT 0,
        taken_by        NVARCHAR(100) NOT NULL,
        taken_dt        DATETIME2     NOT NULL CONSTRAINT df_pm_agov_snap_tdt DEFAULT SYSUTCDATETIME(),
        superseded_dt   DATETIME2     NULL,
        CONSTRAINT uq_pm_agov_snap_ver UNIQUE (organization_id, as_of_date, version_no)
    );
    CREATE UNIQUE INDEX ux_pm_agov_snap_current ON grac_practice.asset_governance_snapshot(organization_id, as_of_date) WHERE is_current = 1;
    PRINT '450: asset_governance_snapshot created.';
END
GO

IF OBJECT_ID('grac_practice.asset_governance_snapshot_kpi','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_governance_snapshot_kpi (
        snapshot_id    BIGINT        NOT NULL
            CONSTRAINT fk_pm_agov_skpi_snap REFERENCES grac_practice.asset_governance_snapshot(snapshot_id),
        kpi_code       NVARCHAR(30)  NOT NULL,
        is_enabled     BIT           NOT NULL,
        numerator      INT           NOT NULL,
        denominator    INT           NOT NULL,
        excluded_count INT           NOT NULL,
        failing_count  INT           NOT NULL,
        score          DECIMAL(5, 1) NULL,          -- NULL: zero denominator (not applicable) or disabled
        rag            NVARCHAR(6)   NOT NULL
            CONSTRAINT ck_pm_agov_skpi_rag CHECK (rag IN (N'GREEN', N'AMBER', N'RED', N'NA')),
        direction      NVARCHAR(6)   NOT NULL,
        target_value   DECIMAL(5, 1) NOT NULL,
        warning_value  DECIMAL(5, 1) NOT NULL,
        weight         INT           NOT NULL,
        period_days    INT           NULL,
        CONSTRAINT pk_pm_agov_skpi PRIMARY KEY (snapshot_id, kpi_code)
    );
    PRINT '450: asset_governance_snapshot_kpi created.';
END
GO

IF OBJECT_ID('grac_practice.asset_governance_snapshot_item','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_governance_snapshot_item (
        snapshot_id BIGINT         NOT NULL
            CONSTRAINT fk_pm_agov_sitem_snap REFERENCES grac_practice.asset_governance_snapshot(snapshot_id),
        kpi_code    NVARCHAR(30)   NOT NULL,
        record_kind NVARCHAR(16)   NOT NULL,
        record_id   BIGINT         NOT NULL,
        record_name NVARCHAR(400)  NULL,
        outcome     NVARCHAR(8)    NOT NULL
            CONSTRAINT ck_pm_agov_sitem_out CHECK (outcome IN (N'PASS', N'FAIL', N'EXCLUDED')),
        numerator   INT            NOT NULL,
        denominator INT            NOT NULL,
        reason      NVARCHAR(1000) NULL,
        CONSTRAINT pk_pm_agov_sitem PRIMARY KEY (snapshot_id, kpi_code, record_kind, record_id)
    );
    CREATE INDEX ix_pm_agov_sitem_out ON grac_practice.asset_governance_snapshot_item(snapshot_id, kpi_code, outcome);
    PRINT '450: asset_governance_snapshot_item created.';
END
GO
