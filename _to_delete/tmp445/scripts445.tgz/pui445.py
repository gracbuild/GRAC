# 445: Asset Discovery screen -- Splits tab and split window; event actions shared with merges.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    open(path, 'w', encoding='utf-8', newline='').write(s)
V = "src/PracticeManagement.Web/Views/Practice/Partials/asset-discovery.cshtml"
J = "src/PracticeManagement.Web/wwwroot/js/AssetConfig/asset-discovery.js"

edit(V, [
("""    duplicate in the queue opens a merge of its two assets.
""",
"""    duplicate in the queue opens a merge of its two assets.
    445: "Splits" -- a source and its resulting records (new Draft assets),
    allocation of the source items and field values, impact, blockers,
    approval, execution and recovery (5.6.3 Split, 19.4).
"""),
("""            <button role="tab" data-adc-main="MERGES" aria-selected="false">Merges</button>
""",
"""            <button role="tab" data-adc-main="MERGES" aria-selected="false">Merges</button>
            <button role="tab" data-adc-main="SPLITS" aria-selected="false">Splits</button>
"""),
("""        @* ---------------- settings ---------------- *@
""",
"""        @* ---------------- splits (445) ---------------- *@
        <div class="pm-tab-panel" data-adc-mainpanel="SPLITS" hidden>
            <div class="pm-toolbar">
                <select id="adcSpStatus" title="Status">
                    <option value="">Open</option><option value="EXECUTED">Executed</option><option value="RECOVERED">Recovered</option>
                    <option value="REJECTED">Rejected</option><option value="CANCELLED">Cancelled</option><option value="ALL">All</option>
                </select>
                <input type="search" id="adcSpSearch" placeholder="Search asset" maxlength="200" />
                @if (adcCanEdit)
                {
                    <button class="pm-button primary" id="adcSpNew" type="button"><i class="fa-solid fa-code-branch"></i> New split</button>
                }
            </div>
            <p class="adc-note">A split keeps the source and its ID; the resulting records are new Draft assets registered on the Asset Register form first. Allocate the source items (relationships, source records, open items, coverage, risk and practice mappings) and field values to them; what is not allocated stays with the source, history stays with the source. Approval by another person (two for critical CIs); execution can be recovered (BRD 5.6.3, 19.4).</p>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Split</th><th>Source</th><th>Resulting records</th><th>Status</th><th>Approvals</th><th>Requested</th></tr></thead>
                    <tbody id="adcSpBody"></tbody>
                </table>
            </div>
            <div id="adcSpPager"></div>
        </div>

        @* ---------------- settings ---------------- *@
"""),
("""@* ======================= Stale review window (443) ======================= *@
""",
"""@* ======================= Split window (445) ======================= *@
<div class="pm-modal" id="adcSplitModal" hidden>
    <div class="pm-modal-panel pm-modal-wide">
        <header>
            <h2 id="adcSpTitle">Split</h2>
            <button class="pm-modal-close" type="button" data-close-adc="adcSplitModal" aria-label="Close">&times;</button>
        </header>
        <div class="adc-info" id="adcSpInfo"></div>
        <p class="pm-message" id="adcSpMessage" role="status" aria-live="polite" hidden></p>

        <form id="adcSpForm" class="pm-form-grid">
            <label><span>Find source</span><input type="search" id="adcSpSrcSearch" maxlength="200" /></label>
            <label><span>Source (keeps its ID) *</span><select id="adcSpSrc"><option value="">--</option></select></label>
            <label><span>Find resulting record (Draft)</span><input type="search" id="adcSpResSearch" maxlength="200" /></label>
            <label><span>Resulting record</span><select id="adcSpResSel"><option value="">--</option></select></label>
            <div class="full">
                <button class="pm-button" type="button" id="adcSpResAdd"><i class="fa-solid fa-plus"></i> Add resulting record</button>
                <button class="pm-button" type="button" id="adcSpRegister"><i class="fa-solid fa-up-right-from-square"></i> Register a new asset</button>
                <div class="pm-table-wrap">
                    <table>
                        <thead><tr><th>Resulting records (new Draft assets)</th><th></th></tr></thead>
                        <tbody id="adcSpResBody"></tbody>
                    </table>
                </div>
            </div>
            <label class="full"><span>Reason *</span><textarea id="adcSpReason" rows="2" maxlength="1000"></textarea></label>
            <footer class="pm-modal-footer full">
                <button type="submit" class="pm-button primary"><i class="fa-solid fa-floppy-disk"></i> Save draft</button>
            </footer>
        </form>

        <div id="adcSpActionWrap" hidden>
            <label class="full"><span>Note (required to reject, cancel or recover)</span><textarea id="adcSpNote" rows="2" maxlength="1000"></textarea></label>
            <div class="pm-modal-footer" id="adcSpActions"></div>
        </div>

        <div id="adcSpDetail" hidden>
            <h3 class="adc-sub">Blockers</h3>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Open item</th></tr></thead>
                    <tbody id="adcSpBlockBody"></tbody>
                </table>
            </div>
            <h3 class="adc-sub">Impact</h3>
            <div class="pm-table-wrap">
                <table>
                    <thead id="adcSpImpactHead"></thead>
                    <tbody id="adcSpImpactBody"></tbody>
                </table>
            </div>
            <div id="adcSpAllocWrap">
                <h3 class="adc-sub">Allocation</h3>
                <p class="adc-note">Choose the resulting record for each item that belongs to it (saved with the draft). Field values: Copy keeps the value on the source too, Move takes it off the source.</p>
                <div class="pm-table-wrap">
                    <table>
                        <thead><tr><th>Domain</th><th>Item</th><th>Goes to</th><th>Field</th><th>Outcome</th></tr></thead>
                        <tbody id="adcSpAllocBody"></tbody>
                    </table>
                </div>
            </div>
            <div id="adcSpOutWrap">
                <h3 class="adc-sub">Outcomes</h3>
                <div class="pm-table-wrap">
                    <table>
                        <thead><tr><th>To</th><th>Item</th><th>Outcome</th><th>Detail</th></tr></thead>
                        <tbody id="adcSpOutBody"></tbody>
                    </table>
                </div>
            </div>
            <h3 class="adc-sub">Approvals</h3>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Decision</th><th>By</th><th>When</th><th>Note</th></tr></thead>
                    <tbody id="adcSpApprBody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

@* ======================= Stale review window (443) ======================= *@
"""),
])

edit(J, [
("""// new merge of its two assets. Plan, blockers and every rule are SQL's.
""",
"""// new merge of its two assets. Plan, blockers and every rule are SQL's.
// 445: Splits -- discovery/splits, discovery/splits/{id}, discovery/splits
// (draft with results and allocations), discovery/splits/{id}/action (the
// same action procedure as merges; the action buttons are shared).
"""),
("""                  mgPager: null, merge: null, mergeDups: [], mergeChoices: {},   // 444
""",
"""                  mgPager: null, merge: null, mergeDups: [], mergeChoices: {},   // 444
                  spPager: null, split: null, splitResults: [], splitAlloc: {},   // 445
"""),
("""    state.mgPager = g ? g.attach({ hostId: "adcMgPager", onChange: refreshMerges }) : null;
""",
"""    state.mgPager = g ? g.attach({ hostId: "adcMgPager", onChange: refreshMerges }) : null;
    state.spPager = g ? g.attach({ hostId: "adcSpPager", onChange: refreshSplits }) : null;
"""),
("""    // stale assets (443)
    let ts = null;
""",
"""    // splits (445)
    let tsp = null;
    document.getElementById("adcSpStatus").addEventListener("change", () => { state.spPager?.reset(true); refreshSplits(); });
    document.getElementById("adcSpSearch").addEventListener("input", () => { clearTimeout(tsp); tsp = setTimeout(() => { state.spPager?.reset(true); refreshSplits(); }, 300); });
    document.getElementById("adcSpNew")?.addEventListener("click", () => openSplitNew());
    document.getElementById("adcSpBody").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-adc-split]");
      if (b) openSplit(Number(b.dataset.adcSplit));
    });
    let tss = null, tsr = null;
    document.getElementById("adcSpSrcSearch").addEventListener("input", () => { clearTimeout(tss); tss = setTimeout(() => fillAssetPicker("adcSpSrcSearch", "adcSpSrc", null, "adcSpMessage"), 300); });
    document.getElementById("adcSpResSearch").addEventListener("input", () => { clearTimeout(tsr); tsr = setTimeout(() => fillAssetPicker("adcSpResSearch", "adcSpResSel", null, "adcSpMessage"), 300); });
    document.getElementById("adcSpResAdd").addEventListener("click", addSplitResult);
    document.getElementById("adcSpRegister").addEventListener("click", () => window.open(U("/Practice/Index/asset-register"), "_blank"));
    document.getElementById("adcSpResBody").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-adc-res-remove]");
      if (b) { state.splitResults.splice(Number(b.dataset.adcResRemove), 1); renderSplitResults(); }
    });
    document.getElementById("adcSpForm").addEventListener("submit", ev => { ev.preventDefault(); saveSplit(); });
    document.getElementById("adcSpActions").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-adc-split-action]");
      if (b) splitAction(b.dataset.adcSplitAction);
    });
    document.getElementById("adcSpAllocBody").addEventListener("change", ev => {
      const x = ev.target.closest("[data-adc-alloc]");
      if (!x) return;
      const key = x.dataset.adcAlloc, row = state.splitAlloc[key] || (state.splitAlloc[key] = JSON.parse(x.dataset.adcItem));
      const modeSel = x.closest("tr").querySelector("[data-adc-alloc-mode]");
      if (x.dataset.adcAllocMode === undefined) row.targetAssetId = Number(x.value) || null;
      row.fieldMode = modeSel ? modeSel.value : null;
      if (!row.targetAssetId) delete state.splitAlloc[key];
    });
    // stale assets (443)
    let ts = null;
"""),
("""    [state.batPager, state.qPager, state.cPager, state.stPager, state.mgPager].forEach(p => p?.reset(true));
""",
"""    [state.batPager, state.qPager, state.cPager, state.stPager, state.mgPager, state.spPager].forEach(p => p?.reset(true));
"""),
("""    else if (name === "MERGES") await refreshMerges();
""",
"""    else if (name === "MERGES") await refreshMerges();
    else if (name === "SPLITS") await refreshSplits();
"""),
("""  async function fillAssetPicker(searchId, selectId, keep) {
""",
"""  async function fillAssetPicker(searchId, selectId, keep, msgId) {   // 445: msgId (default the merge window)
"""),
("""    if (!res.ok) show("adcMgMessage", res.error);
  }
""",
"""    if (!res.ok) show(msgId || "adcMgMessage", res.error);
  }
"""),
("""    const acts = [];
    if (draft && CAN_EDIT) acts.push(["SUBMIT", "Submit for approval", "primary"]);
    if (m.status === "PENDING_APPROVAL" && CAN_APPROVE) acts.push(["APPROVE", "Approve", "primary"], ["REJECT", "Reject", ""]);
    if (m.status === "APPROVED" && CAN_EDIT) acts.push(["EXECUTE", "Execute merge", "primary"]);
    if (m.status === "EXECUTED" && CAN_APPROVE) acts.push(["RECOVER", "Recover", ""]);
    if (["DRAFT", "PENDING_APPROVAL", "APPROVED"].includes(m.status) && CAN_EDIT) acts.push(["CANCEL", "Cancel merge", ""]);
    document.getElementById("adcMgActions").innerHTML = acts.map(([a, l, c]) => `<button class="pm-button ${c}" type="button" data-adc-merge-action="${a}">${esc(l)}</button>`).join("");
""",
"""    const acts = eventActions(m.status, "merge");   // 445: shared with splits
    document.getElementById("adcMgActions").innerHTML = acts.map(([a, l, c]) => `<button class="pm-button ${c}" type="button" data-adc-merge-action="${a}">${esc(l)}</button>`).join("");
"""),
("""    const done = { SUBMIT: "Submitted for approval.", APPROVE: res.data.result === "FIRST_APPROVAL" ? "First approval recorded; a second approver is needed." : "Approved.",
                   REJECT: "Rejected.", CANCEL: "Cancelled.", EXECUTE: "Merge executed; see the outcomes.", RECOVER: "Merge recovered; see the outcome notes." };
    show("adcMgMessage", done[action], "success");
""",
"""    show("adcMgMessage", eventDone(action, res.data.result, "Merge"), "success");
"""),
("""  // ------------------------------------------------------------------ stale assets (443)
  async function refreshStale() {""",
"""  // 444 / 445: actions the status allows (the proxy and SQL check permissions and people).
  function eventActions(status, noun) {
    const acts = [];
    if (status === "DRAFT" && CAN_EDIT) acts.push(["SUBMIT", "Submit for approval", "primary"]);
    if (status === "PENDING_APPROVAL" && CAN_APPROVE) acts.push(["APPROVE", "Approve", "primary"], ["REJECT", "Reject", ""]);
    if (status === "APPROVED" && CAN_EDIT) acts.push(["EXECUTE", `Execute ${noun}`, "primary"]);
    if (status === "EXECUTED" && CAN_APPROVE) acts.push(["RECOVER", "Recover", ""]);
    if (["DRAFT", "PENDING_APPROVAL", "APPROVED"].includes(status) && CAN_EDIT) acts.push(["CANCEL", `Cancel ${noun}`, ""]);
    return acts;
  }
  function eventDone(action, result, noun) {
    return { SUBMIT: "Submitted for approval.", APPROVE: result === "FIRST_APPROVAL" ? "First approval recorded; a second approver is needed." : "Approved.",
             REJECT: "Rejected.", CANCEL: "Cancelled.", EXECUTE: `${noun} executed; see the outcomes.`, RECOVER: `${noun} recovered; see the outcome notes.` }[action];
  }

  // ------------------------------------------------------------------ splits (445)
  async function refreshSplits() {
    const body = document.getElementById("adcSpBody");
    if (!state.organizationId) { body.innerHTML = empty(6, "Select an organization."); state.spPager?.clear(); return; }
    body.innerHTML = empty(6, "Loading...");
    const qs = new URLSearchParams({ organizationId: state.organizationId,
      pageNumber: state.spPager ? state.spPager.page() : 1, pageSize: state.spPager ? state.spPager.size() : 25 });
    if (val("adcSpStatus")) qs.set("status", val("adcSpStatus"));
    if (val("adcSpSearch")) qs.set("search", val("adcSpSearch"));
    const res = await api("GET", `/discovery/splits?${qs}`);
    if (!res.ok) { body.innerHTML = empty(6, res.error); state.spPager?.clear(); return; }
    const rows = res.data.data.rows || [];
    state.spPager?.setTotal(res.data.data.totalRows, rows.length);
    body.innerHTML = rows.map(m => {
      const [sl, sc] = MERGE[m.status] || [m.status, ""];
      return `<tr><td><button class="pm-link-button" type="button" data-adc-split="${m.eventId}">Split #${esc(m.eventId)}</button></td>
        <td>${esc(m.survivorName)}</td><td>${esc(m.duplicateNames || "--")}<div class="adc-note">${esc(m.duplicateCount)} record(s)</div></td>
        <td><span class="adc-chip ${sc}">${esc(sl)}</span></td>
        <td>${esc(m.approvals)} / ${esc(m.approvalsRequired)}${m.isCritical ? ' <span class="adc-chip adc-st-bad">Critical</span>' : ""}</td>
        <td>${esc(m.requestedBy || "")}<div class="adc-note">${esc(dateTime(m.requestedDt))}</div></td></tr>`;
    }).join("") || empty(6, "No splits.");
  }

  function renderSplitResults() {
    const canEdit = CAN_EDIT && (!state.split || state.split.split.status === "DRAFT");
    document.getElementById("adcSpResBody").innerHTML = state.splitResults.map((d, i) => `<tr><td>${esc(d.name)} <span class="adc-note">#${esc(d.id)}</span></td>
        <td>${canEdit ? `<button class="pm-link-button" type="button" data-adc-res-remove="${i}">Remove</button>` : ""}</td></tr>`).join("")
      || empty(2, "Add at least one resulting record (a new Draft asset).");
  }

  function addSplitResult() {
    const sel = document.getElementById("adcSpResSel"), id = Number(sel.value);
    if (!id) return;
    if (String(id) === val("adcSpSrc")) { show("adcSpMessage", "The source cannot also be a resulting record."); return; }
    if (state.splitResults.some(d => d.id === id)) return;
    if (state.splitResults.length >= 5) { show("adcSpMessage", "A split has at most 5 resulting records."); return; }
    state.splitResults.push({ id, name: sel.options[sel.selectedIndex].textContent });
    hide("adcSpMessage");
    renderSplitResults();
  }

  async function openSplitNew() {
    state.split = null; state.splitResults = []; state.splitAlloc = {};
    hide("adcSpMessage");
    document.getElementById("adcSpTitle").textContent = "New split";
    document.getElementById("adcSpInfo").innerHTML = "";
    document.getElementById("adcSpForm").hidden = !CAN_EDIT;
    document.getElementById("adcSpActionWrap").hidden = true;
    document.getElementById("adcSpDetail").hidden = true;
    ["adcSpSrcSearch", "adcSpResSearch", "adcSpReason"].forEach(id => { document.getElementById(id).value = ""; });
    await fillAssetPicker("adcSpSrcSearch", "adcSpSrc", null, "adcSpMessage");
    await fillAssetPicker("adcSpResSearch", "adcSpResSel", null, "adcSpMessage");
    renderSplitResults();
    document.getElementById("adcSplitModal").hidden = false;
  }

  async function saveSplit() {
    const source = num("adcSpSrc");
    if (!source) { show("adcSpMessage", "Choose the source."); return; }
    const m = state.split && state.split.split;
    const keep = new Set(state.splitResults.map(r => r.id));
    const allocations = Object.values(state.splitAlloc).filter(a => a.targetAssetId && keep.has(a.targetAssetId))
      .map(a => ({ objectKind: a.objectKind, objectId: a.objectId, objectKey: a.objectKey, targetAssetId: a.targetAssetId,
                   fieldMode: a.objectKind === "FIELD" ? (a.fieldMode || "COPY") : null }));
    const res = await api("POST", "/discovery/splits", {
      organizationId: state.organizationId, eventId: m ? m.eventId : null, sourceAssetId: source,
      resultAssetIds: state.splitResults.map(r => r.id), reason: val("adcSpReason"), allocations,
      expectedRecordVersion: m ? m.recordVersion : null
    });
    if (!res.ok) { show("adcSpMessage", res.error); return; }
    await openSplit(res.data.id);
    show("adcSpMessage", "Draft saved. Allocate the items, save again, then submit it for approval.", "success");
    await refreshSplits();
  }

  async function openSplit(id) {
    const res = await api("GET", `/discovery/splits/${id}?organizationId=${state.organizationId}`);
    if (!res.ok) { showMessage(res.error); return; }
    const d = res.data.data, m = d.split;
    state.split = d;
    hide("adcSpMessage");
    const [sl, sc] = MERGE[m.status] || [m.status, ""];
    document.getElementById("adcSpTitle").textContent = `Split #${m.eventId} - ${m.sourceName}`;
    const item = (l, v) => `<div><span>${esc(l)}</span>${v}</div>`;
    document.getElementById("adcSpInfo").innerHTML =
      item("Status", `<span class="adc-chip ${sc}">${esc(sl)}</span>${m.isCritical ? ' <span class="adc-chip adc-st-bad">Critical</span>' : ""}`) +
      item("Approvals", `${esc(m.approvals)} / ${esc(m.approvalsRequired)}`) + item("Requested", `${esc(m.requestedBy || "")} ${esc(dateTime(m.requestedDt))}`) +
      item("Reason", esc(m.reason || "--")) +
      (m.executedDt ? item("Executed", `${esc(m.executedBy || "")} ${esc(dateTime(m.executedDt))}`) : "") +
      (m.recoveredDt ? item("Recovered", `${esc(m.recoveredBy || "")} ${esc(dateTime(m.recoveredDt))} - ${esc(m.recoveryReason || "")}`) : "") +
      (m.decidedNote ? item("Decision note", esc(m.decidedNote)) : "");
    const draft = m.status === "DRAFT", open = ["DRAFT", "PENDING_APPROVAL", "APPROVED"].includes(m.status);
    const assets = d.assets || [], results = assets.filter(a => a.memberRole !== "SOURCE");
    const nameOf = aid => (assets.find(a => a.assetId === aid) || {}).assetName || "#" + aid;
    state.splitResults = results.map(a => ({ id: a.assetId, name: a.assetName }));
    state.splitAlloc = {};
    (d.plan || []).filter(p => p.targetAssetId).forEach(p => {
      state.splitAlloc[allocKey(p)] = { objectKind: p.objectKind, objectId: p.objectId, objectKey: p.objectKind === "FIELD" ? null : p.objectKey,
                                        targetAssetId: p.targetAssetId, fieldMode: p.fieldMode };
    });
    document.getElementById("adcSpForm").hidden = !(draft && CAN_EDIT);
    if (draft && CAN_EDIT) {
      document.getElementById("adcSpReason").value = m.reason || "";
      await fillAssetPicker("adcSpSrcSearch", "adcSpSrc", { id: m.sourceAssetId, name: m.sourceName }, "adcSpMessage");
      await fillAssetPicker("adcSpResSearch", "adcSpResSel", null, "adcSpMessage");
    }
    renderSplitResults();
    const acts = eventActions(m.status, "split");
    document.getElementById("adcSpActions").innerHTML = acts.map(([a, l, c]) => `<button class="pm-button ${c}" type="button" data-adc-split-action="${a}">${esc(l)}</button>`).join("");
    document.getElementById("adcSpActionWrap").hidden = !acts.length;
    document.getElementById("adcSpNote").value = "";
    document.getElementById("adcSpBlockBody").innerHTML = (d.blockers || []).map(b => `<tr><td>${esc(b.detail)}</td></tr>`).join("")
      || empty(1, open ? "None." : "--");
    document.getElementById("adcSpImpactHead").innerHTML = `<tr><th>Item</th>${assets.map(a => `<th>${esc(a.assetName)}<div class="adc-note">${a.memberRole === "SOURCE" ? "source" : "resulting record"} - ${esc(a.statusName)}${a.criticalityName ? ", " + esc(a.criticalityName) : ""}</div></th>`).join("")}</tr>`;
    const items = [...new Map((d.impact || []).map(i => [i.impactItem, i.sortOrder])).entries()].sort((x, y) => x[1] - y[1]).map(x => x[0]);
    document.getElementById("adcSpImpactBody").innerHTML = items.map(it => `<tr><td>${esc(it)}</td>${assets.map(a => {
      const r = (d.impact || []).find(i => i.assetId === a.assetId && i.impactItem === it);
      return `<td>${esc(r ? r.itemCount : 0)}</td>`; }).join("")}</tr>`).join("") || empty(1, "--");
    // allocation (open) / outcomes (executed, recovered)
    document.getElementById("adcSpAllocWrap").hidden = !open;
    document.getElementById("adcSpOutWrap").hidden = open;
    const canAlloc = draft && CAN_EDIT;
    document.getElementById("adcSpAllocBody").innerHTML = (d.plan || []).map(p => {
      const key = allocKey(p), a = state.splitAlloc[key];
      const itemJson = esc(JSON.stringify({ objectKind: p.objectKind, objectId: p.objectId, objectKey: p.objectKind === "FIELD" ? null : p.objectKey, targetAssetId: null, fieldMode: null }));
      const target = `<select data-adc-alloc="${esc(key)}" data-adc-item="${itemJson}"${canAlloc ? "" : " disabled"}><option value="">Stays with the source</option>${results.map(r => `<option value="${r.assetId}"${a && a.targetAssetId === r.assetId ? " selected" : ""}>${esc(r.assetName)}</option>`).join("")}</select>`;
      const mode = p.objectKind === "FIELD" ? `<select data-adc-alloc="${esc(key)}" data-adc-alloc-mode="1" data-adc-item="${itemJson}"${canAlloc ? "" : " disabled"}><option value="COPY"${a && a.fieldMode === "MOVE" ? "" : " selected"}>Copy</option><option value="MOVE"${a && a.fieldMode === "MOVE" ? " selected" : ""}>Move</option></select>` : "";
      const [pl, pc] = PLAN[p.outcome] || (p.outcome === "STAY" ? ["Stays", "adc-st-ended"] : p.outcome === "COPY" ? ["Copy", "adc-st-open"] : [p.outcome, ""]);
      return `<tr><td>${esc(p.domain || "")}</td><td>${esc(OBJECT[p.objectKind] || p.objectKind)}: ${esc(p.objectLabel || "")}<div class="adc-note">${esc(p.detail || "")}</div></td>
        <td>${target}</td><td>${mode}</td><td><span class="adc-chip ${pc}">${esc(pl)}</span>${p.outcomeNote ? `<div class="adc-note">${esc(p.outcomeNote)}</div>` : ""}</td></tr>`;
    }).join("") || empty(5, "The source has nothing to allocate.");
    document.getElementById("adcSpOutBody").innerHTML = (d.outcomes || []).map(o => {
      const [pl, pc] = PLAN[o.outcome] || [o.outcome, ""];
      const rec = o.outcome !== "KEPT" ? (o.recovered ? ' <span class="adc-chip adc-st-active">Recovered</span>' : (o.recoveryNote ? `<div class="adc-note">${esc(o.recoveryNote)}</div>` : "")) : "";
      return `<tr><td>${esc(nameOf(o.toAssetId))}</td><td>${esc(OBJECT[o.objectKind] || o.objectKind)}: ${esc(o.objectLabel || "")}</td>
        <td><span class="adc-chip ${pc}">${esc(pl)}</span>${rec}</td>
        <td>${esc(o.detail || "")}${o.objectKind === "FIELD" ? `<div class="adc-note">${esc(o.beforeValue ?? "(empty)")} -> ${esc(o.afterValue ?? "(empty)")}</div>` : ""}</td></tr>`;
    }).join("") || empty(4, "--");
    document.getElementById("adcSpApprBody").innerHTML = (d.approvals || []).map(a => `<tr><td>${esc(label(a.decision))}</td><td>${esc(a.approver)}</td>
        <td>${esc(dateTime(a.decidedDt))}</td><td>${esc(a.note || "")}</td></tr>`).join("") || empty(4, "None yet.");
    document.getElementById("adcSpDetail").hidden = false;
    document.getElementById("adcSplitModal").hidden = false;
  }
  function allocKey(p) { return `${p.objectKind}|${p.objectId ?? ""}|${p.objectKind === "FIELD" ? "" : (p.objectKey ?? "")}`; }

  async function splitAction(action) {
    const m = state.split && state.split.split;
    if (!m) return;
    const asks = { EXECUTE: "Execute the split now? The allocated items move to the resulting records.",
                   RECOVER: "Recover this split? Items are moved back where they were not changed since." };
    if (asks[action] && window.gracUi && window.gracUi.confirm && !(await window.gracUi.confirm(asks[action]))) return;
    if (action === "SUBMIT" && !sameAllocation(state.split.plan || [])) { show("adcSpMessage", "Save the draft first: the allocation changed."); return; }
    const res = await api("POST", `/discovery/splits/${m.eventId}/action`, {
      organizationId: state.organizationId, action, note: val("adcSpNote"), expectedRecordVersion: m.recordVersion
    });
    if (!res.ok) { show("adcSpMessage", res.error); return; }
    await openSplit(m.eventId);
    show("adcSpMessage", eventDone(action, res.data.result, "Split"), "success");
    await refreshSplits();
  }
  function sameAllocation(plan) {
    const saved = {};
    plan.filter(p => p.targetAssetId).forEach(p => { saved[allocKey(p)] = `${p.targetAssetId}|${p.fieldMode || ""}`; });
    const now = {};
    Object.entries(state.splitAlloc).forEach(([k, a]) => { if (a.targetAssetId) now[k] = `${a.targetAssetId}|${a.objectKind === "FIELD" ? (a.fieldMode || "COPY") : ""}`; });
    const ks = Object.keys(saved), kn = Object.keys(now);
    return ks.length === kn.length && ks.every(k => saved[k] === now[k]);
  }

  // ------------------------------------------------------------------ stale assets (443)
  async function refreshStale() {"""),
])
print("pui445 ok")
