-- =====================================================================
-- 3. Verification
-- =====================================================================
SELECT '451-a procedure' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.sp_dashboard_asset_contract','P') IS NOT NULL THEN 'PASS' ELSE 'FAIL' END AS Result;
SELECT '451-b menu: Dashboard is the first Active child of Asset & Contract' AS Check_,
       CASE WHEN (SELECT TOP (1) c.menu_key FROM grac_practice.menu_master c
                    JOIN grac_practice.menu_master p ON p.menu_id = c.parent_menu_id AND p.menu_key = N'nav-asset-contract'
                   WHERE c.status = N'Active' ORDER BY c.display_order, c.menu_id) = N'asset-contract-dashboard'
            THEN 'PASS' ELSE 'FAIL' END AS Result;
-- The dashboard runs for one organization that has assets (four result
-- sets; run it by hand for any other organization).
DECLARE @org BIGINT = (SELECT TOP (1) organization_id FROM grac_practice.organization_dependency_asset ORDER BY organization_id);
IF @org IS NOT NULL EXEC grac_practice.sp_dashboard_asset_contract @organization_id = @org;
GO

/* =====================================================================
   UAT (a role with VIEW on some Asset & Contract screens)
   ---------------------------------------------------------------------
   1. Asset & Contract -> Dashboard opens; only the sections whose screen
      the role may VIEW are shown (remove asset-privacy VIEW -> no Privacy
      section). Re-login after granting.
   2. Asset register: Draft opens the Asset Register filtered to Draft
      with the banner; Clear filter shows every asset; the bar "Assets by
      lifecycle status: Active" opens the register filtered to Active and
      the count matches its total.
   3. Attestation: Overdue opens Asset Attestation -> All occurrences
      filtered to Overdue; same count.
   4. Contracts: Coverage gaps opens the Coverage gaps tab; the count is
      its total. Open renewals opens Renewals (Open).
   5. Privacy: the bar Non-compliant opens Asset Privacy filtered to
      Non-compliant.
   6. CMDB quality: Open conflicts opens the Reconciliation queue with
      Exception = Conflict; Stale assets opens Stale assets.
   7. Lists: a row of Unsupported or unknown technology opens the asset on
      the Asset Register.
   8. Governance: shown once a snapshot exists (Asset Governance);
      the tiles open Asset Governance.
   ===================================================================== */
