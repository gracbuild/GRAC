namespace PracticeManagement.Web.Security;

// =====================================================================
// PermissionAreaMap
//
// Maps a gateway entity type onto the permission area that governs it.
//
// WHY THIS IS ITS OWN FILE, LINKED INTO BOTH TIERS
//   The mapping used to live only in
//   PracticeManagementGatewayController.PermissionArea. The API ran its
//   own check on the RAW entity type:
//
//       permissionPolicy.IsAllowed(principal.Roles, request.EntityType, action)
//
//   so the two tiers disagreed. Opening a row on Organization Controls
//   sends entityType "release-statements": the Web tier mapped it to
//   "organization-controls" and let it through on the caller's
//   organization-controls:VIEW grant, then the API asked for
//   "release-statements:VIEW" — a permission no role can hold, because
//   there is no menu_master row by that name — and answered 403:
//
//       The practice API returned HTTP 403 ... for entity [release-statements]
//
//   admin@grac.local never saw it: PM_ADMIN is "*:*" on both tiers.
//
//   Copying the mapping into the API would have left two lists to keep
//   in step. Instead this file is authored once here and LINKED into
//   PracticeManagement.Api.csproj, the same arrangement PasswordHasher
//   already uses — one source file, two assemblies, one definition of
//   which permission governs which entity type.
//
// WHAT BELONGS HERE
//   Only helper entity types with a SINGLE owning screen. An entity type
//   read by several screens has no parent to map to and belongs in
//   LoginController.SupportingReads instead (that is where
//   subscribed-frameworks, lookups, dashboard-summary and menu-master
//   are handled).
//
//   An entity type that is neither a menu_master row, nor mapped here,
//   nor in SupportingReads is unreachable for every database user and
//   will answer 403 or 500 on the screen that reads it.
// =====================================================================
public static class PermissionAreaMap
{
    // Helper entity types that are governed by the Organization Controls
    // screen: the release drill-down, its statements, and the custom
    // release authoring flow all render inside that screen.
    private static readonly HashSet<string> OrganizationControlsHelpers = new(StringComparer.OrdinalIgnoreCase)
    {
        "release-statements",
        "statement-applicability",
        // Bulk applies the same rules to several statements at once, so it is
        // governed by the same screen and the same permission as marking one.
        // Mapping it anywhere else would let a role that cannot mark a single
        // statement mark fifty.
        "statement-applicability-bulk",
        "custom-release",
        "custom-release-statements",
        "custom-release-source-structure",
        "custom-statement",
        // Statement Classification management for Custom Release authoring
        // (change request 2026-09-22, part 2) -- same screen, same gate as
        // custom-release-source-structure above.
        "custom-statement-classification",
        "subscription-owner",
        // Add Release > Subscribe from Repository (migration 406): lives in
        // the Add Release dialog of this screen, so it needs exactly what
        // Add Release needs -- VIEW to list, ADD to submit a request.
        "repository-subscription-requests"
    };

    // Single-owner helpers that map to a screen of their own.
    private static readonly Dictionary<string, string> DirectMap = new(StringComparer.OrdinalIgnoreCase)
    {
        // Published (typed) obligations of a practice. Read by the Practice
        // View page's Obligations panel and the Practice Instance form's
        // obligation section -- both governed by Organization Practices
        // (see practice-view / practice-instances below). It used to map to
        // "evidence-obligations", the old View Obligations screen, which has
        // no menu_master row: no role could hold "evidence-obligations:VIEW",
        // so every non-admin got HTTP 403 on the panel while
        // admin@grac.local ("*:*") loaded it. The procedure still scopes the
        // rows to the requested organization, and the API still checks the
        // caller's access to that organization.
        ["evidence-obligations-typed"] = "organization-requirements",
        // Calendar grid feed (practice-calendar.js). No menu of its own;
        // the screen it belongs to is assurance-calendar (migration 028).
        ["assurance-calendar-events"] = "assurance-calendar",
        // Move/Skip an occurrence (the Calendar's "Edit Schedule" dialog,
        // now also reachable from the Schedule List's 3-dot menu -- change
        // request 2026-09) and the schedule-rule row it moves/skips
        // against. Neither has ever had a menu_master row of its own --
        // both are governed by the screen that renders their only editor,
        // assurance-calendar. Left unmapped, PermissionAreaMap.For()
        // returns each raw entity type unchanged and IsAllowed(...) is
        // asked for a permission area no role can hold, so the save 403s
        // for every real role -- exactly the release-statements bug this
        // file's header describes, silent for admin@grac.local's "*:*"
        // wildcard and only surfacing for an actual Editor. Caught while
        // wiring the List's Edit action, which is what made a non-admin
        // role's save path matter for the first time.
        ["assurance-schedule-rules"] = "assurance-calendar",
        ["assurance-schedule-overrides"] = "assurance-calendar",
        // Practice instances lost their own menu row to migration 288, and
        // only Active rows pass the permission filter -- so the entity
        // would be refused for everybody. Instances are now created from
        // "New Practice Instance" on an Organization Requirement row, so
        // that screen governs them.
        //
        // This has to match ScreenPermissionArea in PracticeController:
        // that one permissions the FORM, this one permissions the SAVE.
        // Mapping only one of them renders a form that 403s on submit.
        ["practice-instances"] = "organization-requirements",
        // Bulk practice applicability is the Organization Practices screen's
        // own action, governed by that screen's permission -- same rule as
        // statement-applicability-bulk above.
        ["requirement-applicability-bulk"] = "organization-requirements",
        // Source Statement mapping picker on the Add/Edit Practice form
        // (change request 2026-09): read-only helper for that same screen,
        // same rule as practice-instances above -- mapping only this one
        // and not the screen itself would be pointless, but leaving this
        // one unmapped 403s the picker's pre-population query while the
        // rest of the form works fine.
        ["practice-statement-mappings"] = "organization-requirements",
        // Migration 345: the user-ownership entity (list + reassign) is read
        // and written only by the Ownership Management screen, so that screen
        // governs it on both tiers -- VIEW to list, EDIT/ADD to reassign.
        ["user-ownership"] = "ownership-management",
        // Migration 370: Committee Designation Master's "Add Designation"
        // quick-create, reached from the Committee Member row on the
        // Add/Edit Committee form. No menu_master row of its own -- it is
        // a per-form auxiliary write, governed by the same permission as
        // the Committee form itself -- which is now Organization
        // Administration's ADD / EDIT (see the tab entries below), so this
        // points straight there rather than at "committees" (DirectMap is
        // one hop, not chained). Same reasoning as practice-instances/
        // user-ownership above.
        // Reading designations (committee-designations:VIEW) is instead
        // granted to every role via LoginController.SupportingReads, same
        // as team-department-employees/team-members -- see that list's
        // own comment for why.
        ["committee-designations"] = "organization-administration",
        // The Organization Administration tabs. Migration 060 set these five
        // menu_master rows Inactive to take them out of the sidebar (they
        // are tabs inside Organization Administration now), but permissions
        // load only from Active menu rows -- so "committees:VIEW" and the
        // rest became grants no role could hold, and every non-admin got
        // "You do not have permission to view committees" on the tab.
        // The screen that shows them governs them instead: VIEW on
        // Organization Administration lists them, its ADD/EDIT/DELETE
        // govern Add/Edit/Inactive.
        //
        // 2026-10-06: Users joins them. Its "users" menu row (User
        // Management) is Active, but its parent 'nav-administration' is
        // InActive, so it is in neither the sidebar nor the Role Master
        // permission matrix -- an organization admin could not be granted
        // it and the Users tab answered "You do not have permission to view
        // users" while every other tab worked. Same rule as the five above:
        // the screen that shows the tab governs it.
        ["users"] = "organization-administration",
        // The Organization tab of the same screen (read-only by design,
        // 2026-09-20). Its read used "organization-setup" -- the GRAC
        // Admin's Organization Setup menu, which an organization admin is
        // not meant to hold -- so the tab failed the same way. The tab now
        // reads through this alias: QUERY only, organization-scoped at the
        // gateway, resolved to organization-setup inside the API
        // (PracticeRepositoryService.ExecuteAsync), which refuses any
        // write under this name. Organization Setup itself is unchanged.
        // The Organization Management landing LIST (2026-11-02). Like
        // practice-instances above, its menu_master row is Inactive, so
        // "organizations:VIEW" is a grant no role can hold and the list's
        // own query -- plus the navigation code its row click mints --
        // would answer 403 for every real role while admin ("*:*") saw it
        // work. Every row leads to Organization Setup, so that screen
        // governs it.
        //
        // This MUST match PracticeController.ScreenPermissionArea, which
        // maps the same key: that one permissions the PAGE, this one
        // permissions the entity read behind it. Mapping only one of them
        // renders a list that 403s on load.
        ["organizations"] = "organization-setup",
        // The read-only organization page the list's rows open. Same rule,
        // same reason: no menu row of its own, reached from Organization
        // Setup's own list and leading back to it through Actions > Edit.
        // Needed here (not only in ScreenPermissionArea) because the
        // gateway checks PermissionArea on the navigation code it mints and
        // resolves, whose source/target areas are these screen keys.
        ["organization-view"] = "organization-setup",
        ["organization-profile"] = "organization-administration",
        ["locations"] = "organization-administration",
        ["departments"] = "organization-administration",
        ["business-functions"] = "organization-administration",
        ["teams"] = "organization-administration",
        ["committees"] = "organization-administration",
        // Practice View (practice-view.cshtml) is a screen with no
        // menu_master row, so no role could ever be granted
        // "practice-view:VIEW" and every non-admin was refused both the
        // navigation code and the navigation-context read. It is reached
        // only by "View" on the Organization Practices grid, so that
        // screen governs it -- same rule as practice-instances above, and
        // the same mapping PracticeController.ScreenPermissionArea applies
        // to the page itself.
        ["practice-view"] = "organization-requirements",
        // Role Master's Menu Permission card (2026-10-26). Migration 401
        // moved the standalone "Role Menu Permission" screen INTO Role
        // Master (hidden from the sidebar), and the matrix itself leaves
        // the role-menu-permissions menu out (role-menu-permission-editor.js
        // EXCLUDED_KEYS) -- so "role-menu-permissions:VIEW" became a grant
        // no role could be given, and opening an existing role answered
        // "You do not have permission to view role-menu-permissions" on the
        // card. The screen that shows it governs it: VIEW on Role Master
        // reads the matrix, its ADD / EDIT save it. Also covers the card's
        // View Data Scope settings (RoleViewDataScopeController reads
        // PermissionAreaMap.For("role-menu-permissions")).
        ["role-menu-permissions"] = "roles"
    };

    /// <summary>
    /// The permission area that governs <paramref name="entityType"/>.
    /// Returns the entity type unchanged when it is a screen in its own
    /// right, which is the common case.
    /// </summary>
    public static string For(string entityType)
    {
        if (string.IsNullOrWhiteSpace(entityType)) return entityType;
        if (DirectMap.TryGetValue(entityType, out var mapped)) return mapped;
        return OrganizationControlsHelpers.Contains(entityType) ? "organization-controls" : entityType;
    }
}
