
-- =====================================================================
-- 7. Reconciliation queue (5.6.3; D102-D104)
-- =====================================================================
-- Actions:
--   Suggested match / Manual review / New candidate:  LINK (to @asset_id, or the
--       suggested asset), IGNORE (note)
--   Potential duplicate:  LINK (to one of the two assets), NOT_DUPLICATE (note; the
--       pair is not raised again), IGNORE (note)
--   Conflict:  ACCEPT_OBSERVED (the observed value is written), KEEP_CURRENT (note)
-- Linking applies the observation to the asset (confirmed link) and closes
-- the other open match exceptions of the same source record.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_reconciliation_resolve
    @organization_id         BIGINT,
    @exception_id            BIGINT,
    @action                  NVARCHAR(20),
    @asset_id                BIGINT         = NULL,
    @note                    NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @action = UPPER(LTRIM(RTRIM(ISNULL(@action, N''))));
    SET @note = NULLIF(LTRIM(RTRIM(@note)), N'');
    DECLARE @found BIT = 0, @kind NVARCHAR(16), @status NVARCHAR(10), @rv BIGINT, @obs BIGINT, @source BIGINT, @key NVARCHAR(200),
            @exc_asset BIGINT, @other BIGINT, @field NVARCHAR(100), @observed NVARCHAR(400), @score INT, @payload NVARCHAR(MAX);
    SELECT @found = 1, @kind = e.exception_kind, @status = e.status, @rv = CONVERT(BIGINT, e.record_version), @obs = e.observation_id,
           @source = e.source_id, @key = e.external_key, @exc_asset = e.asset_id, @other = e.other_asset_id, @field = e.field_key,
           @observed = e.observed_value, @score = e.match_score, @payload = o.payload_json
      FROM grac_practice.asset_reconciliation_exception e
      JOIN grac_practice.asset_discovery_observation o ON o.observation_id = e.observation_id
     WHERE e.exception_id = @exception_id AND e.organization_id = @organization_id;
    IF @found = 0 THROW 54773, 'Reconciliation exception not found for this organization.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 54774, 'The exception was changed by someone else; reload it and try again.', 1;
    IF @status <> N'OPEN' THROW 54775, 'This exception is already resolved.', 1;
    IF NOT ((@kind IN (N'SUGGESTED_MATCH', N'MANUAL_REVIEW', N'NEW_CANDIDATE') AND @action IN (N'LINK', N'IGNORE'))
         OR (@kind = N'DUPLICATE' AND @action IN (N'LINK', N'NOT_DUPLICATE', N'IGNORE'))
         OR (@kind = N'CONFLICT' AND @action IN (N'ACCEPT_OBSERVED', N'KEEP_CURRENT')))
        THROW 54776, 'That action is not available for this exception.', 1;
    IF @action IN (N'IGNORE', N'NOT_DUPLICATE', N'KEEP_CURRENT') AND @note IS NULL
        THROW 54778, 'Record the reason in the note.', 1;
    IF @action = N'LINK'
    BEGIN
        SET @asset_id = COALESCE(@asset_id, CASE WHEN @kind = N'SUGGESTED_MATCH' THEN @exc_asset END);
        IF @asset_id IS NULL OR (@kind = N'DUPLICATE' AND @asset_id NOT IN (@exc_asset, @other))
           OR NOT EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset a
                            LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
                           WHERE a.asset_id = @asset_id AND a.organization_id = @organization_id
                             AND ISNULL(s.status_code, N'ACTIVE') NOT IN (N'DISPOSED', N'ARCHIVED'))
            THROW 54777, 'Select the register asset to link (for a duplicate, one of the two assets).', 1;
        IF @payload IS NULL
            THROW 54776, 'The observation details are past their retention; wait for the next observation of this record.', 1;
    END
    IF @action = N'ACCEPT_OBSERVED' AND @payload IS NULL AND @observed IS NULL
        THROW 54776, 'The observed value is no longer available.', 1;

    DECLARE @upd INT, @conf INT, @result NVARCHAR(20) = @action;
    BEGIN TRAN;
    IF @action = N'LINK'
    BEGIN
        EXEC grac_practice.sp_asset_discovery_apply @observation_id = @obs, @asset_id = @asset_id, @link_method = N'CONFIRMED',
             @match_score = @score, @actor = @actor, @out_updated = @upd OUTPUT, @out_conflicts = @conf OUTPUT;
        UPDATE grac_practice.asset_reconciliation_exception
           SET status = N'RESOLVED', resolution = N'LINKED', resolution_note = ISNULL(@note, CONCAT(N'Linked to asset ', @asset_id, N'.')),
               resolved_by = @actor, resolved_dt = SYSUTCDATETIME(), asset_id = @asset_id, updated_dt = SYSUTCDATETIME()
         WHERE status = N'OPEN' AND exception_kind IN (N'SUGGESTED_MATCH', N'MANUAL_REVIEW', N'NEW_CANDIDATE', N'DUPLICATE')
           AND (exception_id = @exception_id OR (@key IS NOT NULL AND source_id = @source AND external_key = @key));
        UPDATE grac_practice.asset_discovery_observation
           SET matched_asset_id = @asset_id,
               result_text = LEFT(CONCAT(result_text, N' Linked by ', @actor, N': ', @upd, N' field(s) updated, ', @conf, N' conflict(s).'), 1000)
         WHERE observation_id = @obs;
    END
    ELSE IF @action = N'ACCEPT_OBSERVED'
    BEGIN
        EXEC grac_practice.sp_asset_field_value_set @asset_id = @exc_asset, @field_key = @field, @value = @observed, @actor = @actor;
        UPDATE grac_practice.asset_attribute_source SET applied = 1 WHERE asset_id = @exc_asset AND field_key = @field AND source_id = @source;
        INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
        VALUES (N'asset-register', @exc_asset, N'DISCOVERY', NULL,
                (SELECT @exception_id AS exceptionId, @field AS fieldKey, @observed AS acceptedValue FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
                N'Active', @actor);
    END
    ELSE IF @action = N'NOT_DUPLICATE'
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_duplicate_decision
                        WHERE asset_id_low = CASE WHEN @exc_asset < @other THEN @exc_asset ELSE @other END
                          AND asset_id_high = CASE WHEN @exc_asset < @other THEN @other ELSE @exc_asset END)
            INSERT grac_practice.asset_duplicate_decision (asset_id_low, asset_id_high, note, decided_by)
            VALUES (CASE WHEN @exc_asset < @other THEN @exc_asset ELSE @other END,
                    CASE WHEN @exc_asset < @other THEN @other ELSE @exc_asset END, @note, @actor);
    END
    IF @action <> N'LINK'
        UPDATE grac_practice.asset_reconciliation_exception
           SET status = N'RESOLVED', resolution = @action, resolution_note = @note, resolved_by = @actor, resolved_dt = SYSUTCDATETIME(),
               updated_dt = SYSUTCDATETIME()
         WHERE exception_id = @exception_id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-reconciliation-exception', @exception_id, @action, N'{"status":"OPEN"}',
            (SELECT @action AS resolution, @asset_id AS assetId, @note AS note FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), N'Active', @actor);
    COMMIT;
    SELECT @exception_id AS ExceptionId, @result AS Result;
END
GO
PRINT '442: reconciliation queue created.';
GO

-- =====================================================================
-- 8. Data confidence and freshness (5.6.4; D105)
-- =====================================================================
-- Per asset in use: source links, best identity score, last observation,
-- links fresh within the expected interval x stale multiplier, open
-- conflicts, attributes a source reports differently and not applied, the
-- last verified date. Overall: Conflicting (open conflict) > Stale (linked,
-- nothing fresh) > Verified (verified within the window) > Probable (fresh
-- link at or above the auto-match score) > Unverified.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_discovery_confidence (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT a.asset_id AS AssetId, a.asset_name AS AssetName, ty.asset_type_name AS AssetTypeName,
           ISNULL(l.links, 0) AS LinkCount, l.best_score AS IdentityScore, l.last_seen AS LastObservedDt,
           ISNULL(l.fresh_links, 0) AS FreshLinkCount,
           CASE WHEN l.last_seen IS NULL THEN NULL ELSE DATEDIFF(HOUR, l.last_seen, SYSUTCDATETIME()) END AS AgeHours,
           ISNULL(c.conflicts, 0) AS OpenConflictCount, ISNULL(d.disagreements, 0) AS AttributeDisagreementCount,
           vd.verified_date AS LastVerifiedDate,
           CASE WHEN ISNULL(c.conflicts, 0) > 0 THEN N'CONFLICTING'
                WHEN ISNULL(l.links, 0) > 0 AND ISNULL(l.fresh_links, 0) = 0 THEN N'STALE'
                WHEN vd.verified_date >= DATEADD(DAY, -st.verification_days, CAST(SYSUTCDATETIME() AS DATE)) THEN N'VERIFIED'
                WHEN ISNULL(l.fresh_links, 0) > 0 AND l.best_score >= st.auto_match_score THEN N'PROBABLE'
                ELSE N'UNVERIFIED' END AS OverallStatus
      FROM grac_practice.organization_dependency_asset a
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
      LEFT JOIN grac_practice.dependency_asset_type_master ty ON ty.asset_type_id = a.asset_type_id
     CROSS APPLY (SELECT ISNULL(MAX(x.stale_multiplier), 3) AS stale_multiplier, ISNULL(MAX(x.verification_days), 365) AS verification_days,
                         ISNULL(MAX(x.auto_match_score), 90) AS auto_match_score
                    FROM grac_practice.asset_discovery_setting x WHERE x.organization_id = @organization_id) st
     -- the freshness flag is computed per link first: an aggregate cannot mix the
     -- outer settings with inner columns (Msg 8124).
     OUTER APPLY (SELECT COUNT(*) AS links, MAX(k.identity_score) AS best_score, MAX(k.last_seen_dt) AS last_seen,
                         SUM(fr.is_fresh) AS fresh_links
                    FROM grac_practice.asset_discovery_link k
                    JOIN grac_practice.asset_discovery_source src ON src.source_id = k.source_id
                   CROSS APPLY (SELECT CASE WHEN k.last_seen_dt >= DATEADD(HOUR, -src.expected_interval_hours * st.stale_multiplier,
                                                                            SYSUTCDATETIME()) THEN 1 ELSE 0 END AS is_fresh) fr
                   WHERE k.asset_id = a.asset_id) l
     OUTER APPLY (SELECT COUNT(*) AS conflicts FROM grac_practice.asset_reconciliation_exception e
                   WHERE e.asset_id = a.asset_id AND e.exception_kind = N'CONFLICT' AND e.status = N'OPEN') c
     OUTER APPLY (SELECT COUNT(*) AS disagreements FROM grac_practice.asset_attribute_source x
                   WHERE x.asset_id = a.asset_id AND x.applied = 0) d
     OUTER APPLY (SELECT MAX(v.value_date) AS verified_date FROM grac_practice.asset_field_value v
                    JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id AND f.field_key = N'last_verified_date'
                   WHERE v.asset_id = a.asset_id) vd
     WHERE a.organization_id = @organization_id
       AND ISNULL(s.status_code, N'ACTIVE') NOT IN (N'DISPOSED', N'ARCHIVED');
GO
PRINT '442: data confidence created.';
GO

-- =====================================================================
-- 9. Readers
-- =====================================================================
-- 1. settings  2. sources with health  3. field precedence  4. rules
-- 5. active employees  6. dictionary fields (writable by discovery or not).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_config_get
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54760, 'Organization not found.', 1;
    EXEC grac_practice.sp_asset_discovery_defaults_ensure @organization_id = @organization_id;
    SELECT auto_match_score AS AutoMatchScore, suggested_score AS SuggestedScore, manual_review_score AS ManualReviewScore,
           stale_multiplier AS StaleMultiplier, verification_days AS VerificationDays, create_conflict_tasks AS CreateConflictTasks,
           rule_set_version AS RuleSetVersion
      FROM grac_practice.asset_discovery_setting WHERE organization_id = @organization_id;
    SELECT s.source_id AS SourceId, s.source_code AS SourceCode, s.source_name AS SourceName, s.source_type AS SourceType,
           s.collection_mode AS CollectionMode, s.scope_text AS ScopeText, s.mapping_version AS MappingVersion,
           s.owner_employee_id AS OwnerEmployeeId, ow.employee_name AS OwnerName, s.credential_reference AS CredentialReference,
           s.trust_level AS TrustLevel, s.expected_interval_hours AS ExpectedIntervalHours, s.raw_retention_days AS RawRetentionDays,
           s.observation_retention_days AS ObservationRetentionDays, s.is_active AS IsActive, s.last_run_dt AS LastRunDt,
           s.last_run_status AS LastRunStatus, DATEADD(HOUR, s.expected_interval_hours, s.last_run_dt) AS NextRunDueDt,
           CASE WHEN s.last_run_dt IS NULL THEN N'NEVER'
                WHEN s.last_run_status = N'FAILED' THEN N'FAILED'
                WHEN s.last_run_status = N'PARTIAL' OR DATEADD(HOUR, s.expected_interval_hours, s.last_run_dt) < SYSUTCDATETIME() THEN N'WARNING'
                ELSE N'SUCCESS' END AS HealthStatus,
           (SELECT COUNT(*) FROM grac_practice.asset_discovery_link l WHERE l.source_id = s.source_id) AS LinkCount,
           CONVERT(BIGINT, s.record_version) AS RecordVersion
      FROM grac_practice.asset_discovery_source s
      LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = s.owner_employee_id
     WHERE s.organization_id = @organization_id
     ORDER BY s.source_name;
    SELECT p.source_id AS SourceId, p.field_key AS FieldKey, f.display_label AS FieldLabel, p.source_role AS SourceRole, p.priority AS Priority
      FROM grac_practice.asset_discovery_priority p
      JOIN grac_practice.asset_discovery_source s ON s.source_id = p.source_id AND s.organization_id = @organization_id
      LEFT JOIN grac_practice.asset_field_definition f ON f.field_key = p.field_key
     ORDER BY p.source_id, p.priority, p.field_key;
    SELECT rule_id AS RuleId, rule_name AS RuleName, attribute_keys AS AttributeKeys, strength AS Strength, weight AS Weight,
           is_active AS IsActive, display_order AS DisplayOrder
      FROM grac_practice.asset_identification_rule WHERE organization_id = @organization_id
     ORDER BY display_order, rule_name;
    SELECT employee_id AS EmployeeId, employee_name AS EmployeeName
      FROM grac_practice.organization_employee WHERE organization_id = @organization_id AND status = N'Active' ORDER BY employee_name;
    SELECT f.field_key AS FieldKey, f.display_label AS FieldLabel, f.data_type_code AS DataTypeCode,
           CAST(CASE WHEN f.storage_kind = N'VALUE' AND f.data_type_code IN (N'TEXT', N'MULTILINE', N'DECIMAL', N'PERCENT', N'QUANTITY_UNIT',
                                                                            N'DATE', N'IP_ADDRESS', N'IP_LIST') THEN 1 ELSE 0 END AS BIT) AS IsWritable
      FROM grac_practice.asset_field_definition f
     WHERE f.storage_kind IN (N'VALUE', N'COLUMN')
     ORDER BY f.display_label;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_batches
    @organization_id BIGINT,
    @source_id       BIGINT = NULL,
    @page_number     INT    = 1,
    @page_size       INT    = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    SELECT b.batch_id AS BatchId, b.batch_reference AS BatchReference, b.source_id AS SourceId, s.source_name AS SourceName,
           b.channel AS Channel, b.status AS Status, b.record_count AS RecordCount, b.updated_count AS UpdatedCount,
           b.no_change_count AS NoChangeCount, b.exception_count AS ExceptionCount, b.error_count AS ErrorCount,
           b.rule_set_version AS RuleSetVersion, b.received_dt AS ReceivedDt, b.completed_dt AS CompletedDt, b.entered_by AS EnteredBy,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_discovery_batch b
      JOIN grac_practice.asset_discovery_source s ON s.source_id = b.source_id
     WHERE b.organization_id = @organization_id AND (@source_id IS NULL OR b.source_id = @source_id)
     ORDER BY b.batch_id DESC
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- One batch: 1. batch  2. records.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_batch_get
    @organization_id BIGINT,
    @batch_id        BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_discovery_batch WHERE batch_id = @batch_id AND organization_id = @organization_id)
        THROW 54779, 'Discovery batch not found for this organization.', 1;
    SELECT b.batch_id AS BatchId, b.batch_reference AS BatchReference, s.source_name AS SourceName, b.channel AS Channel, b.status AS Status,
           b.record_count AS RecordCount, b.updated_count AS UpdatedCount, b.no_change_count AS NoChangeCount,
           b.exception_count AS ExceptionCount, b.error_count AS ErrorCount, b.rule_set_version AS RuleSetVersion,
           b.received_dt AS ReceivedDt, b.completed_dt AS CompletedDt, b.entered_by AS EnteredBy
      FROM grac_practice.asset_discovery_batch b
      JOIN grac_practice.asset_discovery_source s ON s.source_id = b.source_id
     WHERE b.batch_id = @batch_id;
    SELECT o.observation_id AS ObservationId, o.record_no AS RecordNo, o.external_key AS ExternalKey, o.observed_dt AS ObservedDt,
           o.outcome AS Outcome, o.match_score AS MatchScore, o.matched_asset_id AS MatchedAssetId, a.asset_name AS MatchedAssetName,
           o.second_asset_id AS SecondAssetId, a2.asset_name AS SecondAssetName, o.second_score AS SecondScore,
           o.matched_rules AS MatchedRules, o.result_text AS ResultText, o.payload_json AS PayloadJson
      FROM grac_practice.asset_discovery_observation o
      LEFT JOIN grac_practice.organization_dependency_asset a ON a.asset_id = o.matched_asset_id
      LEFT JOIN grac_practice.organization_dependency_asset a2 ON a2.asset_id = o.second_asset_id
     WHERE o.batch_id = @batch_id
     ORDER BY o.record_no;
END
GO

-- Reconciliation queue. @status: NULL = open, RESOLVED, ALL.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_reconciliation_exceptions
    @organization_id BIGINT,
    @status          NVARCHAR(10)  = NULL,
    @exception_kind  NVARCHAR(16)  = NULL,
    @source_id       BIGINT        = NULL,
    @asset_id        BIGINT        = NULL,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @exception_kind = NULLIF(UPPER(LTRIM(RTRIM(@exception_kind))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    SELECT e.exception_id AS ExceptionId, e.exception_kind AS ExceptionKind, e.status AS Status, e.source_id AS SourceId,
           s.source_name AS SourceName, e.external_key AS ExternalKey, e.asset_id AS AssetId, a.asset_name AS AssetName,
           e.other_asset_id AS OtherAssetId, a2.asset_name AS OtherAssetName, e.field_key AS FieldKey, f.display_label AS FieldLabel,
           e.current_value AS CurrentValue, e.observed_value AS ObservedValue, e.match_score AS MatchScore, e.raised_count AS RaisedCount,
           e.observation_id AS ObservationId, o.observed_dt AS ObservedDt, o.matched_rules AS MatchedRules, o.payload_json AS PayloadJson,
           e.task_id AS TaskId, t.task_number AS TaskNumber, e.resolution AS Resolution, e.resolution_note AS ResolutionNote,
           e.resolved_by AS ResolvedBy, e.resolved_dt AS ResolvedDt, e.entered_dt AS RaisedDt,
           CONVERT(BIGINT, e.record_version) AS RecordVersion,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_reconciliation_exception e
      JOIN grac_practice.asset_discovery_source s ON s.source_id = e.source_id
      JOIN grac_practice.asset_discovery_observation o ON o.observation_id = e.observation_id
      LEFT JOIN grac_practice.organization_dependency_asset a ON a.asset_id = e.asset_id
      LEFT JOIN grac_practice.organization_dependency_asset a2 ON a2.asset_id = e.other_asset_id
      LEFT JOIN grac_practice.asset_field_definition f ON f.field_key = e.field_key
      LEFT JOIN grac_practice.practice_task t ON t.task_id = e.task_id
     WHERE e.organization_id = @organization_id
       AND ((@status IS NULL AND e.status = N'OPEN') OR @status = N'ALL' OR e.status = @status)
       AND (@exception_kind IS NULL OR e.exception_kind = @exception_kind)
       AND (@source_id IS NULL OR e.source_id = @source_id)
       AND (@asset_id IS NULL OR e.asset_id = @asset_id OR e.other_asset_id = @asset_id)
       AND (@search IS NULL OR a.asset_name LIKE N'%' + @search + N'%' OR e.external_key LIKE N'%' + @search + N'%'
            OR a2.asset_name LIKE N'%' + @search + N'%')
     ORDER BY CASE e.exception_kind WHEN N'CONFLICT' THEN 0 WHEN N'DUPLICATE' THEN 1 WHEN N'SUGGESTED_MATCH' THEN 2
                                    WHEN N'MANUAL_REVIEW' THEN 3 ELSE 4 END, e.exception_id DESC
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- Data confidence list. @status: NULL = every asset, or one overall status.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_confidence
    @organization_id BIGINT,
    @status          NVARCHAR(12)  = NULL,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    SELECT c.*, COUNT(*) OVER () AS TotalRows
      FROM grac_practice.fn_asset_discovery_confidence(@organization_id) c
     WHERE (@status IS NULL OR c.OverallStatus = @status)
       AND (@search IS NULL OR c.AssetName LIKE N'%' + @search + N'%' OR c.AssetTypeName LIKE N'%' + @search + N'%')
     ORDER BY CASE c.OverallStatus WHEN N'CONFLICTING' THEN 0 WHEN N'STALE' THEN 1 WHEN N'UNVERIFIED' THEN 2 WHEN N'PROBABLE' THEN 3 ELSE 4 END,
              c.AssetName
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- One asset: 1. confidence  2. source links  3. values per source
-- (with the register value)  4. open exceptions.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_asset_get
    @organization_id BIGINT,
    @asset_id        BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset WHERE asset_id = @asset_id AND organization_id = @organization_id)
        THROW 54777, 'Asset not found for this organization.', 1;
    SELECT * FROM grac_practice.fn_asset_discovery_confidence(@organization_id) WHERE AssetId = @asset_id;
    SELECT l.link_id AS LinkId, l.source_id AS SourceId, s.source_name AS SourceName, l.external_key AS ExternalKey,
           l.identity_score AS IdentityScore, l.link_method AS LinkMethod, l.first_seen_dt AS FirstSeenDt, l.last_seen_dt AS LastSeenDt,
           DATEDIFF(HOUR, l.last_seen_dt, SYSUTCDATETIME()) AS AgeHours, s.expected_interval_hours AS ExpectedIntervalHours
      FROM grac_practice.asset_discovery_link l
      JOIN grac_practice.asset_discovery_source s ON s.source_id = l.source_id
     WHERE l.asset_id = @asset_id
     ORDER BY s.source_name;
    SELECT x.field_key AS FieldKey, f.display_label AS FieldLabel, s.source_name AS SourceName, ISNULL(p.source_role, N'CONTRIBUTING') AS SourceRole,
           x.observed_value AS ObservedValue, x.observed_dt AS ObservedDt, x.applied AS Applied, v.value_text AS RegisterValue
      FROM grac_practice.asset_attribute_source x
      JOIN grac_practice.asset_discovery_source s ON s.source_id = x.source_id
      LEFT JOIN grac_practice.asset_discovery_priority p ON p.source_id = x.source_id AND p.field_key = x.field_key
      LEFT JOIN grac_practice.asset_field_definition f ON f.field_key = x.field_key
      LEFT JOIN grac_practice.asset_field_value v ON v.asset_id = x.asset_id AND v.field_definition_id = f.field_definition_id
     WHERE x.asset_id = @asset_id
     ORDER BY f.display_label, s.source_name;
    SELECT e.exception_id AS ExceptionId, e.exception_kind AS ExceptionKind, e.field_key AS FieldKey, e.current_value AS CurrentValue,
           e.observed_value AS ObservedValue, e.match_score AS MatchScore, e.entered_dt AS RaisedDt
      FROM grac_practice.asset_reconciliation_exception e
     WHERE (e.asset_id = @asset_id OR e.other_asset_id = @asset_id) AND e.status = N'OPEN' AND e.organization_id = @organization_id
     ORDER BY e.exception_id DESC;
END
GO
PRINT '442: readers created.';
GO
