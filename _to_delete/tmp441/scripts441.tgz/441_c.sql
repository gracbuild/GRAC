
-- =====================================================================
-- 4. Writers (D88-D95)
-- =====================================================================
-- Create (Draft) or change a service; @consumers_json replaces the
-- consumers when given: [{"consumerKind":"DEPARTMENT","consumerRefId":3},
-- {"consumerKind":"EXTERNAL","consumerName":"Retail customers"}].
CREATE OR ALTER PROCEDURE grac_practice.sp_business_service_save
    @organization_id             BIGINT,
    @service_id                  BIGINT         = NULL,
    @service_code                NVARCHAR(40)   = NULL,
    @service_name                NVARCHAR(200)  = NULL,
    @service_type                NVARCHAR(16)   = NULL,
    @description                 NVARCHAR(2000) = NULL,
    @customer_outcome            NVARCHAR(1000) = NULL,
    @business_owner_employee_id  BIGINT         = NULL,
    @service_manager_employee_id BIGINT         = NULL,
    @accountable_department_id   BIGINT         = NULL,
    @criticality_id              INT            = NULL,
    @confidentiality_rating      TINYINT        = NULL,
    @integrity_rating            TINYINT        = NULL,
    @availability_rating         TINYINT        = NULL,
    @rto_hours                   DECIMAL(9, 2)  = NULL,
    @rpo_hours                   DECIMAL(9, 2)  = NULL,
    @mtpd_hours                  DECIMAL(9, 2)  = NULL,
    @service_hours               NVARCHAR(200)  = NULL,
    @sla_text                    NVARCHAR(1000) = NULL,
    @data_classification         NVARCHAR(100)  = NULL,
    @privacy_classification      NVARCHAR(100)  = NULL,
    @review_date                 DATE           = NULL,
    @consumers_json              NVARCHAR(MAX)  = NULL,
    @expected_record_version     BIGINT         = NULL,
    @actor_employee_id           BIGINT         = NULL,
    @actor                       NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @service_code = NULLIF(UPPER(LTRIM(RTRIM(@service_code))), N'');
    SET @service_name = NULLIF(LTRIM(RTRIM(@service_name)), N'');
    SET @service_type = UPPER(LTRIM(RTRIM(ISNULL(@service_type, N''))));
    SET @description = NULLIF(LTRIM(RTRIM(@description)), N'');
    SET @customer_outcome = NULLIF(LTRIM(RTRIM(@customer_outcome)), N'');
    SET @service_hours = NULLIF(LTRIM(RTRIM(@service_hours)), N'');
    SET @sla_text = NULLIF(LTRIM(RTRIM(@sla_text)), N'');
    SET @data_classification = NULLIF(LTRIM(RTRIM(@data_classification)), N'');
    SET @privacy_classification = NULLIF(LTRIM(RTRIM(@privacy_classification)), N'');
    SET @consumers_json = NULLIF(LTRIM(RTRIM(@consumers_json)), N'');

    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54730, 'Organization not found.', 1;
    IF @service_code IS NULL OR @service_name IS NULL
        THROW 54733, 'Enter the service ID and the service name.', 1;
    IF EXISTS (SELECT 1 FROM grac_practice.business_service
                WHERE organization_id = @organization_id AND service_id <> ISNULL(@service_id, -1)
                  AND (service_code = @service_code OR service_name = @service_name))
        THROW 54734, 'Another service already uses this service ID or name.', 1;
    IF @service_type NOT IN (N'BUSINESS', N'CUSTOMER_FACING', N'TECHNICAL', N'SHARED', N'SUPPORTING')
        THROW 54735, 'The service type is Business, Customer-facing, Technical, Shared or Supporting.', 1;
    IF (@business_owner_employee_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM grac_practice.organization_employee
            WHERE employee_id = @business_owner_employee_id AND organization_id = @organization_id AND status = N'Active'))
       OR (@service_manager_employee_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM grac_practice.organization_employee
            WHERE employee_id = @service_manager_employee_id AND organization_id = @organization_id AND status = N'Active'))
        THROW 54736, 'The business owner and the service manager must be active employees of the organization.', 1;
    IF @accountable_department_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM grac_practice.organization_department
            WHERE department_id = @accountable_department_id AND organization_id = @organization_id)
        THROW 54737, 'The accountable department must belong to the organization.', 1;
    IF @criticality_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM grac_practice.criticality_master WHERE criticality_id = @criticality_id)
        THROW 54738, 'Select a valid criticality.', 1;
    IF @confidentiality_rating NOT BETWEEN 1 AND 5 OR @integrity_rating NOT BETWEEN 1 AND 5 OR @availability_rating NOT BETWEEN 1 AND 5
        THROW 54739, 'Confidentiality, integrity and availability are rated 1 to 5.', 1;
    IF @rto_hours < 0 OR @rpo_hours < 0 OR @mtpd_hours < 0 OR (@rto_hours IS NOT NULL AND @mtpd_hours IS NOT NULL AND @rto_hours > @mtpd_hours)
        THROW 54740, 'RTO, RPO and MTPD are hours of zero or more, and the RTO cannot exceed the MTPD.', 1;

    DECLARE @cons TABLE (consumer_kind NVARCHAR(18) NOT NULL, consumer_ref_id BIGINT NULL, consumer_name NVARCHAR(200) NULL,
                         note NVARCHAR(400) NULL);
    IF @consumers_json IS NOT NULL
    BEGIN
        IF ISJSON(@consumers_json) = 0 THROW 54749, 'The consumer list is not valid.', 1;
        INSERT @cons (consumer_kind, consumer_ref_id, consumer_name, note)
        SELECT DISTINCT UPPER(LTRIM(RTRIM(ISNULL(j.consumerKind, N'')))), j.consumerRefId, NULLIF(LTRIM(RTRIM(j.consumerName)), N''),
               NULLIF(LTRIM(RTRIM(j.note)), N'')
          FROM OPENJSON(@consumers_json) WITH (consumerKind NVARCHAR(18), consumerRefId BIGINT, consumerName NVARCHAR(200),
                                               note NVARCHAR(400)) j;
        IF EXISTS (SELECT 1 FROM @cons c
                    WHERE NOT ((c.consumer_kind = N'EXTERNAL' AND c.consumer_name IS NOT NULL)
                            OR (c.consumer_kind = N'DEPARTMENT' AND EXISTS (SELECT 1 FROM grac_practice.organization_department d
                                    WHERE d.department_id = c.consumer_ref_id AND d.organization_id = @organization_id))
                            OR (c.consumer_kind = N'BUSINESS_FUNCTION' AND EXISTS (SELECT 1 FROM grac_practice.organization_business_function f
                                    WHERE f.business_function_id = c.consumer_ref_id AND f.organization_id = @organization_id))
                            OR (c.consumer_kind = N'LOCATION' AND EXISTS (SELECT 1 FROM grac_practice.organization_location l
                                    WHERE l.location_id = c.consumer_ref_id AND l.organization_id = @organization_id))))
            THROW 54749, 'Every consumer is a department, business function or location of the organization, or a named external consumer.', 1;
    END

    DECLARE @id BIGINT = @service_id, @result NVARCHAR(20);
    IF @service_id IS NOT NULL
    BEGIN
        DECLARE @found BIT = 0, @status NVARCHAR(10), @rv BIGINT;
        SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version)
          FROM grac_practice.business_service WHERE service_id = @service_id AND organization_id = @organization_id;
        IF @found = 0 THROW 54731, 'Business service not found for this organization.', 1;
        IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
            THROW 54732, 'The service was changed by someone else; reload it and try again.', 1;
        IF @status = N'RETIRED' THROW 54751, 'A retired service is kept for history and cannot be changed.', 1;
    END

    BEGIN TRAN;
    IF @id IS NULL
    BEGIN
        INSERT grac_practice.business_service
            (organization_id, service_code, service_name, service_type, description, customer_outcome, business_owner_employee_id,
             service_manager_employee_id, accountable_department_id, criticality_id, confidentiality_rating, integrity_rating,
             availability_rating, rto_hours, rpo_hours, mtpd_hours, service_hours, sla_text, data_classification,
             privacy_classification, status, review_date, entered_by)
        VALUES (@organization_id, @service_code, @service_name, @service_type, @description, @customer_outcome,
                @business_owner_employee_id, @service_manager_employee_id, @accountable_department_id, @criticality_id,
                @confidentiality_rating, @integrity_rating, @availability_rating, @rto_hours, @rpo_hours, @mtpd_hours,
                @service_hours, @sla_text, @data_classification, @privacy_classification, N'DRAFT', @review_date, @actor);
        SET @id = SCOPE_IDENTITY();
        SET @result = N'CREATED';
    END
    ELSE
    BEGIN
        UPDATE grac_practice.business_service
           SET service_code = @service_code, service_name = @service_name, service_type = @service_type, description = @description,
               customer_outcome = @customer_outcome, business_owner_employee_id = @business_owner_employee_id,
               service_manager_employee_id = @service_manager_employee_id, accountable_department_id = @accountable_department_id,
               criticality_id = @criticality_id, confidentiality_rating = @confidentiality_rating, integrity_rating = @integrity_rating,
               availability_rating = @availability_rating, rto_hours = @rto_hours, rpo_hours = @rpo_hours, mtpd_hours = @mtpd_hours,
               service_hours = @service_hours, sla_text = @sla_text, data_classification = @data_classification,
               privacy_classification = @privacy_classification, review_date = @review_date, version_no = version_no + 1,
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE service_id = @id;
        SET @result = N'SAVED';
    END
    IF @consumers_json IS NOT NULL
    BEGIN
        DELETE FROM grac_practice.business_service_consumer WHERE service_id = @id;
        INSERT grac_practice.business_service_consumer (service_id, consumer_kind, consumer_ref_id, consumer_name, note, entered_by)
        SELECT @id, consumer_kind, CASE WHEN consumer_kind = N'EXTERNAL' THEN NULL ELSE consumer_ref_id END,
               CASE WHEN consumer_kind = N'EXTERNAL' THEN consumer_name END, note, @actor
          FROM @cons;
    END
    EXEC grac_practice.sp_business_service_history_add @service_id = @id, @action_code = @result, @actor = @actor,
         @actor_employee_id = @actor_employee_id;
    COMMIT;
    SELECT @id AS ServiceId, @result AS Result;
END
GO

-- Retires a service (inside the transaction of the caller): status Retired;
-- its current relationships (supporting it, or it supporting others) are
-- retired with a history row (D94).
CREATE OR ALTER PROCEDURE grac_practice.sp_business_service_retire_apply
    @service_id        BIGINT,
    @note              NVARCHAR(1000) = NULL,
    @actor_employee_id BIGINT         = NULL,
    @actor             NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    UPDATE grac_practice.business_service
       SET status = N'RETIRED', retired_dt = SYSUTCDATETIME(), status_note = @note, pending_retirement = 0, pending_by = NULL,
           pending_by_employee_id = NULL, pending_dt = NULL, version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()
     WHERE service_id = @service_id;
    DECLARE @ended TABLE (relationship_id BIGINT NOT NULL);
    UPDATE grac_practice.asset_relationship
       SET status = N'RETIRED', status_note = N'The business service was retired.', version_no = version_no + 1,
           pending_action = NULL, pending_json = NULL, pending_reason = NULL, pending_by = NULL, pending_by_employee_id = NULL,
           pending_dt = NULL,
           effective_to = CASE WHEN effective_to IS NULL OR effective_to > @today THEN
                                   CASE WHEN effective_from > @today THEN effective_from ELSE @today END
                               ELSE effective_to END,
           updated_by = @actor, updated_dt = SYSUTCDATETIME()
    OUTPUT inserted.relationship_id INTO @ended (relationship_id)
     WHERE status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')
       AND ((target_kind = N'SERVICE' AND target_id = @service_id) OR (source_kind = N'SERVICE' AND source_id = @service_id));
    DECLARE @rid BIGINT;
    DECLARE rel_cur CURSOR LOCAL STATIC FOR SELECT relationship_id FROM @ended;
    OPEN rel_cur;
    FETCH NEXT FROM rel_cur INTO @rid;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC grac_practice.sp_asset_relationship_history_add @relationship_id = @rid, @action_code = N'SERVICE_RETIRED',
             @note = N'The business service was retired.', @actor = @actor, @actor_employee_id = @actor_employee_id;
        FETCH NEXT FROM rel_cur INTO @rid;
    END
    CLOSE rel_cur;
    DEALLOCATE rel_cur;
    EXEC grac_practice.sp_business_service_history_add @service_id = @service_id, @action_code = N'RETIRED', @note = @note,
         @actor = @actor, @actor_employee_id = @actor_employee_id;
END
GO

-- Status changes (5.5, 5.5.1; D91-D94):
--   Draft -> Design | Retired;  Design -> Draft | Active | Retired;
--   Active -> Degraded | Suspended | Retiring;  Degraded -> Active | Suspended | Retiring;
--   Suspended -> Active | Retiring;  Retiring -> Active | Retired.
-- To Active: a business owner and the minimum active supporting
-- relationships. To Retired: no active critical relationship relying on the
-- service; from Retiring also the consumer review and contract assessment
-- notes and, where configured, approval by another person (pending).
CREATE OR ALTER PROCEDURE grac_practice.sp_business_service_transition
    @organization_id          BIGINT,
    @service_id               BIGINT,
    @to_status                NVARCHAR(10),
    @note                     NVARCHAR(1000) = NULL,
    @consumer_review_note     NVARCHAR(1000) = NULL,
    @contract_assessment_note NVARCHAR(1000) = NULL,
    @expected_record_version  BIGINT         = NULL,
    @actor_employee_id        BIGINT         = NULL,
    @actor                    NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @to_status = UPPER(LTRIM(RTRIM(ISNULL(@to_status, N''))));
    SET @note = NULLIF(LTRIM(RTRIM(@note)), N'');
    SET @consumer_review_note = NULLIF(LTRIM(RTRIM(@consumer_review_note)), N'');
    SET @contract_assessment_note = NULLIF(LTRIM(RTRIM(@contract_assessment_note)), N'');
    DECLARE @found BIT = 0, @from NVARCHAR(10), @rv BIGINT, @owner BIGINT, @pending BIT, @msg NVARCHAR(1400);
    SELECT @found = 1, @from = status, @rv = CONVERT(BIGINT, record_version), @owner = business_owner_employee_id,
           @pending = pending_retirement
      FROM grac_practice.business_service WHERE service_id = @service_id AND organization_id = @organization_id;
    IF @found = 0 THROW 54731, 'Business service not found for this organization.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 54732, 'The service was changed by someone else; reload it and try again.', 1;
    IF @pending = 1
        THROW 54747, 'The retirement of this service is waiting for approval; approve, reject or withdraw it first.', 1;
    IF CHARINDEX(CONCAT(N'|', @from, N'>', @to_status, N'|'),
                 N'|DRAFT>DESIGN|DRAFT>RETIRED|DESIGN>DRAFT|DESIGN>ACTIVE|DESIGN>RETIRED|ACTIVE>DEGRADED|ACTIVE>SUSPENDED|ACTIVE>RETIRING|'
                 + N'DEGRADED>ACTIVE|DEGRADED>SUSPENDED|DEGRADED>RETIRING|SUSPENDED>ACTIVE|SUSPENDED>RETIRING|RETIRING>ACTIVE|RETIRING>RETIRED|') = 0
    BEGIN
        SET @msg = CONCAT(N'A service cannot move from ', @from, N' to ', @to_status, N'.');
        THROW 54741, @msg, 1;
    END
    IF @note IS NULL AND NOT (@from IN (N'DRAFT', N'DESIGN') AND @to_status IN (N'DESIGN', N'ACTIVE'))
        THROW 54742, 'Enter a note for this status change.', 1;

    DECLARE @min INT = ISNULL((SELECT min_supporting_relationships FROM grac_practice.business_service_setting
                                WHERE organization_id = @organization_id), 1);
    DECLARE @approval BIT = ISNULL((SELECT retirement_approval_required FROM grac_practice.business_service_setting
                                     WHERE organization_id = @organization_id), 1);
    IF @to_status = N'ACTIVE'
    BEGIN
        IF @owner IS NULL THROW 54743, 'Set the business owner before the service becomes Active.', 1;
        DECLARE @support INT = (SELECT COUNT(*) FROM grac_practice.asset_relationship
                                 WHERE organization_id = @organization_id AND relationship_type_code = N'SUPPORTS_SERVICE'
                                   AND target_kind = N'SERVICE' AND target_id = @service_id AND status = N'ACTIVE'
                                   AND effective_from <= CAST(SYSUTCDATETIME() AS DATE)
                                   AND (effective_to IS NULL OR effective_to >= CAST(SYSUTCDATETIME() AS DATE)));
        IF @support < @min
        BEGIN
            SET @msg = CONCAT(N'The service needs at least ', @min, N' active supporting relationship(s) before it becomes Active (it has ',
                              @support, N'). Map its assets, applications, suppliers or child services first.');
            THROW 54744, @msg, 1;
        END
    END
    IF @to_status = N'RETIRED'
    BEGIN
        DECLARE @blockers NVARCHAR(1000) = (
            SELECT LEFT(STRING_AGG(CONCAT(c.CiName, N' (', t.type_name, N')'), N', '), 900)
              FROM grac_practice.fn_asset_relationship_blockers(@organization_id, N'SERVICE', @service_id) b
              JOIN grac_practice.asset_relationship_type t ON t.type_code = b.TypeCode
              LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) c ON c.CiKind = b.DependentKind AND c.CiId = b.DependentId);
        IF @blockers IS NOT NULL
        BEGIN
            SET @msg = CONCAT(N'Active critical dependencies still rely on this service: ', @blockers,
                              N'. Migrate or retire them, or accept them for retirement (Asset Relationships), first.');
            THROW 54745, @msg, 1;
        END
        IF @from = N'RETIRING' AND (@consumer_review_note IS NULL OR @contract_assessment_note IS NULL)
            THROW 54746, 'Record the consumer review and the contract assessment before retiring the service.', 1;
    END

    DECLARE @result NVARCHAR(20);
    BEGIN TRAN;
    IF @to_status = N'RETIRED' AND @from = N'RETIRING' AND @approval = 1
    BEGIN
        UPDATE grac_practice.business_service
           SET pending_retirement = 1, consumer_review_note = @consumer_review_note, contract_assessment_note = @contract_assessment_note,
               status_note = @note, pending_by = @actor, pending_by_employee_id = @actor_employee_id, pending_dt = SYSUTCDATETIME(),
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE service_id = @service_id;
        EXEC grac_practice.sp_business_service_history_add @service_id = @service_id, @action_code = N'RETIRE_REQUEST', @note = @note,
             @actor = @actor, @actor_employee_id = @actor_employee_id;
        SET @result = N'PENDING_APPROVAL';
    END
    ELSE IF @to_status = N'RETIRED'
    BEGIN
        UPDATE grac_practice.business_service
           SET consumer_review_note = ISNULL(@consumer_review_note, consumer_review_note),
               contract_assessment_note = ISNULL(@contract_assessment_note, contract_assessment_note)
         WHERE service_id = @service_id;
        EXEC grac_practice.sp_business_service_retire_apply @service_id = @service_id, @note = @note,
             @actor_employee_id = @actor_employee_id, @actor = @actor;
        SET @result = N'RETIRED';
    END
    ELSE
    BEGIN
        UPDATE grac_practice.business_service
           SET status = @to_status, status_note = @note, version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE service_id = @service_id;
        EXEC grac_practice.sp_business_service_history_add @service_id = @service_id, @action_code = N'STATUS', @note = @note,
             @actor = @actor, @actor_employee_id = @actor_employee_id;
        SET @result = @to_status;
    END
    COMMIT;
    SELECT @service_id AS ServiceId, @result AS Result;
END
GO

-- Decide a pending retirement: APPROVE / REJECT (another person; reject
-- needs a note) or WITHDRAW (the requester). Approval checks the dependants
-- again.
CREATE OR ALTER PROCEDURE grac_practice.sp_business_service_retirement_decide
    @organization_id         BIGINT,
    @service_id              BIGINT,
    @decision                NVARCHAR(10),
    @decision_note           NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @decision = UPPER(LTRIM(RTRIM(ISNULL(@decision, N''))));
    SET @decision_note = NULLIF(LTRIM(RTRIM(@decision_note)), N'');
    DECLARE @found BIT = 0, @pending BIT, @rv BIGINT, @by NVARCHAR(100), @by_emp BIGINT, @note NVARCHAR(1000);
    SELECT @found = 1, @pending = pending_retirement, @rv = CONVERT(BIGINT, record_version), @by = pending_by,
           @by_emp = pending_by_employee_id, @note = status_note
      FROM grac_practice.business_service WHERE service_id = @service_id AND organization_id = @organization_id;
    IF @found = 0 THROW 54731, 'Business service not found for this organization.', 1;
    IF @pending = 0 THROW 54747, 'No retirement of this service is waiting for a decision.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 54732, 'The service was changed by someone else; reload it and try again.', 1;
    IF @decision NOT IN (N'APPROVE', N'REJECT', N'WITHDRAW')
        THROW 54741, 'The decision is Approve, Reject or Withdraw.', 1;
    IF @decision = N'WITHDRAW' AND ISNULL(@by, N'') <> @actor
        THROW 54748, 'Only the person who requested the retirement can withdraw it.', 1;
    IF @decision IN (N'APPROVE', N'REJECT') AND (@by = @actor OR (@by_emp IS NOT NULL AND @by_emp = @actor_employee_id))
        THROW 54748, 'Segregation of duties: the person who requested the retirement cannot approve or reject it.', 1;
    IF @decision = N'REJECT' AND @decision_note IS NULL
        THROW 54742, 'Give the reason for rejecting the retirement.', 1;
    IF @decision = N'APPROVE' AND EXISTS (SELECT 1 FROM grac_practice.fn_asset_relationship_blockers(@organization_id, N'SERVICE', @service_id))
        THROW 54745, 'Active critical dependencies now rely on this service; reject the retirement or clear them first.', 1;

    BEGIN TRAN;
    IF @decision = N'APPROVE'
    BEGIN
        EXEC grac_practice.sp_business_service_retire_apply @service_id = @service_id,
             @note = @note, @actor_employee_id = @actor_employee_id, @actor = @actor;
    END
    ELSE
    BEGIN
        UPDATE grac_practice.business_service
           SET pending_retirement = 0, pending_by = NULL, pending_by_employee_id = NULL, pending_dt = NULL,
               status_note = ISNULL(@decision_note, N'Retirement withdrawn by the requester.'), updated_by = @actor,
               updated_dt = SYSUTCDATETIME()
         WHERE service_id = @service_id;
        EXEC grac_practice.sp_business_service_history_add @service_id = @service_id, @action_code = @decision,
             @note = @decision_note, @actor = @actor, @actor_employee_id = @actor_employee_id;
    END
    COMMIT;
    SELECT @service_id AS ServiceId, CASE @decision WHEN N'APPROVE' THEN N'RETIRED' WHEN N'REJECT' THEN N'REJECTED'
                                                    ELSE N'WITHDRAWN' END AS Result;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_business_service_setting_save
    @organization_id              BIGINT,
    @min_supporting_relationships INT  = 1,
    @retirement_approval_required BIT  = 1,
    @actor                        NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54730, 'Organization not found.', 1;
    IF @min_supporting_relationships IS NULL OR @min_supporting_relationships NOT BETWEEN 0 AND 50
        THROW 54750, 'The minimum supporting relationships is between 0 and 50.', 1;
    DECLARE @before NVARCHAR(MAX) = (SELECT min_supporting_relationships AS minSupportingRelationships,
                                            retirement_approval_required AS retirementApprovalRequired
                                       FROM grac_practice.business_service_setting WHERE organization_id = @organization_id
                                        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    BEGIN TRAN;
    MERGE grac_practice.business_service_setting AS t
    USING (SELECT @organization_id AS organization_id) AS s ON t.organization_id = s.organization_id
    WHEN MATCHED THEN UPDATE SET min_supporting_relationships = @min_supporting_relationships,
        retirement_approval_required = ISNULL(@retirement_approval_required, 1), updated_by = @actor, updated_dt = SYSUTCDATETIME()
    WHEN NOT MATCHED THEN INSERT (organization_id, min_supporting_relationships, retirement_approval_required, updated_by)
        VALUES (@organization_id, @min_supporting_relationships, ISNULL(@retirement_approval_required, 1), @actor);
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'business-service-setting', @organization_id, CASE WHEN @before IS NULL THEN N'CREATE' ELSE N'UPDATE' END, @before,
            (SELECT @min_supporting_relationships AS minSupportingRelationships,
                    ISNULL(@retirement_approval_required, 1) AS retirementApprovalRequired FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @organization_id AS OrganizationId, N'SAVED' AS Result;
END
GO
PRINT '441: writers created.';
GO
