# Builds the 452 report-definition MERGE (section 2 of 452_a.sql).
# (code, family, report name, description, class, view area, proc, available, unavailable reason,
#  filters, status label, status options, date label, default days, brd)
F = {
 'ASSET': ('Asset', 'sp_asset_report_asset'),
 'ATTESTATION': ('Attestation', 'sp_asset_report_attestation'),
 'CMDB': ('CMDB and Service', 'sp_asset_report_cmdb'),
 'DISCOVERY': ('Discovery and Data Quality', 'sp_asset_report_discovery'),
 'CONTRACT': ('Contract', 'sp_asset_report_contract'),
 'TECHNOLOGY': ('Technology', 'sp_asset_report_technology'),
 'RISK': ('Risk and CIA', 'sp_asset_report_risk'),
 'GOVERNANCE': ('Governance', 'sp_asset_report_governance'),
 'PRIVACY': ('Privacy and Compliance', 'sp_asset_report_privacy'),
}
REG, ATT, REL, SVC, DSC, CON, GOV, PRV, ACT, RSK = ('asset-register', 'asset-attestation', 'asset-relationships',
    'business-services', 'asset-discovery', 'asset-contracts', 'asset-governance', 'asset-privacy', 'asset-activities',
    'risk-centre-register')
S, ST, AT, DR, DY = 'SEARCH', 'STATUS', 'ASSET_TYPE', 'DATE_RANGE', 'DAYS'
def f(*k): return ','.join(k)
ATT_STATUS = 'GENERATED=Generated|PENDING=Pending|IN_PROGRESS=In progress|OVERDUE=Overdue|ESCALATED=Escalated|CONFIRMED=Confirmed|DISPUTED=Disputed|EXCEPTION=Exception|RESOLVED=Resolved|CLOSED=Closed|CANCELLED=Cancelled'
VEX_STATUS = 'OPEN=Open|ASSIGNED=Assigned|UNDER_REVIEW=Under Review|AWAITING_EVIDENCE=Awaiting Evidence|AWAITING_APPROVAL=Awaiting Approval|RESOLVED=Resolved|CLOSED=Closed|CANCELLED=Cancelled'
REL_STATUS = 'PROPOSED=Proposed|ACTIVE=Active|DISPUTED=Disputed|INACTIVE=Inactive|RETIRED=Retired'
TECH_CLASS = 'CURRENT=Current|DUE_SOON=Due soon|UNSUPPORTED=Unsupported|EXCEPTION=Exception|UNKNOWN=Unknown'
OUTCOME = 'PASS=Pass|FAIL=Fail|EXCLUDED=Excluded'
CON_STATUS = 'DRAFT=Draft|APPROVED=Approved|ACTIVE=Active|EXPIRED=Expired|TERMINATED=Terminated'
R = [
 # ---- Asset
 ('ASSET_REGISTER', 'ASSET', 'Complete Asset Register', 'Every asset record of the organization with category, type, lifecycle status and phase, owner, location, criticality, Asset Value, coverage status and whether it is in use. Same status rule and search (name, ID, alias) as the Asset Register.', 'INTERNAL', REG, 1, None, f(S, ST, AT), 'Lifecycle status', '@ASSET_STATUS', None, None, '13.4 Asset'),
 ('ASSET_OWNERSHIP', 'ASSET', 'Ownership and Custody', 'The current assignment of each asset: owner, custodian (person or team), department, site, building, floor, room and since when. Status picks assets with no owner, no custodian or both recorded.', 'CONFIDENTIAL', REG, 1, None, f(S, ST, AT), 'Assignment', 'NO_OWNER=No owner|NO_CUSTODIAN=No custodian|ASSIGNED=Owner and custodian recorded', None, None, '13.4 Asset'),
 ('ASSET_LIFECYCLE', 'ASSET', 'Lifecycle Status', 'Each asset with its lifecycle status and phase, the date it entered that status, days in status and the lifecycle change awaiting approval (target status, requested by and when).', 'INTERNAL', REG, 1, None, f(S, ST, AT), 'Lifecycle status', '@ASSET_STATUS', None, None, '13.4 Asset'),
 ('ASSET_MISSING_DATA', 'ASSET', 'Missing Mandatory Data', 'Assets in use whose asset form has mandatory fields left empty, evaluated now by the form engine (the Metadata Completeness rule): how many of the mandatory fields are empty and which.', 'INTERNAL', REG, 1, None, f(S, AT), None, None, None, None, '13.4 Asset'),
 ('ASSET_MOVEMENT', 'ASSET', 'Asset Movement', 'Assignment history: every change of owner, custodian, department or place with the previous site, effective dates and who recorded it. Dates filter the effective-from date.', 'CONFIDENTIAL', REG, 1, None, f(S, AT, DR), None, None, 'Effective from', None, '13.4 Asset'),
 ('ASSET_DISPOSAL', 'ASSET', 'Disposal and Sanitization', 'Assets on the way out or disposed (Pending Decommission, Sanitization Pending, Disposal Approval, Disposed, Archived) with deletion / sanitization required, method, date, evidence and what is still missing.', 'CONFIDENTIAL', REG, 1, None, f(S, ST, AT), 'Lifecycle status', 'PENDING_DECOMMISSION=Pending Decommission|SANITIZATION_PENDING=Sanitization Pending|DISPOSAL_APPROVAL=Disposal Approval|DISPOSED=Disposed|ARCHIVED=Archived', None, None, '13.4 Asset'),
 # ---- Attestation
 ('ATT_COMPLIANCE', 'ATTESTATION', 'Attestation Compliance', 'Attestation occurrences with their display status (open and past due = Overdue) and whether each counts as compliant (Confirmed, Resolved or Closed; Cancelled is excluded), the Attestation Compliance KPI rule. Dates filter the due date.', 'INTERNAL', ATT, 1, None, f(S, ST, AT, DR), 'Display status', ATT_STATUS, 'Due date', None, '13.4 Attestation'),
 ('ATT_OVERDUE', 'ATTESTATION', 'Overdue Attestations', 'Open attestations past their due date (and escalated ones) with the assignee, due date and days overdue.', 'INTERNAL', ATT, 1, None, f(S, AT), None, None, None, None, '13.4 Attestation'),
 ('ATT_EXCEPTIONS', 'ATTESTATION', 'Disagreement and Exception Register', 'Verification exceptions raised from attestation disagreements: category, severity, investigator, status, SLA dates, outcome and resolution. Dates filter the reported date.', 'CONFIDENTIAL', ATT, 1, None, f(S, ST, AT, DR), 'Exception status', VEX_STATUS, 'Reported', None, '13.4 Attestation'),
 ('ATT_LOST_DAMAGED', 'ATTESTATION', 'Lost/Damaged Assets', 'Verification exceptions for assets not found, lost or damaged, and exceptions closed with loss or damage confirmed, with the current lifecycle status of the asset and the lost-asset security review.', 'CONFIDENTIAL', ATT, 1, None, f(S, ST, AT), 'Exception', 'OPEN=Not closed|CONFIRMED=Loss or damage confirmed', None, None, '13.4 Attestation'),
 ('ATT_SLA', 'ATTESTATION', 'SLA Breach and Ageing', 'Open verification exceptions with age, start and resolution due dates, days overdue and escalation level (5.3.9 levels).', 'INTERNAL', ATT, 1, None, f(S, ST, AT), 'SLA', 'BREACHED=Start or resolution overdue|ON_TRACK=Within SLA', None, None, '13.4 Attestation'),
 # ---- CMDB and Service
 ('CMDB_RELATIONSHIPS', 'CMDB', 'Asset Relationships', 'Every CMDB relationship: source, relationship type, target, critical flag and dependency criticality, status, effective dates, source of the record, confidence, verification and owner.', 'INTERNAL', REL, 1, None, f(S, ST), 'Relationship status', REL_STATUS, None, None, '13.4 CMDB and Service'),
 ('CMDB_ORPHANS', 'CMDB', 'Orphan Assets', 'Assets in use with no relationship (proposed, active or disputed) on either side.', 'INTERNAL', REL, 1, None, f(S, AT), None, None, None, None, '13.4 CMDB and Service'),
 ('CMDB_TOPOLOGY', 'CMDB', 'Business Service Topology', 'Business services with the items that support them (Supports Service relationships): item kind and name, relationship status, critical flag and dependency criticality; services with no supporting item are listed once.', 'INTERNAL', SVC, 1, None, f(S, ST), 'Service status', 'DRAFT=Draft|DESIGN=Design|ACTIVE=Active|DEGRADED=Degraded|SUSPENDED=Suspended|RETIRING=Retiring|RETIRED=Retired', None, None, '13.4 CMDB and Service'),
 ('CMDB_CRITICAL', 'CMDB', 'Critical Dependencies', 'Active relationships marked critical or with a Critical / High dependency criticality.', 'INTERNAL', REL, 1, None, f(S, ST), 'Dependency criticality', 'CRITICAL=Critical|HIGH=High|MEDIUM=Medium|LOW=Low', None, None, '13.4 CMDB and Service'),
 ('CMDB_SERVICE_IMPACT', 'CMDB', 'Service Impact', 'Upstream and downstream impact of one configuration item.', 'INTERNAL', SVC, 0, 'Shown per service in Business Services (Service impact); a catalogue report needs one item chosen first.', 'SEARCH', None, None, None, None, '13.4 CMDB and Service'),
 ('CMDB_QUALITY', 'CMDB', 'Relationship Data Quality', 'One row per relationship issue: disputed, awaiting approval, active but unverified, active past its end date, active with an endpoint that is no longer usable, a change awaiting approval, confidence below 50.', 'INTERNAL', REL, 1, None, f(S, ST), 'Issue', 'DISPUTED=Disputed|PROPOSED=Awaiting approval|UNVERIFIED=Active, unverified|EXPIRED=Active past end date|UNUSABLE=Endpoint not usable|PENDING_CHANGE=Change awaiting approval|LOW_CONFIDENCE=Confidence below 50', None, None, '13.4 CMDB and Service'),
 # ---- Discovery and Data Quality
 ('DSC_COVERAGE', 'DISCOVERY', 'Discovery Coverage', 'Data confidence of every asset not disposed or archived: discovery links, fresh links, identity score, last observed, open conflicts, attribute disagreements, last verified date and the overall confidence.', 'INTERNAL', DSC, 1, None, f(S, ST, AT), 'Data confidence', 'VERIFIED=Verified|PROBABLE=Probable|UNVERIFIED=Unverified|STALE=Stale|CONFLICTING=Conflicting', None, None, '13.4 Discovery and Data Quality'),
 ('DSC_STALE', 'DISCOVERY', 'Stale Assets', 'Assets on the stale list (unseen by every source longer than the aging rule, or with an open stale review): last observed, days unseen and the open review.', 'INTERNAL', DSC, 1, None, f(S, AT), None, None, None, None, '13.4 Discovery and Data Quality'),
 ('DSC_SOURCES', 'DISCOVERY', 'Source Health', 'Discovery sources with their health (Never run, Failed, Warning, Success; the source list rule) and the batches received in the last N days: count, records, updated, exceptions and errors.', 'INTERNAL', DSC, 1, None, f(S, ST, DY), 'Health', 'NEVER=Never run|FAILED=Failed|WARNING=Warning|SUCCESS=Success', None, 30, '13.4 Discovery and Data Quality'),
 ('DSC_RECON', 'DISCOVERY', 'Reconciliation Queue', 'Open reconciliation exceptions of every kind with the source, external key, asset, field, current and observed values, match score and age.', 'INTERNAL', DSC, 1, None, f(S, ST), 'Kind', 'SUGGESTED_MATCH=Suggested match|MANUAL_REVIEW=Manual review|NEW_CANDIDATE=New candidate|DUPLICATE=Duplicate|CONFLICT=Conflict', None, None, '13.4 Discovery and Data Quality'),
 ('DSC_CONFLICTS', 'DISCOVERY', 'Conflicts', 'Open attribute conflicts: asset, field, current and observed value, source and age.', 'INTERNAL', DSC, 1, None, f(S), None, None, None, None, '13.4 Discovery and Data Quality'),
 ('DSC_DUPLICATES', 'DISCOVERY', 'Potential Duplicates', 'Open potential-duplicate exceptions: the two assets, match score, source and age.', 'INTERNAL', DSC, 1, None, f(S), None, None, None, None, '13.4 Discovery and Data Quality'),
 ('DSC_MERGE_SPLIT', 'DISCOVERY', 'Merge/Split History', 'Merge and split events: kind, surviving asset, member count, status, reason, requested, executed and recovered. Dates filter the requested date.', 'INTERNAL', DSC, 1, None, f(S, ST, DR), 'Event status', 'DRAFT=Draft|PENDING_APPROVAL=Pending approval|APPROVED=Approved|EXECUTED=Executed|RECOVERED=Recovered|REJECTED=Rejected|CANCELLED=Cancelled', 'Requested', None, '13.4 Discovery and Data Quality'),
 # ---- Contract
 ('CON_EXPIRY', 'CONTRACT', 'Expiry and Notice Calendar', 'Contracts whose version in force ends, or whose notice or decision date falls, within the next N days (or has passed while the contract is still Active / Approved), with days to end, owner and value.', 'INTERNAL', CON, 1, None, f(S, ST, DY), 'Contract status', CON_STATUS, None, 90, '13.4 Contract'),
 ('CON_RENEWALS', 'CONTRACT', 'Renewal Forecast', 'Open renewals: contract, renewal type, status, due date, current and proposed expiry, renewal value and currency. Dates filter the due date.', 'INTERNAL', CON, 1, None, f(S, ST, DR), 'Renewal type', 'RENEWAL=Renewal|EXTENSION=Extension|REBID=Rebid|REPLACEMENT=Replacement|NON_RENEWAL=Non-renewal', 'Due date', None, '13.4 Contract'),
 ('CON_COVERAGE_GAPS', 'CONTRACT', 'Coverage Gaps', 'Assets missing coverage their asset type requires, or covered for less than the minimum period (the coverage requirement rule).', 'INTERNAL', CON, 1, None, f(S, ST, AT), 'Gap', 'MISSING=Missing|SHORT=Shorter than the minimum period', None, None, '13.4 Contract'),
 ('CON_ENTITLEMENTS', 'CONTRACT', 'Entitlements', 'Entitlement lines of the version in force of each contract: product / SKU, coverage type, quantity, service level, support hours, dates and exclusions.', 'INTERNAL', CON, 1, None, f(S, ST), 'Contract status', CON_STATUS, None, None, '13.4 Contract'),
 ('CON_CONTACTS', 'CONTRACT', 'Vendor Contact Matrix', 'Vendor contacts mapped to contracts: role, contact, email, primary, preferred channel, notifications, dates and mapping status.', 'CONFIDENTIAL', CON, 1, None, f(S, ST), 'Mapping status', 'ACTIVE=Active|PENDING_VALIDATION=Pending validation|INACTIVE=Inactive', None, None, '13.4 Contract'),
 ('CON_VERSION_COMPARE', 'CONTRACT', 'Version Comparison', 'Field-by-field comparison of two contract versions.', 'INTERNAL', CON, 0, 'Asset Contracts -> a contract -> Compare versions, which has its own CSV export; it compares two chosen versions.', 'SEARCH', None, None, None, None, '13.4 Contract'),
 # ---- Technology
 ('TECH_UNSUPPORTED', 'TECHNOLOGY', 'Unsupported Assets', 'Assets in use running firmware or an operating system that is unsupported (end of support / life, withdrawn, or not approved for the model), including those covered by an approved technology exception.', 'INTERNAL', REG, 1, None, f(S, ST, AT), 'Classification', 'UNSUPPORTED=Unsupported|EXCEPTION=Exception', None, None, '13.4 Technology'),
 ('TECH_DUE_SOON', 'TECHNOLOGY', 'Support Ending Soon', 'Assets in use whose firmware or operating system is deprecated / approaching end of support, or whose support ends within the next N days.', 'INTERNAL', REG, 1, None, f(S, AT, DY), None, None, None, 180, '13.4 Technology'),
 ('TECH_FIRMWARE', 'TECHNOLOGY', 'Firmware Compliance', 'Firmware of every asset in use whose form records firmware: current version, release status, support end, recommended target and classification.', 'INTERNAL', REG, 1, None, f(S, ST, AT), 'Classification', TECH_CLASS, None, None, '13.4 Technology'),
 ('TECH_OS', 'TECHNOLOGY', 'OS Compliance', 'Operating system of every asset in use whose form records one: current release, status, support end, recommended target and classification.', 'INTERNAL', REG, 1, None, f(S, ST, AT), 'Classification', TECH_CLASS, None, None, '13.4 Technology'),
 ('TECH_UNKNOWN', 'TECHNOLOGY', 'Unknown Versions', 'Assets in use whose form has a firmware or operating-system field but no version recorded.', 'INTERNAL', REG, 1, None, f(S, AT), None, None, None, None, '13.4 Technology'),
 ('TECH_REFRESH', 'TECHNOLOGY', 'Refresh Campaign Progress', 'Progress of a technology refresh campaign.', 'INTERNAL', REG, 0, 'The module has no technology refresh campaign; unsupported and ending-soon assets are listed by the reports above.', 'SEARCH', None, None, None, None, '13.4 Technology'),
 # ---- Risk and CIA
 ('RISK_CIA', 'RISK', 'CIA Classification', 'Confidentiality, integrity and availability of each asset with the valuation method, Asset Value score and category and the validation status (no result = Not rated).', 'INTERNAL', REG, 1, None, f(S, ST, AT), 'Validation', 'VALID=Valid|INCOMPLETE=Incomplete|INVALID=Invalid|NOT_RATED=Not rated', None, None, '13.4 Risk and CIA'),
 ('RISK_VALUE_DIST', 'RISK', 'Asset Value Distribution', 'Assets per Asset Value category (valid results; the rest as Not rated / Incomplete / Invalid) with share, lowest and highest score.', 'INTERNAL', REG, 1, None, f(AT), None, None, None, None, '13.4 Risk and CIA'),
 ('RISK_INHERENT_RESIDUAL', 'RISK', 'Inherent/Residual Risk', 'Registered risks linked to assets: risk number, title, status, inherent and residual rating, the linked asset and its Asset Value, and whether a review is suggested because an Asset Value changed after the last assessment.', 'CONFIDENTIAL', RSK, 1, None, f(S, AT), None, None, None, None, '13.4 Risk and CIA'),
 ('RISK_TREATMENT', 'RISK', 'Risk Treatment', 'Treatment plans of asset risks.', 'CONFIDENTIAL', RSK, 0, 'Risk treatment integration is out of scope for this module; treatments are reported in the Risk Centre.', 'SEARCH', None, None, None, None, '13.4 Risk and CIA'),
 ('RISK_ACCEPTED', 'RISK', 'Accepted Risk and Expiry', 'Accepted asset risks and their acceptance expiry.', 'CONFIDENTIAL', RSK, 0, 'Risk acceptance is reported in the Risk Centre (Accept Risk, Review Risk).', 'SEARCH', None, None, None, None, '13.4 Risk and CIA'),
 # ---- Governance
 ('GOV_SCORE', 'GOVERNANCE', 'Governance Score', 'Governance snapshots: as-of date, version, overall score, rating, target and warning thresholds, source and who took it. Dates filter the as-of date.', 'INTERNAL', GOV, 1, None, f(ST, DR), 'Rating', 'GREEN=On target|AMBER=Warning|RED=Below threshold|NA=Not applicable', 'As of', None, '13.4 Governance'),
 ('GOV_COMPONENTS', 'GOVERNANCE', 'Metric Components', 'The KPIs of the latest governance snapshot: numerator, denominator, excluded, failing, score, rating, thresholds, weight and direction.', 'INTERNAL', GOV, 1, None, f(ST), 'Rating', 'GREEN=On target|AMBER=Warning|RED=Below threshold|NA=Not applicable', None, None, '13.4 Governance'),
 ('GOV_METADATA', 'GOVERNANCE', 'Metadata Completeness', 'Record-level detail of the Metadata Completeness KPI in the latest snapshot: outcome, numerator, denominator and reason.', 'INTERNAL', GOV, 1, None, f(S, ST), 'Outcome', OUTCOME, None, None, '13.4 Governance'),
 ('GOV_OWNERSHIP', 'GOVERNANCE', 'Ownership Completeness', 'Record-level detail of the Ownership Completeness KPI in the latest snapshot.', 'INTERNAL', GOV, 1, None, f(S, ST), 'Outcome', OUTCOME, None, None, '13.4 Governance'),
 ('GOV_COVERAGE', 'GOVERNANCE', 'Coverage Compliance', 'Record-level detail of the Coverage Compliance KPI in the latest snapshot.', 'INTERNAL', GOV, 1, None, f(S, ST), 'Outcome', OUTCOME, None, None, '13.4 Governance'),
 ('GOV_EXCEPTION', 'GOVERNANCE', 'Exception Health', 'Record-level detail of the Exception Health KPI in the latest snapshot.', 'INTERNAL', GOV, 1, None, f(S, ST), 'Outcome', OUTCOME, None, None, '13.4 Governance'),
 # ---- Privacy and Compliance
 ('PRV_PERSONAL_DATA', 'PRIVACY', 'Personal-Data Assets', 'Assets that process personal data (Yes or Unknown): privacy owner, assessment status, review date, retention end, legal hold, privacy status and the failed / missing / partial / excepted requirement counts.', 'CONFIDENTIAL', PRV, 1, None, f(S, ST, AT), 'Privacy status', 'COMPLIANT=Compliant|CONDITIONAL=Conditional|INCOMPLETE=Incomplete|NON_COMPLIANT=Non-compliant', None, None, '13.4 Privacy and Compliance'),
 ('PRV_DPIA', 'PRIVACY', 'DPIA/PIA', 'Personal-data assets with high-risk processing, special-category / health and children data, DPIA / PIA required and status, the privacy assessment and the DPIA gaps.', 'CONFIDENTIAL', PRV, 1, None, f(S, ST, AT), 'DPIA gap', 'GAP=Has a DPIA gap|NO_GAP=No DPIA gap', None, None, '13.4 Privacy and Compliance'),
 ('PRV_MASK_ENC', 'PRIVACY', 'Masking/Encryption Gaps', 'Masking and encryption gaps of personal-data assets: requirement, gap kind, message, enforcement and the approved exception covering it.', 'CONFIDENTIAL', PRV, 1, None, f(S, ST, AT), 'Requirement', 'MASKING=Masking|ENCRYPTION=Encryption', None, None, '13.4 Privacy and Compliance'),
 ('PRV_RETENTION', 'PRIVACY', 'Retention/Deletion', 'Personal-data assets with a retention end: policy, period, trigger, legal hold, retention end, days left, the open retention review and the last completed decision.', 'CONFIDENTIAL', PRV, 1, None, f(S, ST, AT, DY), 'Retention', 'ENDED=Retention ended|ENDING=Ends within N days', None, 90, '13.4 Privacy and Compliance'),
 ('PRV_EVIDENCE', 'PRIVACY', 'Evidence Expiry', 'Evidence and certificate dates (calibration, insurance, fitness, pollution, permit, registration, road tax) of assets in use that have expired or expire within the next N days.', 'INTERNAL', ACT, 1, None, f(S, ST, AT, DY), 'Expiry', 'EXPIRED=Expired|EXPIRING=Expires within N days', None, 60, '13.4 Privacy and Compliance'),
 ('PRV_FRAMEWORK', 'PRIVACY', 'Framework/Practice Status', 'Compliance framework and practice status of the assets.', 'INTERNAL', PRV, 0, 'Framework and practice status is reported by the Governance and practice dashboards, outside the asset module.', 'SEARCH', None, None, None, None, '13.4 Privacy and Compliance'),
]
def q(v):
    if v is None: return 'NULL'
    if isinstance(v, int): return str(v)
    assert "'" not in v and '--' not in v, v
    return "N'" + v + "'"
rows = []
order = {}
for i, r in enumerate(R):
    code, fam, name, desc, cls, area, avail, why, fk, sl, so, dl, dd, brd = r
    fname, proc = F[fam]
    order[fam] = order.get(fam, 0) + 1
    fo = list(F).index(fam) + 1
    rows.append('    (' + ', '.join([q(code), q(fam), q(fname), q(name), q(desc), q(cls), q(area), q(proc), str(avail), q(why),
                                   q(fk), q(sl), q(so), q(dl), q(dd), str(fo * 100 + order[fam] * 10), q(brd)]) + ')')
cols = ('report_code, family_code, family_name, report_name, description, default_classification, view_area, proc_name, '
        'is_available, unavailable_reason, filter_keys, status_label, status_options, date_label, default_days, display_order, brd_reference')
cmp = [c.strip() for c in cols.split(',')[1:]]
out = """-- =====================================================================
-- 2. The standard reports (13.4). A changed definition gets the next
--    version number; reports the module cannot produce are listed as not
--    available with the place they live today (D196).
-- =====================================================================
MERGE grac_practice.asset_report_definition AS t
USING (VALUES
""" + ',\n'.join(rows) + """
) AS s(""" + cols + """)
ON t.report_code = s.report_code
WHEN MATCHED AND (t.is_active = 0 OR EXISTS (SELECT """ + ', '.join('s.' + c for c in cmp) + """
                                         EXCEPT SELECT """ + ', '.join('t.' + c for c in cmp) + """)) THEN UPDATE SET
    """ + ', '.join(f'{c} = s.{c}' for c in cmp) + """,
    version_no = t.version_no + CASE WHEN EXISTS (SELECT """ + ', '.join('s.' + c for c in cmp) + """
                                                  EXCEPT SELECT """ + ', '.join('t.' + c for c in cmp) + """) THEN 1 ELSE 0 END,
    is_active = 1, updated_by = N'seed-452', updated_dt = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (""" + cols + """, entered_by)
    VALUES (""" + ', '.join('s.' + c.strip() for c in cols.split(',')) + """, N'seed-452');
PRINT CONCAT('452: report definitions upserted: ', @@ROWCOUNT);
GO
"""
open('/home/claude/w452/452_a2.sql', 'w').write(out)
print(len(R), 'reports', sum(1 for r in R if r[6]), 'available')
