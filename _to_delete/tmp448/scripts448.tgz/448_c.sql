-- =====================================================================
-- 5. Sync: reviews and exception expiry (scheduler, form save, run now)
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_privacy_sync
    @organization_id BIGINT,
    @asset_id        BIGINT        = NULL,
    @actor           NVARCHAR(100) = N'system',
    @out_opened      INT           = NULL OUTPUT,
    @out_closed      INT           = NULL OUTPUT,
    @out_expired     INT           = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SELECT @out_opened = 0, @out_closed = 0, @out_expired = 0;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    -- Which reviews should be open: privacy review date (assets in use) and
    -- retention end (any status), unless a completed review already covers it.
    DECLARE @want TABLE (asset_id BIGINT NOT NULL, review_kind NVARCHAR(10) COLLATE DATABASE_DEFAULT NOT NULL, due_date DATE NOT NULL,
                         PRIMARY KEY (asset_id, review_kind));
    INSERT @want (asset_id, review_kind, due_date)
    SELECT v.AssetId, N'PRIVACY', v.rdate
      FROM grac_practice.fn_asset_privacy_values(@organization_id, @asset_id) v
     WHERE v.pd IN (N'YES', N'UNKNOWN') AND v.rdate IS NOT NULL
       AND ISNULL(v.StatusCode, N'') NOT IN (N'DISPOSED', N'ARCHIVED')
    UNION ALL
    SELECT v.AssetId, N'RETENTION', rt.RetentionDueDate
      FROM grac_practice.fn_asset_privacy_values(@organization_id, @asset_id) v
     CROSS APPLY grac_practice.fn_asset_privacy_retention_calc(@organization_id, v.AssetId, v.rper, v.rtrg, v.RegisteredDate, v.psc) rt
     WHERE v.pd IN (N'YES', N'UNKNOWN') AND rt.RetentionDueDate IS NOT NULL;
    DELETE w
      FROM @want w
     WHERE EXISTS (SELECT 1 FROM grac_practice.asset_privacy_review r
                    WHERE r.asset_id = w.asset_id AND r.review_kind = w.review_kind AND r.status = N'COMPLETED'
                      AND r.due_date >= w.due_date);

    BEGIN TRAN;
    UPDATE grac_practice.asset_privacy_exception
       SET status = N'EXPIRED', closed_dt = SYSUTCDATETIME()
     WHERE organization_id = @organization_id AND (@asset_id IS NULL OR asset_id = @asset_id)
       AND status = N'APPROVED' AND expiry_date < @today;
    SET @out_expired = @@ROWCOUNT;

    UPDATE r
       SET status = N'CANCELLED', cancel_reason = N'No longer due: the privacy review date, retention fields or applicability changed.',
           updated_by = @actor, updated_dt = SYSUTCDATETIME()
      FROM grac_practice.asset_privacy_review r
     WHERE r.organization_id = @organization_id AND (@asset_id IS NULL OR r.asset_id = @asset_id) AND r.status = N'OPEN'
       AND NOT EXISTS (SELECT 1 FROM @want w WHERE w.asset_id = r.asset_id AND w.review_kind = r.review_kind);
    SET @out_closed = @@ROWCOUNT;

    UPDATE r
       SET due_date = w.due_date, updated_by = @actor, updated_dt = SYSUTCDATETIME()
      FROM grac_practice.asset_privacy_review r
      JOIN @want w ON w.asset_id = r.asset_id AND w.review_kind = r.review_kind
     WHERE r.status = N'OPEN' AND r.due_date <> w.due_date;

    INSERT grac_practice.asset_privacy_review (organization_id, asset_id, review_kind, due_date, status, entered_by)
    SELECT @organization_id, w.asset_id, w.review_kind, w.due_date, N'OPEN', @actor
      FROM @want w
     WHERE NOT EXISTS (SELECT 1 FROM grac_practice.asset_privacy_review r
                        WHERE r.asset_id = w.asset_id AND r.review_kind = w.review_kind AND r.status = N'OPEN');
    SET @out_opened = @@ROWCOUNT;
    COMMIT;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_privacy_run
    @organization_id BIGINT,
    @asset_id        BIGINT        = NULL,
    @actor           NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53050, 'Organization not found.', 1;
    DECLARE @o INT, @c INT, @x INT;
    EXEC grac_practice.sp_asset_privacy_sync @organization_id = @organization_id, @asset_id = @asset_id, @actor = @actor,
         @out_opened = @o OUTPUT, @out_closed = @c OUTPUT, @out_expired = @x OUTPUT;
    SELECT @organization_id AS OrganizationId,
           CONCAT(@o, N' review(s) opened, ', @c, N' closed, ', @x, N' exception(s) expired') AS Result;
END
GO
PRINT '448: privacy sync created.';
GO

-- =====================================================================
-- 6. Requirement settings (5.2.15)
-- =====================================================================
-- Requirements with settings, overrides, asset types and employees (the
-- configuration of the Asset Privacy screen).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_privacy_requirements
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    -- 1. Catalogue with the organization setting
    SELECT q.requirement_code AS RequirementCode, q.requirement_name AS RequirementName, q.description AS Description,
           q.brd_reference AS BrdReference, q.default_enforcement AS DefaultEnforcement, q.block_target AS BlockTarget,
           s.enforcement AS OrgEnforcement, ISNULL(s.enforcement, q.default_enforcement) AS EffectiveEnforcement,
           ISNULL(s.exception_allowed, 1) AS ExceptionAllowed, s.max_exception_days AS MaxExceptionDays,
           s.updated_by AS UpdatedBy, COALESCE(s.updated_dt, s.entered_dt) AS UpdatedDt
      FROM grac_practice.asset_privacy_requirement q
      LEFT JOIN grac_practice.asset_privacy_setting s
             ON s.organization_id = @organization_id AND s.asset_type_id IS NULL AND s.requirement_code = q.requirement_code
     ORDER BY q.display_order;
    -- 2. Asset-type overrides
    SELECT s.setting_id AS SettingId, s.asset_type_id AS AssetTypeId, t.asset_type_name AS AssetTypeName,
           s.requirement_code AS RequirementCode, q.requirement_name AS RequirementName, s.enforcement AS Enforcement,
           s.exception_allowed AS ExceptionAllowed, s.max_exception_days AS MaxExceptionDays
      FROM grac_practice.asset_privacy_setting s
      JOIN grac_practice.asset_privacy_requirement q ON q.requirement_code = s.requirement_code
      LEFT JOIN grac_practice.dependency_asset_type_master t ON t.asset_type_id = s.asset_type_id
     WHERE s.organization_id = @organization_id AND s.asset_type_id IS NOT NULL
     ORDER BY t.asset_type_name, q.display_order;
    -- 3. Asset types for an override
    SELECT t.asset_type_id AS AssetTypeId, t.asset_type_name AS AssetTypeName
      FROM grac_practice.dependency_asset_type_master t
     WHERE t.is_active = 1
     ORDER BY t.asset_type_name;
    -- 4. Active employees (exception owners)
    SELECT e.employee_id AS EmployeeId, e.employee_name AS EmployeeName
      FROM grac_practice.organization_employee e
     WHERE e.organization_id = @organization_id AND e.status = N'Active'
     ORDER BY e.employee_name;
END
GO

-- Organization row (asset type NULL) or asset-type override; enforcement
-- NULL removes the row (back to the organization / catalogue default).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_privacy_setting_save
    @organization_id    BIGINT,
    @asset_type_id      INT           = NULL,
    @requirement_code   NVARCHAR(30),
    @enforcement        NVARCHAR(10)  = NULL,
    @exception_allowed  BIT           = 1,
    @max_exception_days INT           = NULL,
    @actor              NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @requirement_code = UPPER(LTRIM(RTRIM(ISNULL(@requirement_code, N''))));
    SET @enforcement = NULLIF(UPPER(LTRIM(RTRIM(@enforcement))), N'');
    SET @exception_allowed = ISNULL(@exception_allowed, 1);
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53050, 'Organization not found.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_privacy_requirement WHERE requirement_code = @requirement_code)
        THROW 53052, 'Unknown privacy requirement.', 1;
    IF @enforcement IS NOT NULL AND @enforcement NOT IN (N'OFF', N'WARN', N'BLOCK')
        THROW 53053, 'Choose Off, Warn or Block.', 1;
    IF @max_exception_days IS NOT NULL AND @max_exception_days NOT BETWEEN 1 AND 1095
        THROW 53053, 'The longest exception must be between 1 and 1095 days.', 1;
    IF @asset_type_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM grac_practice.dependency_asset_type_master WHERE asset_type_id = @asset_type_id)
        THROW 53054, 'Asset type not found.', 1;

    DECLARE @before NVARCHAR(MAX) = (SELECT s.enforcement AS enforcement, s.exception_allowed AS exceptionAllowed, s.max_exception_days AS maxExceptionDays
                                       FROM grac_practice.asset_privacy_setting s
                                      WHERE s.organization_id = @organization_id AND s.requirement_code = @requirement_code
                                        AND ISNULL(s.asset_type_id, -1) = ISNULL(@asset_type_id, -1)
                                        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @id BIGINT;
    BEGIN TRAN;
    IF @enforcement IS NULL
    BEGIN
        DELETE FROM grac_practice.asset_privacy_setting
         WHERE organization_id = @organization_id AND requirement_code = @requirement_code
           AND ISNULL(asset_type_id, -1) = ISNULL(@asset_type_id, -1);
    END
    ELSE
    BEGIN
        UPDATE grac_practice.asset_privacy_setting
           SET enforcement = @enforcement, exception_allowed = @exception_allowed, max_exception_days = @max_exception_days,
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE organization_id = @organization_id AND requirement_code = @requirement_code
           AND ISNULL(asset_type_id, -1) = ISNULL(@asset_type_id, -1);
        IF @@ROWCOUNT = 0
            INSERT grac_practice.asset_privacy_setting
                (organization_id, asset_type_id, requirement_code, enforcement, exception_allowed, max_exception_days, entered_by)
            VALUES (@organization_id, @asset_type_id, @requirement_code, @enforcement, @exception_allowed, @max_exception_days, @actor);
        SET @id = (SELECT setting_id FROM grac_practice.asset_privacy_setting
                    WHERE organization_id = @organization_id AND requirement_code = @requirement_code
                      AND ISNULL(asset_type_id, -1) = ISNULL(@asset_type_id, -1));
    END
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-privacy-setting', @organization_id, CASE WHEN @enforcement IS NULL THEN N'RESET' ELSE N'SAVE' END, @before,
            (SELECT @requirement_code AS requirementCode, @asset_type_id AS assetTypeId, @enforcement AS enforcement,
                    @exception_allowed AS exceptionAllowed, @max_exception_days AS maxExceptionDays FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @id AS SettingId, CASE WHEN @enforcement IS NULL THEN N'RESET' ELSE N'SAVED' END AS Result;
END
GO
PRINT '448: requirement settings created.';
GO

-- =====================================================================
-- 7. Exceptions (19.7-style override for a privacy requirement; 9.1.7 expiry)
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_privacy_exception_request
    @organization_id       BIGINT,
    @asset_id              BIGINT,
    @requirement_code      NVARCHAR(30),
    @reason                NVARCHAR(1000) = NULL,
    @compensating_controls NVARCHAR(1000) = NULL,
    @owner_employee_id     BIGINT         = NULL,
    @expiry_date           DATE           = NULL,
    @actor_employee_id     BIGINT         = NULL,
    @actor                 NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @requirement_code = UPPER(LTRIM(RTRIM(ISNULL(@requirement_code, N''))));
    SET @reason = NULLIF(LTRIM(RTRIM(@reason)), N'');
    SET @compensating_controls = NULLIF(LTRIM(RTRIM(@compensating_controls)), N'');
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE), @msg NVARCHAR(400);

    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset
                    WHERE asset_id = @asset_id AND organization_id = @organization_id AND merged_into_asset_id IS NULL)
        THROW 53051, 'Asset not found for this organization.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_privacy_requirement WHERE requirement_code = @requirement_code)
        THROW 53052, 'Unknown privacy requirement.', 1;
    DECLARE @gaps INT = 0, @allowed BIT, @maxd INT, @snapshot NVARCHAR(MAX);
    SELECT @gaps = COUNT(*), @allowed = MIN(CAST(g.ExceptionAllowed AS INT)), @maxd = MIN(g.MaxExceptionDays)
      FROM grac_practice.fn_asset_privacy_gaps(@organization_id, @asset_id) g
     WHERE g.RequirementCode = @requirement_code AND g.IsExcepted = 0;
    IF @gaps = 0 THROW 53062, 'This requirement has no open gap on the asset.', 1;
    IF @allowed = 0 THROW 53057, 'This requirement allows no exception; correct the asset instead.', 1;
    IF @reason IS NULL OR @compensating_controls IS NULL OR @owner_employee_id IS NULL OR @expiry_date IS NULL
        THROW 53058, 'Reason, compensating controls, owner and expiry date are required.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization_employee WHERE employee_id = @owner_employee_id AND organization_id = @organization_id)
        THROW 53058, 'The owner must be an employee of this organization.', 1;
    IF @expiry_date <= @today OR (@maxd IS NOT NULL AND @expiry_date > DATEADD(DAY, @maxd, @today))
    BEGIN
        SET @msg = CONCAT(N'The expiry date must be after today', CASE WHEN @maxd IS NULL THEN N'' ELSE CONCAT(N' and within ', @maxd, N' days') END, N'.');
        THROW 53059, @msg, 1;
    END
    IF EXISTS (SELECT 1 FROM grac_practice.asset_privacy_exception
                WHERE asset_id = @asset_id AND requirement_code = @requirement_code AND status IN (N'PENDING_APPROVAL', N'APPROVED'))
        THROW 53060, 'An exception for this requirement is already pending or approved.', 1;
    SET @snapshot = (SELECT g.GapKind AS gapKind, g.Message AS message
                       FROM grac_practice.fn_asset_privacy_gaps(@organization_id, @asset_id) g
                      WHERE g.RequirementCode = @requirement_code FOR JSON PATH);

    DECLARE @id BIGINT;
    BEGIN TRAN;
    INSERT grac_practice.asset_privacy_exception
        (organization_id, asset_id, requirement_code, status, reason, compensating_controls, owner_employee_id, expiry_date,
         gap_snapshot, requested_by, requested_employee_id)
    VALUES (@organization_id, @asset_id, @requirement_code, N'PENDING_APPROVAL', @reason, @compensating_controls, @owner_employee_id,
            @expiry_date, @snapshot, @actor, @actor_employee_id);
    SET @id = SCOPE_IDENTITY();
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-privacy-exception', @id, N'REQUEST', NULL,
            (SELECT @asset_id AS assetId, @requirement_code AS requirementCode, @reason AS reason, @compensating_controls AS compensatingControls,
                    @owner_employee_id AS ownerEmployeeId, @expiry_date AS expiryDate FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @id AS ExceptionId, N'PENDING_APPROVAL' AS Result;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_privacy_exception_action
    @organization_id         BIGINT,
    @exception_id            BIGINT,
    @action                  NVARCHAR(12),
    @note                    NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @action = UPPER(LTRIM(RTRIM(ISNULL(@action, N''))));
    SET @note = NULLIF(LTRIM(RTRIM(@note)), N'');
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    DECLARE @found BIT = 0, @status NVARCHAR(20), @rv BIGINT, @req_by NVARCHAR(100), @req_emp BIGINT, @expiry DATE;
    SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version), @req_by = requested_by,
           @req_emp = requested_employee_id, @expiry = expiry_date
      FROM grac_practice.asset_privacy_exception WHERE exception_id = @exception_id AND organization_id = @organization_id;
    IF @found = 0 THROW 53056, 'Privacy exception not found for this organization.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 53063, 'This exception was changed by someone else. Reload it and try again.', 1;
    IF @action NOT IN (N'APPROVE', N'REJECT', N'WITHDRAW', N'REVOKE')
        THROW 53072, 'Choose Approve, Reject, Withdraw or Revoke.', 1;
    IF @action IN (N'APPROVE', N'REJECT', N'WITHDRAW') AND @status <> N'PENDING_APPROVAL'
        THROW 53062, 'Only a request awaiting approval can be approved, rejected or withdrawn.', 1;
    IF @action = N'REVOKE' AND @status <> N'APPROVED'
        THROW 53062, 'Only an approved exception can be revoked.', 1;
    IF @action IN (N'APPROVE', N'REJECT')
       AND ((@actor_employee_id IS NOT NULL AND @actor_employee_id = @req_emp) OR @actor = @req_by)
        THROW 53061, 'Segregation of duties: the person who requested the exception cannot decide it.', 1;
    IF @action IN (N'REJECT', N'REVOKE') AND @note IS NULL
        THROW 53058, 'A reason is required.', 1;
    IF @action = N'APPROVE' AND @expiry <= @today
        THROW 53059, 'The expiry date has passed; withdraw and request again.', 1;

    DECLARE @to NVARCHAR(20) = CASE @action WHEN N'APPROVE' THEN N'APPROVED' WHEN N'REJECT' THEN N'REJECTED'
                                            WHEN N'WITHDRAW' THEN N'WITHDRAWN' ELSE N'REVOKED' END;
    BEGIN TRAN;
    UPDATE grac_practice.asset_privacy_exception
       SET status = @to, decision_note = ISNULL(@note, decision_note),
           decided_by = CASE WHEN @action = N'WITHDRAW' THEN decided_by ELSE @actor END,
           decided_employee_id = CASE WHEN @action = N'WITHDRAW' THEN decided_employee_id ELSE @actor_employee_id END,
           decided_dt = CASE WHEN @action = N'WITHDRAW' THEN decided_dt ELSE SYSUTCDATETIME() END,
           closed_dt = CASE WHEN @to = N'APPROVED' THEN NULL ELSE SYSUTCDATETIME() END
     WHERE exception_id = @exception_id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-privacy-exception', @exception_id, @action,
            (SELECT @status AS status FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            (SELECT @to AS status, @note AS note FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @exception_id AS ExceptionId, @to AS Result;
END
GO
PRINT '448: exception procedures created.';
GO

-- =====================================================================
-- 8. Reviews (9.1.7): privacy review and retention decision
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_privacy_review_complete
    @organization_id         BIGINT,
    @review_id               BIGINT,
    @outcome                 NVARCHAR(12),
    @note                    NVARCHAR(1000) = NULL,
    @evidence                NVARCHAR(1000) = NULL,
    @next_date               DATE           = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @outcome = UPPER(LTRIM(RTRIM(ISNULL(@outcome, N''))));
    SET @note = NULLIF(LTRIM(RTRIM(@note)), N'');
    SET @evidence = NULLIF(LTRIM(RTRIM(@evidence)), N'');
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    DECLARE @found BIT = 0, @status NVARCHAR(10), @rv BIGINT, @kind NVARCHAR(10), @asset BIGINT, @due DATE;
    SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version), @kind = review_kind, @asset = asset_id, @due = due_date
      FROM grac_practice.asset_privacy_review WHERE review_id = @review_id AND organization_id = @organization_id;
    IF @found = 0 THROW 53064, 'Privacy review not found for this organization.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 53069, 'This review was changed by someone else. Reload it and try again.', 1;
    IF @status <> N'OPEN' THROW 53065, 'This review is no longer open.', 1;

    IF @kind = N'PRIVACY'
    BEGIN
        IF @outcome <> N'REVIEWED' THROW 53066, 'A privacy review is completed as Reviewed.', 1;
        IF @next_date IS NULL OR @next_date <= @today
            THROW 53067, 'Enter the next privacy review date (after today).', 1;
    END
    ELSE
    BEGIN
        IF @outcome NOT IN (N'DELETE', N'ARCHIVE', N'LEGAL_HOLD', N'EXTEND')
            THROW 53066, 'Choose Delete, Archive, Legal hold verified or Extend.', 1;
        IF @outcome IN (N'DELETE', N'ARCHIVE') AND @evidence IS NULL
            THROW 53066, 'Evidence of the deletion or archival is required.', 1;
        IF @outcome = N'LEGAL_HOLD'
           AND NOT EXISTS (SELECT 1 FROM grac_practice.fn_asset_privacy_values(@organization_id, @asset) v WHERE v.lhold = N'YES')
            THROW 53066, 'Legal hold status of the asset is not Yes; record the legal hold on the asset first.', 1;
        IF @outcome = N'EXTEND' AND @note IS NULL
            THROW 53066, 'A reason is required for an extension.', 1;
        IF @outcome IN (N'LEGAL_HOLD', N'EXTEND') AND (@next_date IS NULL OR @next_date <= @today OR @next_date <= @due)
            THROW 53067, 'Enter the date until which the data is kept (after today and after the current retention end).', 1;
    END

    DECLARE @o INT, @c INT, @x INT, @date_text NVARCHAR(400) = CONVERT(NVARCHAR(10), @next_date, 23);
    BEGIN TRAN;
    UPDATE grac_practice.asset_privacy_review
       SET status = N'COMPLETED', outcome = @outcome, note = @note, evidence = @evidence, next_date = @next_date,
           extended_until = CASE WHEN @outcome IN (N'LEGAL_HOLD', N'EXTEND') THEN @next_date END,
           completed_by = @actor, completed_employee_id = @actor_employee_id, completed_dt = SYSUTCDATETIME(),
           updated_by = @actor, updated_dt = SYSUTCDATETIME()
     WHERE review_id = @review_id;
    IF @kind = N'PRIVACY'
        EXEC grac_practice.sp_asset_field_value_set @asset_id = @asset, @field_key = N'privacy_review_date', @value = @date_text, @actor = @actor;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-privacy-review', @review_id, @outcome,
            (SELECT @kind AS reviewKind, @due AS dueDate, @asset AS assetId FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            (SELECT @outcome AS outcome, @note AS note, @evidence AS evidence, @next_date AS nextDate FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    EXEC grac_practice.sp_asset_privacy_sync @organization_id = @organization_id, @asset_id = @asset, @actor = @actor,
         @out_opened = @o OUTPUT, @out_closed = @c OUTPUT, @out_expired = @x OUTPUT;
    COMMIT;
    SELECT @review_id AS ReviewId, @outcome AS Result;
END
GO
PRINT '448: review completion created.';
GO

-- =====================================================================
-- 9. Readers
-- =====================================================================
-- Privacy register. @status NULL = every asset except Not applicable;
-- ALL; or one privacy status.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_privacy_assets
    @organization_id BIGINT,
    @status          NVARCHAR(20)  = NULL,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    SELECT s.AssetId, s.AssetName, s.StatusCode, s.Applicability, s.PrivacyStatus, s.Failed, s.Missing, s.Partial, s.Excepted,
           s.Blocking, s.PrivacyOwnerId, pe.employee_name AS PrivacyOwnerName, s.AssessmentStatus, s.PrivacyReviewDate,
           s.RetentionDueDate, s.LegalHold
      INTO #ps
      FROM grac_practice.fn_asset_privacy_status(@organization_id, NULL) s
      LEFT JOIN grac_practice.organization_employee pe ON pe.employee_id = s.PrivacyOwnerId;
    SELECT p.AssetId, p.AssetName, p.StatusCode, p.Applicability, p.PrivacyStatus, p.Failed, p.Missing, p.Partial, p.Excepted, p.Blocking,
           p.PrivacyOwnerId, p.PrivacyOwnerName, p.AssessmentStatus, p.PrivacyReviewDate, p.RetentionDueDate, p.LegalHold,
           (SELECT COUNT(*) FROM grac_practice.asset_privacy_review r WHERE r.asset_id = p.AssetId AND r.status = N'OPEN') AS OpenReviews,
           (SELECT COUNT(*) FROM grac_practice.asset_privacy_exception x WHERE x.asset_id = p.AssetId AND x.status = N'PENDING_APPROVAL') AS PendingExceptions,
           COUNT(*) OVER () AS TotalRows
      FROM #ps p
     WHERE ((@status IS NULL AND p.PrivacyStatus <> N'NOT_APPLICABLE') OR @status = N'ALL' OR p.PrivacyStatus = @status)
       AND (@search IS NULL OR p.AssetName LIKE N'%' + @search + N'%')
     ORDER BY CASE p.PrivacyStatus WHEN N'NON_COMPLIANT' THEN 0 WHEN N'INCOMPLETE' THEN 1 WHEN N'UNDETERMINED' THEN 2
                                   WHEN N'CONDITIONAL' THEN 3 WHEN N'COMPLIANT' THEN 4 ELSE 5 END, p.AssetName
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    SELECT PrivacyStatus, COUNT(*) AS AssetCount FROM #ps GROUP BY PrivacyStatus;
END
GO

-- One asset: status, gaps, exceptions, reviews.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_privacy_asset_get
    @organization_id BIGINT,
    @asset_id        BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset
                    WHERE asset_id = @asset_id AND organization_id = @organization_id AND merged_into_asset_id IS NULL)
        THROW 53051, 'Asset not found for this organization.', 1;
    -- 1. Status
    SELECT s.AssetId, s.AssetName, s.StatusCode, s.Applicability, s.PersonalDataProcessed, s.PrivacyStatus, s.Failed, s.Missing,
           s.Partial, s.Excepted, s.Blocking, s.PrivacyOwnerId, pe.employee_name AS PrivacyOwnerName, s.AssessmentStatus,
           s.PrivacyReviewDate, s.RetentionDueDate, s.LegalHold
      FROM grac_practice.fn_asset_privacy_status(@organization_id, @asset_id) s
      LEFT JOIN grac_practice.organization_employee pe ON pe.employee_id = s.PrivacyOwnerId;
    -- 2. Gaps
    SELECT g.RequirementCode, g.RequirementName, g.GapKind, g.Message, g.Enforcement, g.BlockTarget, g.ExceptionAllowed,
           g.MaxExceptionDays, g.ExceptionId, g.ExceptionExpiry, g.IsExcepted
      FROM grac_practice.fn_asset_privacy_gaps(@organization_id, @asset_id) g
     ORDER BY g.DisplayOrder, CASE g.GapKind WHEN N'FAILED' THEN 0 WHEN N'MISSING' THEN 1 ELSE 2 END;
    -- 3. Exceptions
    SELECT x.exception_id AS ExceptionId, x.requirement_code AS RequirementCode, q.requirement_name AS RequirementName,
           x.status AS Status, x.reason AS Reason, x.compensating_controls AS CompensatingControls,
           x.owner_employee_id AS OwnerEmployeeId, oe.employee_name AS OwnerName, x.expiry_date AS ExpiryDate,
           x.requested_by AS RequestedBy, x.requested_dt AS RequestedDt, x.decided_by AS DecidedBy, x.decided_dt AS DecidedDt,
           x.decision_note AS DecisionNote, CONVERT(BIGINT, x.record_version) AS RecordVersion
      FROM grac_practice.asset_privacy_exception x
      JOIN grac_practice.asset_privacy_requirement q ON q.requirement_code = x.requirement_code
      LEFT JOIN grac_practice.organization_employee oe ON oe.employee_id = x.owner_employee_id
     WHERE x.asset_id = @asset_id AND x.organization_id = @organization_id
     ORDER BY CASE WHEN x.status IN (N'PENDING_APPROVAL', N'APPROVED') THEN 0 ELSE 1 END, x.exception_id DESC;
    -- 4. Reviews
    SELECT TOP (50) r.review_id AS ReviewId, r.review_kind AS ReviewKind, r.due_date AS DueDate, r.status AS Status,
           r.outcome AS Outcome, r.note AS Note, r.evidence AS Evidence, r.next_date AS NextDate, r.extended_until AS ExtendedUntil,
           r.completed_by AS CompletedBy, r.completed_dt AS CompletedDt, r.cancel_reason AS CancelReason,
           CONVERT(BIGINT, r.record_version) AS RecordVersion
      FROM grac_practice.asset_privacy_review r
     WHERE r.asset_id = @asset_id AND r.organization_id = @organization_id
     ORDER BY CASE WHEN r.status = N'OPEN' THEN 0 ELSE 1 END, r.due_date DESC, r.review_id DESC;
END
GO

-- Exceptions worklist. @status NULL = pending and approved; ALL; or one status.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_privacy_exceptions
    @organization_id BIGINT,
    @status          NVARCHAR(20) = NULL,
    @page_number     INT          = 1,
    @page_size       INT          = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    SELECT x.exception_id AS ExceptionId, x.asset_id AS AssetId, a.asset_name AS AssetName, x.requirement_code AS RequirementCode,
           q.requirement_name AS RequirementName, x.status AS Status, x.reason AS Reason, x.compensating_controls AS CompensatingControls,
           x.owner_employee_id AS OwnerEmployeeId, oe.employee_name AS OwnerName, x.expiry_date AS ExpiryDate,
           x.requested_by AS RequestedBy, x.requested_dt AS RequestedDt, x.decided_by AS DecidedBy, x.decided_dt AS DecidedDt,
           x.decision_note AS DecisionNote, CONVERT(BIGINT, x.record_version) AS RecordVersion, COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_privacy_exception x
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = x.asset_id
      JOIN grac_practice.asset_privacy_requirement q ON q.requirement_code = x.requirement_code
      LEFT JOIN grac_practice.organization_employee oe ON oe.employee_id = x.owner_employee_id
     WHERE x.organization_id = @organization_id
       AND ((@status IS NULL AND x.status IN (N'PENDING_APPROVAL', N'APPROVED')) OR @status = N'ALL' OR x.status = @status)
     ORDER BY CASE x.status WHEN N'PENDING_APPROVAL' THEN 0 WHEN N'APPROVED' THEN 1 ELSE 2 END, x.expiry_date, x.exception_id DESC
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- Reviews worklist. @status NULL = open; ALL; or one status.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_privacy_reviews
    @organization_id BIGINT,
    @status          NVARCHAR(10) = NULL,
    @kind            NVARCHAR(10) = NULL,
    @page_number     INT          = 1,
    @page_size       INT          = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @kind = NULLIF(UPPER(LTRIM(RTRIM(@kind))), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    SELECT r.review_id AS ReviewId, r.asset_id AS AssetId, a.asset_name AS AssetName, r.review_kind AS ReviewKind,
           r.due_date AS DueDate, CASE WHEN r.status = N'OPEN' AND r.due_date < @today THEN 1 ELSE 0 END AS IsOverdue,
           r.status AS Status, r.outcome AS Outcome, r.note AS Note, r.evidence AS Evidence, r.next_date AS NextDate,
           r.completed_by AS CompletedBy, r.completed_dt AS CompletedDt, v.lhold AS LegalHold,
           TRY_CONVERT(BIGINT, v.powner) AS PrivacyOwnerId, pe.employee_name AS PrivacyOwnerName,
           CONVERT(BIGINT, r.record_version) AS RecordVersion, COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_privacy_review r
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = r.asset_id
      OUTER APPLY (SELECT TOP (1) pv.lhold, pv.powner FROM grac_practice.fn_asset_privacy_values(@organization_id, r.asset_id) pv) v
      LEFT JOIN grac_practice.organization_employee pe ON pe.employee_id = TRY_CONVERT(BIGINT, v.powner)
     WHERE r.organization_id = @organization_id
       AND ((@status IS NULL AND r.status = N'OPEN') OR @status = N'ALL' OR r.status = @status)
       AND (@kind IS NULL OR r.review_kind = @kind)
     ORDER BY CASE WHEN r.status = N'OPEN' THEN 0 ELSE 1 END, r.due_date, r.review_id
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO
PRINT '448: readers created.';
GO

