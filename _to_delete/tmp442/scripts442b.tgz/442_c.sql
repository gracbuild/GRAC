
-- =====================================================================
-- 6. Reconciliation engine (5.6.2-5.6.5; D99-D104)
-- =====================================================================
-- Fills the caller-created #iv (asset_id, field_key, norm) with the
-- normalized identity values of the organization (or one asset) for the
-- fields the active rules use (#ra), plus the record IDs this source
-- already linked (@source_key). Disposed / archived assets are not matched.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_identity_load
    @organization_id BIGINT,
    @source_id       BIGINT,
    @asset_id        BIGINT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM #iv WHERE @asset_id IS NULL OR asset_id = @asset_id;
    INSERT #iv (asset_id, field_key, norm)
    SELECT v.asset_id, f.field_key, n.norm
      FROM grac_practice.asset_field_value v
      JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = v.asset_id AND a.organization_id = @organization_id
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
      LEFT JOIN grac_practice.asset_make mk ON f.data_type_code = N'MAKE' AND mk.make_id = v.value_ref
      LEFT JOIN grac_practice.asset_model md ON f.data_type_code = N'MODEL' AND md.model_id = v.value_ref
     CROSS APPLY (SELECT grac_practice.fn_asset_norm(f.field_key,
                         CASE f.data_type_code WHEN N'MAKE' THEN mk.make_name WHEN N'MODEL' THEN md.model_name
                                               ELSE v.value_text END) AS norm) n
     WHERE (@asset_id IS NULL OR v.asset_id = @asset_id)
       AND ISNULL(s.status_code, N'ACTIVE') NOT IN (N'DISPOSED', N'ARCHIVED')
       AND n.norm IS NOT NULL
       AND f.field_key IN (SELECT field_key FROM #ra)
    UNION ALL
    SELECT l.asset_id, N'@source_key', UPPER(l.external_key)
      FROM grac_practice.asset_discovery_link l
     WHERE l.source_id = @source_id AND (@asset_id IS NULL OR l.asset_id = @asset_id);
END
GO

-- Opens (or refreshes) a reconciliation exception: one open exception per
-- source record, kind and field (repeats are counted, not duplicated). A
-- new Conflict opens an owner task when the settings ask for it (D102).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_reconciliation_exception_raise
    @organization_id BIGINT,
    @exception_kind  NVARCHAR(16),
    @observation_id  BIGINT,
    @source_id       BIGINT,
    @external_key    NVARCHAR(200) = NULL,
    @asset_id        BIGINT        = NULL,
    @other_asset_id  BIGINT        = NULL,
    @field_key       NVARCHAR(100) = NULL,
    @current_value   NVARCHAR(400) = NULL,
    @observed_value  NVARCHAR(400) = NULL,
    @match_score     INT           = NULL,
    @actor           NVARCHAR(100) = N'discovery'
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @eid BIGINT = (SELECT TOP 1 exception_id FROM grac_practice.asset_reconciliation_exception
                            WHERE source_id = @source_id AND exception_kind = @exception_kind AND status = N'OPEN'
                              AND ISNULL(field_key, N'') = ISNULL(@field_key, N'')
                              AND ((@external_key IS NOT NULL AND external_key = @external_key)
                                   OR (@external_key IS NULL AND observation_id = @observation_id))
                            ORDER BY exception_id);
    IF @eid IS NOT NULL
    BEGIN
        UPDATE grac_practice.asset_reconciliation_exception
           SET observation_id = @observation_id, asset_id = @asset_id, other_asset_id = @other_asset_id, current_value = @current_value,
               observed_value = @observed_value, match_score = @match_score, raised_count = raised_count + 1, updated_dt = SYSUTCDATETIME()
         WHERE exception_id = @eid;
        RETURN;
    END
    INSERT grac_practice.asset_reconciliation_exception
        (organization_id, exception_kind, observation_id, source_id, external_key, asset_id, other_asset_id, field_key, current_value,
         observed_value, match_score, status)
    VALUES (@organization_id, @exception_kind, @observation_id, @source_id, @external_key, @asset_id, @other_asset_id, @field_key,
            @current_value, @observed_value, @match_score, N'OPEN');
    SET @eid = SCOPE_IDENTITY();
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-reconciliation-exception', @eid, N'RAISE', NULL,
            (SELECT @exception_kind AS kind, @observation_id AS observationId, @asset_id AS assetId, @other_asset_id AS otherAssetId,
                    @field_key AS fieldKey, @current_value AS currentValue, @observed_value AS observedValue, @match_score AS matchScore
                FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);

    IF @exception_kind = N'CONFLICT' AND @asset_id IS NOT NULL
       AND EXISTS (SELECT 1 FROM grac_practice.asset_discovery_setting WHERE organization_id = @organization_id AND create_conflict_tasks = 1)
    BEGIN
        DECLARE @owner BIGINT, @asset_name NVARCHAR(400), @crit NVARCHAR(40), @prio NVARCHAR(30), @title NVARCHAR(250),
                @descr NVARCHAR(MAX), @ref NVARCHAR(200), @tid BIGINT, @src_name NVARCHAR(200);
        SELECT @owner = grac_practice.fn_asset_activity_person(@organization_id, CAST(a.owner_id AS NVARCHAR(30))),
               @asset_name = a.asset_name, @crit = c.criticality_code
          FROM grac_practice.organization_dependency_asset a
          LEFT JOIN grac_practice.criticality_master c ON c.criticality_id = a.criticality_id
         WHERE a.asset_id = @asset_id;
        SET @src_name = (SELECT source_name FROM grac_practice.asset_discovery_source WHERE source_id = @source_id);
        SET @prio = CASE @crit WHEN N'Critical' THEN N'Critical' WHEN N'High' THEN N'High' WHEN N'Low' THEN N'Low' ELSE N'Medium' END;
        SET @title = LEFT(CONCAT(N'Discovery conflict - ', @asset_name, N' (', @field_key, N')'), 250);
        SET @descr = CONCAT(N'Source ', @src_name, N' reports ', @field_key, N' = "', @observed_value, N'"; the register holds "',
                            @current_value, N'". Both values are kept; resolve it in Asset Discovery (reconciliation exception ', @eid, N').');
        SET @ref = CONCAT(N'REC-', @eid);
        EXEC grac_practice.sp_task_open
             @organization_id         = @organization_id,
             @task_type_code          = N'AssetReconciliation',
             @subject_entity_type     = N'AssetReconciliationException',
             @subject_entity_id       = @eid,
             @subject_title           = @title,
             @subject_description     = @descr,
             @priority                = @prio,
             @criticality             = @crit,
             @origin_code             = N'GRAC',
             @assigned_to_employee_id = @owner,
             @target_date             = NULL,
             @source_type_code        = N'Asset',
             @source_record_id        = @eid,
             @source_reference        = @ref,
             @resolve_owner           = 0,
             @task_id                 = @tid OUTPUT;
        UPDATE grac_practice.asset_reconciliation_exception SET task_id = @tid WHERE exception_id = @eid;
    END
END
GO

-- Applies an observation to an asset (Auto Match or a confirmed link):
-- links the source record, records every attribute per source and writes
-- the fields the source may change (D100-D101):
--   ignored by the source precedence     recorded only
--   same value                           nothing
--   not a writable value field           recorded only (make, model, lookups, people...)
--   empty on the asset                   filled (golden or contributing)
--   different, golden source             overwritten
--   different, otherwise                 Conflict exception (both values kept)
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_apply
    @observation_id    BIGINT,
    @asset_id          BIGINT,
    @link_method       NVARCHAR(10)  = N'AUTO',
    @match_score       INT           = NULL,
    @actor             NVARCHAR(100) = N'discovery',
    @out_updated       INT           = NULL OUTPUT,
    @out_conflicts     INT           = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SELECT @out_updated = 0, @out_conflicts = 0;
    DECLARE @org BIGINT, @source BIGINT, @key NVARCHAR(200), @payload NVARCHAR(MAX), @hash VARBINARY(32), @seen DATETIME2;
    SELECT @org = organization_id, @source = source_id, @key = external_key, @payload = payload_json, @hash = payload_hash,
           @seen = observed_dt
      FROM grac_practice.asset_discovery_observation WHERE observation_id = @observation_id;

    IF @key IS NOT NULL
        MERGE grac_practice.asset_discovery_link AS t
        USING (SELECT @source AS source_id, @key AS external_key) AS s ON t.source_id = s.source_id AND t.external_key = s.external_key
        WHEN MATCHED THEN UPDATE SET asset_id = @asset_id, identity_score = ISNULL(@match_score, t.identity_score), link_method = @link_method,
            last_seen_dt = CASE WHEN @seen > t.last_seen_dt THEN @seen ELSE t.last_seen_dt END, last_observation_id = @observation_id,
            last_payload_hash = @hash
        WHEN NOT MATCHED THEN INSERT (organization_id, asset_id, source_id, external_key, identity_score, link_method, first_seen_dt,
                                      last_seen_dt, last_observation_id, last_payload_hash)
            VALUES (@org, @asset_id, @source, @key, ISNULL(@match_score, 100), @link_method, @seen, @seen, @observation_id, @hash);

    DECLARE @fk NVARCHAR(100), @obs NVARCHAR(400), @dtype NVARCHAR(30), @storage NVARCHAR(10), @role NVARCHAR(12), @cur NVARCHAR(400),
            @applied BIT, @changed NVARCHAR(MAX) = NULL;
    DECLARE fld_cur CURSOR LOCAL STATIC FOR
        SELECT f.field_key, LEFT(CAST(j.[value] AS NVARCHAR(MAX)), 400), f.data_type_code, f.storage_kind, ISNULL(p.source_role, N'CONTRIBUTING')
          FROM OPENJSON(@payload) j
          -- OPENJSON keys are Latin1_General_BIN2: compare in the database collation (Msg 468)
          JOIN grac_practice.asset_field_definition f ON f.field_key = j.[key] COLLATE DATABASE_DEFAULT
          LEFT JOIN grac_practice.asset_discovery_priority p ON p.source_id = @source AND p.field_key = f.field_key
         WHERE j.[type] IN (1, 2) AND NULLIF(LTRIM(RTRIM(CAST(j.[value] AS NVARCHAR(MAX)))), N'') IS NOT NULL;
    OPEN fld_cur;
    FETCH NEXT FROM fld_cur INTO @fk, @obs, @dtype, @storage, @role;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @obs = LTRIM(RTRIM(@obs));
        SET @cur = (SELECT v.value_text FROM grac_practice.asset_field_value v
                      JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id AND f.field_key = @fk
                     WHERE v.asset_id = @asset_id);
        SET @applied = 0;
        IF @role <> N'IGNORED' AND ISNULL(grac_practice.fn_asset_norm(@fk, @cur), N'') = ISNULL(grac_practice.fn_asset_norm(@fk, @obs), N'')
        BEGIN
            SET @applied = 1;
        END
        ELSE IF @role <> N'IGNORED' AND @storage = N'VALUE'
                AND @dtype IN (N'TEXT', N'MULTILINE', N'DECIMAL', N'PERCENT', N'QUANTITY_UNIT', N'DATE', N'IP_ADDRESS', N'IP_LIST')
        BEGIN
            IF @cur IS NULL OR @role = N'GOLDEN'
            BEGIN
                EXEC grac_practice.sp_asset_field_value_set @asset_id = @asset_id, @field_key = @fk, @value = @obs, @actor = @actor;
                SET @applied = 1;
                SET @out_updated = @out_updated + 1;
                SET @changed = CONCAT(@changed, CASE WHEN @changed IS NULL THEN N'' ELSE N', ' END, @fk);
            END
            ELSE
            BEGIN
                EXEC grac_practice.sp_asset_reconciliation_exception_raise
                     @organization_id = @org, @exception_kind = N'CONFLICT', @observation_id = @observation_id, @source_id = @source,
                     @external_key = @key, @asset_id = @asset_id, @field_key = @fk, @current_value = @cur, @observed_value = @obs,
                     @match_score = @match_score, @actor = @actor;
                SET @out_conflicts = @out_conflicts + 1;
            END
        END
        MERGE grac_practice.asset_attribute_source AS t
        USING (SELECT @asset_id AS asset_id, @fk AS field_key, @source AS source_id) AS s
           ON t.asset_id = s.asset_id AND t.field_key = s.field_key AND t.source_id = s.source_id
        WHEN MATCHED THEN UPDATE SET observed_value = @obs, observed_dt = @seen, observation_id = @observation_id, applied = @applied
        WHEN NOT MATCHED THEN INSERT (asset_id, field_key, source_id, observed_value, observed_dt, observation_id, applied)
            VALUES (@asset_id, @fk, @source, @obs, @seen, @observation_id, @applied);
        FETCH NEXT FROM fld_cur INTO @fk, @obs, @dtype, @storage, @role;
    END
    CLOSE fld_cur;
    DEALLOCATE fld_cur;

    IF @out_updated > 0
        INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
        VALUES (N'asset-register', @asset_id, N'DISCOVERY', NULL,
                (SELECT @observation_id AS observationId, @source AS sourceId, @key AS externalKey, @changed AS fields
                    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
                N'Active', @actor);
    IF OBJECT_ID('tempdb..#iv') IS NOT NULL
        EXEC grac_practice.sp_asset_discovery_identity_load @organization_id = @org, @source_id = @source, @asset_id = @asset_id;
END
GO

-- Reconciles one observation. Needs #iv, #irule, #ra and #strong from the
-- caller (sp_asset_discovery_ingest). Score of an asset (D99): the best
-- matched rule weight, +5 for each further matched rule, -30 for each
-- strong identifier both sides hold with different values, bounded 0-100
-- and scaled by the source trust. Outcomes (D101): repeat of the linked
-- record -> No change; two assets at or above the suggested score (not
-- decided as distinct) -> Potential duplicate; best at or above auto match
-- -> applied; at or above suggested -> Suggested; at or above manual review
-- -> Manual review; else New candidate.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_reconcile
    @observation_id BIGINT,
    @actor          NVARCHAR(100) = N'discovery'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @org BIGINT, @source BIGINT, @key NVARCHAR(200), @payload NVARCHAR(MAX), @hash VARBINARY(32), @seen DATETIME2, @trust INT,
            @auto INT, @sug INT, @man INT;
    SELECT @org = o.organization_id, @source = o.source_id, @key = o.external_key, @payload = o.payload_json, @hash = o.payload_hash,
           @seen = o.observed_dt, @trust = s.trust_level
      FROM grac_practice.asset_discovery_observation o
      JOIN grac_practice.asset_discovery_source s ON s.source_id = o.source_id
     WHERE o.observation_id = @observation_id;
    SELECT @auto = auto_match_score, @sug = suggested_score, @man = manual_review_score
      FROM grac_practice.asset_discovery_setting WHERE organization_id = @org;

    -- Repeat of a linked record with the same content: freshness only (5.6.5).
    DECLARE @link_asset BIGINT, @link_hash VARBINARY(32);
    SELECT @link_asset = asset_id, @link_hash = last_payload_hash
      FROM grac_practice.asset_discovery_link WHERE source_id = @source AND external_key = @key;
    IF @link_asset IS NOT NULL AND @link_hash = @hash
    BEGIN
        UPDATE grac_practice.asset_discovery_link
           SET last_seen_dt = CASE WHEN @seen > last_seen_dt THEN @seen ELSE last_seen_dt END, last_observation_id = @observation_id
         WHERE source_id = @source AND external_key = @key;
        UPDATE grac_practice.asset_discovery_observation
           SET outcome = N'NO_CHANGE', matched_asset_id = @link_asset, result_text = N'Same content as the last observation of this record.'
         WHERE observation_id = @observation_id;
        RETURN;
    END

    CREATE TABLE #attr (field_key NVARCHAR(100) COLLATE DATABASE_DEFAULT NOT NULL PRIMARY KEY, norm NVARCHAR(400) COLLATE DATABASE_DEFAULT NOT NULL);
    INSERT #attr (field_key, norm)
    SELECT j.[key] COLLATE DATABASE_DEFAULT, MIN(n.norm)
      FROM OPENJSON(@payload) j
     CROSS APPLY (SELECT grac_practice.fn_asset_norm(j.[key], LEFT(CAST(j.[value] AS NVARCHAR(MAX)), 400)) AS norm) n
     WHERE j.[type] IN (1, 2) AND n.norm IS NOT NULL
     GROUP BY j.[key] COLLATE DATABASE_DEFAULT;
    IF @key IS NOT NULL AND NOT EXISTS (SELECT 1 FROM #attr WHERE field_key = N'@source_key')
        INSERT #attr (field_key, norm) VALUES (N'@source_key', UPPER(@key));

    CREATE TABLE #m (asset_id BIGINT NOT NULL, rule_id BIGINT NOT NULL);
    INSERT #m (asset_id, rule_id)
    SELECT iv.asset_id, ra.rule_id
      FROM #ra ra
      JOIN #attr a ON a.field_key = ra.field_key
      JOIN #iv iv ON iv.field_key = ra.field_key AND iv.norm = a.norm
     GROUP BY iv.asset_id, ra.rule_id, ra.n
    HAVING COUNT(DISTINCT ra.field_key) = ra.n;

    CREATE TABLE #s (asset_id BIGINT NOT NULL PRIMARY KEY, base INT NOT NULL, nrules INT NOT NULL, rules NVARCHAR(400) COLLATE DATABASE_DEFAULT NULL,
                     penalty INT NOT NULL, raw_score INT NULL, score INT NULL);
    INSERT #s (asset_id, base, nrules, rules, penalty)
    SELECT m.asset_id, MAX(r.weight), COUNT(*), LEFT(STRING_AGG(r.rule_name, N', '), 400), 0
      FROM #m m JOIN #irule r ON r.rule_id = m.rule_id
     GROUP BY m.asset_id;
    UPDATE s
       SET penalty = (SELECT COUNT(*) FROM #iv iv
                        JOIN #attr a ON a.field_key = iv.field_key
                        JOIN #strong st ON st.field_key = iv.field_key
                       WHERE iv.asset_id = s.asset_id AND iv.norm <> a.norm)
      FROM #s s;
    UPDATE #s SET raw_score = base + 5 * (nrules - 1) - 30 * penalty;
    UPDATE #s SET score = CAST(ROUND((CASE WHEN raw_score > 100 THEN 100 WHEN raw_score < 0 THEN 0 ELSE raw_score END) * @trust / 100.0, 0) AS INT);

    DECLARE @best BIGINT, @best_score INT, @best_rules NVARCHAR(400), @second BIGINT, @second_score INT;
    SELECT TOP 1 @best = asset_id, @best_score = score, @best_rules = rules FROM #s ORDER BY score DESC, asset_id;
    SELECT TOP 1 @second = asset_id, @second_score = score FROM #s WHERE asset_id <> ISNULL(@best, -1) ORDER BY score DESC, asset_id;
    DECLARE @distinct BIT = CASE WHEN EXISTS (SELECT 1 FROM grac_practice.asset_duplicate_decision
                                               WHERE asset_id_low = CASE WHEN @best < @second THEN @best ELSE @second END
                                                 AND asset_id_high = CASE WHEN @best < @second THEN @second ELSE @best END)
                                 THEN 1 ELSE 0 END;
    DECLARE @outcome NVARCHAR(20), @text NVARCHAR(1000), @upd INT, @conf INT;
    IF @second IS NOT NULL AND @second_score >= @sug AND @distinct = 0
    BEGIN
        EXEC grac_practice.sp_asset_reconciliation_exception_raise
             @organization_id = @org, @exception_kind = N'DUPLICATE', @observation_id = @observation_id, @source_id = @source,
             @external_key = @key, @asset_id = @best, @other_asset_id = @second, @match_score = @best_score, @actor = @actor;
        SELECT @outcome = N'POTENTIAL_DUPLICATE',
               @text = CONCAT(N'Two register assets match (scores ', @best_score, N' and ', @second_score, N'); duplicate review opened.');
    END
    ELSE IF @best_score >= @auto
    BEGIN
        EXEC grac_practice.sp_asset_discovery_apply @observation_id = @observation_id, @asset_id = @best, @link_method = N'AUTO',
             @match_score = @best_score, @actor = @actor, @out_updated = @upd OUTPUT, @out_conflicts = @conf OUTPUT;
        SELECT @outcome = CASE WHEN @upd > 0 THEN N'UPDATED' ELSE N'NO_CHANGE' END,
               @text = CONCAT(N'Auto match (', @best_rules, N'): ', @upd, N' field(s) updated, ', @conf, N' conflict(s).');
    END
    ELSE IF @best_score >= @sug
    BEGIN
        EXEC grac_practice.sp_asset_reconciliation_exception_raise
             @organization_id = @org, @exception_kind = N'SUGGESTED_MATCH', @observation_id = @observation_id, @source_id = @source,
             @external_key = @key, @asset_id = @best, @match_score = @best_score, @actor = @actor;
        SELECT @outcome = N'SUGGESTED', @text = CONCAT(N'Suggested match (', @best_rules, N'); confirm the link.');
    END
    ELSE IF @best_score >= @man
    BEGIN
        EXEC grac_practice.sp_asset_reconciliation_exception_raise
             @organization_id = @org, @exception_kind = N'MANUAL_REVIEW', @observation_id = @observation_id, @source_id = @source,
             @external_key = @key, @asset_id = @best, @match_score = @best_score, @actor = @actor;
        SELECT @outcome = N'MANUAL_REVIEW', @text = CONCAT(N'Low-confidence match (', @best_rules, N'); review it.');
    END
    ELSE
    BEGIN
        EXEC grac_practice.sp_asset_reconciliation_exception_raise
             @organization_id = @org, @exception_kind = N'NEW_CANDIDATE', @observation_id = @observation_id, @source_id = @source,
             @external_key = @key, @asset_id = @best, @match_score = @best_score, @actor = @actor;
        SELECT @outcome = N'NEW_CANDIDATE', @text = N'No register asset matches; staged as a new candidate.';
    END
    UPDATE grac_practice.asset_discovery_observation
       SET outcome = @outcome, match_score = @best_score, matched_asset_id = @best, second_asset_id = @second, second_score = @second_score,
           matched_rules = @best_rules, result_text = @text
     WHERE observation_id = @observation_id;
END
GO

-- Ingests a batch from a source (UI, import or API -- identical rules):
--   @records_json = [{"externalKey":"...","observedAt":"2026-10-05T10:00:00Z",
--                     "attributes":{"serial_number":"...","hostname":"..."}}, ...]
-- observedAt is ISO 8601; an offset (or Z) is converted to UTC, no offset
-- is taken as UTC, a missing or invalid value is the receipt time.
-- A repeated batch reference returns the earlier batch (IsRepeat = 1)
-- without processing it again. Up to 5000 records; each record is reconciled in its own
-- transaction and keeps its own result (D103). Retention of the source is
-- applied afterwards. 1. batch  2. records.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_discovery_ingest
    @organization_id   BIGINT,
    @source_id         BIGINT,
    @batch_reference   NVARCHAR(100),
    @channel           NVARCHAR(10)  = N'UI',
    @records_json      NVARCHAR(MAX) = NULL,
    @actor_employee_id BIGINT        = NULL,
    @actor             NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @batch_reference = NULLIF(LTRIM(RTRIM(@batch_reference)), N'');
    SET @channel = CASE UPPER(ISNULL(@channel, N'')) WHEN N'IMPORT' THEN N'IMPORT' WHEN N'API' THEN N'API' ELSE N'UI' END;
    DECLARE @active BIT, @raw_days INT, @obs_days INT;
    SELECT @active = is_active, @raw_days = raw_retention_days, @obs_days = observation_retention_days
      FROM grac_practice.asset_discovery_source WHERE source_id = @source_id AND organization_id = @organization_id;
    IF @active IS NULL THROW 54761, 'Discovery source not found for this organization.', 1;
    IF @active = 0 THROW 54770, 'The discovery source is inactive.', 1;
    DECLARE @existing BIGINT = (SELECT batch_id FROM grac_practice.asset_discovery_batch
                                 WHERE source_id = @source_id AND batch_reference = @batch_reference);
    DECLARE @repeat BIT = CASE WHEN @existing IS NULL THEN 0 ELSE 1 END;
    IF @existing IS NULL
    BEGIN
        IF @batch_reference IS NULL OR ISJSON(ISNULL(@records_json, N'')) = 0 OR LEFT(LTRIM(@records_json), 1) <> N'['
            THROW 54771, 'Give a batch reference and the records as a JSON array.', 1;
        IF (SELECT COUNT(*) FROM OPENJSON(@records_json)) > 5000
            THROW 54772, 'A batch holds at most 5000 records; split it.', 1;
        EXEC grac_practice.sp_asset_discovery_defaults_ensure @organization_id = @organization_id;
        DECLARE @version INT = (SELECT rule_set_version FROM grac_practice.asset_discovery_setting WHERE organization_id = @organization_id);
        INSERT grac_practice.asset_discovery_batch (organization_id, source_id, batch_reference, channel, status, rule_set_version, entered_by)
        VALUES (@organization_id, @source_id, @batch_reference, @channel, N'RUNNING', @version, @actor);
        DECLARE @batch BIGINT = SCOPE_IDENTITY();

        INSERT grac_practice.asset_discovery_observation
            (organization_id, batch_id, source_id, record_no, external_key, observed_dt, payload_json, payload_hash, outcome, result_text,
             rule_set_version)
        SELECT @organization_id, @batch, @source_id, CAST(j.[key] AS INT) + 1, r.k, ISNULL(r.observed_at, SYSUTCDATETIME()),
               CASE WHEN ISJSON(r.attributes) = 1 AND LEFT(LTRIM(r.attributes), 1) = N'{' THEN r.attributes END,
               HASHBYTES('SHA2_256', CONCAT(r.k, N'|', r.attributes)),
               CASE WHEN ISJSON(r.attributes) = 1 AND LEFT(LTRIM(r.attributes), 1) = N'{' THEN NULL ELSE N'ERROR' END,
               CASE WHEN ISJSON(r.attributes) = 1 AND LEFT(LTRIM(r.attributes), 1) = N'{' THEN NULL
                    ELSE N'The record has no attributes object.' END,
               @version
          FROM OPENJSON(@records_json) j
         CROSS APPLY (SELECT NULLIF(LTRIM(RTRIM(x.externalKey)), N'') AS k, CONVERT(DATETIME2, SWITCHOFFSET(TRY_CONVERT(DATETIMEOFFSET, x.observedAt), N'+00:00')) AS observed_at,
                             x.attributes
                        FROM OPENJSON(j.[value]) WITH (externalKey NVARCHAR(200), observedAt NVARCHAR(40),
                                                       attributes NVARCHAR(MAX) AS JSON) x) r
         WHERE j.[type] = 5;

        CREATE TABLE #irule (rule_id BIGINT NOT NULL PRIMARY KEY, rule_name NVARCHAR(120) COLLATE DATABASE_DEFAULT NOT NULL, weight INT NOT NULL,
                             strength NVARCHAR(10) COLLATE DATABASE_DEFAULT NOT NULL);
        CREATE TABLE #ra (rule_id BIGINT NOT NULL, field_key NVARCHAR(100) COLLATE DATABASE_DEFAULT NOT NULL, n INT NOT NULL);
        CREATE TABLE #strong (field_key NVARCHAR(100) COLLATE DATABASE_DEFAULT NOT NULL PRIMARY KEY);
        CREATE TABLE #iv (asset_id BIGINT NOT NULL, field_key NVARCHAR(100) COLLATE DATABASE_DEFAULT NOT NULL,
                          norm NVARCHAR(400) COLLATE DATABASE_DEFAULT NOT NULL);
        CREATE INDEX ix_iv ON #iv (field_key, norm) INCLUDE (asset_id);
        INSERT #irule (rule_id, rule_name, weight, strength)
        SELECT rule_id, rule_name, weight, strength FROM grac_practice.asset_identification_rule
         WHERE organization_id = @organization_id AND is_active = 1;
        INSERT #ra (rule_id, field_key, n)
        SELECT r.rule_id, LTRIM(RTRIM(x.value)), COUNT(*) OVER (PARTITION BY r.rule_id)
          FROM grac_practice.asset_identification_rule r
         CROSS APPLY (SELECT DISTINCT value FROM STRING_SPLIT(r.attribute_keys, N',') WHERE LTRIM(RTRIM(value)) <> N'') x
         WHERE r.organization_id = @organization_id AND r.is_active = 1;
        INSERT #strong (field_key)
        SELECT DISTINCT ra.field_key FROM #ra ra JOIN #irule r ON r.rule_id = ra.rule_id
         WHERE r.strength = N'STRONG' AND ra.field_key <> N'@source_key';
        EXEC grac_practice.sp_asset_discovery_identity_load @organization_id = @organization_id, @source_id = @source_id;

        DECLARE @obs BIGINT, @err NVARCHAR(1000);
        DECLARE rec_cur CURSOR LOCAL STATIC FOR
            SELECT observation_id FROM grac_practice.asset_discovery_observation WHERE batch_id = @batch AND outcome IS NULL ORDER BY record_no;
        OPEN rec_cur;
        FETCH NEXT FROM rec_cur INTO @obs;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            BEGIN TRY
                BEGIN TRAN;
                EXEC grac_practice.sp_asset_discovery_reconcile @observation_id = @obs, @actor = @actor;
                COMMIT;
            END TRY
            BEGIN CATCH
                IF XACT_STATE() <> 0 ROLLBACK;
                SET @err = LEFT(ERROR_MESSAGE(), 1000);
                UPDATE grac_practice.asset_discovery_observation SET outcome = N'ERROR', result_text = @err WHERE observation_id = @obs;
                -- the identity values may have changed inside the rolled-back record
                EXEC grac_practice.sp_asset_discovery_identity_load @organization_id = @organization_id, @source_id = @source_id;
            END CATCH
            FETCH NEXT FROM rec_cur INTO @obs;
        END
        CLOSE rec_cur;
        DEALLOCATE rec_cur;

        UPDATE b
           SET record_count = x.total, updated_count = x.upd, no_change_count = x.same, exception_count = x.exc, error_count = x.err,
               status = CASE WHEN x.total > 0 AND x.err = x.total THEN N'FAILED' WHEN x.err > 0 THEN N'PARTIAL' ELSE N'COMPLETED' END,
               completed_dt = SYSUTCDATETIME()
          FROM grac_practice.asset_discovery_batch b
         CROSS APPLY (SELECT COUNT(*) AS total,
                             ISNULL(SUM(CASE WHEN outcome = N'UPDATED' THEN 1 ELSE 0 END), 0) AS upd,
                             ISNULL(SUM(CASE WHEN outcome = N'NO_CHANGE' THEN 1 ELSE 0 END), 0) AS same,
                             ISNULL(SUM(CASE WHEN outcome IN (N'SUGGESTED', N'MANUAL_REVIEW', N'NEW_CANDIDATE', N'POTENTIAL_DUPLICATE')
                                             THEN 1 ELSE 0 END), 0) AS exc,
                             ISNULL(SUM(CASE WHEN outcome = N'ERROR' THEN 1 ELSE 0 END), 0) AS err
                        FROM grac_practice.asset_discovery_observation o WHERE o.batch_id = b.batch_id) x
         WHERE b.batch_id = @batch;
        UPDATE s
           SET last_batch_id = @batch, last_run_dt = SYSUTCDATETIME(), last_run_status = b.status
          FROM grac_practice.asset_discovery_source s
          JOIN grac_practice.asset_discovery_batch b ON b.batch_id = @batch
         WHERE s.source_id = @source_id;

        -- Retention (5.6.1): raw payloads, then observations nothing refers to.
        UPDATE grac_practice.asset_discovery_observation
           SET payload_json = NULL
         WHERE source_id = @source_id AND payload_json IS NOT NULL AND entered_dt < DATEADD(DAY, -@raw_days, SYSUTCDATETIME());
        DELETE o FROM grac_practice.asset_discovery_observation o
         WHERE o.source_id = @source_id AND o.entered_dt < DATEADD(DAY, -@obs_days, SYSUTCDATETIME())
           AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_reconciliation_exception e WHERE e.observation_id = o.observation_id);
        INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
        SELECT N'asset-discovery-batch', b.batch_id, N'INGEST', NULL,
               (SELECT b.batch_reference AS batchReference, b.channel AS channel, b.status AS status, b.record_count AS records,
                       b.updated_count AS updated, b.exception_count AS exceptions, b.error_count AS errors, b.rule_set_version AS ruleSetVersion
                   FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
               N'Active', @actor
          FROM grac_practice.asset_discovery_batch b WHERE b.batch_id = @batch;
        SET @existing = @batch;
    END

    SELECT b.batch_id AS BatchId, b.batch_reference AS BatchReference, b.channel AS Channel, b.status AS Status, b.record_count AS RecordCount,
           b.updated_count AS UpdatedCount, b.no_change_count AS NoChangeCount, b.exception_count AS ExceptionCount,
           b.error_count AS ErrorCount, b.rule_set_version AS RuleSetVersion, b.received_dt AS ReceivedDt, b.completed_dt AS CompletedDt,
           @repeat AS IsRepeat
      FROM grac_practice.asset_discovery_batch b WHERE b.batch_id = @existing;
    SELECT o.record_no AS RecordNo, o.external_key AS ExternalKey, o.outcome AS Outcome, o.match_score AS MatchScore,
           o.matched_asset_id AS MatchedAssetId, a.asset_name AS MatchedAssetName, o.matched_rules AS MatchedRules, o.result_text AS ResultText
      FROM grac_practice.asset_discovery_observation o
      LEFT JOIN grac_practice.organization_dependency_asset a ON a.asset_id = o.matched_asset_id
     WHERE o.batch_id = @existing
     ORDER BY o.record_no;
END
GO
PRINT '442: reconciliation engine created.';
GO
