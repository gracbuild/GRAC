-- =====================================================================
-- 452  Asset & Contract report catalogue and governed CSV export
--      (Asset & Contract Management, Phase 8 increment 5a)
--
-- REQUEST
-- -------
--   BRD v1.7 13.4 Standard Reporting Catalog ("governed report
--   definitions with filters, columns, grouping, authorized drill-down,
--   export controls, schedule, retention and distribution rules"; the
--   report families Asset, Attestation, CMDB and Service, Discovery and
--   Data Quality, Contract, Technology, Risk and CIA, Governance, Privacy
--   and Compliance), 13.4.1 Reporting Controls ("reports shall use the
--   same authorization, tenant, field sensitivity, active configuration
--   and calculation rules as application screens and APIs"; "exports
--   shall record report / version, filters, columns, user, tenant,
--   generation time and classification"; "sensitive exports may require
--   watermarking, encryption, approval, expiry or download restrictions
--   according to policy"; "report totals and dashboard drill-downs shall
--   reconcile to the same filtered source records"), 13.2.7 exports.
--   Plan: docs/asset-contract-management.md (Phase 8.5a, D194-D210).
--
-- WHAT THIS DOES
-- --------------
--   1. asset_report_definition -- the 13.4 catalogue: one row per
--      standard report (family, name, description, version, default
--      classification, the screen whose VIEW permission it needs, the
--      family procedure, the filters it takes and the status options);
--      reports the module cannot produce yet are listed as not available
--      with the place they live today. A changed definition gets a new
--      version number (re-running this script bumps only what changed).
--   2. asset_report_org_setting -- per organization and report: enabled,
--      a higher classification, the export policy (ALLOWED, APPROVER,
--      DISABLED).
--   3. asset_report_export -- immutable export log: report and version,
--      organization, filters, columns, row count, classification, user,
--      employee and time.
--   4. fn_asset_report_assets -- the register rows (sp_asset_register_list
--      status rule, 444 search incl. aliases, 450 "in use") shared by every
--      asset-based report.
--   5. Family procedures sp_asset_report_asset / _attestation / _cmdb /
--      _discovery / _contract / _technology / _risk / _governance /
--      _privacy: one branch per report, same filters and paging.
--   6. sp_asset_report_catalogue, sp_asset_report_run (permission, policy
--      and filter checks, then the family procedure), sp_asset_report_
--      export_log, sp_asset_report_exports, sp_asset_report_org_setting_save.
--   7. Menu Asset & Contract -> Asset Reports (366; also in 274).
--
-- NOT DONE HERE (Phase 8.5b): scheduled delivery, distribution lists and
--   report retention (13.4 "schedule, retention and distribution rules",
--   13.4.1 delivery-time recipient checks); encrypted or expiring files
--   (exports are CSV downloads with a classification watermark); the
--   reports listed as not available (see asset_report_definition).
--
-- ERROR NUMBERS: 53100-53119
--   53100 organization not found        53101 unknown report
--   53102 report not available yet     53103 no permission for the report screen
--   53104 report disabled for the organization
--   53105 export not allowed by policy (or needs Asset Reports APPROVE)
--   53106 filter invalid (dates, days)  53107 export too large
--   53108 classification lower than the default / invalid
--   53109 export policy invalid         53110 report procedure missing
--
-- ALSO EDITED: API (AssetConfig service / controller / models), Web
--   proxy (asset-reports area, caller screen areas), PracticeScreen +
--   Manage.cshtml + appsettings (new screen), new asset-reports.cshtml /
--   .js, 274 (menu), docs.
-- DEPENDS ON: 428-451.
-- Rollback: 452_asset_reports_rollback.sql (drops the 452 objects, the
--   export log and the menu row).
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.sp_dashboard_asset_contract','P') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_governance_assets') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_governance_items') IS NULL
   OR OBJECT_ID('grac_practice.asset_governance_snapshot_item','U') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_privacy_status') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_privacy_gaps') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_privacy_retention_calc') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_technology_status') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_coverage_gaps') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_coverage_summary') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_verification_exception_view') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_ci_catalog') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_discovery_confidence') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_stale_state') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_risk_value') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_field_options') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_contract_sync','P') IS NULL
   OR OBJECT_ID('grac_practice.asset_merge_split_member','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_alias','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_evidence_field','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_valuation_result','U') IS NULL
   OR OBJECT_ID('grac_practice.risk_dependency_map','U') IS NULL
   OR COL_LENGTH('grac_practice.risk_register', 'residual_rating_name') IS NULL
   OR NOT EXISTS (SELECT 1 FROM grac_practice.menu_master WHERE menu_key = N'nav-asset-contract')
BEGIN
    RAISERROR('ABORT (452): run 428-451 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Report catalogue (global) -- BRD 13.4
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_report_definition','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_report_definition (
        report_code            NVARCHAR(40)   NOT NULL CONSTRAINT pk_pm_arpt_def PRIMARY KEY,
        family_code            NVARCHAR(20)   NOT NULL,
        family_name            NVARCHAR(60)   NOT NULL,
        report_name            NVARCHAR(120)  NOT NULL,
        description            NVARCHAR(1000) NOT NULL,
        version_no             INT            NOT NULL CONSTRAINT df_pm_arpt_def_ver DEFAULT 1,
        default_classification NVARCHAR(20)   NOT NULL
            CONSTRAINT ck_pm_arpt_def_cls CHECK (default_classification IN (N'PUBLIC', N'INTERNAL', N'CONFIDENTIAL', N'RESTRICTED')),
        view_area              NVARCHAR(100)  NOT NULL,      -- the screen whose VIEW permission the report needs
        proc_name              NVARCHAR(128)  NULL,          -- family procedure (grac_practice schema)
        is_available           BIT            NOT NULL,
        unavailable_reason     NVARCHAR(400)  NULL,
        filter_keys            NVARCHAR(200)  NOT NULL,      -- comma list: SEARCH, STATUS, ASSET_TYPE, DATE_RANGE, DAYS
        status_label           NVARCHAR(60)   NULL,
        status_options         NVARCHAR(1000) NULL,          -- CODE=Label|CODE=Label, or @ASSET_STATUS
        date_label             NVARCHAR(60)   NULL,
        default_days           INT            NULL,
        display_order          INT            NOT NULL,
        brd_reference          NVARCHAR(40)   NOT NULL,
        is_active              BIT            NOT NULL CONSTRAINT df_pm_arpt_def_act DEFAULT 1,
        entered_by             NVARCHAR(100)  NOT NULL CONSTRAINT df_pm_arpt_def_eby DEFAULT N'system',
        entered_dt             DATETIME2      NOT NULL CONSTRAINT df_pm_arpt_def_edt DEFAULT SYSUTCDATETIME(),
        updated_by             NVARCHAR(100)  NULL,
        updated_dt             DATETIME2      NULL,
        CONSTRAINT ck_pm_arpt_def_avail CHECK (is_available = 0 OR proc_name IS NOT NULL)
    );
    PRINT '452: asset_report_definition created.';
END
GO

IF OBJECT_ID('grac_practice.asset_report_org_setting','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_report_org_setting (
        organization_id BIGINT        NOT NULL
            CONSTRAINT fk_pm_arpt_os_org REFERENCES grac_practice.organization(organization_id),
        report_code     NVARCHAR(40)  NOT NULL
            CONSTRAINT fk_pm_arpt_os_def REFERENCES grac_practice.asset_report_definition(report_code),
        is_enabled      BIT           NOT NULL CONSTRAINT df_pm_arpt_os_en DEFAULT 1,
        classification  NVARCHAR(20)  NULL           -- NULL = the default classification
            CONSTRAINT ck_pm_arpt_os_cls CHECK (classification IS NULL
                OR classification IN (N'PUBLIC', N'INTERNAL', N'CONFIDENTIAL', N'RESTRICTED')),
        export_policy   NVARCHAR(10)  NULL           -- NULL = APPROVER when RESTRICTED, else ALLOWED
            CONSTRAINT ck_pm_arpt_os_pol CHECK (export_policy IS NULL OR export_policy IN (N'ALLOWED', N'APPROVER', N'DISABLED')),
        entered_by      NVARCHAR(100) NOT NULL CONSTRAINT df_pm_arpt_os_eby DEFAULT N'system',
        entered_dt      DATETIME2     NOT NULL CONSTRAINT df_pm_arpt_os_edt DEFAULT SYSUTCDATETIME(),
        updated_by      NVARCHAR(100) NULL,
        updated_dt      DATETIME2     NULL,
        CONSTRAINT pk_pm_arpt_os PRIMARY KEY (organization_id, report_code)
    );
    PRINT '452: asset_report_org_setting created.';
END
GO

IF OBJECT_ID('grac_practice.asset_report_export','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_report_export (
        export_id            BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_arpt_exp PRIMARY KEY,
        organization_id      BIGINT         NOT NULL
            CONSTRAINT fk_pm_arpt_exp_org REFERENCES grac_practice.organization(organization_id),
        report_code          NVARCHAR(40)   NOT NULL
            CONSTRAINT fk_pm_arpt_exp_def REFERENCES grac_practice.asset_report_definition(report_code),
        report_version       INT            NOT NULL,
        report_name          NVARCHAR(120)  NOT NULL,
        classification       NVARCHAR(20)   NOT NULL,
        file_format          NVARCHAR(10)   NOT NULL CONSTRAINT df_pm_arpt_exp_fmt DEFAULT N'CSV'
            CONSTRAINT ck_pm_arpt_exp_fmt CHECK (file_format IN (N'CSV')),
        filters_json         NVARCHAR(MAX)  NULL,
        columns_json         NVARCHAR(MAX)  NULL,
        row_count            INT            NOT NULL,
        exported_by          NVARCHAR(100)  NOT NULL,
        exported_employee_id BIGINT         NULL,
        exported_dt          DATETIME2      NOT NULL CONSTRAINT df_pm_arpt_exp_dt DEFAULT SYSUTCDATETIME()
    );
    CREATE INDEX ix_pm_arpt_exp_org ON grac_practice.asset_report_export(organization_id, exported_dt DESC);
    PRINT '452: asset_report_export created.';
END
GO
