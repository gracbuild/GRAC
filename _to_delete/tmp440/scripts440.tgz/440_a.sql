-- =====================================================================
-- 440  CMDB relationships: relationship types, effective-dated asset /
--      configuration-item relationships with governance, impact analysis
--      and the retirement gate (Asset & Contract Management, Phase 7
--      increment 1)
--
-- REQUEST
-- -------
--   BRD v1.7 5.4 "Asset Relationships and Dependency Mapping": effective-
--   dated, directional, auditable relationships among assets, applications,
--   processes, suppliers and locations (business services follow in 7.2);
--   the twelve relationship types (Parent / Child, Depends On, Hosted On,
--   Runs On, Connected To, Protects, Stores Data For, Backed Up By,
--   Monitored By, Supports Service, Located In, Replaces); 5.4.1 record
--   fields (ID, source / target CI, type with direction and inverse label,
--   critical dependency and criticality, impact weight, status Proposed /
--   Active / Disputed / Inactive / Retired, effective from / to, source,
--   confidence, owner / verifier, evidence / change reference, audit);
--   5.4.2 governance (type masters define permitted source / target
--   classes, direction, cardinality and loop rules; circular dependencies
--   blocked where configured and permitted loops flagged; changes to
--   critical relationships need impact preview and approval; impact
--   analysis traverses a configurable upstream / downstream depth without
--   double counting a CI; retiring an asset is blocked until its active
--   critical dependencies are reassigned, accepted as exceptions or closed;
--   history survives retirement); 5.4.4 acceptance criteria. Plan:
--   docs/asset-contract-management.md (Phase 7.1, D79-D87).
--
-- WHAT THIS DOES
-- --------------
--   1. asset_relationship_type (global): the twelve BRD types with label and
--      inverse label, permitted source / target kinds, cardinality, loop
--      rule and the dependent side used by impact analysis. Supports
--      Service is inactive until business services exist (7.2).
--   2. asset_relationship (per organization) and asset_relationship_history
--      (one row per version / action -- topology history).
--   3. CI catalogue (fn_asset_ci_catalog): assets, applications, processes,
--      vendors and locations of the organization as relationship endpoints.
--   4. Governance: type, kinds, endpoints, duplicates, cardinality and
--      loops checked on proposal and on approval; proposals approved by a
--      holder of APPROVE (another person for a critical relationship);
--      changes to an active critical relationship and its retirement wait
--      for approval (pending change); dispute / confirm; retire; acceptance
--      of a critical dependency for retirement; effective-to expiry.
--   5. Impact analysis (sp_asset_ci_impact): downstream (what is affected
--      when the CI fails) or upstream (what the CI relies on), depth 1-10,
--      critical-only, each CI once at its nearest level; preview of a
--      proposed relationship.
--   6. Lifecycle gate: sp_asset_lifecycle_transition (435 body) re-issued --
--      moving an asset into sanitization, disposal approval, Disposed or
--      Archived is blocked while active critical relationships depend on it
--      and were not accepted for retirement.
--   7. Asset Relationships screen (menu row, readers / writers).
--
-- NOT DONE HERE: business services and the Supports Service type (7.2);
--   discovered / imported / inferred relationships and their confidence
--   (7.3); service, risk, change and continuity reviews raised by a
--   relationship change (later phases); organization-defined relationship
--   types; the retirement gate on the approval of an already requested
--   lifecycle change (checked when it is requested).
--
-- ERROR NUMBERS: 54701-54729 (54700 is used by 047)
--   54701 organization not found           54702 unknown / inactive type
--   54703 kind not permitted for the type  54704 endpoint not found / not usable
--   54705 source and target are the same   54706 relationship already exists
--   54707 cardinality                      54708 circular dependency blocked
--   54709 relationship not found           54710 changed by someone else
--   54711 not editable in its status       54712 a change is already pending
--   54713 reason / note required           54714 effective dates
--   54715 action not valid now             54716 segregation of duties
--   54717 criticality / weight / confidence 54718 owner / verifier
--   54719 retirement blocked (lifecycle)   54720 CI kind / direction not valid
--
-- ALSO EDITED: API (AssetConfig service / controller / models), Web proxy,
--   PracticeScreen + Manage.cshtml + appsettings, asset-relationships.cshtml
--   / .js (new), 274 (menu), docs.
-- DEPENDS ON: 428, 429, 435.
-- Rollback: 440_asset_relationships_rollback.sql
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.sp_asset_lifecycle_transition','P') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_coverage_gaps') IS NULL
   OR COL_LENGTH('grac_practice.organization_dependency_asset','current_status_id') IS NULL
   OR COL_LENGTH('grac_practice.organization_dependency_asset','template_id') IS NULL
   OR OBJECT_ID('grac_practice.asset_lifecycle_transition_gate','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_lifecycle_change','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_legacy_status_map','U') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_lifecycle_apply','P') IS NULL
BEGIN
    RAISERROR('ABORT (440): run 428, 429 and 435 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Relationship types (global, BRD 5.4)
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_relationship_type','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_relationship_type (
        type_code       NVARCHAR(30)  NOT NULL CONSTRAINT pk_pm_asset_rel_type PRIMARY KEY,
        type_name       NVARCHAR(100) NOT NULL,     -- forward label: source <type_name> target
        inverse_label   NVARCHAR(100) NOT NULL,     -- target <inverse_label> source
        brd_pair        NVARCHAR(100) NOT NULL,
        description     NVARCHAR(400) NOT NULL,
        source_kinds    NVARCHAR(200) NOT NULL,     -- comma list of ASSET, APPLICATION, PROCESS, VENDOR, LOCATION, SERVICE
        target_kinds    NVARCHAR(200) NOT NULL,
        cardinality     NVARCHAR(12)  NOT NULL
            CONSTRAINT ck_pm_asset_rel_type_card CHECK (cardinality IN (N'MANY', N'ONE_TARGET', N'ONE_SOURCE', N'ONE_TO_ONE')),
        loop_rule       NVARCHAR(6)   NOT NULL
            CONSTRAINT ck_pm_asset_rel_type_loop CHECK (loop_rule IN (N'BLOCK', N'FLAG', N'ALLOW')),
        dependent_side  NVARCHAR(6)   NOT NULL      -- the side that is impacted when the other fails
            CONSTRAINT ck_pm_asset_rel_type_dep CHECK (dependent_side IN (N'SOURCE', N'TARGET', N'NONE')),
        is_active       BIT           NOT NULL,
        inactive_reason NVARCHAR(200) NULL,
        display_order   INT           NOT NULL,
        entered_by      NVARCHAR(100) NOT NULL CONSTRAINT df_pm_asset_rel_type_eby DEFAULT N'system',
        entered_dt      DATETIME2     NOT NULL CONSTRAINT df_pm_asset_rel_type_edt DEFAULT SYSUTCDATETIME()
    );
    PRINT '440: asset_relationship_type created.';
END
GO

MERGE grac_practice.asset_relationship_type AS t
USING (VALUES
    (N'CONTAINS', N'Contains', N'Is part of', N'Parent / Child', N'Chassis contains module; an enclosure contains a component.',
     N'ASSET', N'ASSET', N'ONE_SOURCE', N'BLOCK', N'TARGET', 1, NULL, 10),
    (N'DEPENDS_ON', N'Depends on', N'Is required by', N'Depends On / Required By', N'Application depends on database.',
     N'ASSET,APPLICATION,PROCESS', N'ASSET,APPLICATION,PROCESS,VENDOR', N'MANY', N'BLOCK', N'SOURCE', 1, NULL, 20),
    (N'HOSTED_ON', N'Is hosted on', N'Hosts', N'Hosted On / Hosts', N'Virtual machine is hosted on a hypervisor.',
     N'ASSET,APPLICATION', N'ASSET', N'ONE_TARGET', N'BLOCK', N'SOURCE', 1, NULL, 30),
    (N'RUNS_ON', N'Runs on', N'Runs', N'Runs On / Runs', N'Application runs on a server.',
     N'APPLICATION', N'ASSET', N'MANY', N'BLOCK', N'SOURCE', 1, NULL, 40),
    (N'CONNECTED_TO', N'Is connected to', N'Is connected to', N'Connected To', N'Device or network connection.',
     N'ASSET', N'ASSET', N'MANY', N'ALLOW', N'NONE', 1, NULL, 50),
    (N'PROTECTS', N'Protects', N'Is protected by', N'Protects / Protected By', N'Firewall protects an application or network.',
     N'ASSET,APPLICATION', N'ASSET,APPLICATION', N'MANY', N'FLAG', N'TARGET', 1, NULL, 60),
    (N'STORES_DATA_FOR', N'Stores data for', N'Has data stored in', N'Stores Data For', N'Database or storage supports an application or process.',
     N'ASSET,APPLICATION', N'APPLICATION,PROCESS', N'MANY', N'BLOCK', N'TARGET', 1, NULL, 70),
    (N'BACKED_UP_BY', N'Is backed up by', N'Backs up', N'Backed Up By', N'Asset is protected by a backup system or provider.',
     N'ASSET,APPLICATION', N'ASSET,APPLICATION,VENDOR', N'MANY', N'FLAG', N'SOURCE', 1, NULL, 80),
    (N'MONITORED_BY', N'Is monitored by', N'Monitors', N'Monitored By', N'Asset sends telemetry to a monitoring tool or provider.',
     N'ASSET,APPLICATION', N'ASSET,APPLICATION,VENDOR', N'MANY', N'ALLOW', N'NONE', 1, NULL, 90),
    (N'SUPPORTS_SERVICE', N'Supports service', N'Is supported by', N'Supports Service / Supported By', N'Asset contributes to a business service.',
     N'ASSET,APPLICATION,PROCESS,VENDOR', N'SERVICE', N'MANY', N'BLOCK', N'TARGET', 0, N'Available with business services (Phase 7.2).', 100),
    (N'LOCATED_IN', N'Is located in', N'Contains', N'Located In / Contains', N'Asset placed within a rack, cabinet or enclosure asset, or a site.',
     N'ASSET', N'ASSET,LOCATION', N'ONE_TARGET', N'BLOCK', N'SOURCE', 1, NULL, 110),
    (N'REPLACES', N'Replaces', N'Is replaced by', N'Replaces / Replaced By', N'Successor / predecessor lifecycle link.',
     N'ASSET', N'ASSET', N'ONE_TO_ONE', N'BLOCK', N'NONE', 1, NULL, 120)
) AS s(type_code, type_name, inverse_label, brd_pair, description, source_kinds, target_kinds, cardinality, loop_rule,
       dependent_side, is_active, inactive_reason, display_order)
ON t.type_code = s.type_code
WHEN NOT MATCHED BY TARGET THEN
    INSERT (type_code, type_name, inverse_label, brd_pair, description, source_kinds, target_kinds, cardinality, loop_rule,
            dependent_side, is_active, inactive_reason, display_order, entered_by)
    VALUES (s.type_code, s.type_name, s.inverse_label, s.brd_pair, s.description, s.source_kinds, s.target_kinds, s.cardinality,
            s.loop_rule, s.dependent_side, s.is_active, s.inactive_reason, s.display_order, N'seed-440');
PRINT CONCAT('440: relationship types inserted: ', @@ROWCOUNT);
GO

-- =====================================================================
-- 2. Relationships and their history (5.4.1)
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_relationship','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_relationship (
        relationship_id          BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_asset_rel PRIMARY KEY,
        organization_id          BIGINT         NOT NULL,
        relationship_type_code   NVARCHAR(30)   NOT NULL
            CONSTRAINT fk_pm_asset_rel_type REFERENCES grac_practice.asset_relationship_type(type_code),
        source_kind              NVARCHAR(12)   NOT NULL
            CONSTRAINT ck_pm_asset_rel_skind CHECK (source_kind IN (N'ASSET', N'APPLICATION', N'PROCESS', N'VENDOR', N'LOCATION', N'SERVICE')),
        source_id                BIGINT         NOT NULL,
        target_kind              NVARCHAR(12)   NOT NULL
            CONSTRAINT ck_pm_asset_rel_tkind CHECK (target_kind IN (N'ASSET', N'APPLICATION', N'PROCESS', N'VENDOR', N'LOCATION', N'SERVICE')),
        target_id                BIGINT         NOT NULL,
        is_critical              BIT            NOT NULL CONSTRAINT df_pm_asset_rel_crit DEFAULT 0,
        dependency_criticality   NVARCHAR(10)   NULL
            CONSTRAINT ck_pm_asset_rel_depcrit CHECK (dependency_criticality IS NULL
                OR dependency_criticality IN (N'CRITICAL', N'HIGH', N'MEDIUM', N'LOW')),
        impact_weight            DECIMAL(5, 2)  NULL,
        status                   NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_asset_rel_status CHECK (status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED', N'INACTIVE', N'RETIRED')),
        effective_from           DATE           NOT NULL,
        effective_to             DATE           NULL,
        source_code              NVARCHAR(10)   NOT NULL CONSTRAINT df_pm_asset_rel_src DEFAULT N'MANUAL'
            CONSTRAINT ck_pm_asset_rel_src CHECK (source_code IN (N'MANUAL', N'DISCOVERY', N'IMPORT', N'API', N'INFERENCE')),
        confidence_pct           INT            NULL,
        verification_status      NVARCHAR(10)   NOT NULL CONSTRAINT df_pm_asset_rel_ver DEFAULT N'UNVERIFIED'
            CONSTRAINT ck_pm_asset_rel_ver CHECK (verification_status IN (N'VERIFIED', N'UNVERIFIED')),
        owner_employee_id        BIGINT         NULL
            CONSTRAINT fk_pm_asset_rel_owner REFERENCES grac_practice.organization_employee(employee_id),
        verifier_employee_id     BIGINT         NULL
            CONSTRAINT fk_pm_asset_rel_verifier REFERENCES grac_practice.organization_employee(employee_id),
        evidence_reference       NVARCHAR(400)  NULL,
        change_reference         NVARCHAR(200)  NULL,
        reason                   NVARCHAR(1000) NULL,
        in_loop                  BIT            NOT NULL CONSTRAINT df_pm_asset_rel_loop DEFAULT 0,
        version_no               INT            NOT NULL CONSTRAINT df_pm_asset_rel_vno DEFAULT 1,
        proposed_by              NVARCHAR(100)  NOT NULL,
        proposed_by_employee_id  BIGINT         NULL,
        proposed_dt              DATETIME2      NOT NULL CONSTRAINT df_pm_asset_rel_pdt DEFAULT SYSUTCDATETIME(),
        approved_by              NVARCHAR(100)  NULL,
        approved_by_employee_id  BIGINT         NULL,
        approved_dt              DATETIME2      NULL,
        pending_action           NVARCHAR(10)   NULL
            CONSTRAINT ck_pm_asset_rel_pend CHECK (pending_action IS NULL OR pending_action IN (N'UPDATE', N'RETIRE')),
        pending_json             NVARCHAR(MAX)  NULL,
        pending_reason           NVARCHAR(1000) NULL,
        pending_by               NVARCHAR(100)  NULL,
        pending_by_employee_id   BIGINT         NULL,
        pending_dt               DATETIME2      NULL,
        retirement_accepted      BIT            NOT NULL CONSTRAINT df_pm_asset_rel_racc DEFAULT 0,
        retirement_note          NVARCHAR(1000) NULL,
        retirement_accepted_by   NVARCHAR(100)  NULL,
        retirement_accepted_dt   DATETIME2      NULL,
        status_note              NVARCHAR(1000) NULL,      -- dispute / rejection / retirement note
        entered_by               NVARCHAR(100)  NOT NULL CONSTRAINT df_pm_asset_rel_eby DEFAULT N'system',
        entered_dt               DATETIME2      NOT NULL CONSTRAINT df_pm_asset_rel_edt DEFAULT SYSUTCDATETIME(),
        updated_by               NVARCHAR(100)  NULL,
        updated_dt               DATETIME2      NULL,
        record_version           ROWVERSION     NOT NULL,
        CONSTRAINT ck_pm_asset_rel_dates CHECK (effective_to IS NULL OR effective_to >= effective_from),
        CONSTRAINT ck_pm_asset_rel_weight CHECK (impact_weight IS NULL OR impact_weight BETWEEN 0 AND 100),
        CONSTRAINT ck_pm_asset_rel_conf CHECK (confidence_pct IS NULL OR confidence_pct BETWEEN 0 AND 100)
    );
    -- One current relationship of a type between the same two CIs.
    CREATE UNIQUE INDEX ux_pm_asset_rel_current ON grac_practice.asset_relationship
        (organization_id, relationship_type_code, source_kind, source_id, target_kind, target_id)
        WHERE status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED');
    CREATE INDEX ix_pm_asset_rel_org ON grac_practice.asset_relationship(organization_id, status);
    CREATE INDEX ix_pm_asset_rel_src ON grac_practice.asset_relationship(source_kind, source_id);
    CREATE INDEX ix_pm_asset_rel_tgt ON grac_practice.asset_relationship(target_kind, target_id);
    PRINT '440: asset_relationship created.';
END
GO

IF OBJECT_ID('grac_practice.asset_relationship_history','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_relationship_history (
        history_id        BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_asset_rel_hist PRIMARY KEY,
        relationship_id   BIGINT         NOT NULL
            CONSTRAINT fk_pm_asset_rel_hist_rel REFERENCES grac_practice.asset_relationship(relationship_id),
        organization_id   BIGINT         NOT NULL,
        version_no        INT            NOT NULL,
        action_code       NVARCHAR(20)   NOT NULL,
        status            NVARCHAR(10)   NOT NULL,
        snapshot_json     NVARCHAR(MAX)  NOT NULL,
        note              NVARCHAR(1000) NULL,
        actor             NVARCHAR(100)  NOT NULL,
        actor_employee_id BIGINT         NULL,
        entered_dt        DATETIME2      NOT NULL CONSTRAINT df_pm_asset_rel_hist_edt DEFAULT SYSUTCDATETIME()
    );
    CREATE INDEX ix_pm_asset_rel_hist_rel ON grac_practice.asset_relationship_history(relationship_id, history_id);
    PRINT '440: asset_relationship_history created.';
END
GO
