import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (a[:60], s.count(a))
    s = s.replace(a, b)

rep("execution with per-object outcomes, aliases and recovery (`444`).",
    "execution with per-object outcomes, aliases and recovery (`444`), Phase 7.4c asset split -- resulting Draft records, allocation of items and field values, approval, execution and recovery (`445`).")
rep("| 7.4c | Asset split (5.6.3, 19.4): resulting records, allocation of observations / relationships / evidence / history, approval, controlled recombine | | 7.4b |",
    "| 7.4c **(done)** | Asset split (5.6.3, 19.4): source (keeps its ID) and 1-5 resulting records registered as new Draft assets; allocation of current relationships, source records and values, open items, coverage, risk and practice mappings, and field values (copy / move); impact, blockers, approval (two for critical CIs), execution with per-object outcomes, recovery; Splits tab. Merge and split share the object moves and the action procedure | 445 | 7.4b |")
rep("""| D33 | **Cancel keeps the asset status** (433)""",
"""| D125 | **Split event** (445): the 444 event tables with kind SPLIT -- the source keeps its ID (event survivor), the resulting records (1-5) are members with role RESULT. Resulting records are new Draft assets registered on the Asset Register form first, so each meets the identity and mandatory rules of its form (19.4 validation) and stays Draft until its own lifecycle gates are passed. Same statuses, actions, approval and two-person rule as merges (one action procedure for both kinds). | BRD 5.6.3 Split, 19.4. | Yes. |
| D126 | **Shared moves**: the object moves of 444 are now `sp_asset_merge_split_move` (same statements, called by merge and split); `sp_asset_merge_execute_one` re-issued to call it. Merge behaviour is unchanged. | Project rule: no duplicated code. | Yes. |
| D127 | **Allocation**: the items of the source are those a merge would move (current relationships, discovery links, per-source values, open reconciliation exceptions, coverage lines, open activities, active restrictive reviews, risk mappings, risk links, practice dependency resolutions); each is allocated to one resulting record or stays with the source. For the chosen record an item moves, is blocked (the record already has that open activity / review) or stays (the record already holds the equivalent, or a relationship would refer to the record itself). History rows are not allocated and stay with the source. | BRD 19.4 preview "proposed allocation". | Yes -- history allocation is not supported. |
| D128 | **Field values**: user-entered value fields of the source are copied to the chosen record (replacing its value) or moved (copied, then taken off the source). | BRD 19.4. | Yes. |
| D129 | **Blockers**: source disposed, archived or merged; a pending lifecycle change or open workflow case on the source; a resulting record that is not a Draft of the organization; nothing allocated; an allocation that no longer matches the source; a blocked allocation. Checked at Submit and Execute. | BRD 19.4 validation. | Yes. |
| D130 | **Recovery** (the 444 procedure, re-issued): every split outcome row is reversed where still possible; a value moved off the source is put back when the source still has none. The resulting records stay as Draft assets (retire them on the Asset Register if they are not wanted). | BRD 19.4 "controlled recombine / correction event". | Yes. |
| D131 | **Not in 7.4c**: allocation of history (lifecycle, custody, attestations, results, renewals, notifications); creating the resulting records inside the split; bulk splits. | BRD 19.4. | Yes. |
| D33 | **Cancel keeps the asset status** (433)""")
rep("""### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""",
"""### Asset split (445)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `discovery/splits?organizationId=&status=&search=&pageNumber=&pageSize=` | Splits (status empty = open; ALL; one status) | `sp_asset_merge_events` (`@event_kind = SPLIT`) |
| GET | `discovery/splits/{id}?organizationId=` | `{split, assets, approvals, blockers, plan (allocation), outcomes, impact}` | `sp_asset_split_get` (`fn_asset_split_plan`, `fn_asset_split_blockers`) |
| POST | `discovery/splits` | `{organizationId, eventId?, sourceAssetId, resultAssetIds: [..], reason?, allocations: [{objectKind, objectId, objectKey, targetAssetId, fieldMode?}], expectedRecordVersion?}` -> CREATED / SAVED | `sp_asset_split_save` |
| POST | `discovery/splits/{id}/action` | as merges | `sp_asset_merge_action` (-> `sp_asset_split_execute`, `sp_asset_merge_recover`) |

Proxy: as merges. Errors `52900-52917`; 52915 resulting records 1-5, 52916 resulting record not a new Draft, 52917 allocation invalid.

### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""")
rep("""## 8. Verification (static -- no compiler or database on this machine)""",
"""### Phase 7.4c files (445)
| Layer | File | Change |
|---|---|---|
| DB | `database/445_asset_split.sql` (+ rollback restoring the four 444 bodies) | `asset_split_allocation`; `sp_asset_merge_split_move`; `fn_asset_split_plan`, `fn_asset_split_blockers`; `sp_asset_split_save / _execute / _get`. Re-issued: `sp_asset_merge_execute_one`, `sp_asset_merge_recover`, `sp_asset_merge_action`, `sp_asset_merge_events`. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 4 routes; split save request; event list shared by kind. |
| Web | `Controllers/AssetConfigController.cs` | Split permissions (as merges). |
| Web | `Partials/asset-discovery.cshtml`, `js/AssetConfig/asset-discovery.js` | Splits tab and split window (results, allocation, impact, blockers, outcomes, approvals); event actions shared with merges. |

## 8. Verification (static -- no compiler or database on this machine)""")
s = s.rstrip('\n') + """

445 got the same sweep (clean), the semicolon-before-ELSE scan (the new recovery branch wrapped in BEGIN / END before delivery), OPENJSON / temp-table collation rules, the parameter check of every EXEC, a diff of the four re-issued 444 procedures against their sources (marked lines; the moved block of `sp_asset_merge_execute_one` checked to be the 444 statements with the four renames only), the C#-to-procedure parameter and string-size cross-check, the JS-to-alias and HTML-id / duplicate-id checks, `node --check`, brace / parenthesis / bracket balance and the ASCII check. Its verification block checks the table, the split objects, the four re-issues and that the split functions run. Not compiled or executed. Phase 7 is complete; next: Phase 8 (CIA valuation and risk profiles, privacy, dashboards, report catalogue, exports).
"""
open(p, 'w', encoding='utf-8', newline='').write(s)
print('doc ok')
