
-- =====================================================================
-- 7. Verification
-- =====================================================================
SELECT '452-a tables' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_report_definition','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_report_org_setting','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_report_export','U') IS NOT NULL
            THEN 'PASS' ELSE 'FAIL' END AS Result
UNION ALL
SELECT '452-b functions and procedures present',
       CASE WHEN OBJECT_ID('grac_practice.fn_asset_report_assets') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_report_contracts') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_report_relationships') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_report_effective') IS NOT NULL
             AND (SELECT COUNT(*) FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'grac_practice'
                   AND name IN ('sp_asset_report_asset', 'sp_asset_report_attestation', 'sp_asset_report_cmdb',
                                'sp_asset_report_discovery', 'sp_asset_report_contract', 'sp_asset_report_technology',
                                'sp_asset_report_risk', 'sp_asset_report_governance', 'sp_asset_report_privacy',
                                'sp_asset_report_catalogue', 'sp_asset_report_run', 'sp_asset_report_export_log',
                                'sp_asset_report_exports', 'sp_asset_report_org_setting_save')) = 14
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '452-c catalogue: 53 reports in 9 families, 47 available, every family procedure exists',
       CASE WHEN (SELECT COUNT(*) FROM grac_practice.asset_report_definition WHERE is_active = 1) = 53
             AND (SELECT COUNT(DISTINCT family_code) FROM grac_practice.asset_report_definition WHERE is_active = 1) = 9
             AND (SELECT COUNT(*) FROM grac_practice.asset_report_definition WHERE is_active = 1 AND is_available = 1) = 47
             AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_report_definition
                              WHERE is_active = 1 AND OBJECT_ID(N'grac_practice.' + QUOTENAME(proc_name), 'P') IS NULL)
             AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_report_definition
                              WHERE is_available = 0 AND unavailable_reason IS NULL)
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '452-d filter keys are known tokens',
       CASE WHEN NOT EXISTS (SELECT 1 FROM grac_practice.asset_report_definition d
                             CROSS APPLY STRING_SPLIT(d.filter_keys, N',') k
                              WHERE k.value NOT IN (N'SEARCH', N'STATUS', N'ASSET_TYPE', N'DATE_RANGE', N'DAYS'))
             AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_report_definition
                              WHERE CHARINDEX(N'DAYS', filter_keys) > 0 AND default_days IS NULL)
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '452-e menu: Asset Reports under Asset & Contract with Admin VIEW / EDIT / APPROVE',
       CASE WHEN EXISTS (SELECT 1 FROM grac_practice.menu_master c
                           JOIN grac_practice.menu_master p ON p.menu_id = c.parent_menu_id AND p.menu_key = N'nav-asset-contract'
                          WHERE c.menu_key = N'asset-reports' AND c.status = N'Active')
             AND EXISTS (SELECT 1 FROM grac_practice.organization_role_menu_permission g
                           JOIN grac_practice.menu_master m ON m.menu_id = g.menu_id AND m.menu_key = N'asset-reports'
                           JOIN grac_practice.organization_role r ON r.role_id = g.role_id AND r.role_name = N'Admin'
                          WHERE g.can_view = 1 AND g.can_edit = 1 AND g.can_approve = 1)
            THEN 'PASS' ELSE 'FAIL' END;
GO

-- Every available report runs for the first organization with assets
-- (one page of one row each; the grids are the smoke output). The last
-- result lists the reports that raised an error (none expected).
DECLARE @org BIGINT = (SELECT TOP (1) organization_id FROM grac_practice.organization_dependency_asset ORDER BY organization_id);
DECLARE @areas NVARCHAR(2000) = (SELECT STRING_AGG(v.view_area, N',')
                                   FROM (SELECT DISTINCT view_area FROM grac_practice.asset_report_definition) v);
DECLARE @failed TABLE (report_code NVARCHAR(40), error_number INT, error_message NVARCHAR(4000));
DECLARE @code NVARCHAR(40);
DECLARE rpt CURSOR LOCAL FAST_FORWARD FOR
    SELECT report_code FROM grac_practice.asset_report_definition
     WHERE @org IS NOT NULL AND is_active = 1 AND is_available = 1 ORDER BY display_order;
OPEN rpt;
FETCH NEXT FROM rpt INTO @code;
WHILE @@FETCH_STATUS = 0
BEGIN
    BEGIN TRY
        EXEC grac_practice.sp_asset_report_run @organization_id = @org, @report_code = @code, @allowed_areas = @areas,
             @page_number = 1, @page_size = 1;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK;
        INSERT @failed VALUES (@code, ERROR_NUMBER(), ERROR_MESSAGE());
    END CATCH
    FETCH NEXT FROM rpt INTO @code;
END
CLOSE rpt;
DEALLOCATE rpt;
SELECT '452-f every available report runs' AS Check_,
       CASE WHEN @org IS NULL THEN 'SKIPPED (no organization has assets)'
            WHEN NOT EXISTS (SELECT 1 FROM @failed) THEN 'PASS' ELSE 'FAIL' END AS Result;
SELECT report_code AS FailedReport, error_number AS ErrorNumber, error_message AS ErrorMessage FROM @failed;
GO

/* =====================================================================
   UAT (re-login after running 452; Admin, then a role with VIEW on
   Asset Register only)
   ---------------------------------------------------------------------
   1. Asset & Contract -> Asset Reports: the catalogue lists the reports
      of the screens the role may VIEW, grouped by family, each with its
      classification and version; not-available reports show where the
      information lives today and cannot be run.
   2. Complete Asset Register, status Active: the total equals the Asset
      Register filtered to Active (same search, alias search included).
   3. Coverage Gaps: the total equals Asset Contracts -> Coverage gaps;
      Overdue Attestations equals Asset Attestation filtered to Overdue;
      Asset Value Distribution equals the dashboard bars "Assets in use
      by Asset Value".
   4. Export CSV: the file starts with the report, version, organization,
      classification, exported by, UTC time and filters lines, then the
      columns shown on screen; Export history lists it with the same
      filters, columns and row count.
   5. Settings (Admin): set Vendor Contact Matrix to RESTRICTED -> its
      export needs Asset Reports APPROVE (a role without it gets 53105);
      set a report to INTERNAL below its CONFIDENTIAL default -> refused
      (53108); disable a report -> it cannot be run (53104).
   6. Role with Asset Register VIEW only: contract, privacy and risk
      reports are not listed; calling their run URL directly returns 403
      (53103).
   7. Source Health with Days 7: batch counts cover the last 7 days only.
   ===================================================================== */
