# 444_e2.sql: sp_asset_register_list (429) re-issued with alias search; rollback body.
import re
src = open("/mnt/user-data/uploads/PracticeManagement/database/429_asset_lifecycle_transitions.sql").read()
m = re.search(r"CREATE OR ALTER PROCEDURE grac_practice\.sp_asset_register_list\n.*?\nEND\nGO\n", src, re.S)
body = m.group(0)
open("/home/claude/reglist429_body.sql", "w").write(body)
old = """           AND (@search IS NULL OR a.asset_name LIKE N'%' + @search + N'%' OR CAST(a.asset_id AS NVARCHAR(30)) = @search)
"""
assert body.count(old) == 1
new = """           AND (@search IS NULL OR a.asset_name LIKE N'%' + @search + N'%' OR CAST(a.asset_id AS NVARCHAR(30)) = @search   -- 444
                OR EXISTS (SELECT 1 FROM grac_practice.asset_alias al   -- 444
                            WHERE al.asset_id = a.asset_id AND al.is_active = 1 AND al.alias_value LIKE N'%' + @search + N'%'))   -- 444
"""
body = body.replace(old, new)
hdr = """
-- =====================================================================
-- 9. sp_asset_register_list (429) re-issued: the search also finds the
--    aliases a merge kept on the survivor (19.4 "aliases and external
--    identifiers remain searchable"). Otherwise unchanged.
-- =====================================================================
"""
open("/home/claude/444_e2.sql", "w").write(hdr + body + "PRINT '444: sp_asset_register_list re-issued.';\nGO\n")
print("r444 ok")
