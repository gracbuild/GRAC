import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (a[:60], s.count(a))
    s = s.replace(a, b)

rep("Phase 6.1 notification profiles, reminders, escalation and the scheduler pass in the existing background worker (`437`).",
    "Phase 6.1 notification profiles, reminders, escalation and the scheduler pass in the existing background worker (`437`), Phase 6.2 recurring asset activities -- schedules, occurrences, contract-versus-asset task generation, campaigns (`438`).")
rep("| 6.2 | Activity templates and asset schedules (calibration, preventive maintenance / inspection, standalone licence), contract-vs-asset task generation (7.1.1-7.1.5, 7.1.7) into `practice_task` with occurrence keys, campaigns with one item per asset; raises the Calibration / Maintenance / Standalone licence notifications | | 6.1 |",
    "| 6.2 **(done)** | Activity templates (Calibration, Preventive maintenance, Statutory inspection, Equipment licence renewal) with organization settings; schedules from the register fields (applicable, frequency, basis, last / expiry date) and contract coverage, with next due date and Valid / Due Soon / Overdue / Covered / Not scheduled; occurrences with occurrence key and one open per asset and template; contract-versus-asset decision (7.1.1-7.1.4: execution -> one Task Centre task per asset with the covering contract linked; renewal -> covered by contract or an individual task); reconciliation flags (7.1.5); task completion -> last date and next due (7.1.6); monthly campaigns with one task per asset; calculated next date / status on the register; Calibration / Maintenance-or-inspection / Standalone licence notifications; Task Centre source Asset; Asset Activities screen | 438 | 6.1 |")
rep("""| D33 | **Cancel keeps the asset status** (433)""",
"""| D60 | **Activity templates** (438): the BRD 7.1.4 activities that have register fields -- Calibration, Preventive maintenance, Statutory inspection (execution) and Equipment licence renewal (renewal). Each names its register fields (the "... required" Yes / No, frequency, basis, last date or expiry date, task owner field), the contract coverage types that match it (Calibration; AMC, CMC; Licence) and its 437 notification activity. Per organization: active, task lead days, due-soon days, individual tasks or a monthly campaign, campaign owner. Vehicle service / insurance / fitness, firmware / OS upgrades, encryption / sanitization / disposal activities are not templates yet. | BRD 7.1.4, 5.1.7, 5.2.16. | Yes. |
| D61 | **Next due date**: execution -- the later of the last completed occurrence (its due date + interval for a scheduled / calendar basis, its completion date + interval for a completion basis) and the last date field + interval; no history -> due now (today, kept while that occurrence is open). Renewal -- the expiry date field. Usage, run-hour and manufacturer bases are shown as Not scheduled (there is no meter history). Status: Overdue (past), Due Soon (within the due-soon days), Valid; Covered when a matching contract line covers a renewal through the due date. Published on the register as Next calibration / maintenance / inspection date and Calibration (Valid, Due Soon, Overdue, N/A) / Maintenance (Not Due, Due Soon, Overdue, In Progress) status, unless a value is stored. Failed comes with results (6.3). | BRD 5.1.7, 7.1.6. | Yes. |
| D62 | **Frequency** is read from the register text: a whole number and a unit -- day(s), week(s), month(s), quarter(s), half-year(s), year(s) / annual ("12 months", "2 weeks"). Anything else (for example "monthly") is Not scheduled with the reason shown. | BRD 5.1.7 "integer plus unit". | Yes. |
| D63 | **Completion**: completing the Task Centre task completes the occurrence -- the approved result until 6.3 adds results, certificates, pass / fail and reviewer approval. The last date field is set to the completion date (never moved back). Closing a contract renewal does not close asset tasks and closing an asset task does not renew a contract (7.1.5 -- they are independent records). | BRD 7.1.5, 7.1.6. | Yes. |
| D64 | **Cancelled task**: the occurrence is cancelled and the next pass opens a new one for the same due date (sequence + 1) -- a cancellation is not a valid outcome (7.1.5 needs reason and approver for reschedule / waive / not applicable, which come with 6.3). | BRD 7.1.5. | Yes. |
| D65 | **Tasks**: created the lead days before the due date (default 30; maintenance 15) as Task Centre tasks of the system type Asset Activity with source Asset (the 215 vocabulary widened; Task Centre filter added), due on the due date, priority from the asset criticality, owner from the template owner field (calibration / maintenance / compliance / technical owner) when it names a person, else the asset owner. A task that fails to be created keeps its occurrence open with the error and is retried on the next pass. | BRD 7.1.1, 7.1.5. | Yes. |
| D66 | **Contract versus asset** (7.1.1-7.1.4): execution activities always create one task per asset; a contract line of a matching type covering the asset is linked to the occurrence and named in the task (7.1.2). A renewal activity covered by a matching contract line through the due date is recorded as Covered with no task (contract-level renewal, 436 / 437); otherwise an individual task (7.1.3). An open occurrence is flagged for reconciliation -- never deleted -- when a contract now covers it, its due date moved or it no longer applies; the flag is cleared with a note and not raised again for the same reason (7.1.5). | BRD 7.1.1-7.1.5. | Yes. |
| D67 | **Campaigns**: an activity set to campaigns groups the tasks of one due month in one campaign record (owner, items, derived status Generated / In Progress / Partially Completed / Completed -- BRD 8); every asset keeps its own occurrence and task (7.1.5). No Task Centre parent task is created (its child procedure returns a result set and changes priority / SLA inheritance). Manual / bulk campaigns with selection, preview and approval (BRD 8, 8.1) are not built. | BRD 7.1.2, 7.1.5, 8. | Yes. |
| D68 | **Activity notifications**: open asset-task occurrences raise the Calibration, Preventive maintenance or inspection and Standalone licence profiles (437) from their due date; the activity owner is the task owner, else the template owner field, else the asset owner; the owner of the linked contract version is a recipient type on the occurrence and is added by default to the Calibration stages (9.1.4 -- also to organization calibration profiles still at version 1). | BRD 9.1.3, 9.1.4. | Yes. |
| D33 | **Cancel keeps the asset status** (433)""")
rep("""### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""",
"""### Recurring asset activities (438)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `activities/config?organizationId=` | `{templates (with organization settings), employees}` | `sp_asset_activity_config_get` |
| POST | `activities/settings` | `{organizationId, templateCode, isActive, leadDays, dueSoonDays, groupingMode: INDIVIDUAL \\| CAMPAIGN, campaignOwnerEmployeeId?}` | `sp_asset_activity_setting_save` |
| GET | `activities/schedules?organizationId=&templateCode=&status=&search=&pageNumber=&pageSize=` | Schedules, recalculated on read (status empty = all applicable, ALL, or OVERDUE / DUE_SOON / VALID / COVERED / NOT_SCHEDULED / NOT_APPLICABLE) | `sp_asset_activity_schedules` |
| GET | `activities/occurrences?organizationId=&templateCode=&status=OPEN\\|COMPLETED\\|CANCELLED\\|COVERED\\|ALL&reconcileOnly=&campaignId=&search=&pageNumber=&pageSize=` | Occurrences with decision, contract, task and reconciliation | `sp_asset_activity_occurrences` |
| GET | `activities/campaigns?organizationId=&pageNumber=&pageSize=` | Campaigns with item counts and status | `sp_asset_activity_campaigns` |
| POST | `activities/occurrences/{id}/reconcile` | `{organizationId, note, expectedRecordVersion?}` | `sp_asset_activity_reconcile` |
| POST | `activities/run` | `{organizationId}` -- the 437 scheduler pass (`data.tasksCreated` added) | `sp_asset_scheduler_run` |

Proxy area `asset-activities`: GETs VIEW (organization required); settings, reconcile and run EDIT. Errors `54650-54658`; 54650 / 54651 / 54655 -> 404, 54658 -> 409. The scheduler pass (`sp_asset_scheduler_run`, re-issued) runs `sp_asset_activity_run` per organization before the notification sweep: task results -> occurrences, schedules, occurrences and tasks; the run log has `tasks_created`.

### Rule semantics (421 -- the BRD is silent on these, so they are stated here)""")
rep("""## 8. Verification (static -- no compiler or database on this machine)""",
"""### Phase 6.2 files (438)
| Layer | File | Change |
|---|---|---|
| DB | `database/438_asset_activities.sql` (+ rollback restoring the 435 / 437 / 256 bodies and the 215 vocabulary) | Task type Asset Activity, task source Asset, notification object ACTIVITY; activity templates, settings, schedules, campaigns, occurrences; interval / date / settings / person helpers; task sync, schedule sync, generation, run; readers / writers; menu row. Re-issued: `fn_asset_stored_values`, `sp_asset_notification_parties`, `sp_asset_notification_sweep`, `sp_asset_scheduler_run`, `sp_asset_scheduler_runs`, `sp_task_centre_source_counts`. |
| DB | `database/274_menu_master_seed.sql` | `asset-activities` (360) under `nav-asset-contract`. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 7 routes; setting and reconcile requests. |
| API | `Services/TaskNotificationWorker.cs` | Logs the activity tasks of a pass. |
| API / Web | `appsettings.json` (both) | `asset-activities:*` for PM_ORG_ADMIN. |
| Web | `Controllers/AssetConfigController.cs`, `Models/PracticeScreen.cs`, `Views/Practice/Manage.cshtml` | Activity permissions; Asset Activities screen. |
| Web | `Partials/asset-activities.cshtml`, `js/AssetConfig/asset-activities.js` (new) | Schedules, occurrences (reconcile), campaigns, templates (settings), Run now. |
| Web | `Partials/tasks.cshtml` | Task Centre source filter: Asset activity. |
| Web | `Partials/asset-notifications.cshtml`, `js/AssetConfig/asset-notifications.js` | Scheduler run log: activity tasks column. |

## 8. Verification (static -- no compiler or database on this machine)""")
s = s.rstrip('\n') + """

438 got the same sweep (clean apart from the intended `INSERT ... EXEC sp_org_role_holders_list` in the re-issued sweep), a scan for a semicolon before ELSE and for reserved words used as column aliases (the 437 `offsets` failure -- none), a check that no aggregate mixes an outer column with inner ones (the 437 Msg 8124 -- none), a parameter-name check of every internal EXEC including `sp_task_open`, a diff of the six re-issued bodies against their sources (only marked 438 lines; four lines extended in place), the C#-to-procedure parameter cross-check for all 6 bound procedures (the setting save returns a numeric id, as `ResultRowWriteAsync` needs), the JS-to-alias and HTML-id checks, `node --check` on both edited / new scripts, brace / parenthesis balance of the edited C# files, both `appsettings.json` parse, the ASCII check and the Razor scan. Its verification block checks the templates, task type and the two widened check constraints, the tables and the one-open index, the objects, the re-issues and the frequency / date arithmetic. Not compiled or executed. Not yet done: task results / certificates / pass-fail / reviewer approval, failed and restricted-use follow-ups, reschedule / waive / not applicable with approver (6.3); usage / meter bases; manual / bulk campaigns with preview and approval; vehicle and technology-upgrade activity templates.
"""
open(p, 'w', encoding='utf-8', newline='').write(s)
print('doc ok')
