-- =====================================================================
-- 5. Findings: evaluate, act, run
-- =====================================================================
-- Opens a finding for each new match, refreshes the open ones, resolves
-- those whose condition no longer holds (or whose rule is no longer in
-- effect) and reopens acceptances whose review date passed. CREATE_TASK
-- findings get one Task Centre task when opened. No result set.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_consistency_evaluate
    @organization_id BIGINT,
    @asset_id        BIGINT        = NULL,
    @actor           NVARCHAR(100) = N'system',
    @out_opened      INT           = NULL OUTPUT,
    @out_resolved    INT           = NULL OUTPUT,
    @out_reopened    INT           = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SELECT @out_opened = 0, @out_resolved = 0, @out_reopened = 0;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE), @now DATETIME2 = SYSUTCDATETIME();

    DECLARE @m TABLE (asset_id BIGINT NOT NULL, rule_id BIGINT NOT NULL, rule_code NVARCHAR(20) COLLATE DATABASE_DEFAULT NOT NULL,
                      rule_name NVARCHAR(200) COLLATE DATABASE_DEFAULT NOT NULL, severity NVARCHAR(20) COLLATE DATABASE_DEFAULT NOT NULL,
                      action_code NVARCHAR(20) COLLATE DATABASE_DEFAULT NOT NULL, facts NVARCHAR(MAX) COLLATE DATABASE_DEFAULT NULL,
                      PRIMARY KEY (asset_id, rule_code));
    INSERT @m (asset_id, rule_id, rule_code, rule_name, severity, action_code, facts)
    SELECT e.AssetId, e.RuleId, e.RuleCode, e.RuleName, e.Severity, e.ActionCode, e.FactsJson
      FROM grac_practice.fn_asset_consistency_eval(@organization_id, @asset_id, NULL) e
     WHERE e.Matched = 1;

    DECLARE @new TABLE (finding_id BIGINT NOT NULL PRIMARY KEY, action_code NVARCHAR(20) COLLATE DATABASE_DEFAULT NOT NULL);

    BEGIN TRAN;
    -- Acceptances past their review date reopen (19.7 override expiry).
    UPDATE f
       SET status = N'OPEN', reopened_count = f.reopened_count + 1, last_evaluated_dt = @now,
           decision_note = LEFT(CONCAT(N'Review date ', CONVERT(NVARCHAR(10), f.review_date, 23), N' passed; the acceptance expired.'), 1000)
      FROM grac_practice.asset_consistency_finding f
     WHERE f.organization_id = @organization_id AND (@asset_id IS NULL OR f.asset_id = @asset_id)
       AND f.status = N'ACCEPTED' AND f.review_date < @today;
    SET @out_reopened = @@ROWCOUNT;

    UPDATE f
       SET status = N'RESOLVED', resolved_dt = @now, last_evaluated_dt = @now
      FROM grac_practice.asset_consistency_finding f
     WHERE f.organization_id = @organization_id AND (@asset_id IS NULL OR f.asset_id = @asset_id)
       AND f.status <> N'RESOLVED'
       AND NOT EXISTS (SELECT 1 FROM @m m WHERE m.asset_id = f.asset_id AND m.rule_code = f.rule_code);
    SET @out_resolved = @@ROWCOUNT;

    UPDATE f
       SET rule_id = m.rule_id, severity = m.severity, action_code = m.action_code,
           message = LEFT(m.rule_name, 600), facts_json = m.facts, last_evaluated_dt = @now
      FROM grac_practice.asset_consistency_finding f
      JOIN @m m ON m.asset_id = f.asset_id AND m.rule_code = f.rule_code
     WHERE f.status <> N'RESOLVED';

    INSERT grac_practice.asset_consistency_finding
        (organization_id, asset_id, rule_code, rule_id, severity, action_code, status, message, facts_json)
    OUTPUT inserted.finding_id, inserted.action_code INTO @new (finding_id, action_code)
    SELECT @organization_id, m.asset_id, m.rule_code, m.rule_id, m.severity, m.action_code, N'OPEN', LEFT(m.rule_name, 600), m.facts
      FROM @m m
     WHERE NOT EXISTS (SELECT 1 FROM grac_practice.asset_consistency_finding f
                        WHERE f.asset_id = m.asset_id AND f.rule_code = m.rule_code AND f.status <> N'RESOLVED');
    SET @out_opened = @@ROWCOUNT;

    -- CREATE_TASK: one task per new finding, to the asset owner (as 442).
    DECLARE @fid BIGINT, @aid BIGINT, @owner BIGINT, @asset_name NVARCHAR(400), @crit NVARCHAR(40), @prio NVARCHAR(30),
            @title NVARCHAR(250), @descr NVARCHAR(MAX), @ref NVARCHAR(200), @tid BIGINT, @sev NVARCHAR(20), @msg NVARCHAR(600);
    DECLARE task_cur CURSOR LOCAL STATIC FOR SELECT finding_id FROM @new WHERE action_code = N'CREATE_TASK' ORDER BY finding_id;
    OPEN task_cur;
    FETCH NEXT FROM task_cur INTO @fid;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SELECT @aid = f.asset_id, @sev = f.severity, @msg = f.message,
               @owner = grac_practice.fn_asset_activity_person(@organization_id, CAST(a.owner_id AS NVARCHAR(30))),
               @asset_name = a.asset_name, @crit = c.criticality_code
          FROM grac_practice.asset_consistency_finding f
          JOIN grac_practice.organization_dependency_asset a ON a.asset_id = f.asset_id
          LEFT JOIN grac_practice.criticality_master c ON c.criticality_id = a.criticality_id
         WHERE f.finding_id = @fid;
        SET @prio = CASE WHEN @sev IN (N'ERROR', N'APPROVAL_REQUIRED') THEN N'High' WHEN @sev = N'INFO' THEN N'Low' ELSE N'Medium' END;
        SET @title = LEFT(CONCAT(N'Consistency - ', @asset_name, N' (', @msg, N')'), 250);
        SET @descr = CONCAT(N'The asset ', @asset_name, N' meets the consistency rule "', @msg,
                            N'". Correct the asset (ratings, criticality or service mapping) or record an approved inconsistency ',
                            N'on the Asset Register (Valuation tab, finding ', @fid, N').');
        SET @ref = CONCAT(N'ACF-', @fid);
        SET @tid = NULL;
        EXEC grac_practice.sp_task_open
             @organization_id         = @organization_id,
             @task_type_code          = N'AssetConsistency',
             @subject_entity_type     = N'AssetConsistencyFinding',
             @subject_entity_id       = @fid,
             @subject_title           = @title,
             @subject_description     = @descr,
             @priority                = @prio,
             @criticality             = @crit,
             @origin_code             = N'GRAC',
             @assigned_to_employee_id = @owner,
             @target_date             = NULL,
             @source_type_code        = N'Asset',
             @source_record_id        = @fid,
             @source_reference        = @ref,
             @resolve_owner           = 0,
             @task_id                 = @tid OUTPUT;
        UPDATE grac_practice.asset_consistency_finding SET task_id = @tid WHERE finding_id = @fid;
        FETCH NEXT FROM task_cur INTO @fid;
    END
    CLOSE task_cur;
    DEALLOCATE task_cur;
    COMMIT;
END
GO

-- Re-evaluate on request (one asset or the whole organization).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_consistency_run
    @organization_id BIGINT,
    @asset_id        BIGINT        = NULL,
    @actor           NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53010, 'Organization not found.', 1;
    DECLARE @o INT, @r INT, @x INT;
    EXEC grac_practice.sp_asset_consistency_evaluate @organization_id = @organization_id, @asset_id = @asset_id, @actor = @actor,
         @out_opened = @o OUTPUT, @out_resolved = @r OUTPUT, @out_reopened = @x OUTPUT;
    SELECT @organization_id AS OrganizationId,
           CONCAT(@o, N' opened, ', @r, N' resolved, ', @x, N' reopened') AS Result,
           @o AS Opened, @r AS Resolved, @x AS Reopened;
END
GO

-- Accept (rationale, evidence, owner, review date), withdraw, approve,
-- reject, revoke (19.7 override; D147).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_consistency_finding_action
    @organization_id         BIGINT,
    @finding_id              BIGINT,
    @action                  NVARCHAR(12),
    @rationale               NVARCHAR(1000) = NULL,
    @evidence                NVARCHAR(1000) = NULL,
    @owner_employee_id       BIGINT         = NULL,
    @review_date             DATE           = NULL,
    @note                    NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @action = UPPER(LTRIM(RTRIM(ISNULL(@action, N''))));
    SET @rationale = NULLIF(LTRIM(RTRIM(@rationale)), N'');
    SET @evidence = NULLIF(LTRIM(RTRIM(@evidence)), N'');
    SET @note = NULLIF(LTRIM(RTRIM(@note)), N'');
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    DECLARE @found BIT = 0, @status NVARCHAR(20), @rv BIGINT, @rule_id BIGINT, @sev NVARCHAR(20), @req_by NVARCHAR(100),
            @req_emp BIGINT, @cur_review DATE, @asset BIGINT;
    SELECT @found = 1, @status = f.status, @rv = CONVERT(BIGINT, f.record_version), @rule_id = f.rule_id, @sev = f.severity,
           @req_by = f.requested_by, @req_emp = f.requested_employee_id, @cur_review = f.review_date, @asset = f.asset_id
      FROM grac_practice.asset_consistency_finding f
     WHERE f.finding_id = @finding_id AND f.organization_id = @organization_id;
    IF @found = 0 THROW 53030, 'Consistency finding not found for this organization.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 53036, 'This finding was changed by someone else. Reload it and try again.', 1;
    IF @action NOT IN (N'ACCEPT', N'WITHDRAW', N'APPROVE', N'REJECT', N'REVOKE')
        THROW 53038, 'Choose Accept, Withdraw, Approve, Reject or Revoke.', 1;

    DECLARE @ovr BIT, @maxd INT;
    SELECT @ovr = override_allowed, @maxd = max_override_days FROM grac_practice.asset_consistency_rule WHERE rule_id = @rule_id;
    DECLARE @needs_approval BIT = CASE WHEN @sev IN (N'ERROR', N'APPROVAL_REQUIRED') THEN 1 ELSE 0 END;
    DECLARE @same_person BIT = CASE WHEN (@actor_employee_id IS NOT NULL AND @actor_employee_id = @req_emp) OR @actor = @req_by THEN 1 ELSE 0 END;
    DECLARE @result NVARCHAR(20), @msg NVARCHAR(400);

    IF @action = N'ACCEPT'
    BEGIN
        IF @status <> N'OPEN' THROW 53033, 'Only an open finding can be accepted.', 1;
        IF @ovr = 0 THROW 53031, 'This rule permits no accepted inconsistency; correct the asset instead.', 1;
        IF @rationale IS NULL OR @owner_employee_id IS NULL OR @review_date IS NULL OR (@needs_approval = 1 AND @evidence IS NULL)
        BEGIN
            SET @msg = CASE WHEN @needs_approval = 1 THEN N'Rationale, evidence, owner and review date are required.'
                            ELSE N'Rationale, owner and review date are required.' END;
            THROW 53034, @msg, 1;
        END
        IF NOT EXISTS (SELECT 1 FROM grac_practice.organization_employee WHERE employee_id = @owner_employee_id AND organization_id = @organization_id)
            THROW 53034, 'The owner must be an employee of this organization.', 1;
        IF @review_date <= @today OR (@maxd IS NOT NULL AND @review_date > DATEADD(DAY, @maxd, @today))
        BEGIN
            SET @msg = CONCAT(N'The review date must be after today', CASE WHEN @maxd IS NULL THEN N'' ELSE CONCAT(N' and within ', @maxd, N' days') END, N'.');
            THROW 53035, @msg, 1;
        END
        SET @result = CASE WHEN @needs_approval = 1 THEN N'PENDING_APPROVAL' ELSE N'ACCEPTED' END;
    END
    ELSE IF @action = N'WITHDRAW'
    BEGIN
        IF @status <> N'PENDING_APPROVAL' THROW 53033, 'Only a request awaiting approval can be withdrawn.', 1;
        SET @result = N'OPEN';
    END
    ELSE IF @action IN (N'APPROVE', N'REJECT')
    BEGIN
        IF @status <> N'PENDING_APPROVAL' THROW 53033, 'Only a request awaiting approval can be approved or rejected.', 1;
        IF @same_person = 1 THROW 53032, 'Segregation of duties: the person who requested the acceptance cannot decide it.', 1;
        IF @action = N'REJECT' AND @note IS NULL THROW 53034, 'A reason is required to reject.', 1;
        IF @action = N'APPROVE' AND @cur_review <= @today THROW 53035, 'The review date has passed; withdraw and request again.', 1;
        SET @result = CASE WHEN @action = N'APPROVE' THEN N'ACCEPTED' ELSE N'OPEN' END;
    END
    ELSE
    BEGIN
        IF @status <> N'ACCEPTED' THROW 53033, 'Only an accepted finding can be revoked.', 1;
        IF @note IS NULL THROW 53034, 'A reason is required to revoke.', 1;
        SET @result = N'OPEN';
    END

    BEGIN TRAN;
    UPDATE grac_practice.asset_consistency_finding
       SET status = @result,
           rationale = CASE WHEN @action = N'ACCEPT' THEN @rationale ELSE rationale END,
           evidence = CASE WHEN @action = N'ACCEPT' THEN @evidence ELSE evidence END,
           owner_employee_id = CASE WHEN @action = N'ACCEPT' THEN @owner_employee_id ELSE owner_employee_id END,
           review_date = CASE WHEN @action = N'ACCEPT' THEN @review_date ELSE review_date END,
           requested_by = CASE WHEN @action = N'ACCEPT' THEN @actor ELSE requested_by END,
           requested_employee_id = CASE WHEN @action = N'ACCEPT' THEN @actor_employee_id ELSE requested_employee_id END,
           requested_dt = CASE WHEN @action = N'ACCEPT' THEN SYSUTCDATETIME() ELSE requested_dt END,
           decided_by = CASE WHEN @action IN (N'APPROVE', N'REJECT', N'REVOKE') OR (@action = N'ACCEPT' AND @result = N'ACCEPTED') THEN @actor
                             WHEN @action = N'ACCEPT' THEN NULL ELSE decided_by END,
           decided_employee_id = CASE WHEN @action IN (N'APPROVE', N'REJECT', N'REVOKE') OR (@action = N'ACCEPT' AND @result = N'ACCEPTED') THEN @actor_employee_id
                                      WHEN @action = N'ACCEPT' THEN NULL ELSE decided_employee_id END,
           decided_dt = CASE WHEN @action IN (N'APPROVE', N'REJECT', N'REVOKE') OR (@action = N'ACCEPT' AND @result = N'ACCEPTED') THEN SYSUTCDATETIME()
                             WHEN @action = N'ACCEPT' THEN NULL ELSE decided_dt END,
           decision_note = CASE WHEN @action IN (N'REJECT', N'REVOKE', N'APPROVE', N'WITHDRAW') THEN @note
                                WHEN @action = N'ACCEPT' THEN NULL ELSE decision_note END
     WHERE finding_id = @finding_id;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-consistency-finding', @finding_id, @action,
            (SELECT @status AS status, @asset AS assetId FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            (SELECT @result AS status, @rationale AS rationale, @evidence AS evidence, @owner_employee_id AS ownerEmployeeId,
                    @review_date AS reviewDate, @note AS note FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;

    SELECT @finding_id AS FindingId, @result AS Result;
END
GO
PRINT '447: finding procedures created.';
GO

-- =====================================================================
-- 6. Rules: save a Draft, activate / retire / new version / discard
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_consistency_rule_save
    @organization_id         BIGINT,
    @rule_id                 BIGINT         = NULL,
    @rule_name               NVARCHAR(200)  = NULL,
    @description             NVARCHAR(1000) = NULL,
    @scope_kind              NVARCHAR(12)   = N'TENANT',
    @scope_ref_id            BIGINT         = NULL,
    @severity                NVARCHAR(20)   = NULL,
    @action_code             NVARCHAR(20)   = NULL,
    @override_allowed        BIT            = 1,
    @max_override_days       INT            = NULL,
    @effective_from          DATE           = NULL,
    @effective_to            DATE           = NULL,
    @change_reason           NVARCHAR(1000) = NULL,
    @conditions_json         NVARCHAR(MAX)  = N'[]',
    @expected_record_version BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @rule_name = NULLIF(LTRIM(RTRIM(@rule_name)), N'');
    SET @description = NULLIF(LTRIM(RTRIM(@description)), N'');
    SET @change_reason = NULLIF(LTRIM(RTRIM(@change_reason)), N'');
    SET @scope_kind = UPPER(LTRIM(RTRIM(ISNULL(@scope_kind, N'TENANT'))));
    SET @severity = UPPER(LTRIM(RTRIM(ISNULL(@severity, N''))));
    SET @action_code = UPPER(LTRIM(RTRIM(ISNULL(@action_code, N''))));
    SET @override_allowed = ISNULL(@override_allowed, 1);
    IF ISJSON(ISNULL(@conditions_json, N'')) <> 1 SET @conditions_json = N'[]';

    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53010, 'Organization not found.', 1;
    IF @rule_id IS NOT NULL
    BEGIN
        DECLARE @found BIT = 0, @status NVARCHAR(10), @rv BIGINT;
        SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version)
          FROM grac_practice.asset_consistency_rule WHERE rule_id = @rule_id AND organization_id = @organization_id;
        IF @found = 0 THROW 53011, 'Consistency rule not found for this organization.', 1;
        IF @status <> N'DRAFT' THROW 53012, 'Only a Draft rule can be changed; create a new version instead.', 1;
        IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
            THROW 53013, 'This rule was changed by someone else. Reload it and try again.', 1;
    END
    IF @rule_name IS NULL THROW 53014, 'A rule name is required.', 1;
    IF @scope_kind NOT IN (N'TENANT', N'CATEGORY', N'SUBCATEGORY', N'ASSET_TYPE', N'SERVICE')
       OR (@scope_kind = N'TENANT' AND @scope_ref_id IS NOT NULL)
       OR (@scope_kind = N'CATEGORY'    AND NOT EXISTS (SELECT 1 FROM grac_practice.dependency_asset_category_master WHERE asset_category_id = @scope_ref_id))
       OR (@scope_kind = N'SUBCATEGORY' AND NOT EXISTS (SELECT 1 FROM grac_practice.dependency_asset_subcategory_master WHERE subcategory_id = @scope_ref_id))
       OR (@scope_kind = N'ASSET_TYPE'  AND NOT EXISTS (SELECT 1 FROM grac_practice.dependency_asset_type_master WHERE asset_type_id = @scope_ref_id))
       OR (@scope_kind = N'SERVICE'     AND NOT EXISTS (SELECT 1 FROM grac_practice.business_service WHERE service_id = @scope_ref_id AND organization_id = @organization_id))
        THROW 53015, 'Choose the scope: the whole organization, or a category, subcategory, asset type or business service of it.', 1;
    IF @severity NOT IN (N'INFO', N'WARNING', N'ERROR', N'APPROVAL_REQUIRED')
       OR @action_code NOT IN (N'WARN', N'REQUIRE_RATIONALE', N'CREATE_TASK', N'BLOCK_TRANSITION')
        THROW 53016, 'Choose a severity (Information, Warning, Error, Approval Required) and an action (Warn, Require rationale, Create task, Block transition).', 1;
    IF @max_override_days IS NOT NULL AND @max_override_days NOT BETWEEN 1 AND 1095
        THROW 53016, 'The longest acceptance must be between 1 and 1095 days.', 1;
    IF @effective_to IS NOT NULL AND @effective_to < ISNULL(@effective_from, @effective_to)
        THROW 53022, 'Effective To cannot be before Effective From.', 1;

    DECLARE @conds TABLE (group_no INT NOT NULL, operand_key NVARCHAR(100) COLLATE DATABASE_DEFAULT NULL,
                          operator_code NVARCHAR(30) COLLATE DATABASE_DEFAULT NULL, compare_value NVARCHAR(400) COLLATE DATABASE_DEFAULT NULL,
                          display_order INT NOT NULL);
    INSERT @conds (group_no, operand_key, operator_code, compare_value, display_order)
    SELECT ISNULL(j.groupNo, 1), NULLIF(LTRIM(RTRIM(j.operandKey)), N''), UPPER(NULLIF(LTRIM(RTRIM(j.operatorCode)), N'')),
           NULLIF(LTRIM(RTRIM(j.compareValue)), N''), CAST(a.[ord] AS INT)
      FROM (SELECT x.[key] AS [ord], x.[value] AS v FROM OPENJSON(@conditions_json) x) a
     CROSS APPLY OPENJSON(a.v) WITH (groupNo INT '$.groupNo', operandKey NVARCHAR(100) '$.operandKey',
                                     operatorCode NVARCHAR(30) '$.operatorCode', compareValue NVARCHAR(400) '$.compareValue') j;
    IF EXISTS (SELECT 1 FROM @conds c
                WHERE c.group_no < 1 OR c.operand_key IS NULL OR c.operator_code IS NULL
                   OR NOT EXISTS (SELECT 1 FROM grac_practice.fn_asset_consistency_operands() o WHERE o.OperandKey = c.operand_key)
                   OR c.operator_code NOT IN (N'EQ', N'NEQ', N'IN', N'NOT_IN', N'EMPTY', N'NOT_EMPTY', N'GT', N'GTE', N'LT', N'LTE',
                                              N'DATE_BEFORE_TODAY', N'DATE_AFTER_TODAY', N'DATE_WITHIN_DAYS')
                   OR (c.operator_code IN (N'EQ', N'NEQ', N'IN', N'NOT_IN') AND c.compare_value IS NULL)
                   OR (c.operator_code IN (N'GT', N'GTE', N'LT', N'LTE') AND TRY_CONVERT(DECIMAL(38, 6), c.compare_value) IS NULL)
                   OR (c.operator_code = N'DATE_WITHIN_DAYS' AND TRY_CONVERT(INT, c.compare_value) IS NULL))
        THROW 53017, 'Each condition needs a known operand, an operator and a value (a number for greater / less than and within days).', 1;

    DECLARE @id BIGINT = @rule_id, @result NVARCHAR(20), @code NVARCHAR(20), @n INT;
    BEGIN TRAN;
    IF @rule_id IS NULL
    BEGIN
        SELECT @n = COUNT(DISTINCT rule_code) + 1
          FROM grac_practice.asset_consistency_rule WITH (UPDLOCK, HOLDLOCK)
         WHERE organization_id = @organization_id;
        SET @code = CONCAT(N'CR-', RIGHT(CONCAT(N'0000', @n), 4));
        WHILE EXISTS (SELECT 1 FROM grac_practice.asset_consistency_rule WHERE organization_id = @organization_id AND rule_code = @code)
        BEGIN
            SET @n = @n + 1;
            SET @code = CONCAT(N'CR-', RIGHT(CONCAT(N'0000', @n), 4));
        END
        INSERT grac_practice.asset_consistency_rule
            (organization_id, rule_code, version_no, rule_name, description, scope_kind, scope_ref_id, severity, action_code,
             override_allowed, max_override_days, status, effective_from, effective_to, change_reason, entered_by)
        VALUES (@organization_id, @code, 1, @rule_name, @description, @scope_kind, @scope_ref_id, @severity, @action_code,
                @override_allowed, @max_override_days, N'DRAFT', @effective_from, @effective_to, @change_reason, @actor);
        SET @id = SCOPE_IDENTITY();
        SET @result = N'CREATED';
    END
    ELSE
    BEGIN
        UPDATE grac_practice.asset_consistency_rule
           SET rule_name = @rule_name, description = @description, scope_kind = @scope_kind, scope_ref_id = @scope_ref_id,
               severity = @severity, action_code = @action_code, override_allowed = @override_allowed,
               max_override_days = @max_override_days, effective_from = @effective_from, effective_to = @effective_to,
               change_reason = ISNULL(@change_reason, change_reason), updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE rule_id = @rule_id;
        DELETE FROM grac_practice.asset_consistency_rule_condition WHERE rule_id = @rule_id;
        SET @result = N'SAVED';
    END
    INSERT grac_practice.asset_consistency_rule_condition (rule_id, group_no, operand_key, operator_code, compare_value, display_order)
    SELECT @id, group_no, operand_key, operator_code,
           CASE WHEN operator_code IN (N'EMPTY', N'NOT_EMPTY', N'DATE_BEFORE_TODAY', N'DATE_AFTER_TODAY') THEN NULL ELSE compare_value END,
           display_order
      FROM @conds;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-consistency-rule', @id, CASE WHEN @rule_id IS NULL THEN N'ADD' ELSE N'SAVE' END, NULL,
            (SELECT @rule_name AS ruleName, @scope_kind AS scopeKind, @scope_ref_id AS scopeRefId, @severity AS severity,
                    @action_code AS actionCode, @override_allowed AS overrideAllowed, @max_override_days AS maxOverrideDays,
                    @effective_from AS effectiveFrom, @effective_to AS effectiveTo, JSON_QUERY(@conditions_json) AS conditions
                FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;

    SELECT @id AS RuleId, @result AS Result;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_consistency_rule_action
    @organization_id         BIGINT,
    @rule_id                 BIGINT,
    @action                  NVARCHAR(12),
    @reason                  NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @action = UPPER(LTRIM(RTRIM(ISNULL(@action, N''))));
    SET @reason = NULLIF(LTRIM(RTRIM(@reason)), N'');
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    DECLARE @found BIT = 0, @status NVARCHAR(10), @rv BIGINT, @code NVARCHAR(20), @editor NVARCHAR(100), @from DATE, @ver INT;
    SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version), @code = rule_code,
           @editor = ISNULL(updated_by, entered_by), @from = effective_from, @ver = version_no
      FROM grac_practice.asset_consistency_rule WHERE rule_id = @rule_id AND organization_id = @organization_id;
    IF @found = 0 THROW 53011, 'Consistency rule not found for this organization.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 53013, 'This rule was changed by someone else. Reload it and try again.', 1;
    IF @action NOT IN (N'ACTIVATE', N'RETIRE', N'NEW_VERSION', N'DISCARD')
        THROW 53023, 'Choose Activate, Retire, New version or Discard.', 1;

    DECLARE @id BIGINT = @rule_id, @result NVARCHAR(30), @evaluate BIT = 0;
    -- Checks first, then one transaction for the change.
    IF @action = N'ACTIVATE'
    BEGIN
        IF @status <> N'DRAFT' THROW 53012, 'Only a Draft rule can be activated.', 1;
        IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_consistency_rule_condition WHERE rule_id = @rule_id)
            THROW 53018, 'Add at least one condition before activating the rule.', 1;
        IF @editor = @actor
            THROW 53020, 'Segregation of duties: the person who last saved the Draft cannot activate it.', 1;
        SET @from = ISNULL(@from, @today);
    END
    ELSE IF @action = N'RETIRE'
    BEGIN
        IF @status <> N'ACTIVE' THROW 53012, 'Only an Active rule can be retired.', 1;
        IF @reason IS NULL THROW 53021, 'A reason is required to retire a rule.', 1;
    END
    ELSE IF @action = N'NEW_VERSION'
    BEGIN
        IF @status NOT IN (N'ACTIVE', N'RETIRED') THROW 53012, 'A new version is made from an Active or Retired rule.', 1;
        IF EXISTS (SELECT 1 FROM grac_practice.asset_consistency_rule WHERE organization_id = @organization_id AND rule_code = @code AND status = N'DRAFT')
            THROW 53019, 'A Draft version of this rule already exists; open it.', 1;
        IF @reason IS NULL THROW 53021, 'A reason is required for a new version.', 1;
    END
    ELSE
    BEGIN
        IF @status <> N'DRAFT' THROW 53012, 'Only a Draft rule can be discarded.', 1;
    END

    BEGIN TRAN;
    IF @action = N'ACTIVATE'
    BEGIN
        UPDATE grac_practice.asset_consistency_rule
           SET status = N'RETIRED', retired_by = @actor, retired_dt = SYSUTCDATETIME(),
               effective_to = CASE WHEN DATEADD(DAY, -1, @from) < ISNULL(effective_from, DATEADD(DAY, -1, @from))
                                   THEN effective_from ELSE DATEADD(DAY, -1, @from) END,
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE organization_id = @organization_id AND rule_code = @code AND status = N'ACTIVE';
        UPDATE grac_practice.asset_consistency_rule
           SET status = N'ACTIVE', effective_from = @from, activated_by = @actor, activated_dt = SYSUTCDATETIME()
         WHERE rule_id = @rule_id;
        SELECT @result = N'ACTIVATED', @evaluate = 1;
    END
    ELSE IF @action = N'RETIRE'
    BEGIN
        UPDATE grac_practice.asset_consistency_rule
           SET status = N'RETIRED', effective_to = CASE WHEN @today < ISNULL(effective_from, @today) THEN effective_from ELSE @today END,
               retired_by = @actor, retired_dt = SYSUTCDATETIME(), change_reason = @reason,
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE rule_id = @rule_id;
        SELECT @result = N'RETIRED', @evaluate = 1;
    END
    ELSE IF @action = N'NEW_VERSION'
    BEGIN
        INSERT grac_practice.asset_consistency_rule
            (organization_id, rule_code, version_no, rule_name, description, scope_kind, scope_ref_id, severity, action_code,
             override_allowed, max_override_days, status, effective_from, effective_to, change_reason, source_rule_id, entered_by)
        SELECT organization_id, rule_code,
               (SELECT MAX(version_no) + 1 FROM grac_practice.asset_consistency_rule WHERE organization_id = @organization_id AND rule_code = @code),
               rule_name, description, scope_kind, scope_ref_id, severity, action_code, override_allowed, max_override_days,
               N'DRAFT', NULL, NULL, @reason, rule_id, @actor
          FROM grac_practice.asset_consistency_rule WHERE rule_id = @rule_id;
        SET @id = SCOPE_IDENTITY();
        INSERT grac_practice.asset_consistency_rule_condition (rule_id, group_no, operand_key, operator_code, compare_value, display_order)
        SELECT @id, group_no, operand_key, operator_code, compare_value, display_order
          FROM grac_practice.asset_consistency_rule_condition WHERE rule_id = @rule_id;
        SET @result = N'CREATED';
    END
    ELSE
    BEGIN
        UPDATE grac_practice.asset_consistency_rule
           SET status = N'DISCARDED', updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE rule_id = @rule_id;
        SET @result = N'DISCARDED';
    END
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-consistency-rule', @id, @action,
            (SELECT @rule_id AS ruleId, @status AS status, @ver AS versionNo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            (SELECT @result AS result, @reason AS reason FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;

    -- Findings follow the rule at once; a failure leaves them to the scheduler.
    IF @evaluate = 1
    BEGIN
        DECLARE @o INT, @r INT, @x INT;
        BEGIN TRY
            EXEC grac_practice.sp_asset_consistency_evaluate @organization_id = @organization_id, @actor = @actor,
                 @out_opened = @o OUTPUT, @out_resolved = @r OUTPUT, @out_reopened = @x OUTPUT;
        END TRY
        BEGIN CATCH
            IF XACT_STATE() <> 0 ROLLBACK;
            SET @result = CONCAT(@result, N'_NOT_EVALUATED');
        END CATCH
    END

    SELECT @id AS RuleId, @result AS Result;
END
GO
PRINT '447: rule procedures created.';
GO

-- =====================================================================
-- 7. Readers
-- =====================================================================
-- Scope label of a rule.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_consistency_scope_label (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT r.rule_id AS RuleId,
           CASE r.scope_kind
             WHEN N'TENANT'      THEN N'Whole organization'
             WHEN N'CATEGORY'    THEN CONCAT(N'Category: ', c.asset_category_name)
             WHEN N'SUBCATEGORY' THEN CONCAT(N'Subcategory: ', s.subcategory_name)
             WHEN N'ASSET_TYPE'  THEN CONCAT(N'Asset type: ', t.asset_type_name)
             ELSE CONCAT(N'Service: ', b.service_name) END AS ScopeLabel
      FROM grac_practice.asset_consistency_rule r
      LEFT JOIN grac_practice.dependency_asset_category_master c ON r.scope_kind = N'CATEGORY' AND c.asset_category_id = r.scope_ref_id
      LEFT JOIN grac_practice.dependency_asset_subcategory_master s ON r.scope_kind = N'SUBCATEGORY' AND s.subcategory_id = r.scope_ref_id
      LEFT JOIN grac_practice.dependency_asset_type_master t ON r.scope_kind = N'ASSET_TYPE' AND t.asset_type_id = r.scope_ref_id
      LEFT JOIN grac_practice.business_service b ON r.scope_kind = N'SERVICE' AND b.service_id = r.scope_ref_id
     WHERE r.organization_id = @organization_id;
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_consistency_rules
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT r.rule_id AS RuleId, r.rule_code AS RuleCode, r.version_no AS VersionNo, r.rule_name AS RuleName, r.status AS Status,
           r.scope_kind AS ScopeKind, sl.ScopeLabel, r.severity AS Severity, r.action_code AS ActionCode,
           r.effective_from AS EffectiveFrom, r.effective_to AS EffectiveTo,
           (SELECT COUNT(*) FROM grac_practice.asset_consistency_rule_condition c WHERE c.rule_id = r.rule_id) AS ConditionCount,
           CASE WHEN r.status = N'ACTIVE' THEN (SELECT COUNT(*) FROM grac_practice.asset_consistency_finding f
                                                 WHERE f.organization_id = r.organization_id AND f.rule_code = r.rule_code
                                                   AND f.status IN (N'OPEN', N'PENDING_APPROVAL')) END AS OpenFindings,
           CASE WHEN r.status = N'ACTIVE' THEN (SELECT COUNT(*) FROM grac_practice.asset_consistency_finding f
                                                 WHERE f.organization_id = r.organization_id AND f.rule_code = r.rule_code
                                                   AND f.status = N'ACCEPTED') END AS AcceptedFindings,
           ISNULL(r.updated_by, r.entered_by) AS LastChangedBy, COALESCE(r.updated_dt, r.entered_dt) AS LastChangedDt
      FROM grac_practice.asset_consistency_rule r
      JOIN grac_practice.fn_asset_consistency_scope_label(@organization_id) sl ON sl.RuleId = r.rule_id
     WHERE r.organization_id = @organization_id AND r.status <> N'DISCARDED'
     ORDER BY r.rule_code, r.version_no DESC;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_consistency_rule_get
    @organization_id BIGINT,
    @rule_id         BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_consistency_rule WHERE rule_id = @rule_id AND organization_id = @organization_id)
        THROW 53011, 'Consistency rule not found for this organization.', 1;
    -- 1. Rule
    SELECT r.rule_id AS RuleId, r.rule_code AS RuleCode, r.version_no AS VersionNo, r.rule_name AS RuleName,
           r.description AS Description, r.status AS Status, r.scope_kind AS ScopeKind, r.scope_ref_id AS ScopeRefId,
           sl.ScopeLabel, r.severity AS Severity, r.action_code AS ActionCode, r.override_allowed AS OverrideAllowed,
           r.max_override_days AS MaxOverrideDays, r.effective_from AS EffectiveFrom, r.effective_to AS EffectiveTo,
           r.change_reason AS ChangeReason, r.activated_by AS ActivatedBy, r.activated_dt AS ActivatedDt,
           r.retired_by AS RetiredBy, r.retired_dt AS RetiredDt, r.entered_by AS EnteredBy, r.entered_dt AS EnteredDt,
           ISNULL(r.updated_by, r.entered_by) AS LastChangedBy, COALESCE(r.updated_dt, r.entered_dt) AS LastChangedDt,
           CONVERT(BIGINT, r.record_version) AS RecordVersion
      FROM grac_practice.asset_consistency_rule r
      JOIN grac_practice.fn_asset_consistency_scope_label(@organization_id) sl ON sl.RuleId = r.rule_id
     WHERE r.rule_id = @rule_id;
    -- 2. Conditions
    SELECT c.condition_id AS ConditionId, c.group_no AS GroupNo, c.operand_key AS OperandKey, o.OperandLabel,
           c.operator_code AS OperatorCode, c.compare_value AS CompareValue, c.display_order AS DisplayOrder
      FROM grac_practice.asset_consistency_rule_condition c
      LEFT JOIN grac_practice.fn_asset_consistency_operands() o ON o.OperandKey = c.operand_key
     WHERE c.rule_id = @rule_id
     ORDER BY c.group_no, c.display_order, c.condition_id;
    -- 3. Versions of the rule
    SELECT v.rule_id AS RuleId, v.version_no AS VersionNo, v.status AS Status, v.effective_from AS EffectiveFrom,
           v.effective_to AS EffectiveTo, v.change_reason AS ChangeReason, v.activated_by AS ActivatedBy, v.activated_dt AS ActivatedDt
      FROM grac_practice.asset_consistency_rule v
      JOIN grac_practice.asset_consistency_rule r ON r.rule_id = @rule_id
     WHERE v.organization_id = r.organization_id AND v.rule_code = r.rule_code AND v.status <> N'DISCARDED'
     ORDER BY v.version_no DESC;
END
GO

-- Operands and scope choices for the rule designer.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_consistency_operands
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT o.OperandKey, o.OperandLabel, o.OperandKind, o.Hint
      FROM grac_practice.fn_asset_consistency_operands() o
     ORDER BY CASE o.OperandKind WHEN N'DERIVED' THEN 0 ELSE 1 END, CASE WHEN o.OperandKind = N'DERIVED' THEN o.DisplayOrder ELSE 0 END, o.OperandLabel;
    SELECT N'CATEGORY' AS ScopeKind, CAST(c.asset_category_id AS BIGINT) AS ScopeRefId, c.asset_category_name AS ScopeLabel
      FROM grac_practice.dependency_asset_category_master c WHERE c.is_active = 1
    UNION ALL
    SELECT N'SUBCATEGORY', CAST(s.subcategory_id AS BIGINT), CONCAT(c.asset_category_name, N' / ', s.subcategory_name)
      FROM grac_practice.dependency_asset_subcategory_master s
      JOIN grac_practice.dependency_asset_category_master c ON c.asset_category_id = s.asset_category_id
     WHERE s.is_active = 1
    UNION ALL
    SELECT N'ASSET_TYPE', CAST(t.asset_type_id AS BIGINT), t.asset_type_name
      FROM grac_practice.dependency_asset_type_master t WHERE t.is_active = 1
    UNION ALL
    SELECT N'SERVICE', b.service_id, CONCAT(b.service_code, N' ', b.service_name)
      FROM grac_practice.business_service b WHERE b.organization_id = @organization_id AND b.status <> N'RETIRED'
     ORDER BY 1, 3;
END
GO

-- Bulk preview: what a rule (any status) matches now (19.7).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_consistency_rule_preview
    @organization_id BIGINT,
    @rule_id         BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_consistency_rule WHERE rule_id = @rule_id AND organization_id = @organization_id)
        THROW 53011, 'Consistency rule not found for this organization.', 1;
    SELECT e.AssetId, e.Matched, e.FactsJson INTO #pv
      FROM grac_practice.fn_asset_consistency_eval(@organization_id, NULL, @rule_id) e;
    SELECT (SELECT COUNT(*) FROM #pv) AS InScope, (SELECT COUNT(*) FROM #pv WHERE Matched = 1) AS Matched;
    SELECT TOP (500) p.AssetId, a.asset_name AS AssetName, s.status_name AS StatusName, p.FactsJson,
           f.status AS FindingStatus
      FROM #pv p
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = p.AssetId
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
      LEFT JOIN grac_practice.asset_consistency_rule r ON r.rule_id = @rule_id
      LEFT JOIN grac_practice.asset_consistency_finding f ON f.asset_id = p.AssetId AND f.rule_code = r.rule_code AND f.status <> N'RESOLVED'
     WHERE p.Matched = 1
     ORDER BY a.asset_name;
END
GO

-- Findings list (worklist, dashboards, reports). @status NULL = open or
-- awaiting approval; ALL; or one status.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_consistency_findings
    @organization_id BIGINT,
    @status          NVARCHAR(20)  = NULL,
    @severity        NVARCHAR(20)  = NULL,
    @asset_id        BIGINT        = NULL,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @severity = NULLIF(UPPER(LTRIM(RTRIM(@severity))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    SELECT f.finding_id AS FindingId, f.asset_id AS AssetId, a.asset_name AS AssetName, f.rule_code AS RuleCode,
           r.version_no AS RuleVersionNo, f.message AS Message, f.severity AS Severity, f.action_code AS ActionCode,
           f.status AS Status, f.facts_json AS FactsJson, f.detected_dt AS DetectedDt, f.last_evaluated_dt AS LastEvaluatedDt,
           f.resolved_dt AS ResolvedDt, f.rationale AS Rationale, f.evidence AS Evidence, f.owner_employee_id AS OwnerEmployeeId,
           oe.employee_name AS OwnerName, f.review_date AS ReviewDate, f.requested_by AS RequestedBy, f.requested_dt AS RequestedDt,
           f.decided_by AS DecidedBy, f.decided_dt AS DecidedDt, f.decision_note AS DecisionNote, f.reopened_count AS ReopenedCount,
           f.task_id AS TaskId, r.override_allowed AS OverrideAllowed, r.max_override_days AS MaxOverrideDays,
           CONVERT(BIGINT, f.record_version) AS RecordVersion, COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_consistency_finding f
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = f.asset_id
      JOIN grac_practice.asset_consistency_rule r ON r.rule_id = f.rule_id
      LEFT JOIN grac_practice.organization_employee oe ON oe.employee_id = f.owner_employee_id
     WHERE f.organization_id = @organization_id
       AND ((@status IS NULL AND f.status IN (N'OPEN', N'PENDING_APPROVAL')) OR @status = N'ALL' OR f.status = @status)
       AND (@severity IS NULL OR f.severity = @severity)
       AND (@asset_id IS NULL OR f.asset_id = @asset_id)
       AND (@search IS NULL OR a.asset_name LIKE N'%' + @search + N'%' OR f.message LIKE N'%' + @search + N'%' OR f.rule_code LIKE N'%' + @search + N'%')
     ORDER BY CASE f.status WHEN N'PENDING_APPROVAL' THEN 0 WHEN N'OPEN' THEN 1 WHEN N'ACCEPTED' THEN 2 ELSE 3 END,
              CASE f.severity WHEN N'APPROVAL_REQUIRED' THEN 0 WHEN N'ERROR' THEN 1 WHEN N'WARNING' THEN 2 ELSE 3 END,
              f.detected_dt DESC, f.finding_id DESC
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    -- Counts by status and severity (current findings).
    SELECT f.status AS Status, f.severity AS Severity, COUNT(*) AS FindingCount
      FROM grac_practice.asset_consistency_finding f
     WHERE f.organization_id = @organization_id AND f.status <> N'RESOLVED'
     GROUP BY f.status, f.severity;
END
GO
PRINT '447: readers created.';
GO

