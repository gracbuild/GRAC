-- =====================================================================
-- 443  Discovery follow-up: register a new candidate as a Draft asset,
--      stale-asset review (aging rule, source confirmation, dependency
--      review) leading to a decommission request
--      (Asset & Contract Management, Phase 7 increment 4a)
--
-- REQUEST
-- -------
--   BRD v1.7 5.6.3 "Reconciliation Outcomes": Create Candidate -- "create
--   staged candidate; do not activate until validation rules pass";
--   Retire / Stale -- "require aging rule, source confirmation and
--   dependency review before retirement". 19.3 "Disabling or retiring a
--   connector requires reason, impact analysis and stale-data handling";
--   19.5 "Confidence alone shall not authorize protected overwrite, merge,
--   split or retirement". 5.6.5 every result traceable. Plan:
--   docs/asset-contract-management.md (Phase 7.4a, D109-D116).
--
-- WHAT THIS DOES
-- --------------
--   1. Candidate registration: a New candidate (or Manual review) exception
--      is registered through the Asset Register form (prefilled from the
--      observation, validated by sp_asset_register_save, saved as Draft --
--      activation keeps every lifecycle gate); the new action REGISTER of
--      sp_asset_reconciliation_resolve then links the source record to it
--      (confirmed link, field precedence) and closes the exception as
--      Registered. sp_asset_discovery_candidate_get feeds the form.
--   2. Aging rule per organization (asset_stale_setting, default 90 days):
--      an asset is stale when it has source links, none is fresh (expected
--      interval x stale multiplier, 442) and no source has seen it for the
--      aging period. fn_asset_stale_state, fn_asset_stale_dependencies.
--   3. Stale review (asset_stale_review): opened on a stale asset; source
--      confirmation (absent -> continue, present -> closed as still in
--      use); dependency review (relationships with blockers, contract
--      coverage, open activities, workflows, pending lifecycle change, open
--      reconciliation exceptions, risks -- snapshot kept); then either
--      dismiss (still in use; not listed again for one aging period) or
--      request decommission, which runs the Asset Register lifecycle move
--      to Pending Decommission (sp_asset_lifecycle_transition: its gates
--      and approval apply). An asset observed again after the review opened
--      cannot be sent to decommission from it.
--
-- NOT DONE HERE: merge (7.4b) and split (7.4c); automatic opening of
--   reviews or tasks for stale assets (the list is the work queue);
--   bulk decommission.
--
-- ERROR NUMBERS: 54780-54799
--   54780 organization not found          54781 asset not found
--   54782 asset not stale                 54783 review already open
--   54784 review not found                54785 changed by someone else
--   54786 review not open                 54787 action not valid
--   54788 note required                   54789 source outcome required
--   54790 decommission prerequisites      54791 observed again
--   54792 aging rule                      54793 register: not a new asset
--
-- ALSO EDITED: sp_asset_reconciliation_resolve (442) re-issued with the
--   REGISTER action; API (AssetConfig service / controller / models), Web
--   proxy, asset-discovery.cshtml / .js (Stale assets tab, Register
--   action), asset-register.js (candidate prefill and link), docs.
-- DEPENDS ON: 428, 429, 433, 435, 438, 440, 441, 442; 261 (risk maps).
-- Rollback: 443_asset_discovery_followup_rollback.sql (restores the 442
--   body of sp_asset_reconciliation_resolve).
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.sp_asset_reconciliation_resolve','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_discovery_apply','P') IS NULL
   OR OBJECT_ID('grac_practice.asset_discovery_link','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_discovery_setting','U') IS NULL
   OR COL_LENGTH('grac_practice.asset_reconciliation_exception','resolution') IS NULL
   OR COL_LENGTH('grac_practice.asset_discovery_observation','payload_json') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_relationship_edges') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_ci_catalog') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_lifecycle_transition','P') IS NULL
   OR OBJECT_ID('grac_practice.asset_lifecycle_change','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_workflow_case','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_activity_occurrence','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_contract_coverage','U') IS NULL
   OR OBJECT_ID('grac_practice.risk_asset_map','U') IS NULL
   OR COL_LENGTH('grac_practice.business_service','service_code') IS NULL
BEGIN
    RAISERROR('ABORT (443): run 261, 428, 429, 433, 435, 438, 440, 441 and 442 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Aging rule and stale reviews (5.6.3 Retire / Stale)
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_stale_setting','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_stale_setting (
        organization_id   BIGINT        NOT NULL CONSTRAINT pk_pm_astale_set PRIMARY KEY
            CONSTRAINT fk_pm_astale_set_org REFERENCES grac_practice.organization(organization_id),
        retire_after_days INT           NOT NULL CONSTRAINT ck_pm_astale_set_days CHECK (retire_after_days BETWEEN 1 AND 3650),
        updated_by        NVARCHAR(100) NOT NULL,
        updated_dt        DATETIME2     NOT NULL CONSTRAINT df_pm_astale_set_udt DEFAULT SYSUTCDATETIME()
    );
    PRINT '443: asset_stale_setting created.';
END
GO

IF OBJECT_ID('grac_practice.asset_stale_review','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_stale_review (
        review_id                BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_astale_rev PRIMARY KEY,
        organization_id          BIGINT         NOT NULL
            CONSTRAINT fk_pm_astale_rev_org REFERENCES grac_practice.organization(organization_id),
        asset_id                 BIGINT         NOT NULL
            CONSTRAINT fk_pm_astale_rev_asset REFERENCES grac_practice.organization_dependency_asset(asset_id),
        status                   NVARCHAR(24)   NOT NULL
            CONSTRAINT ck_pm_astale_rev_status CHECK (status IN (N'OPEN', N'DISMISSED', N'DECOMMISSION_REQUESTED')),
        last_observed_dt         DATETIME2      NULL,     -- when the review opened
        days_unseen              INT            NULL,
        retire_after_days        INT            NOT NULL,
        link_count               INT            NOT NULL,
        source_outcome           NVARCHAR(10)   NULL
            CONSTRAINT ck_pm_astale_rev_src CHECK (source_outcome IS NULL OR source_outcome IN (N'ABSENT', N'PRESENT')),
        source_note              NVARCHAR(1000) NULL,
        source_confirmed_by      NVARCHAR(100)  NULL,
        source_confirmed_dt      DATETIME2      NULL,
        dependency_note          NVARCHAR(1000) NULL,
        dependency_snapshot      NVARCHAR(MAX)  NULL,     -- JSON of fn_asset_stale_dependencies at review time
        dependency_blockers      INT            NULL,
        dependencies_reviewed_by NVARCHAR(100)  NULL,
        dependencies_reviewed_dt DATETIME2      NULL,
        decision_note            NVARCHAR(1000) NULL,
        change_id                BIGINT         NULL
            CONSTRAINT fk_pm_astale_rev_change REFERENCES grac_practice.asset_lifecycle_change(change_id),
        change_result            NVARCHAR(20)   NULL,
        opened_by                NVARCHAR(100)  NOT NULL,
        opened_dt                DATETIME2      NOT NULL CONSTRAINT df_pm_astale_rev_odt DEFAULT SYSUTCDATETIME(),
        closed_by                NVARCHAR(100)  NULL,
        closed_dt                DATETIME2      NULL,
        record_version           ROWVERSION     NOT NULL
    );
    CREATE UNIQUE INDEX ux_pm_astale_rev_open ON grac_practice.asset_stale_review(asset_id) WHERE status = N'OPEN';
    CREATE INDEX ix_pm_astale_rev_org ON grac_practice.asset_stale_review(organization_id, status, closed_dt DESC);
    PRINT '443: asset_stale_review created.';
END
GO
