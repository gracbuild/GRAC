D='/home/claude/w448/db/'
def body(fname, header):
    s=open(D+fname).read()
    i=s.index(header); j=s.index('\nGO\n', i)
    return s[i:j+1]
def ins_after(b, anchor, text):
    assert b.count(anchor)==1, (anchor[:70], b.count(anchor)); return b.replace(anchor, anchor+text)
def ins_before(b, anchor, text):
    assert b.count(anchor)==1, (anchor[:70], b.count(anchor)); return b.replace(anchor, text+anchor)
src={}
# ---------------- register save (447)
rs=body('447_asset_consistency_rules.sql','CREATE OR ALTER PROCEDURE grac_practice.sp_asset_register_save'); src['rs']=rs
rs2=ins_after(rs, """         @out_opened = @cons_o OUTPUT, @out_resolved = @cons_r OUTPUT, @out_reopened = @cons_x OUTPUT;   -- 447
""", """    -- 448: privacy reviews of the saved asset (9.1.7).
    DECLARE @prv_o INT, @prv_c INT, @prv_x INT;                                                -- 448
    EXEC grac_practice.sp_asset_privacy_sync                                                   -- 448
         @organization_id = @organization_id, @asset_id = @out_asset_id, @actor = @actor,      -- 448
         @out_opened = @prv_o OUTPUT, @out_closed = @prv_c OUTPUT, @out_expired = @prv_x OUTPUT;   -- 448
""")
rs2=ins_before(rs2, """    SET @out_result = N'SAVED';
""", """    -- 448: privacy gaps (5.1.10 / 5.1.16 / 5.2.15) -- one summary, plus each blocking gap.
    INSERT @issues (severity, field_key, message)                                              -- 448
    SELECT N'WARNING', NULL, CONCAT(N'Privacy: ', COUNT(*), N' gap(s) to resolve or except (Privacy tab).')   -- 448
      FROM grac_practice.fn_asset_privacy_gaps(@organization_id, @out_asset_id) g              -- 448
     WHERE g.IsExcepted = 0                                                                    -- 448
    HAVING COUNT(*) > 0;                                                                       -- 448
    INSERT @issues (severity, field_key, message)                                              -- 448
    SELECT N'WARNING', NULL, LEFT(CONCAT(N'Privacy (', g.RequirementName, N'): ', g.Message,   -- 448
                                   CASE g.BlockTarget WHEN N'ACTIVE' THEN N' -- blocks a move to Active.'   -- 448
                                        ELSE N' -- blocks Disposed / Archived.' END), 500)    -- 448
      FROM grac_practice.fn_asset_privacy_gaps(@organization_id, @out_asset_id) g              -- 448
     WHERE g.IsExcepted = 0 AND g.Enforcement = N'BLOCK';                                      -- 448
""")
src['rs2']=rs2
# ---------------- scheduler (447)
sc=body('447_asset_consistency_rules.sql','CREATE OR ALTER PROCEDURE grac_practice.sp_asset_scheduler_run'); src['sc']=sc
sc2=ins_after(sc, """    DECLARE @co INT, @cr INT, @cx INT;                                                     -- 447
""", """    DECLARE @po INT, @pc INT, @px INT;                                                     -- 448
""")
sc2=ins_before(sc2, """        -- 438: recurring asset activities (before the sweep, so new occurrences notify).
""", """        -- 448: privacy and retention reviews, exception expiry (before the sweep, so they notify).
        BEGIN TRY                                                                          -- 448
            EXEC grac_practice.sp_asset_privacy_sync @organization_id = @org, @actor = @actor,   -- 448
                 @out_opened = @po OUTPUT, @out_closed = @pc OUTPUT, @out_expired = @px OUTPUT;   -- 448
        END TRY                                                                            -- 448
        BEGIN CATCH                                                                        -- 448
            IF XACT_STATE() <> 0 ROLLBACK;                                                 -- 448
            SET @errors = @errors + 1;                                                     -- 448
            SET @err = LEFT(CONCAT(@err, CASE WHEN @err IS NULL THEN N'' ELSE CHAR(10) END,   -- 448
                                   N'Organization ', @org, N' (privacy): ', ERROR_MESSAGE()), 8000);   -- 448
        END CATCH                                                                          -- 448

""")
src['sc2']=sc2
# ---------------- lifecycle (447)
lt=body('447_asset_consistency_rules.sql','CREATE OR ALTER PROCEDURE grac_practice.sp_asset_lifecycle_transition'); src['lt']=lt
lt2=ins_before(lt, """    -- 440: retiring the asset is blocked while active critical relationships
""", """    -- 448: privacy requirements set to Block (5.1.16, 5.2.15, D162).
    IF @to_status_code IN (N'ACTIVE', N'DISPOSED', N'ARCHIVED')                                 -- 448
    BEGIN                                                                                      -- 448
        DECLARE @prv_target NVARCHAR(10) = CASE WHEN @to_status_code = N'ACTIVE' THEN N'ACTIVE' ELSE N'DISPOSAL' END;   -- 448
        DECLARE @prv NVARCHAR(1000) = (SELECT LEFT(STRING_AGG(CAST(CONCAT(g.RequirementName, N': ', g.Message) AS NVARCHAR(MAX)), N' '), 900)   -- 448
                                         FROM grac_practice.fn_asset_privacy_gaps(@organization_id, @asset_id) g   -- 448
                                        WHERE g.IsExcepted = 0 AND g.Enforcement = N'BLOCK' AND g.BlockTarget = @prv_target);   -- 448
        IF @prv IS NOT NULL AND @prv_target = N'ACTIVE'                                        -- 448
        BEGIN                                                                                  -- 448
            DECLARE @prv_msg NVARCHAR(1400) = CONCAT(N'The asset cannot become Active while privacy requirements are not met: ', @prv,   -- 448
                N' Complete the privacy fields or get an exception approved (Asset Privacy).');   -- 448
            THROW 53070, @prv_msg, 1;                                                          -- 448
        END                                                                                    -- 448
        IF @prv IS NOT NULL                                                                    -- 448
        BEGIN                                                                                  -- 448
            DECLARE @san_msg NVARCHAR(1400) = CONCAT(N'The asset cannot be disposed or archived yet: ', @prv,   -- 448
                N' Record the sanitization method, date and evidence first.');                 -- 448
            THROW 53071, @san_msg, 1;                                                          -- 448
        END                                                                                    -- 448
    END                                                                                        -- 448
""")
src['lt2']=lt2
# ---------------- notification sweep (439)
sw=body('439_asset_activity_results.sql','CREATE OR ALTER PROCEDURE grac_practice.sp_asset_notification_sweep'); src['sw']=sw
sw2=ins_before(sw, """    -- 2. Close / reopen.
""", """    -- 448: privacy reviews and retention ends from open reviews; approved
    -- privacy exceptions expiring (9.1.7, 448).
    INSERT #due (occurrence_key, activity_code, object_type, object_id, ref_id, asset_id, contract_id, trigger_date,   -- 448
                 object_ref, object_title, severity_code)                                     -- 448
    SELECT CONCAT(x.act, N':PR:', r.review_id, N':', CONVERT(NVARCHAR(8), r.due_date, 112)),   -- 448
           x.act, N'PRIVACY_REVIEW', r.review_id, NULL, r.asset_id, NULL, r.due_date, a.asset_name,   -- 448
           CONCAT(CASE r.review_kind WHEN N'PRIVACY' THEN N'Privacy / DPIA review of ' ELSE N'Retention end of personal data on ' END,   -- 448
                  a.asset_name),                                                               -- 448
           grac_practice.fn_asset_ntf_asset_severity(r.asset_id)                               -- 448
      FROM grac_practice.asset_privacy_review r                                                -- 448
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = r.asset_id            -- 448
     CROSS APPLY (SELECT CASE r.review_kind WHEN N'PRIVACY' THEN N'PRIVACY_REVIEW' ELSE N'RETENTION_REVIEW' END AS act) x   -- 448
     WHERE r.organization_id = @org AND r.status = N'OPEN';                                    -- 448
    INSERT #due (occurrence_key, activity_code, object_type, object_id, ref_id, asset_id, contract_id, trigger_date,   -- 448
                 object_ref, object_title, severity_code)                                     -- 448
    SELECT CONCAT(N'PRIVACY_REVIEW:PX:', e.exception_id, N':', CONVERT(NVARCHAR(8), e.expiry_date, 112)),   -- 448
           N'PRIVACY_REVIEW', N'PRIVACY_EXCEPTION', e.exception_id, NULL, e.asset_id, NULL, e.expiry_date, a.asset_name,   -- 448
           CONCAT(N'Privacy exception (', q.requirement_name, N') of ', a.asset_name, N' expires'),   -- 448
           grac_practice.fn_asset_ntf_asset_severity(e.asset_id)                               -- 448
      FROM grac_practice.asset_privacy_exception e                                             -- 448
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = e.asset_id            -- 448
      JOIN grac_practice.asset_privacy_requirement q ON q.requirement_code = e.requirement_code   -- 448
     WHERE e.organization_id = @org AND e.status = N'APPROVED';                                -- 448

""")
src['sw2']=sw2
# ---------------- notification parties (439)
np_=body('439_asset_activity_results.sql','CREATE OR ALTER PROCEDURE grac_practice.sp_asset_notification_parties'); src['np']=np_
np2=ins_before(np_, """    ELSE IF @otype IN (N'ASSET_MODEL', N'ASSET_OS', N'ASSET_FIRMWARE')
""", """    ELSE IF @otype = N'PRIVACY_REVIEW'                                                 -- 448
    BEGIN                                                                              -- 448
        -- 448: activity owner -- the privacy owner of the asset, else the asset owner.
        INSERT @raw (party_code, val)                                                  -- 448
        SELECT TOP 1 N'ACTIVITY_OWNER', r.val FROM @raw r                              -- 448
         WHERE r.party_code IN (N'PRIVACY_OWNER', N'ASSET_OWNER')                       -- 448
         ORDER BY CASE r.party_code WHEN N'PRIVACY_OWNER' THEN 0 ELSE 1 END;          -- 448
    END                                                                                -- 448
    ELSE IF @otype = N'PRIVACY_EXCEPTION'                                              -- 448
    BEGIN                                                                              -- 448
        INSERT @raw (party_code, val)                                                  -- 448
        SELECT x.code, CAST(x.emp AS NVARCHAR(30))                                     -- 448
          FROM grac_practice.asset_privacy_exception e                                 -- 448
         CROSS APPLY (VALUES (N'ACTIVITY_OWNER', e.owner_employee_id), (N'EXCEPTION_APPROVER', e.decided_employee_id)) x(code, emp)   -- 448
         WHERE e.exception_id = @oid AND x.emp IS NOT NULL;                            -- 448
    END                                                                                -- 448
""")
src['np2']=np2
for k,v in src.items(): open('/home/claude/w448/part_'+k+'.sql','w').write(v)
print({k:v.count('\n') for k,v in src.items()})
