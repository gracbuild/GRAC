#!/bin/bash
set -e
W=/home/claude/w453; OUT=${1:-$W/new}
rm -rf "$OUT"; cp -r $W/orig "$OUT"
cd $W
cat 453_a.sql 453_b.sql 453_c.sql 453_e.sql > 453.sql
cp 453.sql "$OUT/database/453_asset_report_schedules.sql"
cp 453_rb.sql "$OUT/database/453_asset_report_schedules_rollback.sql"
python3 p453_api.py "$OUT" >/dev/null
python3 p453_web.py "$OUT" >/dev/null
python3 pui453.py "$OUT" >/dev/null
python3 doc453.py "$OUT" >/dev/null
rm -f "$OUT/database/274_menu_master_seed.sql"   # not changed by 453
echo built "$OUT"
