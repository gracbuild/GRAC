# 445: API + Web proxy for asset splits.
def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    open(path, 'w', encoding='utf-8', newline='').write(s)
API = "src/PracticeManagement.Api/"
WEB = "src/PracticeManagement.Web/"

edit(API + "Models/AssetConfigModels.cs", [(
"""public sealed record AssetMergeActionRequest(long OrganizationId, string? Action, string? Note, long? ExpectedRecordVersion);
""",
"""public sealed record AssetMergeActionRequest(long OrganizationId, string? Action, string? Note, long? ExpectedRecordVersion);

// ---------------------------------------------------------------------
// Asset split (migration 445) -- actions use AssetMergeActionRequest
// ---------------------------------------------------------------------
/// <summary>An item of the source for a resulting record. ObjectKind / ObjectId / ObjectKey as the split plan lists
/// them; FieldMode MOVE | COPY for ObjectKind FIELD (ObjectId = field definition).</summary>
public sealed record AssetSplitAllocationItem(string? ObjectKind, long? ObjectId, string? ObjectKey, long TargetAssetId, string? FieldMode);

/// <summary>Draft split: source, 1-5 resulting records (new Draft assets), reason, allocations.</summary>
public sealed record AssetSplitSaveRequest(
    long                            OrganizationId,
    long?                           EventId,
    long                            SourceAssetId,
    List<long>?                     ResultAssetIds,
    string?                         Reason,
    List<AssetSplitAllocationItem>? Allocations,
    long?                           ExpectedRecordVersion);
""")])

edit(API + "Services/AssetConfigService.cs", [
("""//   sp_asset_merge_* (444 -- merge events, plan, approval, execution, recovery)
""",
"""//   sp_asset_merge_* (444 -- merge events, plan, approval, execution, recovery)
//   sp_asset_split_* (445 -- split events and allocation; actions through sp_asset_merge_action)
"""),
("""    Task<AssetLifecycleResult> MergeActionAsync(long eventId, AssetMergeActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
""",
"""    Task<AssetLifecycleResult> MergeActionAsync(long eventId, AssetMergeActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct);

    // 445 -- Asset split (actions: MergeActionAsync, one procedure for both kinds)
    Task<object> ListSplitsAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, CancellationToken ct);
    Task<object?> GetSplitAsync(long organizationId, long eventId, CancellationToken ct);
    Task<AssetLifecycleResult> SaveSplitAsync(AssetSplitSaveRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
"""),
("""    public async Task<object> ListMergesAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_merge_events");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 20);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
""",
"""    public Task<object> ListMergesAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, CancellationToken ct) =>
        ListMergeSplitEventsAsync("MERGE", organizationId, status, search, pageNumber, pageSize, ct);

    // 445: merges and splits share the event list (@event_kind).
    private async Task<object> ListMergeSplitEventsAsync(string kind, long organizationId, string? status, string? search, int pageNumber,
        int pageSize, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_merge_events");
        AddParam(command, "@organization_id", DbType.Int64,  organizationId);
        AddParam(command, "@status",          DbType.String, Blank(status), 20);
        AddParam(command, "@search",          DbType.String, Blank(search), 200);
        AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
        AddParam(command, "@page_size",       DbType.Int32,  pageSize);
        AddParam(command, "@event_kind",      DbType.String, kind, 10);
        await using var reader = await command.ExecuteReaderAsync(ct);
"""),
("""    public Task<AssetLifecycleResult> MergeActionAsync(long eventId, AssetMergeActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
""",
"""    // ----------------------------------------------------------------
    // 445 -- Asset split
    // ----------------------------------------------------------------
    public Task<object> ListSplitsAsync(long organizationId, string? status, string? search, int pageNumber, int pageSize, CancellationToken ct) =>
        ListMergeSplitEventsAsync("SPLIT", organizationId, status, search, pageNumber, pageSize, ct);

    public async Task<object?> GetSplitAsync(long organizationId, long eventId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_split_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@event_id",        DbType.Int64, eventId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var split = await ReadRowsAsync(reader, ct);
            if (split.Count == 0) return null;
            var empty = new List<Dictionary<string, object?>>();
            var assets = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var approvals = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var blockers = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var plan = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var outcomes = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var impact = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            return new { split = split[0], assets, approvals, blockers, plan, outcomes, impact };
        }
        catch (SqlException ex) when (ex.Number == 52902) { return null; }
    }

    public Task<AssetLifecycleResult> SaveSplitAsync(AssetSplitSaveRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_split_save", "eventId", command =>
        {
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@event_id",                DbType.Int64,  request.EventId);
            AddParam(command, "@source_asset_id",         DbType.Int64,  request.SourceAssetId);
            AddParam(command, "@results_json",            DbType.String,
                System.Text.Json.JsonSerializer.Serialize(request.ResultAssetIds ?? new List<long>()));
            AddParam(command, "@reason",                  DbType.String, Blank(request.Reason), 1000);
            AddParam(command, "@allocations_json",        DbType.String, System.Text.Json.JsonSerializer.Serialize(
                (request.Allocations ?? new List<AssetSplitAllocationItem>()).Select(a => new
                {
                    objectKind = a.ObjectKind, objectId = a.ObjectId, objectKey = a.ObjectKey, targetAssetId = a.TargetAssetId, fieldMode = a.FieldMode
                })));
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    // 444 / 445: one action procedure for merges and splits.
    public Task<AssetLifecycleResult> MergeActionAsync(long eventId, AssetMergeActionRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
"""),
])

edit(API + "Controllers/AssetConfigController.cs", [
("""//   POST discovery/merges/{id}/action                SUBMIT | CANCEL | APPROVE | REJECT | EXECUTE | RECOVER
""",
"""//   POST discovery/merges/{id}/action                SUBMIT | CANCEL | APPROVE | REJECT | EXECUTE | RECOVER
//   GET  discovery/splits?organizationId=&status=&search=&pageNumber=&pageSize=   split events (445)
//   GET  discovery/splits/{id}?organizationId=       event, assets, approvals, blockers, plan / allocation, outcomes, impact
//   POST discovery/splits                            new / changed draft split (results, allocations)
//   POST discovery/splits/{id}/action                as merges (same procedure)
"""),
("""    private static readonly int[] MergeConflict = { 52903 };
""",
"""    private static readonly int[] MergeConflict = { 52903 };

    // ---------------------------------------------------------------- 445: asset split
    [HttpGet("discovery/splits")]
    public Task<IActionResult> Splits([FromQuery] long? organizationId, [FromQuery] string? status, [FromQuery] string? search,
        [FromQuery] int? pageNumber, [FromQuery] int? pageSize, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListSplitsAsync(organizationId.Value, status, search, pageNumber ?? 1, pageSize ?? 25, ct), "splits");
    }

    [HttpGet("discovery/splits/{eventId:long}")]
    public Task<IActionResult> Split(long eventId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetSplitAsync(o, eventId, ct), "Split not found.", "split");

    [HttpPost("discovery/splits")]
    public async Task<IActionResult> SaveSplit([FromBody] AssetSplitSaveRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (request.SourceAssetId <= 0) return BadRequest(new { error = "sourceAssetId is required." });
        return ResultWritten(await service.SaveSplitAsync(request, ActorEmployeeId, Actor, ct), MergeNotFound, MergeConflict);
    }

    [HttpPost("discovery/splits/{eventId:long}/action")]
    public async Task<IActionResult> SplitAction(long eventId, [FromBody] AssetMergeActionRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        if (string.IsNullOrWhiteSpace(request.Action)) return BadRequest(new { error = "action is required." });
        return ResultWritten(await service.MergeActionAsync(eventId, request, ActorEmployeeId, Actor, ct), MergeNotFound, MergeConflict);
    }
"""),
])

edit(WEB + "Controllers/AssetConfigController.cs", [
("""//                                      RECOVER also needs asset-register EDIT
""",
"""//                                      RECOVER also needs asset-register EDIT
//                                      445: splits / splits/{id}/action as merges
"""),
("""            : isDiscovery && lower.StartsWith("discovery/merges/") && lower.EndsWith("/action")   // 444
""",
"""            : isDiscovery && (lower.StartsWith("discovery/merges/") || lower.StartsWith("discovery/splits/")) && lower.EndsWith("/action")   // 444 / 445
"""),
("""            : isDiscovery && lower == "discovery/merges"                                              // 444
""",
"""            : isDiscovery && (lower == "discovery/merges" || lower == "discovery/splits")             // 444 / 445
"""),
])
print("p445 ok")
