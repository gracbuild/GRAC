-- =====================================================================
-- 8. Menu: Asset & Contract -> Asset Relationships (also carried in 274)
-- =====================================================================
MERGE grac_practice.menu_master AS t
USING (VALUES
    (N'asset-relationships', N'Asset Relationships', N'Practice/Index/asset-relationships', 361, N'diagram-project', N'Asset & Contract')
) AS s(menu_key, menu_name, menu_url, display_order, icon_class, module_type)
ON t.menu_key = s.menu_key
WHEN MATCHED AND (ISNULL(t.menu_name, N'') <> s.menu_name OR ISNULL(t.menu_url, N'') <> s.menu_url
               OR t.display_order <> s.display_order OR ISNULL(t.icon_class, N'') <> s.icon_class
               OR ISNULL(t.module_type, N'') <> s.module_type OR t.status <> N'Active') THEN UPDATE SET
    menu_name = s.menu_name, menu_url = s.menu_url, display_order = s.display_order, icon_class = s.icon_class,
    module_type = s.module_type, status = N'Active', updated_by = N'seed-440', updated_dt = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (menu_key, menu_name, menu_url, display_order, icon_class, module_type, status, entered_by)
    VALUES (s.menu_key, s.menu_name, s.menu_url, s.display_order, s.icon_class, s.module_type, N'Active', N'seed-440');
PRINT CONCAT('440: menu row upserted: ', @@ROWCOUNT);
GO

UPDATE c
   SET parent_menu_id = p.menu_id, updated_by = N'seed-440', updated_dt = SYSUTCDATETIME()
  FROM grac_practice.menu_master c
  JOIN grac_practice.menu_master p ON p.menu_key = N'nav-asset-contract'
 WHERE c.menu_key = N'asset-relationships' AND ISNULL(c.parent_menu_id, -1) <> p.menu_id;
GO

DECLARE @active_rs INT = (
    SELECT TOP 1 record_status_id FROM grac_practice.record_status_master
     WHERE status_code = N'Active' OR status_name = N'Active' ORDER BY record_status_id);
IF @active_rs IS NULL SET @active_rs = 1;
INSERT grac_practice.organization_role_menu_permission
    (role_id, menu_id, can_view, can_add, can_edit, can_delete, can_approve, status, record_status_id, entered_by, entered_dt)
SELECT r.role_id, m.menu_id, 1, 1, 1, 0, 1, N'Active', @active_rs, N'seed-440', SYSUTCDATETIME()
  FROM grac_practice.organization_role r
  JOIN grac_practice.menu_master m ON m.menu_key = N'asset-relationships'
 WHERE r.role_name = N'Admin' AND r.status = N'Active'
   AND NOT EXISTS (SELECT 1 FROM grac_practice.organization_role_menu_permission e
                    WHERE e.role_id = r.role_id AND e.menu_id = m.menu_id);
PRINT CONCAT('440: Admin grants inserted: ', @@ROWCOUNT);
GO

-- =====================================================================
-- Verification
-- =====================================================================
SELECT '440-a relationship types (12, Supports Service inactive until 7.2)' AS Check_,
       CASE WHEN (SELECT COUNT(*) FROM grac_practice.asset_relationship_type) >= 12
             AND EXISTS (SELECT 1 FROM grac_practice.asset_relationship_type WHERE type_code = N'SUPPORTS_SERVICE' AND is_active = 0)
             AND EXISTS (SELECT 1 FROM grac_practice.asset_relationship_type
                          WHERE type_code = N'HOSTED_ON' AND cardinality = N'ONE_TARGET' AND loop_rule = N'BLOCK' AND dependent_side = N'SOURCE')
            THEN 'PASS' ELSE 'FAIL' END AS Result
UNION ALL
SELECT '440-b relationship and history tables, current-relationship index',
       CASE WHEN OBJECT_ID('grac_practice.asset_relationship','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_relationship_history','U') IS NOT NULL
             AND EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_pm_asset_rel_current' AND is_unique = 1)
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '440-c functions and procedures present',
       CASE WHEN OBJECT_ID('grac_practice.fn_asset_ci_catalog') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_relationship_edges') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_relationship_blockers') IS NOT NULL
             AND (SELECT COUNT(*) FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'grac_practice'
                   AND name IN ('sp_asset_relationship_check', 'sp_asset_relationship_history_add', 'sp_asset_relationship_sync',
                                'sp_asset_relationship_save', 'sp_asset_relationship_action', 'sp_asset_ci_impact',
                                'sp_asset_relationship_config_get', 'sp_asset_ci_lookup', 'sp_asset_relationships',
                                'sp_asset_relationship_get')) = 10
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '440-d lifecycle transition carries the 435 coverage gate and the 440 retirement gate',
       CASE WHEN OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_lifecycle_transition')) LIKE '%THROW 54560%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_lifecycle_transition')) LIKE '%THROW 54719%'
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '440-e menu row Active under Asset & Contract',
       CASE WHEN EXISTS (SELECT 1 FROM grac_practice.menu_master c
                           JOIN grac_practice.menu_master p ON p.menu_id = c.parent_menu_id AND p.menu_key = N'nav-asset-contract'
                          WHERE c.menu_key = N'asset-relationships' AND c.status = N'Active') THEN 'PASS' ELSE 'FAIL' END;
GO

-- =====================================================================
-- UAT (after deploying the API + Web build; re-login for the menu grant)
--   Needs: users P (proposes) and A (approves), both with
--   asset-relationships; application APP1; server assets SRV1 and SRV2;
--   a database asset DB1.
--   1. Asset Relationships -> Add: APP1 "Runs on" SRV1 -> Proposed. A
--      approves -> Active (Verified).
--   2. Add DB1 "Is hosted on" SRV1, then DB1 "Is hosted on" SRV2 -> refused
--      (one target only, 54707). Add APP1 "Depends on" DB1, critical, High;
--      P cannot approve it (54716); A approves.
--   3. Add DB1 "Depends on" APP1 -> refused: circular dependency (54708).
--   4. Impact analysis: SRV1, downstream -> DB1 (level 1), APP1 (level 1,
--      runs on SRV1) -- APP1 listed once although it is also reached through
--      DB1. Upstream from APP1 -> SRV1 and DB1. Critical only -> DB1 only.
--   5. Open APP1 depends on DB1 (critical): change the weight with a reason
--      -> pending approval, still Active; A approves -> version 2 in history.
--      Retire it -> pending; reject it with a note.
--   6. Asset Register -> DB1 -> Lifecycle: move towards disposal
--      (Pending Decommission -> Sanitization) -> refused, naming APP1
--      (54719). Accept the dependency for retirement (A, note) -> allowed.
--   7. Set an effective-to date in the past on a non-critical relationship
--      -> the list shows it Inactive; it stays in the history.
-- =====================================================================
