# 442: Asset Discovery links a candidate to a register asset through the
# relationships/ci-lookup name search; let Asset Discovery viewers call it.
import re
p = "src/PracticeManagement.Web/Controllers/AssetConfigController.cs"
s = open(p, encoding="utf-8-sig").read()
old = """            if (!HttpContext.IsOrganizationAllowed(orgId)) return OrganizationDenied();
            allowed = Can(RelationshipArea, "VIEW");
        }"""
new = """            if (!HttpContext.IsOrganizationAllowed(orgId)) return OrganizationDenied();
            allowed = Can(RelationshipArea, "VIEW")
                      || (lower == "relationships/ci-lookup" && Can(DiscoveryArea, "VIEW"));   // 442: asset picker of the queue
        }"""
assert s.count(old) == 1
s = s.replace(old, new)
old2 = """//                                      exceptions/{id}/resolve ACCEPT_OBSERVED -> APPROVE, other actions EDIT"""
new2 = old2 + """
//                                      relationships/ci-lookup also open to asset-discovery VIEW (asset picker)"""
assert s.count(old2) == 1
s = s.replace(old2, new2)
open(p, "w", encoding="utf-8").write(s)
print("p442b ok")

# 442: a discovery batch (up to 5000 records, each reconciled) can run past
# the 100-second HttpClient default; the API command allows 600 seconds.
s = open(p, encoding="utf-8").read()
old = """            var resp = await BuildClient().SendAsync(msg, ct);"""
new = """            var client = BuildClient();
            if (relativeUrl.Contains("/discovery/sources/", StringComparison.OrdinalIgnoreCase)
                && relativeUrl.EndsWith("/batches", StringComparison.OrdinalIgnoreCase))
                client.Timeout = TimeSpan.FromMinutes(10);                       // 442: batch ingestion
            var resp = await client.SendAsync(msg, ct);"""
assert s.count(old) == 1
s = s.replace(old, new)
open(p, "w", encoding="utf-8").write(s)
print("p442b timeout ok")
