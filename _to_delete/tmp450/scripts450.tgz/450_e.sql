-- =====================================================================
-- 10. Verification
-- =====================================================================
SELECT '450-a objects' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_governance_kpi','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_governance_setting','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_governance_org_setting','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_governance_relationship_rule','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_governance_snapshot','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_governance_snapshot_kpi','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_governance_snapshot_item','U') IS NOT NULL
             AND (SELECT COUNT(*) FROM grac_practice.asset_governance_kpi) = 10
             AND OBJECT_ID('grac_practice.fn_asset_governance_effective') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_governance_assets') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_governance_items') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_governance_snapshot_take','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_governance_get','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_governance_items','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_governance_snapshots','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_governance_settings','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_governance_setting_save','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_governance_org_setting_save','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_governance_relationship_rule_save','P') IS NOT NULL
            THEN 'PASS' ELSE 'FAIL' END AS Result;
SELECT '450-b scheduler re-issue' AS Check_,
       CASE WHEN OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) LIKE '%sp_asset_governance_snapshot_take%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) LIKE '%sp_asset_privacy_sync%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) LIKE '%sp_asset_consistency_evaluate%'
            THEN 'PASS' ELSE 'FAIL' END AS Result;
-- Every KPI branch runs for every organization; nothing is written. Each
-- record row has a valid outcome and an excluded row contributes nothing.
SELECT '450-c record rows' AS Check_,
       (SELECT COUNT(*) FROM grac_practice.organization o CROSS APPLY grac_practice.fn_asset_governance_items(o.organization_id, NULL) i) AS RecordRows,
       CASE WHEN NOT EXISTS (SELECT 1 FROM grac_practice.organization o
                              CROSS APPLY grac_practice.fn_asset_governance_items(o.organization_id, NULL) i
                              WHERE i.Outcome NOT IN (N'PASS', N'FAIL', N'EXCLUDED')
                                 OR (i.Outcome = N'EXCLUDED' AND (i.Numerator <> 0 OR i.Denominator <> 0))
                                 OR i.Numerator > i.Denominator OR i.Numerator < 0)
            THEN 'PASS' ELSE 'FAIL' END AS Result;
SELECT '450-d menu' AS Check_,
       CASE WHEN EXISTS (SELECT 1 FROM grac_practice.menu_master c
                           JOIN grac_practice.menu_master p ON p.menu_id = c.parent_menu_id AND p.menu_key = N'nav-asset-contract'
                          WHERE c.menu_key = N'asset-governance' AND c.status = N'Active') THEN 'PASS' ELSE 'FAIL' END AS Result;
GO

/* =====================================================================
   UAT (asset-governance VIEW / EDIT; asset data from 428-448)
   ---------------------------------------------------------------------
   1. Asset Governance -> Take snapshot: ten KPI cards with score, rating
      against target / warning, numerator / denominator, failing and
      excluded counts; the overall score. Take snapshot again with no data
      change -> "No change since the current snapshot" (UNCHANGED).
   2. Open a card -> KPI detail: formula, numerator, denominator,
      population, as-of, exclusions, zero-denominator and rounding text;
      the record grid (Failing / Passing / Excluded) adds up exactly to the
      card (numerator = sum of passing contributions, denominator = passing
      + failing contributions).
   3. Clear the owner of an asset in use and take a snapshot -> Ownership
      Completeness drops, the asset is listed as failing ("No asset
      owner."); History shows version 2 of today and version 1 kept as
      superseded and still openable.
   4. Settings: set Attestation Compliance target 99 / warning 90 / period
      30 days -> the next snapshot uses them; disable a KPI -> shown as
      disabled and left out of the overall score; warning above target
      for a higher-is-better KPI refused (53082).
   5. Settings -> Relationship requirements: asset type Virtual Machine
      requires 1 "Is hosted on" (asset as source) -> Relationship
      Completeness lists every VM in use; one with no Active Hosted On
      relationship fails.
   6. A source with expected interval 24 h added 10 days ago and 7
      completed batches on different days -> Connector Availability
      7 / 10 (one decimal: 70.0).
   7. No discovery source -> Discovery Freshness and Connector
      Availability show "Not applicable" and are not in the overall score.
   8. Run the asset scheduler -> one snapshot per organization for today;
      a second run the same day takes none.
   ===================================================================== */
