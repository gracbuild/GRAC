parts = ["443_a.sql", "443_b.sql", "443_c1.sql", "443_c2.sql", "443_f.sql"]
s = "".join(open("/home/claude/" + p).read() for p in parts)
open("/home/claude/443.sql", "w").write(s)
print("443.sql", s.count("\n"))
