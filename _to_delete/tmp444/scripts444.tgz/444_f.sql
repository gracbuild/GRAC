
-- =====================================================================
-- Verification
-- =====================================================================
SELECT '444-a tables and merged pointer' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_merge_split_event','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_merge_split_member','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_merge_split_approval','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_merge_split_object','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_alias','U') IS NOT NULL
             AND COL_LENGTH('grac_practice.organization_dependency_asset','merged_into_asset_id') IS NOT NULL
            THEN 'PASS' ELSE 'FAIL' END AS Result
UNION ALL
SELECT '444-b functions and procedures present',
       CASE WHEN OBJECT_ID('grac_practice.fn_asset_merge_blockers') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_merge_plan') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_merge_fields') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_merge_impact') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_merge_critical') IS NOT NULL
             AND (SELECT COUNT(*) FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'grac_practice'
                   AND name IN ('sp_asset_merge_save', 'sp_asset_merge_execute_one', 'sp_asset_merge_recover', 'sp_asset_merge_action',
                                'sp_asset_merge_events', 'sp_asset_merge_get')) = 6
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '444-c merge rules: every status to Archived and back, role ASSET_MERGE, no gate',
       CASE WHEN (SELECT COUNT(*) FROM grac_practice.entity_state_transition_rule r
                   WHERE r.entity_type = N'Asset' AND r.actor_role_code = N'ASSET_MERGE'
                     AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_lifecycle_transition_gate g WHERE g.transition_rule_id = r.transition_rule_id))
                 = 2 * ((SELECT COUNT(*) FROM grac_practice.entity_status_master WHERE entity_type = N'Asset') - 1)
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '444-d user lifecycle rules unchanged (no way back from Disposed / Archived)',
       CASE WHEN NOT EXISTS (SELECT 1 FROM grac_practice.entity_state_transition_rule
                              WHERE entity_type = N'Asset' AND is_active = 1 AND actor_role_code IS NULL
                                AND from_status_code IN (N'DISPOSED', N'ARCHIVED') AND to_status_code <> N'ARCHIVED')
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '444-e register search finds aliases',
       CASE WHEN OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_register_list')) LIKE '%asset_alias%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_register_list')) LIKE '%pending_only%'
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '444-f plan and blockers run',
       CASE WHEN (SELECT COUNT(*) FROM grac_practice.fn_asset_merge_plan(-1, -1, -2)) = 0
             AND (SELECT COUNT(*) FROM grac_practice.fn_asset_merge_blockers(-1, -1, -2)) = 2
            THEN 'PASS' ELSE 'FAIL' END;
GO

-- =====================================================================
-- UAT (after deploying the API + Web build)
--   Needs: assets S (survivor) and D (duplicate) of one organization, D with
--   a discovery link, a relationship to a business service, contract
--   coverage on an active version, a risk mapping, an asset tag and a value
--   S lacks; users R (asset-discovery EDIT + asset-register EDIT), A1 and
--   A2 (asset-discovery APPROVE).
--   1. Asset Discovery -> Reconciliation queue: a Potential duplicate of S
--      and D -> Merge (or Merges -> New merge, survivor S, duplicate D).
--      The window shows both assets, impact per asset, the field
--      comparison (choose D for a field), the plan (moves, ends, kept) and
--      blockers. Give the reason, save, submit.
--   2. D with an open workflow case -> Submit refused, the case named.
--   3. A non-critical merge: R cannot approve (requester); A1 approves ->
--      Approved. Critical (S criticality Critical): A1 approves -> first
--      approval; A1 again refused; A2 approves -> Approved.
--   4. R executes -> Executed: outcomes per object (relationships moved or
--      ended, discovery link, coverage, risk mapping moved, fields filled /
--      replaced, aliases, D archived and inactive); S shows the values of D; the
--      Asset Register search for the name or asset tag of D finds S; the
--      Potential duplicate exception is closed as Merged; the history of D
--      (lifecycle, custody, completed activities) stays on D.
--   5. A1 recovers (note) -> Recovered: D is back in its earlier status, the
--      objects are on D again; a value changed on S after the merge is kept
--      and its row shows why; the event and its rows remain.
--   6. Reject (A1, note) and Cancel (R, note) close a merge without changes.
-- =====================================================================
