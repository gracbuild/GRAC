CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_task_sync
    @organization_id BIGINT,
    @actor           NVARCHAR(100) = N'scheduler',
    @completed       INT           = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'scheduler');
    SET @completed = 0;
    DECLARE @done TABLE (occurrence_id BIGINT NOT NULL, asset_id BIGINT NOT NULL, template_code NVARCHAR(40) NOT NULL,
                         status NVARCHAR(12) NOT NULL, completed_dt DATETIME2 NULL);
    -- 439: a result activity is completed by its approved result, not by the
    -- task; a task closed first leaves the occurrence open and flagged (D71).
    UPDATE o
       SET needs_reconciliation = 1,
           reconciliation_reason = N'The Task Centre task was closed without an approved result; record and approve the result.',
           updated_by = @actor, updated_dt = SYSUTCDATETIME()
      FROM grac_practice.asset_activity_occurrence o
      JOIN grac_practice.asset_activity_template tp ON tp.template_code = o.template_code
      JOIN grac_practice.practice_task t ON t.task_id = o.task_id
      JOIN grac_practice.entity_status_master s ON s.entity_status_id = t.current_status_id
     WHERE o.organization_id = @organization_id AND o.status = N'OPEN' AND tp.result_required = 1
       AND s.status_code <> N'Cancelled' AND (s.status_code = N'Closed' OR t.completed_dt IS NOT NULL)
       AND o.needs_reconciliation = 0
       AND ISNULL(o.reconciliation_reason, N'') <> N'The Task Centre task was closed without an approved result; record and approve the result.';

    BEGIN TRAN;
    UPDATE o
       SET status = CASE WHEN s.status_code = N'Cancelled' THEN N'CANCELLED' ELSE N'COMPLETED' END,
           completed_dt = CASE WHEN s.status_code = N'Cancelled' THEN NULL ELSE COALESCE(t.completed_dt, t.closed_at, SYSUTCDATETIME()) END,
           completed_by_employee_id = CASE WHEN s.status_code = N'Cancelled' THEN NULL ELSE t.completed_by_employee_id END,
           closed_dt = SYSUTCDATETIME(), updated_by = @actor, updated_dt = SYSUTCDATETIME()
    OUTPUT inserted.occurrence_id, inserted.asset_id, inserted.template_code, inserted.status, inserted.completed_dt
      INTO @done (occurrence_id, asset_id, template_code, status, completed_dt)
      FROM grac_practice.asset_activity_occurrence o
      JOIN grac_practice.practice_task t ON t.task_id = o.task_id
      JOIN grac_practice.entity_status_master s ON s.entity_status_id = t.current_status_id
      JOIN grac_practice.asset_activity_template tp ON tp.template_code = o.template_code     -- 439
     WHERE o.organization_id = @organization_id AND o.status = N'OPEN'
       AND (s.status_code IN (N'Closed', N'Cancelled') OR t.completed_dt IS NOT NULL)
       AND (s.status_code = N'Cancelled' OR tp.result_required = 0);                          -- 439
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    SELECT N'asset-activity-occurrence', d.occurrence_id, d.status, N'{"status":"OPEN"}',
           (SELECT d.status AS status, d.completed_dt AS completedDt FOR JSON PATH, WITHOUT_ARRAY_WRAPPER), N'Active', @actor
      FROM @done d;
    COMMIT;
    SET @completed = (SELECT COUNT(*) FROM @done WHERE status = N'COMPLETED');

    -- The last date field follows the completion (never moves back).
    DECLARE @asset BIGINT, @key NVARCHAR(100), @dt DATE, @cur DATE, @val NVARCHAR(400);
    DECLARE last_cur CURSOR LOCAL STATIC FOR
        SELECT d.asset_id, t.last_date_field_key, CAST(d.completed_dt AS DATE)
          FROM @done d
          JOIN grac_practice.asset_activity_template t ON t.template_code = d.template_code
         WHERE d.status = N'COMPLETED' AND t.last_date_field_key IS NOT NULL;
    OPEN last_cur;
    FETCH NEXT FROM last_cur INTO @asset, @key, @dt;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @cur = (SELECT v.value_date FROM grac_practice.asset_field_value v
                      JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id AND f.field_key = @key
                     WHERE v.asset_id = @asset);
        IF @cur IS NULL OR @cur < @dt
        BEGIN
            SET @val = CONVERT(NVARCHAR(10), @dt, 23);
            EXEC grac_practice.sp_asset_field_value_set @asset_id = @asset, @field_key = @key, @value = @val, @actor = @actor;
        END
        FETCH NEXT FROM last_cur INTO @asset, @key, @dt;
    END
    CLOSE last_cur;
    DEALLOCATE last_cur;
END
GO
