CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_generate
    @organization_id BIGINT,
    @actor           NVARCHAR(100) = N'scheduler',
    @opened          INT           = NULL OUTPUT,
    @tasks           INT           = NULL OUTPUT,
    @errors          INT           = NULL OUTPUT,
    @error_text      NVARCHAR(MAX) = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'scheduler');
    SELECT @opened = 0, @tasks = 0, @errors = 0, @error_text = NULL;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    -- a. Reconciliation flags (a reason already reconciled is not raised again).
    UPDATE o
       SET needs_reconciliation = 1, reconciliation_reason = r.reason, updated_by = @actor, updated_dt = SYSUTCDATETIME()
      FROM grac_practice.asset_activity_occurrence o
      LEFT JOIN grac_practice.asset_activity_schedule s ON s.asset_id = o.asset_id AND s.template_code = o.template_code
     CROSS APPLY (SELECT CASE
               WHEN s.schedule_state IS NULL OR s.schedule_state <> N'SCHEDULED'
                   THEN N'The activity no longer applies or is no longer scheduled for this asset.'
               WHEN s.status_code = N'COVERED'
                   THEN N'A contract now covers this renewal; complete or cancel the task after reconciling (BRD 7.1.5).'
               WHEN s.next_due_date <> o.due_date
                   THEN CONCAT(N'The due date is now ', CONVERT(NVARCHAR(10), s.next_due_date, 23), N'.') END AS reason) r
     WHERE o.organization_id = @organization_id AND o.status = N'OPEN' AND o.needs_reconciliation = 0
       AND r.reason IS NOT NULL AND r.reason <> ISNULL(o.reconciliation_reason, N'');

    -- b. Coverage no longer reaches a covered renewal: it becomes an asset task.
    UPDATE o
       SET status = N'OPEN', decision = N'ASSET_TASK',
           decision_reason = N'The matching contract no longer covers the asset through the due date (BRD 7.1.3).',
           contract_version_id = NULL, updated_by = @actor, updated_dt = SYSUTCDATETIME()
      FROM grac_practice.asset_activity_occurrence o
      JOIN grac_practice.asset_activity_schedule s ON s.asset_id = o.asset_id AND s.template_code = o.template_code
     WHERE o.organization_id = @organization_id AND o.status = N'COVERED' AND s.schedule_state = N'SCHEDULED'
       AND s.next_due_date = o.due_date AND s.status_code <> N'COVERED'
       AND DATEADD(DAY, -(SELECT LeadDays FROM grac_practice.fn_asset_activity_settings(@organization_id) x
                           WHERE x.TemplateCode = o.template_code), o.due_date) <= @today
       AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_activity_occurrence z
                        WHERE z.asset_id = o.asset_id AND z.template_code = o.template_code AND z.status = N'OPEN');

    -- c. New occurrences.
    DECLARE @new TABLE (occurrence_id BIGINT NOT NULL);
    INSERT grac_practice.asset_activity_occurrence
        (organization_id, asset_id, template_code, due_date, sequence_no, occurrence_key, decision, decision_reason,
         contract_version_id, status, entered_by, is_retest)                                       -- 439
    OUTPUT inserted.occurrence_id INTO @new (occurrence_id)
    SELECT @organization_id, s.asset_id, s.template_code, s.next_due_date, q.seq,
           CONCAT(N'AA-', s.template_code, N'-', s.asset_id, N'-', CONVERT(NVARCHAR(8), s.next_due_date, 112), N'-', q.seq),
           CASE WHEN s.status_code = N'COVERED' THEN N'CONTRACT_COVERED' ELSE N'ASSET_TASK' END,
           CASE WHEN s.status_code = N'FAILED' THEN N'Re-test after a failed result (BRD 7.1.6). ' ELSE N'' END   -- 439
           + CASE WHEN s.due_source = N'WAIVED_REVIEW' THEN N'Review date of a waived occurrence (BRD 7.1.5). ' ELSE N'' END
           + CASE WHEN s.status_code = N'COVERED'
                    THEN N'A matching contract covers the asset through the due date: contract-level renewal, no separate task (BRD 7.1.3).'
                WHEN t.activity_kind = N'EXECUTION' AND s.contract_version_id IS NOT NULL
                    THEN N'Asset-specific result: one task per asset; the covering contract is linked (BRD 7.1.2).'
                WHEN t.activity_kind = N'EXECUTION' THEN N'Asset-specific result: one task per asset (BRD 7.1.4).'
                ELSE N'No matching contract covers the asset: individual renewal task (BRD 7.1.3).' END
           + CASE WHEN q.seq > 1 THEN N' The previous task for this due date was cancelled.' ELSE N'' END,
           s.contract_version_id,
           CASE WHEN s.status_code = N'COVERED' THEN N'COVERED' ELSE N'OPEN' END, @actor,
           CASE WHEN s.status_code = N'FAILED' THEN 1 ELSE 0 END                                     -- 439
      FROM grac_practice.asset_activity_schedule s
      JOIN grac_practice.asset_activity_template t ON t.template_code = s.template_code
      JOIN grac_practice.fn_asset_activity_settings(@organization_id) st ON st.TemplateCode = s.template_code AND st.IsActive = 1
     CROSS APPLY (SELECT 1 + COUNT(*) AS seq FROM grac_practice.asset_activity_occurrence z
                   WHERE z.asset_id = s.asset_id AND z.template_code = s.template_code AND z.due_date = s.next_due_date) q
     WHERE s.organization_id = @organization_id AND s.schedule_state = N'SCHEDULED'
       AND DATEADD(DAY, -st.LeadDays, s.next_due_date) <= @today
       AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_activity_occurrence z
                        WHERE z.asset_id = s.asset_id AND z.template_code = s.template_code
                          AND (z.status = N'OPEN' OR (z.due_date = s.next_due_date AND z.status IN (N'COMPLETED', N'COVERED', N'WAIVED')
                                                       AND NOT (s.status_code = N'FAILED' AND z.status = N'COMPLETED' AND z.is_retest = 0))));   -- 439
    SET @opened = @@ROWCOUNT;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    SELECT N'asset-activity-occurrence', o.occurrence_id, N'CREATE', NULL,
           (SELECT o.occurrence_key AS occurrenceKey, o.asset_id AS assetId, o.template_code AS templateCode, o.due_date AS dueDate,
                   o.decision AS decision, o.contract_version_id AS contractVersionId FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           N'Active', @actor
      FROM @new n JOIN grac_practice.asset_activity_occurrence o ON o.occurrence_id = n.occurrence_id;

    -- d. Tasks.
    DECLARE @occ BIGINT, @asset BIGINT, @tpl NVARCHAR(40), @due DATE, @key NVARCHAR(200), @ver BIGINT,
            @tpl_name NVARCHAR(160), @owner_key NVARCHAR(100), @grouping NVARCHAR(12), @cmp_owner BIGINT,
            @asset_name NVARCHAR(400), @asset_owner BIGINT, @crit NVARCHAR(40), @reason NVARCHAR(400),
            @assignee BIGINT, @prio NVARCHAR(30), @title NVARCHAR(250), @descr NVARCHAR(MAX), @ref NVARCHAR(200),
            @cmp BIGINT, @cmp_key NVARCHAR(120), @period CHAR(6), @tid BIGINT, @contract_text NVARCHAR(400), @target DATETIME2;
    DECLARE task_cur CURSOR LOCAL STATIC FOR
        SELECT o.occurrence_id, o.asset_id, o.template_code, o.due_date, o.occurrence_key, o.contract_version_id, o.decision_reason,
               t.template_name, t.owner_field_key, st.GroupingMode, st.CampaignOwnerEmployeeId,
               a.asset_name, a.owner_id, c.criticality_code
          FROM grac_practice.asset_activity_occurrence o
          JOIN grac_practice.asset_activity_template t ON t.template_code = o.template_code
          JOIN grac_practice.fn_asset_activity_settings(@organization_id) st ON st.TemplateCode = o.template_code
          JOIN grac_practice.organization_dependency_asset a ON a.asset_id = o.asset_id
          LEFT JOIN grac_practice.criticality_master c ON c.criticality_id = a.criticality_id
         WHERE o.organization_id = @organization_id AND o.status = N'OPEN' AND o.decision = N'ASSET_TASK' AND o.task_id IS NULL
         ORDER BY o.due_date, o.occurrence_id;
    OPEN task_cur;
    FETCH NEXT FROM task_cur INTO @occ, @asset, @tpl, @due, @key, @ver, @reason, @tpl_name, @owner_key, @grouping, @cmp_owner,
                                  @asset_name, @asset_owner, @crit;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            SELECT @assignee = NULL, @cmp = NULL, @cmp_key = NULL, @tid = NULL, @contract_text = NULL;
            -- Owner: the template owner field (a person), else the asset owner (D65).
            IF @owner_key IS NOT NULL
                SET @assignee = grac_practice.fn_asset_activity_person(@organization_id,
                    (SELECT LEFT(v.value_text, 100) FROM grac_practice.asset_field_value v
                       JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id AND f.field_key = @owner_key
                      WHERE v.asset_id = @asset));
            IF @assignee IS NULL
                SET @assignee = grac_practice.fn_asset_activity_person(@organization_id, CAST(@asset_owner AS NVARCHAR(30)));
            SET @prio = CASE @crit WHEN N'Critical' THEN N'Critical' WHEN N'High' THEN N'High' WHEN N'Low' THEN N'Low' ELSE N'Medium' END;
            IF @ver IS NOT NULL
                SELECT @contract_text = CONCAT(c.contract_number, N' version ', v.version_no, N' (', c.contract_name, N')')
                  FROM grac_practice.asset_contract_version v
                  JOIN grac_practice.asset_contract c ON c.contract_id = v.contract_id
                 WHERE v.version_id = @ver;

            IF @grouping = N'CAMPAIGN'
            BEGIN
                SET @period = CONVERT(CHAR(6), @due, 112);
                SET @cmp_key = CONCAT(N'AC-', @tpl, N'-', @period);
                SELECT @cmp = campaign_id FROM grac_practice.asset_activity_campaign
                 WHERE organization_id = @organization_id AND campaign_key = @cmp_key;
                IF @cmp IS NULL
                BEGIN
                    INSERT grac_practice.asset_activity_campaign
                        (organization_id, template_code, period_key, campaign_key, campaign_name, owner_employee_id, entered_by)
                    VALUES (@organization_id, @tpl, @period, @cmp_key,
                            CONCAT(@tpl_name, N' campaign ', LEFT(@period, 4), N'-', RIGHT(@period, 2)), @cmp_owner, @actor);
                    SET @cmp = SCOPE_IDENTITY();
                END
            END

            SET @title = LEFT(CONCAT(@tpl_name, N' - ', @asset_name, N' (due ', CONVERT(NVARCHAR(10), @due, 23), N')'), 250);
            SET @descr = CONCAT(@tpl_name, N' of ', @asset_name, N', due ', CONVERT(NVARCHAR(10), @due, 23), N'.', CHAR(13), CHAR(10),
                                N'Occurrence: ', @key, CHAR(13), CHAR(10),
                                CASE WHEN @cmp_key IS NULL THEN N'' ELSE CONCAT(N'Campaign: ', @cmp_key, CHAR(13), CHAR(10)) END,
                                CASE WHEN @contract_text IS NULL THEN N'' ELSE CONCAT(N'Contract: ', @contract_text, CHAR(13), CHAR(10)) END,
                                @reason);
            SET @ref = ISNULL(@cmp_key, @key);
            SET @target = CAST(@due AS DATETIME2);
            EXEC grac_practice.sp_task_open
                 @organization_id         = @organization_id,
                 @task_type_code          = N'AssetActivity',
                 @subject_entity_type     = N'AssetActivityOccurrence',
                 @subject_entity_id       = @occ,
                 @subject_title           = @title,
                 @subject_description     = @descr,
                 @priority                = @prio,
                 @criticality             = @crit,
                 @origin_code             = N'GRAC',
                 @assigned_to_employee_id = @assignee,
                 @target_date             = @target,
                 @source_type_code        = N'Asset',
                 @source_record_id        = @occ,
                 @source_reference        = @ref,
                 @resolve_owner           = 0,
                 @task_id                 = @tid OUTPUT;
            UPDATE grac_practice.asset_activity_occurrence
               SET task_id = @tid, campaign_id = @cmp, task_error = NULL, updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE occurrence_id = @occ;
            SET @tasks = @tasks + 1;
        END TRY
        BEGIN CATCH
            IF XACT_STATE() <> 0 ROLLBACK;
            SET @errors = @errors + 1;
            SET @error_text = LEFT(CONCAT(@error_text, CASE WHEN @error_text IS NULL THEN N'' ELSE CHAR(10) END,
                                          N'Activity occurrence ', @occ, N': ', ERROR_MESSAGE()), 4000);
            UPDATE grac_practice.asset_activity_occurrence
               SET task_error = LEFT(ERROR_MESSAGE(), 1000), updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE occurrence_id = @occ;
        END CATCH
        FETCH NEXT FROM task_cur INTO @occ, @asset, @tpl, @due, @key, @ver, @reason, @tpl_name, @owner_key, @grouping, @cmp_owner,
                                      @asset_name, @asset_owner, @crit;
    END
    CLOSE task_cur;
    DEALLOCATE task_cur;
END
GO
