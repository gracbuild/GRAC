# 450 UI patch: installs the Asset Governance screen; the Asset Register
# opens an asset from ?organizationId=&assetId= (governance drill-down).
import shutil, sys
W = "new/src/PracticeManagement.Web/"
shutil.copyfile("asset-governance.cshtml", W + "Views/Practice/Partials/asset-governance.cshtml")
shutil.copyfile("asset-governance.js", W + "wwwroot/js/AssetConfig/asset-governance.js")
def patch(path, pairs):
    p = W + path
    s = open(p, encoding="utf-8").read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1: sys.exit(f"{path}: expected 1 match, got {n}: {old[:70]!r}")
        s = s.replace(old, new)
    open(p, "w", encoding="utf-8", newline="").write(s)
patch("Views/Practice/Partials/asset-register.cshtml", [
("""    and reviews are acted on in Asset Privacy ("Open in Asset Privacy").
""", """    and reviews are acted on in Asset Privacy ("Open in Asset Privacy").

    450: opened with ?organizationId=&assetId= (Asset Governance KPI
    drill-down) the screen opens that asset.
"""),
])
patch("wwwroot/js/AssetConfig/asset-register.js", [
("""// screen with ?organizationId=&assetId=, where they are acted on.
""", """// screen with ?organizationId=&assetId=, where they are acted on.
// 450: opened with ?organizationId=&assetId= (Asset Governance drill-down)
// the asset is opened.
"""),
("""    const excParam = Number(params.get("discoveryException"));
    if (excParam > 0 && state.organizationId) await startFromDiscovery(excParam);
""", """    const excParam = Number(params.get("discoveryException"));
    if (excParam > 0 && state.organizationId) await startFromDiscovery(excParam);
    const assetParam = Number(params.get("assetId"));                     // 450
    if (!(excParam > 0) && assetParam > 0 && state.organizationId) await openAsset(assetParam);
"""),
])
print("pui450 ok")
