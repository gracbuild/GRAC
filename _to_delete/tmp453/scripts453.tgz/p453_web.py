import sys
R = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w453/new'
def edit(path, old, new, count=1):
    s = open(path).read(); assert s.count(old) == count, (path, old[:80], s.count(old)); open(path, 'w').write(s.replace(old, new))
W = R + '/src/PracticeManagement.Web/Controllers/AssetConfigController.cs'
edit(W, """//                                      X-PM-Caller-Report-Approve; a report is refused unless its screen is listed.
""", """//                                      X-PM-Caller-Report-Approve; a report is refused unless its screen is listed.
//                                      453: POST reports/schedules and reports/schedules/{id}/run EDIT;
//                                      POST reports/deliveries/recipients/{id}/download VIEW (only the recipient, in SQL)
""")
edit(W, """            : isReport && lower == "reports/settings"
            ? Can(area, "EDIT")
""", """            : isReport && lower == "reports/settings"
            ? Can(area, "EDIT")
            : isReport && lower.StartsWith("reports/deliveries/recipients/") && lower.EndsWith("/download")   // 453: recipient in SQL
            ? Can(area, "VIEW")
            : isReport && (lower == "reports/schedules" || (lower.StartsWith("reports/schedules/") && lower.EndsWith("/run")))   // 453
            ? Can(area, "EDIT")
""")
print('web patched')
