import sys
R = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w453/new'
P = R + '/docs/asset-contract-management.md'
def edit(old, new, count=1):
    s = open(P).read(); assert s.count(old) == count, (old[:80], s.count(old)); open(P, 'w').write(s.replace(old, new))

edit("""| 8.5b | Scheduled delivery, distribution lists and report retention (13.4 schedule / retention / distribution, 13.4.1 delivery-time recipient checks and distribution results) on the existing background worker | | 8.5a |
""", """| 8.5b **(done)** | Scheduled delivery (13.4 schedule / retention / distribution, 13.4.1): report schedules with fixed filters (date window of the last N days), daily / weekly / monthly, distribution lists of employees and roles, every recipient checked at delivery time and given the rows of their own permissions and View Data Scope, distribution results per recipient, delivered files kept for the schedule retention, My deliveries with a download recorded as an export; delivery pass on TaskNotificationWorker and Run now | 453 | 8.5a |
""")

edit("""| D141 | **Not in 8.1**:""", """| D211 | **Delivery is in the application** (Asset Reports -> My deliveries): the codebase has no e-mail / Teams dispatcher for asset notifications (437 D57), so a delivered report is a file kept for its recipient, downloaded from the screen. A dispatcher can later send a link to it. | 437 D57. | Yes. |
| D212 | **The rows are produced in the API, per recipient**: `sp_asset_report_delivery_start` starts the deliveries and checks the recipients; `AssetConfigService` then runs the report for each recipient through `sp_asset_report_run` with that recipient report screens, APPROVE flag and View Data Scope (415, `CallerViewScope`), and stores the columns and rows (`sp_asset_report_delivery_store`). One recipient failing does not stop the others. | 13.4.1 "same authorization ... as screens"; a recipient must never receive rows their own screen would hide. | Yes. |
| D213 | **Recipient check at delivery time** (13.4.1): an active employee who may act on the organization (the sign-in rule: employee organization or `user_organization_map`), VIEW on Asset Reports and on the report screen from the employee roles (the sign-in permission rule: primary role plus assigned roles), report available and enabled, export policy (Approver needs Asset Reports APPROVE; Disabled delivers to nobody). A recipient who fails is SKIPPED with the reason; the reason is part of the distribution result. Configuration roles (PM_ADMIN and the bootstrap sign-in) have no employee and cannot be recipients. | 13.4.1. | Yes. |
| D214 | **Distribution list**: named employees of the organization and organization roles; a role means every active holder (primary or assigned role) at delivery time. An employee reached twice receives one file. | 13.4 "distribution rules". | Yes. |
| D215 | **Schedule**: one report, filters fixed when saved (only the filters the report takes; the status must be one of its options), date-range reports take a window of the last N days up to the run date, frequency Daily / Weekly on a weekday / Monthly on day 1-28 (present in every month), active flag, retention 1-3650 days (default 90). The report of a schedule is fixed; the next run date is computed when created, when the frequency or day changes, on reactivation and after each scheduled run. | -- | Yes. |
| D216 | **Once per day**: the worker pass (`TaskNotification:AssetReportDeliveryEnabled`, every `AssetReportDeliveryIntervalMinutes`, default 60) starts every active schedule whose next run date has come; a unique index allows one scheduled delivery per schedule and day, so a second pass or API instance starts nothing. Run now (EDIT) starts an extra delivery and leaves the next run date as it is. There is no SQL Agent equivalent (the rows are produced in the API). | Standing decision: the existing background worker. | Yes. |
| D217 | **Retention**: a delivered file is kept for the retention of its schedule (copied to the delivery when it starts); the next pass removes the columns and rows and stamps the removal; the delivery and the distribution result stay. Recipients left pending for 6 hours (pass stopped) fail as interrupted. | 13.4 "retention"; 13.4.1 "expiry". | Yes. |
| D218 | **Download**: only the recipient; checked again at download (file kept, report screen still viewable, report enabled, export policy now) -- 53129 otherwise; recorded in the 452 export log with the delivery reference (`asset_report_export.delivery_recipient_id`); the file has the 452 watermark heading plus the generation time. | 13.4.1 "exports shall record ...". | Yes. |
| D219 | **Interactive export now applies the caller View Data Scope** (8.5a correction): an export is a POST and only GET reads were given the caller scope by `CallerViewScope.BeginForRequest`; `ExportReportAsync` now applies it, so the file holds exactly the rows of the grid. | 13.4.1. | Yes. |
| D220 | **Permissions**: schedules and their deliveries are listed for the reports whose screen the caller may view (Asset Reports VIEW); creating, changing and Run now need Asset Reports EDIT and VIEW on the report screen (53123). My deliveries needs Asset Reports VIEW; the procedures limit it to the caller employee. | 452 D198. | Yes. |
| D221 | **Audit**: schedule changes in `practice_audit_trace` (`asset-report-schedule`, before / after with the distribution list); a schedule whose delivery cannot start is recorded as DELIVERY_ERROR and retried on the next pass; deliveries and per-recipient results are kept (never updated after completion except the retention removal and download counts). | 14 "immutable audit history". | Yes. |
| D222 | **Size**: a delivered file has at most 50000 rows (the export limit); a larger result fails for that recipient with the reason (narrow the schedule filters). | 452 D200. | Yes. |
| D223 | **Screen**: Asset Reports gets two tabs -- My deliveries and Schedules (list, New / Edit form with the distribution list, Run now, Deliveries with the distribution result per recipient). The status-option and CSV code of 8.5a is shared by the report filter, the export, the schedule form and the download. | No redesign. | Yes. |
| D224 | **Error numbers 53120-53129**. Not in 8.5b: e-mail / Teams delivery and notification of a new file (no dispatcher); encrypted files; per-recipient filters; schedules run by SQL Agent alone. | -- | Yes. |
| D141 | **Not in 8.1**:""")

edit("""Family procedures: `sp_asset_report_asset`, `_attestation`, `_cmdb`, `_discovery`, `_contract`, `_technology`, `_risk`, `_governance`, `_privacy` (called by `sp_asset_report_run` only).""",
"""| GET | `reports/schedules?organizationId=` | `{schedules, recipients, employees, roles}` -- schedules of the reports the caller may view with frequency, filters, next run, last delivery and recipients (453) | `sp_asset_report_schedules` |
| POST | `reports/schedules` | `{organizationId, scheduleId?, reportCode, scheduleName, search?, status?, assetTypeId?, days?, dateWindowDays?, frequency: DAILY \\| WEEKLY \\| MONTHLY, dayOfWeek?, dayOfMonth?, retentionDays, isActive, recipients: [{kind: EMPLOYEE \\| ROLE, id}], expectedRecordVersion?}` -> CREATED / SAVED | `sp_asset_report_schedule_save` |
| POST | `reports/schedules/{id}/run` | `{organizationId}` -> `{deliveries, delivered, failed, skipped}` -- deliver now | `sp_asset_report_delivery_start`, `sp_asset_report_run` (per recipient), `sp_asset_report_delivery_store` |
| GET | `reports/deliveries?organizationId=&scheduleId=&pageNumber=&pageSize=` | deliveries with status and counts | `sp_asset_report_deliveries` |
| GET | `reports/deliveries/{id}/recipients?organizationId=` | per recipient: status, reason, rows, delivered, downloads, removed | `sp_asset_report_delivery_recipients` |
| GET | `reports/deliveries/mine?organizationId=&pageNumber=&pageSize=` | the caller delivered files (available until, downloads) | `sp_asset_report_my_deliveries` |
| POST | `reports/deliveries/recipients/{id}/download` | `{organizationId}` -> `{export, columns, rows}` (recorded as an export) | `sp_asset_report_delivery_download` |

Family procedures: `sp_asset_report_asset`, `_attestation`, `_cmdb`, `_discovery`, `_contract`, `_technology`, `_risk`, `_governance`, `_privacy` (called by `sp_asset_report_run` only).""")
edit("""Errors `53100-53110`: 53100 / 53101 -> 404; 53103 / 53105 -> 403; 53102 / 53104 -> 409; others -> 400.""",
"""Errors `53100-53110`: 53100 / 53101 -> 404; 53103 / 53105 -> 403; 53102 / 53104 -> 409; others -> 400. 453: proxy POST reports/schedules and .../run asset-reports EDIT, download VIEW; the scheduled pass runs in `TaskNotificationWorker` (`AssetReportDeliveryEnabled`, `AssetReportDeliveryIntervalMinutes`); errors `53120-53129`: 53120 / 53121 / 53126 -> 404 (schedule save: also 53122); 53123 / 53129 -> 403; 53127 / 53128 -> 409; others -> 400.""")

edit("""### Phase 8.5a files (452)
""", """### Phase 8.5b files (453)
| Layer | File | Change |
|---|---|---|
| DB | `database/453_asset_report_schedules.sql` (+ rollback) | Schedules, distribution lists, deliveries and per-recipient results with the delivered files; `asset_report_export.delivery_recipient_id`; next-run, employee-access and employee-in-organization functions; schedule, delivery start / store / finish, readers and download procedures. |
| API | `Controllers/AssetConfigController.cs`, `Services/AssetConfigService.cs`, `Models/AssetConfigModels.cs` | `reports/schedules...`, `reports/deliveries...` routes; per-recipient delivery under the recipient permissions and View Data Scope; download; interactive export applies the caller View Data Scope (D219). |
| API | `Services/TaskNotificationWorker.cs`, `appsettings.json` | Fourth pass: asset report deliveries (`AssetReportDeliveryEnabled`, `AssetReportDeliveryIntervalMinutes`). |
| Web | `Controllers/AssetConfigController.cs` | POST rules for schedules, Run now and download. |
| Web | `Views/Practice/Partials/asset-reports.cshtml`, `js/AssetConfig/asset-reports.js` | My deliveries and Schedules tabs; shared status options and CSV writer. |

### Phase 8.5a files (452)
""")

s = open(P).read()
tail = "Not compiled or executed. Next: 8.5b (scheduled delivery, distribution and retention).\n"
assert s.endswith(tail)
s += """
453 got the same sweep (clean), the semicolon-before-ELSE scan (one found in the delivery start and wrapped in BEGIN / END before delivery), the comment-apostrophe scan, a declared-variable scan, a review of the counting rules (a delivery with no recipient counts zero, not NULL; a table variable fed by OUTPUT has no key, since one delivery has several recipients), a check that the API parameter names and sizes match the procedures, that every column the API reads from the delivery work set exists, that every element id the script uses exists in the partial, brace / parenthesis / bracket balance of the edited C# files, `node --check` of the script, JSON parse of appsettings, the ASCII check and a re-run of the patch scripts on the base files reproducing the delivered copies. Its verification block checks the objects and the next-run arithmetic (daily, weekly, monthly from a known Tuesday). Not compiled or executed. Next: Phase 9 (regression, permission, workflow and reconciliation testing).
"""
open(P, 'w').write(s)
print('doc patched')
