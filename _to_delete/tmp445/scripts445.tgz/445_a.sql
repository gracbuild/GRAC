-- =====================================================================
-- 445  Asset split: source and resulting records, allocation of current
--      relationships, source records, open items, coverage, risk and
--      practice mappings and field values, impact, validation, approval
--      (two-person for critical CIs), execution with per-object outcomes,
--      recovery (Asset & Contract Management, Phase 7 increment 4c)
--
-- REQUEST
-- -------
--   BRD v1.7 5.6.3 Split -- "create controlled records and redistribute
--   observations / relationships with approval". 19.4 split control:
--   initiation (source and proposed resulting records), preview (proposed
--   allocation of data, evidence, history and relationships), impact
--   analysis (same domains for each resulting record), validation (each
--   result meets identity and mandatory rules), approval (configured
--   approver; two-person control for critical CIs), execution (controlled
--   redistribution with per-object outcomes), recovery (controlled
--   recombine / correction event), audit (before / after IDs, allocation,
--   actor, reason, approval). Plan: docs/asset-contract-management.md
--   (Phase 7.4c, D125-D131).
--
-- WHAT THIS DOES
-- --------------
--   1. Split events reuse the 444 event tables (kind SPLIT; the source is
--      the survivor_asset_id of the event, the resulting records are members
--      with role RESULT) and add asset_split_allocation: which object goes
--      to which resulting record (field values: move or copy).
--   2. Resulting records are Draft assets registered on the Asset Register
--      form first, so each one has passed the identity and mandatory
--      rules; the source keeps its ID and whatever is not allocated.
--   3. fn_asset_split_plan: every object of the source (the 444 merge plan
--      read for the source) with its allocation and what moving it to that
--      resulting record would do now (MOVE, BLOCK, or STAY when the result
--      already holds the equivalent); fn_asset_split_blockers.
--   4. sp_asset_merge_split_move: the object moves of 444 taken out of
--      sp_asset_merge_execute_one unchanged so merge and split share them;
--      sp_asset_merge_execute_one is re-issued to call it.
--   5. sp_asset_split_save / sp_asset_split_execute / readers; the 444
--      action procedure is re-issued for both kinds (same approval rules),
--      the 444 list takes the kind, and recovery restores values a split
--      cleared on the source.
--
-- NOT DONE HERE: allocation of history rows (lifecycle, custody,
--   attestations, results, renewals, notifications stay with the source);
--   creating the resulting records inside the split; bulk splits.
--
-- ERROR NUMBERS: 52900-52914 (444) and 52915-52919
--   52915 1-5 resulting records          52916 result must be a new Draft
--   52917 allocation invalid             (52900-52914 as in 444)
--
-- ALSO EDITED: sp_asset_merge_execute_one, sp_asset_merge_action,
--   sp_asset_merge_recover, sp_asset_merge_events (444) re-issued; API
--   (AssetConfig service / controller / models), Web proxy,
--   asset-discovery.cshtml / .js (Splits tab), docs.
-- DEPENDS ON: 444.
-- Rollback: 445_asset_split_rollback.sql (restores the four 444 bodies).
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.asset_merge_split_event','U') IS NULL
   OR OBJECT_ID('grac_practice.asset_merge_split_object','U') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_merge_plan') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_merge_critical') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_merge_impact') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_merge_execute_one','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_merge_action','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_merge_recover','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_asset_merge_events','P') IS NULL
   OR COL_LENGTH('grac_practice.organization_dependency_asset','merged_into_asset_id') IS NULL
BEGIN
    RAISERROR('ABORT (445): run 444 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Allocation of the source objects to the resulting records
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_split_allocation','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_split_allocation (
        allocation_id   BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_asplit_alloc PRIMARY KEY,
        event_id        BIGINT        NOT NULL CONSTRAINT fk_pm_asplit_alloc_event REFERENCES grac_practice.asset_merge_split_event(event_id),
        object_kind     NVARCHAR(20)  NOT NULL,
        object_id       BIGINT        NULL,
        object_key      NVARCHAR(200) NULL,
        target_asset_id BIGINT        NOT NULL
            CONSTRAINT fk_pm_asplit_alloc_target REFERENCES grac_practice.organization_dependency_asset(asset_id),
        field_mode      NVARCHAR(4)   NULL
            CONSTRAINT ck_pm_asplit_alloc_mode CHECK (field_mode IS NULL OR field_mode IN (N'MOVE', N'COPY'))
    );
    CREATE UNIQUE INDEX ux_pm_asplit_alloc ON grac_practice.asset_split_allocation(event_id, object_kind, object_id, object_key);
    PRINT '445: asset_split_allocation created.';
END
GO
