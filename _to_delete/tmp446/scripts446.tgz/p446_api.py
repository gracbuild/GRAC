import sys
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w446/new'
A=R+'/src/PracticeManagement.Api/'
def edit(path, old, new, count=1):
    s=open(path).read()
    assert s.count(old)==count, (path, old[:80], s.count(old))
    s=s.replace(old,new); open(path,'w').write(s)

# ---------------- models
edit(A+'Models/AssetConfigModels.cs', """    List<AssetSplitAllocationItem>? Allocations,
    long?                           ExpectedRecordVersion);
""", """    List<AssetSplitAllocationItem>? Allocations,
    long?                           ExpectedRecordVersion);

// ---------------------------------------------------------------------
// Asset Value per asset (migration 446)
// ---------------------------------------------------------------------
/// <summary>Recalculate one asset now. Reason required when the asset moves to a newer configuration version.</summary>
public sealed record AssetValuationRecalculateRequest(long OrganizationId, string? Reason);

/// <summary>Asset-level valuation method override: MAXIMUM | WEIGHTED_AVERAGE | SUMMATION, or null / the configured
/// method to remove it. Reason required.</summary>
public sealed record AssetValuationMethodRequest(long OrganizationId, string? Method, string? Reason);

/// <summary>Controlled recalculation run. ExpectedAffected is the affected-asset count the preview showed.</summary>
public sealed record AssetValuationRecalcRunRequest(long OrganizationId, string? Reason, int? ExpectedAffected);
""")

# ---------------- service interface
edit(A+'Services/AssetConfigService.cs', """    Task<AssetLifecycleResult> SaveSplitAsync(AssetSplitSaveRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
}
""", """    Task<AssetLifecycleResult> SaveSplitAsync(AssetSplitSaveRequest request, long? actorEmployeeId, string actor, CancellationToken ct);

    // 446 -- Asset Value per asset
    Task<object?> GetAssetValuationAsync(long organizationId, long assetId, CancellationToken ct);
    Task<AssetLifecycleResult> RecalculateAssetValuationAsync(long assetId, AssetValuationRecalculateRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<AssetLifecycleResult> SetAssetValuationMethodAsync(long assetId, AssetValuationMethodRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
    Task<object> GetValuationRecalcPreviewAsync(long organizationId, CancellationToken ct);
    Task<AssetLifecycleResult> RunValuationRecalcAsync(AssetValuationRecalcRunRequest request, long? actorEmployeeId, string actor, CancellationToken ct);
}
""")

# ---------------- service implementation (after MergeActionAsync)
edit(A+'Services/AssetConfigService.cs', """            AddParam(command, "@action",                  DbType.String, Blank(request.Action), 10);
            AddParam(command, "@note",                    DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    public async Task<object> GetBusinessServiceTreeAsync(""", """            AddParam(command, "@action",                  DbType.String, Blank(request.Action), 10);
            AddParam(command, "@note",                    DbType.String, Blank(request.Note), 1000);
            AddParam(command, "@expected_record_version", DbType.Int64,  request.ExpectedRecordVersion);
            AddParam(command, "@actor_employee_id",       DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",                   DbType.String, actor, 100);
        }, ct);

    // ----------------------------------------------------------------
    // 446 -- Asset Value per asset
    // ----------------------------------------------------------------
    public async Task<object?> GetAssetValuationAsync(long organizationId, long assetId, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_valuation_get");
            AddParam(command, "@organization_id", DbType.Int64, organizationId);
            AddParam(command, "@asset_id",        DbType.Int64, assetId);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var current = await ReadRowsAsync(reader, ct);
            var history = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
            return new { current = current.Count > 0 ? current[0] : null, history };
        }
        catch (SqlException ex) when (ex.Number == 53000) { return null; }
    }

    public Task<AssetLifecycleResult> RecalculateAssetValuationAsync(long assetId, AssetValuationRecalculateRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_valuation_recalculate", "assetId", command =>
        {
            AddParam(command, "@organization_id",   DbType.Int64,  request.OrganizationId);
            AddParam(command, "@asset_id",          DbType.Int64,  assetId);
            AddParam(command, "@reason_text",       DbType.String, Blank(request.Reason), 1000);
            AddParam(command, "@actor_employee_id", DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",             DbType.String, actor, 100);
        }, ct);

    public Task<AssetLifecycleResult> SetAssetValuationMethodAsync(long assetId, AssetValuationMethodRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_valuation_method_set", "assetId", command =>
        {
            AddParam(command, "@organization_id",   DbType.Int64,  request.OrganizationId);
            AddParam(command, "@asset_id",          DbType.Int64,  assetId);
            AddParam(command, "@method",            DbType.String, Blank(request.Method), 30);
            AddParam(command, "@reason_text",       DbType.String, Blank(request.Reason), 1000);
            AddParam(command, "@actor_employee_id", DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",             DbType.String, actor, 100);
        }, ct);

    public async Task<object> GetValuationRecalcPreviewAsync(long organizationId, CancellationToken ct)
    {
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_valuation_recalc_preview");
        command.CommandTimeout = 120;   // evaluates every asset of the organization
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var empty = new List<Dictionary<string, object?>>();
        var summary = await ReadRowsAsync(reader, ct);
        var moves   = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var assets  = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        var runs    = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
        return new { summary = summary.Count > 0 ? summary[0] : null, moves, assets, runs };
    }

    public Task<AssetLifecycleResult> RunValuationRecalcAsync(AssetValuationRecalcRunRequest request, long? actorEmployeeId, string actor, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_valuation_recalc_run", "runId", command =>
        {
            command.CommandTimeout = 600;   // one calculation per affected asset
            AddParam(command, "@organization_id",   DbType.Int64,  request.OrganizationId);
            AddParam(command, "@reason_text",       DbType.String, Blank(request.Reason), 1000);
            AddParam(command, "@expected_affected", DbType.Int32,  request.ExpectedAffected);
            AddParam(command, "@actor_employee_id", DbType.Int64,  actorEmployeeId);
            AddParam(command, "@actor",             DbType.String, actor, 100);
        }, ct);

    public async Task<object> GetBusinessServiceTreeAsync(""")

# ---------------- controller: route docs
C=A+'Controllers/AssetConfigController.cs'
edit(C, """//   POST discovery/splits/{id}/action                as merges (same procedure)
//
""", """//   POST discovery/splits/{id}/action                as merges (same procedure)
//   GET  register/{id}/valuation?organizationId=     Asset Value: current, state vs the Active configuration, history (446)
//   POST register/{id}/valuation/recalculate         recalculate one asset now (reason when the configuration changed)
//   POST register/{id}/valuation/method              asset-level method override (method or null, reason)
//   GET  valuation/recalculation?organizationId=     impact analysis: summary, category moves, affected assets, runs
//   POST valuation/recalculation                     controlled recalculation run (reason, expectedAffected)
//
""")
edit(C, """        return ResultWritten(await service.MergeActionAsync(eventId, request, ActorEmployeeId, Actor, ct), MergeNotFound, MergeConflict);
    }

    // 441: 54730""", """        return ResultWritten(await service.MergeActionAsync(eventId, request, ActorEmployeeId, Actor, ct), MergeNotFound, MergeConflict);
    }

    // ---------------------------------------------------------------- 446: Asset Value per asset
    [HttpGet("register/{assetId:long}/valuation")]
    public Task<IActionResult> AssetValuation(long assetId, [FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetAssetValuationAsync(o, assetId, ct), "Asset not found.", "asset valuation");

    [HttpPost("register/{assetId:long}/valuation/recalculate")]
    public async Task<IActionResult> RecalculateAssetValuation(long assetId, [FromBody] AssetValuationRecalculateRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.RecalculateAssetValuationAsync(assetId, request, ActorEmployeeId, Actor, ct), ValuationNotFound, ValuationConflict);
    }

    [HttpPost("register/{assetId:long}/valuation/method")]
    public async Task<IActionResult> SetAssetValuationMethod(long assetId, [FromBody] AssetValuationMethodRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SetAssetValuationMethodAsync(assetId, request, ActorEmployeeId, Actor, ct), ValuationNotFound, ValuationConflict);
    }

    [HttpGet("valuation/recalculation")]
    public Task<IActionResult> ValuationRecalcPreview([FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.GetValuationRecalcPreviewAsync(organizationId.Value, ct), "valuation recalculation preview");
    }

    [HttpPost("valuation/recalculation")]
    public async Task<IActionResult> RunValuationRecalc([FromBody] AssetValuationRecalcRunRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.RunValuationRecalcAsync(request, ActorEmployeeId, Actor, ct), ValuationNotFound, ValuationConflict);
    }

    // 446: 53000 (asset), 53007 (organization) -> 404; 53005 (affected assets changed since the preview),
    //      53006 (a run is in progress) -> 409; others (no Active configuration, override not enabled, reason) -> 400.
    private static readonly int[] ValuationNotFound = { 53000, 53007 };
    private static readonly int[] ValuationConflict = { 53005, 53006 };

    // 441: 54730""")
print('api patched')
