B='/home/claude/b439/new_'
def g(n): return open(B+n+'.sql').read()
b = """
-- =====================================================================
-- 7. Re-issued 438 bodies (439 lines marked; the rest is verbatim)
-- =====================================================================
-- 438 body + the result / disposition / restriction settings.
""" + g('fn_asset_activity_settings') + """
-- 438 body + result activities completed by their approved result (D71).
""" + g('sp_asset_activity_task_sync') + """
-- 438 body + revised due dates, waivers (review date) and failed results
-- (re-test) (D72, D74).
""" + g('sp_asset_activity_schedule_sync') + """PRINT '439: settings, task sync and schedule sync re-issued.';
GO
"""
c = "\n" + open('/home/claude/439_rs.sql').read() + """
-- 438 body + re-test occurrences and waived due dates (D72, D74).
""" + g('sp_asset_activity_generate') + """
-- 438 body + the restrictive-use review step.
""" + g('sp_asset_activity_run') + """PRINT '439: generate and run re-issued.';
GO
"""
d = """
-- =====================================================================
-- 9. Re-issued notification / register bodies (439 lines marked)
-- =====================================================================
-- 438 body + the Failed calibration status (5.1.7).
""" + g('fn_asset_stored_values') + """PRINT '439: fn_asset_stored_values re-issued.';
GO

-- 438 body + the ASSET_EVIDENCE branch.
""" + g('sp_asset_notification_parties') + """PRINT '439: sp_asset_notification_parties re-issued.';
GO

-- 438 body + revised due dates, re-test severity and the evidence source.
""" + g('sp_asset_notification_sweep') + """PRINT '439: sp_asset_notification_sweep re-issued.';
GO
"""
e0 = """
-- =====================================================================
-- 9b. Re-issued 438 readers / writers (439 lines marked)
-- =====================================================================
-- 438 body + the 439 settings and the evidence catalogue.
""" + g('sp_asset_activity_config_get') + """
-- 438 body + the 439 settings.
""" + g('sp_asset_activity_setting_save') + """
-- 438 body + revised due date, Failed first.
""" + g('sp_asset_activity_schedules') + """
-- 438 body + result / disposition columns and the awaiting-decision filter.
""" + g('sp_asset_activity_occurrences') + """PRINT '439: 438 readers / writers re-issued.';
GO

"""
full = open('/home/claude/439_a.sql').read() + b + c + d + e0 + open('/home/claude/439_e.sql').read() + "\n" + open('/home/claude/439_f.sql').read()
assert all(ord(ch) < 128 for ch in full)
open('/home/claude/439.sql','w',newline='').write(full)
print('439.sql', full.count('\n'))
