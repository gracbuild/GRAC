CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationship_action
    @organization_id         BIGINT,
    @relationship_id         BIGINT,
    @action                  NVARCHAR(20),
    @note                    NVARCHAR(1000) = NULL,
    @expected_record_version BIGINT         = NULL,
    @actor_employee_id       BIGINT         = NULL,
    @actor                   NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @action = UPPER(LTRIM(RTRIM(ISNULL(@action, N''))));
    SET @note = NULLIF(LTRIM(RTRIM(@note)), N'');
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    DECLARE @found BIT = 0, @status NVARCHAR(10), @rv BIGINT, @critical BIT, @pending NVARCHAR(10), @pending_json NVARCHAR(MAX),
            @pending_by NVARCHAR(100), @pending_emp BIGINT, @pending_reason NVARCHAR(1000), @proposed_by NVARCHAR(100),
            @proposed_emp BIGINT, @type NVARCHAR(30), @sk NVARCHAR(12), @si BIGINT, @tk NVARCHAR(12), @ti BIGINT;
    SELECT @found = 1, @status = status, @rv = CONVERT(BIGINT, record_version), @critical = is_critical, @pending = pending_action,
           @pending_json = pending_json, @pending_by = pending_by, @pending_emp = pending_by_employee_id,
           @pending_reason = pending_reason, @proposed_by = proposed_by, @proposed_emp = proposed_by_employee_id,
           @type = relationship_type_code, @sk = source_kind, @si = source_id, @tk = target_kind, @ti = target_id
      FROM grac_practice.asset_relationship WHERE relationship_id = @relationship_id AND organization_id = @organization_id;
    IF @found = 0 THROW 54709, 'Relationship not found for this organization.', 1;
    IF @action NOT IN (N'APPROVE', N'REJECT', N'WITHDRAW', N'DISPUTE', N'CONFIRM', N'RETIRE', N'ACCEPT_RETIREMENT')
        THROW 54715, 'The action is Approve, Reject, Withdraw, Dispute, Confirm, Retire or Accept for retirement.', 1;
    IF @expected_record_version IS NOT NULL AND @expected_record_version <> @rv
        THROW 54710, 'The relationship was changed by someone else; reload it and try again.', 1;
    IF @action IN (N'REJECT', N'DISPUTE', N'CONFIRM', N'RETIRE', N'ACCEPT_RETIREMENT') AND @note IS NULL
        THROW 54713, 'Enter the note for this action.', 1;

    DECLARE @result NVARCHAR(20), @loop BIT, @hist NVARCHAR(20) = @action;
    BEGIN TRAN;
    IF @action = N'APPROVE' AND @status = N'PROPOSED'
    BEGIN
        IF @critical = 1 AND (@proposed_by = @actor OR (@proposed_emp IS NOT NULL AND @proposed_emp = @actor_employee_id))
            THROW 54716, 'Segregation of duties: the person who proposed a critical relationship cannot approve it.', 1;
        EXEC grac_practice.sp_asset_relationship_check @organization_id = @organization_id, @relationship_id = @relationship_id,
             @type_code = @type, @source_kind = @sk, @source_id = @si, @target_kind = @tk, @target_id = @ti, @out_loop = @loop OUTPUT;
        UPDATE grac_practice.asset_relationship
           SET status = N'ACTIVE', verification_status = N'VERIFIED', in_loop = ISNULL(@loop, 0), approved_by = @actor,
               approved_by_employee_id = @actor_employee_id, approved_dt = SYSUTCDATETIME(), status_note = @note,
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
        SET @result = N'ACTIVE';
    END
    ELSE IF @action = N'APPROVE' AND @pending IS NOT NULL
    BEGIN
        IF @pending_by = @actor OR (@pending_emp IS NOT NULL AND @pending_emp = @actor_employee_id)
            THROW 54716, 'Segregation of duties: the person who requested the change cannot approve it.', 1;
        IF @pending = N'UPDATE'
        BEGIN
            UPDATE r
               SET is_critical = ISNULL(j.isCritical, 0), dependency_criticality = j.dependencyCriticality, impact_weight = j.impactWeight,
                   effective_from = j.effectiveFrom, effective_to = j.effectiveTo, confidence_pct = j.confidencePct,
                   owner_employee_id = j.ownerEmployeeId, verifier_employee_id = j.verifierEmployeeId,
                   evidence_reference = j.evidenceReference, change_reference = j.changeReference, reason = j.reason,
                   service_role = j.serviceRole,                                                      -- 441
                   version_no = version_no + 1
              FROM grac_practice.asset_relationship r
             CROSS APPLY OPENJSON(@pending_json) WITH (
                    isCritical BIT, dependencyCriticality NVARCHAR(10), impactWeight DECIMAL(5, 2), effectiveFrom DATE,
                    effectiveTo DATE, confidencePct INT, ownerEmployeeId BIGINT, verifierEmployeeId BIGINT,
                    evidenceReference NVARCHAR(400), changeReference NVARCHAR(200), reason NVARCHAR(1000),
                    serviceRole NVARCHAR(100)) j                                                      -- 441
             WHERE r.relationship_id = @relationship_id;
            SET @result = N'UPDATED';
            SET @hist = N'APPROVE_CHANGE';
        END
        ELSE
        BEGIN
            UPDATE grac_practice.asset_relationship
               SET status = N'RETIRED', status_note = @pending_reason, version_no = version_no + 1,
                   effective_to = CASE WHEN effective_to IS NULL OR effective_to > @today THEN
                                           CASE WHEN effective_from > @today THEN effective_from ELSE @today END
                                       ELSE effective_to END
             WHERE relationship_id = @relationship_id;
            SET @result = N'RETIRED';
            SET @hist = N'APPROVE_RETIRE';
        END
        UPDATE grac_practice.asset_relationship
           SET pending_action = NULL, pending_json = NULL, pending_reason = NULL, pending_by = NULL, pending_by_employee_id = NULL,
               pending_dt = NULL, approved_by = @actor, approved_by_employee_id = @actor_employee_id, approved_dt = SYSUTCDATETIME(),
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
    END
    ELSE IF @action IN (N'REJECT', N'WITHDRAW') AND (@status = N'PROPOSED' OR @pending IS NOT NULL)
    BEGIN
        IF @action = N'WITHDRAW'
           AND ((@pending IS NOT NULL AND ISNULL(@pending_by, N'') <> @actor)
                OR (@pending IS NULL AND @proposed_by <> @actor))
            THROW 54716, 'Only the person who proposed the relationship or requested the change can withdraw it.', 1;
        IF @pending IS NOT NULL
        BEGIN
            UPDATE grac_practice.asset_relationship
               SET pending_action = NULL, pending_json = NULL, pending_reason = NULL, pending_by = NULL, pending_by_employee_id = NULL,
                   pending_dt = NULL, status_note = ISNULL(@note, N'Withdrawn by the requester.'),
                   updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE relationship_id = @relationship_id;
            SET @result = @status;
            SET @hist = CONCAT(@action, N'_CHANGE');
        END
        ELSE
        BEGIN
            UPDATE grac_practice.asset_relationship
               SET status = N'RETIRED', status_note = ISNULL(@note, N'Withdrawn by the proposer.'), version_no = version_no + 1,
                   updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE relationship_id = @relationship_id;
            SET @result = N'RETIRED';
        END
    END
    ELSE IF @action = N'DISPUTE' AND @status = N'ACTIVE' AND @pending IS NULL
    BEGIN
        UPDATE grac_practice.asset_relationship
           SET status = N'DISPUTED', status_note = @note, version_no = version_no + 1, updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
        SET @result = N'DISPUTED';
    END
    ELSE IF @action = N'CONFIRM' AND @status = N'DISPUTED'
    BEGIN
        UPDATE grac_practice.asset_relationship
           SET status = N'ACTIVE', verification_status = N'VERIFIED', status_note = @note, version_no = version_no + 1,
               approved_by = @actor, approved_by_employee_id = @actor_employee_id, approved_dt = SYSUTCDATETIME(),
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
        SET @result = N'ACTIVE';
    END
    ELSE IF @action = N'RETIRE' AND @status IN (N'ACTIVE', N'DISPUTED', N'INACTIVE') AND @pending IS NULL
    BEGIN
        IF @status = N'ACTIVE' AND @critical = 1
        BEGIN
            UPDATE grac_practice.asset_relationship
               SET pending_action = N'RETIRE', pending_json = NULL, pending_reason = @note, pending_by = @actor,
                   pending_by_employee_id = @actor_employee_id, pending_dt = SYSUTCDATETIME(),
                   updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE relationship_id = @relationship_id;
            SET @result = N'PENDING_APPROVAL';
            SET @hist = N'RETIRE_REQUEST';
        END
        ELSE
        BEGIN
            UPDATE grac_practice.asset_relationship
               SET status = N'RETIRED', status_note = @note, version_no = version_no + 1,
                   effective_to = CASE WHEN effective_to IS NULL OR effective_to > @today THEN
                                           CASE WHEN effective_from > @today THEN effective_from ELSE @today END
                                       ELSE effective_to END,
                   updated_by = @actor, updated_dt = SYSUTCDATETIME()
             WHERE relationship_id = @relationship_id;
            SET @result = N'RETIRED';
        END
    END
    ELSE IF @action = N'ACCEPT_RETIREMENT' AND @status = N'ACTIVE' AND @critical = 1
    BEGIN
        UPDATE grac_practice.asset_relationship
           SET retirement_accepted = 1, retirement_note = @note, retirement_accepted_by = @actor,
               retirement_accepted_dt = SYSUTCDATETIME(), updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE relationship_id = @relationship_id;
        SET @result = N'ACCEPTED';
    END
    ELSE
        THROW 54715, 'This action is not available for the relationship in its current status.', 1;

    EXEC grac_practice.sp_asset_relationship_history_add @relationship_id = @relationship_id, @action_code = @hist, @note = @note,
         @actor = @actor, @actor_employee_id = @actor_employee_id;
    COMMIT;
    SELECT @relationship_id AS RelationshipId, @result AS Result;
END
GO
