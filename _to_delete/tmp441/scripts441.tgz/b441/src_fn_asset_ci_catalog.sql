CREATE OR ALTER FUNCTION grac_practice.fn_asset_ci_catalog (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT N'ASSET' AS CiKind, a.asset_id AS CiId, CAST(a.asset_name AS NVARCHAR(400)) AS CiName,
           CAST(ISNULL(ty.asset_type_name, N'Asset') AS NVARCHAR(200)) AS CiClass,
           CAST(ISNULL(s.status_name, N'Active') AS NVARCHAR(120)) AS CiStatus,
           CAST(CASE WHEN ISNULL(s.status_code, N'ACTIVE') IN (N'DISPOSED', N'ARCHIVED') THEN 0 ELSE 1 END AS BIT) AS IsUsable,
           a.owner_id AS OwnerEmployeeId
      FROM grac_practice.organization_dependency_asset a
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
      LEFT JOIN grac_practice.dependency_asset_type_master ty ON ty.asset_type_id = a.asset_type_id
     WHERE a.organization_id = @organization_id
    UNION ALL
    SELECT N'APPLICATION', p.application_id, CAST(p.application_name AS NVARCHAR(400)), CAST(N'Application' AS NVARCHAR(200)),
           CAST(p.status AS NVARCHAR(120)), CAST(CASE WHEN p.status = N'Active' THEN 1 ELSE 0 END AS BIT), p.business_owner_id
      FROM grac_practice.organization_dependency_application p
     WHERE p.organization_id = @organization_id
    UNION ALL
    SELECT N'PROCESS', p.process_id, CAST(p.process_name AS NVARCHAR(400)), CAST(N'Process' AS NVARCHAR(200)),
           CAST(p.status AS NVARCHAR(120)), CAST(CASE WHEN p.status = N'Active' THEN 1 ELSE 0 END AS BIT), p.process_owner_id
      FROM grac_practice.organization_dependency_process p
     WHERE p.organization_id = @organization_id
    UNION ALL
    SELECT N'VENDOR', v.vendor_id, CAST(v.vendor_name AS NVARCHAR(400)), CAST(N'Vendor' AS NVARCHAR(200)),
           CAST(v.status AS NVARCHAR(120)), CAST(CASE WHEN v.status = N'Active' THEN 1 ELSE 0 END AS BIT), v.relationship_owner_id
      FROM grac_practice.organization_dependency_vendor v
     WHERE v.organization_id = @organization_id
    UNION ALL
    SELECT N'LOCATION', l.location_id, CAST(l.location_name AS NVARCHAR(400)), CAST(N'Location' AS NVARCHAR(200)),
           CAST(l.status AS NVARCHAR(120)), CAST(CASE WHEN l.status = N'Active' THEN 1 ELSE 0 END AS BIT), l.location_head_id
      FROM grac_practice.organization_location l
     WHERE l.organization_id = @organization_id;
GO
