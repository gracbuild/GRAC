
-- =====================================================================
-- Verification
-- =====================================================================
SELECT '445-a allocation table' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_split_allocation','U') IS NOT NULL
             AND EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_pm_asplit_alloc') THEN 'PASS' ELSE 'FAIL' END AS Result
UNION ALL
SELECT '445-b split objects present',
       CASE WHEN OBJECT_ID('grac_practice.fn_asset_split_plan') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_split_blockers') IS NOT NULL
             AND (SELECT COUNT(*) FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'grac_practice'
                   AND name IN ('sp_asset_merge_split_move', 'sp_asset_split_save', 'sp_asset_split_execute', 'sp_asset_split_get')) = 4
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '445-c 444 procedures re-issued (shared moves, both kinds, split recovery, kind filter)',
       CASE WHEN OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_merge_execute_one')) LIKE '%sp_asset_merge_split_move%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_merge_action')) LIKE '%sp_asset_split_execute%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_merge_recover')) LIKE '%@after IS NULL%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_merge_events')) LIKE '%@event_kind%'
            THEN 'PASS' ELSE 'FAIL' END
UNION ALL
SELECT '445-d split plan and blockers run',
       CASE WHEN (SELECT COUNT(*) FROM grac_practice.fn_asset_split_plan(-1, -1)) = 0
             AND (SELECT COUNT(*) FROM grac_practice.fn_asset_split_blockers(-1, -1)) = 0
            THEN 'PASS' ELSE 'FAIL' END;
GO

-- =====================================================================
-- UAT (after deploying the API + Web build)
--   Needs: asset S that really is two devices (two discovery source records,
--   relationships, a risk mapping, a serial number belonging to the second
--   device); users R (asset-discovery EDIT + asset-register ADD / EDIT), A1
--   and A2 (asset-discovery APPROVE).
--   1. Asset Register: register the second device as a new Draft asset N
--      (its own form, identity and mandatory fields).
--   2. Asset Discovery -> Splits -> New split: source S, resulting record N,
--      reason; save. The window lists every item of S: allocate the second
--      source record, one relationship and the risk mapping to N, and the
--      serial number (Move) and location fields (Copy); save again. Impact
--      shows both assets; blockers are empty.
--   3. A resulting record that is not Draft, or an open workflow case on S
--      -> Submit refused with the reason.
--   4. Submit; A1 approves (two approvers when S is Critical); R executes:
--      outcomes per object (moved / kept), the serial is on N and no longer
--      on S, the location on both; S keeps its ID, history and the
--      unallocated items. A relationship between S and N allocated to N is
--      kept (it would refer to N itself).
--   5. A1 recovers (note): the items go back to S, the serial returns to S
--      and is removed from N where unchanged; the event keeps its rows.
--   6. Merges keep working as in 444 (they now call the shared moves).
-- =====================================================================
