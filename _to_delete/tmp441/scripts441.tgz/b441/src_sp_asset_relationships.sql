CREATE OR ALTER PROCEDURE grac_practice.sp_asset_relationships
    @organization_id BIGINT,
    @ci_kind         NVARCHAR(12)  = NULL,
    @ci_id           BIGINT        = NULL,
    @type_code       NVARCHAR(30)  = NULL,
    @status          NVARCHAR(10)  = NULL,
    @critical_only   BIT           = 0,
    @pending_only    BIT           = 0,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25,
    @actor           NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54701, 'Organization not found.', 1;
    SET @ci_kind = NULLIF(UPPER(LTRIM(RTRIM(@ci_kind))), N'');
    SET @type_code = NULLIF(UPPER(LTRIM(RTRIM(@type_code))), N'');
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    EXEC grac_practice.sp_asset_relationship_sync @organization_id = @organization_id, @actor = @actor;

    SELECT r.relationship_id AS RelationshipId, r.relationship_type_code AS TypeCode, t.type_name AS TypeName,
           t.inverse_label AS InverseLabel, t.dependent_side AS DependentSide,
           r.source_kind AS SourceKind, r.source_id AS SourceId, sc.CiName AS SourceName, sc.CiClass AS SourceClass,
           sc.CiStatus AS SourceStatus, r.target_kind AS TargetKind, r.target_id AS TargetId, tc.CiName AS TargetName,
           tc.CiClass AS TargetClass, tc.CiStatus AS TargetStatus, r.is_critical AS IsCritical,
           r.dependency_criticality AS DependencyCriticality, r.impact_weight AS ImpactWeight, r.status AS Status,
           r.effective_from AS EffectiveFrom, r.effective_to AS EffectiveTo, r.source_code AS SourceCode,
           r.confidence_pct AS ConfidencePct, r.verification_status AS VerificationStatus, ow.employee_name AS OwnerName,
           vf.employee_name AS VerifierName, r.in_loop AS InLoop, r.version_no AS VersionNo, r.pending_action AS PendingAction,
           r.pending_reason AS PendingReason, r.pending_by AS PendingBy, r.retirement_accepted AS RetirementAccepted,
           r.proposed_by AS ProposedBy, r.approved_by AS ApprovedBy, r.approved_dt AS ApprovedDt, r.status_note AS StatusNote,
           CONVERT(BIGINT, r.record_version) AS RecordVersion,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_relationship r
      JOIN grac_practice.asset_relationship_type t ON t.type_code = r.relationship_type_code
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) sc ON sc.CiKind = r.source_kind AND sc.CiId = r.source_id
      LEFT JOIN grac_practice.fn_asset_ci_catalog(@organization_id) tc ON tc.CiKind = r.target_kind AND tc.CiId = r.target_id
      LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = r.owner_employee_id
      LEFT JOIN grac_practice.organization_employee vf ON vf.employee_id = r.verifier_employee_id
     WHERE r.organization_id = @organization_id
       AND (@ci_kind IS NULL OR @ci_id IS NULL
            OR (r.source_kind = @ci_kind AND r.source_id = @ci_id) OR (r.target_kind = @ci_kind AND r.target_id = @ci_id))
       AND (@type_code IS NULL OR r.relationship_type_code = @type_code)
       AND ((@status IS NULL AND r.status IN (N'PROPOSED', N'ACTIVE', N'DISPUTED')) OR @status = N'ALL' OR r.status = @status)
       AND (ISNULL(@critical_only, 0) = 0 OR r.is_critical = 1)
       AND (ISNULL(@pending_only, 0) = 0 OR r.status = N'PROPOSED' OR r.pending_action IS NOT NULL)
       AND (@search IS NULL OR sc.CiName LIKE N'%' + @search + N'%' OR tc.CiName LIKE N'%' + @search + N'%')
     ORDER BY CASE WHEN r.status = N'PROPOSED' OR r.pending_action IS NOT NULL THEN 0 WHEN r.status = N'DISPUTED' THEN 1
                   WHEN r.status = N'ACTIVE' THEN 2 ELSE 3 END,
              r.is_critical DESC, sc.CiName, t.display_order, tc.CiName
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO
