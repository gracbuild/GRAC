# Asset & Contract Management -- gap analysis, plan and API reference

**BRD:** `Compliance_Asset_Contract_Management_Workflow_Specification_v1.7_Final_Consolidated.docx` (v1.7, Oct 2026)
**Status:** Phase 1 (discovery) complete. Delivered: Phase 0 stabilisation (`419`), Phase 2.1 field dictionary + asset form templates (`420`), Phase 2.2 option lists + conditional rules + preview (`421`), Phase 2.3 asset valuation configuration -- CIA scales, valuation method, value bands, criticality (`422`), Phase 2.4 organization option lists (`423`), Phase 2.5 asset taxonomy governance (`424`), Phase 3.1 technology catalogue -- makes and models (`425`), Phase 3.2 firmware catalogue and compatibility (`426`), Phase 3.3 operating-system catalogue and compatibility (`427`), Phase 4.1 Asset Register core (`428`).
**Build/test environment:** neither `dotnet` nor `sqlcmd` is available on the development machine. Every change in this document was checked by static review only (see "Verification" at the end). Nothing here has been compiled or executed yet.

---

## 1. What exists today (traced, not assumed)

| Area | Where it lives | Notes |
|---|---|---|
| Settings -> Dependencies -> Vendors / Assets / Processes tabs | `Views/Practice/Manage.cshtml` (generic grid), `wwwroot/js/practice.js` (`schemas`, `setupChildScreens`, `openSetupActionMenu`) | No dedicated controller/service. Route `Practice/Index/organization-dependencies`; menu row `organization-dependencies` under `nav-organization` ("Settings"). |
| Gateway | Web `PracticeManagementGatewayController` -> API `PracticeRepositoryController` (`secure/query`, `secure/manage`) -> `PracticeRepositoryService` | Entities `dependency-vendors`, `dependency-assets`, `asset-taxonomy`, `dependency-options`. |
| Vendor table | `grac_practice.organization_dependency_vendor` (002) | name, service category, relationship owner, contract start/end/renewal, `sla_applicable`, criticality, status. UNIQUE(org, name). **Authoritative vendor record.** Saved/retired by monolith `dbo.pm_manage_practice_repository` (404). |
| Asset table | `grac_practice.organization_dependency_asset` (002, +123, +239) | name, category, subcategory, type, owner (employee), location, purchase/warranty/AMC dates, criticality, `lifecycle_status` (Planned/Commissioned/Decommissioned), status. UNIQUE(org, name). Saved by shim `sp_org_dependency_assets_repository_manage` (241). |
| Asset taxonomy | `dependency_asset_category_master` / `_subcategory_master` / `_type_master` (002/239, seeded 240/272) | **Global** masters, 3 levels, `is_active` only. |
| Vendor users | `organization_employee.party_type='ThirdParty'` + `provider_vendor_id` (133) | Third-party personnel linked to a vendor. No separate vendor-contact or vendor-portal concept. |
| Practice/obligation integration | Event-driven obligations with ASSET subject; Asset Profiles (407: Location/Category/Sub Category/Type); `sp_event_raise_asset_lifecycle` (commission/decommission); `event_checklist_mapping.scope_asset_category_id` | Real, working integration point for asset activities. |
| Operationalize / Risk | `practice_instance_dependency`, `practice_dependency_resolution`, `risk_dependency_map` (265), `risk_register.linked_asset_id/linked_vendor_id` | Assets/vendors are mappable dependencies. |
| Ownership | `fn_pm_user_ownership` sources `DEP_ASSET`, `DEP_VENDOR_REL` (345) | |
| Tasks | `practice_task`, `task_attachment` (evidence), `task_candidate.source_dedupe_key` (idempotency), `sp_task_*` | Reusable for every asset/contract activity. |
| State machine | `entity_status_master`, `entity_state_transition_rule`, `entity_state_transition_log` (immutable), `sp_pm_state_transition` (035) | Reusable for every BRD status lifecycle. |
| Audit | `practice_audit_trace` (immutable), module `*_history` tables | |
| Exceptions (waivers) | `exception_request` + `exception_type_master` (Exception Centre) | Reusable for Technology Exceptions (waiver with expiry/approver). |
| Notifications | `task_notification_outbox` (dedupe key), `org_sla_config`, My Notification | Reminder/escalation **profiles** do not exist. |
| Documents | `document_upload*` (146) | Reusable for signed contract documents. |
| Dashboards | `management-dashboard` partial, `sp_dashboard_*`, `js/Shared/dashboard-drill.js` | Pattern for reconciled drill-down. |
| Dynamic forms | **None.** Closest: `organization_metadata_definition/value` (typed EAV, org attributes) | Pattern reused for asset field values. |

### Defects found in the existing Asset/Vendor tabs (fixed in 419)

| # | Defect | Cause |
|---|---|---|
| D-1 | Asset row -> **Inactive** failed with "Organization is required." | Gateway sends `RETIRE`; the 241 shim only recognised `delete/inactive/deactivate`, so RETIRE fell into the save path. |
| D-2 | **Editing an asset wiped its Sub Category and Asset Type.** | The monolith list query (404) never returned `asset_subcategory_id`/`asset_type_id`; the form opened blank and the shim's UPDATE wrote NULL. |
| D-3 | Asset save skipped the organization-access, Owner and Location checks the monolith applies, and its error numbers were not mapped to form fields. | Shim re-implemented validation partially (52720-52727). |

Vendor retire/save were traced and work (monolith path).

---

## 2. BRD -> implementation gap matrix

Legend: **Reuse** = use as is; **Enhance** = extend the existing object; **New** = no existing implementation.

| BRD section | Requirement | Status | Existing object(s) to build on |
|---|---|---|---|
| 4.1 | Category / subcategory / type hierarchy | Enhance | taxonomy masters (global). Missing: sector, owner, effective dates, governed status. |
| 4.1 | Asset-type template | New (420) | -- |
| 4.2-4.5 | Make, model, firmware, OS catalogues, many-to-many compatibility | New | `organization_dependency_application` support/EOL dates are the only lifecycle data today. |
| 4.6 | Installed firmware/OS history | New | -- |
| 4.7-4.8 | Technology lifecycle workflow, rules | New | Technology Exception -> Reuse `exception_request` (new request type). |
| 5 | Asset master domains | Enhance | `organization_dependency_asset` stays the asset record; extended fields via dictionary + EAV. |
| 5 / 19.9 | Lifecycle statuses (28) + transition matrix | Enhance | Move to state machine (entity_type `Asset`); keep `lifecycle_status` in step for `sp_event_raise_asset_lifecycle`. |
| 5.1 | Registration data dictionary | New (420) | Typed-EAV pattern of `organization_metadata_value`. |
| 5.1.14-5.1.16 | Conditional logic, cross-field validation | New (Phase 2 inc 2) | -- |
| 5.1.18 | CIA scales, valuation methods, bands, criticality config | New | `criticality_master` (global) reused as default scale; org risk matrix (204) for later risk use. |
| 5.2 | Asset Type Form Designer, versioning, approval, publication | New (420: fields/sections/lifecycle; rules + migration in inc 2) | State machine for template status. |
| 5.3 | Custodian acknowledgement, attestation, verification exceptions, SLA, lost-asset | New | Tasks (`practice_task`), evidence (`task_attachment`), SLA (`org_sla_config`), outbox, state machine. |
| 5.4 | Asset relationships | Enhance | `risk_dependency_map`/`practice_instance_dependency` are object links, not CI relationships -> new `asset_relationship` + type/class rules. |
| 5.5 / 19.6 | Business services, contract-to-service | New | `organization_dependency_process` reused for "process supported". |
| 5.6 / 19.3-19.5 | Discovery, matching, confidence, merge/split | New | -- |
| 5.7 / 19.8 | Governance metrics & score | New | Management-dashboard procedures + drill pattern. |
| 5.8 | Risk calculation profiles | Enhance | `risk_register`, `risk_dependency_map`, risk scoring masters. **Risk Treatment Integration excluded (19.12).** |
| 6 | Practice/checklist applicability | Enhance | Event-driven obligations, Asset Profiles (407), `event_checklist_mapping`, `assurance_schedule_rule`. Extend profile dimensions (make/model/criticality/privacy). |
| 7 | Contract record | New | Vendor reference -> `organization_dependency_vendor`. |
| 7.1 | Contract-vs-asset task generation, occurrence keys | New logic | `practice_task` + `task_candidate.source_dedupe_key`. |
| 7.2-7.3 | Immutable contract versions, renewal history, compare | New | `document_upload` for signed documents. |
| 7.4 | Vendor integration, contract vendor contacts | Reuse + New | Vendor = `organization_dependency_vendor`; vendor users = ThirdParty `organization_employee` (decision D2). Contact mapping is new. |
| 8 | Bulk jobs, campaigns, per-record results | New | -- |
| 9.1 | Notification profiles, stages, escalation | Enhance | `task_notification_outbox` (dedupe), `org_sla_config`, My Notification. |
| 10 | Privacy model | New | Fields via dictionary; assessments new. |
| 11 | Owner change, transfer, breakdown, disposal workflows | New | State machine + tasks. |
| 12 | Multi-dimension status governance | New (calculated) | -- |
| 13 | Dashboards & report catalogue | New | Management dashboard pattern, `dashboard-drill.js`. |
| 14 | Audit | Reuse | `practice_audit_trace`, `entity_state_transition_log`. |

---

## 3. Phased plan (adapted to this codebase)

| Phase | Scope | Key objects | Depends on |
|---|---|---|---|
| 0 | Stabilise existing Asset/Vendor tabs | 419 | -- |
| 2.1 **(done)** | Field dictionary (BRD 5.1 seeded), org-scoped asset form templates: fields, sections, properties, versioned lifecycle Draft -> Testing -> Pending Approval -> Approved -> Active -> Retired with segregation of duties, publish-readiness check | 420, `AssetConfigurationController`, two screens | 0 |
| 2.2 **(done)** | Option lists (BRD-enumerated values), dictionary type corrections, conditional SHOW / REQUIRE rules with AND/OR groups and circular-dependency blocking, one evaluation engine + Preview tab | 421 | 2.1 |
| 2.3 **(done)** | Per-organization, versioned, approval-controlled valuation configuration: CIA scales (C/I/A levels), Maximum / Weighted Average / Summation with weights and rounding, non-overlapping gap-free Asset Value bands, criticality scale mapped to existing Criticality values; calculation function + Calculator; template CIA fields list the Active scale | 422 | 2.2 |
| 2.4 **(done)** | Organization option lists: catalogue of every dictionary `OPTION:` list with a scope (Organization values / Defaults + organization / Fixed); the organization's own values with parent links (building -> site, floor -> building, room -> floor, zone -> site); relabel / reorder / hide / reset of a global default per organization; one effective-list function used by templates, preview and readiness | 423 | 2.3 |
| 2.5 **(done)** | Asset taxonomy governance: category sector / owner / standards / default criticality / effective dates; L1/L2 subcategories; asset type description / default criticality / effective dates, name unique within subcategory; per-organization default business owner role and support group; one "selectable now" function used by the asset lookup, template creation and asset save; Asset Taxonomy screen | 424 | 2.4 |
| 3.1 **(done)** | Technology catalogue -- makes (identity, support, governance, supported asset types) and models (identity, release / support dates, technical, governance, risk, BRD lifecycle status) with record approval, identity lock after approval, milestone history with reason (4.6 / 4.8); shared catalogue (platform admin) + organization rows | 425 | 2.5 |
| 3.2 **(done)** | Firmware products and releases (BRD 4.4 fields; status list Draft / Approved / Recommended / Supported / Deprecated / EOS / EOL / Withdrawn on the state machine), identity lock after approval, milestone history with reason; explicit compatibility rows (asset type + optional make / model / hardware revision, Certified..Unknown, upgrade path, effective dates, evidence) approved separately; approved in-effect compatibility per model | 426 | 3.1 |
| 3.3 **(done)** | OS products (publisher, family, product) and releases (BRD 4.5 identity, lifecycle, servicing, governance incl. approved baseline, exception, replacement path); status list Draft / Approved / Supported / Extended Support / Approaching EOS / EOS / Unsupported; explicit OS compatibility rows (asset type + optional make / model / architecture, minimum firmware release, exclusions) approved separately; approved OS per model | 427 | 3.2 |
| 3.4 | Installed firmware / OS history and technology exceptions (4.6) -- moved into Phase 4 as 4.3 | | 4.1 |
| 4.1 **(done)** | Asset Register: 27 BRD lifecycle statuses with phases (creation -> Draft only), legacy lifecycle kept in step, template version pinned per asset, typed values for VALUE fields, one rule engine (`fn_asset_form_evaluate`) for Preview / form / save, master lookups function, data-driven cross-field rules from the dictionary text, hidden-value RETAIN / CLEAR / MIGRATE decisions, model-make-type consistency, serial and compatibility warnings; register screen with dynamic form | 428 | 3.3 |
| 4.2 **(done)** | Asset lifecycle transitions: 75-row matrix from BRD 19.9 / 5.4.3 (plus 11 / 5.3.10 and PROPOSED exits, D16) on the state machine, per-transition gates (reason, reference, evidence, saved on form, owner, approval), approval with segregation of duties, Disposed / Archived -> Active refused, legacy lifecycle + commissioning / decommissioning event kept in step, change history; Lifecycle tab, pending-approval filter, transition-rules view | 429 | 4.1 |
| 4.3 **(done)** | Installed technology (4.6): firmware / OS installation history (previous version, result, rollback, licence, evidence, current flag) written by the Technology tab and by form changes; technology status per asset (release status, support dates, recommended target from approved compatibility, classification Current / Due Soon / Unsupported / Exception / Unknown); technology exceptions (asset or model, reason, controls, owner, expiry, review; approval by another person, withdraw, revoke); register save blocks an unmapped firmware / OS unless an exception covers it | 430 | 4.1 |
| 4.4 **(done)** | Custody (5.3): effective-dated owner / custodian / department / location history written by every save; attestation profiles by category / subcategory / asset type (participant, frequency, due window, evidence, manager approval); initial acknowledgement raised by a custodian / owner change (superseded ones cancelled, open ones reassigned); periodic runs and ad-hoc campaigns with idempotent occurrence keys and overdue marking; assignee-only responses with the 5.3.4 checks, condition, disagreement categories, comments and evidence; manager approval / return, cancel; asset verification state and next date; Asset Attestation screen and Asset Register Custody tab | 431 | 4.2 |
| 4.5a **(done)** | Asset Verification Exceptions (5.3.5-5.3.10): one exception per disagreement on the state machine (Open / Assigned / Under Review / Awaiting Evidence / Awaiting Approval / Resolved / Closed / Cancelled), BRD 5.3.8 assignment / SLA matrix as defaults with organization overrides, investigator from the rule with fallback, start / original / revised resolution due dates with SLA pause, escalation level 1 / 2 / 3, lost-asset security review, controlled outcome + narrative + closure evidence + approval by another person, lifecycle posture check before closing; Exceptions and Exception settings tabs, Custody tab list | 432 | 4.4 |
| 4.5b | Owner change, location transfer, breakdown and disposal workflows (11) with Transfer / Return attestation types | 433 | 4.5a |
| 5 | Contracts: versions, renewals, vendor contacts, entitlement, coverage, reconciliation | | 4 |
| 6 | Activities: scheduler with contract-vs-asset rules (7.1), occurrence keys, tasks/evidence/approval, notification profiles & escalation | | 4, 5 |
| 7 | CMDB relationships, business services, impact analysis, discovery & reconciliation | | 4 |
| 8 | CIA valuation & risk profiles, privacy, dashboards, report catalogue, exports | | 4-7 |
| 9 | Regression, permission, workflow, reconciliation testing | | all |

Acceptance criteria per phase are the BRD's own (5.2.21, 5.3.13, 7.5, 9.1.12, 16.x).

---

## 4. Decisions taken (please confirm or redirect)

| # | Decision | Why | Reversible? |
|---|---|---|---|
| D1 | **Field dictionary is global** (platform-controlled, seeded from BRD 5.1); **asset form templates are per organization**. | Taxonomy masters are already global; BRD wants form configuration tenant-scoped. | Yes -- templates carry `organization_id`. |
| D2 | **Vendor users = existing ThirdParty employees** (`organization_employee.provider_vendor_id`). Contract contacts will map to them. | BRD 7.4 forbids duplicating vendor users; this is the only vendor-user record today. | Needs an extension if non-login contacts are required. |
| D3 | **`organization_dependency_asset` remains the asset record.** Dictionary fields mapped to existing columns are `COLUMN` storage; all other fields will be stored in a typed EAV table (Phase 4). | No parallel asset table; existing links (risk, operationalize, ownership, events) keep working. | -- |
| D4 | Legal entity = `organization`; business unit = `organization_division`; department = `organization_department`. | Closest existing structure. | Confirm. |
| D6 | **Option lists = global defaults + per-organization values** (423). BRD-enumerated lists keep their 421 defaults and each organization may add, relabel or hide; lists the BRD leaves open are organization-only; yes/no lists are fixed. | BRD 5.1.2 / 5.1.6 / 5.1.10 call them the organization's active values; 5.2.5 allows a controlled list. | Yes -- scope is a column on `asset_option_list_master`. |
| D7 | **Taxonomy stays global; only the platform administrator (PM_ADMIN) edits it** (424). Category sector / owner / standards are global text; owner role and support group of an asset type are per organization (`asset_type_org_default`). | D1; one change reaches every organization; roles and teams are organization records. | Yes -- the per-org table can take more columns. |
| D8 | **Effective dates gate new choices, not existing records** (424). A node is selectable when it and its ancestors are active and inside their dates (UTC date). The asset lookup, template creation and asset save check it; reports and event scoping still read `is_active`. | BRD 4.1 lists status and effective dates without further rules. | Yes -- one function, `fn_asset_taxonomy_selectable`. |
| D9 | **Technology catalogue = shared rows + organization rows** (425). `organization_id NULL` rows are the shared catalogue, maintained only by PM_ADMIN; an organization sees shared + its own and may add its own makes / models. | Make / model facts are vendor facts most organizations share; local OEMs still need a place. Same shape as D6. | Yes -- one column. |
| D10 | **Model lifecycle status is set by the catalogue administrator**, not derived from dates (425). | BRD 4.3 lists the six statuses but gives no thresholds (e.g. for Approaching EOS). | Yes -- a derivation can be added once thresholds are agreed. |
| D11 | **Firmware approval = a different person from the last draft editor** (426). The BRD status list has no Pending Approval step, so the release goes Draft -> Approved directly; segregation of duties is enforced against `draft_edited_by`. Compatibility rows follow the same rule, and editing an approved row returns it to Draft. | BRD 4.4 status list; 4.4 "explicit and approved". | Yes. |
| D12 | **OS catalogue adds no status or field the BRD does not list** (427): no Withdrawn release status (4.5 lists none), no compatibility status or effective dates on OS rows (4.5 lists asset type, make, model, architecture, firmware prerequisites and exclusions only). Status moves are forward-only except Approaching EOS -> Extended Support (reason required). | BRD 4.5. | Yes -- add statuses / columns if the BRD is extended. |
| D13 | **Register save = issues, not exceptions** (428): validation problems come back as rows (ERROR / WARNING / DECISION) and nothing is written until no ERROR or DECISION remains; refusals that are not field problems (not found, stale version, no Active template) are raised. | One call shows every problem at once; imports can reuse it. | -- |
| D14 | **Policies the BRD leaves open default to warnings** (428): serial duplicates within make / model ("warn or block according to policy" -- no policy store yet) and firmware / OS without an approved compatibility record (blocking needs technology exceptions, 4.3). COUNTRY / CURRENCY lookups are free text until masters exist; CONTRACT stays empty until Phase 5. | BRD 5.1.16 wording; missing masters. | Yes. |
| D15 | **Assets keep their template version** (428): editing uses the version the asset was registered with; moving to a newer Active version is an approved migration (5.1.14), not done implicitly. The Settings -> Dependencies -> Assets tab still writes the legacy columns only. | BRD 5.1.14 / 5.2.1. | -- |
| D16 | **Asset transition matrix** (429). BRD 19.9 gives "from -> permitted target examples -> minimum gate"; 5.4.3 adds Draft -> Received, Received -> Active and Pending Decommission -> Disposed. Seeded as given where the target is a BRD 5 status. 19.9 targets that are not statuses: *Returned / Rejected* (from Requested) -> back to Draft; *Returned* (from Sanitization / Disposal Approval) -> back to Pending Decommission; *Cancelled* (Transfer Pending) and *approved cancellation* (Pending Decommission) -> Active. Statuses 19.9 has no row for get exits marked **11** (Breakdown, Location Transfer, Owner Change workflows), **5.3.10** (Lost / Stolen -> approved investigation outcome, never straight to Disposed) or **PROPOSED** (Storage, Recalled, Obsolete, Non-Compliant, Out of Service / Quarantined release, readiness order). Gates follow the BRD wording: "approval" -> approval by another person, "reference" -> a required reference, "evidence / test / work result" -> required evidence, "impact review / rationale" -> required reason, "identity / owner" -> owner set, "required draft fields" -> saved on its form template. **Please confirm the PROPOSED and mapped rows**; any row can be switched off (`entity_state_transition_rule.is_active = 0`) without code. Open: no exit for a Draft / Approved / Ordered asset that is cancelled (19.9 target Cancelled, no BRD 5 status), and *Returned* from Inspection / Commissioning (returned to the vendor?) is not mapped. | BRD 19.9, 5.4.3, 11, 5.3.10, 5.1.16. | Yes -- rules are data. |
| D17 | **Lifecycle approval = a different person with APPROVE on Asset Register** (429). A move with an approval gate is recorded as PENDING_APPROVAL (one per asset; no other move meanwhile); the requester cannot approve or reject (by user and employee id), a rejection needs a note, only the requester can cancel. Approval re-checks that the asset is still in the requested-from status and the rule is still active. Moves without an approval gate complete at once. Evidence is a reference (document number, report, link) until task evidence exists (Phase 6). | BRD 19.9 / 5.4.3 "approval"; 17 "required approvals / evidence". | Yes. |
| D18 | **Commissioning / decommissioning events follow the lifecycle** (429). When a move changes the legacy lifecycle (Planned -> Commissioned, -> Decommissioned) it calls the existing `sp_event_raise_asset_lifecycle`, so the same event, checklists and obligations as the Commission / Decommission action are raised; if raising fails (e.g. the event is deactivated) the move is refused with that message (19.9: a failed side effect does not silently complete the transition). | D5; BRD 19.9. | Yes. |
| D19 | **Technology classification and recommended target** (430). BRD 4.7 lists Current / Due Soon / Unsupported / Exception / Unknown without thresholds, so it is status-based: Unsupported = firmware EOS / EOL / Withdrawn, OS EOS / Unsupported, or no approved compatibility row for the asset's model; Exception = unsupported but an active exception covers it; Due Soon = firmware Deprecated, OS Approaching EOS; Unknown = the asset's form has the field but no version is recorded; Not applicable = the form has no such field. No date window is applied to Due Soon (the BRD gives none -- one can be added). Recommended firmware = a **Recommended** release with an approved, in-effect compatibility row for the asset's model (hardware revision respected); recommended OS = an **approved-baseline** release with an approved row for the model. The current version stays in the form fields; the history tables record every change. | BRD 4.6-4.8, 5 (Technology domain). | Yes. |
| D20 | **Technology exceptions are their own record, not Exception Centre requests** (430). `exception_request` is bound to a compliance gap (`custom_gap_id NOT NULL`, gap analysis and linked-practice derivation), so reusing it would change the Exception Centre workflow. `asset_technology_exception` carries the BRD 4.6 fields (asset or model, version, reason, controls, owner, approver, expiry, review); approval by a different person with Asset Register APPROVE; active from approval to expiry; withdraw (requester) and revoke (note). Reverses the earlier gap-matrix note "reuse exception_request". Listing them in the Exception Centre can be added later. | BRD 4.6; existing schema 161 / 166. | Yes. |
| D21 | **Unmapped firmware / OS now blocks the save** (430). 5.1.16 says the installed version "must have approved mapping or explicit exception"; D14 kept it a warning only until exceptions existed. The check runs when the value changes (existing assets are not blocked on unrelated edits); a new asset with an unmapped version is saved without it first, then an exception is requested on its Technology tab. | BRD 5.1.16, 4.8. | Yes -- one rule in `sp_asset_register_save`. |
| D22 | **Ownership / custody / location history is a snapshot table written by the save** (431). `asset_assignment_history` keeps asset owner, custodian (employee or team), department, site, building, floor and room with effective dates; `sp_asset_assignment_snapshot` runs at the end of every register save and writes a row only when one of them changed (effective from the assignment start date when newer, else today). It is also what raises the initial acknowledgement (5.3.2). | BRD 1 (effective-dated history), 5.3.2. | Yes. |
| D23 | **Due windows are calendar days** (431). 5.3.1 allows business or calendar days, but the application has no business calendar / holiday table yet. | BRD 5.3.1. | Yes -- add a business calendar. |
| D24 | **Which assets are attested** (431): an active profile with Attestation Required applies (most specific: asset type, subcategory incl. its level-1 parent, category), and the asset is not in acquisition (Draft / Requested / Approved / Ordered), Lost / Stolen (under investigation, 5.3.10) or Disposed / Archived. Initial acknowledgements are raised in any status except Disposed / Archived. Participant Both creates one occurrence per role. | BRD 5.3.1 / 5.3.3. | Yes. |
| D25 | **Who may respond and approve** (431). Only the assignee responds -- the custodian employee, or any active member of a custodian team; no delegated authority is configured, so nobody responds on behalf of another (5.3.2). Manager approval (when the profile asks for it) is given by the attester's reporting officer, or -- without one -- the asset owner, never the attester; enforced in the procedures, so the screen needs only VIEW for responding / approving. Cancelling an occurrence needs a reason and APPROVE. | BRD 5.3.1, 5.3.2, 5.3.5. | Yes. |
| D26 | **Disagreements are recorded, not yet investigated** (431). Disagree sets the occurrence and the asset Disputed and stores the category, comments and evidence; ownership never changes. The Asset Verification Exception, category tasks and SLA (5.3.6-5.3.9) are increment 4.5 / Phase 6. Confirm writes the dictionary fields Last verified date / Verified by. | BRD 5.3.5-5.3.9. | -- |
| D27 | **Exception severity** (432): Critical when the category is Asset Lost (5.3.9 "critical / lost-asset cases") or the asset criticality is Critical (5.3.1 critical-asset override), otherwise Standard. A Critical exception is shown first; shorter SLAs for critical assets are not applied because the BRD gives no values (the per-category rule can be shortened). | BRD 5.3.1, 5.3.7, 5.3.9. | Yes. |
| D28 | **Closure approval / evidence by category** (432): 5.3.7 says "required according to category / severity" without values. Defaults: approval and evidence for Asset Not Found, Asset Lost and Asset Retired; evidence for Asset Damaged; none otherwise. Each organization can change them per category (Exception settings). | BRD 5.3.7. | Yes -- configuration. |
| D29 | **Investigator resolution** (432): the rule's primary assignment maps to asset fields -- Asset owner -> asset owner; Asset administrator -> the organization's asset administrator setting; Maintenance team -> maintenance owner, else support group; Security -> information security owner, else asset owner; Fallback team -> the organization's fallback team. Unresolved -> fallback team -> asset administrator -> asset owner; still none -> Open (unassigned) until reassigned. Supporting assignments are recorded as text (tasks arrive with Phase 6). | BRD 5.3.8. | Yes. |
| D30 | **Outcomes and posture** (432): outcomes No change, Record corrected, Loss confirmed, Damage confirmed, Retirement confirmed, Duplicate confirmed, Other. Record corrections are made on the Asset Register form (history kept by 431). Loss / damage / retirement outcomes close only after the asset was moved (or a move is pending) through its lifecycle (429) -- Lost / Stolen, Maintenance / Repair / Out of Service / Quarantined, or the retirement phase -- so posture changes only through the lifecycle workflow (5.3.5). Closing sets the occurrence Resolved; No change / Record corrected restore Verified with the next date, other outcomes leave the asset Not verified. | BRD 5.3.5. | Yes. |
| D5 | Legacy `lifecycle_status` (Planned/Commissioned/Decommissioned) will be kept in step with the new BRD status (Phase 4). | `sp_event_raise_asset_lifecycle` and event obligations read it. | -- |

## 5. Out of scope / not touched

- Risk Treatment Integration, AI/Automation Readiness, separate Data Stewardship (BRD 19.12).
- Observed but unrelated: `ITaskCandidateService` / `ITaskNotificationService` and `TaskNotificationWorker` are not registered in `Api/Program.cs` (Phase 6 will depend on the notification worker -- needs a decision before then). The Asset picker in `workflow-event-inbox.cshtml` / `_event-assurance-panel.cshtml` calls the gateway without an encrypted `code` (not changed).

---

## 6. API reference -- Asset Configuration (migration 420)

Web proxy: `/practice/api/asset-config/*` -> API `/api/practice/asset-config/*`. The proxy checks the session, the organization (`IsOrganizationAllowed`), and the menu grant (`asset-field-dictionary` or `asset-form-templates`: VIEW for GET; ADD/EDIT for writes; APPROVE for approve/reject/return). The acting employee is taken from the `X-PM-Caller-Employee-Id` header stamped by the Web tier, never from the body.

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `field-groups` | Dictionary groups (sections of BRD 5.1) | `sp_asset_field_group_list` |
| GET | `field-definitions?groupCode=&dataType=&sensitivity=&search=&pageNumber=&pageSize=` | Dictionary list (paged, `totalRows`) | `sp_asset_field_definition_list` |
| GET | `taxonomy` | Category / subcategory / type tree | `sp_get_asset_taxonomy_lookup` (241, reused) |
| GET | `templates?organizationId=&assetTypeId=&statusCode=&search=&pageNumber=&pageSize=` | Template versions | `sp_asset_form_template_list` |
| GET | `templates/{id}?organizationId=` | Header + sections + fields + transitions | `sp_asset_form_template_get` |
| POST | `templates` | Create Draft v1 for an asset type `{organizationId, assetTypeId, templateName, changeReason}` (seeds system-mandatory fields) | `sp_asset_form_template_create` |
| POST | `templates/{id}/new-version` | Clone any version into a new Draft (`changeReason` required) | `sp_asset_form_template_new_version` |
| POST | `templates/{id}/header` | Name, approval-required, owner, effective dates, reason (Draft only) | `sp_asset_form_template_header_save` |
| POST | `templates/{id}/sections` | Upsert one section (Draft only) | `sp_asset_form_template_section_save` |
| POST | `templates/{id}/fields` | Add / update one field's placement and properties (Draft only) | `sp_asset_form_template_field_save` |
| POST | `templates/{id}/fields/remove` | Remove a field (blocked for system-mandatory) | `sp_asset_form_template_field_remove` |
| GET | `templates/{id}/readiness?organizationId=` | Publish-readiness report | `sp_asset_form_template_readiness` |
| POST | `templates/{id}/transition` | `{organizationId, toStatusCode, reasonText}`: TESTING, DRAFT (return), PENDING_APPROVAL, APPROVED, ACTIVE, RETIRED | `sp_asset_form_template_transition` |

| POST | `templates/{id}/rules` | Add / update one rule `{organizationId, ruleId?, ruleName?, targetFieldDefinitionId, actionCode: SHOW\|REQUIRE\|SHOW_AND_REQUIRE, isActive, conditions:[{groupNo, sourceFieldDefinitionId, operatorCode, compareValue}]}` (Draft only) | `sp_asset_form_template_rule_save` (421) |
| POST | `templates/{id}/rules/remove` | `{organizationId, ruleId}` (Draft only) | `sp_asset_form_template_rule_remove` (421) |
| POST | `templates/{id}/evaluate` | Preview: `{organizationId, values:{field_key: value}}` -> each field's effective visible / mandatory and the rules that fired. Read-only; proxy needs VIEW | `sp_asset_form_template_evaluate` (421) |

`GET templates/{id}` also returns `rules`, `conditions` and `options` (option values of the template's OPTION: fields) since 421.

Error numbers: `54200-54249` (see the 420 and 421 headers). Illegal status moves surface the framework's `53520` (HTTP 409).

### Asset valuation (422)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `valuation?organizationId=` | Configuration versions | `sp_asset_valuation_config_list` |
| GET | `valuation/{id}?organizationId=` | Header, CIA levels, bands, criticality levels, history, criticality master list | `sp_asset_valuation_config_get` |
| GET | `valuation/{id}/readiness?organizationId=` | Blocking issues / warnings (+ the method's possible score range) | `sp_asset_valuation_config_readiness` |
| POST | `valuation` | New Draft `{organizationId, configName?, sourceConfigId?, changeReason?}`: v1 = BRD defaults, later versions copy the current one (reason required) | `sp_asset_valuation_config_create` |
| POST | `valuation/{id}/header` | Name, method, weights, decimal places, rounding, override flag, effective dates, reason (Draft only, concurrency-checked) | `sp_asset_valuation_config_header_save` |
| POST | `valuation/{id}/items` | Add / update / remove one CIA level, band or criticality level `{itemKind: CIA_LEVEL\|BAND\|CRITICALITY, itemId?, remove?, ...}` (Draft only) | `sp_asset_valuation_config_item_save` |
| POST | `valuation/{id}/transition` | `DRAFT \| PENDING_APPROVAL \| APPROVED \| ACTIVE \| RETIRED` (reason for DRAFT / RETIRED) | `sp_asset_valuation_config_transition` |
| POST | `valuation/{id}/calculate` | `{organizationId, confidentiality, integrity, availability}` -> raw score, Asset Value score, category (read-only; proxy needs VIEW) | `sp_asset_valuation_calculate` / `fn_asset_value_calc` |

Rules: weighted weights must total 100 before submission; bands may not overlap, may not leave a gap (step 1 for Maximum / Summation, 10^-decimals for Weighted Average) and must cover the method's full possible range; each dimension needs two or more distinct scores; criticality needs one or more levels. Value-band ranges are not pre-filled because the BRD does not define them. Errors `54250-54269` (see the 422 header); 54251 -> 404, 54253 / 53520 -> 409.

### Organization option lists (423)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `option-lists?organizationId=&search=` | Catalogue: list, scope, parent field, default / organization / effective counts, fields using it | `sp_asset_option_list_catalog` |
| GET | `option-lists/{group}?organizationId=` | `{list, values, parents}` -- values carry `source` GLOBAL / OVERRIDE / HIDDEN / ORG, `globalLabel`, `orgOptionId`, `status`; parents are the organization's locations (site) or the parent list's effective values | `sp_asset_option_list_get` |
| POST | `option-lists/{group}/values` | Add / edit / retire / reactivate an organization value `{organizationId, orgOptionId?, optionValue?, optionLabel, parentValue?, displayOrder?, status?}` (code derived from the label when blank) | `sp_asset_option_org_save` |
| POST | `option-lists/{group}/override` | Relabel / reorder / hide (`hidden`) / reset (`reset`) a global default for one organization `{organizationId, optionValue, optionLabel?, displayOrder?, hidden?, reset?}` (Defaults + organization lists only) | `sp_asset_option_org_override` |

Rules: Fixed lists cannot be changed; codes are unique per organization and list and may not repeat a default; dependent lists need an active parent (a location for site); a value with active child values cannot be retired; values are never deleted (retire = Inactive), override rows may be reset. Every write is audited in `practice_audit_trace` (`asset-option-org`). Web proxy area `asset-option-lists`: GET VIEW, POST ADD or EDIT. Errors `54270-54279` (see the 423 header); 54270 / 54276 / 54279 -> 404.

### Asset taxonomy governance (424)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `taxonomy/governance?organizationId=` | `{categories, subcategories, types, criticality, roles, teams}`; usage counts and type defaults are the organization's; `isSelectable` = active and in effect | `sp_asset_taxonomy_list` |
| POST | `taxonomy/categories` | Add / edit `{categoryId?, categoryName, description?, sector?, ownerName?, standards?, defaultCriticalityId?, effectiveFrom?, effectiveTo?, isActive?, displayOrder?, expectedRecordVersion?}` | `sp_asset_taxonomy_category_save` |
| POST | `taxonomy/subcategories` | Add / edit `{subcategoryId?, categoryId, parentSubcategoryId?, subcategoryName, ...}` | `sp_asset_taxonomy_subcategory_save` |
| POST | `taxonomy/types` | Add / edit `{assetTypeId?, subcategoryId, assetTypeName, defaultCriticalityId?, ...}` | `sp_asset_taxonomy_type_save` |
| POST | `taxonomy/types/{id}/org-defaults` | `{organizationId, businessOwnerRoleId?, supportTeamId?}` (both null clears) | `sp_asset_type_org_default_save` |

Web proxy: GET needs `asset-taxonomy` VIEW and an allowed organization; the three global POSTs need the PM_ADMIN role **and** ADD or EDIT (no organization); org-defaults needs EDIT for that organization. Rules: Asset Type Name unique within its subcategory; L1 / L2 only (an L2's parent is an L1 of the same category; a subcategory with children cannot become L2); unique category names and subcategory names per category + parent; Effective To not before From; no change of category / subcategory while assets or templates use the node; nothing is deleted; concurrency via `record_version` (ROWVERSION). Codes are generated from the name (`fn_asset_make_code`). Every write is audited (`asset-taxonomy-category | -subcategory | -type`, `asset-type-org-default`). Errors `54280-54295`; 54280 / 54285 / 54288 / 54291 -> 404, 54284 -> 409.

### Technology catalogue -- makes and models (425)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `tech-catalog?organizationId=` | `{makes, models, assetTypes, criticality}` -- shared + the organization's rows; asset types = selectable now (424) with path | `sp_asset_tech_catalog_list` |
| GET | `tech-catalog/models/{id}?organizationId=` | `{model, lifecycleEvents, history}` | `sp_asset_model_get` |
| POST | `tech-catalog/makes` | Add / edit `{organizationId, shared?, makeId?, makeName, legalName?, aliases?, supportPortalUrl?, securityAdvisoryUrl?, supportContact?, supportRegion?, ownerName?, authoritativeSource?, verifiedDate?, verifiedBy?, effectiveDate?, status?, assetTypeIds?, expectedRecordVersion?}` | `sp_asset_make_save` |
| POST | `tech-catalog/models` | Add / edit (all BRD 4.3 fields) + `changeReason` | `sp_asset_model_save` |
| POST | `tech-catalog/models/{id}/transition` | `{organizationId, shared?, toStatusCode: PENDING_APPROVAL \| APPROVED \| DRAFT \| WITHDRAWN, reasonText?, expectedRecordVersion?}` | `sp_asset_model_transition` |

Web proxy area `asset-tech-catalog`: GET VIEW; transition APPROVED needs APPROVE, DRAFT needs ADD / EDIT / APPROVE, other POSTs ADD or EDIT; `shared: true` also needs PM_ADMIN, and the procedures refuse when the declared scope does not match the row (54804). Rules: make name may not match another visible make's name or alias; per make, model number unique when given and name + variant + hardware revision unique; end-of-sale / support / life dates on or after release, announcement on or before it (also a CHECK constraint); overwriting a milestone that had a value needs a reason and writes `technology_lifecycle_event` rows (before / after / source / reason); submitting needs a source reference, an active make and a selectable asset type; submitter cannot approve; approved models keep make, type, name, number, variant and hardware revision. Errors `54800-54818`; 54800 / 54801 / 54807 -> 404, 54805 -> 409.

### Technology catalogue -- firmware (426)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `tech-catalog/firmware?organizationId=` | `{products, releases}` (shared + organization) with compatibility counts | `sp_asset_firmware_list` |
| GET | `tech-catalog/firmware/releases/{id}?organizationId=` | `{release, compatibility, lifecycleEvents, history}` | `sp_asset_firmware_release_get` |
| GET | `tech-catalog/models/{id}/firmware?organizationId=` | Approved, active, in-effect compatibility for the model (model / make / asset-type match level, hardware-revision match) | `sp_asset_model_firmware_list` |
| POST | `tech-catalog/firmware/products` | `{organizationId, shared?, productId?, publisherMakeId, productName, description?, status?, expectedRecordVersion?}` | `sp_asset_firmware_product_save` |
| POST | `tech-catalog/firmware/releases` | All BRD 4.4 release fields + `changeReason` | `sp_asset_firmware_release_save` |
| POST | `tech-catalog/firmware/releases/{id}/transition` | `{organizationId, shared?, toStatusCode, reasonText?, expectedRecordVersion?}` | `sp_asset_firmware_release_transition` |
| POST | `tech-catalog/firmware/compatibility` | `{organizationId, shared?, compatId?, releaseId, assetTypeId, makeId?, modelId?, hardwareRevision?, compatStatus, upgradePath?, effectiveFrom?, effectiveTo?, evidence?, reviewer?, isActive?, expectedRecordVersion?}` | `sp_asset_firmware_compat_save` |
| POST | `tech-catalog/firmware/compatibility/{id}/approve` | `{organizationId, shared?, expectedRecordVersion?}` (proxy: APPROVE) | `sp_asset_firmware_compat_approve` |

Rules: product = publisher make + name, unique; release = product + version + build + branch + edition, unique; support-end / EOL dates on or after release (CHECK too); overwriting a lifecycle date needs a reason (`technology_lifecycle_event`, entity FIRMWARE); approving a release needs a source reference, an active product and a different person from the last draft editor; after approval the identity is locked; withdraw / reopen need a reason. Compatibility: model must match the asset type (and make when given), make / model must be visible in the row's scope, no two active rows for the same release + type + make + model + hardware revision; approval needs evidence, an approved (not Draft / Withdrawn) release, and a different person from the last editor. Errors `54850-54872`; 54850 / 54851 / 54857 / 54866 -> 404, 54855 -> 409.

### Technology catalogue -- operating systems (427)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `tech-catalog/os?organizationId=` | `{products, releases}` with compatibility counts | `sp_asset_os_list` |
| GET | `tech-catalog/os/releases/{id}?organizationId=` | `{release, compatibility, lifecycleEvents, history}` | `sp_asset_os_release_get` |
| GET | `tech-catalog/models/{id}/os?organizationId=` | Approved, active OS compatibility for the model (match level, architecture match, minimum firmware) | `sp_asset_model_os_list` |
| POST | `tech-catalog/os/products` | `{organizationId, shared?, productId?, publisherMakeId, family?, productName, description?, status?, expectedRecordVersion?}` | `sp_asset_os_product_save` |
| POST | `tech-catalog/os/releases` | All BRD 4.5 release fields + `changeReason` | `sp_asset_os_release_save` |
| POST | `tech-catalog/os/releases/{id}/transition` | `AssetCatalogTransitionRequest` | `sp_asset_os_release_transition` |
| POST | `tech-catalog/os/compatibility` | `{organizationId, shared?, compatId?, releaseId, assetTypeId, makeId?, modelId?, processorArchitecture?, minFirmwareReleaseId?, firmwarePrerequisite?, exclusions?, evidence?, reviewer?, isActive?, expectedRecordVersion?}` | `sp_asset_os_compat_save` |
| POST | `tech-catalog/os/compatibility/{id}/approve` | `AssetCatalogApproveRequest` (proxy: APPROVE) | `sp_asset_os_compat_approve` |

Rules mirror 426: unique product (publisher + family + name) and release (product + edition + version + build + architecture); end dates on or after release (CHECK too); lifecycle-date overwrite needs a reason (`technology_lifecycle_event`, entity OS); approval needs a source reference, an active product and a different person from the last draft editor; identity locked after approval; the replacement release must be another release visible in the scope; compatibility rows need evidence, an approved release and a different approver, and return to Draft when edited. Errors `54910-54932`; 54910 / 54911 / 54917 / 54926 -> 404, 54915 -> 409.

API consolidation in 427: the model (425), firmware (426) and OS (427) status moves share one request type (`AssetCatalogTransitionRequest`, replacing `AssetModelTransitionRequest` / `AssetFirmwareTransitionRequest`) and one service binding (`CatalogTransitionAsync`); the two compatibility approvals share `AssetCatalogApproveRequest` / `CatalogApproveAsync`. Routes and JSON bodies are unchanged.

### Asset Register (428)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `register?organizationId=&search=&assetTypeId=&statusCode=&pageNumber=&pageSize=` | Paged asset list with status, phase, template version | `sp_asset_register_list` |
| GET | `register/{id}?organizationId=` | `{asset, values, history}` -- stored values by field key | `sp_asset_register_get` / `fn_asset_stored_values` |
| GET | `register/form?organizationId=&assetTypeId=` or `&templateId=` | Form definition (same shape as `templates/{id}`) | `sp_asset_register_form` -> `sp_asset_form_template_get` |
| GET | `register/lookups?organizationId=&sources=MASTER:...` | `{source, value, label, parentValue}` for pickers | `sp_asset_register_lookups` / `fn_asset_master_lookup` |
| POST | `register/evaluate` | `{organizationId, templateId, values}` -> visibility / mandatory (VIEW) | `sp_asset_form_template_evaluate` / `fn_asset_form_evaluate` |
| POST | `register` | `{organizationId, assetId?, assetTypeId?, values, hiddenDecisions?, expectedRecordVersion?}` -> `{success, result, id, issues}`; 200 SAVED, 400 INVALID / NEEDS_DECISION, 404 / 409 for refusals | `sp_asset_register_save` |

Proxy area `asset-register`: GET and evaluate VIEW; save ADD for a new asset, EDIT for an existing one. (429 adds `pendingOnly=true` to the list and `pendingChangeId` / `pendingToStatusName` to its rows.) Save order: org / asset / version checks -> asset type (selectable when set or changed; cannot change once set) -> template (pinned, else Active) -> stored + submitted values (template defaults for a new asset; taxonomy and legal entity derived) -> rules -> hidden-value decisions -> mandatory -> data types -> lookup values -> `asset_field_validation_rule` -> model / make / type -> serial and compatibility warnings -> unique asset name -> write (COLUMN fields to the asset row, VALUE fields to `asset_field_value`, Draft state on create) -> audit. Errors raised: `54950-54955`.

### Asset lifecycle transitions (429)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `register/{id}/lifecycle?organizationId=` | `{current, moves, changes}` -- status + record version; the moves open from it with gate (BRD source, wording, mapping note, reason / reference label / evidence / approval / saved-on-form / owner, `blockedReason`), none while a change awaits approval; every lifecycle change | `sp_asset_lifecycle_get` |
| GET | `register/lifecycle-matrix?organizationId=` | Every Asset transition rule with its gate and `isActive` (D16 review) | `sp_asset_lifecycle_matrix` |
| POST | `register/{id}/transition` | `{organizationId, toStatusCode, reasonText?, referenceText?, evidenceText?, expectedRecordVersion?}` -> `{success, result: COMPLETED \| PENDING_APPROVAL, id: changeId}` | `sp_asset_lifecycle_transition` |
| POST | `register/lifecycle-changes/{id}/decide` | `{organizationId, decision: APPROVE \| REJECT \| CANCEL, decisionNote?, expectedRecordVersion?}` -> `{success, result: APPROVED \| REJECTED \| CANCELLED, id}` | `sp_asset_lifecycle_decide` |

Proxy: GETs VIEW; transition EDIT; decide APPROVE / REJECT needs APPROVE, CANCEL needs EDIT. Transition order: organization -> asset (status from `current_status_id`, else the legacy map) -> record version -> no change awaiting approval -> Disposed / Archived -> Active refused (54975) -> configured, active rule (else 54974 listing the configured moves) -> saved on form -> owner -> reason -> reference -> evidence -> approval gate ? record PENDING_APPROVAL : apply. Apply (`sp_asset_lifecycle_apply`): re-check status, `sp_pm_state_transition` (log + audit), set `current_status_id` (optimistic), legacy lifecycle via `sp_event_raise_asset_lifecycle` (COMMISSION / DECOMMISSION, trigger source `AssetLifecycle`) or a direct update; then the `asset_lifecycle_change` row and an `asset-lifecycle` audit row. Errors `54970-54988`; 54970 / 54971 / 54981 -> 404, 54972 / 54973 / 54986 / 54987 -> 409.

### Installed technology (430)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `register/{id}/technology?organizationId=` | `{status, firmwareHistory, osHistory, exceptions}` -- `status`: one row per technology (kind, applicable, current release + label, release status, build / patch, minimum compliant / latest approved build, support end, EOL, compatible, recommended release + label, active exception + expiry, classification + reason, record version) | `sp_asset_technology_get` / `fn_asset_technology_status` |
| POST | `register/{id}/technology/installations` | `{organizationId, kind: FIRMWARE \| OS, releaseId, installedDate, source, result? (firmware: SUCCESSFUL \| FAILED), buildPatchLevel? (OS), rollbackNote? (firmware), licenceReference? (OS), evidenceText?, expectedRecordVersion?}` -> `{success, result, id: installationId}` | `sp_asset_tech_install_record` |
| POST | `register/{id}/technology/exceptions` | `{organizationId, scope: ASSET \| MODEL, kind, releaseId, reason, compensatingControls, ownerEmployeeId, expiryDate, reviewDate?}` -> `{success, result: PENDING_APPROVAL, id: exceptionId}` | `sp_asset_tech_exception_request` |
| POST | `register/technology-exceptions/{id}/decide` | `{organizationId, decision: APPROVE \| REJECT \| WITHDRAW \| REVOKE, decisionNote?, expectedRecordVersion?}` | `sp_asset_tech_exception_decide` |

Proxy: GET VIEW; installations and exception requests EDIT; decide APPROVE / REJECT / REVOKE needs APPROVE, WITHDRAW needs EDIT. Rules: release visible to the organization (installation: firmware not Draft / Withdrawn, OS not Draft; exception: not Draft); installed date required, not in the future; source required; a successful installation needs an approved compatibility row for the asset's model (`fn_asset_tech_compatible`) or an active exception (`fn_asset_tech_exception_active`), becomes current, keeps the previous version and updates the form fields (`firmware_version`, `operating_system`, `os_build_patch_level`); a failed firmware installation is history only. Exceptions: reason and controls required, active owner of the organization, expiry after today, review between today and expiry, no second pending / active exception for the same scope and version; requester cannot approve or reject; reject and revoke need a note; approving an expired request is refused. Form saves that change firmware / OS / patch level write a history row (source "Asset form"). Errors `54320-54342`; 54320 / 54321 / 54335 -> 404, 54322 / 54334 / 54340 -> 409.

### Custody and attestation (431)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `register/{id}/custody?organizationId=` | `{state, assignments, attestations}` -- verification status, last / next attestation date, applicable profile; assignment history; the asset's occurrences | `sp_asset_custody_get` |
| GET | `attestation/profiles?organizationId=` | `{profiles, scopes}` (scopes = categories, subcategories, asset types for the picker) | `sp_asset_attestation_profiles` |
| POST | `attestation/profiles` | `{organizationId, profileId?, scopeKind, scopeId, attestationRequired?, participant, frequency, customIntervalDays?, dueWindowDays, evidenceRequirement, managerApprovalRequired?, isActive?, expectedRecordVersion?}` | `sp_asset_attestation_profile_save` |
| GET | `attestation/campaigns?organizationId=` | Last 50 runs / campaigns with generated / skipped / closed / overdue counts | `sp_asset_attestation_campaigns` |
| POST | `attestation/generate` | `{organizationId, campaignType: PERIODIC \| CAMPAIGN, campaignName?, assetTypeId?, dueDate?}` -> `{success, data: {campaignId, generated, skipped, overdueMarked}}` | `sp_asset_attestation_generate` |
| GET | `attestation?organizationId=&scope=ALL\|MINE\|APPROVALS&status=&campaignId=&search=&pageNumber=&pageSize=` | Paged occurrences with snapshot, response and `canRespond` / `canApprove` for the caller | `sp_asset_attestation_list` |
| POST | `attestation/{id}/respond` | `{organizationId, response: CONFIRM \| DISAGREE, assetExists, custodyConfirmed, locationVerified, tagVerified, serialVerified, assignedUserVerified, informationCorrect, businessUseConfirmed, conditionCode, disagreementCategory?, comments?, evidenceText?, expectedRecordVersion?}` -> `result: CLOSED \| CONFIRMED \| DISPUTED` | `sp_asset_attestation_respond` |
| POST | `attestation/{id}/decide` | `{organizationId, decision: APPROVE \| RETURN \| CANCEL, decisionNote?, expectedRecordVersion?}` | `sp_asset_attestation_decide` |

Proxy area `asset-attestation`: GETs VIEW; profiles ADD / EDIT; generate ADD; respond VIEW (assignee enforced in SQL); decide APPROVE / RETURN VIEW (manager enforced in SQL), CANCEL APPROVE. Custody GET uses `asset-register` VIEW. Occurrence keys: `INITIAL:<asset>:<role>:<assignment>`, `PERIODIC:<asset>:<role>:<next date or FIRST>`, `CAMPAIGN:<campaign>:<asset>:<role>`; unique while not Cancelled. Response rules: open statuses only (Pending / In progress / Overdue); condition required; Confirm needs Asset exists + Custody confirmed and not Lost / Not found; a confirmation with an open check or a condition other than Good needs a comment; Disagree needs a category (11 BRD values) and a comment; evidence when the profile says Mandatory. Confirm -> Closed (Verified, next date by frequency, Last verified date / Verified by written) or Confirmed awaiting the manager; Disagree -> Disputed. Errors `54350-54372`; 54350 / 54352 / 54357 -> 404, 54353 / 54358 -> 409.

### Verification exceptions (432)

| Verb | Route | Purpose | Proc |
|---|---|---|---|
| GET | `attestation/exceptions?organizationId=&scope=ALL\|MINE&status=<code>\|OPEN_ALL&search=&pageNumber=&pageSize=` | Paged exceptions with SLA dates, overdue days, escalation level, `isInvestigator`, `canDecide` | `sp_asset_verification_exception_list` / `fn_asset_verification_exception_view` |
| GET | `attestation/exceptions/{id}?organizationId=` | `{exception, history}` (status history from the transition log) | `sp_asset_verification_exception_get` |
| POST | `attestation/exceptions/{id}/action` | `{organizationId, action, note?, outcome?, narrative?, closureEvidence?, secRemoteLockWipe?, secCredentialReview?, secPrivacyAssessment?, secAccessRevocation?, secMonitoring?, investigator?, expectedRecordVersion?}` -> `{success, result: <new status>, id}` | `sp_asset_verification_exception_action` |
| GET | `attestation/exception-settings?organizationId=` | `{settings, rules, employees, teams}` | `sp_asset_verification_settings_get` |
| POST | `attestation/exception-settings` | `{organizationId, assetAdministratorEmployeeId?, fallbackTeamId?, escalationLevel1Days, escalationLevel2Days, escalationLevel3Days, expectedRecordVersion?}` | `sp_asset_verification_settings_save` |
| POST | `attestation/exception-rules` | `{organizationId, category, primaryAssignment, supportingAssignment?, startSlaDays, startImmediate?, resolutionSlaDays, closureApprovalRequired?, closureEvidenceRequired?, reset?}` | `sp_asset_verification_rule_save` |

Proxy area `asset-attestation`: GETs VIEW; actions APPROVE / REJECT / REASSIGN / CANCEL need APPROVE; the investigator actions (START_REVIEW, AWAIT_EVIDENCE, RESUME, RESOLVE, CLOSE) need VIEW and are allowed by the procedure only to the investigator (or a member of the investigator team); settings and rules need EDIT. Creation: `sp_asset_attestation_respond` (re-issued) calls `sp_asset_verification_exception_create` on Disagree; the occurrence becomes Exception; `/respond` returns `result: EXCEPTION` and `exceptionId`. Due dates: start = reported + start SLA (Lost: same day), resolution = reported + resolution SLA; Await evidence pauses, Resume adds the paused days to the revised due date (original kept); reassignment never moves a date. Approval: a different person from the resolver. Errors `54410-54426`; 54410 / 54411 -> 404, 54412 / 54426 -> 409.

### Rule semantics (421 -- the BRD is silent on these, so they are stated here)
- Conditions in one group are ANDed; groups are ORed. Operators: EQ, NEQ, IN, NOT_IN (`A|B` lists), EMPTY, NOT_EMPTY, GT, GTE, LT, LTE, DATE_BEFORE_TODAY, DATE_AFTER_TODAY, DATE_WITHIN_DAYS.
- A field with active SHOW rules is visible only while one of them is true; otherwise its static Visible flag applies.
- Mandatory = static flag OR any true REQUIRE rule, and never while hidden.
- Rules cannot target baseline fields, a field cannot drive itself, loops are refused on save and reported by readiness, and a field used by a rule cannot be removed.
- Option lists: the BRD-enumerated values only (40 lists, 201 values, global `reference_option` groups `asset_field.*`). Lists the BRD leaves to the organization (building, floor, room, zone, cost centre, network zone, domain, ...) stay empty and readiness warns until the organization adds values on the Option Lists screen (423).

---

## 7. Files changed (Phase 0 + Phase 2.1)

| Layer | File | Change |
|---|---|---|
| DB | `database/419_asset_vendor_stabilization.sql` (+ rollback) | Re-issued asset save shim; new asset list shim (D-1..D-3). |
| DB | `database/420_asset_form_templates.sql` (+ rollback) | Dictionary + template tables, seeds, state machine, 13 procedures, menu, grants. |
| DB | `database/274_menu_master_seed.sql` | Three menu rows, two parent links, one root (snapshot is authoritative). |
| DB | `database/272_master_data_seed.sql` (+ rollback) | Section M: the two global masters + dictionary (insert-only); expected counts. |
| API | `Services/PracticeRepositoryService.cs` | `dependency-assets` query -> 419 list shim; field-error map 52726/52727. |
| API | `Controllers/AssetConfigController.cs`, `Services/AssetConfigService.cs`, `Models/AssetConfigModels.cs`, `Infrastructure/AssetConfigServiceRegistration.cs`, `Program.cs` | New Asset Configuration API. |
| API/Web | `appsettings.json` (both) | `PM_ORG_ADMIN`: `nav-asset-contract:VIEW`, `asset-field-dictionary:VIEW`, `asset-form-templates:*`. |
| Web | `Controllers/AssetConfigController.cs` | Proxy with session + organization + menu-grant checks. |
| Web | `Models/PracticeScreen.cs`, `Views/Practice/Manage.cshtml` | Two screens, `AssetContractGroup`, workflow-screen registration. |
| Web | `Views/Practice/Partials/asset-field-dictionary.cshtml`, `asset-form-templates.cshtml` | New screens (existing page heading, toolbar, grid, pm-grid pager, portalled 3-dot menu, `.pm-modal`, `.pm-tabs`, tokens only). |
| Web | `wwwroot/js/AssetConfig/asset-field-dictionary.js`, `asset-form-templates.js` | Screen scripts. |

Existing Settings -> Dependencies -> Assets / Vendors screens are unchanged in layout and keep working; only the defects above were fixed.

### Phase 2.2 files (421)
| Layer | File | Change |
|---|---|---|
| DB | `database/421_asset_form_rules.sql` (+ rollback) | Option values, 13 dictionary corrections (versioned + audited), rule tables, rule save/remove, evaluate, re-issued get / readiness / new_version / field_remove. |
| DB | `database/272_master_data_seed.sql` | Section N (option values); section M rows corrected to match 421. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | rules, rules/remove, evaluate; get returns rules / conditions / options. |
| Web | `Controllers/AssetConfigController.cs` | evaluate needs VIEW. |
| Web | `asset-form-templates.cshtml` / `.js` | Rules tab + rule modal (condition builder with OR groups), Preview tab. |

### Phase 2.3 files (422)
| Layer | File | Change |
|---|---|---|
| DB | `database/422_asset_valuation_config.sql` (+ rollback) | 4 tables, lifecycle, `fn_asset_value_calc`, 9 procedures, re-issued template get / readiness, menu + grants. |
| DB | `database/274_menu_master_seed.sql` | `asset-valuation-config` row + parent link. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 8 valuation endpoints; 54251 / 54253 status mapping. |
| API/Web | `appsettings.json` (both) | `PM_ORG_ADMIN`: `asset-valuation-config:*`. |
| Web | `Controllers/AssetConfigController.cs`, `PracticeScreen.cs`, `Manage.cshtml` | Valuation routes + permissions, new screen registration. |
| Web | `Partials/asset-valuation-config.cshtml`, `js/AssetConfig/asset-valuation-config.js` | Asset Valuation screen: versions list; CIA Scales / Valuation Method / Value Bands / Criticality / Calculator / Readiness / History tabs. |

### Phase 2.4 files (423)
| Layer | File | Change |
|---|---|---|
| DB | `database/423_asset_option_lists.sql` (+ rollback) | `asset_option_list_master`, `asset_field_option_org`, `fn_asset_field_options`, 4 procedures, re-issued template get / readiness (options from the organization's effective list, with parent value), menu + grants. |
| DB | `database/274_menu_master_seed.sql` | `asset-option-lists` row + parent link. |
| DB | `database/272_master_data_seed.sql` (+ rollback) | Section O: option-list catalogue (insert-only). |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 4 option-list endpoints; 54270 / 54276 / 54279 -> 404. |
| API/Web | `appsettings.json` (both) | `PM_ORG_ADMIN`: `asset-option-lists:*`. |
| Web | `Controllers/AssetConfigController.cs`, `PracticeScreen.cs`, `Manage.cshtml` | `option-lists` routes + permissions, new screen registration. |
| Web | `Partials/asset-option-lists.cshtml`, `js/AssetConfig/asset-option-lists.js` | Option Lists screen: catalogue (search, scope filter) -> list values with add / edit / retire / reactivate, and relabel / hide / show / reset for defaults. |

### Phase 2.5 files (424)
| Layer | File | Change |
|---|---|---|
| DB | `database/424_asset_taxonomy_governance.sql` (+ rollback) | Governance columns on the three masters, `asset_type_org_default`, `fn_asset_taxonomy_selectable`, `fn_asset_make_code`, 5 procedures; re-issued `sp_get_asset_taxonomy_lookup` (241), `sp_asset_form_template_create` (420) and `sp_org_dependency_assets_repository_manage` (419) -- generated from the earlier bodies with only the taxonomy checks replaced; menu + Admin VIEW / EDIT. The rollback restores those three bodies verbatim. |
| DB | `database/274_menu_master_seed.sql` | `asset-taxonomy` row (355) + parent link. 272 unchanged (it seeds the original columns only). |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 5 taxonomy endpoints; 404 / 409 mapping. |
| API/Web | `appsettings.json` (both) | `PM_ORG_ADMIN`: `asset-taxonomy:VIEW`, `asset-taxonomy:EDIT` (EDIT = organization defaults; the proxy keeps global writes to PM_ADMIN). |
| Web | `Controllers/AssetConfigController.cs`, `PracticeScreen.cs`, `Manage.cshtml` | taxonomy routes + permission rules, new screen registration. |
| Web | `Partials/asset-taxonomy.cshtml`, `js/AssetConfig/asset-taxonomy.js` | Asset Taxonomy screen: Categories / Subcategories / Asset Types tabs with filters, add / edit modal (platform administrator; read-only view for others), Organization defaults modal on asset types. |

### Phase 3.1 files (425)
| Layer | File | Change |
|---|---|---|
| DB | `database/425_asset_technology_catalog.sql` (+ rollback) | `asset_make`, `asset_make_asset_type`, `asset_model`, `technology_lifecycle_event`; AssetModel lifecycle (4 statuses, 7 rules); 5 procedures; menu + Admin VIEW / ADD / EDIT / APPROVE. |
| DB | `database/274_menu_master_seed.sql` | `asset-tech-catalog` row (356) + parent link. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 5 endpoints; 404 / 409 mapping. |
| API/Web | `appsettings.json` (both) | `PM_ORG_ADMIN`: `asset-tech-catalog:*`. |
| Web | `Controllers/AssetConfigController.cs`, `PracticeScreen.cs`, `Manage.cshtml` | tech-catalog routes, shared-scope check, screen registration. |
| Web | `Partials/asset-tech-catalog.cshtml`, `js/AssetConfig/asset-tech-catalog.js` | Technology Catalogue screen: Makes / Models tabs with filters; make modal (supported asset types); model modal with Details / History tabs and Submit / Approve / Return / Withdraw / Reopen. |

### Phase 3.2 files (426)
| Layer | File | Change |
|---|---|---|
| DB | `database/426_asset_firmware_catalog.sql` (+ rollback) | `asset_firmware_product`, `asset_firmware_release`, `asset_firmware_compatibility`; FirmwareRelease lifecycle (8 statuses, 26 rules); 8 procedures. No menu change (same screen). |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 8 firmware endpoints, `ReadOrNotFound` helper; 404 / 409 mapping. |
| Web | `Controllers/AssetConfigController.cs` | `.../approve` needs APPROVE. |
| Web | `Partials/asset-tech-catalog.cshtml`, `js/AssetConfig/asset-tech-catalog.js` | Firmware tab (products + releases with filters), product modal, release modal (Details / Compatibility / History, status buttons from the 426 rules), compatibility modal, Firmware tab on the model modal. |

### Phase 3.3 files (427)
| Layer | File | Change |
|---|---|---|
| DB | `database/427_asset_os_catalog.sql` (+ rollback) | `asset_os_product`, `asset_os_release`, `asset_os_compatibility`; OsRelease lifecycle (7 statuses, 18 rules); 8 procedures. No menu change. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 8 OS endpoints; shared transition / approval request types and bindings (see above); 404 / 409 mapping. |
| Web | `Controllers/AssetConfigController.cs` | comment only -- the tech-catalog rules already cover `os/...`. |
| Web | `Partials/asset-tech-catalog.cshtml`, `js/AssetConfig/asset-tech-catalog.js` | Operating Systems tab; the product / release / compatibility dialogs now serve both catalogues (`data-kind="fw"` / `"os"` fields, one `KIND` table in the script) instead of separate copies; Operating Systems tab on the model dialog. |

### Phase 4.1 files (428)
| Layer | File | Change |
|---|---|---|
| DB | `database/428_asset_register_core.sql` (+ rollback) | Asset statuses + phases + legacy map, asset columns (template_id, current_status_id, record_version) with backfill, `asset_field_value`, `asset_field_validation_rule` (31 rules from the dictionary text), `fn_asset_form_evaluate` (421 logic, re-issued evaluate proc reads it), `fn_asset_master_lookup`, `fn_asset_stored_values`, 5 register procedures, menu + Admin VIEW / ADD / EDIT. The rollback restores the 421 evaluate body verbatim. |
| DB | `database/274_menu_master_seed.sql` | `asset-register` row (349) + parent link. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 6 register endpoints; template-detail reader shared by the designer and the register form; save result model. |
| API/Web | `appsettings.json` (both) | `PM_ORG_ADMIN`: `asset-register:*`. |
| Web | `Controllers/AssetConfigController.cs`, `PracticeScreen.cs`, `Manage.cshtml` | register routes (ADD vs EDIT by assetId), screen registration. |
| Web | `Partials/asset-register.cshtml`, `js/AssetConfig/asset-register.js` | Asset Register: paged list with type / status filters; asset type step; dynamic form by section and data type (pickers from option lists and masters, make filters models), live rule evaluation, issues panel with keep / clear decisions, status history. |

### Phase 4.2 files (429)
| Layer | File | Change |
|---|---|---|
| DB | `database/429_asset_lifecycle_transitions.sql` (+ rollback) | 75 Asset transition rules + `asset_lifecycle_transition_gate`, `asset_lifecycle_change` (one pending per asset), `sp_asset_lifecycle_apply` / `_transition` / `_decide` / `_get` / `_matrix`, `sp_asset_register_list` re-issued (pending change + filter), Admin APPROVE on Asset Register. The rollback restores the 428 list body verbatim. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 4 lifecycle endpoints, `pendingOnly` on the list, `AssetLifecycleTransitionRequest` / `AssetLifecycleDecisionRequest` / `AssetLifecycleResult`. |
| Web | `Controllers/AssetConfigController.cs` | transition EDIT; decide APPROVE / REJECT -> APPROVE, CANCEL -> EDIT. |
| Web | `Partials/asset-register.cshtml`, `js/AssetConfig/asset-register.js` | Lifecycle tab (pending change with Approve / Reject / Cancel, moves with BRD gate and needs, change history), move dialog asking only for what the gate requires, "Pending approval only" filter and "awaiting" note in the list, Transition rules dialog. |

No menu, appsettings or `274` change: Asset Register already exists and `PM_ORG_ADMIN` has `asset-register:*`.

### Phase 4.3 files (430)
| Layer | File | Change |
|---|---|---|
| DB | `database/430_asset_installed_technology.sql` (+ rollback) | `asset_firmware_installation`, `asset_os_installation` (one current row per asset; starting rows for existing values), `asset_technology_exception` (one pending per scope + version), `fn_asset_tech_compatible`, `fn_asset_tech_exception_active`, `fn_asset_fw_release_label`, `fn_asset_os_release_label`, `fn_asset_technology_status`, `sp_asset_tech_install_apply` / `_record`, `sp_asset_tech_exception_request` / `_decide`, `sp_asset_technology_get`; `sp_asset_register_save` re-issued (exception rule + history write; generated from the 428 body, 14 lines replaced, 41 added). The rollback restores the 428 save body verbatim. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 4 technology endpoints; `AssetTechInstallRequest`, `AssetTechExceptionRequest`; the 429 one-row write helper generalised (`ResultRowWriteAsync`, `ResultWritten`) and shared by lifecycle and technology writes. |
| Web | `Controllers/AssetConfigController.cs` | technology POSTs EDIT; decide REVOKE added to the APPROVE decisions. |
| Web | `Partials/asset-register.cshtml`, `js/AssetConfig/asset-register.js` | Technology tab (status with classification and recommended target, firmware / OS history, exceptions with Approve / Reject / Withdraw / Revoke), installation dialog (fields per technology), exception dialog. |

### Phase 4.4 files (431)
| Layer | File | Change |
|---|---|---|
| DB | `database/431_asset_custody_attestation.sql` (+ rollback) | `asset_assignment_history` (starting row per asset), `asset_attestation_profile`, `asset_attestation_campaign`, `asset_attestation`, `asset_attestation_state`; `fn_asset_attestation_profile_for`, `fn_asset_attestation_next_date`; 12 procedures (create, snapshot, field value set, close verified, profile save, generate, respond, decide, profiles, campaigns, list, custody get); `sp_asset_register_save` re-issued from the 430 body with one call added (the rollback restores the 430 body verbatim); menu `asset-attestation` (357) + Admin VIEW / ADD / EDIT / APPROVE. |
| DB | `database/274_menu_master_seed.sql` | `asset-attestation` row + parent link. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 8 routes; `AssetAttestationProfileSaveRequest`, `AssetAttestationGenerateRequest`, `AssetAttestationRespondRequest`; decisions reuse `AssetLifecycleDecisionRequest`. |
| API/Web | `appsettings.json` (both) | `PM_ORG_ADMIN`: `asset-attestation:*`. |
| Web | `Controllers/AssetConfigController.cs`, `PracticeScreen.cs`, `Manage.cshtml` | attestation routes, screen registration. |
| Web | `Partials/asset-attestation.cshtml`, `js/AssetConfig/asset-attestation.js` (new) | My attestations / My approvals / All occurrences (respond, approve, return, cancel), Runs and campaigns, Profiles. |
| Web | `Partials/asset-register.cshtml`, `js/AssetConfig/asset-register.js` | Custody tab. |

### Phase 4.5a files (432)
| Layer | File | Change |
|---|---|---|
| DB | `database/432_asset_verification_exceptions.sql` (+ rollback) | Exception statuses + 20 transition rules (entity AssetVerificationException), `asset_verification_sla_rule` (11 BRD defaults), `asset_verification_settings`, `asset_verification_exception` (one per attestation response); `fn_asset_verification_rule`, `fn_asset_verification_exception_view`; create / action / list / get / settings get / settings save / rule save procedures; `sp_asset_attestation_respond` and `sp_asset_custody_get` re-issued from their 431 bodies (one call and one result set added; the rollback restores the 431 bodies verbatim); exceptions created for existing disagreements. |
| API | `AssetConfigController.cs`, `AssetConfigService.cs`, `AssetConfigModels.cs` | 6 routes; `AssetVerificationActionRequest`, `AssetVerificationSettingsSaveRequest`, `AssetVerificationRuleSaveRequest`; custody reads the 4th result set. |
| Web | `Controllers/AssetConfigController.cs` | exception action / settings / rules permissions. |
| Web | `Partials/asset-attestation.cshtml`, `js/AssetConfig/asset-attestation.js` | Exceptions tab (list, detail dialog with actions, security review, history), Exception settings tab (settings form, rules with override / reset), Exception / Resolved statuses. |
| Web | `Partials/asset-register.cshtml`, `js/AssetConfig/asset-register.js` | Custody tab: verification exceptions. |

## 8. Verification (static -- no compiler or database on this machine)

Executed:
- SQL sweep on 419, 420 (+ rollbacks), 272, 274: balanced parentheses; BEGIN/CASE vs END balanced; BEGIN TRAN = COMMIT; no expression passed as an EXEC parameter; no aggregate over a subquery; no `INSERT ... EXEC` (readiness is called with `@suppress_result = 1`); ASCII-only; LF line endings.
- Every `@parameter` the C# service passes exists on the target procedure, and every procedure parameter without a default is passed.
- Every property the two scripts read from API rows is a column alias of the procedures (or the existing employee / organization lookups).
- `node --check` on both scripts: pass.
- Razor `@` scan on both partials: only real directives.
- `appsettings.json` (Web, API) still parse as JSON.

421 got the same sweep (parentheses, BEGIN/CASE/END, TRAN/COMMIT, EXEC arguments, aggregate-over-subquery, INSERT-EXEC, ASCII), the C#-to-procedure parameter cross-check for all 15 procedures, the JS-to-column-alias check, `node --check`, and the Razor `@` scan.

Not executed (needs the build/test environment): `dotnet build`, the migrations against SQL Server, and the UI. The runtime test scripts are the "UAT" blocks at the end of 419, 420 and 421. Until those pass, treat Phases 0, 2.1, 2.2 and 2.3 as **implemented, not yet tested**. (421's UAT verification rows were reported PASS by the user on 2026-10-03 after a re-run; a PRINT-with-subquery error in 421 was fixed then.)

422 got the same sweep, including a new check for subqueries inside PRINT / RAISERROR / THROW (the 421 trap), the C#-to-procedure parameter cross-check, the JS-to-alias check, `node --check` and the Razor scan.

423 got the same sweep (parentheses, BEGIN/CASE/END, TRAN/COMMIT, EXEC arguments, aggregate-over-subquery, PRINT/RAISERROR/THROW subqueries, ASCII), the C#-to-procedure parameter cross-check for all 4 new procedures (no missing or extra parameters), the JS-to-column-alias check, `node --check` and the Razor scan. Not compiled or executed.

424 got the same sweep (clean), the C#-to-procedure parameter cross-check for all 5 new procedures (no extra, missing or unpassed parameters), the JS-to-alias check, `node --check`, the Razor scan, and an assertion that each re-issued body differs from its source only in the replaced taxonomy checks. Not compiled or executed.

Remaining for later phases: template inheritance from category / subcategory templates (BRD 5.2.1), Default Lifecycle Profile on the asset type (needs the Phase 4 lifecycle), make / model / firmware / OS (Phase 3).

425 got the same sweep (clean), the C#-to-procedure parameter cross-check for all 5 procedures (no extra, missing or unpassed parameters), the JS-to-alias check, `node --check` and the Razor scan. Not compiled or executed. Deferred from BRD 4.3: blocking / approving asset creation for Legacy, Unsupported or Retired models (Asset Register, Phase 4), extended commercial support records (contracts, Phase 5), impact analysis and refresh campaigns (4.7 steps 4-8).

426 got the same sweep (clean), the C#-to-procedure parameter cross-check for all 8 procedures, the JS-to-alias check, `node --check`, the ASCII check and the Razor scan. Not compiled or executed.

427 got the same sweep (clean), the C#-to-procedure parameter cross-check for all 8 procedures (including the shared transition / approval bindings, re-checked against 425 / 426), the JS-to-alias check, an HTML-id check (every id the script uses exists, no duplicates), `node --check`, the ASCII check and the Razor scan. Not compiled or executed.

428 got the same sweep (clean), the C#-to-procedure parameter cross-check for all 5 register procedures, the JS-to-alias check, `node --check`, the ASCII check and the Razor scan. Its verification block also checks that every COLUMN dictionary field is mapped and every validation rule names dictionary fields. Not compiled or executed. Not yet in 4.1: dependent option-list filtering on the form (building -> floor -> room), which the save does not enforce either.

428 first run (2026-10-04): every section ran except `sp_asset_register_save`, which failed to compile with Msg 468 (collation conflict) -- OPENJSON returns `[key]` as Latin1_General_BIN2 and it was joined to a table-variable column in the database collation. Fixed with `COLLATE DATABASE_DEFAULT` on that join; the static sweep now flags OPENJSON `[key]` comparisons without COLLATE. 428 is re-runnable, so it is simply run again.

429 got the same sweep (clean -- one false positive from `--` inside a string literal was removed by rewording the text), the C#-to-procedure parameter cross-check for the 3 new bound procedures and the re-issued list (no extra or unpassed parameters), the JS-to-alias check, an HTML-id check, `node --check`, the ASCII check and the Razor scan. Its verification block checks that every rule has a gate, no rule leads out of Disposed / Archived except Disposed -> Archived, every non-terminal status has a way out, and the Admin APPROVE grant. Not compiled or executed. Not yet enforced (shown as gate text only): checklists (Phase 6), coverage (Phase 5), dependency / relationship checks (Phase 7), owner-change hand-over steps (4.4), Lost / Stolen verification exception and security review (4.5).

430 got the same sweep (clean -- apostrophes in comments were reworded so the older string-stripping sweep agrees), the C#-to-procedure parameter cross-check for the 4 new bound procedures (no extra or unbound required parameters), a check that the rollback's save body is byte-identical to the 428 body, the JS-to-alias check, an HTML-id check (no missing or duplicate ids), `node --check`, the ASCII check and the Razor scan. Its verification block checks the tables and indexes, that every firmware / OS value has a current history row, the re-issued save, the objects, and two status rows per asset. Not compiled or executed. Not yet done: assessment gap + validation task for Unknown and upgrade / replacement campaigns (Phase 6), automatic Non-Compliant status (BRD "can"; available as a lifecycle move), technology exceptions in the Exception Centre list.

431 got the same sweep (clean; the 274 batch-1 parenthesis note is a pre-existing false positive from `--` inside a RAISERROR string, identical in the committed version), the C#-to-procedure parameter cross-check for all 8 bound procedures (no extra or unbound required parameters), a check that the re-issued save is the 430 body plus one call and that the rollback body is byte-identical to the 430 body, the JS-to-alias check, HTML-id checks on both screens, `node --check` on both scripts, both `appsettings.json` parse, the ASCII check and the Razor scan. Not compiled or executed. Not yet done: Asset Verification Exceptions, category tasks and SLA (4.5 / Phase 6), reminders and escalations (Phase 6), delegated authority, Transfer / Return / Event occurrence types (raised by the 4.5 workflows), business-day due windows.

432 got the same sweep (clean), the C#-to-procedure parameter cross-check for all 6 bound procedures (no extra or unbound required parameters), a check that the re-issued respond / custody procedures are their 431 bodies plus the marked additions and that the rollback bodies are byte-identical to 431, the JS-to-alias check, HTML-id checks on both screens, `node --check` on both scripts, the ASCII check and the Razor scan. Not compiled or executed. Not yet done: category tasks and task SLAs, notifications and escalation messages (Phase 6), security incident integration, business-day SLAs, approved SLA extensions.
