
-- =====================================================================
-- 3. Functions
-- =====================================================================
-- First run date on or after @from: every day, a weekday (1 Monday ..
-- 7 Sunday; 1900-01-01 was a Monday, so no dependence on DATEFIRST) or a
-- day of the month (1-28, present in every month).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_report_next_run
(
    @frequency    NVARCHAR(10),
    @day_of_week  TINYINT,
    @day_of_month TINYINT,
    @from         DATE
)
RETURNS TABLE
AS
RETURN
    SELECT MIN(c.d) AS NextRunDate
      FROM (SELECT DATEADD(DAY, n.n, @from) AS d
              FROM (VALUES (0), (1), (2), (3), (4), (5), (6), (7), (8), (9), (10), (11), (12), (13), (14), (15),
                           (16), (17), (18), (19), (20), (21), (22), (23), (24), (25), (26), (27), (28), (29), (30), (31)) n(n)) c
     WHERE @frequency = N'DAILY'
        OR (@frequency = N'WEEKLY' AND DATEDIFF(DAY, CAST('19000101' AS DATE), c.d) % 7 + 1 = @day_of_week)
        OR (@frequency = N'MONTHLY' AND DAY(c.d) = @day_of_month);
GO

-- An active employee who may act on the organization: the sign-in rule
-- (PracticeAuthenticationService) -- active record, and the organization
-- is the employee organization or mapped to the employee in
-- user_organization_map.
CREATE OR ALTER FUNCTION grac_practice.fn_asset_report_employee_in_org (@organization_id BIGINT, @employee_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT e.employee_id AS EmployeeId, e.employee_name AS EmployeeName, e.email AS Email
      FROM grac_practice.organization_employee e
      JOIN grac_practice.record_status_master rs ON rs.record_status_id = e.record_status_id
     WHERE e.employee_id = @employee_id AND e.status = N'Active'
       AND (rs.status_code = N'ACTIVE' OR rs.status_name = N'Active')
       AND (e.organization_id = @organization_id
            OR EXISTS (SELECT 1 FROM grac_practice.user_organization_map m
                        WHERE m.organization_id = @organization_id AND m.status = N'Active'
                          AND LOWER(m.user_email) IN (LOWER(e.email), LOWER(e.employee_code))));
GO

-- The menu permissions of an employee: the sign-in rule (primary role plus
-- every active assigned role; Active grants on Active menu rows).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_report_employee_access (@employee_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT m.menu_key AS MenuKey,
           CAST(MAX(CAST(p.can_view AS INT)) AS BIT) AS CanView,
           CAST(MAX(CAST(p.can_approve AS INT)) AS BIT) AS CanApprove
      FROM grac_practice.organization_role_menu_permission p
      JOIN grac_practice.menu_master m ON m.menu_id = p.menu_id AND m.status = N'Active'
     WHERE p.status = N'Active'
       AND p.role_id IN (SELECT er.role_id FROM grac_practice.organization_employee_role er
                          WHERE er.employee_id = @employee_id AND er.status = N'Active'
                         UNION
                         SELECT e.role_id FROM grac_practice.organization_employee e
                          WHERE e.employee_id = @employee_id AND e.role_id IS NOT NULL)
     GROUP BY m.menu_key;
GO
PRINT '453: functions created.';
GO

-- =====================================================================
-- 4. Schedules: list and save
-- =====================================================================
-- 1. schedules of the reports the caller may view   2. recipients
-- 3. active employees of the organization          4. active roles
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_schedules
    @organization_id BIGINT,
    @allowed_areas   NVARCHAR(2000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53120, 'Organization not found.', 1;
    DECLARE @areas NVARCHAR(2004) = N',' + REPLACE(ISNULL(@allowed_areas, N''), N' ', N'') + N',';

    SELECT s.schedule_id AS ScheduleId, s.schedule_name AS ScheduleName, s.report_code AS ReportCode, d.report_name AS ReportName,
           d.family_name AS FamilyName, s.search_text AS SearchText, s.status_code AS StatusCode, s.asset_type_id AS AssetTypeId,
           s.days AS Days, s.date_window_days AS DateWindowDays, s.frequency AS Frequency, s.day_of_week AS DayOfWeek,
           s.day_of_month AS DayOfMonth, s.retention_days AS RetentionDays, s.next_run_date AS NextRunDate, s.is_active AS IsActive,
           ow.employee_name AS OwnerName, ld.status AS LastStatus, ld.started_dt AS LastRunDt, ld.delivered_count AS LastDelivered,
           ld.skipped_count AS LastSkipped, ld.failed_count AS LastFailed, rc.names AS Recipients,
           CONVERT(BIGINT, s.record_version) AS RecordVersion
      FROM grac_practice.asset_report_schedule s
      JOIN grac_practice.asset_report_definition d ON d.report_code = s.report_code
      LEFT JOIN grac_practice.organization_employee ow ON ow.employee_id = s.owner_employee_id
      LEFT JOIN grac_practice.asset_report_delivery ld ON ld.delivery_id = s.last_delivery_id
     OUTER APPLY (SELECT STRING_AGG(CAST(CASE WHEN r.recipient_kind = N'ROLE' THEN CONCAT(rl.role_name, N' (role)')
                                              ELSE e.employee_name END AS NVARCHAR(MAX)), N'; ') AS names
                    FROM grac_practice.asset_report_schedule_recipient r
                    LEFT JOIN grac_practice.organization_employee e ON e.employee_id = r.employee_id
                    LEFT JOIN grac_practice.organization_role rl ON rl.role_id = r.role_id
                   WHERE r.schedule_id = s.schedule_id) rc
     WHERE s.organization_id = @organization_id AND CHARINDEX(N',' + d.view_area + N',', @areas) > 0
     ORDER BY s.is_active DESC, s.schedule_name, s.schedule_id;

    SELECT r.schedule_id AS ScheduleId, r.recipient_kind AS RecipientKind, r.employee_id AS EmployeeId, r.role_id AS RoleId,
           CASE WHEN r.recipient_kind = N'ROLE' THEN rl.role_name ELSE e.employee_name END AS Name
      FROM grac_practice.asset_report_schedule_recipient r
      JOIN grac_practice.asset_report_schedule s ON s.schedule_id = r.schedule_id AND s.organization_id = @organization_id
      LEFT JOIN grac_practice.organization_employee e ON e.employee_id = r.employee_id
      LEFT JOIN grac_practice.organization_role rl ON rl.role_id = r.role_id
     ORDER BY r.schedule_id, r.recipient_kind, Name;

    SELECT e.employee_id AS EmployeeId, e.employee_name AS EmployeeName, e.email AS Email
      FROM grac_practice.organization_employee e
     WHERE e.organization_id = @organization_id AND e.status = N'Active'
     ORDER BY e.employee_name;

    SELECT r.role_id AS RoleId, r.role_name AS RoleName
      FROM grac_practice.organization_role r
     WHERE r.organization_id = @organization_id AND r.status = N'Active'
     ORDER BY r.role_name;
END
GO

-- New when @schedule_id is NULL. The report is fixed once saved. Filters
-- the report does not take are dropped; a status must be one of its
-- options (the sp_asset_report_run rule). Recipients: JSON array of
-- {"kind": "EMPLOYEE" | "ROLE", "id": n}; the list is replaced. A new
-- schedule, a changed frequency / day or a reactivation recomputes the
-- next run date from today.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_schedule_save
    @organization_id         BIGINT,
    @schedule_id             BIGINT         = NULL,
    @report_code             NVARCHAR(40)   = NULL,
    @schedule_name           NVARCHAR(160)  = NULL,
    @search                  NVARCHAR(200)  = NULL,
    @status                  NVARCHAR(60)   = NULL,
    @asset_type_id           INT            = NULL,
    @days                    INT            = NULL,
    @date_window_days        INT            = NULL,
    @frequency               NVARCHAR(10)   = NULL,
    @day_of_week             TINYINT        = NULL,
    @day_of_month            TINYINT        = NULL,
    @retention_days          INT            = NULL,
    @is_active               BIT            = 1,
    @recipients_json         NVARCHAR(MAX)  = NULL,
    @expected_record_version BIGINT         = NULL,
    @allowed_areas           NVARCHAR(2000) = NULL,
    @actor                   NVARCHAR(100)  = N'system',
    @actor_employee_id       BIGINT         = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @report_code = UPPER(NULLIF(LTRIM(RTRIM(@report_code)), N''));
    SET @schedule_name = NULLIF(LTRIM(RTRIM(@schedule_name)), N'');
    SET @frequency = UPPER(NULLIF(LTRIM(RTRIM(@frequency)), N''));
    SET @is_active = ISNULL(@is_active, 1);
    SET @retention_days = ISNULL(@retention_days, 90);
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53120, 'Organization not found.', 1;

    DECLARE @old_report NVARCHAR(40), @old_freq NVARCHAR(10), @old_dow TINYINT, @old_dom TINYINT, @old_active BIT,
            @old_next DATE, @old_version BIGINT;
    IF @schedule_id IS NOT NULL
    BEGIN
        SELECT @old_report = report_code, @old_freq = frequency, @old_dow = day_of_week, @old_dom = day_of_month,
               @old_active = is_active, @old_next = next_run_date, @old_version = CONVERT(BIGINT, record_version)
          FROM grac_practice.asset_report_schedule
         WHERE schedule_id = @schedule_id AND organization_id = @organization_id;
        IF @old_report IS NULL
            THROW 53121, 'Schedule not found.', 1;
        IF @expected_record_version IS NOT NULL AND @expected_record_version <> @old_version
            THROW 53128, 'The schedule was changed by someone else; reload it.', 1;
        IF @report_code IS NOT NULL AND @report_code <> @old_report
            THROW 53124, 'The report of a schedule cannot be changed; create a new schedule.', 1;
        SET @report_code = @old_report;
    END

    DECLARE @area NVARCHAR(100), @available BIT, @keys NVARCHAR(204), @options NVARCHAR(1000), @default_days INT, @enabled BIT;
    SELECT @area = d.view_area, @available = d.is_available, @keys = N',' + d.filter_keys + N',', @options = d.status_options,
           @default_days = d.default_days, @enabled = e.IsEnabled
      FROM grac_practice.asset_report_definition d
      JOIN grac_practice.fn_asset_report_effective(@organization_id) e ON e.ReportCode = d.report_code
     WHERE d.report_code = @report_code AND d.is_active = 1;
    IF @area IS NULL OR @available = 0 OR @enabled = 0
        THROW 53122, 'The report is unknown, not available or disabled for the organization; it cannot be scheduled.', 1;
    IF CHARINDEX(N',' + @area + N',', N',' + REPLACE(ISNULL(@allowed_areas, N''), N' ', N'') + N',') = 0
        THROW 53123, 'You do not have permission to view the screen this report is based on.', 1;
    IF @schedule_name IS NULL OR LEN(@schedule_name) > 160
        THROW 53124, 'A schedule name is required (at most 160 characters).', 1;
    IF @frequency IS NULL OR @frequency NOT IN (N'DAILY', N'WEEKLY', N'MONTHLY')
       OR (@frequency = N'WEEKLY' AND (@day_of_week IS NULL OR @day_of_week NOT BETWEEN 1 AND 7))
       OR (@frequency = N'MONTHLY' AND (@day_of_month IS NULL OR @day_of_month NOT BETWEEN 1 AND 28))
        THROW 53124, 'Frequency must be DAILY, WEEKLY with a weekday (1 Monday - 7 Sunday) or MONTHLY with a day 1-28.', 1;
    IF @retention_days NOT BETWEEN 1 AND 3650
        THROW 53124, 'Delivered files are kept between 1 and 3650 days.', 1;
    SELECT @day_of_week = CASE WHEN @frequency = N'WEEKLY' THEN @day_of_week END,
           @day_of_month = CASE WHEN @frequency = N'MONTHLY' THEN @day_of_month END;

    -- Filters the report does not take are dropped (the run rule of 452).
    SET @search = CASE WHEN CHARINDEX(N',SEARCH,', @keys) > 0 THEN NULLIF(LTRIM(RTRIM(@search)), N'') END;
    SET @status = CASE WHEN CHARINDEX(N',STATUS,', @keys) > 0 THEN NULLIF(UPPER(LTRIM(RTRIM(@status))), N'') END;
    SET @asset_type_id = CASE WHEN CHARINDEX(N',ASSET_TYPE,', @keys) > 0 THEN @asset_type_id END;
    SET @days = CASE WHEN CHARINDEX(N',DAYS,', @keys) > 0 THEN ISNULL(@days, @default_days) END;
    SET @date_window_days = CASE WHEN CHARINDEX(N',DATE_RANGE,', @keys) > 0 THEN @date_window_days END;
    IF @status IS NOT NULL
       AND NOT ((@options = N'@ASSET_STATUS'
                 AND EXISTS (SELECT 1 FROM grac_practice.entity_status_master WHERE entity_type = N'Asset' AND status_code = @status))
                OR (@options <> N'@ASSET_STATUS' AND CHARINDEX(N'|' + @status + N'=', N'|' + @options) > 0))
        THROW 53124, 'Unknown status for this report.', 1;
    IF (@days IS NOT NULL AND @days NOT BETWEEN 1 AND 3650)
       OR (@date_window_days IS NOT NULL AND @date_window_days NOT BETWEEN 1 AND 3650)
        THROW 53124, 'Days and the date window must be between 1 and 3650.', 1;

    DECLARE @rcp TABLE (recipient_kind NVARCHAR(10) COLLATE DATABASE_DEFAULT NOT NULL, ref_id BIGINT NOT NULL,
                        PRIMARY KEY (recipient_kind, ref_id));
    IF @recipients_json IS NULL OR ISJSON(@recipients_json) = 0
        THROW 53125, 'Recipients must be a JSON array of {kind, id}.', 1;
    INSERT @rcp (recipient_kind, ref_id)
    SELECT DISTINCT UPPER(j.kind), j.id
      FROM OPENJSON(@recipients_json) WITH (kind NVARCHAR(10) '$.kind', id BIGINT '$.id') j
     WHERE j.id IS NOT NULL;
    IF NOT EXISTS (SELECT 1 FROM @rcp)
        THROW 53125, 'Add at least one recipient (an employee or a role).', 1;
    IF EXISTS (SELECT 1 FROM @rcp r
                WHERE NOT (   (r.recipient_kind = N'EMPLOYEE'
                               AND EXISTS (SELECT 1 FROM grac_practice.organization_employee e
                                            WHERE e.employee_id = r.ref_id AND e.organization_id = @organization_id AND e.status = N'Active'))
                           OR (r.recipient_kind = N'ROLE'
                               AND EXISTS (SELECT 1 FROM grac_practice.organization_role rl
                                            WHERE rl.role_id = r.ref_id AND rl.organization_id = @organization_id AND rl.status = N'Active'))))
        THROW 53125, 'A recipient is not an active employee or role of the organization.', 1;

    DECLARE @next DATE = @old_next;
    IF @schedule_id IS NULL OR @frequency <> @old_freq OR ISNULL(@day_of_week, 0) <> ISNULL(@old_dow, 0)
       OR ISNULL(@day_of_month, 0) <> ISNULL(@old_dom, 0) OR (@is_active = 1 AND @old_active = 0)
        SET @next = (SELECT NextRunDate FROM grac_practice.fn_asset_report_next_run(@frequency, @day_of_week, @day_of_month,
                                                                                  CAST(SYSUTCDATETIME() AS DATE)));

    DECLARE @before NVARCHAR(MAX) = (SELECT s.schedule_name AS scheduleName, s.search_text AS search, s.status_code AS status,
                                            s.asset_type_id AS assetTypeId, s.days, s.date_window_days AS dateWindowDays,
                                            s.frequency, s.day_of_week AS dayOfWeek, s.day_of_month AS dayOfMonth,
                                            s.retention_days AS retentionDays, s.is_active AS isActive,
                                            (SELECT r.recipient_kind AS kind, COALESCE(r.employee_id, r.role_id) AS id
                                               FROM grac_practice.asset_report_schedule_recipient r
                                              WHERE r.schedule_id = s.schedule_id FOR JSON PATH) AS recipients
                                       FROM grac_practice.asset_report_schedule s
                                      WHERE s.schedule_id = @schedule_id FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    DECLARE @result NVARCHAR(10) = CASE WHEN @schedule_id IS NULL THEN N'CREATED' ELSE N'SAVED' END;
    BEGIN TRAN;
    IF @schedule_id IS NULL
    BEGIN
        INSERT grac_practice.asset_report_schedule (organization_id, report_code, schedule_name, search_text, status_code, asset_type_id,
                                                    days, date_window_days, frequency, day_of_week, day_of_month, retention_days,
                                                    next_run_date, is_active, owner_employee_id, entered_by)
        VALUES (@organization_id, @report_code, @schedule_name, @search, @status, @asset_type_id, @days, @date_window_days,
                @frequency, @day_of_week, @day_of_month, @retention_days, @next, @is_active, @actor_employee_id, @actor);
        SET @schedule_id = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE grac_practice.asset_report_schedule
           SET schedule_name = @schedule_name, search_text = @search, status_code = @status, asset_type_id = @asset_type_id,
               days = @days, date_window_days = @date_window_days, frequency = @frequency, day_of_week = @day_of_week,
               day_of_month = @day_of_month, retention_days = @retention_days, next_run_date = @next, is_active = @is_active,
               updated_by = @actor, updated_dt = SYSUTCDATETIME()
         WHERE schedule_id = @schedule_id;
        DELETE FROM grac_practice.asset_report_schedule_recipient WHERE schedule_id = @schedule_id;
    END
    INSERT grac_practice.asset_report_schedule_recipient (schedule_id, recipient_kind, employee_id, role_id, entered_by)
    SELECT @schedule_id, r.recipient_kind, CASE WHEN r.recipient_kind = N'EMPLOYEE' THEN r.ref_id END,
           CASE WHEN r.recipient_kind = N'ROLE' THEN r.ref_id END, @actor
      FROM @rcp r;
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-report-schedule', @schedule_id, @result, @before,
            (SELECT @report_code AS reportCode, @schedule_name AS scheduleName, @search AS search, @status AS status,
                    @asset_type_id AS assetTypeId, @days AS days, @date_window_days AS dateWindowDays, @frequency AS frequency,
                    @day_of_week AS dayOfWeek, @day_of_month AS dayOfMonth, @retention_days AS retentionDays,
                    @is_active AS isActive, JSON_QUERY(@recipients_json) AS recipients FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @schedule_id AS ScheduleId, @result AS Result;
END
GO
PRINT '453: schedule procedures created.';
GO
