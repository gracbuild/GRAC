-- =====================================================================
-- 439  Asset activity results, approvals, reschedule / waive / not
--      applicable / exception, evidence expiry and restrictive-use
--      reviews (Asset & Contract Management, Phase 6 increment 3)
--
-- REQUEST
-- -------
--   BRD v1.7 7.1 (an activity that produces an asset-specific result,
--   certificate or pass / fail decision is an individual asset task);
--   7.1.2 calibration (result, certificate, pass / fail, reviewer approval
--   and next date per asset; "Calibration fails: set Calibration Status to
--   Failed; create repair, adjustment, recalibration or restricted-use
--   action; the asset cannot return to compliant / active use until the
--   acceptance criteria are met"); 7.1.3 standalone licence renewed /
--   not renewed; 7.1.5 "Rescheduled, waived, not-applicable and exception
--   outcomes require a reason, approver where configured and a new review /
--   expiry date"; 7.1.6 (calibration task approved -> last date, next date,
--   certificate, status Valid; calibration overdue -> evaluate restricted
--   use based on criticality; calibration failed -> status Failed and a
--   recalibration task; standalone licence renewed -> expiry; licence
--   expired -> remediation); 5.1.7 (last calibration date cannot be in the
--   future; calibration status N/A / Valid / Due Soon / Overdue / Failed;
--   certificate number required after a successful calibration;
--   certificate expiry must follow the certificate issue date and drives
--   evidence-expiry notifications); 9.1 "Snooze / reschedule: reason,
--   revised date and audit record mandatory"; "completion, cancellation or
--   approved rescheduling recalculates future notifications without
--   deleting"; 9.1.4 (failed calibration -> critical notification);
--   9.1.7 (evidence-expiry reminders from certificate, insurance, licence
--   and other evidence expiry dates); 9.1.9 restrictive actions
--   (calibration expired, vehicle insurance / fitness / permit expired,
--   licence expired). Plan: docs/asset-contract-management.md (Phase 6.3,
--   D69-D80).
--
-- WHAT THIS DOES
-- --------------
--   1. Activity results (asset_activity_result, one per occurrence): the
--      outcome (Pass / Fail for execution, Renewed / Not renewed for
--      renewal), performed date, certificate number and expiry, new expiry,
--      evidence reference and note. Draft -> Submitted -> Approved (or
--      Returned) by another person when the organization requires a
--      reviewer for the activity (Calibration by default); otherwise the
--      submitted result is approved at once.
--   2. An approved result completes the occurrence on the performed date and
--      writes the register: last date (Pass), certificate number and expiry
--      (Pass), new expiry (Renewed). A Fail opens a re-test occurrence
--      after the re-test days (status Failed, critical notification); a Not
--      renewed lets the expiry pass (Overdue -> restrictive review).
--   3. A Task Centre task closed without an approved result no longer
--      completes a result activity: the occurrence stays open and is flagged.
--   4. Dispositions (asset_activity_disposition): Reschedule (revised due
--      date), Waive, Not applicable, Exception (review date) with a reason;
--      approved by another person when the organization requires it (the
--      default). Reschedule moves the due date of the occurrence, its task
--      SLA and its notifications; the others close the occurrence as Waived
--      until the review date and cancel the open task.
--   5. Evidence expiry: a catalogue of evidence date fields (calibration
--      certificate, insurance, fitness, pollution, permit, registration,
--      road tax); the 437 Evidence / certificate expiry profile now has a
--      source (sweep re-issued; parties re-issued with the evidence owner).
--   6. Restrictive-use reviews (asset_restrictive_review, 9.1.9): raised by
--      the scheduler for a failed result, an overdue activity on an asset
--      whose criticality the policy names (calibration: Critical and High),
--      an expired equipment licence and expired restricting evidence
--      (insurance, fitness, permit, registration); decided with one of the
--      BRD actions and a note; resolved automatically when the cause clears.
--   7. Organization settings per activity: reviewer required, approval of
--      dispositions required, restricted-use policy on overdue and on fail.
--   8. Readers / writers for the Asset Activities screen.
--
-- NOT DONE HERE: the Task Centre task is not closed by an approved result
--   (its owner completes it; sp_task_complete returns a result set);
--   lifecycle changes from a review decision (the 429 Lifecycle tab is
--   used); linked control status from expired evidence (Phase 8);
--   attachments (evidence is a reference); corrective-action task types.
--
-- ERROR NUMBERS: 54670-54699
--   54670 occurrence not found              54671 occurrence not open / not an asset task
--   54672 outcome not valid for activity    54673 performed date missing or in the future
--   54674 certificate number required       54675 certificate expiry before performed date
--   54676 new expiry required / too early   54677 note / reason required
--   54678 result not in a state for that    54679 segregation of duties
--   54680 changed by someone else           54681 decision not valid
--   54682 disposition type not valid        54683 revised due date not valid
--   54684 review date not valid             54685 a disposition is already pending
--   54686 disposition not found             54687 disposition not pending / not yours
--   54688 review not found                  54689 review action not valid for the trigger
--   54690 review already resolved           54691 restricted-use policy not valid
--   54692 unknown template / organization
--
-- ALSO EDITED: API (AssetConfig service / controller / models), Web proxy,
--   asset-activities.cshtml / .js, docs.
-- DEPENDS ON: 192-196, 437, 438.
-- Rollback: 439_asset_activity_results_rollback.sql
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.sp_asset_activity_run','P') IS NULL
   OR OBJECT_ID('grac_practice.asset_activity_occurrence','U') IS NULL
   OR OBJECT_ID('grac_practice.sp_task_transition','P') IS NULL
   OR OBJECT_ID('grac_practice.sp_task_activity_add','P') IS NULL
   OR COL_LENGTH('grac_practice.practice_task','approved_extended_due_at') IS NULL
BEGIN
    RAISERROR('ABORT (439): run 192-196, 437 and 438 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Template result / disposition / restriction defaults (global)
-- =====================================================================
IF COL_LENGTH('grac_practice.asset_activity_template', 'result_required') IS NULL
    ALTER TABLE grac_practice.asset_activity_template ADD
        result_required              BIT           NOT NULL CONSTRAINT df_pm_asset_act_tpl_resreq DEFAULT 1,
        default_result_review        BIT           NOT NULL CONSTRAINT df_pm_asset_act_tpl_review DEFAULT 0,
        default_disposition_approval BIT           NOT NULL CONSTRAINT df_pm_asset_act_tpl_dispapp DEFAULT 1,
        retest_days                  INT           NULL,
        certificate_number_field_key NVARCHAR(100) NULL,
        certificate_expiry_field_key NVARCHAR(100) NULL,
        default_restrict_on_overdue  NVARCHAR(100) NULL,     -- ALL | NONE | CRITICAL,HIGH,MEDIUM,LOW
        default_restrict_on_fail     BIT           NOT NULL CONSTRAINT df_pm_asset_act_tpl_rfail DEFAULT 0;
GO

-- The templates are system-maintained (no editing screen): the values are set
-- on every run.
UPDATE t
   SET result_required = 1, default_result_review = x.review, default_disposition_approval = 1, retest_days = x.retest,
       certificate_number_field_key = x.cert_no, certificate_expiry_field_key = x.cert_exp,
       default_restrict_on_overdue = x.on_overdue, default_restrict_on_fail = x.on_fail
  FROM grac_practice.asset_activity_template t
  JOIN (VALUES (N'CALIBRATION',            1, 7,    N'calibration_certificate_number', N'calibration_certificate_expiry', N'CRITICAL,HIGH', 1),
               (N'PREVENTIVE_MAINTENANCE', 0, 7,    NULL, NULL, NULL,  0),
               (N'STATUTORY_INSPECTION',   0, 7,    NULL, NULL, NULL,  0),
               (N'EQUIPMENT_LICENCE',      0, NULL, NULL, NULL, N'ALL', 0))
       AS x(template_code, review, retest, cert_no, cert_exp, on_overdue, on_fail)
    ON x.template_code = t.template_code;
PRINT CONCAT('439: template result defaults set: ', @@ROWCOUNT);
GO

-- Organization overrides (NULL = the template default).
IF COL_LENGTH('grac_practice.asset_activity_setting', 'result_review_required') IS NULL
    ALTER TABLE grac_practice.asset_activity_setting ADD
        result_review_required        BIT           NULL,
        disposition_approval_required BIT           NULL,
        restrict_on_overdue           NVARCHAR(100) NULL,
        restrict_on_fail              BIT           NULL;
GO

-- =====================================================================
-- 2. Occurrence / schedule columns, widened vocabularies
-- =====================================================================
IF COL_LENGTH('grac_practice.asset_activity_occurrence', 'revised_due_date') IS NULL
    ALTER TABLE grac_practice.asset_activity_occurrence ADD
        revised_due_date DATE NULL,      -- approved reschedule
        review_date      DATE NULL,      -- waived / not applicable / exception until
        is_retest        BIT  NOT NULL CONSTRAINT df_pm_asset_act_occ_retest DEFAULT 0;
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
                WHERE name = 'ck_pm_asset_act_occ_status' AND definition LIKE '%WAIVED%')
BEGIN
    IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_asset_act_occ_status')
        ALTER TABLE grac_practice.asset_activity_occurrence DROP CONSTRAINT ck_pm_asset_act_occ_status;
    ALTER TABLE grac_practice.asset_activity_occurrence WITH CHECK
        ADD CONSTRAINT ck_pm_asset_act_occ_status
            CHECK (status IN (N'OPEN', N'COMPLETED', N'CANCELLED', N'COVERED', N'WAIVED'));
    PRINT '439: occurrence statuses widened (WAIVED).';
END
GO

IF COL_LENGTH('grac_practice.asset_activity_schedule', 'revised_due_date') IS NULL
    ALTER TABLE grac_practice.asset_activity_schedule ADD revised_due_date DATE NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
                WHERE name = 'ck_pm_asset_ntf_occ_obj' AND definition LIKE '%ASSET_EVIDENCE%')
BEGIN
    IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_asset_ntf_occ_obj')
        ALTER TABLE grac_practice.asset_notification_occurrence DROP CONSTRAINT ck_pm_asset_ntf_occ_obj;
    ALTER TABLE grac_practice.asset_notification_occurrence WITH NOCHECK
        ADD CONSTRAINT ck_pm_asset_ntf_occ_obj
            CHECK (object_type IN (N'CONTRACT_VERSION', N'ASSET_MODEL', N'ASSET_OS', N'ASSET_FIRMWARE',
                                   N'TECH_EXCEPTION', N'ATTESTATION', N'ACTIVITY', N'ASSET_EVIDENCE'));
    PRINT '439: notification object types widened (ASSET_EVIDENCE).';
END
GO

UPDATE grac_practice.asset_notification_activity
   SET source_available = 1, source_note = N'Raised from the evidence date fields of the asset register (439).'
 WHERE activity_code = N'EVIDENCE_EXPIRY' AND source_available = 0;
PRINT CONCAT('439: evidence expiry has a source now: ', @@ROWCOUNT);
GO

-- =====================================================================
-- 3. Results
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_activity_result','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_activity_result (
        result_id                BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_asset_act_res PRIMARY KEY,
        organization_id          BIGINT         NOT NULL,
        occurrence_id            BIGINT         NOT NULL
            CONSTRAINT fk_pm_asset_act_res_occ REFERENCES grac_practice.asset_activity_occurrence(occurrence_id),
        state                    NVARCHAR(12)   NOT NULL
            CONSTRAINT ck_pm_asset_act_res_state CHECK (state IN (N'DRAFT', N'SUBMITTED', N'RETURNED', N'APPROVED')),
        outcome                  NVARCHAR(12)   NULL
            CONSTRAINT ck_pm_asset_act_res_outcome CHECK (outcome IS NULL OR outcome IN (N'PASS', N'FAIL', N'RENEWED', N'NOT_RENEWED')),
        performed_date           DATE           NULL,
        certificate_number       NVARCHAR(100)  NULL,
        certificate_expiry       DATE           NULL,
        new_expiry               DATE           NULL,
        evidence_reference       NVARCHAR(400)  NULL,
        result_note              NVARCHAR(2000) NULL,
        submitted_by             NVARCHAR(100)  NULL,
        submitted_by_employee_id BIGINT         NULL
            CONSTRAINT fk_pm_asset_act_res_sub REFERENCES grac_practice.organization_employee(employee_id),
        submitted_dt             DATETIME2      NULL,
        decided_by               NVARCHAR(100)  NULL,
        decided_by_employee_id   BIGINT         NULL
            CONSTRAINT fk_pm_asset_act_res_dec REFERENCES grac_practice.organization_employee(employee_id),
        decided_dt               DATETIME2      NULL,
        decision_note            NVARCHAR(1000) NULL,
        entered_by               NVARCHAR(100)  NOT NULL CONSTRAINT df_pm_asset_act_res_eby DEFAULT N'system',
        entered_dt               DATETIME2      NOT NULL CONSTRAINT df_pm_asset_act_res_edt DEFAULT SYSUTCDATETIME(),
        updated_by               NVARCHAR(100)  NULL,
        updated_dt               DATETIME2      NULL,
        record_version           ROWVERSION     NOT NULL,
        CONSTRAINT uq_pm_asset_act_res_occ UNIQUE (occurrence_id)
    );
    CREATE INDEX ix_pm_asset_act_res_org ON grac_practice.asset_activity_result(organization_id, state);
    PRINT '439: asset_activity_result created.';
END
GO

-- =====================================================================
-- 4. Dispositions (7.1.5)
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_activity_disposition','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_activity_disposition (
        disposition_id           BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_asset_act_disp PRIMARY KEY,
        organization_id          BIGINT         NOT NULL,
        occurrence_id            BIGINT         NOT NULL
            CONSTRAINT fk_pm_asset_act_disp_occ REFERENCES grac_practice.asset_activity_occurrence(occurrence_id),
        disposition_type         NVARCHAR(16)   NOT NULL
            CONSTRAINT ck_pm_asset_act_disp_type CHECK (disposition_type IN (N'RESCHEDULE', N'WAIVE', N'NOT_APPLICABLE', N'EXCEPTION')),
        reason                   NVARCHAR(1000) NOT NULL,
        previous_due_date        DATE           NOT NULL,
        revised_due_date         DATE           NULL,
        review_date              DATE           NULL,
        status                   NVARCHAR(12)   NOT NULL
            CONSTRAINT ck_pm_asset_act_disp_status CHECK (status IN (N'PENDING', N'APPROVED', N'REJECTED', N'WITHDRAWN')),
        requested_by             NVARCHAR(100)  NOT NULL,
        requested_by_employee_id BIGINT         NULL
            CONSTRAINT fk_pm_asset_act_disp_req REFERENCES grac_practice.organization_employee(employee_id),
        requested_dt             DATETIME2      NOT NULL CONSTRAINT df_pm_asset_act_disp_rdt DEFAULT SYSUTCDATETIME(),
        decided_by               NVARCHAR(100)  NULL,
        decided_by_employee_id   BIGINT         NULL
            CONSTRAINT fk_pm_asset_act_disp_dec REFERENCES grac_practice.organization_employee(employee_id),
        decided_dt               DATETIME2      NULL,
        decision_note            NVARCHAR(1000) NULL,
        task_note                NVARCHAR(400)  NULL,      -- what happened to the Task Centre task
        record_version           ROWVERSION     NOT NULL
    );
    CREATE UNIQUE INDEX ux_pm_asset_act_disp_pending ON grac_practice.asset_activity_disposition(occurrence_id) WHERE status = N'PENDING';
    CREATE INDEX ix_pm_asset_act_disp_org ON grac_practice.asset_activity_disposition(organization_id, status);
    PRINT '439: asset_activity_disposition created.';
END
GO

-- =====================================================================
-- 5. Evidence date fields (global catalogue, 9.1.7 / 9.1.9)
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_evidence_field','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_evidence_field (
        field_key          NVARCHAR(100) NOT NULL CONSTRAINT pk_pm_asset_evid_fld PRIMARY KEY,
        evidence_name      NVARCHAR(160) NOT NULL,
        owner_field_key    NVARCHAR(100) NULL,      -- evidence owner (person), else the asset owner
        restrict_on_expiry BIT           NOT NULL,  -- raise a restrictive-use review when expired
        is_active          BIT           NOT NULL CONSTRAINT df_pm_asset_evid_fld_act DEFAULT 1,
        display_order      INT           NOT NULL,
        entered_by         NVARCHAR(100) NOT NULL CONSTRAINT df_pm_asset_evid_fld_eby DEFAULT N'system',
        entered_dt         DATETIME2     NOT NULL CONSTRAINT df_pm_asset_evid_fld_edt DEFAULT SYSUTCDATETIME()
    );
    PRINT '439: asset_evidence_field created.';
END
GO

MERGE grac_practice.asset_evidence_field AS t
USING (VALUES
    (N'calibration_certificate_expiry', N'Calibration certificate', N'calibration_owner', 0, 10),
    (N'insurance_expiry',               N'Vehicle insurance',       NULL,                1, 20),
    (N'fitness_certificate_expiry',     N'Fitness certificate',     NULL,                1, 30),
    (N'pollution_certificate_expiry',   N'Pollution certificate',   NULL,                0, 40),
    (N'permit_expiry',                  N'Permit',                  NULL,                1, 50),
    (N'registration_expiry',            N'Vehicle registration',    NULL,                1, 60),
    (N'road_tax_expiry',                N'Road tax',                NULL,                0, 70)
) AS s(field_key, evidence_name, owner_field_key, restrict_on_expiry, display_order)
ON t.field_key = s.field_key
WHEN NOT MATCHED BY TARGET THEN
    INSERT (field_key, evidence_name, owner_field_key, restrict_on_expiry, display_order, entered_by)
    VALUES (s.field_key, s.evidence_name, s.owner_field_key, s.restrict_on_expiry, s.display_order, N'seed-439');
PRINT CONCAT('439: evidence fields inserted: ', @@ROWCOUNT);
GO

-- =====================================================================
-- 6. Restrictive-use reviews (9.1.9)
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_restrictive_review','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_restrictive_review (
        review_id              BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_asset_rr PRIMARY KEY,
        organization_id        BIGINT         NOT NULL,
        asset_id               BIGINT         NOT NULL
            CONSTRAINT fk_pm_asset_rr_asset REFERENCES grac_practice.organization_dependency_asset(asset_id),
        source_kind            NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_asset_rr_kind CHECK (source_kind IN (N'ACTIVITY', N'EVIDENCE')),
        source_code            NVARCHAR(100)  NOT NULL,   -- template code or evidence field key
        trigger_code           NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_asset_rr_trigger CHECK (trigger_code IN (N'FAILED', N'OVERDUE', N'EXPIRED')),
        trigger_date           DATE           NOT NULL,
        review_key             NVARCHAR(250)  NOT NULL,
        title                  NVARCHAR(400)  NOT NULL,
        severity_code          NVARCHAR(10)   NOT NULL,
        occurrence_id          BIGINT         NULL
            CONSTRAINT fk_pm_asset_rr_occ REFERENCES grac_practice.asset_activity_occurrence(occurrence_id),
        status                 NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_asset_rr_status CHECK (status IN (N'OPEN', N'DECIDED', N'RESOLVED')),
        decision_code          NVARCHAR(30)   NULL,
        decision_note          NVARCHAR(1000) NULL,
        decided_by             NVARCHAR(100)  NULL,
        decided_by_employee_id BIGINT         NULL
            CONSTRAINT fk_pm_asset_rr_dec REFERENCES grac_practice.organization_employee(employee_id),
        decided_dt             DATETIME2      NULL,
        resolved_dt            DATETIME2      NULL,
        resolved_reason        NVARCHAR(400)  NULL,
        entered_by             NVARCHAR(100)  NOT NULL CONSTRAINT df_pm_asset_rr_eby DEFAULT N'scheduler',
        entered_dt             DATETIME2      NOT NULL CONSTRAINT df_pm_asset_rr_edt DEFAULT SYSUTCDATETIME(),
        updated_by             NVARCHAR(100)  NULL,
        updated_dt             DATETIME2      NULL,
        record_version         ROWVERSION     NOT NULL,
        CONSTRAINT uq_pm_asset_rr_key UNIQUE (organization_id, review_key)
    );
    -- One active review per asset, source and trigger.
    CREATE UNIQUE INDEX ux_pm_asset_rr_active ON grac_practice.asset_restrictive_review(asset_id, source_kind, source_code, trigger_code)
        WHERE status IN (N'OPEN', N'DECIDED');
    CREATE INDEX ix_pm_asset_rr_org ON grac_practice.asset_restrictive_review(organization_id, status);
    PRINT '439: asset_restrictive_review created.';
END
GO
