import sys,json,re
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w448/new'
def edit(path, old, new, count=1):
    s=open(path).read(); assert s.count(old)==count, (path, old[:80], s.count(old)); open(path,'w').write(s.replace(old,new))
W=R+'/src/PracticeManagement.Web/Controllers/AssetConfigController.cs'
edit(W, """//   Consistency rules (447)            GET valuation/consistency/... -> asset-valuation-config VIEW;
""", """//   privacy... (448)                   asset-privacy: GET VIEW (organization required); POST requirements,
//                                      exceptions (request), run EDIT; exceptions/{id}/action APPROVE / REJECT /
//                                      REVOKE -> APPROVE, WITHDRAW -> EDIT; reviews/{id}/complete EXTEND -> APPROVE,
//                                      other outcomes EDIT (segregation of duties in SQL);
//                                      GET register/{id}/privacy -> asset-register VIEW
//   Consistency rules (447)            GET valuation/consistency/... -> asset-valuation-config VIEW;
""")
edit(W, """    private const string DiscoveryArea = "asset-discovery";          // 442
""", """    private const string DiscoveryArea = "asset-discovery";          // 442
    private const string PrivacyArea = "asset-privacy";              // 448
""")
edit(W, """        else if (lower.StartsWith("valuation"))
""", """        else if (lower.StartsWith("privacy/"))                                  // 448
        {
            if (!long.TryParse(Request.Query["organizationId"], out var orgId) || orgId <= 0)
                return BadRequest(new { error = "organizationId is required." });
            if (!HttpContext.IsOrganizationAllowed(orgId)) return OrganizationDenied();
            allowed = Can(PrivacyArea, "VIEW");
        }
        else if (lower.StartsWith("valuation"))
""")
edit(W, """        var isDiscovery = lower.StartsWith("discovery/");                        // 442
""", """        var isDiscovery = lower.StartsWith("discovery/");                        // 442
        var isPrivacy = lower.StartsWith("privacy/");                            // 448
""")
edit(W, """            && !isActivity && !isRelationship && !isService && !isDiscovery && !lower.StartsWith("templates"))""",
"""            && !isActivity && !isRelationship && !isService && !isDiscovery && !isPrivacy && !lower.StartsWith("templates"))""")
edit(W, """        var area = isDiscovery ? DiscoveryArea : isService""", """        var area = isPrivacy ? PrivacyArea : isDiscovery ? DiscoveryArea : isService""")
edit(W, """        string? exceptionAction = null;                         // 432: verification exception action
""", """        string? exceptionAction = null;                         // 432: verification exception action
        string? outcome = null;                                 // 448: privacy review outcome
""")
edit(W, """                exceptionAction = ac.GetString()?.Trim().ToUpperInvariant();
""", """                exceptionAction = ac.GetString()?.Trim().ToUpperInvariant();
            if (doc.RootElement.TryGetProperty("outcome", out var oc) && oc.ValueKind == JsonValueKind.String)
                outcome = oc.GetString()?.Trim().ToUpperInvariant();
""")
edit(W, """            : isDiscovery
            ? false
""", """            : isDiscovery
            ? false
            : isPrivacy && lower.StartsWith("privacy/exceptions/") && lower.EndsWith("/action")   // 448
            ? (exceptionAction is "APPROVE" or "REJECT" or "REVOKE" ? Can(area, "APPROVE") : Can(area, "EDIT"))
            : isPrivacy && lower.StartsWith("privacy/reviews/") && lower.EndsWith("/complete")    // 448: an extension is approved
            ? (outcome == "EXTEND" ? Can(area, "APPROVE") : Can(area, "EDIT"))
            : isPrivacy && (lower == "privacy/requirements" || lower == "privacy/exceptions" || lower == "privacy/run")
            ? Can(area, "EDIT")
            : isPrivacy
            ? false
""")
# appsettings
for app in ['/src/PracticeManagement.Web/appsettings.json','/src/PracticeManagement.Api/appsettings.json']:
    edit(R+app, '"asset-discovery:*"', '"asset-discovery:*", "asset-privacy:*"')
    json.load(open(R+app))
# PracticeScreen
P=R+'/src/PracticeManagement.Web/Models/PracticeScreen.cs'
s=open(P).read()
i=s.index('        new("asset-discovery",'); j=s.index('\n', i)
line=s[i:j]
new_entry = """
        // Phase 8.3 (migration 448): privacy -- status and gaps per asset,
        // exceptions, privacy and retention reviews, requirement settings.
        new("asset-privacy","Asset Privacy","Personal data on assets: DPDP / GDPR applicability, privacy status and gaps against the privacy requirements (assessment, processing details, DPIA / PIA, masking, encryption, retention, third parties, review, sanitization), privacy exceptions with approval and expiry, privacy and retention reviews, and the requirement settings of the organization.","user-shield",["Asset","Privacy status","Gaps","Owner","Review"], AssetContractGroup),"""
s=s[:j]+new_entry+s[j:]
open(P,'w').write(s)
# Manage.cshtml
edit(R+'/src/PracticeManagement.Web/Views/Practice/Manage.cshtml', """        // Phase 7.3 (migration 442): discovery and reconciliation.
        "asset-discovery"
""", """        // Phase 7.3 (migration 442): discovery and reconciliation.
        "asset-discovery",
        // Phase 8.3 (migration 448): privacy.
        "asset-privacy"
""")
# 274 menu snapshot
M=R+'/database/274_menu_master_seed.sql'
edit(M, """--   442 -- 'asset-discovery' (363, Asset Discovery) under
--     'nav-asset-contract'.
""", """--   442 -- 'asset-discovery' (363, Asset Discovery) under
--     'nav-asset-contract'.
--   448 -- 'asset-privacy' (364, Asset Privacy) under
--     'nav-asset-contract'.
""")
edit(M, """    (N'asset-discovery'               , N'Asset Discovery'                   , N'Practice/Index/asset-discovery'             ,  363, N'satellite-dish'        , N'Asset & Contract'           , N'Active')   -- 442
""", """    (N'asset-discovery'               , N'Asset Discovery'                   , N'Practice/Index/asset-discovery'             ,  363, N'satellite-dish'        , N'Asset & Contract'           , N'Active'),  -- 442
    (N'asset-privacy'                 , N'Asset Privacy'                     , N'Practice/Index/asset-privacy'               ,  364, N'user-shield'           , N'Asset & Contract'           , N'Active')   -- 448
""")
edit(M, """    (N'asset-discovery'               , N'nav-asset-contract')   -- 442
""", """    (N'asset-discovery'               , N'nav-asset-contract'),  -- 442
    (N'asset-privacy'                 , N'nav-asset-contract')   -- 448
""")
print('web patched')
