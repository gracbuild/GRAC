import sys, json
R = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w452/new'
def edit(path, old, new, count=1):
    s = open(path).read(); assert s.count(old) == count, (path, old[:80], s.count(old)); open(path, 'w').write(s.replace(old, new))

W = R + '/src/PracticeManagement.Web/Controllers/AssetConfigController.cs'
edit(W, """//   governance... (450)                asset-governance: GET VIEW (organization required); POST settings,
""", """//   reports... (452)                   asset-reports: GET VIEW (organization required); POST reports/{code}/export
//                                      VIEW (the export policy and the APPROVE an approver policy needs are checked
//                                      in SQL); POST reports/settings EDIT. Every report call carries
//                                      X-PM-Caller-Report-Areas (the report screens the session may VIEW) and
//                                      X-PM-Caller-Report-Approve; a report is refused unless its screen is listed.
//   governance... (450)                asset-governance: GET VIEW (organization required); POST settings,
""")
edit(W, """    private const string GovernanceArea = "asset-governance";        // 450
""", """    private const string GovernanceArea = "asset-governance";        // 450
    private const string ReportArea = "asset-reports";               // 452
    private const string CallerReportAreasHeader = "X-PM-Caller-Report-Areas";       // 452
    private const string CallerReportApproveHeader = "X-PM-Caller-Report-Approve";   // 452

    // 452: the screens a report can be based on (asset_report_definition.view_area). A report on another screen is
    // refused until its screen is added here.
    private static readonly string[] ReportScreenAreas =
    {
        RegisterArea, AttestationArea, RelationshipArea, ServiceArea, DiscoveryArea, ContractArea, GovernanceArea,
        PrivacyArea, ActivityArea, "risk-centre-register"
    };
""")
edit(W, """        else if (lower == "governance" || lower.StartsWith("governance/"))     // 450
        {""", """        else if (lower == "reports" || lower.StartsWith("reports/"))           // 452
        {
            if (!long.TryParse(Request.Query["organizationId"], out var orgId) || orgId <= 0)
                return BadRequest(new { error = "organizationId is required." });
            if (!HttpContext.IsOrganizationAllowed(orgId)) return OrganizationDenied();
            allowed = Can(ReportArea, "VIEW");
        }
        else if (lower == "governance" || lower.StartsWith("governance/"))     // 450
        {""")
edit(W, """        if (!allowed) return Denied();
        var qs = Request.QueryString.HasValue ? Request.QueryString.Value : "";
        return await ForwardAsync(HttpMethod.Get, "api/practice/asset-config/" + path + qs, null, ct);""",
"""        if (!allowed) return Denied();
        var qs = Request.QueryString.HasValue ? Request.QueryString.Value : "";
        return await ForwardAsync(HttpMethod.Get, "api/practice/asset-config/" + path + qs, null, ct,
            reportCaller: lower == "reports" || lower.StartsWith("reports/"));""")
edit(W, """        var isGovernance = lower.StartsWith("governance/");                      // 450
""", """        var isGovernance = lower.StartsWith("governance/");                      // 450
        var isReport = lower.StartsWith("reports/");                             // 452
""")
edit(W, """            && !isActivity && !isRelationship && !isService && !isDiscovery && !isPrivacy && !isGovernance && !lower.StartsWith("templates"))""",
"""            && !isActivity && !isRelationship && !isService && !isDiscovery && !isPrivacy && !isGovernance && !isReport
            && !lower.StartsWith("templates"))""")
edit(W, """        var area = isGovernance ? GovernanceArea : isPrivacy""", """        var area = isReport ? ReportArea : isGovernance ? GovernanceArea : isPrivacy""")
edit(W, """            : isGovernance
            ? false
""", """            : isGovernance
            ? false
            : isReport && lower.StartsWith("reports/") && lower.EndsWith("/export")   // 452: policy / approver in SQL
            ? Can(area, "VIEW")
            : isReport && lower == "reports/settings"
            ? Can(area, "EDIT")
            : isReport
            ? false
""")
edit(W, """        return await ForwardAsync(HttpMethod.Post, "api/practice/asset-config/" + path, body, ct);
    }

    // 424: the taxonomy masters are global""", """        return await ForwardAsync(HttpMethod.Post, "api/practice/asset-config/" + path, body, ct, reportCaller: isReport);
    }

    // 424: the taxonomy masters are global""")
edit(W, """    private async Task<IActionResult> ForwardAsync(HttpMethod method, string relativeUrl, string? body, CancellationToken ct)
    {
        try
        {
            using var msg = new HttpRequestMessage(method, relativeUrl);
            if (body is not null)
            {
                msg.Content = new StringContent(body);
                msg.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            }
            var client = BuildClient();""", """    private async Task<IActionResult> ForwardAsync(HttpMethod method, string relativeUrl, string? body, CancellationToken ct,
        bool reportCaller = false)
    {
        try
        {
            using var msg = new HttpRequestMessage(method, relativeUrl);
            if (body is not null)
            {
                msg.Content = new StringContent(body);
                msg.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            }
            if (reportCaller) StampReportCaller(msg);                            // 452
            var client = BuildClient();
            if (reportCaller) client.Timeout = TimeSpan.FromMinutes(5);           // 452: whole-organization reports and exports""")
edit(W, """    private IActionResult? SessionMissing() =>""", """    // 452: set from the session (never from the browser): the report screens the caller may VIEW and whether the
    // caller holds Asset Reports APPROVE (exports whose policy needs an approver).
    private void StampReportCaller(HttpRequestMessage msg)
    {
        msg.Headers.Remove(CallerReportAreasHeader);
        msg.Headers.Remove(CallerReportApproveHeader);
        msg.Headers.TryAddWithoutValidation(CallerReportAreasHeader,
            string.Join(",", ReportScreenAreas.Where(a => Can(a, "VIEW"))));
        msg.Headers.TryAddWithoutValidation(CallerReportApproveHeader, Can(ReportArea, "APPROVE") ? "1" : "0");
    }

    private IActionResult? SessionMissing() =>""")

for app in ['/src/PracticeManagement.Web/appsettings.json', '/src/PracticeManagement.Api/appsettings.json']:
    edit(R + app, '"asset-contract-dashboard:VIEW"', '"asset-contract-dashboard:VIEW", "asset-reports:*"')
    json.load(open(R + app))

P = R + '/src/PracticeManagement.Web/Models/PracticeScreen.cs'
s = open(P).read()
i = s.index('        new("asset-governance",'); j = s.index('\n', i)
s = s[:j] + """
        // Phase 8.5a (migration 452): report catalogue -- BRD 13.4 standard
        // reports with governed CSV export (13.4.1).
        new("asset-reports","Asset Reports","Standard reports of the asset module (BRD 13.4): asset register, ownership and custody, lifecycle, missing data, movement, disposal; attestation compliance, overdue, exceptions, lost and damaged, SLA; CMDB relationships, orphans, service topology, critical dependencies, data quality; discovery coverage, stale assets, source health, reconciliation queue, merge and split history; contract expiry, renewals, coverage gaps, entitlements, vendor contacts; technology support; CIA, Asset Value and risk; governance scores; privacy, DPIA, masking and encryption, retention and evidence expiry -- each limited to the screens the user may view, with CSV export recorded with report, version, filters, columns, user, organization, time and classification.","file-lines",["Report","Family","Classification","Rows","Exported"], AssetContractGroup),""" + s[j:]
open(P, 'w').write(s)

edit(R + '/src/PracticeManagement.Web/Views/Practice/Manage.cshtml', """        // Phase 8.4a (migration 450): governance KPIs.
        "asset-governance\"""", """        // Phase 8.4a (migration 450): governance KPIs.
        "asset-governance",
        // Phase 8.5a (migration 452): report catalogue and exports.
        "asset-reports\"""")

M = R + '/database/274_menu_master_seed.sql'
edit(M, """--   451 -- 'asset-contract-dashboard' (348, Dashboard -- first child, 416
--     rule) under 'nav-asset-contract'.
""", """--   451 -- 'asset-contract-dashboard' (348, Dashboard -- first child, 416
--     rule) under 'nav-asset-contract'.
--   452 -- 'asset-reports' (366, Asset Reports) under
--     'nav-asset-contract'.
""")
edit(M, """    (N'asset-contract-dashboard'      , N'Dashboard'                         , N'Practice/Index/asset-contract-dashboard'    ,  348, N'chart-pie'             , N'Asset & Contract'           , N'Active')   -- 451
""", """    (N'asset-contract-dashboard'      , N'Dashboard'                         , N'Practice/Index/asset-contract-dashboard'    ,  348, N'chart-pie'             , N'Asset & Contract'           , N'Active'),  -- 451
    (N'asset-reports'                 , N'Asset Reports'                     , N'Practice/Index/asset-reports'               ,  366, N'file-lines'            , N'Asset & Contract'           , N'Active')   -- 452
""")
edit(M, """    (N'asset-contract-dashboard'      , N'nav-asset-contract')   -- 451
""", """    (N'asset-contract-dashboard'      , N'nav-asset-contract'),  -- 451
    (N'asset-reports'                 , N'nav-asset-contract')   -- 452
""")
print('web patched')
