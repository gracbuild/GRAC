-- =====================================================================
-- 453  Asset report schedules, distribution and delivery retention
--      (Asset & Contract Management, Phase 8 increment 5b)
--
-- REQUEST
-- -------
--   BRD v1.7 13.4 ("governed report definitions with ... schedule,
--   retention and distribution rules"), 13.4.1 ("scheduled delivery shall
--   validate recipient authorization at delivery time and record
--   distribution results"; "exports shall record report / version,
--   filters, columns, user, tenant, generation time and classification";
--   "sensitive exports may require ... expiry or download restrictions").
--   Standing instruction: use the existing background worker
--   (TaskNotificationWorker). Plan: docs/asset-contract-management.md
--   (Phase 8.5b, D211-D224).
--
-- WHAT THIS DOES
-- --------------
--   1. asset_report_schedule -- a report of the 452 catalogue with fixed
--      filters (a date window of the last N days for date-range reports),
--      frequency (daily, weekly on a weekday, monthly on a day 1-28), next
--      run date, active flag and how long delivered files are kept.
--   2. asset_report_schedule_recipient -- the distribution list: named
--      employees and organization roles (every active holder at delivery).
--   3. asset_report_delivery / _delivery_recipient -- one delivery per
--      run; per recipient DELIVERED, SKIPPED (with the reason the
--      authorization check gave) or FAILED, row count, the columns and
--      rows produced under that recipient (View Data Scope included),
--      downloads, and when the file was removed by retention.
--   4. asset_report_export.delivery_recipient_id -- a download of a
--      delivered file is recorded as an export like any other (452).
--   5. fn_asset_report_next_run, fn_asset_report_employee_access (the menu
--      permissions of an employee: primary role plus assigned roles, the
--      sign-in rule) and fn_asset_report_employee_in_org (sign-in rule).
--   6. Procedures: sp_asset_report_schedules, _schedule_save,
--      _delivery_start (claims due schedules or one schedule now, checks
--      every recipient, purges files past retention, returns the work),
--      _delivery_store, _deliveries, _delivery_recipients,
--      _my_deliveries, _delivery_download.
--   The rows are produced by the API (AssetConfigService.RunReport
--   DeliveriesAsync) through sp_asset_report_run, per recipient and under
--   the recipient own View Data Scope; TaskNotificationWorker runs it.
--
-- NOT DONE HERE: e-mail / Teams delivery (no dispatcher exists in the
--   codebase -- as 437 D57, delivery is in the application: Asset Reports
--   -> My deliveries); encrypted files; schedules run by SQL Agent alone
--   (the rows are produced in the API).
--
-- ERROR NUMBERS: 53120-53139
--   53120 organization not found        53121 schedule not found
--   53122 report cannot be scheduled (unknown, not available, disabled)
--   53123 no permission for the report screen
--   53124 schedule invalid (name, frequency, day, window, retention, filters)
--   53125 recipients invalid            53126 delivery not found / not yours
--   53127 file not available (not delivered or removed by retention)
--   53128 changed by someone else       53129 download not allowed now
--
-- ALSO EDITED: API (AssetConfig service / controller / models,
--   TaskNotificationWorker, appsettings), Web proxy, asset-reports.cshtml
--   / .js, docs. 452 objects are not re-issued.
-- DEPENDS ON: 452.
-- Rollback: 453_asset_report_schedules_rollback.sql (drops the 453 objects
--   and the export column; schedules, deliveries and their files are lost).
-- Re-runnable. ASCII-only.
-- =====================================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOEXEC OFF;
GO

IF OBJECT_ID('grac_practice.sp_asset_report_run','P') IS NULL
   OR OBJECT_ID('grac_practice.asset_report_export','U') IS NULL
   OR OBJECT_ID('grac_practice.fn_asset_report_effective') IS NULL
   OR OBJECT_ID('grac_practice.organization_employee_role','U') IS NULL
   OR OBJECT_ID('grac_practice.user_organization_map','U') IS NULL
   OR COL_LENGTH('grac_practice.menu_master', 'parent_menu_id') IS NULL
BEGIN
    RAISERROR('ABORT (453): run 452 first.', 16, 1);
    SET NOEXEC ON;
END
GO

-- =====================================================================
-- 1. Schedules and distribution lists
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_report_schedule','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_report_schedule (
        schedule_id       BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_arpt_sch PRIMARY KEY,
        organization_id   BIGINT         NOT NULL
            CONSTRAINT fk_pm_arpt_sch_org REFERENCES grac_practice.organization(organization_id),
        report_code       NVARCHAR(40)   NOT NULL
            CONSTRAINT fk_pm_arpt_sch_def REFERENCES grac_practice.asset_report_definition(report_code),
        schedule_name     NVARCHAR(160)  NOT NULL,
        search_text       NVARCHAR(200)  NULL,
        status_code       NVARCHAR(60)   NULL,
        asset_type_id     INT            NULL,
        days              INT            NULL,
        date_window_days  INT            NULL,       -- date-range reports: the last N days up to the run date
        frequency         NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_arpt_sch_freq CHECK (frequency IN (N'DAILY', N'WEEKLY', N'MONTHLY')),
        day_of_week       TINYINT        NULL        -- 1 Monday .. 7 Sunday (WEEKLY)
            CONSTRAINT ck_pm_arpt_sch_dow CHECK (day_of_week IS NULL OR day_of_week BETWEEN 1 AND 7),
        day_of_month      TINYINT        NULL        -- 1 .. 28 (MONTHLY)
            CONSTRAINT ck_pm_arpt_sch_dom CHECK (day_of_month IS NULL OR day_of_month BETWEEN 1 AND 28),
        retention_days    INT            NOT NULL CONSTRAINT df_pm_arpt_sch_ret DEFAULT 90
            CONSTRAINT ck_pm_arpt_sch_ret CHECK (retention_days BETWEEN 1 AND 3650),
        next_run_date     DATE           NULL,
        last_delivery_id  BIGINT         NULL,
        is_active         BIT            NOT NULL CONSTRAINT df_pm_arpt_sch_act DEFAULT 1,
        owner_employee_id BIGINT         NULL,
        entered_by        NVARCHAR(100)  NOT NULL CONSTRAINT df_pm_arpt_sch_eby DEFAULT N'system',
        entered_dt        DATETIME2      NOT NULL CONSTRAINT df_pm_arpt_sch_edt DEFAULT SYSUTCDATETIME(),
        updated_by        NVARCHAR(100)  NULL,
        updated_dt        DATETIME2      NULL,
        record_version    ROWVERSION     NOT NULL
    );
    CREATE INDEX ix_pm_arpt_sch_due ON grac_practice.asset_report_schedule(is_active, next_run_date);
    PRINT '453: asset_report_schedule created.';
END
GO

IF OBJECT_ID('grac_practice.asset_report_schedule_recipient','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_report_schedule_recipient (
        recipient_id   BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_arpt_srcp PRIMARY KEY,
        schedule_id    BIGINT        NOT NULL
            CONSTRAINT fk_pm_arpt_srcp_sch REFERENCES grac_practice.asset_report_schedule(schedule_id),
        recipient_kind NVARCHAR(10)  NOT NULL
            CONSTRAINT ck_pm_arpt_srcp_kind CHECK (recipient_kind IN (N'EMPLOYEE', N'ROLE')),
        employee_id    BIGINT        NULL
            CONSTRAINT fk_pm_arpt_srcp_emp REFERENCES grac_practice.organization_employee(employee_id),
        role_id        BIGINT        NULL
            CONSTRAINT fk_pm_arpt_srcp_role REFERENCES grac_practice.organization_role(role_id),
        entered_by     NVARCHAR(100) NOT NULL CONSTRAINT df_pm_arpt_srcp_eby DEFAULT N'system',
        entered_dt     DATETIME2     NOT NULL CONSTRAINT df_pm_arpt_srcp_edt DEFAULT SYSUTCDATETIME(),
        CONSTRAINT ck_pm_arpt_srcp_ref CHECK ((recipient_kind = N'EMPLOYEE' AND employee_id IS NOT NULL AND role_id IS NULL)
                                           OR (recipient_kind = N'ROLE' AND role_id IS NOT NULL AND employee_id IS NULL))
    );
    CREATE UNIQUE INDEX ux_pm_arpt_srcp ON grac_practice.asset_report_schedule_recipient(schedule_id, recipient_kind, employee_id, role_id);
    PRINT '453: asset_report_schedule_recipient created.';
END
GO

-- =====================================================================
-- 2. Deliveries and distribution results
-- =====================================================================
IF OBJECT_ID('grac_practice.asset_report_delivery','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_report_delivery (
        delivery_id     BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_arpt_dlv PRIMARY KEY,
        schedule_id     BIGINT         NOT NULL
            CONSTRAINT fk_pm_arpt_dlv_sch REFERENCES grac_practice.asset_report_schedule(schedule_id),
        organization_id BIGINT         NOT NULL,
        report_code     NVARCHAR(40)   NOT NULL,
        report_version  INT            NOT NULL,
        report_name     NVARCHAR(120)  NOT NULL,
        classification  NVARCHAR(20)   NOT NULL,
        filters_json    NVARCHAR(MAX)  NULL,      -- as recorded with an export (452)
        search_text     NVARCHAR(200)  NULL,      -- the filters the run used
        status_code     NVARCHAR(60)   NULL,
        asset_type_id   INT            NULL,
        date_from       DATE           NULL,
        date_to         DATE           NULL,
        days            INT            NULL,
        run_date        DATE           NOT NULL,
        trigger_code    NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_arpt_dlv_trg CHECK (trigger_code IN (N'SCHEDULED', N'MANUAL')),
        status          NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_arpt_dlv_status CHECK (status IN (N'RUNNING', N'COMPLETED', N'PARTIAL', N'FAILED', N'SKIPPED')),
        recipient_count INT            NOT NULL CONSTRAINT df_pm_arpt_dlv_rc DEFAULT 0,
        delivered_count INT            NOT NULL CONSTRAINT df_pm_arpt_dlv_dc DEFAULT 0,
        skipped_count   INT            NOT NULL CONSTRAINT df_pm_arpt_dlv_sc DEFAULT 0,
        failed_count    INT            NOT NULL CONSTRAINT df_pm_arpt_dlv_fc DEFAULT 0,
        retention_days  INT            NOT NULL,
        started_by      NVARCHAR(100)  NOT NULL,
        started_dt      DATETIME2      NOT NULL CONSTRAINT df_pm_arpt_dlv_sdt DEFAULT SYSUTCDATETIME(),
        completed_dt    DATETIME2      NULL
    );
    -- One scheduled delivery per schedule and day (a second worker or pass claims nothing).
    CREATE UNIQUE INDEX ux_pm_arpt_dlv_day ON grac_practice.asset_report_delivery(schedule_id, run_date) WHERE trigger_code = N'SCHEDULED';
    CREATE INDEX ix_pm_arpt_dlv_org ON grac_practice.asset_report_delivery(organization_id, started_dt DESC);
    PRINT '453: asset_report_delivery created.';
END
GO

IF OBJECT_ID('grac_practice.asset_report_delivery_recipient','U') IS NULL
BEGIN
    CREATE TABLE grac_practice.asset_report_delivery_recipient (
        delivery_recipient_id BIGINT         IDENTITY(1,1) NOT NULL CONSTRAINT pk_pm_arpt_drcp PRIMARY KEY,
        delivery_id           BIGINT         NOT NULL
            CONSTRAINT fk_pm_arpt_drcp_dlv REFERENCES grac_practice.asset_report_delivery(delivery_id),
        employee_id           BIGINT         NOT NULL,
        recipient_name        NVARCHAR(200)  NULL,
        via_role_name         NVARCHAR(200)  NULL,
        status                NVARCHAR(10)   NOT NULL
            CONSTRAINT ck_pm_arpt_drcp_status CHECK (status IN (N'PENDING', N'DELIVERED', N'SKIPPED', N'FAILED')),
        reason                NVARCHAR(1000) NULL,
        allowed_areas         NVARCHAR(2000) NULL,   -- the recipient report screens at delivery time
        can_approve           BIT            NOT NULL CONSTRAINT df_pm_arpt_drcp_appr DEFAULT 0,
        row_count             INT            NULL,
        columns_json          NVARCHAR(MAX)  NULL,
        rows_json             NVARCHAR(MAX)  NULL,
        delivered_dt          DATETIME2      NULL,
        first_downloaded_dt   DATETIME2      NULL,
        download_count        INT            NOT NULL CONSTRAINT df_pm_arpt_drcp_dl DEFAULT 0,
        purged_dt             DATETIME2      NULL,
        entered_dt            DATETIME2      NOT NULL CONSTRAINT df_pm_arpt_drcp_edt DEFAULT SYSUTCDATETIME()
    );
    CREATE UNIQUE INDEX ux_pm_arpt_drcp ON grac_practice.asset_report_delivery_recipient(delivery_id, employee_id);
    CREATE INDEX ix_pm_arpt_drcp_emp ON grac_practice.asset_report_delivery_recipient(employee_id, delivery_id DESC);
    PRINT '453: asset_report_delivery_recipient created.';
END
GO

IF COL_LENGTH('grac_practice.asset_report_export', 'delivery_recipient_id') IS NULL
BEGIN
    ALTER TABLE grac_practice.asset_report_export ADD delivery_recipient_id BIGINT NULL
        CONSTRAINT fk_pm_arpt_exp_drcp REFERENCES grac_practice.asset_report_delivery_recipient(delivery_recipient_id);
    PRINT '453: asset_report_export.delivery_recipient_id added.';
END
GO
