// =====================================================================
// OrgAssuranceQuestionService
//
// Phase 2 Assurance Management -- Stage 2 Question Builder service.
//
// Thin wrapper over the sp_org_assurance_question_* stored procedures
// in migration 077. Follows the exact TaskService / OrgAssuranceDefinition-
// Service conventions:
//   * Primary-constructor injection
//   * Infrastructure.SqlConnectionStringResolver for the connection
//   * AddParam helper + snake_case @-parameters
//   * Structured *Result records
// =====================================================================
using System.Data;
using System.Data.Common;
using Microsoft.Data.SqlClient;
using PracticeManagement.Api.Models;

namespace PracticeManagement.Api.Services;

public interface IOrgAssuranceQuestionService
{
    Task<IReadOnlyList<OrgAssuranceAdminQuestionTypeRow>> ListAdminQuestionTypesAsync(CancellationToken cancellationToken);

    // Sets
    Task<OrgAssuranceQuestionSetListResult> ListSetsAsync(
        OrgAssuranceQuestionSetListQuery query, CancellationToken cancellationToken);
    Task<OrgAssuranceQuestionSetDetail?> GetSetAsync(
        long organizationId, long questionSetId, CancellationToken cancellationToken);
    Task<OrgAssuranceQuestionSetSaveResult> SaveSetAsync(
        OrgAssuranceQuestionSetSaveRequest request, CancellationToken cancellationToken);
    Task<OrgAssuranceCommandResult> DeleteSetAsync(
        long organizationId, long questionSetId, string? actor, CancellationToken cancellationToken);

    // Questions
    Task<IReadOnlyList<OrgAssuranceQuestionRow>> ListQuestionsAsync(
        long organizationId, long questionSetId, CancellationToken cancellationToken);
    Task<OrgAssuranceQuestionRow?> GetQuestionAsync(
        long organizationId, long questionId, CancellationToken cancellationToken);
    Task<OrgAssuranceQuestionSaveResult> SaveQuestionAsync(
        OrgAssuranceQuestionSaveRequest request, CancellationToken cancellationToken);
    Task<OrgAssuranceCommandResult> DeleteQuestionAsync(
        long organizationId, long questionId, string? actor, CancellationToken cancellationToken);

    // Question Repository (516)
    Task<OrgAssuranceQuestionCategoryTree> ListCategoriesAsync(
        long organizationId, CancellationToken cancellationToken);
    Task<OrgAssuranceCommandResult> SaveCategoryAsync(
        OrgAssuranceQuestionCategorySaveRequest request, CancellationToken cancellationToken);
    Task<OrgAssuranceCommandResult> DeleteCategoryAsync(
        long organizationId, long categoryId, string? actor, CancellationToken cancellationToken);
    Task<OrgAssuranceCommandResult> SaveSubcategoryAsync(
        OrgAssuranceQuestionSubcategorySaveRequest request, CancellationToken cancellationToken);
    Task<OrgAssuranceCommandResult> DeleteSubcategoryAsync(
        long organizationId, long subcategoryId, string? actor, CancellationToken cancellationToken);
    Task<OrgAssuranceRepositoryQuestionListResult> ListRepositoryQuestionsAsync(
        OrgAssuranceRepositoryQuestionListQuery query, CancellationToken cancellationToken);
    Task<OrgAssuranceRepositoryQuestionRow?> GetRepositoryQuestionAsync(
        long organizationId, long repositoryQuestionId, CancellationToken cancellationToken);
    Task<OrgAssuranceCommandResult> SaveRepositoryQuestionAsync(
        OrgAssuranceRepositoryQuestionSaveRequest request, CancellationToken cancellationToken);
    Task<OrgAssuranceCommandResult> DeleteRepositoryQuestionAsync(
        long organizationId, long repositoryQuestionId, string? actor, CancellationToken cancellationToken);
    Task<OrgAssuranceCommandResult> AddToSetFromRepositoryAsync(
        long questionSetId, OrgAssuranceSetAddFromRepositoryRequest request, CancellationToken cancellationToken);
}

public sealed class OrgAssuranceQuestionService(
    IConfiguration configuration,
    ILogger<OrgAssuranceQuestionService> logger) : IOrgAssuranceQuestionService
{
    // -----------------------------------------------------------------
    // Admin question types
    // -----------------------------------------------------------------
    public async Task<IReadOnlyList<OrgAssuranceAdminQuestionTypeRow>> ListAdminQuestionTypesAsync(CancellationToken cancellationToken)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_org_assurance_admin_question_type_list";

        var rows = new List<OrgAssuranceAdminQuestionTypeRow>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            rows.Add(new OrgAssuranceAdminQuestionTypeRow(
                ReadLongOrNull(reader,   "Id"),
                ReadStringOrNull(reader, "Code"),
                ReadStringOrNull(reader, "Name"),
                ReadStringOrNull(reader, "Description")));
        }
        return rows;
    }

    // -----------------------------------------------------------------
    // Question Sets
    // -----------------------------------------------------------------
    public async Task<OrgAssuranceQuestionSetListResult> ListSetsAsync(
        OrgAssuranceQuestionSetListQuery query, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(query);
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_org_assurance_question_set_list";

        AddParam(command, "@organization_id", DbType.Int64,  query.OrganizationId);
        AddParam(command, "@search",          DbType.String, (object?)query.Search ?? DBNull.Value, 200);
        AddParam(command, "@page",            DbType.Int32,  Math.Max(1, query.Page));
        AddParam(command, "@page_size",       DbType.Int32,  Math.Clamp(query.PageSize, 1, 200));

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);

        long total = 0;
        int  page  = query.Page;
        int  size  = query.PageSize;
        if (await reader.ReadAsync(cancellationToken))
        {
            total = Convert.ToInt64(reader["TotalCount"]);
            page  = Convert.ToInt32(reader["PageNumber"]);
            size  = Convert.ToInt32(reader["PageSize"]);
        }

        var rows = new List<OrgAssuranceQuestionSetListRow>();
        if (await reader.NextResultAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
            {
                rows.Add(new OrgAssuranceQuestionSetListRow(
                    Convert.ToInt64(reader["QuestionSetId"]),
                    Convert.ToInt64(reader["OrganizationId"]),
                    reader["SetCode"]?.ToString() ?? "",
                    reader["SetName"]?.ToString() ?? "",
                    ReadStringOrNull(reader, "Description"),
                    ReadLongOrNull(reader,   "OwnerEmployeeId"),
                    ReadStringOrNull(reader, "OwnerDisplayName"),
                    reader["Status"]?.ToString() ?? "Active",
                    Convert.ToInt64(reader["QuestionCount"]),
                    ReadDateTimeOrNull(reader, "EnteredDt"),
                    ReadDateTimeOrNull(reader, "UpdatedDt")));
            }
        }

        return new OrgAssuranceQuestionSetListResult(total, page, size, rows);
    }

    public async Task<OrgAssuranceQuestionSetDetail?> GetSetAsync(
        long organizationId, long questionSetId, CancellationToken cancellationToken)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_org_assurance_question_set_get";

        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        AddParam(command, "@question_set_id", DbType.Int64, questionSetId);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken)) return null;

        return new OrgAssuranceQuestionSetDetail(
            Convert.ToInt64(reader["QuestionSetId"]),
            Convert.ToInt64(reader["OrganizationId"]),
            reader["SetCode"]?.ToString() ?? "",
            reader["SetName"]?.ToString() ?? "",
            ReadStringOrNull(reader, "Description"),
            ReadLongOrNull(reader,   "OwnerEmployeeId"),
            ReadStringOrNull(reader, "OwnerDisplayName"),
            reader["Status"]?.ToString() ?? "Active",
            ReadStringOrNull(reader, "EnteredBy"),
            ReadDateTimeOrNull(reader, "EnteredDt"),
            ReadStringOrNull(reader, "UpdatedBy"),
            ReadDateTimeOrNull(reader, "UpdatedDt"));
    }

    public async Task<OrgAssuranceQuestionSetSaveResult> SaveSetAsync(
        OrgAssuranceQuestionSetSaveRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (string.IsNullOrWhiteSpace(request.SetCode))
            return new OrgAssuranceQuestionSetSaveResult(false, Error: "SetCode is required.");
        if (string.IsNullOrWhiteSpace(request.SetName))
            return new OrgAssuranceQuestionSetSaveResult(false, Error: "SetName is required.");

        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_org_assurance_question_set_save";

            AddParam(command, "@organization_id",    DbType.Int64,  request.OrganizationId);
            AddParam(command, "@question_set_id",    DbType.Int64,  (object?)request.QuestionSetId ?? DBNull.Value);
            AddParam(command, "@set_code",           DbType.String, request.SetCode.Trim(), 80);
            AddParam(command, "@set_name",           DbType.String, request.SetName.Trim(), 240);
            AddParam(command, "@description",        DbType.String, (object?)request.Description ?? DBNull.Value, -1);
            AddParam(command, "@owner_employee_id",  DbType.Int64,  (object?)request.OwnerEmployeeId ?? DBNull.Value);
            AddParam(command, "@owner_display_name", DbType.String, (object?)request.OwnerDisplayName ?? DBNull.Value, 240);
            AddParam(command, "@status",             DbType.String, (object?)request.Status ?? (object)"Active", 30);
            AddParam(command, "@actor",              DbType.String, (object?)request.Actor  ?? (object)"system", 100);

            var idOut = command.CreateParameter();
            idOut.ParameterName = "@question_set_id_out";
            idOut.DbType        = DbType.Int64;
            idOut.Direction     = ParameterDirection.Output;
            command.Parameters.Add(idOut);

            await command.ExecuteNonQueryAsync(cancellationToken);
            var id = idOut.Value is long l ? l : Convert.ToInt64(idOut.Value);
            return new OrgAssuranceQuestionSetSaveResult(true, id);
        }
        catch (SqlException ex)
        {
            var reason = MapReason(ex.Number);
            logger.LogWarning(ex,
                "OrgAssuranceQuestionService.SaveSetAsync SQL error {Number}: {Message}",
                ex.Number, ex.Message);
            return new OrgAssuranceQuestionSetSaveResult(false, Error: ex.Message, ReasonCode: reason);
        }
    }

    public async Task<OrgAssuranceCommandResult> DeleteSetAsync(
        long organizationId, long questionSetId, string? actor, CancellationToken cancellationToken)
    {
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_org_assurance_question_set_delete";

            AddParam(command, "@organization_id", DbType.Int64,  organizationId);
            AddParam(command, "@question_set_id", DbType.Int64,  questionSetId);
            AddParam(command, "@actor",           DbType.String, (object?)actor ?? (object)"system", 100);

            await command.ExecuteNonQueryAsync(cancellationToken);
            return new OrgAssuranceCommandResult(true, questionSetId);
        }
        catch (SqlException ex)
        {
            var reason = MapReason(ex.Number);
            logger.LogWarning(ex, "OrgAssuranceQuestionService.DeleteSetAsync SQL error {Number}: {Message}",
                ex.Number, ex.Message);
            return new OrgAssuranceCommandResult(false, Error: ex.Message, ReasonCode: reason);
        }
    }

    // -----------------------------------------------------------------
    // Questions
    // -----------------------------------------------------------------
    public async Task<IReadOnlyList<OrgAssuranceQuestionRow>> ListQuestionsAsync(
        long organizationId, long questionSetId, CancellationToken cancellationToken)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_org_assurance_question_list";

        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        AddParam(command, "@question_set_id", DbType.Int64, questionSetId);

        var rows = new List<OrgAssuranceQuestionRow>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
            rows.Add(MapQuestionRow(reader));
        return rows;
    }

    public async Task<OrgAssuranceQuestionRow?> GetQuestionAsync(
        long organizationId, long questionId, CancellationToken cancellationToken)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_org_assurance_question_get";

        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        AddParam(command, "@question_id",     DbType.Int64, questionId);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        return await reader.ReadAsync(cancellationToken) ? MapQuestionRow(reader) : null;
    }

    public async Task<OrgAssuranceQuestionSaveResult> SaveQuestionAsync(
        OrgAssuranceQuestionSaveRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (string.IsNullOrWhiteSpace(request.QuestionCode))
            return new OrgAssuranceQuestionSaveResult(false, Error: "QuestionCode is required.");
        if (string.IsNullOrWhiteSpace(request.QuestionText))
            return new OrgAssuranceQuestionSaveResult(false, Error: "QuestionText is required.");

        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_org_assurance_question_save";

            AddParam(command, "@organization_id",     DbType.Int64,   request.OrganizationId);
            AddParam(command, "@question_set_id",     DbType.Int64,   request.QuestionSetId);
            AddParam(command, "@question_id",         DbType.Int64,   (object?)request.QuestionId ?? DBNull.Value);
            AddParam(command, "@question_code",       DbType.String,  request.QuestionCode.Trim(), 80);
            AddParam(command, "@question_text",       DbType.String,  request.QuestionText.Trim(), -1);
            AddParam(command, "@help_text",           DbType.String,  (object?)request.HelpText ?? DBNull.Value, -1);
            AddParam(command, "@question_type_id",    DbType.Int64,   (object?)request.QuestionTypeId ?? DBNull.Value);
            AddParam(command, "@question_type_code",  DbType.String,  (object?)request.QuestionTypeCode ?? DBNull.Value, 120);
            AddParam(command, "@question_type_name",  DbType.String,  (object?)request.QuestionTypeName ?? DBNull.Value, 200);
            AddParam(command, "@is_mandatory",        DbType.Boolean, request.IsMandatory ?? false);
            AddParam(command, "@display_order",       DbType.Int32,   request.DisplayOrder ?? 0);
            AddParam(command, "@weight",              DbType.Decimal, (object?)request.Weight ?? DBNull.Value);
            AddParam(command, "@expected_response",   DbType.String,  (object?)request.ExpectedResponse ?? DBNull.Value, -1);
            AddParam(command, "@actor",               DbType.String,  (object?)request.Actor ?? (object)"system", 100);

            var idOut = command.CreateParameter();
            idOut.ParameterName = "@question_id_out";
            idOut.DbType        = DbType.Int64;
            idOut.Direction     = ParameterDirection.Output;
            command.Parameters.Add(idOut);

            await command.ExecuteNonQueryAsync(cancellationToken);
            var id = idOut.Value is long l ? l : Convert.ToInt64(idOut.Value);
            return new OrgAssuranceQuestionSaveResult(true, id);
        }
        catch (SqlException ex)
        {
            var reason = MapReason(ex.Number);
            logger.LogWarning(ex,
                "OrgAssuranceQuestionService.SaveQuestionAsync SQL error {Number}: {Message}",
                ex.Number, ex.Message);
            return new OrgAssuranceQuestionSaveResult(false, Error: ex.Message, ReasonCode: reason);
        }
    }

    public async Task<OrgAssuranceCommandResult> DeleteQuestionAsync(
        long organizationId, long questionId, string? actor, CancellationToken cancellationToken)
    {
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_org_assurance_question_delete";

            AddParam(command, "@organization_id", DbType.Int64,  organizationId);
            AddParam(command, "@question_id",     DbType.Int64,  questionId);
            AddParam(command, "@actor",           DbType.String, (object?)actor ?? (object)"system", 100);

            await command.ExecuteNonQueryAsync(cancellationToken);
            return new OrgAssuranceCommandResult(true, questionId);
        }
        catch (SqlException ex)
        {
            var reason = MapReason(ex.Number);
            logger.LogWarning(ex, "OrgAssuranceQuestionService.DeleteQuestionAsync SQL error {Number}: {Message}",
                ex.Number, ex.Message);
            return new OrgAssuranceCommandResult(false, Error: ex.Message, ReasonCode: reason);
        }
    }

    // -----------------------------------------------------------------
    // Question Repository (516) -- categories / subcategories
    // -----------------------------------------------------------------
    public async Task<OrgAssuranceQuestionCategoryTree> ListCategoriesAsync(
        long organizationId, CancellationToken cancellationToken)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_org_assurance_question_category_list";
        AddParam(command, "@organization_id", DbType.Int64, organizationId);

        var cats = new List<OrgAssuranceQuestionCategoryRow>();
        var subs = new List<OrgAssuranceQuestionSubcategoryRow>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            cats.Add(new OrgAssuranceQuestionCategoryRow(
                Convert.ToInt64(reader["CategoryId"]),
                reader["CategoryName"]?.ToString() ?? "",
                Convert.ToInt32(reader["DisplayOrder"]),
                Convert.ToInt64(reader["QuestionCount"])));
        }
        if (await reader.NextResultAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
            {
                subs.Add(new OrgAssuranceQuestionSubcategoryRow(
                    Convert.ToInt64(reader["SubcategoryId"]),
                    Convert.ToInt64(reader["CategoryId"]),
                    reader["SubcategoryName"]?.ToString() ?? "",
                    Convert.ToInt32(reader["DisplayOrder"]),
                    Convert.ToInt64(reader["QuestionCount"])));
            }
        }
        return new OrgAssuranceQuestionCategoryTree(cats, subs);
    }

    public async Task<OrgAssuranceCommandResult> SaveCategoryAsync(
        OrgAssuranceQuestionCategorySaveRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (string.IsNullOrWhiteSpace(request.CategoryName))
            return new OrgAssuranceCommandResult(false, Error: "Category name is required.", ReasonCode: "CATEGORY_NAME_REQUIRED");
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_org_assurance_question_category_save";
            AddParam(command, "@organization_id", DbType.Int64,  request.OrganizationId);
            AddParam(command, "@category_id",     DbType.Int64,  (object?)request.CategoryId ?? DBNull.Value);
            AddParam(command, "@category_name",   DbType.String, request.CategoryName.Trim(), 200);
            AddParam(command, "@display_order",   DbType.Int32,  (object?)request.DisplayOrder ?? DBNull.Value);
            AddParam(command, "@actor",           DbType.String, (object?)request.Actor ?? (object)"system", 100);
            var idOut = AddOutputId(command, "@category_id_out");
            await command.ExecuteNonQueryAsync(cancellationToken);
            return new OrgAssuranceCommandResult(true, Convert.ToInt64(idOut.Value));
        }
        catch (SqlException ex) { return SqlFailure(ex, nameof(SaveCategoryAsync)); }
    }

    public Task<OrgAssuranceCommandResult> DeleteCategoryAsync(
        long organizationId, long categoryId, string? actor, CancellationToken cancellationToken)
        => ExecuteDeleteAsync("grac_practice.sp_org_assurance_question_category_delete",
                              "@category_id", organizationId, categoryId, actor, cancellationToken);

    public async Task<OrgAssuranceCommandResult> SaveSubcategoryAsync(
        OrgAssuranceQuestionSubcategorySaveRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (string.IsNullOrWhiteSpace(request.SubcategoryName))
            return new OrgAssuranceCommandResult(false, Error: "Subcategory name is required.", ReasonCode: "SUBCATEGORY_NAME_REQUIRED");
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_org_assurance_question_subcategory_save";
            AddParam(command, "@organization_id",  DbType.Int64,  request.OrganizationId);
            AddParam(command, "@category_id",      DbType.Int64,  request.CategoryId);
            AddParam(command, "@subcategory_id",   DbType.Int64,  (object?)request.SubcategoryId ?? DBNull.Value);
            AddParam(command, "@subcategory_name", DbType.String, request.SubcategoryName.Trim(), 200);
            AddParam(command, "@display_order",    DbType.Int32,  (object?)request.DisplayOrder ?? DBNull.Value);
            AddParam(command, "@actor",            DbType.String, (object?)request.Actor ?? (object)"system", 100);
            var idOut = AddOutputId(command, "@subcategory_id_out");
            await command.ExecuteNonQueryAsync(cancellationToken);
            return new OrgAssuranceCommandResult(true, Convert.ToInt64(idOut.Value));
        }
        catch (SqlException ex) { return SqlFailure(ex, nameof(SaveSubcategoryAsync)); }
    }

    public Task<OrgAssuranceCommandResult> DeleteSubcategoryAsync(
        long organizationId, long subcategoryId, string? actor, CancellationToken cancellationToken)
        => ExecuteDeleteAsync("grac_practice.sp_org_assurance_question_subcategory_delete",
                              "@subcategory_id", organizationId, subcategoryId, actor, cancellationToken);

    // -----------------------------------------------------------------
    // Question Repository (516) -- questions
    // -----------------------------------------------------------------
    public async Task<OrgAssuranceRepositoryQuestionListResult> ListRepositoryQuestionsAsync(
        OrgAssuranceRepositoryQuestionListQuery query, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(query);
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_org_assurance_question_repository_list";
        AddParam(command, "@organization_id", DbType.Int64,  query.OrganizationId);
        AddParam(command, "@search",          DbType.String, (object?)query.Search ?? DBNull.Value, 200);
        AddParam(command, "@category_id",     DbType.Int64,  (object?)query.CategoryId ?? DBNull.Value);
        AddParam(command, "@subcategory_id",  DbType.Int64,  (object?)query.SubcategoryId ?? DBNull.Value);
        AddParam(command, "@status",          DbType.String, (object?)query.Status ?? DBNull.Value, 20);
        AddParam(command, "@exclude_set_id",  DbType.Int64,  (object?)query.ExcludeSetId ?? DBNull.Value);
        AddParam(command, "@page",            DbType.Int32,  Math.Max(1, query.Page));
        AddParam(command, "@page_size",       DbType.Int32,  Math.Clamp(query.PageSize, 1, 200));

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        long total = 0;
        int  page  = query.Page;
        int  size  = query.PageSize;
        if (await reader.ReadAsync(cancellationToken))
        {
            total = Convert.ToInt64(reader["TotalCount"]);
            page  = Convert.ToInt32(reader["PageNumber"]);
            size  = Convert.ToInt32(reader["PageSize"]);
        }
        var rows = new List<OrgAssuranceRepositoryQuestionRow>();
        if (await reader.NextResultAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
                rows.Add(MapRepositoryQuestionRow(reader));
        }
        return new OrgAssuranceRepositoryQuestionListResult(total, page, size, rows);
    }

    public async Task<OrgAssuranceRepositoryQuestionRow?> GetRepositoryQuestionAsync(
        long organizationId, long repositoryQuestionId, CancellationToken cancellationToken)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_org_assurance_question_repository_get";
        AddParam(command, "@organization_id",        DbType.Int64, organizationId);
        AddParam(command, "@repository_question_id", DbType.Int64, repositoryQuestionId);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        return await reader.ReadAsync(cancellationToken) ? MapRepositoryQuestionRow(reader) : null;
    }

    public async Task<OrgAssuranceCommandResult> SaveRepositoryQuestionAsync(
        OrgAssuranceRepositoryQuestionSaveRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (request.RepositoryQuestionId is null && string.IsNullOrWhiteSpace(request.QuestionCode))
            return new OrgAssuranceCommandResult(false, Error: "Question Code is required.", ReasonCode: "QUESTION_CODE_REQUIRED");
        if (string.IsNullOrWhiteSpace(request.QuestionText))
            return new OrgAssuranceCommandResult(false, Error: "Question is required.", ReasonCode: "QUESTION_TEXT_REQUIRED");
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_org_assurance_question_repository_save";
            AddParam(command, "@organization_id",        DbType.Int64,   request.OrganizationId);
            AddParam(command, "@repository_question_id", DbType.Int64,   (object?)request.RepositoryQuestionId ?? DBNull.Value);
            AddParam(command, "@question_code",          DbType.String,  (request.QuestionCode ?? "").Trim(), 80);
            AddParam(command, "@question_text",          DbType.String,  request.QuestionText.Trim(), -1);
            AddParam(command, "@category_id",            DbType.Int64,   request.CategoryId);
            AddParam(command, "@subcategory_id",         DbType.Int64,   (object?)request.SubcategoryId ?? DBNull.Value);
            AddParam(command, "@guidance",               DbType.String,  (object?)request.Guidance ?? DBNull.Value, -1);
            AddParam(command, "@question_type_id",       DbType.Int64,   (object?)request.QuestionTypeId ?? DBNull.Value);
            AddParam(command, "@question_type_code",     DbType.String,  (object?)request.QuestionTypeCode ?? DBNull.Value, 120);
            AddParam(command, "@question_type_name",     DbType.String,  (object?)request.QuestionTypeName ?? DBNull.Value, 200);
            AddParam(command, "@is_mandatory",           DbType.Boolean, request.IsMandatory ?? false);
            AddParam(command, "@evidence_required",      DbType.Boolean, request.EvidenceRequired ?? false);
            AddParam(command, "@expected_evidence",      DbType.String,  (object?)request.ExpectedEvidence ?? DBNull.Value, -1);
            AddParam(command, "@weight",                 DbType.Decimal, (object?)request.Weight ?? DBNull.Value);
            AddParam(command, "@status",                 DbType.String,  (object?)request.Status ?? (object)"Active", 20);
            AddParam(command, "@actor",                  DbType.String,  (object?)request.Actor ?? (object)"system", 100);
            var idOut = AddOutputId(command, "@repository_question_id_out");
            await command.ExecuteNonQueryAsync(cancellationToken);
            return new OrgAssuranceCommandResult(true, Convert.ToInt64(idOut.Value));
        }
        catch (SqlException ex) { return SqlFailure(ex, nameof(SaveRepositoryQuestionAsync)); }
    }

    public Task<OrgAssuranceCommandResult> DeleteRepositoryQuestionAsync(
        long organizationId, long repositoryQuestionId, string? actor, CancellationToken cancellationToken)
        => ExecuteDeleteAsync("grac_practice.sp_org_assurance_question_repository_delete",
                              "@repository_question_id", organizationId, repositoryQuestionId, actor, cancellationToken);

    /// <summary>Adds Repository questions to a set; Id carries the number added.</summary>
    public async Task<OrgAssuranceCommandResult> AddToSetFromRepositoryAsync(
        long questionSetId, OrgAssuranceSetAddFromRepositoryRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        var ids = (request.RepositoryQuestionIds ?? Array.Empty<long>()).Where(i => i > 0).Distinct().ToList();
        if (ids.Count == 0)
            return new OrgAssuranceCommandResult(false, Error: "Select at least one question.", ReasonCode: "NO_QUESTIONS_SELECTED");
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_org_assurance_question_set_add_from_repository";
            AddParam(command, "@organization_id",         DbType.Int64,  request.OrganizationId);
            AddParam(command, "@question_set_id",         DbType.Int64,  questionSetId);
            AddParam(command, "@repository_question_ids", DbType.String, string.Join(",", ids), -1);
            AddParam(command, "@actor",                   DbType.String, (object?)request.Actor ?? (object)"system", 100);
            var countOut = command.CreateParameter();
            countOut.ParameterName = "@added_count";
            countOut.DbType        = DbType.Int32;
            countOut.Direction     = ParameterDirection.Output;
            command.Parameters.Add(countOut);
            await command.ExecuteNonQueryAsync(cancellationToken);
            return new OrgAssuranceCommandResult(true, Convert.ToInt64(countOut.Value));
        }
        catch (SqlException ex) { return SqlFailure(ex, nameof(AddToSetFromRepositoryAsync)); }
    }

    private async Task<OrgAssuranceCommandResult> ExecuteDeleteAsync(
        string procedure, string idParam, long organizationId, long id, string? actor,
        CancellationToken cancellationToken)
    {
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = procedure;
            AddParam(command, "@organization_id", DbType.Int64,  organizationId);
            AddParam(command, idParam,            DbType.Int64,  id);
            AddParam(command, "@actor",           DbType.String, (object?)actor ?? (object)"system", 100);
            await command.ExecuteNonQueryAsync(cancellationToken);
            return new OrgAssuranceCommandResult(true, id);
        }
        catch (SqlException ex) { return SqlFailure(ex, procedure); }
    }

    private static DbParameter AddOutputId(DbCommand command, string name)
    {
        var p = command.CreateParameter();
        p.ParameterName = name;
        p.DbType        = DbType.Int64;
        p.Direction     = ParameterDirection.Output;
        command.Parameters.Add(p);
        return p;
    }

    private OrgAssuranceCommandResult SqlFailure(SqlException ex, string op)
    {
        logger.LogWarning(ex, "OrgAssuranceQuestionService.{Op} SQL error {Number}: {Message}",
            op, ex.Number, ex.Message);
        return new OrgAssuranceCommandResult(false, Error: ex.Message, ReasonCode: MapReason(ex.Number));
    }

    private static OrgAssuranceRepositoryQuestionRow MapRepositoryQuestionRow(System.Data.Common.DbDataReader r) => new(
        Convert.ToInt64(r["RepositoryQuestionId"]),
        Convert.ToInt64(r["OrganizationId"]),
        r["QuestionCode"]?.ToString() ?? "",
        r["QuestionText"]?.ToString() ?? "",
        Convert.ToInt64(r["CategoryId"]),
        r["CategoryName"]?.ToString() ?? "",
        ReadLongOrNull(r,   "SubcategoryId"),
        ReadStringOrNull(r, "SubcategoryName"),
        ReadStringOrNull(r, "Guidance"),
        ReadLongOrNull(r,   "QuestionTypeId"),
        ReadStringOrNull(r, "QuestionTypeCode"),
        ReadStringOrNull(r, "QuestionTypeName"),
        Convert.ToBoolean(r["IsMandatory"]),
        Convert.ToBoolean(r["EvidenceRequired"]),
        ReadStringOrNull(r, "ExpectedEvidence"),
        ReadDecimalOrNull(r, "Weight"),
        r["Status"]?.ToString() ?? "Active",
        Convert.ToInt32(r["VersionNumber"]),
        Convert.ToInt64(r["UsedInSets"]),
        ReadStringOrNull(r, "EnteredBy"),
        ReadDateTimeOrNull(r, "EnteredDt"),
        ReadStringOrNull(r, "UpdatedBy"),
        ReadDateTimeOrNull(r, "UpdatedDt"));

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------
    private async Task<DbConnection> OpenAsync(CancellationToken cancellationToken)
    {
        var connString = Infrastructure.SqlConnectionStringResolver.Resolve(configuration);
        if (string.IsNullOrWhiteSpace(connString))
            throw new InvalidOperationException("PracticeManagement connection string is not configured.");
        var connection = new SqlConnection(connString);
        await connection.OpenAsync(cancellationToken);
        await Infrastructure.ViewScopeSession.ApplyAsync(connection, cancellationToken);   // 415: View Data Scope
        return connection;
    }

    private static void AddParam(DbCommand command, string name, DbType type, object? value, int? size = null)
    {
        var p = command.CreateParameter();
        p.ParameterName = name;
        p.DbType        = type;
        if (size.HasValue) p.Size = size.Value;
        p.Value = value ?? DBNull.Value;
        command.Parameters.Add(p);
    }

    private static long?    ReadLongOrNull(System.Data.Common.DbDataReader r, string col)     => r[col] == DBNull.Value ? null : Convert.ToInt64(r[col]);
    private static int?     ReadIntOrNull(System.Data.Common.DbDataReader r, string col)      => r[col] == DBNull.Value ? null : Convert.ToInt32(r[col]);
    private static decimal? ReadDecimalOrNull(System.Data.Common.DbDataReader r, string col)  => r[col] == DBNull.Value ? null : Convert.ToDecimal(r[col]);
    private static DateTime? ReadDateTimeOrNull(System.Data.Common.DbDataReader r, string col)=> r[col] == DBNull.Value ? null : Convert.ToDateTime(r[col]);
    private static string?  ReadStringOrNull(System.Data.Common.DbDataReader r, string col)   => r[col] == DBNull.Value ? null : r[col].ToString();

    private static OrgAssuranceQuestionRow MapQuestionRow(System.Data.Common.DbDataReader r) => new(
        Convert.ToInt64(r["QuestionId"]),
        Convert.ToInt64(r["QuestionSetId"]),
        r["QuestionCode"]?.ToString() ?? "",
        r["QuestionText"]?.ToString() ?? "",
        ReadStringOrNull(r, "HelpText"),
        ReadLongOrNull(r,   "QuestionTypeId"),
        ReadStringOrNull(r, "QuestionTypeCode"),
        ReadStringOrNull(r, "QuestionTypeName"),
        Convert.ToBoolean(r["IsMandatory"]),
        Convert.ToInt32(r["DisplayOrder"]),
        ReadDecimalOrNull(r, "Weight"),
        ReadStringOrNull(r, "ExpectedResponse"),
        ReadStringOrNull(r, "EnteredBy"),
        ReadDateTimeOrNull(r, "EnteredDt"),
        ReadStringOrNull(r, "UpdatedBy"),
        ReadDateTimeOrNull(r, "UpdatedDt"),
        ReadLongOrNull(r,   "RepositoryQuestionId"),   // 516
        ReadStringOrNull(r, "CategoryName"),
        ReadStringOrNull(r, "SubcategoryName"));

    // Reason mapping for SP THROW numbers (077, 516).
    private static string MapReason(int errorNumber) => errorNumber switch
    {
        53801 => "ORGANIZATION_ID_REQUIRED",
        53802 => "IDS_REQUIRED",
        53803 => "CODE_REQUIRED",
        53804 => "NAME_REQUIRED",
        53805 => "DUPLICATE_SET_CODE",
        53806 => "SET_NOT_FOUND",
        53807 => "WRONG_ORGANIZATION",
        53808 => "QUESTION_CODE_REQUIRED",
        53809 => "QUESTION_TEXT_REQUIRED",
        53810 => "DUPLICATE_QUESTION_CODE",
        53811 => "QUESTION_NOT_FOUND",
        53812 => "SET_MISMATCH",
        // 516 Question Repository
        53301 => "ORGANIZATION_ID_REQUIRED",
        53302 => "CATEGORY_NAME_REQUIRED",
        53303 => "DUPLICATE_CATEGORY",
        53304 => "CATEGORY_NOT_FOUND",
        53305 => "WRONG_ORGANIZATION",
        53306 => "CATEGORY_IN_USE",
        53307 => "DUPLICATE_SUBCATEGORY",
        53308 => "SUBCATEGORY_NOT_FOUND",
        53309 => "SUBCATEGORY_IN_USE",
        53310 => "SUBCATEGORY_NAME_REQUIRED",
        53311 => "REPOSITORY_QUESTION_NOT_FOUND",
        53312 => "QUESTION_IN_USE",
        53313 => "QUESTION_CODE_REQUIRED",
        53314 => "QUESTION_TEXT_REQUIRED",
        53315 => "CATEGORY_REQUIRED",
        53316 => "RESPONSE_TYPE_REQUIRED",
        53317 => "DUPLICATE_QUESTION_CODE",
        53318 => "SUBCATEGORY_MISMATCH",
        53319 => "INVALID_STATUS",
        53320 => "ADD_FROM_REPOSITORY",
        53322 => "NO_QUESTIONS_SELECTED",
        53323 => "QUESTION_INACTIVE",
        2627 or 2601 => "DUPLICATE",
        _     => "SQL_ERROR"
    };
}
