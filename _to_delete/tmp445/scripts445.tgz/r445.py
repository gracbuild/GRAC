# Builds 445_b.sql (shared move procedure + re-issued sp_asset_merge_execute_one)
# and 445_e.sql (re-issued sp_asset_merge_recover, sp_asset_merge_action,
# sp_asset_merge_events) from the 444 bodies; keeps the 444 bodies for the rollback.
import re
src = open("/home/claude/444.sql").read()
def body(name):
    m = re.search(r"CREATE OR ALTER PROCEDURE grac_practice\." + name + r"\n.*?\nEND\nGO\n", src, re.S)
    return m.group(0)
orig = {n: body(n) for n in ["sp_asset_merge_execute_one", "sp_asset_merge_recover", "sp_asset_merge_action", "sp_asset_merge_events"]}
open("/home/claude/bodies444.sql", "w").write("".join(orig.values()))
M = "   -- 445"

# ---------------------------------------------------------------- shared move procedure
ex = orig["sp_asset_merge_execute_one"]
L = ex.split("\n")
start = [i for i, l in enumerate(L) if l.startswith("    -- ----") and "relationships" in l][0]
end = [i for i, l in enumerate(L) if l.startswith("    -- ----") and "field values (D117)" in l][0]
section = "\n".join(L[start:end]).rstrip() + "\n"
moved = (section.replace("@survivor_name", "@to_name").replace("@survivor", "@to_asset").replace("@duplicate", "@from_asset")
                .replace("FROM @plan", "FROM #msplan").replace("JOIN @plan", "JOIN #msplan"))
assert "@plan" not in moved and "@survivor" not in moved and "@duplicate" not in moved
move_proc = """
-- =====================================================================
-- 2. Object moves shared by merge and split (D126). The statements are the
--    444 ones of sp_asset_merge_execute_one, with @duplicate -> @from_asset,
--    @survivor -> @to_asset, @survivor_name -> @to_name and the plan in the
--    caller-created #msplan (object_kind, object_id, object_key,
--    object_label, outcome MOVE / END / RESOLVE / KEEP, detail).
-- =====================================================================
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_merge_split_move
    @organization_id   BIGINT,
    @event_id          BIGINT,
    @from_asset        BIGINT,
    @to_asset          BIGINT,
    @note              NVARCHAR(400),
    @actor_employee_id BIGINT        = NULL,
    @actor             NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @to_name NVARCHAR(300) = (SELECT asset_name FROM grac_practice.organization_dependency_asset WHERE asset_id = @to_asset);
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

""" + moved + """END
GO
"""

# ---------------------------------------------------------------- execute_one re-issued
e = ex
def rep(s, a, b):
    assert s.count(a) == 1, a[:70]
    return s.replace(a, b)
e = rep(e, """    DECLARE @plan TABLE (object_kind NVARCHAR(20) NOT NULL, object_id BIGINT NULL, object_key NVARCHAR(200) NULL,
                         object_label NVARCHAR(400) NULL, outcome NVARCHAR(10) NOT NULL, detail NVARCHAR(600) NULL);
    INSERT @plan (object_kind, object_id, object_key, object_label, outcome, detail)
""", """    CREATE TABLE #msplan (object_kind NVARCHAR(20) COLLATE DATABASE_DEFAULT NOT NULL, object_id BIGINT NULL,""" + M + """
                          object_key NVARCHAR(200) COLLATE DATABASE_DEFAULT NULL, object_label NVARCHAR(400) COLLATE DATABASE_DEFAULT NULL,""" + M + """
                          outcome NVARCHAR(10) COLLATE DATABASE_DEFAULT NOT NULL, detail NVARCHAR(600) COLLATE DATABASE_DEFAULT NULL);""" + M + """
    INSERT #msplan (object_kind, object_id, object_key, object_label, outcome, detail)""" + M + """
""")
e = rep(e, """    IF EXISTS (SELECT 1 FROM @plan WHERE outcome = N'BLOCK')
""", """    IF EXISTS (SELECT 1 FROM #msplan WHERE outcome = N'BLOCK')""" + M + """
""")
e = rep(e, """    DECLARE @survivor_name NVARCHAR(300) = (SELECT asset_name FROM grac_practice.organization_dependency_asset WHERE asset_id = @survivor);
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE), @note NVARCHAR(400) = CONCAT(N'Merge #', @event_id, N': asset #', @duplicate,
""", """    DECLARE @note NVARCHAR(400) = CONCAT(N'Merge #', @event_id, N': asset #', @duplicate,""" + M + """
""")
assert e.count(section) == 1
e = e.replace(section, """    -- the object moves (relationships ... practice resolutions) are shared with split (D126)""" + M + """
    EXEC grac_practice.sp_asset_merge_split_move""" + M + """
         @organization_id = @organization_id, @event_id = @event_id, @from_asset = @duplicate, @to_asset = @survivor,""" + M + """
         @note = @note, @actor_employee_id = @actor_employee_id, @actor = @actor;""" + M + """

""")
open("/home/claude/445_b.sql", "w").write(move_proc + """
-- sp_asset_merge_execute_one (444) re-issued: the object moves now run in
-- sp_asset_merge_split_move (same statements); plan in #msplan.
""" + e + "PRINT '445: sp_asset_merge_split_move created; sp_asset_merge_execute_one re-issued.';\nGO\n")

# ---------------------------------------------------------------- recover re-issued (values a split cleared)
r = orig["sp_asset_merge_recover"]
r = rep(r, """            IF EXISTS (SELECT 1 FROM grac_practice.asset_field_value WHERE asset_id = @to_asset AND field_definition_id = @oid AND value_text = @after)
""", """            IF (@after IS NOT NULL""" + M + """
                AND EXISTS (SELECT 1 FROM grac_practice.asset_field_value WHERE asset_id = @to_asset AND field_definition_id = @oid AND value_text = @after))""" + M + """
               OR (@after IS NULL AND @before IS NOT NULL""" + M + """
                   AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_field_value WHERE asset_id = @to_asset AND field_definition_id = @oid))""" + M + """
""")
r = rep(r, """                    DELETE FROM grac_practice.asset_field_value WHERE asset_id = @to_asset AND field_definition_id = @oid;
                END
                ELSE
""", """                    DELETE FROM grac_practice.asset_field_value WHERE asset_id = @to_asset AND field_definition_id = @oid;
                END
                ELSE IF @after IS NULL""" + M + """
                BEGIN""" + M + """
                    -- a split moved the value away from the source: put it back""" + M + """
                    INSERT grac_practice.asset_field_value""" + M + """
                        (asset_id, field_definition_id, value_text, value_number, value_date, value_ref, entered_by)""" + M + """
                    SELECT @to_asset, f.field_definition_id, @before,""" + M + """
                           TRY_CONVERT(DECIMAL(38, 6), CASE WHEN f.data_type_code = N'QUANTITY_UNIT'""" + M + """
                                                            THEN LEFT(@before, CHARINDEX(N' ', @before + N' ') - 1) ELSE @before END),""" + M + """
                           CASE WHEN f.data_type_code = N'DATE' THEN TRY_CONVERT(DATE, @before, 23) END,""" + M + """
                           CASE WHEN f.lookup_source LIKE N'MASTER:%' AND f.data_type_code NOT IN (N'MULTI_SELECT', N'MULTI_USER')""" + M + """
                                THEN TRY_CONVERT(BIGINT, @before) END, @actor""" + M + """
                      FROM grac_practice.asset_field_definition f WHERE f.field_definition_id = @oid;""" + M + """
                END""" + M + """
                ELSE
""")

# ---------------------------------------------------------------- action re-issued (both kinds)
a = orig["sp_asset_merge_action"]
a = rep(a, """            @requested_by NVARCHAR(100), @requested_emp BIGINT, @required INT;
""", """            @requested_by NVARCHAR(100), @requested_emp BIGINT, @required INT, @kind NVARCHAR(10);""" + M + """
""")
a = rep(a, """           @required = approvals_required
      FROM grac_practice.asset_merge_split_event
     WHERE event_id = @event_id AND organization_id = @organization_id AND event_kind = N'MERGE';
""", """           @required = approvals_required, @kind = event_kind""" + M + """
      FROM grac_practice.asset_merge_split_event
     WHERE event_id = @event_id AND organization_id = @organization_id AND event_kind IN (N'MERGE', N'SPLIT');""" + M + """
""")
a = rep(a, """             WHERE m.event_id = @event_id);
        IF @blk IS NOT NULL
""", """             WHERE m.event_id = @event_id);
        IF @kind = N'SPLIT'""" + M + """
            SET @blk = (SELECT LEFT(STRING_AGG(CAST(b.Detail AS NVARCHAR(MAX)), N' | '), 1400)""" + M + """
                          FROM grac_practice.fn_asset_split_blockers(@organization_id, @event_id) b);""" + M + """
        IF @blk IS NOT NULL
""")
a = rep(a, """               preview_json = (SELECT p.ObjectKind AS kind, p.Outcome AS outcome, COUNT(*) AS items
""", """               preview_json = CASE WHEN @kind = N'SPLIT'""" + M + """
                              THEN (SELECT x.ObjectKind AS kind, x.Outcome AS outcome, COUNT(*) AS items""" + M + """
                                      FROM grac_practice.fn_asset_split_plan(@organization_id, @event_id) x""" + M + """
                                     GROUP BY x.ObjectKind, x.Outcome FOR JSON PATH)""" + M + """
                              ELSE (SELECT p.ObjectKind AS kind, p.Outcome AS outcome, COUNT(*) AS items""" + M + """
""")
a = rep(a, """                                GROUP BY p.ObjectKind, p.Outcome FOR JSON PATH)
""", """                                GROUP BY p.ObjectKind, p.Outcome FOR JSON PATH) END""" + M + """
""")
a = rep(a, """        DECLARE @dup BIGINT;
        DECLARE dup_cur CURSOR LOCAL STATIC FOR
            SELECT asset_id FROM grac_practice.asset_merge_split_member WHERE event_id = @event_id ORDER BY sequence_no;
""", """        DECLARE @dup BIGINT;
        IF @kind = N'SPLIT'""" + M + """
            EXEC grac_practice.sp_asset_split_execute @organization_id = @organization_id, @event_id = @event_id,""" + M + """
                 @actor_employee_id = @actor_employee_id, @actor = @actor;""" + M + """
        DECLARE dup_cur CURSOR LOCAL STATIC FOR
            SELECT asset_id FROM grac_practice.asset_merge_split_member WHERE event_id = @event_id AND @kind = N'MERGE' ORDER BY sequence_no;""" + M + """
""")
a = rep(a, """    VALUES (N'asset-merge', @event_id, @action, (SELECT @status AS status FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
""", """    VALUES (CASE WHEN @kind = N'SPLIT' THEN N'asset-split' ELSE N'asset-merge' END, @event_id, @action,""" + M + """
            (SELECT @status AS status FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),""" + M + """
""")

# ---------------------------------------------------------------- events re-issued (kind)
v = orig["sp_asset_merge_events"]
v = rep(v, """    @page_size       INT           = 25
AS
""", """    @page_size       INT           = 25,""" + M + """
    @event_kind      NVARCHAR(10)  = N'MERGE'""" + M + """
AS
""")
v = rep(v, """     WHERE e.organization_id = @organization_id AND e.event_kind = N'MERGE'
""", """     WHERE e.organization_id = @organization_id AND e.event_kind = ISNULL(@event_kind, N'MERGE')""" + M + """
""")
hdr = """
-- =====================================================================
-- 6. 444 procedures re-issued for split (D127, D130)
--    sp_asset_merge_recover: a value a split moved off the source (row with
--      no after value) is put back when the source still has none.
--    sp_asset_merge_action: one action procedure for MERGE and SPLIT (same
--      statuses, approval and two-person rules); split blockers, plan
--      counts and execution are the split ones.
--    sp_asset_merge_events: @event_kind (default MERGE).
-- =====================================================================
"""
open("/home/claude/445_e.sql", "w").write(hdr + r + a + v + "PRINT '445: 444 recovery, action and list re-issued.';\nGO\n")
print("r445 ok")
