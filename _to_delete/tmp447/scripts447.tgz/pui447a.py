import sys
R=sys.argv[1] if len(sys.argv)>1 else '/home/claude/w447/new'
W=R+'/src/PracticeManagement.Web/'
def edit(path, old, new, count=1):
    s=open(path).read(); assert s.count(old)==count, (path, old[:90], s.count(old)); open(path,'w').write(s.replace(old,new))
C=W+'Views/Practice/Partials/asset-valuation-config.cshtml'
edit(C, """    Backend: practice/api/asset-config/valuation... (AssetConfigController)
""", """    447 (BRD 19.7): Consistency rules -- per-organization rules over CIA,
    Asset Value, criticality, supported-service criticality and asset
    fields (conditions in a group all hold; any group may hold), with
    scope, severity, action, acceptance settings and effective dates;
    Draft -> Active (another person, APPROVE) -> Retired, new versions as
    Drafts; Preview lists the assets a rule matches now. Findings are
    worked on the Asset Register.

    Backend: practice/api/asset-config/valuation... (AssetConfigController)
""")
edit(C, """            <button class="pm-button" id="avcRecalcBtn" type="button">
                <i class="fa-solid fa-calculator"></i> Recalculation
            </button>
""", """            <button class="pm-button" id="avcRecalcBtn" type="button">
                <i class="fa-solid fa-calculator"></i> Recalculation
            </button>
            <button class="pm-button" id="avcRulesBtn" type="button">
                <i class="fa-solid fa-scale-balanced"></i> Consistency rules
            </button>
""")
edit(C, """    @* =========================== Design view =========================== *@
""", """    @* ===================== Consistency rules view (447) ===================== *@
    <section id="avcRulesView" hidden>
        <div class="pm-panel avc-head">
            <div class="avc-head-main">
                <button class="pm-button" id="avcRulesBack" type="button"><i class="fa-solid fa-arrow-left"></i> Configurations</button>
                <div>
                    <div class="avc-head-title">CIA and criticality consistency rules</div>
                    <div class="avc-head-meta">Findings appear on the Asset Register (Valuation tab and Consistency findings).</div>
                </div>
            </div>
            <div class="avc-head-actions">
                @if (avcCanEdit)
                {
                    <button class="pm-button primary" id="avcRuleNew" type="button"><i class="fa-solid fa-plus"></i> New rule</button>
                }
            </div>
        </div>
        <p class="pm-message" id="avcRulesMessage" role="status" aria-live="polite" hidden></p>
        <div class="pm-panel">
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Rule</th><th>Version</th><th>Status</th><th>Scope</th><th>Severity</th><th>Action</th><th>Effective</th><th>Findings</th></tr></thead>
                    <tbody id="avcRulesBody"></tbody>
                </table>
            </div>
        </div>
        <div class="pm-panel" id="avcRuleEditor" hidden>
            <div class="avc-head">
                <div>
                    <div class="avc-head-title" id="avcRuleTitle">--</div>
                    <div class="avc-head-meta" id="avcRuleMeta"></div>
                </div>
                <div class="avc-head-actions" id="avcRuleActions"></div>
            </div>
            <form id="avcRuleForm" class="pm-form-grid">
                <label class="full"><span>Rule name *</span><input type="text" id="avcRuleName" maxlength="200" /></label>
                <label class="full"><span>Description</span><textarea id="avcRuleDesc" rows="2" maxlength="1000"></textarea></label>
                <label><span>Scope *</span><select id="avcRuleScopeKind"></select></label>
                <label><span>Applies to</span><select id="avcRuleScopeRef"></select></label>
                <label><span>Severity *</span><select id="avcRuleSeverity"></select></label>
                <label><span>Action *</span><select id="avcRuleAction"></select></label>
                <label class="avc-check"><input type="checkbox" id="avcRuleOverride" /> <span>An inconsistency may be accepted (rationale, owner, review date)</span></label>
                <label><span>Longest acceptance (days)</span><input type="number" id="avcRuleMaxDays" min="1" max="1095" step="1" /></label>
                <label><span>Effective from</span><input type="date" id="avcRuleFrom" /></label>
                <label><span>Effective to</span><input type="date" id="avcRuleTo" /></label>
                <label class="full"><span>Change reason</span><textarea id="avcRuleReason" rows="2" maxlength="1000"></textarea></label>
                <div class="full">
                    <div class="avc-head">
                        <h3 class="avc-sub">Conditions <small>(conditions in a group must all hold; any group may hold)</small></h3>
                        <button class="pm-button" type="button" id="avcCondAdd"><i class="fa-solid fa-plus"></i> Add condition</button>
                    </div>
                    <div class="pm-table-wrap">
                        <table>
                            <thead><tr><th>Group</th><th>Operand</th><th>Operator</th><th>Value</th><th></th></tr></thead>
                            <tbody id="avcCondBody"></tbody>
                        </table>
                    </div>
                    <p class="avc-note">Example (BRD 19.7): Asset Value Category equals Critical and Criticality (name) equals Low. For "is one of", separate values with |.</p>
                </div>
            </form>
            <h3 class="avc-sub">Preview</h3>
            <p class="avc-note" id="avcRulePreviewNote">Preview lists the assets the saved rule matches now.</p>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Asset</th><th>Status</th><th>Values</th><th>Finding</th></tr></thead>
                    <tbody id="avcRulePreviewBody"></tbody>
                </table>
            </div>
            <h3 class="avc-sub">Versions</h3>
            <div class="pm-table-wrap">
                <table>
                    <thead><tr><th>Version</th><th>Status</th><th>Effective</th><th>Reason</th><th>Activated</th></tr></thead>
                    <tbody id="avcRuleVersions"></tbody>
                </table>
            </div>
        </div>
    </section>

    @* =========================== Design view =========================== *@
""")

J=W+'wwwroot/js/AssetConfig/asset-valuation-config.js'
edit(J, """// run with a reason against the affected count shown (409 when it moved).
""", """// run with a reason against the affected count shown (409 when it moved).
// 447: Consistency rules view -- valuation/consistency/rules (list, get,
// save, preview, action ACTIVATE / RETIRE / NEW_VERSION / DISCARD) and
// valuation/consistency/operands; the rules are enforced by the procedures.
""")
edit(J, """  const state = { organizationId: null, rows: [], detail: null, preview: null };
""", """  const state = { organizationId: null, rows: [], detail: null, preview: null, ruleOps: null, rules: [], rule: null };   // 447: rules
""")
edit(J, """    document.getElementById("avcRecalcRun")?.addEventListener("click", runRecalc);
""", """    document.getElementById("avcRecalcRun")?.addEventListener("click", runRecalc);
    // 447
    document.getElementById("avcRulesBtn").addEventListener("click", openRules);
    document.getElementById("avcRulesBack").addEventListener("click", showList);
    document.getElementById("avcRuleNew")?.addEventListener("click", newRule);
    document.getElementById("avcRulesBody").addEventListener("click", ev => {
      const tr = ev.target.closest("tr[data-avc-rule]");
      if (tr) openRule(Number(tr.dataset.avcRule));
    });
    document.getElementById("avcRuleScopeKind").addEventListener("change", () => fillScopeRefs(val("avcRuleScopeKind"), null));
    document.getElementById("avcCondAdd").addEventListener("click", () => {
      const conds = readConds();
      conds.push({ groupNo: conds.length ? conds[conds.length - 1].groupNo : 1, operandKey: "", operatorCode: "EQ", compareValue: "" });
      renderConds(conds);
    });
    document.getElementById("avcCondBody").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-avc-cond-remove]");
      if (!b) return;
      const conds = readConds();
      conds.splice(Number(b.dataset.avcCondRemove), 1);
      renderConds(conds);
    });
    document.getElementById("avcCondBody").addEventListener("change", ev => {
      if (ev.target.matches("select[data-avc-cond-op]")) renderConds(readConds());
    });
    document.getElementById("avcRuleActions").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-avc-rule-act]");
      if (b) ruleAction(b.dataset.avcRuleAct);
    });
""")
edit(J, """    document.getElementById("avcRecalcView").hidden = true;   // 446
    document.getElementById("avcListView").hidden = false;
""", """    document.getElementById("avcRecalcView").hidden = true;   // 446
    document.getElementById("avcRulesView").hidden = true;    // 447
    document.getElementById("avcListView").hidden = false;
""")
edit(J, """  function recalcMessage(text, kind) {""", """  // ------------------------------------------------------------------ consistency rules (447)
  const SCOPE = { TENANT: "Whole organization", CATEGORY: "Category", SUBCATEGORY: "Subcategory", ASSET_TYPE: "Asset type", SERVICE: "Business service" };
  const SEVERITY = { INFO: "Information", WARNING: "Warning", ERROR: "Error", APPROVAL_REQUIRED: "Approval Required" };
  const ACTION = { WARN: "Warn", REQUIRE_RATIONALE: "Require rationale", CREATE_TASK: "Create task", BLOCK_TRANSITION: "Block move to Active" };
  const OPERATOR = { EQ: "equals", NEQ: "does not equal", IN: "is one of", NOT_IN: "is not one of", EMPTY: "is empty", NOT_EMPTY: "is not empty",
                     GT: "greater than", GTE: "at least", LT: "less than", LTE: "at most",
                     DATE_BEFORE_TODAY: "date before today", DATE_AFTER_TODAY: "date after today", DATE_WITHIN_DAYS: "date within (days)" };
  const NO_VALUE = new Set(["EMPTY", "NOT_EMPTY", "DATE_BEFORE_TODAY", "DATE_AFTER_TODAY"]);
  const optionsOf = (map, sel) => Object.entries(map).map(([k, v]) => `<option value="${k}"${k === sel ? " selected" : ""}>${esc(v)}</option>`).join("");

  async function openRules() {
    if (!state.organizationId) { await notify("Select an organization first.", "warning"); return; }
    document.getElementById("avcListView").hidden = true;
    document.getElementById("avcDesignView").hidden = true;
    document.getElementById("avcRecalcView").hidden = true;
    document.getElementById("avcRulesView").hidden = false;
    document.getElementById("avcRuleEditor").hidden = true;
    rulesMessage("");
    state.ruleOps = null;
    const res = await api("GET", `/consistency/operands?organizationId=${state.organizationId}`);
    if (!res.ok) { rulesMessage(res.error, "error"); return; }
    state.ruleOps = res.data.data || { operands: [], scopes: [] };
    await loadRules();
  }

  async function loadRules() {
    const body = document.getElementById("avcRulesBody");
    const res = await api("GET", `/consistency/rules?organizationId=${state.organizationId}`);
    if (!res.ok) { body.innerHTML = `<tr><td colspan="8" class="pm-empty">${esc(res.error)}</td></tr>`; return; }
    state.rules = res.data.data || [];
    body.innerHTML = state.rules.map(r => `
      <tr class="pm-row-clickable" data-avc-rule="${r.ruleId}">
        <td>${esc(r.ruleCode)}<div class="avc-note">${esc(r.ruleName)}</div></td><td>v${esc(r.versionNo)}</td><td>${chip(r.status)}</td>
        <td>${esc(r.scopeLabel)}</td><td>${esc(SEVERITY[r.severity] || r.severity)}</td><td>${esc(ACTION[r.actionCode] || r.actionCode)}</td>
        <td>${esc(dateRange(r.effectiveFrom, r.effectiveTo))}</td>
        <td>${r.status === "ACTIVE" ? `${esc(r.openFindings)} open / ${esc(r.acceptedFindings)} accepted` : "--"}</td>
      </tr>`).join("") || `<tr><td colspan="8" class="pm-empty">No consistency rule yet${CAN_EDIT ? " -- use New rule." : "."}</td></tr>`;
  }

  function newRule() {
    state.rule = {
      rule: { status: "DRAFT", scopeKind: "TENANT", severity: "WARNING", actionCode: "WARN", overrideAllowed: true },
      conditions: [{ groupNo: 1, operandKey: "", operatorCode: "EQ", compareValue: "" }], versions: []
    };
    renderRule();
  }

  async function openRule(id) {
    const res = await api("GET", `/consistency/rules/${id}?organizationId=${state.organizationId}`);
    if (!res.ok) { rulesMessage(res.error, "error"); return; }
    state.rule = res.data.data;
    renderRule();
  }

  function ruleEditable() { const r = state.rule && state.rule.rule; return CAN_EDIT && !!r && r.status === "DRAFT"; }

  function renderRule() {
    const d = state.rule, r = d.rule, edit = ruleEditable();
    document.getElementById("avcRuleEditor").hidden = false;
    document.getElementById("avcRuleTitle").textContent = r.ruleId ? `${r.ruleCode} v${r.versionNo} -- ${r.ruleName}` : "New rule";
    document.getElementById("avcRuleMeta").innerHTML = r.ruleId
      ? `${chip(r.status)} ${esc(r.scopeLabel || "")}${r.activatedBy ? ` -- activated by ${esc(r.activatedBy)} ${esc(dateTime(r.activatedDt))}` : ""}`
        + (r.status === "DRAFT" ? ` -- last saved by ${esc(r.lastChangedBy)}; another person activates it` : "")
      : "Not saved yet.";
    setVal("avcRuleName", r.ruleName); setVal("avcRuleDesc", r.description);
    document.getElementById("avcRuleScopeKind").innerHTML = optionsOf(SCOPE, r.scopeKind || "TENANT");
    fillScopeRefs(r.scopeKind || "TENANT", r.scopeRefId);
    document.getElementById("avcRuleSeverity").innerHTML = optionsOf(SEVERITY, r.severity);
    document.getElementById("avcRuleAction").innerHTML = optionsOf(ACTION, r.actionCode);
    document.getElementById("avcRuleOverride").checked = r.overrideAllowed !== false;
    setVal("avcRuleMaxDays", r.maxOverrideDays); setVal("avcRuleFrom", isoDate(r.effectiveFrom)); setVal("avcRuleTo", isoDate(r.effectiveTo));
    setVal("avcRuleReason", r.changeReason);
    renderConds(d.conditions || []);
    document.querySelectorAll("#avcRuleForm input, #avcRuleForm select, #avcRuleForm textarea").forEach(el => { el.disabled = !edit; });
    if (!edit) document.getElementById("avcRuleScopeRef").disabled = true;
    document.getElementById("avcCondAdd").hidden = !edit;
    const acts = [];
    if (edit) acts.push(["SAVE", "Save draft", "primary", "fa-floppy-disk"]);
    if (r.ruleId) acts.push(["PREVIEW", "Preview", "", "fa-eye"]);
    if (r.ruleId && r.status === "DRAFT" && CAN_APPROVE) acts.push(["ACTIVATE", "Activate", "", "fa-circle-check"]);
    if (r.ruleId && r.status === "DRAFT" && CAN_EDIT) acts.push(["DISCARD", "Discard", "", "fa-trash-can"]);
    if (r.status === "ACTIVE" && CAN_APPROVE) acts.push(["RETIRE", "Retire", "", "fa-box-archive"]);
    if ((r.status === "ACTIVE" || r.status === "RETIRED") && CAN_EDIT) acts.push(["NEW_VERSION", "New version", "", "fa-code-branch"]);
    document.getElementById("avcRuleActions").innerHTML = acts.map(([a, label, cls, icon]) =>
      `<button class="pm-button ${cls}" type="button" data-avc-rule-act="${a}"><i class="fa-solid ${icon}"></i> ${esc(label)}</button>`).join("");
    document.getElementById("avcRulePreviewBody").innerHTML = `<tr><td colspan="4" class="pm-empty">${r.ruleId ? "Use Preview." : "Save the rule first."}</td></tr>`;
    document.getElementById("avcRulePreviewNote").textContent = "Preview lists the assets the saved rule matches now.";
    document.getElementById("avcRuleVersions").innerHTML = (d.versions || []).map(v => `
      <tr><td>v${esc(v.versionNo)}</td><td>${chip(v.status)}</td><td>${esc(dateRange(v.effectiveFrom, v.effectiveTo))}</td>
          <td>${esc(v.changeReason || "")}</td><td>${esc(v.activatedBy || "")}${v.activatedDt ? `<div class="avc-note">${esc(dateTime(v.activatedDt))}</div>` : ""}</td></tr>`).join("")
      || `<tr><td colspan="5" class="pm-empty">--</td></tr>`;
    document.getElementById("avcRuleEditor").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function fillScopeRefs(kind, selected) {
    const el = document.getElementById("avcRuleScopeRef");
    const opts = ((state.ruleOps || {}).scopes || []).filter(s => s.scopeKind === kind);
    el.innerHTML = kind === "TENANT" ? `<option value="">--</option>`
      : `<option value="">Select</option>` + opts.map(s => `<option value="${esc(s.scopeRefId)}"${String(s.scopeRefId) === String(selected) ? " selected" : ""}>${esc(s.scopeLabel)}</option>`).join("");
    el.disabled = kind === "TENANT" || !ruleEditable();
  }

  function renderConds(conds) {
    const edit = ruleEditable();
    const ops = (state.ruleOps || {}).operands || [];
    const operandOptions = sel => `<option value="">Select</option>`
      + `<optgroup label="Derived">${ops.filter(o => o.operandKind === "DERIVED").map(o => `<option value="${esc(o.operandKey)}"${o.operandKey === sel ? " selected" : ""} title="${esc(o.hint || "")}">${esc(o.operandLabel)}</option>`).join("")}</optgroup>`
      + `<optgroup label="Asset fields">${ops.filter(o => o.operandKind === "FIELD").map(o => `<option value="${esc(o.operandKey)}"${o.operandKey === sel ? " selected" : ""}>${esc(o.operandLabel)} (${esc(o.operandKey)})</option>`).join("")}</optgroup>`;
    document.getElementById("avcCondBody").innerHTML = conds.map((c, i) => `
      <tr><td><input type="number" min="1" step="1" data-avc-cond-group value="${esc(c.groupNo || 1)}"${edit ? "" : " disabled"} /></td>
          <td><select data-avc-cond-operand${edit ? "" : " disabled"}>${operandOptions(c.operandKey)}</select></td>
          <td><select data-avc-cond-op${edit ? "" : " disabled"}>${optionsOf(OPERATOR, c.operatorCode || "EQ")}</select></td>
          <td><input type="text" maxlength="400" data-avc-cond-value value="${esc(NO_VALUE.has(c.operatorCode) ? "" : (c.compareValue || ""))}"${edit && !NO_VALUE.has(c.operatorCode) ? "" : " disabled"} /></td>
          <td>${edit ? `<button class="pm-button icon" type="button" data-avc-cond-remove="${i}" title="Remove" aria-label="Remove"><i class="fa-solid fa-xmark"></i></button>` : ""}</td></tr>`).join("")
      || `<tr><td colspan="5" class="pm-empty">No condition.</td></tr>`;
  }

  function readConds() {
    return [...document.querySelectorAll("#avcCondBody tr")].filter(tr => tr.querySelector("select[data-avc-cond-op]")).map(tr => ({
      groupNo: Number(tr.querySelector("input[data-avc-cond-group]").value) || 1,
      operandKey: tr.querySelector("select[data-avc-cond-operand]").value,
      operatorCode: tr.querySelector("select[data-avc-cond-op]").value,
      compareValue: tr.querySelector("input[data-avc-cond-value]").value.trim() || null
    }));
  }

  async function ruleAction(action) {
    const r = state.rule.rule;
    if (action === "SAVE") { await saveRule(); return; }
    if (action === "PREVIEW") { await previewRule(); return; }
    let reason = null;
    if (action === "RETIRE" || action === "NEW_VERSION") {
      reason = await window.gracUi.promptRequired(action === "RETIRE" ? "Why is this rule retired? Its open findings are resolved." : "Why is a new version needed?",
        { title: action === "RETIRE" ? "Retire rule" : "New version", inputLabel: "Reason" });
      if (!reason) return;
    } else if (!await window.gracUi.confirm(action === "ACTIVATE"
        ? "Activate this rule? It becomes immutable, replaces the Active version of the rule and is evaluated for every asset now."
        : "Discard this Draft?")) return;
    const res = await api("POST", `/consistency/rules/${r.ruleId}/action`, {
      organizationId: state.organizationId, action, reason, expectedRecordVersion: r.recordVersion ?? null
    });
    if (!res.ok) { rulesMessage(res.error, "error"); if (res.status === 409) await openRule(r.ruleId); return; }
    await loadRules();
    if (action === "DISCARD") { document.getElementById("avcRuleEditor").hidden = true; state.rule = null; }
    else await openRule(res.data.id);
    const result = String(res.data.result || "");
    rulesMessage(result.endsWith("_NOT_EVALUATED")
      ? "Done, but the findings could not be refreshed now; the scheduler refreshes them."
      : { ACTIVATED: "Rule activated; findings refreshed.", RETIRED: "Rule retired; its findings were resolved.",
          CREATED: "New Draft version created.", DISCARDED: "Draft discarded." }[result] || "Done.", "success");
  }

  async function saveRule() {
    const r = state.rule.rule;
    const kind = val("avcRuleScopeKind");
    const res = await api("POST", "/consistency/rules", {
      organizationId: state.organizationId, ruleId: r.ruleId || null, ruleName: val("avcRuleName") || null,
      description: val("avcRuleDesc") || null, scopeKind: kind, scopeRefId: kind === "TENANT" ? null : (Number(val("avcRuleScopeRef")) || null),
      severity: val("avcRuleSeverity"), actionCode: val("avcRuleAction"), overrideAllowed: document.getElementById("avcRuleOverride").checked,
      maxOverrideDays: Number(val("avcRuleMaxDays")) || null, effectiveFrom: val("avcRuleFrom") || null, effectiveTo: val("avcRuleTo") || null,
      changeReason: val("avcRuleReason") || null, conditions: readConds(), expectedRecordVersion: r.recordVersion ?? null
    });
    if (!res.ok) { rulesMessage(res.error, "error"); if (res.status === 409 && r.ruleId) await openRule(r.ruleId); return; }
    await loadRules();
    await openRule(res.data.id);
    rulesMessage(res.data.result === "CREATED" ? "Rule saved as Draft version 1. Another person with approval rights activates it." : "Draft saved.", "success");
  }

  async function previewRule() {
    const r = state.rule.rule, body = document.getElementById("avcRulePreviewBody");
    body.innerHTML = `<tr><td colspan="4" class="pm-empty">Evaluating...</td></tr>`;
    const res = await api("GET", `/consistency/rules/${r.ruleId}/preview?organizationId=${state.organizationId}`);
    if (!res.ok) { body.innerHTML = `<tr><td colspan="4" class="pm-empty">${esc(res.error)}</td></tr>`; return; }
    const p = res.data.data || {}, s = p.summary || {};
    document.getElementById("avcRulePreviewNote").textContent = `${s.matched ?? 0} of ${s.inScope ?? 0} assets in scope match the saved conditions now (first 500 listed).`;
    const facts = j => { try { return (JSON.parse(j || "[]") || []).map(x => `${x.operand} = ${x.value}`).join("; "); } catch (_) { return ""; } };
    body.innerHTML = (p.assets || []).map(a => `
      <tr><td>${esc(a.assetName)} <span class="avc-note">#${esc(a.assetId)}</span></td><td>${esc(a.statusName || "")}</td>
          <td>${esc(facts(a.factsJson))}</td><td>${esc(a.findingStatus ? a.findingStatus.replace(/_/g, " ").toLowerCase() : "--")}</td></tr>`).join("")
      || `<tr><td colspan="4" class="pm-empty">No asset matches.</td></tr>`;
  }

  function rulesMessage(text, kind) {
    const el = document.getElementById("avcRulesMessage");
    el.textContent = text || ""; el.classList.toggle("success", kind === "success"); el.hidden = !text;
  }

  function recalcMessage(text, kind) {""")
print('ui-a patched')
