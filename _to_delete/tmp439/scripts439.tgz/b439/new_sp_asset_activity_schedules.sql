CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_schedules
    @organization_id BIGINT,
    @template_code   NVARCHAR(40)  = NULL,
    @status          NVARCHAR(16)  = NULL,
    @search          NVARCHAR(200) = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25,
    @actor           NVARCHAR(100) = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 54650, 'Organization not found.', 1;
    SET @template_code = NULLIF(LTRIM(RTRIM(@template_code)), N'');
    SET @status = NULLIF(UPPER(LTRIM(RTRIM(@status))), N'');
    SET @search = NULLIF(LTRIM(RTRIM(@search)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) < 1 THEN 25 WHEN @page_size > 200 THEN 200 ELSE @page_size END;
    DECLARE @done INT;
    EXEC grac_practice.sp_asset_activity_task_sync @organization_id = @organization_id, @actor = @actor, @completed = @done OUTPUT;
    EXEC grac_practice.sp_asset_activity_schedule_sync @organization_id = @organization_id;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    SELECT s.asset_id AS AssetId, a.asset_name AS AssetName, ty.asset_type_name AS AssetTypeName, s.template_code AS TemplateCode,
           t.template_name AS TemplateName, t.activity_kind AS ActivityKind, s.schedule_state AS ScheduleState,
           s.not_scheduled_reason AS NotScheduledReason, s.frequency_text AS FrequencyText, s.basis AS Basis,
           s.last_done_date AS LastDoneDate, s.next_due_date AS NextDueDate, DATEDIFF(DAY, @today, s.next_due_date) AS DaysToDue,
           s.due_source AS DueSource, s.status_code AS StatusCode, s.revised_due_date AS RevisedDueDate,   -- 439
           c.contract_number AS ContractNumber, v.version_no AS ContractVersionNo, s.coverage_end AS CoverageEnd,
           o.occurrence_id AS OpenOccurrenceId, o.occurrence_key AS OpenOccurrenceKey, o.task_id AS OpenTaskId,
           o.needs_reconciliation AS NeedsReconciliation,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_activity_schedule s
      JOIN grac_practice.asset_activity_template t ON t.template_code = s.template_code
      JOIN grac_practice.organization_dependency_asset a ON a.asset_id = s.asset_id
      LEFT JOIN grac_practice.dependency_asset_type_master ty ON ty.asset_type_id = a.asset_type_id
      LEFT JOIN grac_practice.asset_contract_version v ON v.version_id = s.contract_version_id
      LEFT JOIN grac_practice.asset_contract c ON c.contract_id = v.contract_id
      LEFT JOIN grac_practice.asset_activity_occurrence o ON o.asset_id = s.asset_id AND o.template_code = s.template_code AND o.status = N'OPEN'
     WHERE s.organization_id = @organization_id
       AND (@template_code IS NULL OR s.template_code = @template_code)
       AND ((@status IS NULL AND s.status_code <> N'NOT_APPLICABLE') OR @status = N'ALL' OR s.status_code = @status)
       AND (@search IS NULL OR a.asset_name LIKE N'%' + @search + N'%' OR ty.asset_type_name LIKE N'%' + @search + N'%')
     ORDER BY CASE s.status_code WHEN N'FAILED' THEN 0 WHEN N'OVERDUE' THEN 0 WHEN N'DUE_SOON' THEN 1 WHEN N'VALID' THEN 2   -- 439: FAILED
                                 WHEN N'WAIVED' THEN 3 WHEN N'COVERED' THEN 3 WHEN N'NOT_SCHEDULED' THEN 4 ELSE 5 END,
              s.next_due_date, a.asset_name, t.display_order
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO
