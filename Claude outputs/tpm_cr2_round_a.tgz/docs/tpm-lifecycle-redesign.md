# Third-Party Management -- lifecycle redesign (target design and phase plan)

Sources:

* "GRAC Third-Party Management Lifecycle Redesign -- Functional &
  Technical Change Document v1.4" (2026-11-07). Phase 1 was built from
  it (migration 521, section 15.1).
* **"Change Document -- GRAC Third-Party Management (TPM) Redesign"
  (CR 2, 2026-11-08).** CR 2 replaces the v1.4 target from the
  qualification stage onwards. Where the two differ, CR 2 wins. This
  document is the CR 2 design. "CR 2 x.y" below refers to a section of
  that change document.

Status: **for review.** Round A (sections 4-5 of CR 2) is built in
migration 522 (section 15.2). Rounds B and C are designs only until they
are approved.

Decisions taken with the product owner:

| # | Date | Question | Answer |
|---|---|---|---|
| Q1 | 2026-11-07 | What happens to the TPRM module already built (486-490, 507)? | **Restructure it.** Pieces that already fit (configuration layers, versioned templates, questionnaires, evidence linking, audit, the dashboard frame) are kept. |
| Q2 | 2026-11-07 | What was delivered in the first round? | The v1.4 design plus Phase 1 (521). |
| Q3 | 2026-11-07 | Is there TPRM data in UAT that must be kept? | No, test data only. Tables may be reshaped, with no data migration. |
| Q4 | 2026-11-07 | What happens to the vendor function under Settings -> Dependencies? | It stays untouched (CR 2 10-18 confirms it is out of scope). Section 17 is the data-disposition plan. |
| Q5 | 2026-11-08 | What does the CR 2 round deliver? | **This design, plus Round A**: lightweight registration with automatic activation, progressive vendor information, the engagement initial form and progressive exposure capture (CR 2 sections 4 and 5). Screening, the applicability decision, admission and the TP Risk Register follow in Rounds B and C. |
| Q6 | 2026-11-08 | Which menus does the module show? | **Only the three CR 2 menus**: Vendor Registry, Engagement Management, TP Risk Register (CR 2 section 3). The dashboard and Reviews & Monitoring stay reachable but leave the sidebar; Configuration moves to Settings. |
| Q7 | 2026-11-08 | Which approval does formal admission follow? | **The TPRM approval rules** (`tprm_approval_rule`, 486) with their delegations and segregation of duties (Round B). |

## Contents

1. Principles
2. Where the module stands against CR 2
3. Menu structure
4. Vendor Registry -- progressive vendor onboarding (Round A)
5. Engagement Management -- engagement scoping (Round A)
6. Initial Exposure Screening (Round B)
7. Client TPRM applicability decision and admission (Round B)
8. TP Risk Register -- vendor-level record (Round C)
9. End-to-end lifecycle and state models
10. Logical entities -> physical objects
11. Authorization and segregation of duties
12. API surface
13. Phase plan
14. Acceptance scenarios (CR 2 section 11)
15. As built (521, 522)
16. What happens to each current TPRM object
17. Legacy vendor (Settings -> Dependencies): data-disposition plan
18. Open points for review

---

## 1. Principles

CR 2 section 2, and how the design keeps each one:

| CR 2 principle | Where the design keeps it |
|---|---|
| Registration is lightweight and needs no TPRM approval | Eight fields; no approval step; the vendor is Active on save (section 4) |
| Activation does not imply TPRM applicability or admission | Vendor status and TP Risk Register membership are separate records; nothing in the vendor lifecycle reads or writes the register (sections 4, 8) |
| Information is captured progressively | Vendor: extra identity data on the Edit vendor page, never at registration. Engagement: the initial form, then Scope & Exposure with gating questions (section 5) |
| Each engagement is screened independently | One screening report series per engagement (section 6) |
| GRAC correlates proposed exposure with what it already holds | Discovery from the engagement's applications, processes and business functions; kept apart from the proposed exposure (section 6.3) |
| GRAC identifies potential cases, the client decides | The screening classification is informational; the decision is a separate record by a person with the permission (sections 6.5, 7) |
| The client explicitly decides; admission follows the configured workflow | Include / Exclude / Defer with rationale; Include starts the TPRM approval rules (section 7) |
| One active vendor-level register record per vendor; engagements link to it | Filtered unique index on the register; admission links, never duplicates (section 8) |
| History stays traceable | Versioned screening reports, decisions kept after revision, audit trail on every step (sections 6-8) |

Unchanged house rules: procedures own every rule (`grac_practice`
schema). The API binds parameters and shapes results. The Web tier checks
the session, the organization and the menu grant, then proxies. Every
change writes an audit row. Nothing in TPM reads or writes the legacy
vendor objects (CR 2 10-18).

## 2. Where the module stands against CR 2

| CR 2 capability | After 521 | Gap | Round |
|---|---|---|---|
| 4.1-4.2 lightweight registration, immediate activation | Full identity form; vendor starts as DRAFT and is activated by hand | Eight-field registration page; vendor Active on save; DRAFT state retired | **A** |
| 4.3 progressive vendor information | All fields on one form | Separate Edit vendor page holding the progressive fields; none mandatory | **A** |
| 4.2-1 duplicate detection before registration | Configurable attributes, reviewed matches (521) | Kept | -- |
| 5.1 initial engagement form | One large form; criticality mandatory | Eleven-field initial form, CR 2 mandatory set; service category defaulted from the vendor | **A** |
| 5.2-5.3 progressive exposure capture | Exposure fields on the same form, scope items added one by one | Scope & Exposure page: gating questions open only the dimensions that apply; one save | **A** |
| 6 Initial Exposure Screening | Discovery exists (manual, from applications) | Automatic, versioned screening report with classification and observations | B |
| 7 Client applicability decision, admission approval | None | Include / Exclude / Defer; admission through the TPRM approval rules | B |
| 8 TP Risk Register | None (risk is per engagement) | Vendor-level register record, linked engagements, consolidated profile, impact review, exit | C |
| 3 menus | Dashboard, Vendor Registry, Engagements, Reviews & Monitoring, Configuration | Vendor Registry, Engagement Management, TP Risk Register (C); Configuration under Settings | **A** (C adds the register) |

The v1.4 design moved inherent risk, due diligence and the decision from
the engagement to a consolidated record. **CR 2 8.3 keeps them on the
engagement**: each admitted engagement keeps its own inherent assessment,
due diligence, safeguards, residual risk and findings. The vendor-level
record consolidates (section 8). So the engagement risk workflow of
488 / 489 stays where it is, behind the applicability decision.

## 3. Menu structure

Root `nav-tprm` "Third-Party Management". Menu keys do not change, so
grants and drill links keep working.

| CR 2 menu | Key | Sidebar | Screen |
|---|---|---|---|
| 3.1 Vendor Registry | `tprm-third-parties` | Yes | Registry, Register vendor page, Edit vendor page, profile, engagements, status and duplicate history |
| 3.2 Engagement Management | `tprm-engagements` | Yes (renamed from "Engagements") | Register, New engagement page, Scope & Exposure page, workspace (screening and decision tabs in Round B) |
| 3.3 TP Risk Register | `tprm-risk-register` | Yes, **from Round C** (added with its screen) | Admitted vendors, consolidated profile, linked engagements, history |
| -- | `tprm-dashboard` | No (`show_in_sidebar = 0`) | Still on Home (management dashboard card) |
| -- | `tprm-reviews` | No (`show_in_sidebar = 0`) | Still opened from an engagement and from the dashboard |
| -- | `tprm-configuration` | Moves to **Settings** as "Third-Party Settings" (beside Risk Settings) | Lists, library, templates, rules, custom fields |

`show_in_sidebar = 0` (migration 390) removes a row from navigation only;
the screen, its grants and its links stay. Every screen keeps the
existing layout: compact page heading, organization picker, `pm-panel` +
`pm-toolbar`, `pm-table-wrap` grid with the `pm-grid` pager, and the
shared `_tprm-form-dialog` form engine for both dialogs and full pages.

## 4. Vendor Registry -- progressive vendor onboarding (Round A)

### 4.1 Registration (CR 2 4.1, 4.2)

The **Register vendor** page has exactly the CR 2 fields:

| Field | Mandatory | Stored in |
|---|---|---|
| Legal name | Yes | `tprm_third_party.legal_name` |
| Trading name | No | `trading_name` |
| Primary service category | Yes | `primary_service_category_code` |
| Relationship owner | Yes | `relationship_owner_employee_id` |
| Country | Yes | `country` |
| Primary contact name | Yes | `tprm_third_party_contact` (`is_primary = 1`) |
| Contact email | Yes | the primary contact's `email` |
| Contact phone | No | the primary contact's `phone` |

On **Register** (`sp_tprm_third_party_save`, re-issued by 522):

1. Duplicate detection runs on the configured attributes (521,
   `VENDOR_MATCH_ATTRIBUTE`). Matches are listed and nothing is saved
   until each has a "different vendor" rationale; a real duplicate is
   not registered.
2. With no unreviewed match, the vendor is registered **and activated in
   the same transaction**: status = the organization's ACTIVE value,
   `first_activated_dt` = now.
3. No approval workflow starts.
4. The vendor is offered at once for a new engagement.
5. Status history: one row "registered and activated" (none -> Active).
   Audit trail: two rows, `CREATE` and `ACTIVATE`.

Activation means "available for engagement management". It never means
assessed, approved or admitted (the page says so).

### 4.2 Progressive vendor information (CR 2 4.3)

The **Edit vendor** page (from the vendor's profile) holds the
registration fields plus everything else, none of it mandatory:
registration number, Tax ID, LEI, vendor type, reporting and other
service categories, full address, state / region, city, website, parent
company, year established, employee and revenue bands, certifications,
notes, all contacts (one row each: name, role, email, phone, primary)
and the organization's custom fields. The registration mandatory set
still applies on every save, so a vendor never loses it.

CR 2 4.3 says these fields "may become mandatory when required by a
configured due-diligence questionnaire, risk assessment or client
policy". The existing mechanism for client policy is the custom field
with `is_mandatory` (486). Questionnaire-driven requirements are part of
due diligence (unchanged, 489).

### 4.3 Vendor states

`TP_STATUS` meanings after 522: **ACTIVE, INACTIVE, SUSPENDED,
ARCHIVED** (DRAFT is retired; DRAFT vendors become ACTIVE).

```
  register ---> ACTIVE <---- reinstate ---- SUSPENDED
                 |   ^ \---- suspend ----------^   |
      inactivate |   | reactivate                  | inactivate
                 v   |                             v
               INACTIVE <--------------------------+
                 |   ^
         archive |   | restore
                 v   |
               ARCHIVED
```

| Action | From -> To | Gate (`fn_tprm_vendor_transitions`) | Permission |
|---|---|---|---|
| SUSPEND | ACTIVE -> SUSPENDED | Reason | Vendor Registry APPROVE |
| REINSTATE | SUSPENDED -> ACTIVE | Reason | APPROVE |
| INACTIVATE | ACTIVE / SUSPENDED -> INACTIVE | No open engagement | APPROVE |
| REACTIVATE | INACTIVE -> ACTIVE | Registration fields complete | APPROVE |
| ARCHIVE | INACTIVE -> ARCHIVED | No open engagement | APPROVE |
| RESTORE | ARCHIVED -> INACTIVE | -- | APPROVE |

Every transition keeps a mandatory reason and an optional evidence
reference (521). **Mark as duplicate** (521) is allowed from any
non-archived state when the vendor has no open engagement; the vendor is
archived with `duplicate_of_third_party_id`, nothing is merged. A new
engagement needs an **ACTIVE** vendor.

## 5. Engagement Management -- engagement scoping (Round A)

### 5.1 Initial engagement (CR 2 5.1)

The **New engagement** page:

| Field | Mandatory | Column |
|---|---|---|
| Vendor | Yes (Active vendors) | `third_party_id` |
| Engagement name | Yes | `engagement_title` |
| Service category | Yes -- defaults from the vendor's primary category, editable | `service_category_code` |
| Service description | Yes | `service_description` |
| Business purpose | Yes | `business_purpose` |
| Service recipient | Yes | `service_recipient` |
| Engagement type | Yes | `engagement_type_code` |
| Service model | Yes | `service_model_code` |
| Delivery location | Yes | `delivery_locations` |
| Proposed start date | Yes | `proposed_start_dt` |
| Proposed end date | No | `proposed_end_dt` |
| Relationship owner | Yes | `relationship_owner_employee_id` |

Service criticality is **no longer asked at creation** (521 required
it); it is part of Business continuity in Scope & Exposure. Editing the
engagement opens the same page with the administrative fields that are
not exposure: scope description, existing relationship, business owner,
due-diligence assessor, actual term, notes, custom fields.

After **Create**, the Scope & Exposure page opens.

### 5.2 Progressive exposure capture (CR 2 5.2, 5.3)

The **Scope & Exposure** page starts with gating questions. Each is
answered Yes / No / Not sure; the details of a dimension are asked only
after a Yes, so a routine supplier answers a few No's and saves.

| Gating question (column) | A Yes asks for (CR 2 5.2 dimension) |
|---|---|
| Will the vendor access or support our applications or systems? (`app_access_answer`) | **Applications and systems** (GRAC applications + others not in GRAC) and **Access privileges** |
| Will the vendor have physical access to our premises? (`premises_access_answer`) | **Access privileges** |
| Will the vendor access, process, store or transmit organization or customer data? (`data_processing_answer`) | **Data exposure**: data categories and processing details (`data_processing_details`) |
| Will the vendor use subcontractors or other third parties for this service? (`subcontracting_answer`) | **Fourth parties**: name, category, country |
| Does the service support an important business process or function? (`important_process_answer`) | **Business processes**: business functions, processes (GRAC + others) |
| Could a disruption of the service affect business operations? (`disruption_impact_answer`) | **Business continuity**: customer impact, substitutability, exit dependencies |
| Are service commitments (SLA, recovery objectives) part of the service? (`service_commitment_answer`) | **Service commitments**: SLA summary, RTO, RPO |
| Is there a contract for this engagement? (`contract_answer`) | **Contractual information**: Asset & Contract record, reference, value, currency, validity (start / end), renewal date, related documents |

Always shown: **Delivery locations** (sites / countries where the service
is delivered or data is processed, as LOCATION scope items) and **Service
criticality**.

Rules (`sp_tprm_engagement_exposure_save`, new in 522):

* **Only applicable fields are kept.** When a question is not Yes, the
  fields and proposed scope items of its dimension are cleared on save
  (the page warns before it). Not sure is recorded as such: it is the
  information gap that screening reports in Round B.
* The proposed scope items are saved **as one set** with the page
  (`@scope_json`): items no longer listed are removed, new ones added,
  unchanged ones keep their criticality and notes. An item whose GRAC
  record was deactivated, or whose list value was retired, stays offered
  (marked as no longer active) and is kept unless it is unticked. A
  location or fourth party is identified by name and country. Proposed items are no
  longer added one at a time (`sp_tprm_scope_item_save` now refuses
  PROPOSED); ACTUAL items (onboarding) work as before.
* **Data exposure** (`data_exposure_code`, read by the risk-model
  prefill and questionnaire applicability) is derived: the highest-rank
  data category when data is in scope, the lowest (rank 0, "No
  organization data") when it is not, empty when not known.
* Access privileges are one dimension opened by either access question
  (applications or premises); its access categories are kept while either
  is Yes.
* `exposure_saved_dt` / `_by` record the save. In Round B this save
  triggers the Initial Exposure Screening (CR 2 6.1).
* On an approved or live engagement a change of criticality, data
  exposure, customer impact or substitutability is a **material
  change** (logged, reassessment flagged), as since 488 / 521; the
  core save keeps the same rule for service model and delivery
  locations. Both share `sp_tprm_engagement_flag_material`.

## 6. Initial Exposure Screening (Round B -- design)

### 6.1 Trigger

Saving Scope & Exposure runs `sp_tprm_screening_run` in the same
request. It is intelligence generation: it never changes the engagement
stage, the vendor status or the register. A report can also be
regenerated on demand ("Refresh screening") and is regenerated
automatically when a deferred engagement's exposure is saved again
(CR 2 7.3).

### 6.2 Report and observations

`tprm_screening_report` (one row per run, `version_no` per engagement,
never updated): engagement overview, proposed exposure summary, discovery
summary, classification, counts, generated by / at, and the exposure
snapshot it read (`tprm_exposure_snapshot` PROPOSED + DISCOVERED of the
same run). `tprm_screening_observation` (rows of a report):

| Column | Content |
|---|---|
| `section` | CR 2 6.4 sections 4-10: BUSINESS_OPERATIONAL, DATA_TECHNOLOGY, REGULATORY_OUTSOURCING, FOURTH_PARTY, RELATED_RECORDS, INFORMATION_GAP, OBSERVATION |
| `dimension` | CR 2 6.2 input: CRITICALITY, OPERATIONAL_DEPENDENCY, DATA, SYSTEM_ACCESS, PRIVILEGED_ACCESS, REGULATORY, OUTSOURCING, LOCATION, FOURTH_PARTY, CONTINUITY, CONTRACT |
| `origin` | **PROPOSED** (declared by the business) or **DISCOVERED** (GRAC correlation) -- CR 2 6.3 keeps them apart |
| `significance` | HIGH / MEDIUM / LOW / INFO |
| `source_kind`, `source_id`, `source_label` | the scope item, engagement field or GRAC record behind it |
| `verification_status` | DECLARED / DISCOVERED_UNVALIDATED / VALIDATED |
| `evidence_reference` | supporting reference |
| `text` | the observation |

### 6.3 Discovery correlation (CR 2 6.3)

Extends `sp_tprm_engagement_discover` (521: from applications) with the
engagement's business functions and processes:

| GRAC module | Discovered |
|---|---|
| Practice Management | practice instances depending on the engagement's applications / processes / functions, their criticality and dependencies |
| Risk Management | enterprise risks of those practices (`risk_register`) |
| Gap Register | open gaps of those instances |
| Obligation Management | obligations of those instances and practices |
| Audit Assurance | open assurance findings on those instances |
| Asset Management | the applications and the contract (434) |
| Third-Party Management | the vendor's other engagements, their stages, risk bands, screening classifications and decisions; register membership |

Discovered records stay DISCOVERED_UNVALIDATED until a user validates
them (existing `tprm_engagement_link` validation). They are never added
to the proposed scope by themselves.

### 6.4 Classification (CR 2 6.5)

Rules, evaluated in order; the result and every rule that fired are kept
on the report:

1. **FURTHER_INFORMATION_REQUIRED** -- any gating question unanswered or
   Not sure; or an inconsistency: a Yes with nothing recorded under it
   (data with no category, application access with no application,
   subcontracting with no fourth party, a contract with no reference);
   a No contradicted by discovery (for example no application access,
   but discovery finds the vendor's applications in practice
   dependencies); a proposed end date before the start.
2. **POTENTIAL_TPRM_CASE** -- any indicator of significance HIGH:
   data category rank >= 3 (personal or above), privileged / system /
   hosting access, criticality rank >= 3, an important business process
   with disruption impact, customer impact or substitutability rank at
   the top of its list, a fourth party handling data, a discovered
   critical practice instance or regulatory obligation, an open high
   finding on a discovered instance.
3. **NO_SIGNIFICANT_INDICATORS** -- otherwise.

The thresholds are organization configuration (new list
`SCREENING_INDICATOR`, value = indicator, rank = threshold, hide =
switch off), with the baseline above. The classification is shown as
GRAC's view, never as a decision (CR 2 10-9).

## 7. Client TPRM applicability decision and admission (Round B -- design)

### 7.1 Decision (CR 2 7)

`tprm_applicability_decision`: engagement, the screening report it was
made on, decision **INCLUDE / EXCLUDE / DEFER**, rationale (mandatory),
decision-maker (employee), decision date, supporting evidence / references
(Evidence Center links or text), approval reference, status
(CURRENT / SUPERSEDED). A revised decision supersedes the previous row;
nothing is deleted (CR 2 10-16).

Engagement **applicability status** (new column, independent of the risk
stage): NOT_SCREENED -> SCREENED -> PENDING_DECISION ->
{ EXCLUDED | DEFERRED | ADMISSION_PENDING -> ADMITTED | ADMISSION_REJECTED }.

* **Exclude** (CR 2 7.2): rationale kept with the report; the engagement
  stays in Engagement Management; the vendor stays Active; no register
  record. The engagement's risk workflow (inherent, due diligence) is
  not offered.
* **Defer** (CR 2 7.3): pending; "Request information" creates a task
  for the relationship owner (Task Board); the next exposure save
  regenerates the screening; a revised decision can be recorded.
* **Include** (CR 2 7.1): starts the admission approval (7.2 below).

### 7.2 Admission approval (Q7)

Reuses the TPRM approval machinery of 489 / 486: `tprm_decision` with a
new decision kind ADMISSION, levels from `tprm_approval_rule`
(conditions extended with screening classification and service
category), delegations, and the existing SoD rule (the decision-maker
cannot approve; one person per level). On final approval
`sp_tprm_register_admit` creates or links the vendor-level register
record (section 8) and sets the engagement ADMITTED; the engagement then
enters the formal TPRM lifecycle (inherent risk, due diligence, decision,
onboarding -- unchanged). A rejected admission leaves the engagement
ADMISSION_REJECTED with the reason; a new decision can be recorded.

## 8. TP Risk Register -- vendor-level record (Round C -- design)

* `tprm_risk_register` -- one row per admission lifetime: organization,
  vendor, status OPEN / EXIT_IN_PROGRESS / CLOSED, admitted date,
  overall vendor risk status, vendor-level profile assessments (CR 2
  8.2: corporate profile, ownership and group, financial stability,
  governance, legal and regulatory standing, enterprise information
  security, business continuity capability, certifications and
  assurance), review dates. **Filtered unique index (organization,
  vendor) WHERE status <> CLOSED** -- one active record per vendor
  (CR 2 10-12).
* `tprm_register_engagement` -- the admitted engagements (CR 2 10-13):
  register record, engagement, admitted date, admission decision,
  status LINKED / ENDED.
* `tprm_register_impact_review` -- raised when a further engagement of
  an admitted vendor is admitted (CR 2 8.4): the new engagement's
  exposure against the record's current profile, outcome NO_CHANGE /
  PROFILE_UPDATED, rationale, reviewer. The new engagement still
  undergoes its own assessment.
* **Consolidated profile** (CR 2 8.3): never an average. Per dimension it
  shows the vendor-level assessment and the highest engagement exposure,
  with the engagement that set it; the overall vendor risk status is the
  highest of the vendor-level rating and the admitted engagements'
  residual bands, unless a configured method (risk model version) says
  otherwise.
* **Exit** (CR 2 8.5): ending one engagement ends its link only. When
  the last linked engagement is exited, the record moves to
  EXIT_IN_PROGRESS and follows the exit checks (`EXIT_CHECK`); closure
  sets CLOSED. Closed records stay readable.
* **Screen** `tprm-risk-register` (menu 3.3): admitted vendors only,
  search and filters, the vendor profile with its engagements and their
  risk, due diligence, contracts, monitoring, admission / approval /
  acceptance history, and the exit status.

## 9. End-to-end lifecycle and state models

CR 2 section 9, with where each step lives:

| # | Step | Where | Round |
|---|---|---|---|
| 1-2 | Register vendor, activated | Vendor Registry -> Register vendor | A |
| 3-4 | Create engagement, initial information | Engagement Management -> New engagement | A |
| 5-6 | Progressive exposure, save | Scope & Exposure page | A |
| 7-9 | Screening report, discovery, classification | Engagement -> Screening tab | B |
| 10-11 | Client review and decision | Engagement -> Applicability tab | B |
| 12 | Admission approval | TPRM approval rules (decision kind ADMISSION) | B |
| 13 | Create or link the register record | TP Risk Register | C (B records the admission; C links the record) |
| 14-15 | Risk assessment, due diligence, monitoring, exit | Engagement tabs (existing) + register | existing / C |

Engagement **stage** (488) is unchanged in Rounds A-C: SCOPING ->
RISK_ASSESSED -> DUE_DILIGENCE -> PENDING_DECISION -> APPROVED ->
ONBOARDING -> ACTIVE -> SUSPENDED / EXITING -> EXITED, plus REJECTED and
CANCELLED. Round B places the applicability status in front of it: the
risk steps are offered only to an ADMITTED engagement (engagements
already past SCOPING before Round B are treated as admitted).

## 10. Logical entities -> physical objects

| CR 2 entity | Physical object | Round |
|---|---|---|
| Vendor | `tprm_third_party` (+ `_contact`, `_category`, `_status_history`), `tprm_vendor_match_review` | 521 / A |
| Engagement | `tprm_engagement` (+ gating answers and exposure columns of 522), `_scope`, `_link`, `_history`, `tprm_exposure_snapshot` | A |
| Screening report | `tprm_screening_report`, `tprm_screening_observation` | B |
| Applicability decision | `tprm_applicability_decision`; `tprm_engagement.applicability_status` | B |
| Admission approval | `tprm_decision` (kind ADMISSION) + `tprm_decision_approval`, `tprm_approval_rule`, delegations | B |
| TP Risk Register record | `tprm_risk_register`, `tprm_register_engagement`, `tprm_register_impact_review` | C |
| Engagement-level risk | `tprm_risk_assessment*`, `tprm_dd_*`, `tprm_safeguard_assessment`, `tprm_finding`, `tprm_decision` (kind RISK) -- unchanged, on the engagement | existing |

## 11. Authorization and segregation of duties

| Action | Screen grant | SoD in SQL |
|---|---|---|
| Register vendor | Vendor Registry ADD | -- |
| Edit vendor | Vendor Registry EDIT | -- |
| Suspend, reinstate, inactivate, reactivate, archive, restore, mark duplicate | Vendor Registry APPROVE | -- |
| Create engagement | Engagement Management ADD | -- |
| Edit engagement, Scope & Exposure | Engagement Management EDIT | -- |
| Refresh screening (B) | Engagement Management EDIT | -- |
| Record applicability decision (B) | Engagement Management APPROVE | -- |
| Admission approval (B) | the approval rule's role at each level | decision-maker <> approver; one person per level (existing D11) |
| Impact review, register exit (C) | TP Risk Register APPROVE | reviewer <> requester |
| Configuration | Third-Party Settings ADD / EDIT / APPROVE | -- |

## 12. API surface

Same pattern: Web `practice/api/tprm/...` proxies to API
`api/practice/tprm/...`; the API tier is generated from the procedure
signatures (`tools/tprm/gen_csharp.py`).

* Round A (522): `POST third-parties` (registration rules),
  `POST engagements` (core fields only), **`POST engagements/{id}/exposure`**
  (new), `GET engagements/{id}` (new columns). Details: section 15.2.
* Round B: `POST engagements/{id}/screening` (refresh),
  `GET engagements/{id}/screening[/{reportId}]`,
  `POST engagements/{id}/applicability`, admission through the existing
  `decisions/{id}/act`.
* Round C: `GET risk-register`, `GET risk-register/{id}`,
  `POST risk-register/{id}/impact-reviews/{reviewId}/decide`,
  `POST risk-register/{id}/exit`.

## 13. Phase plan

| Round | Migration | Content | Depends on |
|---|---|---|---|
| Phase 1 (v1.4) | **521** (built) | Vendor Registry restructure, duplicate reviews, vendor states, legacy decoupling, engagement exposure attributes | 486-490, 507 |
| **A** | **522** (built) | Lightweight registration with automatic activation, progressive vendor information, engagement initial form, progressive exposure, CR 2 menus | 521 |
| B | 523 | Screening (automatic, versioned, discovery correlation, classification), applicability decision, admission approval | A |
| C | 524 | TP Risk Register record, links, consolidated profile, impact review, exit, register screen and menu | B |
| later | 525+ | v1.4 items still wanted after review: TPM-owned contracts and SLAs, subcontractor records, exit plans, reporting rework (section 18) | C |

Each round has its own migration and rollback, its own API regeneration
and UI change, and a section in `docs/tprm.md`.

## 14. Acceptance scenarios (CR 2 section 11)

| Scenario | Demonstrated by |
|---|---|
| 1 Routine vendor | A: register (Active), engagement with every gating question No. B: report NO_SIGNIFICANT_INDICATORS, client Excludes. Vendor stays Active, no register record |
| 2 Potential TPRM case | A: data Yes (personal / customer data), application access Yes. B: POTENTIAL_TPRM_CASE, Include, admission approved. C: vendor in the register |
| 3 Multiple engagements | A: several engagements per vendor. B: a report series and decision per engagement. C: all admitted ones linked to one record |
| 4 New material engagement | B: new engagement screened, included, approved. C: linked to the existing record, impact review raised |
| 5 Insufficient information | A: Not sure answers / a Yes without details. B: FURTHER_INFORMATION_REQUIRED with the gaps listed; no decision is made by GRAC |
| 6 Excluded engagement of a registered vendor | B: Exclude. C: the record and its other engagements unaffected |

## 15. As built

### 15.1 Phase 1 -- migration 521

Unchanged from the first round; see `docs/tprm.md` section 521. Summary:

| Change | Detail |
|---|---|
| Vendor states | `TP_STATUS` meanings DRAFT, ACTIVE, INACTIVE, SUSPENDED, ARCHIVED; controlled transitions (`fn_tprm_vendor_transitions`); mandatory reason, evidence reference |
| Duplicate detection | `VENDOR_MATCH_ATTRIBUTE`; `tprm_vendor_match_review`; registration saves nothing until each match is reviewed; mark duplicate archives (no merge) |
| Legacy decoupling | `vendor_id`, vendor discovery / import, VENDOR link kind and VENDOR custom-field reference removed; discovery from applications |
| Engagement attributes | service recipient, substitutability, customer impact, exit dependencies |
| Navigation | "Third-Party Management", Vendor Registry, Engagements, Reviews & Monitoring, Configuration |

### 15.2 Round A -- migration 522 `522_tpm_cr2_registration_exposure.sql`

| Change | Detail |
|---|---|
| DRAFT retired | DRAFT vendors -> ACTIVE (`first_activated_dt` set, history row); baseline DRAFT value deleted; organization values of meaning DRAFT retired; `TP_STATUS` allowed meanings ACTIVE, INACTIVE, SUSPENDED, ARCHIVED |
| Transitions | `fn_tprm_vendor_transitions` without DRAFT; REACTIVATE needs the registration fields; RESTORE -> INACTIVE |
| Registration | `sp_tprm_third_party_save`: relationship owner, country and a primary contact with an e-mail address are mandatory (58050-58053); a new vendor is ACTIVE at once; audit CREATE + ACTIVATE |
| Mark duplicate | `sp_tprm_vendor_match_review_save`: from any non-archived state with no open engagement (521's DRAFT / INACTIVE gate 58027 removed) |
| Engagement core | `sp_tprm_engagement_save` re-issued with the CR 2 5.1 fields and the administrative fields; CR 2 mandatory set (58060); vendor must be ACTIVE (58061); criticality no longer required |
| Exposure | 8 gating-answer columns, `data_processing_details`, `contract_start_dt`, `contract_end_dt`, `contract_documents`, `exposure_saved_dt`, `exposure_saved_by`; new `sp_tprm_engagement_exposure_save`; shared `sp_tprm_engagement_flag_material`; answers backfilled from existing data |
| Scope items | `sp_tprm_scope_item_save` / `_remove` refuse PROPOSED items (58062) -- the exposure page owns them |
| Engagement read | `sp_tprm_engagement_get` returns the new columns |
| Samples | `sp_tprm_sample_load` registers samples as ACTIVE (relationship owner = the person loading them; a primary contact is added on first edit) and answers their gating questions |
| Existing data | `sp_tprm_engagement_answers_derive`: gating answers from what each engagement records, the data category behind a data exposure added as a scope item, the data exposure aligned to the highest category (so the first save reports no false material change); Scope & Exposure counts as saved where a criticality exists |
| Navigation | `tprm-engagements` "Engagement Management"; `tprm-dashboard`, `tprm-reviews` hidden from the sidebar; `tprm-configuration` "Third-Party Settings" under Settings (module type Organization) |
| Guards | 521 refuses to run after 522 |

Error numbers: 58050-58099.

## 16. What happens to each current TPRM object

| Object | Fate | Round |
|---|---|---|
| Configuration (486), baseline seed (487) | Kept; 487 regenerated as lists change | each |
| `tprm_third_party` + contact / category / history / match review | Kept as the Vendor Registry; DRAFT retired | A |
| `tprm_engagement` | Kept; gating answers and exposure columns added (A); applicability status (B) | A, B |
| `tprm_engagement_scope` | PROPOSED items owned by Scope & Exposure; ACTUAL unchanged | A |
| `sp_tprm_engagement_discover`, `tprm_engagement_link` | Extended for screening correlation | B |
| `tprm_risk_assessment*`, `tprm_dd_*`, `tprm_safeguard_assessment`, `tprm_finding` | **Stay on the engagement** (CR 2 8.3); offered only after admission | B |
| `tprm_decision*`, `tprm_approval_rule` | Reused for the admission approval (new decision kind) | B |
| `sp_tprm_third_party_sync_status` | No-op (521); removed when its 488 / 489 callers are next re-issued | later |
| `tprm_review`, monitoring sweep | Kept; register-level reviews added | C |
| `tprm_onboarding_item` (EXIT) | Feeds the register exit | C |
| `sp_dashboard_tprm` (507) | Kept (Home card); reworked to the CR 2 views later | later |

## 17. Legacy vendor (Settings -> Dependencies): data-disposition plan

Out of scope for CR 2 (CR 2 10-18). TPM reads and writes none of these
objects after 521.

| Area | Objects that hold or read legacy vendors | Records to decide on |
|---|---|---|
| Dependencies (core) | `organization_dependency_vendor` (002), `organization_dependency_application.vendor_id`, `practice_dependency_resolution` (dependency type Vendor), dependency category sync (238, 497), Settings -> Dependencies Vendor tab | vendor rows, application ownership, resolutions on practice instances |
| Risk Centre | `risk_register.linked_vendor_id` (205 / 378), risk dependency map (265) | risks linked to vendors |
| Assurance | `org_assurance_execution_entity` dimension VENDOR (074) | audit scope entities and their observations |
| Asset & Contract | `asset_contract.vendor_id` (434), coverage (435), renewals (436), relationships (440), business services (441), reports (452) | contracts and their links |
| Users / ownership | ownership management (345), user scope reads (341, 366, 467) | owner assignments |
| Dashboards / seeds | governance dashboard (503), master seeds (023, 272) | none (derived) |

Disposition options, per area, to be decided separately: (1) retain
read-only; (2) map each legacy vendor to a TPM vendor and re-point the
consumers; (3) export and archive. Recommended: (1) now; (2) for Risk
Centre and Assurance after Round C. Each step needs its own approval and
rollback.

## 18. Open points for review

1. **Screening thresholds** (section 6.4) -- confirm the baseline
   indicators and that FURTHER_INFORMATION_REQUIRED wins over
   POTENTIAL_TPRM_CASE when both apply.
2. **Engagements already in assessment** before Round B -- confirm they
   are treated as admitted (section 9) rather than screened again.
3. **Admission approval conditions** -- which `tprm_approval_rule`
   conditions apply to admission (classification, service category,
   criticality).
4. **Consolidated vendor risk status** (section 8) -- confirm "highest of
   vendor-level and engagement residual" as the baseline method.
5. **Contracts** -- v1.4 proposed TPM-owned contracts; CR 2 asks only for
   contract information on the engagement (built in Round A). Confirm
   whether TPM-owned contracts are still wanted.
6. **Legacy vendor** -- choose the disposition option per area
   (section 17).
