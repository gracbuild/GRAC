
-- =====================================================================
-- 5. Effective settings, catalogue, run, export log, history, settings
-- =====================================================================
-- Per report for an organization: enabled, classification (the
-- organization may raise it, never lower it) and export policy (default:
-- APPROVER for RESTRICTED, else ALLOWED).
CREATE OR ALTER FUNCTION grac_practice.fn_asset_report_effective (@organization_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT d.report_code AS ReportCode, CAST(ISNULL(os.is_enabled, 1) AS BIT) AS IsEnabled,
           ISNULL(os.classification, d.default_classification) AS Classification,
           ISNULL(os.export_policy, CASE WHEN ISNULL(os.classification, d.default_classification) = N'RESTRICTED'
                                         THEN N'APPROVER' ELSE N'ALLOWED' END) AS ExportPolicy,
           os.classification AS ClassificationOverride, os.export_policy AS ExportPolicyOverride
      FROM grac_practice.asset_report_definition d
      LEFT JOIN grac_practice.asset_report_org_setting os ON os.organization_id = @organization_id AND os.report_code = d.report_code;
GO

-- 1. reports the caller may view (the screen of each report is in
--    @allowed_areas, a comma list the Web tier builds from the session)
-- 2. asset lifecycle statuses (status filter of the asset reports)
-- 3. asset types in use in the organization (asset type filter)
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_catalogue
    @organization_id BIGINT,
    @allowed_areas   NVARCHAR(2000) = NULL,
    @can_approve     BIT            = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53100, 'Organization not found.', 1;
    DECLARE @areas NVARCHAR(2004) = N',' + REPLACE(ISNULL(@allowed_areas, N''), N' ', N'') + N',';

    SELECT d.report_code AS ReportCode, d.family_code AS FamilyCode, d.family_name AS FamilyName, d.report_name AS ReportName,
           d.description AS Description, d.version_no AS VersionNo, d.is_available AS IsAvailable,
           d.unavailable_reason AS UnavailableReason, e.IsEnabled, d.default_classification AS DefaultClassification,
           e.Classification, e.ExportPolicy, e.ClassificationOverride, e.ExportPolicyOverride,
           CAST(CASE WHEN d.is_available = 1 AND e.IsEnabled = 1
                      AND (e.ExportPolicy = N'ALLOWED' OR (e.ExportPolicy = N'APPROVER' AND ISNULL(@can_approve, 0) = 1))
                     THEN 1 ELSE 0 END AS BIT) AS CanExport,
           d.view_area AS ViewArea, d.filter_keys AS FilterKeys, d.status_label AS StatusLabel, d.status_options AS StatusOptions,
           d.date_label AS DateLabel, d.default_days AS DefaultDays, d.brd_reference AS BrdReference, d.display_order AS DisplayOrder
      FROM grac_practice.asset_report_definition d
      JOIN grac_practice.fn_asset_report_effective(@organization_id) e ON e.ReportCode = d.report_code
     WHERE d.is_active = 1 AND CHARINDEX(N',' + d.view_area + N',', @areas) > 0
     ORDER BY d.display_order;

    SELECT s.status_code AS Code, s.status_name AS Name
      FROM grac_practice.entity_status_master s
     WHERE s.entity_type = N'Asset'
     ORDER BY s.display_order;

    SELECT t.asset_type_id AS AssetTypeId, t.asset_type_name AS AssetTypeName
      FROM grac_practice.dependency_asset_type_master t
     WHERE EXISTS (SELECT 1 FROM grac_practice.organization_dependency_asset a
                    WHERE a.organization_id = @organization_id AND a.asset_type_id = t.asset_type_id)
     ORDER BY t.asset_type_name;
END
GO

-- Runs one report (screen grid or export). Checks: report known and
-- available, its screen in @allowed_areas, enabled for the organization,
-- for an export the policy (APPROVER needs @can_approve), filters valid.
-- Filters the report does not take are ignored. Export: page 1 of up to
-- 50001 rows (the API refuses more than 50000 -- 53107).
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_run
    @organization_id BIGINT,
    @report_code     NVARCHAR(40),
    @allowed_areas   NVARCHAR(2000) = NULL,
    @can_approve     BIT            = 0,
    @for_export      BIT            = 0,
    @search          NVARCHAR(200)  = NULL,
    @status          NVARCHAR(60)   = NULL,
    @asset_type_id   INT            = NULL,
    @date_from       DATE           = NULL,
    @date_to         DATE           = NULL,
    @days            INT            = NULL,
    @page_number     INT            = 1,
    @page_size       INT            = 25
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53100, 'Organization not found.', 1;
    SET @report_code = UPPER(NULLIF(LTRIM(RTRIM(@report_code)), N''));
    DECLARE @areas NVARCHAR(2004) = N',' + REPLACE(ISNULL(@allowed_areas, N''), N' ', N'') + N',';
    DECLARE @proc NVARCHAR(128), @area NVARCHAR(100), @available BIT, @keys NVARCHAR(204), @options NVARCHAR(1000),
            @default_days INT, @enabled BIT, @policy NVARCHAR(10);
    SELECT @proc = d.proc_name, @area = d.view_area, @available = d.is_available, @keys = N',' + d.filter_keys + N',',
           @options = d.status_options, @default_days = d.default_days, @enabled = e.IsEnabled, @policy = e.ExportPolicy
      FROM grac_practice.asset_report_definition d
      JOIN grac_practice.fn_asset_report_effective(@organization_id) e ON e.ReportCode = d.report_code
     WHERE d.report_code = @report_code AND d.is_active = 1;
    IF @area IS NULL
        THROW 53101, 'Unknown report.', 1;
    IF CHARINDEX(N',' + @area + N',', @areas) = 0
        THROW 53103, 'You do not have permission to view the screen this report is based on.', 1;
    IF @available = 0
        THROW 53102, 'This report is not available yet; see the catalogue for where the information is today.', 1;
    IF @enabled = 0
        THROW 53104, 'This report is disabled for the organization.', 1;
    IF ISNULL(@for_export, 0) = 1
       AND NOT (@policy = N'ALLOWED' OR (@policy = N'APPROVER' AND ISNULL(@can_approve, 0) = 1))
        THROW 53105, 'Export of this report is not allowed by the organization policy, or needs Asset Reports APPROVE.', 1;

    -- Filters the report does not take are ignored.
    SET @search = CASE WHEN CHARINDEX(N',SEARCH,', @keys) > 0 THEN NULLIF(LTRIM(RTRIM(@search)), N'') END;
    SET @status = CASE WHEN CHARINDEX(N',STATUS,', @keys) > 0 THEN NULLIF(UPPER(LTRIM(RTRIM(@status))), N'') END;
    SET @asset_type_id = CASE WHEN CHARINDEX(N',ASSET_TYPE,', @keys) > 0 THEN @asset_type_id END;
    IF CHARINDEX(N',DATE_RANGE,', @keys) = 0 SELECT @date_from = NULL, @date_to = NULL;
    SET @days = CASE WHEN CHARINDEX(N',DAYS,', @keys) > 0 THEN ISNULL(@days, @default_days) END;

    IF @status IS NOT NULL
       AND NOT ((@options = N'@ASSET_STATUS'
                 AND EXISTS (SELECT 1 FROM grac_practice.entity_status_master WHERE entity_type = N'Asset' AND status_code = @status))
                OR (@options <> N'@ASSET_STATUS' AND CHARINDEX(N'|' + @status + N'=', N'|' + @options) > 0))
        THROW 53106, 'Unknown status for this report.', 1;
    IF @date_from IS NOT NULL AND @date_to IS NOT NULL AND @date_from > @date_to
        THROW 53106, 'The from date is after the to date.', 1;
    IF CHARINDEX(N',DAYS,', @keys) > 0 AND (@days IS NULL OR @days NOT BETWEEN 1 AND 3650)
        THROW 53106, 'Days must be between 1 and 3650.', 1;

    IF ISNULL(@for_export, 0) = 1
    BEGIN
        SELECT @page_number = 1, @page_size = 50001;
    END
    ELSE
    BEGIN
        SELECT @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END,
               @page_size = CASE WHEN ISNULL(@page_size, 25) NOT BETWEEN 1 AND 200 THEN 25 ELSE @page_size END;
    END

    IF @proc IS NULL OR @proc NOT LIKE N'sp[_]asset[_]report[_]%' OR OBJECT_ID(N'grac_practice.' + QUOTENAME(@proc), 'P') IS NULL
        THROW 53110, 'The report procedure is missing; re-run migration 452.', 1;
    DECLARE @module NVARCHAR(300) = N'grac_practice.' + QUOTENAME(@proc);
    EXEC @module @report_code = @report_code, @organization_id = @organization_id, @search = @search, @status = @status,
         @asset_type_id = @asset_type_id, @date_from = @date_from, @date_to = @date_to, @days = @days,
         @page_number = @page_number, @page_size = @page_size;
END
GO

-- Export record (13.4.1): report and version, organization, filters,
-- columns, row count, classification, user, employee and time. Written
-- by the API after the rows were read and before they are returned.
-- Returns what the file watermark shows.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_export_log
    @organization_id   BIGINT,
    @report_code       NVARCHAR(40),
    @filters_json      NVARCHAR(MAX) = NULL,
    @columns_json      NVARCHAR(MAX) = NULL,
    @row_count         INT,
    @actor             NVARCHAR(100) = N'system',
    @actor_employee_id BIGINT        = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53100, 'Organization not found.', 1;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.asset_report_definition WHERE report_code = @report_code AND is_active = 1)
        THROW 53101, 'Unknown report.', 1;
    IF (@filters_json IS NOT NULL AND ISJSON(@filters_json) = 0) OR (@columns_json IS NOT NULL AND ISJSON(@columns_json) = 0)
       OR @row_count IS NULL OR @row_count < 0
        THROW 53106, 'Export filters, columns or row count invalid.', 1;
    DECLARE @id TABLE (export_id BIGINT NOT NULL);
    INSERT grac_practice.asset_report_export (organization_id, report_code, report_version, report_name, classification,
                                              filters_json, columns_json, row_count, exported_by, exported_employee_id)
    OUTPUT inserted.export_id INTO @id (export_id)
    SELECT @organization_id, d.report_code, d.version_no, d.report_name, e.Classification,
           @filters_json, @columns_json, @row_count, @actor, @actor_employee_id
      FROM grac_practice.asset_report_definition d
      JOIN grac_practice.fn_asset_report_effective(@organization_id) e ON e.ReportCode = d.report_code
     WHERE d.report_code = @report_code;

    SELECT x.export_id AS ExportId, x.report_code AS ReportCode, x.report_name AS ReportName, x.report_version AS ReportVersion,
           x.classification AS Classification, o.organization_name AS OrganizationName, x.row_count AS [RowCount],
           COALESCE(emp.employee_name, x.exported_by) AS ExportedBy, x.exported_dt AS ExportedDt, x.filters_json AS FiltersJson
      FROM grac_practice.asset_report_export x
      JOIN @id i ON i.export_id = x.export_id
      JOIN grac_practice.organization o ON o.organization_id = x.organization_id
      LEFT JOIN grac_practice.organization_employee emp ON emp.employee_id = x.exported_employee_id;
END
GO

-- Export history of the reports the caller may view.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_exports
    @organization_id BIGINT,
    @allowed_areas   NVARCHAR(2000) = NULL,
    @report_code     NVARCHAR(40)   = NULL,
    @page_number     INT            = 1,
    @page_size       INT            = 25
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53100, 'Organization not found.', 1;
    DECLARE @areas NVARCHAR(2004) = N',' + REPLACE(ISNULL(@allowed_areas, N''), N' ', N'') + N',';
    SET @report_code = NULLIF(LTRIM(RTRIM(@report_code)), N'');
    SET @page_number = CASE WHEN ISNULL(@page_number, 1) < 1 THEN 1 ELSE @page_number END;
    SET @page_size = CASE WHEN ISNULL(@page_size, 25) NOT BETWEEN 1 AND 200 THEN 25 ELSE @page_size END;

    SELECT x.export_id AS ExportId, x.report_code AS ReportCode, x.report_name AS ReportName, x.report_version AS ReportVersion,
           d.family_name AS FamilyName, x.classification AS Classification, x.file_format AS FileFormat, x.row_count AS [RowCount],
           x.filters_json AS FiltersJson, x.columns_json AS ColumnsJson,
           COALESCE(emp.employee_name, x.exported_by) AS ExportedBy, x.exported_dt AS ExportedDt,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.asset_report_export x
      JOIN grac_practice.asset_report_definition d ON d.report_code = x.report_code
      LEFT JOIN grac_practice.organization_employee emp ON emp.employee_id = x.exported_employee_id
     WHERE x.organization_id = @organization_id
       AND CHARINDEX(N',' + d.view_area + N',', @areas) > 0
       AND (@report_code IS NULL OR x.report_code = @report_code)
     ORDER BY x.exported_dt DESC, x.export_id DESC
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

-- Organization setting of one report: enabled, classification (not below
-- the default; NULL = default), export policy (NULL = default). Audited.
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_org_setting_save
    @organization_id BIGINT,
    @report_code     NVARCHAR(40),
    @allowed_areas   NVARCHAR(2000) = NULL,
    @is_enabled      BIT            = 1,
    @classification  NVARCHAR(20)   = NULL,
    @export_policy   NVARCHAR(10)   = NULL,
    @actor           NVARCHAR(100)  = N'system'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @actor = ISNULL(NULLIF(@actor, N''), N'system');
    SET @report_code = UPPER(NULLIF(LTRIM(RTRIM(@report_code)), N''));
    SET @classification = UPPER(NULLIF(LTRIM(RTRIM(@classification)), N''));
    SET @export_policy = UPPER(NULLIF(LTRIM(RTRIM(@export_policy)), N''));
    IF NOT EXISTS (SELECT 1 FROM grac_practice.organization WHERE organization_id = @organization_id)
        THROW 53100, 'Organization not found.', 1;
    DECLARE @area NVARCHAR(100), @default NVARCHAR(20);
    SELECT @area = view_area, @default = default_classification
      FROM grac_practice.asset_report_definition WHERE report_code = @report_code AND is_active = 1;
    IF @area IS NULL
        THROW 53101, 'Unknown report.', 1;
    IF CHARINDEX(N',' + @area + N',', N',' + REPLACE(ISNULL(@allowed_areas, N''), N' ', N'') + N',') = 0
        THROW 53103, 'You do not have permission to view the screen this report is based on.', 1;
    IF @classification IS NOT NULL
       AND (@classification NOT IN (N'PUBLIC', N'INTERNAL', N'CONFIDENTIAL', N'RESTRICTED')
            OR CASE @classification WHEN N'PUBLIC' THEN 1 WHEN N'INTERNAL' THEN 2 WHEN N'CONFIDENTIAL' THEN 3 ELSE 4 END
             < CASE @default WHEN N'PUBLIC' THEN 1 WHEN N'INTERNAL' THEN 2 WHEN N'CONFIDENTIAL' THEN 3 ELSE 4 END)
        THROW 53108, 'The classification is unknown or lower than the default classification of the report.', 1;
    IF @export_policy IS NOT NULL AND @export_policy NOT IN (N'ALLOWED', N'APPROVER', N'DISABLED')
        THROW 53109, 'Export policy must be ALLOWED, APPROVER or DISABLED.', 1;
    IF @classification = @default SET @classification = NULL;

    DECLARE @before NVARCHAR(MAX) = (SELECT os.report_code AS reportCode, os.is_enabled AS isEnabled, os.classification,
                                            os.export_policy AS exportPolicy
                                       FROM grac_practice.asset_report_org_setting os
                                      WHERE os.organization_id = @organization_id AND os.report_code = @report_code
                                        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
    BEGIN TRAN;
    UPDATE grac_practice.asset_report_org_setting
       SET is_enabled = ISNULL(@is_enabled, 1), classification = @classification, export_policy = @export_policy,
           updated_by = @actor, updated_dt = SYSUTCDATETIME()
     WHERE organization_id = @organization_id AND report_code = @report_code;
    IF @@ROWCOUNT = 0
        INSERT grac_practice.asset_report_org_setting (organization_id, report_code, is_enabled, classification, export_policy, entered_by)
        VALUES (@organization_id, @report_code, ISNULL(@is_enabled, 1), @classification, @export_policy, @actor);
    INSERT grac_practice.practice_audit_trace (entity_type, entity_id, action_type, before_json, after_json, status, entered_by)
    VALUES (N'asset-report-org-setting', @organization_id, N'SAVE', @before,
            (SELECT @report_code AS reportCode, ISNULL(@is_enabled, 1) AS isEnabled, @classification AS classification,
                    @export_policy AS exportPolicy FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
            N'Active', @actor);
    COMMIT;
    SELECT @organization_id AS OrganizationId, @report_code AS ReportCode, N'SAVED' AS Result;
END
GO
PRINT '452: catalogue, run, export log, history and settings procedures created.';
GO
