CREATE OR ALTER PROCEDURE grac_practice.sp_asset_activity_schedule_sync
    @organization_id BIGINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    CREATE TABLE #cov (asset_id BIGINT NOT NULL, coverage_type NVARCHAR(160) NOT NULL, version_id BIGINT NOT NULL, eff_end DATE NULL);
    INSERT #cov (asset_id, coverage_type, version_id, eff_end)
    SELECT AssetId, CoverageType, VersionId, EffectiveEnd
      FROM grac_practice.fn_asset_coverage_line_view(@organization_id)
     WHERE LineStatus IN (N'COVERED', N'EXPIRING');

    CREATE TABLE #in (
        asset_id BIGINT NOT NULL, template_code NVARCHAR(40) NOT NULL, activity_kind NVARCHAR(12) NOT NULL,
        due_soon_days INT NOT NULL, coverage_types NVARCHAR(200) NULL,
        required_val NVARCHAR(400) NULL, frequency_text NVARCHAR(400) NULL, basis NVARCHAR(400) NULL,
        field_last DATE NULL, expiry DATE NULL, occ_due DATE NULL, occ_done DATE NULL, open_due DATE NULL,
        occ_status NVARCHAR(12) NULL, occ_outcome NVARCHAR(12) NULL, occ_review DATE NULL,       -- 439
        open_revised DATE NULL, retest_days INT NULL,                                             -- 439
        PRIMARY KEY (asset_id, template_code));
    INSERT #in (asset_id, template_code, activity_kind, due_soon_days, coverage_types, required_val, frequency_text, basis,
                field_last, expiry, occ_due, occ_done, open_due,
                occ_status, occ_outcome, occ_review, open_revised, retest_days)                -- 439
    SELECT a.asset_id, t.template_code, t.activity_kind, st.DueSoonDays, t.coverage_types,
           (SELECT v.value_text FROM grac_practice.asset_field_value v
              JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id AND f.field_key = t.required_field_key
             WHERE v.asset_id = a.asset_id),
           (SELECT v.value_text FROM grac_practice.asset_field_value v
              JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id AND f.field_key = t.frequency_field_key
             WHERE v.asset_id = a.asset_id),
           (SELECT v.value_text FROM grac_practice.asset_field_value v
              JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id AND f.field_key = t.basis_field_key
             WHERE v.asset_id = a.asset_id),
           (SELECT v.value_date FROM grac_practice.asset_field_value v
              JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id AND f.field_key = t.last_date_field_key
             WHERE v.asset_id = a.asset_id),
           (SELECT v.value_date FROM grac_practice.asset_field_value v
              JOIN grac_practice.asset_field_definition f ON f.field_definition_id = v.field_definition_id AND f.field_key = t.expiry_field_key
             WHERE v.asset_id = a.asset_id),
           lo.due_date, CAST(lo.completed_dt AS DATE),
           (SELECT o.due_date FROM grac_practice.asset_activity_occurrence o
             WHERE o.asset_id = a.asset_id AND o.template_code = t.template_code AND o.status = N'OPEN'),
           lo.status, lo.outcome, lo.review_date,                                                 -- 439
           (SELECT o.revised_due_date FROM grac_practice.asset_activity_occurrence o
             WHERE o.asset_id = a.asset_id AND o.template_code = t.template_code AND o.status = N'OPEN'),
           st.RetestDays
      FROM grac_practice.organization_dependency_asset a
      LEFT JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
     CROSS JOIN grac_practice.asset_activity_template t
      JOIN grac_practice.fn_asset_activity_settings(@organization_id) st ON st.TemplateCode = t.template_code AND st.IsActive = 1
     -- 439: the last finished occurrence is completed (with its approved
     -- result, if any) or waived (until its review date).
     OUTER APPLY (SELECT TOP 1 o.due_date, o.completed_dt, o.status, r.outcome, o.review_date
                    FROM grac_practice.asset_activity_occurrence o
                    LEFT JOIN grac_practice.asset_activity_result r ON r.occurrence_id = o.occurrence_id AND r.state = N'APPROVED'
                   WHERE o.asset_id = a.asset_id AND o.template_code = t.template_code AND o.status IN (N'COMPLETED', N'WAIVED')
                   ORDER BY o.due_date DESC, o.occurrence_id DESC) lo
     WHERE a.organization_id = @organization_id
       AND ISNULL(s.status_code, N'ACTIVE') NOT IN (N'DRAFT', N'REQUESTED', N'APPROVED', N'ORDERED', N'LOST', N'STOLEN',
                                                     N'DISPOSED', N'ARCHIVED');

    CREATE TABLE #out (
        asset_id BIGINT NOT NULL, template_code NVARCHAR(40) NOT NULL, schedule_state NVARCHAR(16) NOT NULL,
        not_scheduled_reason NVARCHAR(300) NULL, frequency_text NVARCHAR(100) NULL, interval_value INT NULL, interval_unit NVARCHAR(10) NULL,
        basis NVARCHAR(40) NULL, last_done_date DATE NULL, next_due_date DATE NULL, due_source NVARCHAR(30) NULL,
        status_code NVARCHAR(16) NOT NULL, contract_version_id BIGINT NULL, coverage_end DATE NULL,
        revised_due_date DATE NULL);                                                                -- 439
    INSERT #out (asset_id, template_code, schedule_state, not_scheduled_reason, frequency_text, interval_value, interval_unit, basis,
                 last_done_date, next_due_date, due_source, status_code, contract_version_id, coverage_end,
                 revised_due_date)                                                                  -- 439
    SELECT i.asset_id, i.template_code, z.state, z.reason, LEFT(i.frequency_text, 100), iv.IntervalValue, iv.IntervalUnit,
           LEFT(i.basis, 40), CASE WHEN z.state = N'SCHEDULED' THEN n.last_done END,
           CASE WHEN z.state = N'SCHEDULED' THEN n.next_due END,
           CASE WHEN z.state = N'SCHEDULED' THEN n.source END,
           CASE WHEN z.state = N'NOT_APPLICABLE' THEN N'NOT_APPLICABLE'
                WHEN z.state = N'NOT_SCHEDULED' THEN N'NOT_SCHEDULED'
                WHEN n.source = N'FAILED_RESULT' THEN N'FAILED'                                          -- 439
                WHEN i.activity_kind = N'RENEWAL' AND cv.version_id IS NOT NULL
                     AND ISNULL(cv.eff_end, CAST('9999-12-31' AS DATE)) >= n.next_due THEN N'COVERED'
                WHEN n.source = N'WAIVED_REVIEW' AND n.next_due > DATEADD(DAY, i.due_soon_days, @today) THEN N'WAIVED'   -- 439
                WHEN ISNULL(i.open_revised, n.next_due) < @today THEN N'OVERDUE'                         -- 439: revised due
                WHEN ISNULL(i.open_revised, n.next_due) <= DATEADD(DAY, i.due_soon_days, @today) THEN N'DUE_SOON'
                ELSE N'VALID' END,
           cv.version_id, cv.eff_end,
           CASE WHEN z.state = N'SCHEDULED' THEN i.open_revised END                                    -- 439
      FROM #in i
     OUTER APPLY grac_practice.fn_asset_activity_interval(i.frequency_text) iv
     CROSS APPLY (SELECT CASE WHEN UPPER(LTRIM(RTRIM(ISNULL(i.basis, N'')))) IN (N'APPROVED_COMPLETION_DATE', N'COMPLETION_DATE') THEN N'COMPLETION'
                              WHEN UPPER(LTRIM(RTRIM(ISNULL(i.basis, N'')))) IN (N'USAGE', N'RUN_HOURS', N'MANUFACTURER') THEN N'UNSUPPORTED'
                              ELSE N'SCHEDULED' END AS basis_class) b
     -- 439: a waiver lasts until its review date while nothing newer was
     -- recorded on the register; a failed result is re-tested after the
     -- re-test days (D72, D74).
     CROSS APPLY (SELECT CASE WHEN i.occ_status = N'WAIVED' AND i.occ_review IS NOT NULL
                               AND ((i.activity_kind = N'RENEWAL' AND (i.expiry IS NULL OR i.expiry <= i.occ_due))
                                    OR (i.activity_kind = N'EXECUTION' AND (i.field_last IS NULL OR i.field_last <= i.occ_due)))
                              THEN 1 ELSE 0 END AS waived,
                         CASE WHEN i.activity_kind = N'EXECUTION' AND i.occ_status = N'COMPLETED' AND i.occ_outcome = N'FAIL'
                               AND i.occ_done IS NOT NULL AND (i.field_last IS NULL OR i.occ_done >= i.field_last)
                              THEN 1 ELSE 0 END AS failed) w
     CROSS APPLY (SELECT
            CASE WHEN w.waived = 1 THEN i.occ_review                                                   -- 439
                 WHEN w.failed = 1 THEN DATEADD(DAY, ISNULL(i.retest_days, 0), i.occ_done)             -- 439
                 WHEN i.activity_kind = N'RENEWAL' THEN i.expiry
                 WHEN i.occ_done IS NOT NULL AND (i.field_last IS NULL OR i.occ_done >= i.field_last)
                     THEN grac_practice.fn_asset_activity_add(CASE WHEN b.basis_class = N'COMPLETION' THEN i.occ_done ELSE i.occ_due END,
                                                              iv.IntervalValue, iv.IntervalUnit)
                 WHEN i.field_last IS NOT NULL THEN grac_practice.fn_asset_activity_add(i.field_last, iv.IntervalValue, iv.IntervalUnit)
                 ELSE ISNULL(i.open_due, @today) END AS next_due,      -- no history: due now (D61), kept while it is open
            CASE WHEN i.activity_kind = N'RENEWAL' THEN NULL
                 WHEN i.occ_done IS NOT NULL AND (i.field_last IS NULL OR i.occ_done >= i.field_last) THEN i.occ_done
                 ELSE i.field_last END AS last_done,
            CASE WHEN w.waived = 1 THEN N'WAIVED_REVIEW'                                               -- 439
                 WHEN w.failed = 1 THEN N'FAILED_RESULT'                                               -- 439
                 WHEN i.activity_kind = N'RENEWAL' THEN N'EXPIRY_FIELD'
                 WHEN i.occ_done IS NOT NULL AND (i.field_last IS NULL OR i.occ_done >= i.field_last) THEN N'COMPLETED_OCCURRENCE'
                 WHEN i.field_last IS NOT NULL THEN N'LAST_DATE_FIELD'
                 ELSE N'NO_HISTORY' END AS source) n
     CROSS APPLY (SELECT
            CASE WHEN ISNULL(i.required_val, N'') <> N'Yes' THEN N'NOT_APPLICABLE'
                 WHEN w.waived = 1 THEN N'SCHEDULED'                                                   -- 439
                 WHEN i.activity_kind = N'RENEWAL' AND i.expiry IS NULL THEN N'NOT_SCHEDULED'
                 WHEN i.activity_kind = N'EXECUTION' AND iv.IntervalValue IS NULL THEN N'NOT_SCHEDULED'
                 WHEN i.activity_kind = N'EXECUTION' AND b.basis_class = N'UNSUPPORTED' THEN N'NOT_SCHEDULED'
                 ELSE N'SCHEDULED' END AS state,
            CASE WHEN ISNULL(i.required_val, N'') <> N'Yes' THEN NULL
                 WHEN w.waived = 1 THEN NULL                                                           -- 439
                 WHEN i.activity_kind = N'RENEWAL' AND i.expiry IS NULL THEN N'No expiry date is recorded on the asset.'
                 WHEN i.activity_kind = N'EXECUTION' AND iv.IntervalValue IS NULL
                     THEN N'The frequency is missing or not understood (for example "12 months").'
                 WHEN i.activity_kind = N'EXECUTION' AND b.basis_class = N'UNSUPPORTED'
                     THEN CONCAT(N'The ', LOWER(REPLACE(i.basis, N'_', N' ')), N' basis needs meter readings; it is not scheduled yet.') END AS reason) z
     OUTER APPLY (SELECT TOP 1 c.version_id, c.eff_end
                    FROM #cov c
                   WHERE c.asset_id = i.asset_id AND i.coverage_types IS NOT NULL
                     AND CHARINDEX(N',' + c.coverage_type + N',', N',' + i.coverage_types + N',') > 0
                   ORDER BY ISNULL(c.eff_end, CAST('9999-12-31' AS DATE)) DESC, c.version_id DESC) cv;

    BEGIN TRAN;
    DELETE grac_practice.asset_activity_schedule WHERE organization_id = @organization_id;
    INSERT grac_practice.asset_activity_schedule
        (organization_id, asset_id, template_code, schedule_state, not_scheduled_reason, frequency_text, interval_value, interval_unit,
         basis, last_done_date, next_due_date, due_source, status_code, contract_version_id, coverage_end,
         revised_due_date)                                                                                 -- 439
    SELECT @organization_id, asset_id, template_code, schedule_state, not_scheduled_reason, frequency_text, interval_value, interval_unit,
           basis, last_done_date, next_due_date, due_source, status_code, contract_version_id, coverage_end,
           revised_due_date
      FROM #out;
    COMMIT;
END
GO
