import sys, json
R = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/w453/new'
A = R + '/src/PracticeManagement.Api/'
def edit(path, old, new, count=1):
    s = open(path).read(); assert s.count(old) == count, (path, old[:80], s.count(old)); open(path, 'w').write(s.replace(old, new))

# ---------------------------------------------------------------- models
edit(A + 'Models/AssetConfigModels.cs', """/// <summary>Outcome of a report run or export: the data, or the refusal (53100-53119) of the procedures.</summary>
public sealed record AssetReportResult(bool Success, object? Data, int? ErrorNumber, string? Error);
""", """/// <summary>Outcome of a report run or export: the data, or the refusal (53100-53119) of the procedures.</summary>
public sealed record AssetReportResult(bool Success, object? Data, int? ErrorNumber, string? Error);

// ---------------------------------------------------------------------
// Report schedules, distribution and delivered files (migration 453)
// ---------------------------------------------------------------------
/// <summary>A distribution list entry: Kind EMPLOYEE (Id = employee) or ROLE (Id = organization role; every active holder
/// at delivery time).</summary>
public sealed record AssetReportScheduleRecipient(string? Kind, long? Id);

/// <summary>A report schedule. New when ScheduleId is null; the report is fixed afterwards. Frequency DAILY | WEEKLY
/// (DayOfWeek 1 Monday - 7 Sunday) | MONTHLY (DayOfMonth 1-28). DateWindowDays: date-range reports cover the last N days
/// up to the run date. RetentionDays: how long delivered files are kept (1-3650, default 90).</summary>
public sealed record AssetReportScheduleRequest(long OrganizationId, long? ScheduleId, string? ReportCode, string? ScheduleName,
    string? Search, string? Status, int? AssetTypeId, int? Days, int? DateWindowDays, string? Frequency, int? DayOfWeek,
    int? DayOfMonth, int? RetentionDays, bool? IsActive, IReadOnlyList<AssetReportScheduleRecipient>? Recipients,
    long? ExpectedRecordVersion);

/// <summary>Run one schedule now, or download one delivered file (organization of the request).</summary>
public sealed record AssetReportOrganizationRequest(long OrganizationId);

/// <summary>What a delivery pass did: deliveries started, files delivered, recipients failed and skipped.</summary>
public sealed record AssetReportDeliveryPassResult(int Deliveries, int Delivered, int Failed, int Skipped);
""")

# ---------------------------------------------------------------- service
S = A + 'Services/AssetConfigService.cs'
edit(S, """//   sp_asset_report_* (452 -- report catalogue, report runs, export log, organization report settings)
""", """//   sp_asset_report_* (452 -- report catalogue, report runs, export log, organization report settings;
//   453 -- schedules, distribution, delivered files, retention; the delivery pass run by TaskNotificationWorker)
""")
edit(S, """    Task<AssetLifecycleResult> SaveReportSettingAsync(AssetReportSettingRequest request, string? allowedAreas, string actor, CancellationToken ct);
}
""", """    Task<AssetLifecycleResult> SaveReportSettingAsync(AssetReportSettingRequest request, string? allowedAreas, string actor, CancellationToken ct);

    // 453 -- Report schedules, distribution and delivered files
    Task<object?> GetReportSchedulesAsync(long organizationId, string? allowedAreas, CancellationToken ct);
    Task<AssetLifecycleResult> SaveReportScheduleAsync(AssetReportScheduleRequest request, string? allowedAreas, string actor,
        long? actorEmployeeId, CancellationToken ct);
    Task<AssetReportResult> RunReportScheduleNowAsync(long organizationId, long scheduleId, string? allowedAreas, string actor, CancellationToken ct);
    /// <summary>The scheduled delivery pass (TaskNotificationWorker): every schedule due today, every organization
    /// (or one).</summary>
    Task<AssetReportDeliveryPassResult> RunReportDeliveriesAsync(long? organizationId, CancellationToken ct);
    Task<object?> ListReportDeliveriesAsync(long organizationId, string? allowedAreas, long? scheduleId, int pageNumber, int pageSize,
        CancellationToken ct);
    Task<AssetReportResult> ListReportDeliveryRecipientsAsync(long organizationId, long deliveryId, string? allowedAreas, CancellationToken ct);
    Task<object> ListMyReportDeliveriesAsync(long organizationId, long? employeeId, int pageNumber, int pageSize, CancellationToken ct);
    Task<AssetReportResult> DownloadReportDeliveryAsync(long organizationId, long deliveryRecipientId, long? employeeId, string? allowedAreas,
        bool canApprove, string actor, CancellationToken ct);
}
""")
# 453: an export is a POST, which carries no read scope (CallerViewScope.BeginForRequest); apply the caller own.
edit(S, """            var (columns, rows) = await ExecuteReportAsync(request, allowedAreas, canApprove, true, 1, ReportExportRowLimit + 1, ct);
            if (rows.Count > ReportExportRowLimit)
                return new AssetReportResult(false, null, 53107,
                    $"The export has more than {ReportExportRowLimit} rows. Narrow the filters and export again.");""",
"""            string[] columns;
            List<Dictionary<string, object?>> rows;
            try
            {
                // 453: an export is a POST, and only GET reads get the caller View Data Scope (415, CallerViewScope);
                // the export applies the caller own so it carries exactly the rows the grid shows.
                Infrastructure.CallerViewScope.BeginRead(actorEmployeeId);
                (columns, rows) = await ExecuteReportAsync(request, allowedAreas, canApprove, true, 1, ReportExportRowLimit + 1, ct);
            }
            finally { Infrastructure.CallerViewScope.Clear(); }
            if (rows.Count > ReportExportRowLimit)
                return new AssetReportResult(false, null, 53107,
                    $"The export has more than {ReportExportRowLimit} rows. Narrow the filters and export again.");""")

edit(S, """    /// <summary>Runs sp_asset_report_run and reads the one result set of the report: the column names (camelCase,""",
"""    // ----------------------------------------------------------------
    // 453 -- Report schedules, distribution and delivered files (13.4 / 13.4.1)
    // ----------------------------------------------------------------
    public async Task<object?> GetReportSchedulesAsync(long organizationId, string? allowedAreas, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_report_schedules");
            AddParam(command, "@organization_id", DbType.Int64,  organizationId);
            AddParam(command, "@allowed_areas",   DbType.String, Blank(allowedAreas), 2000);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var empty = new List<Dictionary<string, object?>>();
            var schedules  = await ReadRowsAsync(reader, ct);
            var recipients = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var employees  = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            var roles      = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : empty;
            return new { schedules, recipients, employees, roles };
        }
        catch (SqlException ex) when (ex.Number == 53120) { return null; }
    }

    public Task<AssetLifecycleResult> SaveReportScheduleAsync(AssetReportScheduleRequest request, string? allowedAreas, string actor,
        long? actorEmployeeId, CancellationToken ct) =>
        ResultRowWriteAsync("grac_practice.sp_asset_report_schedule_save", "scheduleId", command =>
        {
            var recipients = System.Text.Json.JsonSerializer.Serialize((request.Recipients ?? Array.Empty<AssetReportScheduleRecipient>())
                .Select(r => new { kind = r.Kind, id = r.Id }));
            AddParam(command, "@organization_id",         DbType.Int64,   request.OrganizationId);
            AddParam(command, "@schedule_id",             DbType.Int64,   request.ScheduleId);
            AddParam(command, "@report_code",             DbType.String,  Blank(request.ReportCode), 40);
            AddParam(command, "@schedule_name",           DbType.String,  Blank(request.ScheduleName), 160);
            AddParam(command, "@search",                  DbType.String,  Blank(request.Search), 200);
            AddParam(command, "@status",                  DbType.String,  Blank(request.Status), 60);
            AddParam(command, "@asset_type_id",           DbType.Int32,   request.AssetTypeId);
            AddParam(command, "@days",                    DbType.Int32,   request.Days);
            AddParam(command, "@date_window_days",        DbType.Int32,   request.DateWindowDays);
            AddParam(command, "@frequency",               DbType.String,  Blank(request.Frequency), 10);
            AddParam(command, "@day_of_week",             DbType.Byte,    request.DayOfWeek is { } dw && dw is >= 0 and <= 255 ? (byte?)dw : null);
            AddParam(command, "@day_of_month",            DbType.Byte,    request.DayOfMonth is { } dm && dm is >= 0 and <= 255 ? (byte?)dm : null);
            AddParam(command, "@retention_days",          DbType.Int32,   request.RetentionDays);
            AddParam(command, "@is_active",               DbType.Boolean, request.IsActive ?? true);
            AddParam(command, "@recipients_json",         DbType.String,  recipients, -1);
            AddParam(command, "@expected_record_version", DbType.Int64,   request.ExpectedRecordVersion);
            AddParam(command, "@allowed_areas",           DbType.String,  Blank(allowedAreas), 2000);
            AddParam(command, "@actor",                   DbType.String,  actor, 100);
            AddParam(command, "@actor_employee_id",       DbType.Int64,   actorEmployeeId);
        }, ct);

    public async Task<AssetReportResult> RunReportScheduleNowAsync(long organizationId, long scheduleId, string? allowedAreas, string actor,
        CancellationToken ct)
    {
        try
        {
            var pass = await DeliverReportsAsync(organizationId, scheduleId, allowedAreas, actor, ct);
            return new AssetReportResult(true, pass, null, null);
        }
        catch (SqlException ex) when (ex.Number is >= 53100 and <= 53139)
        {
            logger.LogWarning(ex, "AssetConfigService report schedule {Schedule} run refused ({Number})", scheduleId, ex.Number);
            return new AssetReportResult(false, null, ex.Number, ex.Message);
        }
    }

    public Task<AssetReportDeliveryPassResult> RunReportDeliveriesAsync(long? organizationId, CancellationToken ct) =>
        DeliverReportsAsync(organizationId, null, null, "scheduler", ct);

    /// <summary>13.4.1 scheduled delivery. sp_asset_report_delivery_start starts the deliveries and checks every recipient
    /// at delivery time; each recipient that passed gets the report produced under its own permissions (the report
    /// screens it may view, Asset Reports APPROVE) and its own View Data Scope (415), through sp_asset_report_run with the
    /// export checks; the columns and rows (or the reason it failed) are stored for that recipient. A failure stays with
    /// its recipient; the others are still delivered.</summary>
    private async Task<AssetReportDeliveryPassResult> DeliverReportsAsync(long? organizationId, long? scheduleId, string? allowedAreas,
        string actor, CancellationToken ct)
    {
        List<Dictionary<string, object?>> work, started;
        await using (var connection = await OpenAsync(ct))
        {
            await using var command = Proc(connection, "grac_practice.sp_asset_report_delivery_start");
            command.CommandTimeout = 300;
            AddParam(command, "@organization_id", DbType.Int64,  organizationId);
            AddParam(command, "@schedule_id",     DbType.Int64,  scheduleId);
            AddParam(command, "@trigger_code",    DbType.String, scheduleId is null ? "SCHEDULED" : "MANUAL", 10);
            AddParam(command, "@allowed_areas",   DbType.String, Blank(allowedAreas), 2000);
            AddParam(command, "@actor",           DbType.String, actor, 100);
            await using var reader = await command.ExecuteReaderAsync(ct);
            work = await ReadRowsAsync(reader, ct);
            started = await reader.NextResultAsync(ct) ? await ReadRowsAsync(reader, ct) : new List<Dictionary<string, object?>>();
        }

        int delivered = 0, failed = 0;
        foreach (var item in work)
        {
            var recipientId = Convert.ToInt64(item["deliveryRecipientId"]);
            var employeeId = Convert.ToInt64(item["employeeId"]);
            var request = new AssetReportRunRequest(Convert.ToInt64(item["organizationId"]), Convert.ToString(item["reportCode"]),
                item["search"] as string, item["status"] as string,
                item["assetTypeId"] is null ? null : Convert.ToInt32(item["assetTypeId"]),
                item["dateFrom"] as DateTime?, item["dateTo"] as DateTime?,
                item["days"] is null ? null : Convert.ToInt32(item["days"]));
            string status = "FAILED";
            string? reason = null, columnsJson = null, rowsJson = null;
            int? rowCount = null;
            try
            {
                Infrastructure.CallerViewScope.BeginRead(employeeId);   // the recipient View Data Scope (415)
                var (columns, rows) = await ExecuteReportAsync(request, item["allowedAreas"] as string,
                    Convert.ToBoolean(item["canApprove"] ?? false), true, 1, ReportExportRowLimit + 1, ct);
                if (rows.Count > ReportExportRowLimit)
                    reason = $"The report has more than {ReportExportRowLimit} rows. Narrow the schedule filters.";
                else
                {
                    foreach (var row in rows) row.Remove("totalRows");
                    columnsJson = System.Text.Json.JsonSerializer.Serialize(columns);
                    rowsJson = System.Text.Json.JsonSerializer.Serialize(rows);
                    rowCount = rows.Count;
                    status = "DELIVERED";
                }
            }
            catch (SqlException ex) when (ex.Number is >= 53100 and <= 53119)
            {
                reason = ex.Message;   // the run refused it for this recipient (screen, policy, filters)
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogError(ex, "Report delivery {Recipient} could not be produced", recipientId);
                reason = "The report could not be produced: " + ex.Message;
            }
            finally { Infrastructure.CallerViewScope.Clear(); }

            try
            {
                await using var connection = await OpenAsync(ct);
                await using var command = Proc(connection, "grac_practice.sp_asset_report_delivery_store");
                command.CommandTimeout = 300;
                AddParam(command, "@delivery_recipient_id", DbType.Int64,  recipientId);
                AddParam(command, "@status",                DbType.String, status, 10);
                AddParam(command, "@reason",                DbType.String, reason, 1000);
                AddParam(command, "@row_count",             DbType.Int32,  rowCount);
                AddParam(command, "@columns_json",          DbType.String, columnsJson, -1);
                AddParam(command, "@rows_json",             DbType.String, rowsJson, -1);
                await command.ExecuteNonQueryAsync(ct);
                if (status == "DELIVERED") delivered++; else failed++;
            }
            catch (SqlException ex)
            {
                // Left pending: the next pass marks it interrupted after 6 hours.
                logger.LogError(ex, "Report delivery {Recipient} result could not be stored ({Number})", recipientId, ex.Number);
            }
        }
        var skipped = started.Sum(d => d.TryGetValue("skippedCount", out var s) && s is not null ? Convert.ToInt32(s) : 0);
        return new AssetReportDeliveryPassResult(started.Count, delivered, failed, skipped);
    }

    public async Task<object?> ListReportDeliveriesAsync(long organizationId, string? allowedAreas, long? scheduleId, int pageNumber,
        int pageSize, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_report_deliveries");
            AddParam(command, "@organization_id", DbType.Int64,  organizationId);
            AddParam(command, "@allowed_areas",   DbType.String, Blank(allowedAreas), 2000);
            AddParam(command, "@schedule_id",     DbType.Int64,  scheduleId);
            AddParam(command, "@page_number",     DbType.Int32,  pageNumber);
            AddParam(command, "@page_size",       DbType.Int32,  pageSize);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var rows = await ReadRowsAsync(reader, ct);
            return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
        }
        catch (SqlException ex) when (ex.Number == 53120) { return null; }
    }

    public async Task<AssetReportResult> ListReportDeliveryRecipientsAsync(long organizationId, long deliveryId, string? allowedAreas,
        CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_report_delivery_recipients");
            AddParam(command, "@organization_id", DbType.Int64,  organizationId);
            AddParam(command, "@delivery_id",     DbType.Int64,  deliveryId);
            AddParam(command, "@allowed_areas",   DbType.String, Blank(allowedAreas), 2000);
            await using var reader = await command.ExecuteReaderAsync(ct);
            return new AssetReportResult(true, new { rows = await ReadRowsAsync(reader, ct) }, null, null);
        }
        catch (SqlException ex) when (ex.Number is >= 53120 and <= 53139)
        {
            return new AssetReportResult(false, null, ex.Number, ex.Message);
        }
    }

    public async Task<object> ListMyReportDeliveriesAsync(long organizationId, long? employeeId, int pageNumber, int pageSize, CancellationToken ct)
    {
        // A session without an employee (the configured bootstrap sign-in) receives no deliveries.
        if (employeeId is null) return new { rows = new List<Dictionary<string, object?>>(), totalRows = 0, page = pageNumber, pageSize };
        await using var connection = await OpenAsync(ct);
        await using var command = Proc(connection, "grac_practice.sp_asset_report_my_deliveries");
        AddParam(command, "@organization_id", DbType.Int64, organizationId);
        AddParam(command, "@employee_id",     DbType.Int64, employeeId);
        AddParam(command, "@page_number",     DbType.Int32, pageNumber);
        AddParam(command, "@page_size",       DbType.Int32, pageSize);
        await using var reader = await command.ExecuteReaderAsync(ct);
        var rows = await ReadRowsAsync(reader, ct);
        return new { rows, totalRows = TotalRows(rows), page = pageNumber, pageSize };
    }

    /// <summary>The recipient downloads a delivered file: checked again now, recorded as an export (452), and returned
    /// as the export heading with the stored columns and rows.</summary>
    public async Task<AssetReportResult> DownloadReportDeliveryAsync(long organizationId, long deliveryRecipientId, long? employeeId,
        string? allowedAreas, bool canApprove, string actor, CancellationToken ct)
    {
        try
        {
            await using var connection = await OpenAsync(ct);
            await using var command = Proc(connection, "grac_practice.sp_asset_report_delivery_download");
            AddParam(command, "@organization_id",       DbType.Int64,   organizationId);
            AddParam(command, "@delivery_recipient_id", DbType.Int64,   deliveryRecipientId);
            AddParam(command, "@employee_id",           DbType.Int64,   employeeId);
            AddParam(command, "@allowed_areas",         DbType.String,  Blank(allowedAreas), 2000);
            AddParam(command, "@can_approve",           DbType.Boolean, canApprove);
            AddParam(command, "@actor",                 DbType.String,  actor, 100);
            await using var reader = await command.ExecuteReaderAsync(ct);
            var rows = await ReadRowsAsync(reader, ct);
            if (rows.Count == 0) return new AssetReportResult(false, null, 53126, "Delivered file not found.");
            var heading = rows[0];
            var columns = System.Text.Json.JsonDocument.Parse(Convert.ToString(heading["columnsJson"]) ?? "[]").RootElement.Clone();
            var data = System.Text.Json.JsonDocument.Parse(Convert.ToString(heading["rowsJson"]) ?? "[]").RootElement.Clone();
            heading.Remove("columnsJson");
            heading.Remove("rowsJson");
            return new AssetReportResult(true, new { export = heading, columns, rows = data }, null, null);
        }
        catch (SqlException ex) when (ex.Number is >= 53120 and <= 53139)
        {
            logger.LogWarning(ex, "AssetConfigService report delivery {Recipient} download refused ({Number})", deliveryRecipientId, ex.Number);
            return new AssetReportResult(false, null, ex.Number, ex.Message);
        }
    }

    /// <summary>Runs sp_asset_report_run and reads the one result set of the report: the column names (camelCase,""")

# ---------------------------------------------------------------- controller
C = A + 'Controllers/AssetConfigController.cs'
edit(C, """//   POST reports/settings                            organization setting of a report (enabled, classification, policy)
""", """//   POST reports/settings                            organization setting of a report (enabled, classification, policy)
//   GET  reports/schedules?organizationId=           schedules, distribution lists, employees and roles (453)
//   POST reports/schedules                           create / change a schedule and its distribution list
//   POST reports/schedules/{id}/run                  deliver one schedule now (recipients checked as at a scheduled run)
//   GET  reports/deliveries?organizationId=&scheduleId=&pageNumber=&pageSize=   deliveries (distribution results)
//   GET  reports/deliveries/{id}/recipients?organizationId=   per recipient: delivered, skipped (reason), failed
//   GET  reports/deliveries/mine?organizationId=&pageNumber=&pageSize=   the caller delivered files
//   POST reports/deliveries/recipients/{id}/download download a delivered file (checked again, recorded as an export)
""")
edit(C, """    [HttpPost("reports/settings")]""", """    [HttpGet("reports/schedules")]
    public Task<IActionResult> ReportSchedules([FromQuery] long? organizationId, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.GetReportSchedulesAsync(o, ReportAreas, ct), "Organization not found.", "report schedules");

    [HttpPost("reports/schedules")]
    public async Task<IActionResult> SaveReportSchedule([FromBody] AssetReportScheduleRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ResultWritten(await service.SaveReportScheduleAsync(request, ReportAreas, Actor, ActorEmployeeId, ct),
            ReportScheduleNotFound, ReportScheduleConflict);
    }

    [HttpPost("reports/schedules/{id:long}/run")]
    public async Task<IActionResult> RunReportSchedule(long id, [FromBody] AssetReportOrganizationRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ReportResult(await service.RunReportScheduleNowAsync(request.OrganizationId, id, ReportAreas, Actor, ct));
    }

    [HttpGet("reports/deliveries")]
    public Task<IActionResult> ReportDeliveries([FromQuery] long? organizationId, [FromQuery] long? scheduleId, [FromQuery] int? pageNumber,
        [FromQuery] int? pageSize, CancellationToken ct) =>
        ReadOrNotFound(organizationId, o => service.ListReportDeliveriesAsync(o, ReportAreas, scheduleId, pageNumber ?? 1, pageSize ?? 25, ct),
            "Organization not found.", "report deliveries");

    [HttpGet("reports/deliveries/mine")]
    public Task<IActionResult> MyReportDeliveries([FromQuery] long? organizationId, [FromQuery] int? pageNumber, [FromQuery] int? pageSize,
        CancellationToken ct)
    {
        if (organizationId is null or <= 0)
            return Task.FromResult<IActionResult>(BadRequest(new { error = "organizationId is required." }));
        return ReadAsync(() => service.ListMyReportDeliveriesAsync(organizationId.Value, ActorEmployeeId, pageNumber ?? 1, pageSize ?? 25, ct),
            "my report deliveries");
    }

    [HttpGet("reports/deliveries/{id:long}/recipients")]
    public async Task<IActionResult> ReportDeliveryRecipients(long id, [FromQuery] long? organizationId, CancellationToken ct)
    {
        if (organizationId is null or <= 0) return BadRequest(new { error = "organizationId is required." });
        return ReportResult(await service.ListReportDeliveryRecipientsAsync(organizationId.Value, id, ReportAreas, ct));
    }

    [HttpPost("reports/deliveries/recipients/{id:long}/download")]
    public async Task<IActionResult> DownloadReportDelivery(long id, [FromBody] AssetReportOrganizationRequest request, CancellationToken ct)
    {
        if (request is null || request.OrganizationId <= 0) return BadRequest(new { error = "organizationId is required." });
        return ReportResult(await service.DownloadReportDeliveryAsync(request.OrganizationId, id, ActorEmployeeId, ReportAreas, ReportApprove,
            Actor, ct));
    }

    [HttpPost("reports/settings")]""")
edit(C, """    private static readonly int[] ReportNotFound = { 53100, 53101 };
""", """    private static readonly int[] ReportNotFound = { 53100, 53101 };

    // 453: 53120 (organization), 53121 (schedule), 53122 (report cannot be scheduled) -> 404; 53128 (changed by someone
    //      else) -> 409; 53123 / 53124 / 53125 -> 400. Runs, deliveries and downloads go through ReportResult.
    private static readonly int[] ReportScheduleNotFound = { 53120, 53121, 53122 };
    private static readonly int[] ReportScheduleConflict = { 53128 };
""")
edit(C, """            53100 or 53101 => NotFound(body),
            53103 or 53105 => StatusCode(403, body),
            53102 or 53104 => Conflict(body),""", """            53100 or 53101 or 53120 or 53121 or 53126 => NotFound(body),
            53103 or 53105 or 53123 or 53129 => StatusCode(403, body),
            53102 or 53104 or 53127 or 53128 => Conflict(body),""")

# ---------------------------------------------------------------- worker
W = A + 'Services/TaskNotificationWorker.cs'
edit(W, """//     EXEC grac_practice.sp_schedule_obligation_tasks_generate;
// =====================================================================""", """//     EXEC grac_practice.sp_schedule_obligation_tasks_generate;
//
// ASSET REPORT DELIVERIES (migration 453)
// ---------------------------------------
// A fourth pass: every AssetReportDeliveryIntervalMinutes (default 60) it
// runs IAssetConfigService.RunReportDeliveriesAsync, which starts the
// deliveries of the report schedules due today (one per schedule and day),
// checks every recipient at delivery time and produces the report for each
// recipient under that recipient permissions and View Data Scope. The rows
// are produced in the API, so there is no SQL Agent equivalent;
// AssetReportDeliveryEnabled=false stops scheduled deliveries ("Run now" on
// the screen still works).
// =====================================================================""")
edit(W, """    public int ScheduledObligationTasksIntervalMinutes { get; set; } = 60;
}""", """    public int ScheduledObligationTasksIntervalMinutes { get; set; } = 60;

    /// <summary>453: deliver the asset report schedules due today.</summary>
    public bool AssetReportDeliveryEnabled { get; set; } = true;

    /// <summary>453: minutes between delivery passes (schedules are per day).</summary>
    public int AssetReportDeliveryIntervalMinutes { get; set; } = 60;
}""")
edit(W, """        if (!options.Enabled && !options.AssetSchedulerEnabled && !options.ScheduledObligationTasksEnabled)""",
"""        if (!options.Enabled && !options.AssetSchedulerEnabled && !options.ScheduledObligationTasksEnabled && !options.AssetReportDeliveryEnabled)""")
edit(W, """        DateTime? lastObligationRun = null;   // 449
""", """        DateTime? lastObligationRun = null;   // 449
        var reportInterval = TimeSpan.FromMinutes(Math.Clamp(options.AssetReportDeliveryIntervalMinutes, 5, 1440));
        DateTime? lastReportRun = null;   // 453
""")
edit(W, """                catch (Exception ex)
                {
                    logger.LogError(ex, "Scheduled obligation task pass failed; will retry on the next interval.");
                }
            }
""", """                catch (Exception ex)
                {
                    logger.LogError(ex, "Scheduled obligation task pass failed; will retry on the next interval.");
                }
            }

            // 453: asset report deliveries, at most every reportInterval.
            if (options.AssetReportDeliveryEnabled && (lastReportRun is null || DateTime.UtcNow - lastReportRun.Value >= reportInterval))
            {
                lastReportRun = DateTime.UtcNow;   // also after a failure: retry on the next interval
                try
                {
                    using var scope = scopeFactory.CreateScope();
                    var assets = scope.ServiceProvider.GetService<IAssetConfigService>();
                    if (assets is not null)
                    {
                        var run = await assets.RunReportDeliveriesAsync(options.OrganizationId, stoppingToken);
                        if (run.Deliveries > 0)
                            logger.LogInformation(
                                "Asset report delivery pass: {Deliveries} delivery(ies), {Delivered} file(s) delivered, {Skipped} recipient(s) skipped, {Failed} failed.",
                                run.Deliveries, run.Delivered, run.Skipped, run.Failed);
                    }
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    break;   // shutting down
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Asset report delivery pass failed; will retry on the next interval.");
                }
            }
""")

# ---------------------------------------------------------------- appsettings
edit(A + 'appsettings.json', """    "ScheduledObligationTasksIntervalMinutes": 60
  },""", """    "ScheduledObligationTasksIntervalMinutes": 60,
    "AssetReportDeliveryEnabled": true,
    "AssetReportDeliveryIntervalMinutes": 60
  },""")
json.load(open(A + 'appsettings.json'))
print('api patched')
