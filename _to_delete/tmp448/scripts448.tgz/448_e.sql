-- =====================================================================
-- 12. Verification
-- =====================================================================
SELECT '448-a objects' AS Check_,
       CASE WHEN OBJECT_ID('grac_practice.asset_privacy_requirement','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_privacy_setting','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_privacy_exception','U') IS NOT NULL
             AND OBJECT_ID('grac_practice.asset_privacy_review','U') IS NOT NULL
             AND (SELECT COUNT(*) FROM grac_practice.asset_privacy_requirement) = 12
             AND OBJECT_ID('grac_practice.fn_asset_privacy_values') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_privacy_retention_calc') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_privacy_gaps') IS NOT NULL
             AND OBJECT_ID('grac_practice.fn_asset_privacy_status') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_privacy_sync','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_privacy_run','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_privacy_requirements','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_privacy_setting_save','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_privacy_exception_request','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_privacy_exception_action','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_privacy_review_complete','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_privacy_assets','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_privacy_asset_get','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_privacy_exceptions','P') IS NOT NULL
             AND OBJECT_ID('grac_practice.sp_asset_privacy_reviews','P') IS NOT NULL
            THEN 'PASS' ELSE 'FAIL' END AS Result;
SELECT '448-b re-issued bodies and notification wiring' AS Check_,
       CASE WHEN OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_register_save')) LIKE '%sp_asset_privacy_sync%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_register_save')) LIKE '%sp_asset_consistency_evaluate%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) LIKE '%sp_asset_privacy_sync%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_scheduler_run')) LIKE '%sp_asset_consistency_evaluate%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_lifecycle_transition')) LIKE '%53070%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_lifecycle_transition')) LIKE '%53037%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_notification_sweep')) LIKE '%PRIVACY_REVIEW:PX:%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_notification_sweep')) LIKE '%EVIDENCE_EXPIRY:EV:%'
             AND OBJECT_DEFINITION(OBJECT_ID('grac_practice.sp_asset_notification_parties')) LIKE '%PRIVACY_EXCEPTION%'
             AND EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_pm_asset_ntf_occ_obj' AND definition LIKE '%PRIVACY_REVIEW%')
             AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_notification_activity
                              WHERE activity_code IN (N'PRIVACY_REVIEW', N'RETENTION_REVIEW') AND source_available = 0)
            THEN 'PASS' ELSE 'FAIL' END AS Result;
-- Retention arithmetic: 7 years from 2026-01-15 -> 2033-01-15; 18 months -> 2027-07-15; bad text -> invalid.
SELECT '448-c retention arithmetic' AS Check_,
       CASE WHEN (SELECT FormulaDueDate FROM grac_practice.fn_asset_privacy_retention_calc(0, 0, N'7 years', N'CREATION', '2026-01-15', NULL)) = '2033-01-15'
             AND (SELECT FormulaDueDate FROM grac_practice.fn_asset_privacy_retention_calc(0, 0, N'18 Months', N'CREATION', '2026-01-15', NULL)) = '2027-07-15'
             AND (SELECT PeriodInvalid FROM grac_practice.fn_asset_privacy_retention_calc(0, 0, N'forever', N'CREATION', '2026-01-15', NULL)) = 1
             AND (SELECT PeriodInvalid FROM grac_practice.fn_asset_privacy_retention_calc(0, 0, N'500 years', N'CREATION', '2026-01-15', NULL)) = 1
            THEN 'PASS' ELSE 'FAIL' END AS Result;
-- The status function runs for every organization; menu row in place.
SELECT '448-d status readable and menu' AS Check_,
       (SELECT COUNT(*) FROM grac_practice.organization o CROSS APPLY grac_practice.fn_asset_privacy_status(o.organization_id, NULL) s) AS AssetsEvaluated,
       CASE WHEN EXISTS (SELECT 1 FROM grac_practice.menu_master c
                           JOIN grac_practice.menu_master p ON p.menu_id = c.parent_menu_id AND p.menu_key = N'nav-asset-contract'
                          WHERE c.menu_key = N'asset-privacy' AND c.status = N'Active') THEN 'PASS' ELSE 'FAIL' END AS Result;
GO

/* =====================================================================
   UAT (asset-privacy VIEW / EDIT / APPROVE held by two people;
   asset-register EDIT)
   ---------------------------------------------------------------------
   1. Asset Register: an asset whose template has the privacy fields; set
      Personal data processed = Yes and save -> warning "Privacy: n gap(s)";
      the Privacy tab shows status Incomplete and the gaps.
   2. Complete every 5.1.10 field (assessment Approved, DPIA not required,
      masking / encryption Yes and implemented, retention 7 years from
      Creation, review date next month, residual risk) -> Compliant;
      masking implemented = Partially -> Conditional; encryption
      implemented = No -> Non-compliant (5.1.16: never Compliant while
      incomplete).
   3. Asset Privacy -> Requirements: Encryption = Block; the move to
      Active is refused (53070) while encryption is not implemented.
   4. Request an exception for Encryption (reason, controls, owner,
      expiry) -> approve as the requester refused (53061), as another
      person approved -> status Conditional, the move to Active allowed.
   5. Reviews tab: an open Privacy review due on the review date; complete
      it with a next date -> the asset privacy review date changes and a
      new review opens. Set a retention period ending in the past ->
      Retention review overdue and a Retention gap; complete with Extend
      (approver, reason, date) or Delete (evidence).
   6. Asset with Sanitization required = Yes in Disposal Approval and no
      sanitization date / evidence -> move to Disposed refused (53071).
   7. Run the scheduler -> notifications PRIVACY_REVIEW / RETENTION_REVIEW
      for the open reviews (Asset Notifications).
   ===================================================================== */
