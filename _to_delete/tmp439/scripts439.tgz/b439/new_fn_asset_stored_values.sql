CREATE OR ALTER FUNCTION grac_practice.fn_asset_stored_values (@asset_id BIGINT)
RETURNS TABLE
AS
RETURN
    SELECT d.field_definition_id AS FieldDefinitionId, d.field_key AS FieldKey, c.val AS Value
      FROM grac_practice.organization_dependency_asset a
     CROSS APPLY (VALUES
        (N'asset_id',             CAST(a.asset_id AS NVARCHAR(MAX))),
        (N'asset_name',           CAST(a.asset_name AS NVARCHAR(MAX))),
        (N'asset_category_id',    CAST(a.asset_category_id AS NVARCHAR(MAX))),
        (N'asset_subcategory_id', CAST(a.asset_subcategory_id AS NVARCHAR(MAX))),
        (N'asset_type_id',        CAST(a.asset_type_id AS NVARCHAR(MAX))),
        (N'organization_id',      CAST(a.organization_id AS NVARCHAR(MAX))),
        (N'location_id',          CAST(a.location_id AS NVARCHAR(MAX))),
        (N'owner_id',             CAST(a.owner_id AS NVARCHAR(MAX))),
        (N'purchase_dt',          CONVERT(NVARCHAR(MAX), a.purchase_dt, 23)),
        (N'warranty_expiry_dt',   CONVERT(NVARCHAR(MAX), a.warranty_expiry_dt, 23)),
        (N'amc_expiry_dt',        CONVERT(NVARCHAR(MAX), a.amc_expiry_dt, 23)),
        (N'criticality_id',       CAST(a.criticality_id AS NVARCHAR(MAX))),
        (N'remarks',              CAST(a.remarks AS NVARCHAR(MAX))),
        (N'entered_by',           CAST(a.entered_by AS NVARCHAR(MAX))),
        (N'entered_dt',           CONVERT(NVARCHAR(MAX), a.entered_dt, 126)),
        (N'updated_by',           CAST(a.updated_by AS NVARCHAR(MAX))),
        (N'updated_dt',           CONVERT(NVARCHAR(MAX), a.updated_dt, 126))
     ) AS c(column_name, val)
      JOIN grac_practice.asset_field_definition d ON d.storage_kind = N'COLUMN' AND d.column_name = c.column_name
     WHERE a.asset_id = @asset_id AND c.val IS NOT NULL
    UNION ALL
    SELECT v.field_definition_id, d.field_key, v.value_text
      FROM grac_practice.asset_field_value v
      JOIN grac_practice.asset_field_definition d ON d.field_definition_id = v.field_definition_id
     WHERE v.asset_id = @asset_id
    UNION ALL
    SELECT d.field_definition_id, d.field_key, s.status_code
      FROM grac_practice.organization_dependency_asset a
      JOIN grac_practice.entity_status_master s ON s.entity_status_id = a.current_status_id
      JOIN grac_practice.asset_field_definition d ON d.field_key = N'asset_status'
     WHERE a.asset_id = @asset_id
    UNION ALL
    -- 435: the calculated coverage status (5.1.11).
    SELECT d.field_definition_id, d.field_key, cs.CoverageStatusLabel
      FROM grac_practice.organization_dependency_asset a
     CROSS APPLY grac_practice.fn_asset_coverage_summary(a.organization_id, a.asset_id) cs
      JOIN grac_practice.asset_field_definition d ON d.field_key = N'coverage_status'
     WHERE a.asset_id = @asset_id
    UNION ALL
    -- 438: next calibration / maintenance / inspection date and calibration /
    -- maintenance status from the activity schedule (5.1.7), unless a value
    -- is stored for the field.
    SELECT d.field_definition_id, d.field_key, x.val
      FROM grac_practice.asset_activity_schedule s
      JOIN grac_practice.asset_activity_template t ON t.template_code = s.template_code
     CROSS APPLY (VALUES
        (t.next_date_field_key, CONVERT(NVARCHAR(MAX), s.next_due_date, 23)),
        (t.status_field_key,
         CASE WHEN t.status_field_key = N'maintenance_status'
                   AND EXISTS (SELECT 1 FROM grac_practice.asset_activity_occurrence o
                                WHERE o.asset_id = s.asset_id AND o.template_code = s.template_code
                                  AND o.status = N'OPEN' AND o.task_id IS NOT NULL) THEN N'In Progress'
              WHEN t.status_field_key = N'maintenance_status' THEN
                   CASE s.status_code WHEN N'VALID' THEN N'Not Due' WHEN N'DUE_SOON' THEN N'Due Soon' WHEN N'OVERDUE' THEN N'Overdue'
                                      WHEN N'FAILED' THEN N'Overdue' END                                   -- 439
              ELSE CASE s.status_code WHEN N'VALID' THEN N'Valid' WHEN N'DUE_SOON' THEN N'Due Soon' WHEN N'OVERDUE' THEN N'Overdue'
                                      WHEN N'NOT_APPLICABLE' THEN N'N/A' WHEN N'FAILED' THEN N'Failed' END END)   -- 439: Failed
     ) AS x(field_key, val)
      JOIN grac_practice.asset_field_definition d ON d.field_key = x.field_key
     WHERE s.asset_id = @asset_id AND x.val IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM grac_practice.asset_field_value v
                        WHERE v.asset_id = @asset_id AND v.field_definition_id = d.field_definition_id);
GO
