// =====================================================================
// TaskService  (charter §12.1.3)
//
// Thin façade over grac_practice.sp_task_* procedures. Kept in a new
// file per charter §5 non-negotiable — do not extend
// PracticeRepositoryService.cs.
//
// Wire-up (extension method): Api/Infrastructure/TaskServiceRegistration.cs
// The reviewer adds the following ONE line to Program.cs (pending
// explicit approval per charter §5):
//     builder.Services.AddPracticeTaskService();
//
// TASK CENTRE v2 (BRD 16 Aug 2026)
// --------------------------------
// The v2 methods are grouped below the original five. Two deliberate
// design points:
//
//   * The service adds NO business logic. Priority asymmetry, SLA
//     derivation, child inheritance and the completion gate all live in
//     the procedures (192-196), because the Gap Centre, sweeps and
//     Exception Centre must obey the same rules without going through
//     this API.
//
//   * Row mapping is COLUMN-TOLERANT. MapRow only reads a v2 column when
//     the result set actually carries it, so the Api tier keeps working
//     against a database where 195 has not been applied yet. That makes
//     the migration order (DB first, then app) non-breaking in either
//     direction.
// =====================================================================
using System.Data;
using System.Data.Common;
using Microsoft.Data.SqlClient;
using PracticeManagement.Api.Models;

namespace PracticeManagement.Api.Services;

public interface ITaskService
{
    // ---- original contract (037/048) --------------------------------
    Task<TaskListResult> ListAsync(TaskListQuery query, CancellationToken cancellationToken);
    Task<TaskCommandResult> OpenAsync(TaskOpenRequest request, CancellationToken cancellationToken);
    Task<TaskCommandResult> AssignAsync(TaskAssignRequest request, CancellationToken cancellationToken);
    Task<TaskCommandResult> TransitionAsync(TaskTransitionRequest request, CancellationToken cancellationToken);
    Task<TaskCommandResult> CloseAsync(TaskCloseRequest request, CancellationToken cancellationToken);
    Task<TaskCommandResult> ReopenAsync(TaskReopenRequest request, CancellationToken cancellationToken);

    // ---- Task Centre v2 (192-196) -----------------------------------
    Task<TaskCountsResult> CountsAsync(long? organizationId, CancellationToken cancellationToken);
    // Migration 256 -- per-source counts for the Source filter.
    Task<TaskSourceCountsResult> SourceCountsAsync(long? organizationId, CancellationToken cancellationToken);
    Task<TaskDetailResult?> GetAsync(long taskId, CancellationToken cancellationToken);
    Task<TaskCommandResult> ChangePriorityAsync(TaskPriorityChangeRequest request, CancellationToken cancellationToken);
    Task<TaskCommandResult> RequestSlaExtensionAsync(TaskSlaExtensionRequest request, CancellationToken cancellationToken);
    Task<TaskCommandResult> ApproveSlaExtensionAsync(TaskGovernanceApproveRequest request, CancellationToken cancellationToken);
    Task<TaskCommandResult> ApprovePriorityReductionAsync(TaskGovernanceApproveRequest request, CancellationToken cancellationToken);
    Task<TaskCommandResult> CreateChildAsync(TaskChildCreateRequest request, CancellationToken cancellationToken);
    Task<TaskCommandResult> CompleteAsync(TaskCompleteRequest request, CancellationToken cancellationToken);
    Task<TaskCompletionEligibility?> CompletionEligibilityAsync(long taskId, CancellationToken cancellationToken);
    Task<TaskCommandResult> AddActivityAsync(TaskActivityAddRequest request, CancellationToken cancellationToken);
    Task<TaskOwnerResolveResult> ResolveOwnerAsync(TaskOwnerResolveQuery query, CancellationToken cancellationToken);
    Task<IReadOnlyList<TaskSourceTaskRow>> SourceTasksAsync(string sourceTypeCode, long sourceRecordId, long? organizationId, CancellationToken cancellationToken);
    Task<TaskCommandResult> AddAttachmentAsync(long taskId, string fileName, string? contentType, byte[] fileData, string? evidenceDescription, long? uploadedByEmployeeId, bool callerIsAdmin, long? instanceEvidenceId, CancellationToken cancellationToken);
    Task<TaskAttachmentContent?> GetAttachmentAsync(long taskAttachmentId, CancellationToken cancellationToken);
    // 477: Select from Evidence Center on a task.
    Task<TaskEvidenceCandidateResult> ListEvidenceCandidatesAsync(long taskId, long organizationId, long? callerEmployeeId, bool callerIsAdmin,
                                                                  string? search, int? evidenceTypeId, int pageNumber, int pageSize,
                                                                  CancellationToken cancellationToken);
    Task<TaskCommandResult> LinkEvidenceAsync(long taskId, TaskEvidenceLinkRequest request, long? callerEmployeeId, bool callerIsAdmin,
                                              string callerDisplayName, CancellationToken cancellationToken);
    // 482: recurring evidence on Complete Task.
    Task<TaskRecurringEvidenceResult> ListRecurringEvidenceAsync(long taskId, long organizationId, CancellationToken cancellationToken);
    Task<TaskCommandResult> SaveRecurringEvidenceAsync(long taskId, TaskRecurringEvidenceSaveRequest request, long? callerEmployeeId,
                                                       string callerDisplayName, CancellationToken cancellationToken);

    // ---- Task edit (269) --------------------------------------------
    // The single update path. The four single-field commands above stay
    // on this interface: they are still the right call for one governed
    // act from elsewhere in the product, and UpdateAsync composes the
    // same procedures rather than re-deciding anything.
    Task<TaskEditOptions?> GetEditOptionsAsync(long taskId, CancellationToken cancellationToken);
    Task<TaskUpdateResult> UpdateAsync(TaskUpdateRequest request, CancellationToken cancellationToken);
}

public sealed class TaskService(IConfiguration configuration, ILogger<TaskService> logger) : ITaskService
{
    // Delegates to SqlConnectionStringResolver — see PermissionService.

    // =================================================================
    // Original contract
    // =================================================================

    public async Task<TaskListResult> ListAsync(TaskListQuery query, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(query);

        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_task_list";

        AddParam(command, "@organization_id",         DbType.Int64,  (object?)query.OrganizationId ?? DBNull.Value);
        AddParam(command, "@assigned_to_employee_id", DbType.Int64,  (object?)query.AssignedToEmployeeId ?? DBNull.Value);
        AddParam(command, "@task_type_code",          DbType.String, (object?)query.TaskTypeCode ?? DBNull.Value, 60);
        AddParam(command, "@status_code",             DbType.String, (object?)query.StatusCode ?? DBNull.Value, 60);
        AddParam(command, "@overdue_only",            DbType.Boolean, query.OverdueOnly ?? false);
        AddParam(command, "@search",                  DbType.String, (object?)query.Search ?? DBNull.Value, 200);
        AddParam(command, "@page",                    DbType.Int32,  Math.Max(1, query.Page));
        AddParam(command, "@page_size",               DbType.Int32,  Math.Clamp(query.PageSize, 1, 200));

        // v2 filters (195). Sent only when the proc understands them, so
        // an Api deployed ahead of migration 195 still works.
        if (await ProcHasParameterAsync(connection, "sp_task_list", "@include_children", cancellationToken))
        {
            AddParam(command, "@parent_task_id",   DbType.Int64,  (object?)query.ParentTaskId ?? DBNull.Value);
            AddParam(command, "@include_children", DbType.Boolean, query.IncludeChildren ?? false);
            AddParam(command, "@sla_status_code",  DbType.String, (object?)query.SlaStatusCode ?? DBNull.Value, 30);
            AddParam(command, "@source_type_code", DbType.String, (object?)query.SourceTypeCode ?? DBNull.Value, 40);
            AddParam(command, "@source_record_id", DbType.Int64,  (object?)query.SourceRecordId ?? DBNull.Value);
            AddParam(command, "@priority",         DbType.String, (object?)query.Priority ?? DBNull.Value, 30);
        }
        // 414: dashboard drill-down, sent only when declared.
        await Infrastructure.ListDrillParameters.AddAsync(connection, command, "sp_task_list", query.Drill, cancellationToken);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);

        long total = 0;
        int  page  = query.Page;
        int  size  = query.PageSize;
        if (await reader.ReadAsync(cancellationToken))
        {
            total = Convert.ToInt64(reader["TotalCount"]);
            page  = Convert.ToInt32(reader["PageNumber"]);
            size  = Convert.ToInt32(reader["PageSize"]);
        }

        var rows = new List<TaskListRow>();
        if (await reader.NextResultAsync(cancellationToken))
        {
            var cols = ColumnSet(reader);
            while (await reader.ReadAsync(cancellationToken))
                rows.Add(MapRow(reader, cols));
        }

        return new TaskListResult(total, page, size, rows);
    }

    public async Task<TaskCommandResult> OpenAsync(TaskOpenRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (string.IsNullOrWhiteSpace(request.TaskTypeCode))      return Fail("TaskTypeCode is required.");
        if (string.IsNullOrWhiteSpace(request.SubjectEntityType)) return Fail("SubjectEntityType is required.");
        if (string.IsNullOrWhiteSpace(request.SubjectTitle))      return Fail("SubjectTitle is required.");

        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_open";

            AddParam(command, "@organization_id",        DbType.Int64,  request.OrganizationId);
            AddParam(command, "@task_type_code",         DbType.String, request.TaskTypeCode, 60);
            AddParam(command, "@subject_entity_type",    DbType.String, request.SubjectEntityType, 60);
            AddParam(command, "@subject_entity_id",      DbType.Int64,  request.SubjectEntityId);
            AddParam(command, "@subject_title",          DbType.String, request.SubjectTitle, 250);
            AddParam(command, "@subject_description",    DbType.String, (object?)request.SubjectDescription ?? DBNull.Value, -1);
            AddParam(command, "@linked_release_id",      DbType.Int64,  (object?)request.LinkedReleaseId ?? DBNull.Value);
            AddParam(command, "@linked_control_id",      DbType.Int64,  (object?)request.LinkedControlId ?? DBNull.Value);
            AddParam(command, "@linked_practice_id",     DbType.Int64,  (object?)request.LinkedPracticeId ?? DBNull.Value);
            AddParam(command, "@linked_instance_id",     DbType.Int64,  (object?)request.LinkedInstanceId ?? DBNull.Value);
            AddParam(command, "@priority",               DbType.String, (object?)request.Priority ?? DBNull.Value, 30);
            AddParam(command, "@criticality",            DbType.String, (object?)request.Criticality ?? DBNull.Value, 30);
            AddParam(command, "@origin_code",            DbType.String, (object?)request.OriginCode ?? DBNull.Value, 30);
            AddParam(command, "@assigned_to_employee_id",DbType.Int64,  (object?)request.AssignedToEmployeeId ?? DBNull.Value);
            AddParam(command, "@actor_employee_id",      DbType.Int64,  (object?)request.ActorEmployeeId ?? DBNull.Value);
            AddParam(command, "@actor_role_code",        DbType.String, (object?)request.ActorRoleCode ?? DBNull.Value, 60);
            AddParam(command, "@correlation_id",         DbType.Guid,   (object?)request.CorrelationId ?? DBNull.Value);
            AddParam(command, "@start_date",             DbType.DateTime2, (object?)request.StartDate ?? DBNull.Value);
            AddParam(command, "@target_date",            DbType.DateTime2, (object?)request.TargetDate ?? DBNull.Value);

            // v3 params (196). Owner resolution and SLA derivation happen
            // inside the proc so every caller — not just this API — gets
            // them (BRD §6, §8).
            if (await ProcHasParameterAsync(connection, "sp_task_open", "@source_type_code", cancellationToken))
            {
                AddParam(command, "@source_type_code", DbType.String, (object?)request.SourceTypeCode ?? DBNull.Value, 40);
                AddParam(command, "@source_record_id", DbType.Int64,  (object?)request.SourceRecordId ?? DBNull.Value);
                AddParam(command, "@source_reference", DbType.String, (object?)request.SourceReference ?? DBNull.Value, 200);
                AddParam(command, "@resolve_owner",    DbType.Boolean, request.ResolveOwner ?? true);
            }

            var taskIdParam = command.CreateParameter();
            taskIdParam.ParameterName = "@task_id";
            taskIdParam.DbType        = DbType.Int64;
            taskIdParam.Direction     = ParameterDirection.Output;
            command.Parameters.Add(taskIdParam);

            await command.ExecuteNonQueryAsync(cancellationToken);
            var taskId = taskIdParam.Value is long l ? l : Convert.ToInt64(taskIdParam.Value);
            return new TaskCommandResult(true, taskId);
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(OpenAsync));
        }
    }

    public async Task<TaskCommandResult> AssignAsync(TaskAssignRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_assign";

            AddParam(command, "@task_id",                DbType.Int64,  request.TaskId);
            AddParam(command, "@assigned_to_employee_id",DbType.Int64,  request.AssignedToEmployeeId);
            AddParam(command, "@actor_employee_id",      DbType.Int64,  (object?)request.ActorEmployeeId ?? DBNull.Value);
            AddParam(command, "@actor_role_code",        DbType.String, (object?)request.ActorRoleCode ?? DBNull.Value, 60);
            AddParam(command, "@reason_code",            DbType.String, (object?)request.ReasonCode ?? DBNull.Value, 60);
            AddParam(command, "@reason_text",            DbType.String, (object?)request.ReasonText ?? DBNull.Value, 1000);
            AddParam(command, "@correlation_id",         DbType.Guid,   (object?)request.CorrelationId ?? DBNull.Value);

            await command.ExecuteNonQueryAsync(cancellationToken);

            // BRD §6: "Owner reassignment is operational freedom. It
            // requires no Exception approval. Every reassignment must be
            // auditable." sp_task_assign already writes to
            // practice_audit_trace; this adds the human-readable entry to
            // the task's own activity feed (BRD §16). Best-effort: a
            // logging failure must not fail a completed reassignment.
            await TryLogActivityAsync(connection, request.TaskId, "Reassign",
                request.ReasonText, null, request.AssignedToEmployeeId.ToString(),
                request.ActorEmployeeId, cancellationToken);

            await TryStampOwnerSourceAsync(connection, request.TaskId, cancellationToken);

            return new TaskCommandResult(true, request.TaskId);
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(AssignAsync));
        }
    }

    public async Task<TaskCommandResult> TransitionAsync(TaskTransitionRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (string.IsNullOrWhiteSpace(request.ToStatusCode)) return Fail("ToStatusCode is required.");
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_transition";

            AddParam(command, "@task_id",           DbType.Int64,  request.TaskId);
            AddParam(command, "@to_status_code",    DbType.String, request.ToStatusCode, 60);
            AddParam(command, "@actor_employee_id", DbType.Int64,  (object?)request.ActorEmployeeId ?? DBNull.Value);
            AddParam(command, "@actor_role_code",   DbType.String, (object?)request.ActorRoleCode ?? DBNull.Value, 60);
            AddParam(command, "@reason_code",       DbType.String, (object?)request.ReasonCode ?? DBNull.Value, 60);
            AddParam(command, "@reason_text",       DbType.String, (object?)request.ReasonText ?? DBNull.Value, 1000);
            AddParam(command, "@correlation_id",    DbType.Guid,   (object?)request.CorrelationId ?? DBNull.Value);

            await command.ExecuteNonQueryAsync(cancellationToken);

            await TryLogActivityAsync(connection, request.TaskId, "StatusChange",
                request.ReasonText, null, request.ToStatusCode,
                request.ActorEmployeeId, cancellationToken);

            return new TaskCommandResult(true, request.TaskId);
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(TransitionAsync));
        }
    }

    public async Task<TaskCommandResult> CloseAsync(TaskCloseRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_close";

            AddParam(command, "@task_id",           DbType.Int64,  request.TaskId);
            AddParam(command, "@actor_employee_id", DbType.Int64,  (object?)request.ActorEmployeeId ?? DBNull.Value);
            AddParam(command, "@actor_role_code",   DbType.String, (object?)request.ActorRoleCode ?? DBNull.Value, 60);
            AddParam(command, "@reason_code",       DbType.String, (object?)request.ReasonCode ?? DBNull.Value, 60);
            AddParam(command, "@reason_text",       DbType.String, (object?)request.ReasonText ?? DBNull.Value, 1000);
            AddParam(command, "@correlation_id",    DbType.Guid,   (object?)request.CorrelationId ?? DBNull.Value);

            await command.ExecuteNonQueryAsync(cancellationToken);
            return new TaskCommandResult(true, request.TaskId);
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(CloseAsync));
        }
    }

    public async Task<TaskCommandResult> ReopenAsync(TaskReopenRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_reopen";

            AddParam(command, "@task_id",           DbType.Int64,   request.TaskId);
            AddParam(command, "@actor_employee_id", DbType.Int64,   (object?)request.ActorEmployeeId ?? DBNull.Value);
            AddParam(command, "@actor_role_code",   DbType.String,  (object?)request.ActorRoleCode ?? DBNull.Value, 60);
            AddParam(command, "@is_admin",          DbType.Boolean, request.IsAdmin);
            AddParam(command, "@reason_text",       DbType.String,  (object?)request.ReasonText ?? DBNull.Value, 1000);
            AddParam(command, "@correlation_id",    DbType.Guid,    (object?)request.CorrelationId ?? DBNull.Value);

            await command.ExecuteNonQueryAsync(cancellationToken);
            return new TaskCommandResult(true, request.TaskId);
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(ReopenAsync));
        }
    }

    // =================================================================
    // Task Centre v2
    // =================================================================

    public async Task<TaskCountsResult> CountsAsync(long? organizationId, CancellationToken cancellationToken)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_task_center_counts";
        AddParam(command, "@organization_id", DbType.Int64, (object?)organizationId ?? DBNull.Value);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
            return new TaskCountsResult(0, 0, 0, 0, 0, 0);

        var cols = ColumnSet(reader);
        return new TaskCountsResult(
            GapsCount:            GetLong(reader, cols, "GapsCount") ?? 0,
            ImplementationCount:  GetLong(reader, cols, "ImplementationCount") ?? 0,
            AssuranceCount:       GetLong(reader, cols, "AssuranceCount") ?? 0,
            CustomCount:          GetLong(reader, cols, "CustomCount") ?? 0,
            BreachedCount:        GetLong(reader, cols, "BreachedCount") ?? 0,
            PendingApprovalCount: GetLong(reader, cols, "PendingApprovalCount") ?? 0);
    }

    // Migration 256 -- Source filter counts, the Task Centre twin of
    // CustomGapService.ListGapCentreSourcesAsync. Non-fatal by contract:
    // an empty list means "no counts available" and the screen falls back
    // to unlabelled options rather than failing the page.
    public async Task<TaskSourceCountsResult> SourceCountsAsync(
        long? organizationId, CancellationToken cancellationToken)
    {
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_centre_source_counts";
            AddParam(command, "@organization_id", DbType.Int64, (object?)organizationId ?? DBNull.Value);

            var sources = new List<TaskSourceCount>();
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
                sources.Add(new TaskSourceCount(
                    reader["SourceTypeCode"]?.ToString() ?? "",
                    Convert.ToInt32(reader["DisplayOrder"]),
                    Convert.ToInt64(reader["TaskCount"])));

            long total = 0, unsourced = 0;
            if (await reader.NextResultAsync(cancellationToken)
                && await reader.ReadAsync(cancellationToken))
            {
                total     = Convert.ToInt64(reader["TotalCount"]);
                unsourced = Convert.ToInt64(reader["UnsourcedCount"]);
            }
            return new TaskSourceCountsResult(sources, total, unsourced);
        }
        catch (SqlException ex)
        {
            logger.LogError(ex, "sp_task_centre_source_counts failed for organization {OrgId}.", organizationId);
            // 2812 = "Could not find stored procedure" -- name the cause
            // rather than leaving a silent empty dropdown, the same way
            // 255's Gap Centre read does.
            var message = ex.Number == 2812
                ? "Task Centre source-count procedure is missing. Run database migration "
                  + "256_task_centre_source_counts.sql."
                : ex.Message;
            return new TaskSourceCountsResult([], 0, 0, message);
        }
    }

    public async Task<TaskDetailResult?> GetAsync(long taskId, CancellationToken cancellationToken)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_task_get";
        AddParam(command, "@task_id", DbType.Int64, taskId);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);

        // ---- 1. header ----
        TaskListRow? header = null;
        if (await reader.ReadAsync(cancellationToken))
        {
            var cols = ColumnSet(reader);
            header = MapRow(reader, cols);
        }
        if (header is null) return null;

        // ---- 2. activity ----
        var activity = new List<TaskActivityRow>();
        if (await reader.NextResultAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
                activity.Add(new TaskActivityRow(
                    TaskActivityId:   Convert.ToInt64(reader["TaskActivityId"]),
                    TaskId:           Convert.ToInt64(reader["TaskId"]),
                    ActivityTypeCode: reader["ActivityTypeCode"]?.ToString() ?? "",
                    Remark:           reader["Remark"]           as string,
                    FromValue:        reader["FromValue"]        as string,
                    ToValue:          reader["ToValue"]          as string,
                    ActorEmployeeId:  reader["ActorEmployeeId"]  as long?,
                    ActorDisplayName: reader["ActorDisplayName"] as string,
                    EnteredDt:        Convert.ToDateTime(reader["EnteredDt"])));
        }

        // ---- 3. attachments (metadata only) ----
        var attachments = new List<TaskAttachmentRow>();
        if (await reader.NextResultAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
                attachments.Add(new TaskAttachmentRow(
                    TaskAttachmentId:     Convert.ToInt64(reader["TaskAttachmentId"]),
                    FileName:             reader["FileName"]?.ToString() ?? "",
                    ContentType:          reader["ContentType"]          as string,
                    FileSizeBytes:        Convert.ToInt64(reader["FileSizeBytes"]),
                    EvidenceDescription:  reader["EvidenceDescription"]  as string,
                    UploadedByEmployeeId: reader["UploadedByEmployeeId"] as long?,
                    UploadedByName:       reader["UploadedByName"]       as string,
                    UploadedDt:           Convert.ToDateTime(reader["UploadedDt"]),
                    // 477 -- absent before the migration.
                    EvidenceItemId:       GetLong(reader, ColumnSet(reader), "EvidenceItemId"),
                    EvidenceTitle:        GetString(reader, ColumnSet(reader), "EvidenceTitle"),
                    VersionNo:            GetInt(reader, ColumnSet(reader), "VersionNo"),
                    PeriodDate:           GetDate(reader, ColumnSet(reader), "PeriodDate"),
                    // 482 -- absent before the migration.
                    InstanceEvidenceId:   GetLong(reader, ColumnSet(reader), "InstanceEvidenceId")));
        }

        // ---- 4. children ----
        var children = new List<TaskChildRow>();
        if (await reader.NextResultAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
                children.Add(new TaskChildRow(
                    TaskId:                 Convert.ToInt64(reader["TaskId"]),
                    TaskNumber:             reader["TaskNumber"]             as string,
                    SubjectTitle:           reader["SubjectTitle"]?.ToString() ?? "",
                    SubjectDescription:     reader["SubjectDescription"]     as string,
                    AssignedToEmployeeId:   reader["AssignedToEmployeeId"]   as long?,
                    AssignedToEmployeeName: reader["AssignedToEmployeeName"] as string,
                    Priority:               reader["Priority"]?.ToString() ?? "Medium",
                    IsMandatoryChild:       reader["IsMandatoryChild"] == DBNull.Value ? null : Convert.ToBoolean(reader["IsMandatoryChild"]),
                    ChildTargetDate:        reader["ChildTargetDate"]        as DateTime?,
                    SlaDueAt:               reader["SlaDueAt"]               as DateTime?,
                    SlaStatusCode:          reader["SlaStatusCode"]          as string,
                    CurrentStatusCode:      reader["CurrentStatusCode"]?.ToString() ?? "",
                    CurrentStatusName:      reader["CurrentStatusName"]?.ToString() ?? "",
                    ClosedAt:               reader["ClosedAt"]               as DateTime?,
                    CompletedDt:            reader["CompletedDt"]            as DateTime?));
        }

        // ---- 5. governance requests ----
        var requests = new List<TaskGovernanceRequestRow>();
        if (await reader.NextResultAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
                requests.Add(new TaskGovernanceRequestRow(
                    ExceptionRequestId: Convert.ToInt64(reader["ExceptionRequestId"]),
                    RequestTypeCode:    reader["RequestTypeCode"]?.ToString() ?? "",
                    RequestTitle:       reader["RequestTitle"]?.ToString() ?? "",
                    RequestReason:      reader["RequestReason"]    as string,
                    StatusCode:         reader["StatusCode"]?.ToString() ?? "",
                    PriorityOriginal:   reader["PriorityOriginal"]  as string,
                    PriorityRequested:  reader["PriorityRequested"] as string,
                    DueAtOriginal:      reader["DueAtOriginal"]     as DateTime?,
                    DueAtRequested:     reader["DueAtRequested"]    as DateTime?,
                    RequestedOn:        reader["RequestedOn"]       as DateTime?,
                    RequestedByName:    reader["RequestedByName"]   as string,
                    ApprovedOn:         reader["ApprovedOn"]        as DateTime?,
                    ApprovedByName:     reader["ApprovedByName"]    as string,
                    RejectedOn:         reader["RejectedOn"]        as DateTime?,
                    RejectedByName:     reader["RejectedByName"]    as string,
                    RejectionReason:    reader["RejectionReason"]   as string));
        }

        return new TaskDetailResult(header, activity, attachments, children, requests);
    }

    public async Task<TaskCommandResult> ChangePriorityAsync(TaskPriorityChangeRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (string.IsNullOrWhiteSpace(request.NewPriority)) return Fail("NewPriority is required.");

        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_priority_change";

            AddParam(command, "@task_id",           DbType.Int64,  request.TaskId);
            AddParam(command, "@new_priority",      DbType.String, request.NewPriority, 30);
            AddParam(command, "@reason",            DbType.String, (object?)request.Reason ?? DBNull.Value, -1);
            AddParam(command, "@actor_employee_id", DbType.Int64,  (object?)request.ActorEmployeeId ?? DBNull.Value);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
                return new TaskCommandResult(true, request.TaskId);

            var cols = ColumnSet(reader);
            return new TaskCommandResult(
                Success:            true,
                TaskId:             request.TaskId,
                ExceptionRequestId: GetLong(reader, cols, "ExceptionRequestId"),
                StatusCode:         GetString(reader, cols, "StatusCode"));
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(ChangePriorityAsync));
        }
    }

    public async Task<TaskCommandResult> RequestSlaExtensionAsync(TaskSlaExtensionRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (string.IsNullOrWhiteSpace(request.ExtensionReason)) return Fail("ExtensionReason is required.");

        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_sla_extension_request_create";

            AddParam(command, "@task_id",                  DbType.Int64,     request.TaskId);
            AddParam(command, "@requested_due_at",         DbType.DateTime2, request.RequestedDueAt);
            AddParam(command, "@extension_reason",         DbType.String,    request.ExtensionReason, -1);
            AddParam(command, "@requested_by_employee_id", DbType.Int64,     request.RequestedByEmployeeId);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
                return new TaskCommandResult(true, request.TaskId);

            var cols = ColumnSet(reader);
            return new TaskCommandResult(
                Success:            true,
                TaskId:             request.TaskId,
                ExceptionRequestId: GetLong(reader, cols, "ExceptionRequestId"),
                StatusCode:         GetString(reader, cols, "StatusCode"));
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(RequestSlaExtensionAsync));
        }
    }

    public Task<TaskCommandResult> ApproveSlaExtensionAsync(TaskGovernanceApproveRequest request, CancellationToken cancellationToken)
        => ApproveGovernanceAsync("grac_practice.sp_task_sla_extension_approve", request, nameof(ApproveSlaExtensionAsync), cancellationToken);

    public Task<TaskCommandResult> ApprovePriorityReductionAsync(TaskGovernanceApproveRequest request, CancellationToken cancellationToken)
        => ApproveGovernanceAsync("grac_practice.sp_task_priority_reduction_approve", request, nameof(ApprovePriorityReductionAsync), cancellationToken);

    /// <summary>
    /// Both approval procs share an identical contract — one input pair,
    /// one summary row — so they share one implementation rather than two
    /// near-identical copies.
    /// </summary>
    private async Task<TaskCommandResult> ApproveGovernanceAsync(
        string procName, TaskGovernanceApproveRequest request, string op, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = procName;

            AddParam(command, "@exception_request_id",    DbType.Int64, request.ExceptionRequestId);
            AddParam(command, "@approved_by_employee_id", DbType.Int64, request.ApprovedByEmployeeId);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
                return new TaskCommandResult(true, null, null, null, request.ExceptionRequestId, "Approved");

            var cols = ColumnSet(reader);
            return new TaskCommandResult(
                Success:            true,
                TaskId:             GetLong(reader, cols, "TaskId"),
                ExceptionRequestId: GetLong(reader, cols, "ExceptionRequestId"),
                StatusCode:         GetString(reader, cols, "StatusCode"));
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, op);
        }
    }

    public async Task<TaskCommandResult> CreateChildAsync(TaskChildCreateRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (string.IsNullOrWhiteSpace(request.SubjectTitle)) return Fail("SubjectTitle is required.");

        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_child_create";

            AddParam(command, "@parent_task_id",          DbType.Int64,     request.ParentTaskId);
            AddParam(command, "@subject_title",           DbType.String,    request.SubjectTitle, 250);
            AddParam(command, "@subject_description",     DbType.String,    (object?)request.SubjectDescription ?? DBNull.Value, -1);
            AddParam(command, "@assigned_to_employee_id", DbType.Int64,     (object?)request.AssignedToEmployeeId ?? DBNull.Value);
            AddParam(command, "@is_mandatory",            DbType.Boolean,   request.IsMandatory ?? true);
            AddParam(command, "@child_target_date",       DbType.DateTime2, (object?)request.ChildTargetDate ?? DBNull.Value);
            AddParam(command, "@actor_employee_id",       DbType.Int64,     (object?)request.ActorEmployeeId ?? DBNull.Value);

            var childIdParam = command.CreateParameter();
            childIdParam.ParameterName = "@child_task_id";
            childIdParam.DbType        = DbType.Int64;
            childIdParam.Direction     = ParameterDirection.Output;
            command.Parameters.Add(childIdParam);

            // The proc returns a summary row AND sets the OUTPUT param;
            // the reader must be fully consumed before OUTPUT values are
            // populated by SqlClient.
            await using (var reader = await command.ExecuteReaderAsync(cancellationToken))
            {
                while (await reader.ReadAsync(cancellationToken)) { }
                while (await reader.NextResultAsync(cancellationToken)) { }
            }

            var childId = childIdParam.Value is long l ? l
                        : childIdParam.Value == DBNull.Value ? (long?)null
                        : Convert.ToInt64(childIdParam.Value);

            return new TaskCommandResult(true, childId, null, null, null, "Created");
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(CreateChildAsync));
        }
    }

    public async Task<TaskCommandResult> CompleteAsync(TaskCompleteRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_complete";

            AddParam(command, "@task_id",           DbType.Int64,  request.TaskId);
            AddParam(command, "@completion_remark", DbType.String, (object?)request.CompletionRemark ?? DBNull.Value, -1);
            AddParam(command, "@actor_employee_id", DbType.Int64,  (object?)request.ActorEmployeeId ?? DBNull.Value);
            AddParam(command, "@actor_role_code",   DbType.String, (object?)request.ActorRoleCode ?? DBNull.Value, 60);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
                return new TaskCommandResult(true, request.TaskId, null, null, null, "Completed");

            var cols = ColumnSet(reader);
            return new TaskCommandResult(
                Success:    true,
                TaskId:     request.TaskId,
                StatusCode: GetString(reader, cols, "StatusCode"));
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(CompleteAsync));
        }
    }

    public async Task<TaskCompletionEligibility?> CompletionEligibilityAsync(long taskId, CancellationToken cancellationToken)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_task_completion_eligibility";
        AddParam(command, "@task_id", DbType.Int64, taskId);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken)) return null;

        return new TaskCompletionEligibility(
            TaskId:                       Convert.ToInt64(reader["TaskId"]),
            IsEligible:                   Convert.ToBoolean(reader["IsEligible"]),
            Reason:                       reader["Reason"]?.ToString() ?? "",
            ChildCount:                   Convert.ToInt32(reader["ChildCount"]),
            MandatoryChildCount:          Convert.ToInt32(reader["MandatoryChildCount"]),
            MandatoryChildCompletedCount: Convert.ToInt32(reader["MandatoryChildCompletedCount"]),
            MandatoryChildOpenCount:      Convert.ToInt32(reader["MandatoryChildOpenCount"]));
    }

    public async Task<TaskCommandResult> AddActivityAsync(TaskActivityAddRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (string.IsNullOrWhiteSpace(request.ActivityTypeCode)) return Fail("ActivityTypeCode is required.");

        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_activity_add";

            AddParam(command, "@task_id",            DbType.Int64,  request.TaskId);
            AddParam(command, "@activity_type_code", DbType.String, request.ActivityTypeCode, 40);
            AddParam(command, "@remark",             DbType.String, (object?)request.Remark ?? DBNull.Value, -1);
            AddParam(command, "@from_value",         DbType.String, (object?)request.FromValue ?? DBNull.Value, 400);
            AddParam(command, "@to_value",           DbType.String, (object?)request.ToValue ?? DBNull.Value, 400);
            AddParam(command, "@actor_employee_id",  DbType.Int64,  (object?)request.ActorEmployeeId ?? DBNull.Value);

            await command.ExecuteNonQueryAsync(cancellationToken);
            return new TaskCommandResult(true, request.TaskId);
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(AddActivityAsync));
        }
    }

    public async Task<TaskOwnerResolveResult> ResolveOwnerAsync(TaskOwnerResolveQuery query, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(query);

        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_task_owner_resolve";

        AddParam(command, "@organization_id",            DbType.Int64,  query.OrganizationId);
        AddParam(command, "@source_type_code",           DbType.String, (object?)query.SourceTypeCode ?? DBNull.Value, 40);
        AddParam(command, "@source_record_id",           DbType.Int64,  (object?)query.SourceRecordId ?? DBNull.Value);
        AddParam(command, "@linked_practice_id",         DbType.Int64,  (object?)query.LinkedPracticeId ?? DBNull.Value);
        AddParam(command, "@linked_control_id",          DbType.Int64,  (object?)query.LinkedControlId ?? DBNull.Value);
        AddParam(command, "@linked_instance_id",         DbType.Int64,  (object?)query.LinkedInstanceId ?? DBNull.Value);
        AddParam(command, "@explicit_owner_employee_id", DbType.Int64,  (object?)query.ExplicitOwnerEmployeeId ?? DBNull.Value);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
            return new TaskOwnerResolveResult(null, null, "MANUAL", "Manual assignment required");

        return new TaskOwnerResolveResult(
            OwnerEmployeeId:   reader["OwnerEmployeeId"]   as long?,
            OwnerEmployeeName: reader["OwnerEmployeeName"] as string,
            OwnerSourceCode:   reader["OwnerSourceCode"]?.ToString() ?? "MANUAL",
            OwnerSourceName:   reader["OwnerSourceName"]?.ToString() ?? "Manual assignment required");
    }

    public async Task<IReadOnlyList<TaskSourceTaskRow>> SourceTasksAsync(
        string sourceTypeCode, long sourceRecordId, long? organizationId, CancellationToken cancellationToken)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_task_source_tasks";

        AddParam(command, "@source_type_code", DbType.String, sourceTypeCode, 40);
        AddParam(command, "@source_record_id", DbType.Int64,  sourceRecordId);
        AddParam(command, "@organization_id",  DbType.Int64,  (object?)organizationId ?? DBNull.Value);

        var rows = new List<TaskSourceTaskRow>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
            rows.Add(new TaskSourceTaskRow(
                TaskId:                 Convert.ToInt64(reader["TaskId"]),
                TaskNumber:             reader["TaskNumber"]             as string,
                SubjectTitle:           reader["SubjectTitle"]?.ToString() ?? "",
                TaskTypeCode:           reader["TaskTypeCode"]?.ToString() ?? "",
                TaskTypeName:           reader["TaskTypeName"]?.ToString() ?? "",
                AssignedToEmployeeId:   reader["AssignedToEmployeeId"]   as long?,
                AssignedToEmployeeName: reader["AssignedToEmployeeName"] as string,
                Priority:               reader["Priority"]?.ToString() ?? "Medium",
                StandardDueAt:          reader["StandardDueAt"]          as DateTime?,
                ApprovedExtendedDueAt:  reader["ApprovedExtendedDueAt"]  as DateTime?,
                SlaDueAt:               reader["SlaDueAt"]               as DateTime?,
                SlaStatusCode:          reader["SlaStatusCode"]          as string,
                CurrentStatusCode:      reader["CurrentStatusCode"]?.ToString() ?? "",
                CurrentStatusName:      reader["CurrentStatusName"]?.ToString() ?? "",
                IsChild:                Convert.ToBoolean(reader["IsChild"]),
                ParentTaskId:           reader["ParentTaskId"]           as long?,
                ChildCount:             Convert.ToInt32(reader["ChildCount"]),
                ClosedAt:               reader["ClosedAt"]               as DateTime?,
                CompletedDt:            reader["CompletedDt"]            as DateTime?));

        return rows;
    }

    public async Task<TaskCommandResult> AddAttachmentAsync(
        long taskId, string fileName, string? contentType, byte[] fileData,
        string? evidenceDescription, long? uploadedByEmployeeId, bool callerIsAdmin, long? instanceEvidenceId,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(fileName)) return Fail("fileName is required.");
        if (fileData is null || fileData.Length == 0) return Fail("File content is empty.");

        try
        {
            // 477: the file becomes an Evidence Center item, or links the
            // identical one the uploader can already see -- "can see" reads
            // the View Data Scope policy, so this POST runs as a read.
            Infrastructure.CallerViewScope.BeginRead(uploadedByEmployeeId);

            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_attachment_add";

            AddParam(command, "@task_id",                 DbType.Int64,  taskId);
            AddParam(command, "@file_name",               DbType.String, fileName, 500);
            AddParam(command, "@content_type",            DbType.String, (object?)contentType ?? DBNull.Value, 200);
            AddParam(command, "@file_data",               DbType.Binary, fileData, -1);
            AddParam(command, "@evidence_description",    DbType.String, (object?)evidenceDescription ?? DBNull.Value, 1000);
            AddParam(command, "@uploaded_by_employee_id", DbType.Int64,  (object?)uploadedByEmployeeId ?? DBNull.Value);
            // 477. Bound only when declared, so a database without 477
            // still attaches (the 193 way).
            if (await Infrastructure.ProcParameterProbe.HasParameterAsync(
                    connection, "sp_task_attachment_add", "@caller_is_admin", cancellationToken))
                AddParam(command, "@caller_is_admin", DbType.Boolean, callerIsAdmin);
            // 482: the recurring evidence row this file answers. Same rule.
            if (instanceEvidenceId is > 0
                && await Infrastructure.ProcParameterProbe.HasParameterAsync(
                       connection, "sp_task_attachment_add", "@instance_evidence_id", cancellationToken))
                AddParam(command, "@instance_evidence_id", DbType.Int64, instanceEvidenceId);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
                return new TaskCommandResult(true, taskId);

            var cols = ColumnSet(reader);
            return new TaskCommandResult(
                Success:    true,
                TaskId:     GetLong(reader, cols, "TaskAttachmentId"),
                StatusCode: "Uploaded",
                Message:    GetString(reader, cols, "Message"));
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(AddAttachmentAsync));
        }
    }

    public async Task<TaskAttachmentContent?> GetAttachmentAsync(long taskAttachmentId, CancellationToken cancellationToken)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command    = connection.CreateCommand();
        command.CommandType = CommandType.StoredProcedure;
        command.CommandText = "grac_practice.sp_task_attachment_get";
        AddParam(command, "@task_attachment_id", DbType.Int64, taskAttachmentId);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken)) return null;

        return new TaskAttachmentContent(
            TaskAttachmentId: Convert.ToInt64(reader["TaskAttachmentId"]),
            TaskId:           Convert.ToInt64(reader["TaskId"]),
            FileName:         reader["FileName"]?.ToString() ?? "download",
            ContentType:      reader["ContentType"] as string,
            FileSizeBytes:    Convert.ToInt64(reader["FileSizeBytes"]),
            FileData:         (byte[])reader["FileData"]);
    }

    // -----------------------------------------------------------------
    // 477: Select from Evidence Center on a task. The procedures check
    // the task (this organisation, still open), the item (visible to the
    // caller, active) and that its validity covers the task's period.
    // -----------------------------------------------------------------
    public async Task<TaskEvidenceCandidateResult> ListEvidenceCandidatesAsync(
        long taskId, long organizationId, long? callerEmployeeId, bool callerIsAdmin,
        string? search, int? evidenceTypeId, int pageNumber, int pageSize, CancellationToken cancellationToken)
    {
        if (taskId <= 0 || organizationId <= 0)
            return new TaskEvidenceCandidateResult(false, [], 0, "Organization and task are both required.");
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_evidence_candidates";
            AddParam(command, "@task_id",            DbType.Int64,   taskId);
            AddParam(command, "@organization_id",    DbType.Int64,   organizationId);
            AddParam(command, "@caller_employee_id", DbType.Int64,   callerEmployeeId is > 0 ? callerEmployeeId : DBNull.Value);
            AddParam(command, "@caller_is_admin",    DbType.Boolean, callerIsAdmin);
            AddParam(command, "@search",             DbType.String,  string.IsNullOrWhiteSpace(search) ? DBNull.Value : search.Trim(), 200);
            AddParam(command, "@evidence_type_id",   DbType.Int32,   evidenceTypeId is > 0 ? evidenceTypeId : DBNull.Value);
            AddParam(command, "@page_number",        DbType.Int32,   pageNumber);
            AddParam(command, "@page_size",          DbType.Int32,   pageSize);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            var rows = await ReadRowsAsync(reader, cancellationToken);
            var total = rows.Count > 0 && rows[0]["TotalRows"] is { } t ? Convert.ToInt32(t) : 0;
            return new TaskEvidenceCandidateResult(true, rows, total);
        }
        catch (SqlException ex) when (ex.Number == 2812)
        {
            logger.LogWarning(ex, "sp_task_evidence_candidates is not installed (run 477).");
            return new TaskEvidenceCandidateResult(false, [], 0, "The Evidence Center is not installed for tasks yet (database migration 477).");
        }
        catch (SqlException ex) when (ex.Number is >= 51000 and <= 52999)
        {
            return new TaskEvidenceCandidateResult(false, [], 0, ex.Message);
        }
    }

    public async Task<TaskCommandResult> LinkEvidenceAsync(
        long taskId, TaskEvidenceLinkRequest request, long? callerEmployeeId, bool callerIsAdmin,
        string callerDisplayName, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (taskId <= 0 || request.OrganizationId <= 0 || request.EvidenceItemId <= 0)
            return new TaskCommandResult(false, null, "Organization, task and evidence item are all required.", "VALIDATION_ERROR");
        try
        {
            // Visibility of the item is part of the rule (see AddAttachmentAsync).
            Infrastructure.CallerViewScope.BeginRead(callerEmployeeId);

            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_evidence_link_add";
            AddParam(command, "@task_id",             DbType.Int64,   taskId);
            AddParam(command, "@organization_id",     DbType.Int64,   request.OrganizationId);
            AddParam(command, "@evidence_item_id",    DbType.Int64,   request.EvidenceItemId);
            AddParam(command, "@link_note",           DbType.String,  string.IsNullOrWhiteSpace(request.LinkNote) ? DBNull.Value : request.LinkNote.Trim(), 1000);
            AddParam(command, "@caller_employee_id",  DbType.Int64,   callerEmployeeId is > 0 ? callerEmployeeId : DBNull.Value);
            AddParam(command, "@caller_is_admin",     DbType.Boolean, callerIsAdmin);
            AddParam(command, "@caller_display_name", DbType.String,  callerDisplayName, 100);
            // 482: the recurring evidence row this item answers.
            if (request.InstanceEvidenceId is > 0
                && await Infrastructure.ProcParameterProbe.HasParameterAsync(
                       connection, "sp_task_evidence_link_add", "@instance_evidence_id", cancellationToken))
                AddParam(command, "@instance_evidence_id", DbType.Int64, request.InstanceEvidenceId);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
                return new TaskCommandResult(true, taskId, StatusCode: "Linked");
            var cols = ColumnSet(reader);
            return new TaskCommandResult(
                Success:    true,
                TaskId:     GetLong(reader, cols, "TaskAttachmentId"),
                StatusCode: "Linked",
                Message:    GetString(reader, cols, "Message"));
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(LinkEvidenceAsync));
        }
    }

    // -----------------------------------------------------------------
    // 482: recurring evidence on Complete Task. The list is the recurring
    // evidence of the scheduled task's obligation (empty for any other
    // task); the save records the option chosen per row and, for
    // External, the location and locator. Nothing is required.
    // -----------------------------------------------------------------
    public async Task<TaskRecurringEvidenceResult> ListRecurringEvidenceAsync(
        long taskId, long organizationId, CancellationToken cancellationToken)
    {
        if (taskId <= 0 || organizationId <= 0)
            return new TaskRecurringEvidenceResult(false, [], "Organization and task are both required.");
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_recurring_evidence_list";
            AddParam(command, "@task_id",         DbType.Int64, taskId);
            AddParam(command, "@organization_id", DbType.Int64, organizationId);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            var rows = await ReadRowsAsync(reader, cancellationToken);
            // 483: result 2, the general row -- absent before 483.
            Dictionary<string, object?>? general = null;
            if (await reader.NextResultAsync(cancellationToken))
                general = (await ReadRowsAsync(reader, cancellationToken)).FirstOrDefault();
            return new TaskRecurringEvidenceResult(true, rows, General: general);
        }
        catch (SqlException ex) when (ex.Number == 2812)
        {
            // A database without 482: the dialog simply lists nothing.
            logger.LogWarning(ex, "sp_task_recurring_evidence_list is not installed (run 482).");
            return new TaskRecurringEvidenceResult(true, []);
        }
        catch (SqlException ex) when (ex.Number is >= 51000 and <= 52999)
        {
            return new TaskRecurringEvidenceResult(false, [], ex.Message);
        }
    }

    public async Task<TaskCommandResult> SaveRecurringEvidenceAsync(
        long taskId, TaskRecurringEvidenceSaveRequest request, long? callerEmployeeId,
        string callerDisplayName, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (taskId <= 0 || request.OrganizationId <= 0)
            return new TaskCommandResult(false, null, "Organization and task are both required.", "VALIDATION_ERROR");
        var items = request.Items ?? [];
        if (items.Count == 0)
            return new TaskCommandResult(true, taskId, StatusCode: "Saved", Message: "Nothing to save.");
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_evidence_response_save";
            var payload = System.Text.Json.JsonSerializer.Serialize(items.Select(i => new
            {
                evidenceId       = i.EvidenceId,
                evidenceSource   = i.EvidenceSource,
                evidenceLocation = i.EvidenceLocation,
                evidenceLocator  = i.EvidenceLocator
            }));
            AddParam(command, "@task_id",             DbType.Int64,  taskId);
            AddParam(command, "@organization_id",     DbType.Int64,  request.OrganizationId);
            AddParam(command, "@payload_json",        DbType.String, payload, -1);
            AddParam(command, "@caller_employee_id",  DbType.Int64,  callerEmployeeId is > 0 ? callerEmployeeId : DBNull.Value);
            AddParam(command, "@caller_display_name", DbType.String, callerDisplayName, 100);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
                return new TaskCommandResult(true, taskId, StatusCode: "Saved");
            var cols = ColumnSet(reader);
            return new TaskCommandResult(true, taskId, StatusCode: "Saved", Message: GetString(reader, cols, "Message"));
        }
        catch (SqlException ex)
        {
            return HandleSqlError(ex, nameof(SaveRecurringEvidenceAsync));
        }
    }

    // Column-name rows (477 candidates, 482 recurring evidence).
    private static async Task<List<Dictionary<string, object?>>> ReadRowsAsync(
        DbDataReader reader, CancellationToken cancellationToken)
    {
        var rows = new List<Dictionary<string, object?>>();
        while (await reader.ReadAsync(cancellationToken))
        {
            var row = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < reader.FieldCount; i++)
                row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
            rows.Add(row);
        }
        return rows;
    }

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------
    private async Task<DbConnection> OpenAsync(CancellationToken cancellationToken)
    {
        var connString = Infrastructure.SqlConnectionStringResolver.Resolve(configuration);
        if (string.IsNullOrWhiteSpace(connString))
            throw new InvalidOperationException("PracticeManagement connection string is not configured.");

        var connection = new SqlConnection(connString);
        await connection.OpenAsync(cancellationToken);
        await Infrastructure.ViewScopeSession.ApplyAsync(connection, cancellationToken);   // 415: View Data Scope
        return connection;
    }

    private static void AddParam(DbCommand command, string name, DbType type, object? value, int? size = null)
    {
        var p = command.CreateParameter();
        p.ParameterName = name;
        p.DbType = type;
        if (size.HasValue) p.Size = size.Value;
        p.Value = value ?? DBNull.Value;
        command.Parameters.Add(p);
    }

    /// <summary>
    /// Lets the Api tier stay deployable against a database that has not
    /// yet received a migration: v2 parameters are only bound when the
    /// procedure actually declares them. Cheap metadata query, and the
    /// alternative (a hard failure on "too many arguments specified") is
    /// far worse operationally.
    /// </summary>
    /// <remarks>
    /// The implementation moved to
    /// <see cref="Infrastructure.ProcParameterProbe"/> when RiskCentreService
    /// needed the same probe — one rule, one implementation. This wrapper
    /// stays so the call sites in this file read unchanged.
    /// </remarks>
    private static Task<bool> ProcHasParameterAsync(
        DbConnection connection, string procName, string parameterName, CancellationToken cancellationToken)
        => Infrastructure.ProcParameterProbe.HasParameterAsync(
               connection, procName, parameterName, cancellationToken);

    /// <summary>Best-effort activity note. Never throws — the governing
    /// action has already committed by the time this runs.</summary>
    private async Task TryLogActivityAsync(
        DbConnection connection, long taskId, string activityTypeCode,
        string? remark, string? fromValue, string? toValue,
        long? actorEmployeeId, CancellationToken cancellationToken)
    {
        try
        {
            await using var cmd = connection.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "grac_practice.sp_task_activity_add";
            AddParam(cmd, "@task_id",            DbType.Int64,  taskId);
            AddParam(cmd, "@activity_type_code", DbType.String, activityTypeCode, 40);
            AddParam(cmd, "@remark",             DbType.String, (object?)remark ?? DBNull.Value, -1);
            AddParam(cmd, "@from_value",         DbType.String, (object?)fromValue ?? DBNull.Value, 400);
            AddParam(cmd, "@to_value",           DbType.String, (object?)toValue ?? DBNull.Value, 400);
            AddParam(cmd, "@actor_employee_id",  DbType.Int64,  (object?)actorEmployeeId ?? DBNull.Value);
            await cmd.ExecuteNonQueryAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            logger.LogDebug(ex, "TaskService: activity log skipped for task {TaskId} ({Type}).", taskId, activityTypeCode);
        }
    }

    /// <summary>
    /// BRD §6: a manual reassignment supersedes whatever rung of the
    /// ownership ladder originally proposed the owner, so the provenance
    /// stamp becomes REASSIGNED. Best-effort for the same reason as
    /// TryLogActivityAsync.
    /// </summary>
    private async Task TryStampOwnerSourceAsync(DbConnection connection, long taskId, CancellationToken cancellationToken)
    {
        try
        {
            await using var cmd = connection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = @"
                IF COL_LENGTH('grac_practice.practice_task','owner_source_code') IS NOT NULL
                    UPDATE grac_practice.practice_task
                       SET owner_source_code = N'REASSIGNED'
                     WHERE task_id = @task_id;";
            AddParam(cmd, "@task_id", DbType.Int64, taskId);
            await cmd.ExecuteNonQueryAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            logger.LogDebug(ex, "TaskService: owner_source stamp skipped for task {TaskId}.", taskId);
        }
    }

    // ---- column-tolerant readers ------------------------------------
    private static HashSet<string> ColumnSet(DbDataReader reader)
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (var i = 0; i < reader.FieldCount; i++) set.Add(reader.GetName(i));
        return set;
    }

    private static object? Raw(DbDataReader r, HashSet<string> cols, string name)
    {
        if (!cols.Contains(name)) return null;
        var v = r[name];
        return v == DBNull.Value ? null : v;
    }

    private static string?   GetString(DbDataReader r, HashSet<string> c, string n) => Raw(r, c, n)?.ToString();
    private static long?     GetLong  (DbDataReader r, HashSet<string> c, string n) => Raw(r, c, n) is { } v ? Convert.ToInt64(v)   : null;
    private static int?      GetInt   (DbDataReader r, HashSet<string> c, string n) => Raw(r, c, n) is { } v ? Convert.ToInt32(v)   : null;
    private static bool      GetBool  (DbDataReader r, HashSet<string> c, string n) => Raw(r, c, n) is { } v && Convert.ToBoolean(v);
    private static bool?     GetBoolN (DbDataReader r, HashSet<string> c, string n) => Raw(r, c, n) is { } v ? Convert.ToBoolean(v) : null;
    private static DateTime? GetDate  (DbDataReader r, HashSet<string> c, string n) => Raw(r, c, n) is { } v ? Convert.ToDateTime(v): null;

    private static TaskListRow MapRow(DbDataReader reader, HashSet<string> c) => new(
        // ---- original columns (always present) ----
        TaskId:                     Convert.ToInt64(reader["task_id"]),
        OrganizationId:             Convert.ToInt64(reader["organization_id"]),
        TaskTypeCode:               reader["task_type_code"]?.ToString() ?? "",
        TaskTypeName:               reader["task_type_name"]?.ToString() ?? "",
        SubjectEntityType:          reader["subject_entity_type"]?.ToString() ?? "",
        SubjectEntityId:            Convert.ToInt64(reader["subject_entity_id"]),
        LinkedReleaseId:            reader["linked_release_id"]  as long?,
        LinkedControlId:            reader["linked_control_id"]  as long?,
        LinkedPracticeId:           reader["linked_practice_id"] as long?,
        LinkedInstanceId:           reader["linked_instance_id"] as long?,
        SubjectTitle:               reader["subject_title"]?.ToString() ?? "",
        SubjectDescription:         reader["subject_description"] as string,
        AssignedToEmployeeId:       reader["assigned_to_employee_id"] as long?,
        CurrentStatusCode:          reader["current_status_code"]?.ToString() ?? "",
        CurrentStatusName:          reader["current_status_name"]?.ToString() ?? "",
        CurrentStatusIsTerminal:    Convert.ToBoolean(reader["current_status_is_terminal"]),
        Priority:                   reader["priority"]?.ToString() ?? "Medium",
        Criticality:                reader["criticality"] as string,
        OriginCode:                 reader["origin_code"]  as string,
        SlaDueAt:                   reader["sla_due_at"]   as DateTime?,
        IsOverdue:                  reader["is_overdue"] is null || reader["is_overdue"] == DBNull.Value ? false : Convert.ToBoolean(reader["is_overdue"]),
        EscalatedAt:                reader["escalated_at"] as DateTime?,
        ReasonCode:                 reader["reason_code"]  as string,
        ReasonText:                 reader["reason_text"]  as string,
        ClosedAt:                   reader["closed_at"]    as DateTime?,

        // ---- v2 columns (present once 192/195 are applied) ----
        TaskNumber:                 GetString(reader, c, "task_number"),
        AssignedToEmployeeName:     GetString(reader, c, "assigned_to_employee_name"),
        OwnerSourceCode:            GetString(reader, c, "owner_source_code"),

        StandardSlaDays:            GetInt   (reader, c, "standard_sla_days"),
        StandardDueAt:              GetDate  (reader, c, "standard_due_at"),
        ApprovedExtendedDueAt:      GetDate  (reader, c, "approved_extended_due_at"),
        SlaSourceCode:              GetString(reader, c, "sla_source_code"),
        SlaMasterName:              GetString(reader, c, "sla_master_name"),
        ExtensionStatusCode:        GetString(reader, c, "extension_status_code"),
        RequestedDueAt:             GetDate  (reader, c, "requested_due_at"),
        ExtensionReason:            GetString(reader, c, "extension_reason"),
        IsExtended:                 GetBool  (reader, c, "is_extended"),

        SlaTimingCode:              GetString(reader, c, "sla_timing_code"),
        SlaStatusCode:              GetString(reader, c, "sla_status_code"),
        DaysToDue:                  GetInt   (reader, c, "days_to_due"),

        RequestedPriority:          GetString(reader, c, "requested_priority"),
        PriorityChangeStatusCode:   GetString(reader, c, "priority_change_status_code"),

        ParentTaskId:               GetLong  (reader, c, "parent_task_id"),
        ParentTaskNumber:           GetString(reader, c, "parent_task_number"),
        ParentTaskTitle:            GetString(reader, c, "parent_task_title"),
        IsChild:                    GetBool  (reader, c, "is_child"),
        IsMandatoryChild:           GetBoolN (reader, c, "is_mandatory_child"),
        ChildTargetDate:            GetDate  (reader, c, "child_target_date"),
        ChildCount:                 GetInt   (reader, c, "child_count") ?? 0,
        MandatoryChildCount:        GetInt   (reader, c, "mandatory_child_count") ?? 0,
        MandatoryChildOpenCount:    GetInt   (reader, c, "mandatory_child_open_count") ?? 0,
        IsEligibleForCompletion:    GetBool  (reader, c, "is_eligible_for_completion"),

        SourceTypeCode:             GetString(reader, c, "source_type_code"),
        SourceRecordId:             GetLong  (reader, c, "source_record_id"),
        SourceReference:            GetString(reader, c, "source_reference"),

        CompletedByEmployeeId:      GetLong  (reader, c, "completed_by_employee_id"),
        CompletedByEmployeeName:    GetString(reader, c, "completed_by_employee_name"),
        CompletedDt:                GetDate  (reader, c, "completed_dt"),

        // ---- Organization / Created-Updated (326) ------------------------
        OrganizationName:           GetString(reader, c, "organization_name"),
        EnteredBy:                  GetString(reader, c, "entered_by"),
        EnteredDt:                  GetDate  (reader, c, "entered_dt"),
        UpdatedBy:                  GetString(reader, c, "updated_by"),
        UpdatedDt:                  GetDate  (reader, c, "updated_dt"));

    private TaskCommandResult HandleSqlError(SqlException ex, string op)
    {
        // Map framework + Task Centre v2 error codes back to reason
        // strings the client can branch on. The HTTP status mapping lives
        // in TaskController.Respond.
        var reason = ex.Number switch
        {
            // state machine / two-gate (037, 035)
            53520 => "ILLEGAL_TRANSITION",
            53521 => "REASON_REQUIRED",
            53752 => "TWO_GATE_NOT_PASSED",

            // task reopen (479)
            53760 => "VALIDATION_ERROR",
            53761 => "TASK_NOT_FOUND",
            53762 => "TASK_NOT_CLOSED",
            53763 => "REOPEN_FORBIDDEN",

            // priority governance (193) — BRD §7
            55619 => "CHILD_PRIORITY_LOCKED",
            55620 => "REASON_REQUIRED",
            55621 => "ACTOR_REQUIRED",
            55622 => "PRIORITY_REQUEST_PENDING",

            // SLA extension (194) — BRD §8
            55656 => "CHILD_SLA_LOCKED",
            55657 => "EXTENSION_PENDING",
            55658 => "EXTENSION_NOT_LATER",

            // parent / child (194) — BRD §11
            55673 => "PARENT_COMPLETED",
            55674 => "CHILD_NESTING_NOT_ALLOWED",

            // completion (194) — BRD §12
            55692 => "ALREADY_COMPLETED",
            55693 => "COMPLETION_BLOCKED",

            // task edit (269). Each one is a distinct thing for the form
            // to say, which is why they are not collapsed into
            // VALIDATION_ERROR: the field-level messages are the point.
            56704 => "TASK_CLOSED",
            56705 => "CONCURRENT_EDIT",
            56706 => "OWNER_NOT_IN_ORGANIZATION",
            56707 => "CLOSE_VIA_EDIT_REFUSED",
            56708 => "ILLEGAL_TRANSITION",
            56710 => "REASON_REQUIRED",
            56711 => "REASON_REQUIRED",
            56712 => "ACTOR_REQUIRED",

            // everything else in the Task Centre v2 ranges is a
            // validation failure rather than a server fault
            >= 55600 and <= 55799 => "VALIDATION_ERROR",
            >= 56700 and <= 56719 => "VALIDATION_ERROR",
            // 476 / 477: Evidence Center sentences (link to a task).
            >= 52780 and <= 52869 => "VALIDATION_ERROR",
            // 482: recurring evidence on a task.
            >= 52920 and <= 52929 => "VALIDATION_ERROR",

            _     => "SQL_ERROR"
        };
        logger.LogWarning(ex, "TaskService.{Op} failed with SQL error {Number}: {Message}", op, ex.Number, ex.Message);
        return new TaskCommandResult(false, null, ex.Message, reason);
    }

    private static TaskCommandResult Fail(string error) => new(false, null, error);

    // =================================================================
    // Task edit — migration 269
    //
    // ONE update path. Before this, changing status + owner + priority
    // was three endpoints, three round trips and three audit shapes; the
    // UI drove them from three separate 3-dot actions.
    //
    // These two methods add no rules of their own. sp_task_update
    // composes sp_task_assign / sp_task_transition /
    // sp_task_priority_change / sp_task_sla_extension_request_create, so
    // every §7 and §8 rule is enforced exactly once, in the procedure
    // that already owned it. Duplicating any of that here would create
    // the second copy this work exists to remove.
    // =================================================================

    /// <summary>
    /// What the editor may offer for this task, including the status
    /// transitions that are legal right now. One round trip, so the form
    /// can be built without guessing and without a second call.
    /// </summary>
    public async Task<TaskEditOptions?> GetEditOptionsAsync(long taskId, CancellationToken cancellationToken)
    {
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_edit_options";
            AddParam(command, "@task_id", DbType.Int64, taskId);

            await using var reader = await command.ExecuteReaderAsync(cancellationToken);

            if (!await reader.ReadAsync(cancellationToken)) return null;

            var c = ColumnSet(reader);
            var header = new
            {
                CurrentStatusCode     = GetString(reader, c, "CurrentStatusCode"),
                TaskTypeCode          = GetString(reader, c, "TaskTypeCode"),
                CurrentPriority       = GetString(reader, c, "CurrentPriority"),
                IsChild               = GetBool(reader, c, "IsChild"),
                IsTerminal            = GetBool(reader, c, "IsTerminal"),
                CanEdit               = GetBool(reader, c, "CanEdit"),
                CanEditPriority       = GetBool(reader, c, "CanEditPriority"),
                CanEditDueDate        = GetBool(reader, c, "CanEditDueDate"),
                PriorityChangePending = GetBool(reader, c, "PriorityChangePending"),
                SlaExtensionPending   = GetBool(reader, c, "SlaExtensionPending"),
                CanEditMandatory      = GetBool(reader, c, "CanEditMandatory"),
                // Read defensively: an older 269 without these columns
                // still yields a working editor, just without prefill and
                // without the concurrency check.
                StartDate             = GetDate(reader, c, "StartDate"),
                IsMandatoryChild      = GetBoolN(reader, c, "IsMandatoryChild"),
                ChildTargetDate       = GetDate(reader, c, "ChildTargetDate"),
                UpdatedDt             = GetDate(reader, c, "UpdatedDt")
            };

            // Second result set: the legal transitions.
            var statuses = new List<TaskStatusOption>();
            if (await reader.NextResultAsync(cancellationToken))
            {
                var sc = ColumnSet(reader);
                while (await reader.ReadAsync(cancellationToken))
                {
                    var code = GetString(reader, sc, "StatusCode");
                    if (string.IsNullOrWhiteSpace(code)) continue;
                    statuses.Add(new TaskStatusOption(code, GetString(reader, sc, "StatusName") ?? code));
                }
            }

            return new TaskEditOptions(
                taskId,
                header.CurrentStatusCode,
                header.TaskTypeCode,
                header.CurrentPriority,
                header.IsChild,
                header.IsTerminal,
                header.CanEdit,
                header.CanEditPriority,
                header.CanEditDueDate,
                header.PriorityChangePending,
                header.SlaExtensionPending,
                header.CanEditMandatory,
                statuses,
                header.StartDate,
                header.IsMandatoryChild,
                header.ChildTargetDate,
                header.UpdatedDt);
        }
        catch (SqlException ex)
        {
            logger.LogWarning(ex, "TaskService.GetEditOptionsAsync failed for task {TaskId}", taskId);
            return null;
        }
    }

    /// <summary>
    /// Save the whole edit form. Returns one row per field that was
    /// actually different, each saying what happened to it.
    ///
    /// <para>A caller must read <see cref="TaskFieldChange.Outcome"/>
    /// before telling the user anything: <c>PendingApproval</c> means a
    /// request was raised and <b>the task did not change</b>.</para>
    /// </summary>
    public async Task<TaskUpdateResult> UpdateAsync(TaskUpdateRequest request, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(request);
        try
        {
            await using var connection = await OpenAsync(cancellationToken);
            await using var command    = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "grac_practice.sp_task_update";

            // NULL means "leave alone", so every optional field is sent
            // as DBNull rather than as a default. An empty string is NOT
            // collapsed to NULL for the description: clearing a
            // description is a real edit, and "" is how the form says so.
            AddParam(command, "@task_id",                 DbType.Int64,    request.TaskId);
            AddParam(command, "@subject_title",           DbType.String,   (object?)request.SubjectTitle ?? DBNull.Value, 250);
            AddParam(command, "@subject_description",     DbType.String,   (object?)request.SubjectDescription ?? DBNull.Value, -1);
            AddParam(command, "@assigned_to_employee_id", DbType.Int64,    (object?)request.AssignedToEmployeeId ?? DBNull.Value);
            AddParam(command, "@priority",                DbType.String,   (object?)request.Priority ?? DBNull.Value, 30);
            AddParam(command, "@status_code",             DbType.String,   (object?)request.StatusCode ?? DBNull.Value, 60);
            AddParam(command, "@start_date",              DbType.DateTime2,(object?)request.StartDate ?? DBNull.Value);
            AddParam(command, "@due_at",                  DbType.DateTime2,(object?)request.DueAt ?? DBNull.Value);
            AddParam(command, "@is_mandatory_child",      DbType.Boolean,  (object?)request.IsMandatoryChild ?? DBNull.Value);
            AddParam(command, "@child_target_date",       DbType.DateTime2,(object?)request.ChildTargetDate ?? DBNull.Value);
            AddParam(command, "@change_reason",           DbType.String,   (object?)request.ChangeReason ?? DBNull.Value, -1);
            AddParam(command, "@actor_employee_id",       DbType.Int64,    (object?)request.ActorEmployeeId ?? DBNull.Value);
            AddParam(command, "@actor_role_code",         DbType.String,   (object?)request.ActorRoleCode ?? DBNull.Value, 60);
            AddParam(command, "@caller_display_name",     DbType.String,   "task-center", 100);
            AddParam(command, "@expected_updated_dt",     DbType.DateTime2,(object?)request.ExpectedUpdatedDt ?? DBNull.Value);

            var changes = new List<TaskFieldChange>();
            await using (var reader = await command.ExecuteReaderAsync(cancellationToken))
            {
                var c = ColumnSet(reader);
                while (await reader.ReadAsync(cancellationToken))
                {
                    changes.Add(new TaskFieldChange(
                        GetString(reader, c, "FieldCode")  ?? "",
                        GetString(reader, c, "FieldLabel") ?? "",
                        GetString(reader, c, "FromValue"),
                        GetString(reader, c, "ToValue"),
                        GetString(reader, c, "Outcome")    ?? "Applied",
                        GetString(reader, c, "Detail")));
                }
            }

            // An empty list is a success with nothing to do, not a
            // failure. The caller says "no changes to save" rather than
            // claiming one.
            return new TaskUpdateResult(true, request.TaskId, changes);
        }
        catch (SqlException ex)
        {
            // Reuses the same number -> reason map every other command
            // uses, so the client branches on one vocabulary.
            var mapped = HandleSqlError(ex, nameof(UpdateAsync));
            return new TaskUpdateResult(false, request.TaskId,
                                        Array.Empty<TaskFieldChange>(),
                                        mapped.Error, mapped.ReasonCode);
        }
    }
}
