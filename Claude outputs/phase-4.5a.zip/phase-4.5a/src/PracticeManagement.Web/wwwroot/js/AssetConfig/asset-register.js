// =====================================================================
// Asset Register (migration 428) -- BRD 5 / 5.1.14 / 5.1.16 / 5.2.1.
// Loaded by asset-register.cshtml. The form is built from the asset
// type's form template (sections, fields, rules, option lists); live
// visibility / mandatory comes from the same rule engine the save uses
// (register/evaluate -> fn_asset_form_evaluate). Every rule is enforced by
// sp_asset_register_save; this screen only mirrors it and shows its issues.
// 429: Lifecycle tab -- the configured moves from the asset's status with
// their BRD gates (register/{id}/lifecycle), moves through
// register/{id}/transition, approve / reject / cancel through
// register/lifecycle-changes/{id}/decide, and the whole matrix
// (register/lifecycle-matrix). Gates are enforced by the procedures.
// 430: Technology tab -- register/{id}/technology (status, recommended
// target, classification, installation history, exceptions), installations
// through register/{id}/technology/installations, exception requests through
// register/{id}/technology/exceptions and decisions through
// register/technology-exceptions/{id}/decide.
// 431: Custody tab -- register/{id}/custody (verification state, profile,
// owner / custodian / location history, acknowledgements and attestations).
// 432: the Custody tab also lists the asset's verification exceptions.
// =====================================================================
(() => {
  "use strict";

  const U    = p => String(window.appBasePath || window.pmPathBase || "").replace(/\/+$/, "") + p;
  const base = "/practice/api/asset-config/register";
  const root = document.getElementById("argRoot");
  if (!root) return;
  const CAN_ADD = root.dataset.canAdd === "1";
  const CAN_EDIT = root.dataset.canEdit === "1";
  const CAN_APPROVE = root.dataset.canApprove === "1";

  // BRD 5 lifecycle statuses (seeded by 428 on entity Asset), for the filter.
  const STATUSES = [
    ["DRAFT", "Draft"], ["REQUESTED", "Requested"], ["APPROVED", "Approved"], ["ORDERED", "Ordered"], ["RECEIVED", "Received"],
    ["UNDER_INSPECTION", "Under Inspection"], ["PENDING_INSTALLATION", "Pending Installation"], ["PENDING_COMMISSIONING", "Pending Commissioning"],
    ["ACTIVE", "Active"], ["MAINTENANCE", "Maintenance"], ["REPAIR", "Repair"], ["OUT_OF_SERVICE", "Out of Service"], ["QUARANTINED", "Quarantined"],
    ["STORAGE", "Storage"], ["TRANSFER_PENDING", "Transfer Pending"], ["TRANSFERRED", "Transferred"], ["OWNER_CHANGE_PENDING", "Owner Change Pending"],
    ["LOST", "Lost"], ["STOLEN", "Stolen"], ["RECALLED", "Recalled"], ["OBSOLETE", "Obsolete"], ["NON_COMPLIANT", "Non-Compliant"],
    ["PENDING_DECOMMISSION", "Pending Decommission"], ["SANITIZATION_PENDING", "Sanitization Pending"], ["DISPOSAL_APPROVAL", "Disposal Approval"],
    ["DISPOSED", "Disposed"], ["ARCHIVED", "Archived"]
  ];
  // Data types the user does not enter (420 seed: is_user_entered = 0).
  const SYSTEM_TYPES = new Set(["AUTO", "CALCULATED", "SYSTEM", "DATETIME", "APPROVAL_REF"]);
  // Lookups the register sets from the asset type / organization, not the user.
  const FIXED_SOURCES = new Set(["MASTER:ASSET_CATEGORY", "MASTER:ASSET_SUBCATEGORY", "MASTER:ASSET_TYPE", "MASTER:ORGANIZATION"]);
  // Masters without a table yet: entered as text (428).
  const TEXT_SOURCES = new Set(["MASTER:COUNTRY", "MASTER:CURRENCY"]);
  const MULTI_TYPES = new Set(["MULTI_SELECT", "MULTI_USER"]);

  const state = {
    organizationId: null, pager: null, lookups: {},
    asset: null, history: [], stored: {}, form: null, typeId: null,
    ruleSources: new Set(), evalState: {}, decisions: {}, evalTimer: null,
    lifecycle: null, move: null, tech: null, installKind: null, custody: null
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();

  async function init() {
    state.pager = window.__pmGrid ? window.__pmGrid.attach({ hostId: "argPager", onChange: refreshList }) : null;
    document.getElementById("argStatusFilter").innerHTML = `<option value="">All statuses</option>`
      + STATUSES.map(([c, n]) => `<option value="${c}">${esc(n)}</option>`).join("");
    bind();
    await populateOrgs();
    const sel = document.getElementById("argOrg");
    if (sel.options.length > 1) sel.selectedIndex = 1;
    await changeOrg(Number(sel.value) || null);
  }

  async function populateOrgs() {
    const sel = document.getElementById("argOrg");
    try {
      const r = await fetch(U("/practice/api/organizations/allowed"), { credentials: "same-origin" });
      const b = r.ok ? await r.json() : null;
      ((b && (b.data || b.Data)) || []).forEach(row => {
        const value = String(row.organizationId ?? row.OrganizationId ?? "");
        if (!value) return;
        const o = document.createElement("option");
        o.value = value; o.textContent = String(row.organizationName ?? row.OrganizationName ?? value);
        sel.appendChild(o);
      });
    } catch (_) { /* placeholder stays */ }
    if (sel.options.length === 2) sel.disabled = true;
  }

  function bind() {
    document.getElementById("argOrg").addEventListener("change", e => changeOrg(Number(e.target.value) || null));
    document.getElementById("argRefresh").addEventListener("click", () => refreshList());
    let t = null;
    document.getElementById("argSearch").addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => { state.pager?.reset(true); refreshList(); }, 300); });
    ["argTypeFilter", "argStatusFilter", "argPendingOnly"].forEach(id => document.getElementById(id).addEventListener("change", () => { state.pager?.reset(true); refreshList(); }));
    document.getElementById("argMatrixBtn").addEventListener("click", openMatrix);
    document.querySelectorAll("[data-close-arg]").forEach(b => b.addEventListener("click", () => { document.getElementById(b.dataset.closeArg).hidden = true; }));
    document.getElementById("argMoves").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-arg-move]");
      if (b) openMove(b.dataset.argMove);
    });
    document.getElementById("argPending").addEventListener("click", ev => {
      const b = ev.target.closest("button[data-arg-decide]");
      if (b) decide(Number(b.dataset.argChange), b.dataset.argDecide);
    });
    document.getElementById("argMoveForm").addEventListener("submit", ev => { ev.preventDefault(); submitMove(); });
    document.getElementById("argTechPanel").addEventListener("click", ev => {
      const inst = ev.target.closest("button[data-arg-install]");
      if (inst) { openInstall(inst.dataset.argInstall); return; }
      if (ev.target.closest("button[data-arg-exc-new]")) { openException(); return; }
      const d = ev.target.closest("button[data-arg-exc-decide]");
      if (d) decideException(Number(d.dataset.argExc), d.dataset.argExcDecide);
    });
    document.getElementById("argInstallForm").addEventListener("submit", ev => { ev.preventDefault(); submitInstall(); });
    document.getElementById("argExcForm").addEventListener("submit", ev => { ev.preventDefault(); submitException(); });
    document.getElementById("argExcKind").addEventListener("change", () => fillExceptionReleases());
    document.getElementById("argNewBtn")?.addEventListener("click", () => openNew());
    document.getElementById("argListBody").addEventListener("click", ev => {
      const tr = ev.target.closest("tr[data-arg-id]");
      if (tr) openAsset(Number(tr.dataset.argId));
    });
    document.getElementById("argBack").addEventListener("click", showList);
    document.getElementById("argCat").addEventListener("change", () => fillTypeStep("cat"));
    document.getElementById("argSub").addEventListener("change", () => fillTypeStep("sub"));
    document.getElementById("argTypeGo").addEventListener("click", () => {
      const typeId = Number(val("argType"));
      if (!typeId) { showMessage("Choose the asset type.", "error"); return; }
      loadForm(typeId, null);
    });
    document.getElementById("argSave").addEventListener("click", save);
    document.getElementById("argForm").addEventListener("change", onFieldChange);
    document.getElementById("argIssues").addEventListener("change", ev => {
      const r = ev.target.closest("input[data-arg-decision]");
      if (r) state.decisions[r.dataset.argDecision] = r.value;
    });
    document.querySelectorAll("[data-arg-tab]").forEach(b => b.addEventListener("click", () => selectTab(b.dataset.argTab)));
  }

  function selectTab(name) {
    document.querySelectorAll("[data-arg-tab]").forEach(x => { const on = x.dataset.argTab === name; x.classList.toggle("active", on); x.setAttribute("aria-selected", on ? "true" : "false"); });
    document.querySelectorAll("[data-arg-panel]").forEach(p => { p.hidden = p.dataset.argPanel !== name; });
  }

  async function changeOrg(id) {
    state.organizationId = id;
    state.lookups = {};
    showList();
    if (!id) return;
    await ensureLookups(["MASTER:ASSET_CATEGORY", "MASTER:ASSET_SUBCATEGORY", "MASTER:ASSET_TYPE"]);
    const f = document.getElementById("argTypeFilter");
    f.innerHTML = `<option value="">All asset types</option>` + (state.lookups["MASTER:ASSET_TYPE"] || [])
      .map(t => `<option value="${esc(t.value)}">${esc(t.label)}</option>`).join("");
    state.pager?.reset(true);
    await refreshList();
  }

  // ------------------------------------------------------------------ list
  async function refreshList() {
    const body = document.getElementById("argListBody");
    if (!state.organizationId) { body.innerHTML = empty(8, "Select an organization."); state.pager?.clear(); return; }
    body.innerHTML = empty(8, "Loading...");
    const qs = new URLSearchParams({ organizationId: state.organizationId, pageNumber: state.pager ? state.pager.page() : 1, pageSize: state.pager ? state.pager.size() : 25 });
    if (val("argSearch")) qs.set("search", val("argSearch"));
    if (val("argTypeFilter")) qs.set("assetTypeId", val("argTypeFilter"));
    if (val("argStatusFilter")) qs.set("statusCode", val("argStatusFilter"));
    if (document.getElementById("argPendingOnly").checked) qs.set("pendingOnly", "true");
    const res = await api("GET", `?${qs}`);
    if (!res.ok) { body.innerHTML = empty(8, res.error); state.pager?.clear(); return; }
    const rows = res.data.data.rows || [];
    state.pager?.setTotal(res.data.data.totalRows, rows.length);
    body.innerHTML = rows.map(r => `
      <tr class="pm-row-clickable" data-arg-id="${r.assetId}">
        <td>${esc(r.assetName)}<div class="arg-note">#${esc(r.assetId)}</div></td>
        <td>${esc(r.assetTypeName || "--")}<div class="arg-note">${esc([r.categoryName, r.subcategoryName].filter(Boolean).join(" / "))}</div></td>
        <td>${statusChip(r.statusName, r.phaseName)}${r.pendingChangeId ? `<div class="arg-note">Awaiting approval: ${esc(r.pendingToStatusName)}</div>` : ""}</td>
        <td>${esc(r.ownerName || "--")}</td>
        <td>${esc(r.locationName || "--")}</td>
        <td>${esc(r.criticalityName || "--")}</td>
        <td>${r.templateId ? "v" + esc(r.templateVersion) : `<span class="arg-note">Not on a form</span>`}</td>
        <td>${esc(dateTime(r.lastChanged))}</td>
      </tr>`).join("") || empty(8, "No assets match.");
  }

  function showList() {
    document.getElementById("argAssetView").hidden = true;
    document.getElementById("argListView").hidden = false;
    state.asset = null; state.form = null;
    if (state.organizationId) refreshList();
  }

  // ------------------------------------------------------------------ open
  function resetAssetView(title, meta) {
    document.getElementById("argListView").hidden = true;
    document.getElementById("argAssetView").hidden = false;
    document.getElementById("argTitle").textContent = title;
    document.getElementById("argMeta").innerHTML = meta;
    document.getElementById("argTypeStep").hidden = true;
    document.getElementById("argFormPanel").hidden = true;
    document.getElementById("argSave").hidden = true;
    hideMessage(); renderIssues([]);
    state.decisions = {}; state.evalState = {};
    state.lifecycle = null; state.tech = null;
    document.getElementById("argLifecycleTab").hidden = true;
    document.getElementById("argTechTab").hidden = true;
    document.getElementById("argCustodyTab").hidden = true;
    state.custody = null;
    selectTab("details");
  }

  function openNew() {
    state.asset = null; state.stored = {}; state.history = [];
    resetAssetView("New asset", "");
    fillTypeStep("init");
    document.getElementById("argTypeStep").hidden = false;
  }

  async function openAsset(id) {
    const res = await api("GET", `/${id}?organizationId=${state.organizationId}`);
    if (!res.ok) { showMessage(res.error, "error"); return; }
    const d = res.data.data;
    state.asset = d.asset;
    state.history = d.history || [];
    state.stored = {};
    (d.values || []).forEach(v => { state.stored[v.fieldKey] = v.value; });
    const a = d.asset;
    resetAssetView(a.assetName, `${statusChip(a.statusName, a.phaseName)} <span class="arg-note">#${esc(a.assetId)}</span>`
      + (a.templateId ? ` <span class="arg-note">- form ${esc(a.templateName)} v${esc(a.templateVersion)}`
         + (a.activeTemplateId && a.activeTemplateId !== a.templateId ? ` (v${esc(a.activeTemplateVersion)} is now Active; moving an asset to a newer version needs an approved migration)` : "") + "</span>" : ""));
    renderHistory();
    await loadLifecycle();
    await loadTechnology();
    await loadCustody();
    if (!a.assetTypeId) {
      showMessage("This asset was created before asset types existed. Choose its asset type to open the form.", "info");
      fillTypeStep("init");
      document.getElementById("argTypeStep").hidden = false;
      return;
    }
    await loadForm(a.assetTypeId, a.templateId || null);
  }

  // Category -> subcategory -> asset type, from the taxonomy in effect (424).
  function fillTypeStep(changed) {
    const cats = state.lookups["MASTER:ASSET_CATEGORY"] || [], subs = state.lookups["MASTER:ASSET_SUBCATEGORY"] || [],
          types = state.lookups["MASTER:ASSET_TYPE"] || [];
    const opt = (rows, sel) => `<option value="">Select</option>` + rows.map(r => `<option value="${esc(r.value)}"${String(r.value) === String(sel) ? " selected" : ""}>${esc(r.label)}</option>`).join("");
    if (changed === "init") {
      document.getElementById("argCat").innerHTML = opt(cats, "");
      document.getElementById("argSub").innerHTML = opt([], "");
      document.getElementById("argType").innerHTML = opt([], "");
      return;
    }
    if (changed === "cat") {
      document.getElementById("argSub").innerHTML = opt(subs.filter(s => String(s.parentValue) === val("argCat")), "");
      document.getElementById("argType").innerHTML = opt([], "");
    }
    if (changed === "sub")
      document.getElementById("argType").innerHTML = opt(types.filter(t => String(t.parentValue) === val("argSub")), "");
  }

  // ------------------------------------------------------------------ form
  async function loadForm(typeId, templateId) {
    const qs = new URLSearchParams({ organizationId: state.organizationId });
    if (templateId) qs.set("templateId", templateId); else qs.set("assetTypeId", typeId);
    const res = await api("GET", `/form?${qs}`);
    if (!res.ok) { showMessage(res.error, "error"); return; }
    state.form = res.data.data;
    state.typeId = typeId;
    const sources = [...new Set(state.form.fields.map(f => f.lookupSource).filter(s => s && s.startsWith("MASTER:") && !TEXT_SOURCES.has(s) && s !== "MASTER:CONTRACT"))];
    await ensureLookups(sources);
    state.ruleSources = new Set((state.form.conditions || []).map(c => c.sourceFieldKey));
    document.getElementById("argTypeStep").hidden = true;
    document.getElementById("argFormPanel").hidden = false;
    const canWrite = state.asset ? CAN_EDIT : CAN_ADD;
    document.getElementById("argSave").hidden = !canWrite;
    if (!state.asset) {
      document.getElementById("argTitle").textContent = `New ${state.form.header.assetTypeName}`;
      document.getElementById("argMeta").innerHTML = `<span class="arg-note">Form ${esc(state.form.header.templateName)} v${esc(state.form.header.versionNo)} - saved assets start as Draft</span>`;
    }
    renderForm(canWrite);
    await evaluate();
  }

  async function ensureLookups(sources) {
    const missing = sources.filter(s => !state.lookups[s]);
    if (!missing.length) return;
    const res = await api("GET", `/lookups?organizationId=${state.organizationId}&sources=${encodeURIComponent(missing.join(","))}`);
    missing.forEach(s => { state.lookups[s] = []; });
    if (res.ok) (res.data.data || []).forEach(r => { (state.lookups[r.source] = state.lookups[r.source] || []).push(r); });
  }

  function isEditable(f) {
    return !SYSTEM_TYPES.has(f.dataTypeCode) && f.storageKind !== "SYSTEM" && !f.isReadOnly && !FIXED_SOURCES.has(f.lookupSource);
  }

  function initialValue(f) {
    if (FIXED_SOURCES.has(f.lookupSource)) {
      if (f.lookupSource === "MASTER:ASSET_TYPE") return String(state.typeId);
      if (f.lookupSource === "MASTER:ORGANIZATION") return String(state.organizationId);
      const type = (state.lookups["MASTER:ASSET_TYPE"] || []).find(t => String(t.value) === String(state.typeId));
      const sub = type && (state.lookups["MASTER:ASSET_SUBCATEGORY"] || []).find(s => String(s.value) === String(type.parentValue));
      if (f.lookupSource === "MASTER:ASSET_SUBCATEGORY") return state.stored[f.fieldKey] ?? (sub ? String(sub.value) : "");
      return state.stored[f.fieldKey] ?? (sub ? String(sub.parentValue) : "");
    }
    if (f.fieldKey in state.stored) return state.stored[f.fieldKey];
    return state.asset ? "" : (f.defaultValue ?? "");
  }

  function optionsFor(f) {
    if (!f.lookupSource) return null;
    if (f.lookupSource.startsWith("MASTER:")) return (state.lookups[f.lookupSource] || []).map(r => ({ value: String(r.value), label: r.label, parent: r.parentValue }));
    return (state.form.options || []).filter(o => o.fieldDefinitionId === f.fieldDefinitionId)
      .sort((a, b) => (a.displayOrder ?? 0) - (b.displayOrder ?? 0))
      .map(o => ({ value: String(o.optionValue), label: o.optionLabel, parent: o.parentValue }));
  }

  function renderForm(canWrite) {
    const form = document.getElementById("argForm");
    const sections = (state.form.sections || []).filter(s => s.isActive !== false).sort((a, b) => a.displayOrder - b.displayOrder);
    form.innerHTML = sections.map(s => {
      const fields = state.form.fields.filter(f => f.sectionId === s.sectionId).sort((a, b) => a.displayOrder - b.displayOrder);
      if (!fields.length) return "";
      return `<div class="arg-section"><h3>${esc(s.sectionLabel)}</h3><div class="pm-form-grid">${fields.map(f => fieldHtml(f, canWrite)).join("")}</div></div>`;
    }).join("") || `<p class="pm-empty">The form template has no fields.</p>`;
    filterModels();
  }

  function fieldHtml(f, canWrite) {
    const v = initialValue(f);
    const editable = canWrite && isEditable(f);
    const id = `argF_${f.fieldKey}`;
    const dis = editable ? "" : " disabled";
    const full = ["MULTILINE", "MULTI_SELECT", "MULTI_USER"].includes(f.dataTypeCode) ? " full" : "";
    const ph = f.placeholderText ? ` placeholder="${esc(f.placeholderText)}"` : "";
    let control;
    const opts = optionsFor(f);
    if (f.fieldKey === "asset_status") {
      control = `<input type="text" id="${id}" value="${esc(state.asset?.statusName || "Draft")}" disabled />`;
    } else if (f.lookupSource === "MASTER:CONTRACT") {
      control = `<input type="text" id="${id}" value="" disabled placeholder="Linked once contracts are available" />`;
    } else if (!editable && (SYSTEM_TYPES.has(f.dataTypeCode) || f.storageKind === "SYSTEM")) {
      control = `<input type="text" id="${id}" value="${esc(displayOf(f, v))}" disabled />`;
    } else if (opts && !TEXT_SOURCES.has(f.lookupSource) && f.dataTypeCode !== "TEXT") {
      const multi = MULTI_TYPES.has(f.dataTypeCode);
      const chosen = new Set(multi ? parseArray(v) : [String(v ?? "")]);
      control = `<select id="${id}" data-key="${esc(f.fieldKey)}"${multi ? " multiple size=\"5\"" : ""}${dis}>`
        + (multi ? "" : `<option value="">Select</option>`)
        + opts.map(o => `<option value="${esc(o.value)}" data-parent="${esc(o.parent ?? "")}"${chosen.has(o.value) ? " selected" : ""}>${esc(o.label)}</option>`).join("")
        + `</select>`;
    } else if (f.dataTypeCode === "YES_NO") {
      control = `<select id="${id}" data-key="${esc(f.fieldKey)}"${dis}><option value="">Select</option>`
        + ["Yes", "No"].map(x => `<option value="${x}"${v === x ? " selected" : ""}>${x}</option>`).join("") + `</select>`;
    } else if (f.dataTypeCode === "MULTILINE") {
      control = `<textarea id="${id}" data-key="${esc(f.fieldKey)}" rows="3"${ph}${dis}>${esc(v)}</textarea>`;
    } else if (f.dataTypeCode === "DATE") {
      control = `<input type="date" id="${id}" data-key="${esc(f.fieldKey)}" value="${esc(String(v || "").substring(0, 10))}"${dis} />`;
    } else if (["DECIMAL", "CURRENCY", "PERCENT"].includes(f.dataTypeCode)) {
      control = `<input type="number" step="any" id="${id}" data-key="${esc(f.fieldKey)}" value="${esc(v)}"${ph}${f.dataTypeCode === "PERCENT" ? " min=\"0\" max=\"100\"" : ""}${dis} />`;
    } else if (f.dataTypeCode === "QUANTITY_UNIT") {
      const [num, ...unit] = String(v || "").split(" ");
      control = `<span class="arg-qty"><input type="number" step="any" id="${id}" data-key="${esc(f.fieldKey)}" data-qty="n" value="${esc(num)}"${dis} />`
        + `<input type="text" data-key="${esc(f.fieldKey)}" data-qty="u" value="${esc(unit.join(" "))}" placeholder="unit"${dis} /></span>`;
    } else {
      control = `<input type="text" id="${id}" data-key="${esc(f.fieldKey)}" value="${esc(v)}"${ph}${dis} />`;
    }
    return `<label class="arg-field${full}" data-field="${esc(f.fieldKey)}">
      <span>${esc(f.displayLabel)} <b class="arg-req" hidden>*</b></span>${control}
      ${f.helpText ? `<small class="arg-help">${esc(f.helpText)}</small>` : ""}</label>`;
  }

  function displayOf(f, v) {
    if (v == null || v === "") return "";
    const opts = optionsFor(f);
    if (opts) { const o = opts.find(x => x.value === String(v)); if (o) return o.label; }
    return f.dataTypeCode === "DATETIME" ? dateTime(v) : String(v);
  }

  // Make selection filters models (5.1.14).
  function filterModels() {
    const make = document.querySelector('#argForm select[data-key="manufacturer_make"]');
    const model = document.querySelector('#argForm select[data-key="model"]');
    if (!model) return;
    const m = make ? make.value : "";
    Array.from(model.options).forEach(o => { if (o.value) o.hidden = !!m && o.dataset.parent !== m; });
    if (model.selectedOptions[0]?.hidden) model.value = "";
  }

  function readValues() {
    const out = {};
    document.querySelectorAll("#argForm [data-key]").forEach(el => {
      const key = el.dataset.key;
      if (el.dataset.qty) {
        const n = document.querySelector(`#argForm [data-key="${cssEsc(key)}"][data-qty="n"]`).value.trim();
        const u = document.querySelector(`#argForm [data-key="${cssEsc(key)}"][data-qty="u"]`).value.trim();
        out[key] = n === "" ? null : (u ? `${n} ${u}` : n);
        return;
      }
      if (el.multiple) { const a = Array.from(el.selectedOptions).map(o => o.value); out[key] = a.length ? a : null; return; }
      out[key] = el.value.trim() === "" ? null : el.value.trim();
    });
    return out;
  }

  function onFieldChange(ev) {
    const key = ev.target.dataset.key;
    if (key === "manufacturer_make") filterModels();
    if (key && state.ruleSources.has(key)) { clearTimeout(state.evalTimer); state.evalTimer = setTimeout(evaluate, 150); }
  }

  // Live visibility / mandatory from the template rules (same engine as the save).
  async function evaluate() {
    if (!state.form) return;
    const values = { ...state.stored, ...readValues() };
    Object.keys(values).forEach(k => { if (values[k] == null) delete values[k]; });
    const res = await api("POST", "/evaluate", { organizationId: state.organizationId, templateId: state.form.header.templateId, values });
    if (!res.ok) return;
    (res.data.data.fields || []).forEach(f => {
      state.evalState[f.fieldKey] = f;
      const wrap = document.querySelector(`#argForm [data-field="${cssEsc(f.fieldKey)}"]`);
      if (!wrap) return;
      wrap.hidden = !f.isVisible;
      wrap.querySelector(".arg-req").hidden = !f.isMandatory;
    });
  }

  // ------------------------------------------------------------------ save
  async function save() {
    if (!state.form) return;
    const a = state.asset;
    const values = readValues();
    const res = await api("POST", "", {
      organizationId: state.organizationId, assetId: a ? a.assetId : null, assetTypeId: state.typeId,
      values, hiddenDecisions: state.decisions, expectedRecordVersion: a ? a.recordVersion : null
    });
    const body = res.data || {};
    if (res.ok && body.result === "SAVED") {
      const warnings = (body.issues || []).filter(i => i.severity === "WARNING");
      await openAsset(body.id);
      showMessage(warnings.length ? "Saved with warnings -- see below." : "Asset saved.", "success");
      renderIssues(warnings);
      return;
    }
    if (body.issues && body.issues.length) {
      showMessage(body.result === "NEEDS_DECISION" ? "Decide what happens to the hidden values below, then save again." : "The asset was not saved. Fix the fields below.", "error");
      renderIssues(body.issues);
      return;
    }
    showMessage(res.error, "error");
    if (res.status === 409 && a) await openAsset(a.assetId);
  }

  function renderIssues(issues) {
    const host = document.getElementById("argIssues");
    document.querySelectorAll("#argForm .arg-invalid").forEach(el => el.classList.remove("arg-invalid"));
    if (!issues.length) { host.hidden = true; host.innerHTML = ""; return; }
    issues.forEach(i => { if (i.severity === "ERROR" && i.fieldKey) document.querySelector(`#argForm [data-field="${cssEsc(i.fieldKey)}"]`)?.classList.add("arg-invalid"); });
    const decisions = issues.filter(i => i.severity === "DECISION");
    const others = issues.filter(i => i.severity !== "DECISION");
    host.innerHTML = (others.length ? `<ul>${others.map(i => `<li class="arg-${i.severity === "ERROR" ? "error" : "warning"}">${esc(i.message)}</li>`).join("")}</ul>` : "")
      + decisions.map(i => `<div class="arg-decision"><span>${esc(i.message)}</span>
          <label class="arg-check"><input type="radio" name="argDec_${esc(i.fieldKey)}" data-arg-decision="${esc(i.fieldKey)}" value="RETAIN"${state.decisions[i.fieldKey] === "RETAIN" ? " checked" : ""} /> Keep</label>
          <label class="arg-check"><input type="radio" name="argDec_${esc(i.fieldKey)}" data-arg-decision="${esc(i.fieldKey)}" value="CLEAR"${state.decisions[i.fieldKey] === "CLEAR" ? " checked" : ""} /> Clear</label></div>`).join("");
    host.hidden = false;
  }

  function renderHistory() {
    document.getElementById("argHistory").innerHTML = (state.history || []).map(x => `
      <tr><td>${esc(dateTime(x.transitionedAt))}</td><td>${esc(x.fromStatus || "--")}</td><td>${esc(x.toStatus)}</td>
          <td>${esc(x.actorName || (x.actorEmployeeId ? "Employee #" + x.actorEmployeeId : "System"))}</td>
          <td>${esc(x.reasonText || x.reasonCode || "")}</td></tr>`).join("") || empty(5, "No history yet.");
  }

  // ------------------------------------------------------------------ lifecycle (429)
  async function loadLifecycle() {
    if (!state.asset) return;
    const res = await api("GET", `/${state.asset.assetId}/lifecycle?organizationId=${state.organizationId}`);
    if (!res.ok) return;
    state.lifecycle = res.data.data;
    document.getElementById("argLifecycleTab").hidden = false;
    renderLifecycle();
  }

  function needsText(m) {
    return [m.requiresReason ? "Reason" : null, m.referenceLabel || null, m.requiresEvidence ? "Evidence" : null,
            m.requiresApproval ? "Approval by another person" : null, m.requiresRegisteredForm ? "Saved on its form" : null,
            m.requiresOwner ? "Owner set" : null].filter(Boolean).join(", ") || "--";
  }

  function renderLifecycle() {
    const lc = state.lifecycle || {}, moves = lc.moves || [], changes = lc.changes || [];
    const pending = changes.find(c => c.changeStatus === "PENDING_APPROVAL");
    const host = document.getElementById("argPending");
    host.hidden = !pending;
    host.innerHTML = !pending ? "" : `
      <strong>Awaiting approval: ${esc(pending.fromStatusName)} &rarr; ${esc(pending.toStatusName)}</strong>
      <div class="arg-note">Requested by ${esc(pending.requestedByName || pending.requestedBy)} on ${esc(dateTime(pending.requestedDt))}</div>
      ${changeDetail(pending)}
      <div class="pm-message info">The person who asked for this change cannot approve or reject it.</div>
      <div class="arg-pending-actions">
        ${CAN_APPROVE ? `<button class="pm-button primary" type="button" data-arg-decide="APPROVE" data-arg-change="${pending.changeId}"><i class="fa-solid fa-check"></i> Approve</button>
        <button class="pm-button" type="button" data-arg-decide="REJECT" data-arg-change="${pending.changeId}"><i class="fa-solid fa-xmark"></i> Reject</button>` : ""}
        ${CAN_EDIT ? `<button class="pm-button" type="button" data-arg-decide="CANCEL" data-arg-change="${pending.changeId}">Cancel request</button>` : ""}
      </div>`;
    document.getElementById("argMoves").innerHTML = pending
      ? empty(4, "No other move while a change is awaiting approval.")
      : moves.map(m => `
        <tr><td>${statusChip(m.toStatusName, m.toPhaseName)}</td>
            <td>${esc(m.minimumGate)}<div class="arg-note">BRD ${esc(m.brdSource)}${m.mappingNote ? " - " + esc(m.mappingNote) : ""}</div></td>
            <td>${esc(needsText(m))}${m.blockedReason ? `<div class="arg-note">${esc(m.blockedReason)}</div>` : ""}</td>
            <td>${CAN_EDIT && !m.blockedReason ? `<button class="pm-button" type="button" data-arg-move="${esc(m.toStatusCode)}">${m.requiresApproval ? "Request" : "Move"}</button>` : ""}</td></tr>`).join("")
        || empty(4, "No move is configured from this status.");
    const outcome = { COMPLETED: "Completed", PENDING_APPROVAL: "Awaiting approval", APPROVED: "Approved", REJECTED: "Rejected", CANCELLED: "Cancelled" };
    document.getElementById("argChanges").innerHTML = changes.map(c => `
      <tr><td>${esc(dateTime(c.requestedDt))}</td><td>${esc(c.fromStatusName)}</td><td>${esc(c.toStatusName)}</td>
          <td>${esc(outcome[c.changeStatus] || c.changeStatus)}${c.decisionNote ? `<div class="arg-note">${esc(c.decisionNote)}</div>` : ""}</td>
          <td>${esc(c.requestedByName || c.requestedBy)}</td>
          <td>${esc(c.decidedByName || c.decidedBy || "--")}${c.decidedDt ? `<div class="arg-note">${esc(dateTime(c.decidedDt))}</div>` : ""}</td>
          <td>${changeDetail(c)}</td></tr>`).join("") || empty(7, "No lifecycle change yet.");
  }

  function changeDetail(c) {
    return [c.reasonText ? `<div>${esc(c.reasonText)}</div>` : "",
            c.referenceText ? `<div class="arg-note">${esc(c.referenceLabel || "Reference")}: ${esc(c.referenceText)}</div>` : "",
            c.evidenceText ? `<div class="arg-note">Evidence: ${esc(c.evidenceText)}</div>` : ""].join("");
  }

  function openMove(code) {
    const m = ((state.lifecycle || {}).moves || []).find(x => x.toStatusCode === code);
    if (!m) return;
    state.move = m;
    document.getElementById("argMoveTitle").textContent = `${m.requiresApproval ? "Request" : "Move"}: ${state.lifecycle.current?.statusName || ""} -> ${m.toStatusName}`;
    document.getElementById("argMoveGate").textContent = `Minimum gate (BRD ${m.brdSource}): ${m.minimumGate}.`
      + (m.requiresApproval ? " This change waits for approval by another person with approval rights." : "");
    document.getElementById("argMoveReasonLabel").textContent = m.requiresReason ? "Reason *" : "Reason";
    document.getElementById("argMoveRefWrap").hidden = !m.referenceLabel;
    document.getElementById("argMoveRefLabel").textContent = `${m.referenceLabel || "Reference"} *`;
    document.getElementById("argMoveEvWrap").hidden = !m.requiresEvidence;
    ["argMoveReason", "argMoveRef", "argMoveEv"].forEach(id => { document.getElementById(id).value = ""; });
    const msg = document.getElementById("argMoveMessage"); msg.hidden = true; msg.textContent = "";
    document.getElementById("argMoveModal").hidden = false;
  }

  async function submitMove() {
    const m = state.move;
    if (!m || !state.asset) return;
    const msg = document.getElementById("argMoveMessage");
    const res = await api("POST", `/${state.asset.assetId}/transition`, {
      organizationId: state.organizationId, toStatusCode: m.toStatusCode,
      reasonText: val("argMoveReason") || null, referenceText: m.referenceLabel ? (val("argMoveRef") || null) : null,
      evidenceText: m.requiresEvidence ? (val("argMoveEv") || null) : null,
      expectedRecordVersion: state.lifecycle?.current?.recordVersion ?? null
    });
    if (!res.ok) { msg.textContent = res.error; msg.hidden = false; return; }
    document.getElementById("argMoveModal").hidden = true;
    await openAsset(state.asset.assetId);
    selectTab("lifecycle");
    showMessage(res.data.result === "PENDING_APPROVAL" ? `Change to ${m.toStatusName} is awaiting approval.` : `Asset moved to ${m.toStatusName}.`, "success");
  }

  async function decide(changeId, decision) {
    const change = ((state.lifecycle || {}).changes || []).find(c => c.changeId === changeId);
    let note = null;
    if (decision === "REJECT") {
      note = await window.gracUi.promptRequired("Why is this change rejected?", { title: "Reject change", inputLabel: "Reason" });
      if (!note) return;
    } else if (!await window.gracUi.confirm(decision === "APPROVE"
      ? `Approve the move to ${change?.toStatusName || "the new status"}? The asset changes status at once.`
      : "Cancel this request?")) return;
    const res = await api("POST", `/lifecycle-changes/${changeId}/decide`, {
      organizationId: state.organizationId, decision, decisionNote: note, expectedRecordVersion: change?.recordVersion ?? null
    });
    if (!res.ok) { showMessage(res.error, "error"); return; }
    await openAsset(state.asset.assetId);
    selectTab("lifecycle");
    showMessage({ APPROVED: "Change approved.", REJECTED: "Change rejected.", CANCELLED: "Request cancelled." }[res.data.result] || "Done.", "success");
  }

  async function openMatrix() {
    const body = document.getElementById("argMatrixBody");
    document.getElementById("argMatrixModal").hidden = false;
    if (!state.organizationId) { body.innerHTML = empty(6, "Select an organization."); return; }
    body.innerHTML = empty(6, "Loading...");
    const res = await api("GET", `/lifecycle-matrix?organizationId=${state.organizationId}`);
    if (!res.ok) { body.innerHTML = empty(6, res.error); return; }
    body.innerHTML = (res.data.data || []).map(m => `
      <tr><td>${esc(m.fromStatusName)}</td><td>${esc(m.toStatusName)}</td><td>${esc(m.brdSource)}</td>
          <td>${esc(m.minimumGate)}${m.mappingNote ? `<div class="arg-note">${esc(m.mappingNote)}</div>` : ""}</td>
          <td>${esc(needsText(m))}</td><td>${m.isActive ? "Yes" : "No"}</td></tr>`).join("") || empty(6, "No transition rules.");
  }

  // ------------------------------------------------------------------ technology (430)
  const KIND_NAME = { FIRMWARE: "Firmware", OS: "Operating system" };
  const CLASS_INFO = {
    CURRENT: ["Current", "arg-ph-operation"], DUE_SOON: ["Due soon", "arg-tc-warn"], UNSUPPORTED: ["Unsupported", "arg-ph-exception"],
    EXCEPTION: ["Exception", "arg-tc-warn"], UNKNOWN: ["Unknown", "arg-ph-acquisition"], NOT_APPLICABLE: ["Not applicable", "arg-ph-retirement"]
  };
  const EXC_STATUS = { PENDING_APPROVAL: "Awaiting approval", APPROVED: "Active", EXPIRED: "Expired", REJECTED: "Rejected", WITHDRAWN: "Withdrawn", REVOKED: "Revoked" };

  async function loadTechnology() {
    if (!state.asset) return;
    const res = await api("GET", `/${state.asset.assetId}/technology?organizationId=${state.organizationId}`);
    if (!res.ok) return;
    state.tech = res.data.data;
    document.getElementById("argTechTab").hidden = false;
    renderTechnology();
  }

  function renderTechnology() {
    const t = state.tech || {};
    document.getElementById("argTechStatus").innerHTML = (t.status || []).map(x => {
      const [cls, css] = CLASS_INFO[x.classification] || [x.classification, "arg-ph-acquisition"];
      return `<tr><td>${esc(KIND_NAME[x.kind] || x.kind)}</td>
        <td>${esc(x.currentLabel || "--")}${x.buildPatchLevel ? `<div class="arg-note">Build / patch ${esc(x.buildPatchLevel)}</div>` : ""}
            ${x.minimumCompliantBuild || x.latestApprovedBuild ? `<div class="arg-note">Minimum compliant ${esc(x.minimumCompliantBuild || "--")}, latest approved ${esc(x.latestApprovedBuild || "--")}</div>` : ""}</td>
        <td>${esc(x.releaseStatusName || "--")}</td>
        <td><span class="arg-chip ${css}">${esc(cls)}</span>${x.classificationReason ? `<div class="arg-note">${esc(x.classificationReason)}</div>` : ""}</td>
        <td>${x.recommendedReleaseId ? esc(x.recommendedLabel) + (x.recommendedReleaseId === x.currentReleaseId ? ` <span class="arg-note">(installed)</span>` : "") : `<span class="arg-note">None approved for the model</span>`}</td>
        <td>${esc(date(x.supportEndDate) || "--")}<div class="arg-note">EOL ${esc(date(x.endOfLifeDate) || "--")}</div></td>
        <td>${x.exceptionId ? `#${esc(x.exceptionId)}<div class="arg-note">until ${esc(date(x.exceptionExpiry))}</div>` : "--"}</td></tr>`;
    }).join("") || empty(7, "No technology data.");
    document.getElementById("argFwHistory").innerHTML = (t.firmwareHistory || []).map(h => `
      <tr><td>${esc(date(h.installedDate) || "--")}${h.isCurrent ? ` <span class="arg-note">(current)</span>` : ""}</td><td>${esc(h.releaseLabel)}</td>
          <td>${esc(h.previousLabel || "--")}</td><td>${esc(h.source)}</td><td>${esc(h.result === "FAILED" ? "Failed" : "Successful")}</td>
          <td>${esc(h.rollbackNote || "")}</td><td>${esc(h.evidenceText || "")}</td><td>${esc(dateTime(h.enteredDt))}</td></tr>`).join("") || empty(8, "No firmware installation recorded.");
    document.getElementById("argOsHistory").innerHTML = (t.osHistory || []).map(h => `
      <tr><td>${esc(date(h.installedDate) || "--")}${h.isCurrent ? ` <span class="arg-note">(current)</span>` : ""}</td><td>${esc(h.releaseLabel)}</td>
          <td>${esc(h.buildPatchLevel || "--")}</td><td>${esc([h.previousLabel, h.previousBuildPatchLevel].filter(Boolean).join(" / ") || "--")}</td>
          <td>${esc(h.source)}</td><td>${esc(h.licenceReference || "")}</td><td>${esc(h.evidenceText || "")}</td><td>${esc(dateTime(h.enteredDt))}</td></tr>`).join("") || empty(8, "No operating-system installation recorded.");
    document.getElementById("argTechExceptions").innerHTML = (t.exceptions || []).map(e => {
      const actions = [];
      if (e.status === "PENDING_APPROVAL" && CAN_APPROVE) actions.push(["APPROVE", "Approve"], ["REJECT", "Reject"]);
      if (e.status === "PENDING_APPROVAL" && CAN_EDIT) actions.push(["WITHDRAW", "Withdraw"]);
      if (e.status === "APPROVED" && CAN_APPROVE) actions.push(["REVOKE", "Revoke"]);
      return `<tr><td>${esc(KIND_NAME[e.kind] || e.kind)}<div class="arg-note">${esc(e.releaseLabel)}</div></td>
        <td>${e.scope === "MODEL" ? "Every asset of " + esc(e.modelName || "the model") : "This asset"}</td>
        <td>${esc(e.reason)}<div class="arg-note">Controls: ${esc(e.compensatingControls)}</div></td>
        <td>${esc(e.ownerName || "--")}</td>
        <td>${esc(date(e.expiryDate))}${e.reviewDate ? `<div class="arg-note">Review ${esc(date(e.reviewDate))}</div>` : ""}</td>
        <td>${esc(EXC_STATUS[e.displayStatus] || e.displayStatus)}<div class="arg-note">Requested by ${esc(e.requestedByName || e.requestedBy)}${e.decidedBy ? "; decided by " + esc(e.decidedByName || e.decidedBy) : ""}</div>${e.decisionNote ? `<div class="arg-note">${esc(e.decisionNote)}</div>` : ""}</td>
        <td>${actions.map(([d, label]) => `<button class="pm-button" type="button" data-arg-exc-decide="${d}" data-arg-exc="${e.exceptionId}">${label}</button>`).join(" ")}</td></tr>`;
    }).join("") || empty(7, "No technology exception.");
  }

  function releaseOptions(kind, selected) {
    const rows = state.lookups[kind === "FIRMWARE" ? "MASTER:FIRMWARE" : "MASTER:OS_RELEASE"] || [];
    const current = ((state.tech || {}).status || []).find(x => x.kind === kind);
    const list = rows.map(r => ({ value: String(r.value), label: r.label }));
    if (current?.currentReleaseId && !list.some(o => o.value === String(current.currentReleaseId)))
      list.unshift({ value: String(current.currentReleaseId), label: current.currentLabel });
    return `<option value="">Select</option>` + list.map(o => `<option value="${esc(o.value)}"${o.value === String(selected ?? "") ? " selected" : ""}>${esc(o.label)}</option>`).join("");
  }

  async function openInstall(kind) {
    await ensureLookups(["MASTER:FIRMWARE", "MASTER:OS_RELEASE"]);
    state.installKind = kind;
    const current = ((state.tech || {}).status || []).find(x => x.kind === kind);
    document.getElementById("argInstallTitle").textContent = `Record ${kind === "FIRMWARE" ? "firmware" : "operating-system"} installation`;
    document.getElementById("argInstRelease").innerHTML = releaseOptions(kind, current?.recommendedReleaseId);
    document.getElementById("argInstDate").value = new Date().toISOString().substring(0, 10);
    ["argInstSource", "argInstBuild", "argInstLicence", "argInstRollback", "argInstEvidence"].forEach(id => { document.getElementById(id).value = ""; });
    document.getElementById("argInstResult").value = "SUCCESSFUL";
    ["argInstResultWrap", "argInstRollbackWrap"].forEach(id => { document.getElementById(id).hidden = kind !== "FIRMWARE"; });
    ["argInstBuildWrap", "argInstLicenceWrap"].forEach(id => { document.getElementById(id).hidden = kind !== "OS"; });
    const msg = document.getElementById("argInstMessage"); msg.hidden = true; msg.textContent = "";
    document.getElementById("argInstallModal").hidden = false;
  }

  async function submitInstall() {
    const kind = state.installKind, msg = document.getElementById("argInstMessage");
    const res = await api("POST", `/${state.asset.assetId}/technology/installations`, {
      organizationId: state.organizationId, kind, releaseId: Number(val("argInstRelease")) || 0,
      installedDate: val("argInstDate") || null, source: val("argInstSource") || null,
      result: kind === "FIRMWARE" ? val("argInstResult") : null,
      buildPatchLevel: kind === "OS" ? (val("argInstBuild") || null) : null,
      rollbackNote: kind === "FIRMWARE" ? (val("argInstRollback") || null) : null,
      licenceReference: kind === "OS" ? (val("argInstLicence") || null) : null,
      evidenceText: val("argInstEvidence") || null,
      expectedRecordVersion: state.asset.recordVersion ?? null
    });
    if (!res.ok) { msg.textContent = res.error; msg.hidden = false; return; }
    document.getElementById("argInstallModal").hidden = true;
    await openAsset(state.asset.assetId);
    selectTab("technology");
    showMessage("Installation recorded.", "success");
  }

  async function openException() {
    await ensureLookups(["MASTER:FIRMWARE", "MASTER:OS_RELEASE", "MASTER:EMPLOYEE"]);
    const st = (state.tech || {}).status || [];
    const flagged = st.find(x => x.classification === "UNSUPPORTED") || st.find(x => x.currentReleaseId) || st[0];
    document.getElementById("argExcKind").value = flagged?.kind || "FIRMWARE";
    fillExceptionReleases();
    document.getElementById("argExcScope").value = "ASSET";
    document.getElementById("argExcOwner").innerHTML = `<option value="">Select</option>`
      + (state.lookups["MASTER:EMPLOYEE"] || []).map(e => `<option value="${esc(e.value)}">${esc(e.label)}</option>`).join("");
    ["argExcReason", "argExcControls", "argExcExpiry", "argExcReview"].forEach(id => { document.getElementById(id).value = ""; });
    const msg = document.getElementById("argExcMessage"); msg.hidden = true; msg.textContent = "";
    document.getElementById("argExcModal").hidden = false;
  }

  function fillExceptionReleases() {
    const kind = val("argExcKind");
    const current = ((state.tech || {}).status || []).find(x => x.kind === kind);
    document.getElementById("argExcRelease").innerHTML = releaseOptions(kind, current?.currentReleaseId);
  }

  async function submitException() {
    const msg = document.getElementById("argExcMessage");
    const res = await api("POST", `/${state.asset.assetId}/technology/exceptions`, {
      organizationId: state.organizationId, scope: val("argExcScope"), kind: val("argExcKind"),
      releaseId: Number(val("argExcRelease")) || 0, reason: val("argExcReason") || null,
      compensatingControls: val("argExcControls") || null, ownerEmployeeId: Number(val("argExcOwner")) || null,
      expiryDate: val("argExcExpiry") || null, reviewDate: val("argExcReview") || null
    });
    if (!res.ok) { msg.textContent = res.error; msg.hidden = false; return; }
    document.getElementById("argExcModal").hidden = true;
    await loadTechnology();
    showMessage("Technology exception requested; it needs approval by another person.", "success");
  }

  async function decideException(id, decision) {
    const e = ((state.tech || {}).exceptions || []).find(x => x.exceptionId === id);
    let note = null;
    if (decision === "REJECT" || decision === "REVOKE") {
      note = await window.gracUi.promptRequired(decision === "REJECT" ? "Why is this exception rejected?" : "Why is this exception revoked?",
        { title: decision === "REJECT" ? "Reject exception" : "Revoke exception", inputLabel: "Reason" });
      if (!note) return;
    } else if (!await window.gracUi.confirm(decision === "APPROVE" ? "Approve this technology exception? It is active until its expiry date." : "Withdraw this request?")) return;
    const res = await api("POST", `/technology-exceptions/${id}/decide`, {
      organizationId: state.organizationId, decision, decisionNote: note, expectedRecordVersion: e?.recordVersion ?? null
    });
    if (!res.ok) { showMessage(res.error, "error"); return; }
    await loadTechnology();
    showMessage({ APPROVED: "Exception approved.", REJECTED: "Exception rejected.", WITHDRAWN: "Request withdrawn.", REVOKED: "Exception revoked." }[res.data.result] || "Done.", "success");
  }

  // ------------------------------------------------------------------ custody (431)
  async function loadCustody() {
    if (!state.asset) return;
    const res = await api("GET", `/${state.asset.assetId}/custody?organizationId=${state.organizationId}`);
    if (!res.ok) return;
    state.custody = res.data.data;
    document.getElementById("argCustodyTab").hidden = false;
    renderCustody();
  }

  function renderCustody() {
    const c = state.custody || {}, st = c.state || {};
    const ver = { VERIFIED: "Verified", DISPUTED: "Disputed", NOT_VERIFIED: "Not verified" };
    const freq = { MONTHLY: "monthly", QUARTERLY: "quarterly", HALF_YEARLY: "half-yearly", ANNUAL: "annual", CUSTOM: `every ${st.customIntervalDays} days` };
    const part = { CUSTODIAN: "custodian", OWNER: "asset owner", BOTH: "custodian and asset owner" };
    document.getElementById("argCustodyState").textContent =
      `Verification: ${ver[st.verificationStatus] || st.verificationStatus || "Not verified"}`
      + (st.lastAttestedDate ? `; last attested ${date(st.lastAttestedDate)}` : "")
      + (st.nextAttestationDate ? `; next attestation ${date(st.nextAttestationDate)}` : "") + ". "
      + (st.profileId && st.attestationRequired ? `Attestation profile v${st.profileVersion}: ${part[st.participant] || st.participant}, ${freq[st.frequency] || st.frequency}, due within ${st.dueWindowDays} days.`
                                                : "No attestation profile applies to this asset.");
    const statusName = { GENERATED: "Generated", PENDING: "Pending", IN_PROGRESS: "In progress", OVERDUE: "Overdue", CONFIRMED: "Awaiting approval",
                         DISPUTED: "Disputed", CLOSED: "Closed", CANCELLED: "Cancelled", ESCALATED: "Escalated", EXCEPTION: "Exception", RESOLVED: "Resolved" };
    const typeName = { INITIAL: "Initial acknowledgement", PERIODIC: "Periodic", CAMPAIGN: "Campaign", TRANSFER: "Transfer", RETURN: "Return", EVENT: "Event" };
    document.getElementById("argAssignments").innerHTML = (c.assignments || []).map(h => `
      <tr><td>${esc(date(h.effectiveFrom))}${h.isCurrent ? ` <span class="arg-note">(current)</span>` : ""}</td><td>${esc(date(h.effectiveTo) || "--")}</td>
          <td>${esc(h.ownerName || "--")}</td><td>${esc(h.custodianName || "--")}</td><td>${esc(h.departmentName || "--")}</td>
          <td>${esc([h.locationName, h.building, h.floor, h.room].filter(Boolean).join(" / ") || "--")}</td>
          <td>${esc(h.changeSource)}<div class="arg-note">${esc(h.enteredBy)} ${esc(dateTime(h.enteredDt))}</div></td></tr>`).join("") || empty(7, "No assignment history.");
    document.getElementById("argAttestations").innerHTML = (c.attestations || []).map(t => `
      <tr><td>${esc(typeName[t.attestationType] || t.attestationType)}</td><td>${esc(t.assigneeName || "--")}</td><td>${esc(date(t.dueDate))}</td>
          <td>${esc(statusName[t.displayStatus] || t.displayStatus)}${t.decisionNote ? `<div class="arg-note">${esc(t.decisionNote)}</div>` : ""}</td>
          <td>${t.response ? esc(t.response === "CONFIRM" ? "Confirmed" : "Disagreed") : "--"}${t.disagreementCategory ? `<div class="arg-note">${esc(t.disagreementCategory.replace(/_/g, " ").toLowerCase())}</div>` : ""}${t.comments ? `<div class="arg-note">${esc(t.comments)}</div>` : ""}</td>
          <td>${esc(t.attestedByName || "")}${t.responseDt ? `<div class="arg-note">${esc(dateTime(t.responseDt))}</div>` : ""}</td></tr>`).join("") || empty(6, "No acknowledgement or attestation yet.");
    // 432: verification exceptions of the asset.
    const outcome = { NO_CHANGE: "No change", RECORD_CORRECTION: "Record corrected", LOST_CONFIRMED: "Loss confirmed", DAMAGE_CONFIRMED: "Damage confirmed",
                      RETIREMENT_CONFIRMED: "Retirement confirmed", DUPLICATE_CONFIRMED: "Duplicate confirmed", OTHER: "Other" };
    document.getElementById("argVerExceptions").innerHTML = (c.exceptions || []).map(x => `
      <tr><td>#${esc(x.exceptionId)}<div class="arg-note">${esc(dateTime(x.reportedDt))}</div></td>
          <td>${esc(String(x.category || "").replace(/_/g, " ").toLowerCase())}</td><td>${esc(x.severity === "CRITICAL" ? "Critical" : "Standard")}</td>
          <td>${esc(x.investigatorName || "Unassigned")}</td><td>${esc(x.statusName)}</td><td>${esc(date(x.resolutionDue))}</td>
          <td>${esc(outcome[x.outcome] || "--")}</td></tr>`).join("") || empty(7, "No verification exception.");
  }

  // ------------------------------------------------------------------ helpers
  async function api(method, path, body) {
    try {
      const r = await fetch(U(base + path), {
        method, credentials: "same-origin",
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok || data.success === false) {
        const hint = r.status === 404 && !data.error ? " -- the Asset Configuration API was not found; deploy the latest API and Web build" : "";
        return { ok: false, status: r.status, data, errorNumber: data.errorNumber, error: data.error || `Request failed (HTTP ${r.status})${hint}.` };
      }
      return { ok: true, status: r.status, data };
    } catch (err) { return { ok: false, status: 0, data: {}, error: err.message }; }
  }
  function statusChip(name, phase) {
    const cls = phase ? "arg-ph-" + String(phase).toLowerCase() : "arg-ph-acquisition";
    return `<span class="arg-chip ${cls}" title="${esc(phase || "")}">${esc(name || "--")}</span>`;
  }
  function parseArray(v) { try { const a = JSON.parse(v || "[]"); return Array.isArray(a) ? a.map(String) : []; } catch (_) { return []; } }
  function cssEsc(v) { return window.CSS && CSS.escape ? CSS.escape(v) : String(v).replace(/"/g, '\\"'); }
  function empty(cols, text) { return `<tr><td colspan="${cols}" class="pm-empty">${esc(text)}</td></tr>`; }
  function showMessage(text, kind) {
    const el = document.getElementById("argMessage");
    el.textContent = text || ""; el.classList.toggle("success", kind === "success"); el.classList.toggle("info", kind === "info"); el.hidden = !text;
  }
  function hideMessage() { const el = document.getElementById("argMessage"); el.hidden = true; el.textContent = ""; }
  function val(id) { return (document.getElementById(id).value || "").trim(); }
  function date(v) { return v ? String(v).substring(0, 10) : ""; }   // SQL DATE values: yyyy-mm-dd, no time-zone shift
  function dateTime(v) { if (!v) return ""; const x = new Date(v); return isNaN(x) ? String(v) : x.toLocaleString(); }
  function esc(v) { return String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
})();
