
CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_contract
    @report_code     NVARCHAR(40),
    @organization_id BIGINT,
    @search          NVARCHAR(200) = NULL,
    @status          NVARCHAR(60)  = NULL,
    @asset_type_id   INT           = NULL,
    @date_from       DATE          = NULL,
    @date_to         DATE          = NULL,
    @days            INT           = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    -- Same date-driven processing as the contract list before reading (434, D35).
    EXEC grac_practice.sp_asset_contract_sync @organization_id = @organization_id;

    IF @report_code = N'CON_EXPIRY'
    BEGIN
        SELECT k.ContractId, k.ContractNumber, k.ContractName, k.VendorName AS Vendor, k.ContractType, k.ContractStatus,
               k.VersionInForce, k.EffectiveStart, k.EffectiveEnd, k.NoticeDate, k.DecisionDate, nx.next_date AS NextKeyDate,
               DATEDIFF(DAY, @today, k.EffectiveEnd) AS DaysToEnd, k.ContractOwner, k.ContractValue, k.CurrencyCode AS Currency,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_contracts(@organization_id, @search) k
         CROSS APPLY (SELECT MIN(d.dt) AS next_date
                        FROM (VALUES (k.EffectiveEnd), (k.NoticeDate), (k.DecisionDate)) d(dt)) nx
         WHERE ((@status IS NULL AND k.ContractStatus IN (N'ACTIVE', N'APPROVED')) OR k.ContractStatus = @status)
           AND (k.EffectiveEnd <= DATEADD(DAY, @days, @today) OR k.NoticeDate <= DATEADD(DAY, @days, @today)
                OR k.DecisionDate <= DATEADD(DAY, @days, @today))
         ORDER BY nx.next_date, k.ContractNumber
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'CON_RENEWALS'
    BEGIN
        SELECT r.renewal_id AS RenewalId, k.ContractNumber, k.ContractName, k.VendorName AS Vendor, r.renewal_type AS RenewalType,
               s.status_name AS Status, r.due_date AS DueDate, r.old_expiry AS CurrentExpiry, r.new_expiry AS ProposedExpiry,
               r.renewal_value AS RenewalValue, r.currency_code AS Currency, r.quotation_reference AS QuotationReference,
               k.ContractOwner,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.asset_contract_renewal r
          JOIN grac_practice.fn_asset_report_contracts(@organization_id, @search) k ON k.ContractId = r.contract_id
          JOIN grac_practice.entity_status_master s ON s.entity_status_id = r.current_status_id
         WHERE r.organization_id = @organization_id AND r.is_open = 1
           AND (@status IS NULL OR r.renewal_type = @status)
           AND (@date_from IS NULL OR r.due_date >= @date_from)
           AND (@date_to IS NULL OR r.due_date <= @date_to)
         ORDER BY r.due_date, k.ContractNumber
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'CON_COVERAGE_GAPS'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus, x.OwnerName AS Owner,
               g.CoverageTypeLabel AS CoverageType, g.GapKind AS Gap, g.CoverageStatus, g.ContractNumber,
               g.EffectiveStart, g.EffectiveEnd, g.MinimumPeriodMonths, g.MissingAction, g.Message,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_coverage_gaps(@organization_id) g
          JOIN grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x ON x.AssetId = g.AssetId
         WHERE (@status IS NULL OR g.GapKind = @status)
         ORDER BY x.AssetName, x.AssetId, g.CoverageType
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'CON_ENTITLEMENTS'
    BEGIN
        SELECT k.ContractNumber, k.ContractName, k.VendorName AS Vendor, k.ContractStatus, k.VersionInForce,
               en.product_sku AS ProductSku, en.description AS Description, ISNULL(opt.OptionLabel, en.coverage_type) AS CoverageType,
               en.quantity AS Quantity, en.unit AS Unit, en.service_level AS ServiceLevel, en.support_hours AS SupportHours,
               ISNULL(en.start_date, k.EffectiveStart) AS StartDate, ISNULL(en.end_date, k.EffectiveEnd) AS EndDate,
               en.exclusions AS Exclusions,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_contracts(@organization_id, @search) k
          JOIN grac_practice.asset_contract_entitlement en ON en.contract_id = k.ContractId AND en.version_id = k.CurrentVersionId
         OUTER APPLY (SELECT TOP 1 o.OptionLabel FROM grac_practice.fn_asset_field_options(@organization_id) o
                       WHERE o.OptionGroup = N'asset_field.coverage_type' AND o.OptionValue = en.coverage_type) opt
         WHERE (@status IS NULL OR k.ContractStatus = @status)
         ORDER BY k.ContractNumber, en.product_sku, en.entitlement_id
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'CON_CONTACTS'
    BEGIN
        SELECT k.ContractNumber, k.ContractName, vd.vendor_name AS Vendor, rl.role_name AS Role, e.employee_name AS Contact,
               e.email AS Email, CASE WHEN m.is_primary = 1 THEN N'Yes' ELSE N'No' END AS IsPrimary,
               m.preferred_channel AS PreferredChannel, CASE WHEN m.notification_participation = 1 THEN N'Yes' ELSE N'No' END AS Notifications,
               CASE WHEN m.version_id IS NULL THEN N'All versions' ELSE CONCAT(N'Version ', v.version_no) END AS AppliesTo,
               m.effective_start AS EffectiveStart, m.effective_end AS EffectiveEnd, m.status AS MappingStatus,
               m.validated_by AS ValidatedBy, m.validated_dt AS ValidatedDt,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.asset_contract_contact m
          JOIN grac_practice.fn_asset_report_contracts(@organization_id, @search) k ON k.ContractId = m.contract_id
          JOIN grac_practice.asset_contract_contact_role rl ON rl.role_code = m.role_code
          JOIN grac_practice.organization_employee e ON e.employee_id = m.employee_id
          JOIN grac_practice.organization_dependency_vendor vd ON vd.vendor_id = m.vendor_id
          LEFT JOIN grac_practice.asset_contract_version v ON v.version_id = m.version_id
         WHERE m.organization_id = @organization_id
           AND (@status IS NULL OR m.status = @status)
         ORDER BY k.ContractNumber, rl.display_order, e.employee_name
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE
        THROW 53101, 'Unknown report for the Contract family.', 1;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_technology
    @report_code     NVARCHAR(40),
    @organization_id BIGINT,
    @search          NVARCHAR(200) = NULL,
    @status          NVARCHAR(60)  = NULL,
    @asset_type_id   INT           = NULL,
    @date_from       DATE          = NULL,
    @date_to         DATE          = NULL,
    @days            INT           = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);
    IF @report_code NOT IN (N'TECH_UNSUPPORTED', N'TECH_DUE_SOON', N'TECH_FIRMWARE', N'TECH_OS', N'TECH_UNKNOWN')
        THROW 53101, 'Unknown report for the Technology family.', 1;

    -- Assets in use and the 430 classification (the dashboard technology rule, 451).
    SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus, x.OwnerName AS Owner,
           CASE ts.Kind WHEN N'FIRMWARE' THEN N'Firmware' ELSE N'Operating system' END AS Technology,
           ts.CurrentLabel AS CurrentVersion, ts.ReleaseStatusName AS ReleaseStatus, ts.SupportEndDate, ts.EndOfLifeDate,
           ts.RecommendedLabel AS RecommendedTarget, ts.Classification, ts.ClassificationReason, ts.ExceptionExpiry,
           COUNT(*) OVER () AS TotalRows
      FROM grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x
     CROSS APPLY grac_practice.fn_asset_technology_status(@organization_id, x.AssetId) ts
     WHERE x.InUse = 1 AND ts.Classification <> N'NOT_APPLICABLE'
       AND ((@report_code = N'TECH_UNSUPPORTED' AND ts.Classification IN (N'UNSUPPORTED', N'EXCEPTION'))
            OR (@report_code = N'TECH_DUE_SOON'
                AND (ts.Classification = N'DUE_SOON'
                     OR (ts.Classification = N'CURRENT' AND ts.SupportEndDate BETWEEN @today AND DATEADD(DAY, @days, @today))))
            OR (@report_code = N'TECH_FIRMWARE' AND ts.Kind = N'FIRMWARE')
            OR (@report_code = N'TECH_OS' AND ts.Kind = N'OS')
            OR (@report_code = N'TECH_UNKNOWN' AND ts.Classification = N'UNKNOWN'))
       AND (@status IS NULL OR ts.Classification = @status)
     ORDER BY x.AssetName, x.AssetId, ts.Kind
    OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_risk
    @report_code     NVARCHAR(40),
    @organization_id BIGINT,
    @search          NVARCHAR(200) = NULL,
    @status          NVARCHAR(60)  = NULL,
    @asset_type_id   INT           = NULL,
    @date_from       DATE          = NULL,
    @date_to         DATE          = NULL,
    @days            INT           = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;

    IF @report_code = N'RISK_CIA'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus, x.OwnerName AS Owner,
               vr.confidentiality AS Confidentiality, vr.integrity AS Integrity, vr.availability AS Availability,
               vr.method_used AS Method, vr.method_source AS MethodSource, vr.asset_value_score AS AssetValueScore,
               vr.asset_value_category AS AssetValue, vs.validation AS Validation, vr.validation_message AS ValidationMessage,
               vr.calculated_dt AS CalculatedDt,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x
          LEFT JOIN grac_practice.asset_valuation_result vr ON vr.asset_id = x.AssetId
         CROSS APPLY (SELECT ISNULL(vr.validation_status, N'NOT_RATED') AS validation) vs
         WHERE (@status IS NULL OR vs.validation = @status)
         ORDER BY x.AssetName, x.AssetId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'RISK_VALUE_DIST'
    BEGIN
        -- Assets in use by Asset Value: the dashboard distribution (451), with share and score range.
        SELECT d.category AS AssetValue, COUNT(*) AS Assets,
               CAST(ROUND(100.0 * COUNT(*) / NULLIF(SUM(COUNT(*)) OVER (), 0), 1) AS DECIMAL(5, 1)) AS SharePct,
               MIN(d.score) AS LowestScore, MAX(d.score) AS HighestScore,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_assets(@organization_id, NULL, @asset_type_id) x
          LEFT JOIN grac_practice.asset_valuation_result vr ON vr.asset_id = x.AssetId AND vr.validation_status = N'VALID'
         CROSS APPLY (SELECT ISNULL(vr.asset_value_category, N'Not rated') AS category, vr.asset_value_score AS score,
                             CASE WHEN vr.asset_value_category IS NULL THEN 1 ELSE 0 END AS last_) d
         WHERE x.InUse = 1
         GROUP BY d.category, d.last_
         ORDER BY d.last_, MAX(d.score) DESC, d.category
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'RISK_INHERENT_RESIDUAL'
    BEGIN
        -- Asset links of registered risks: the risk-value rule of 447 (dependency type Asset).
        SELECT rr.risk_number AS RiskNumber, rr.risk_title AS RiskTitle, rr.status_code AS RiskStatus,
               rr.inherent_rating_name AS InherentRating, rr.inherent_rating_score AS InherentScore,
               rr.residual_rating_name AS ResidualRating, ro.employee_name AS RiskOwner,
               x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, vr.asset_value_category AS AssetValue,
               vr.asset_value_score AS AssetValueScore,
               CASE WHEN rv.ReviewSuggested = 1 THEN N'Yes' ELSE N'No' END AS ReviewSuggested,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.risk_dependency_map m
          JOIN grac_practice.dependency_type_master dt ON dt.dependency_type_id = m.dependency_type_id
                                                      AND (dt.dependency_type_code = N'ASSET' OR dt.dependency_type_name = N'Asset')
          JOIN grac_practice.risk_register rr ON rr.risk_register_id = m.risk_register_id AND rr.organization_id = @organization_id
          JOIN grac_practice.fn_asset_report_assets(@organization_id, NULL, @asset_type_id) x ON x.AssetId = m.dependency_object_id
          LEFT JOIN grac_practice.asset_valuation_result vr ON vr.asset_id = x.AssetId AND vr.validation_status = N'VALID'
          LEFT JOIN grac_practice.fn_asset_risk_value(@organization_id) rv ON rv.RiskRegisterId = rr.risk_register_id
          LEFT JOIN grac_practice.organization_employee ro ON ro.employee_id = rr.risk_owner_employee_id
         WHERE (@search IS NULL OR x.AssetName LIKE N'%' + @search + N'%' OR rr.risk_title LIKE N'%' + @search + N'%'
                OR rr.risk_number LIKE N'%' + @search + N'%')
         ORDER BY rr.risk_number, x.AssetName
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE
        THROW 53101, 'Unknown report for the Risk and CIA family.', 1;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_governance
    @report_code     NVARCHAR(40),
    @organization_id BIGINT,
    @search          NVARCHAR(200) = NULL,
    @status          NVARCHAR(60)  = NULL,
    @asset_type_id   INT           = NULL,
    @date_from       DATE          = NULL,
    @date_to         DATE          = NULL,
    @days            INT           = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    -- The latest current snapshot: what the scorecard and the dashboard show (450 / 451).
    DECLARE @snap BIGINT = (SELECT TOP (1) snapshot_id FROM grac_practice.asset_governance_snapshot
                             WHERE organization_id = @organization_id AND is_current = 1 ORDER BY as_of_date DESC);
    DECLARE @kpi NVARCHAR(30) = CASE @report_code WHEN N'GOV_METADATA' THEN N'METADATA_COMPLETENESS'
                                                  WHEN N'GOV_OWNERSHIP' THEN N'OWNERSHIP_COMPLETENESS'
                                                  WHEN N'GOV_COVERAGE' THEN N'COVERAGE_COMPLIANCE'
                                                  WHEN N'GOV_EXCEPTION' THEN N'EXCEPTION_HEALTH' END;

    IF @report_code = N'GOV_SCORE'
    BEGIN
        SELECT s.snapshot_id AS SnapshotId, s.as_of_date AS AsOfDate, s.version_no AS VersionNo,
               CASE WHEN s.is_current = 1 THEN N'Yes' ELSE N'No' END AS IsCurrent, s.overall_score AS OverallScore,
               s.overall_rag AS Rating, s.overall_target AS Target, s.overall_warning AS Warning, s.source_code AS Source,
               s.item_count AS RecordCount, s.taken_by AS TakenBy, s.taken_dt AS TakenDt, s.superseded_dt AS SupersededDt,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.asset_governance_snapshot s
         WHERE s.organization_id = @organization_id
           AND (@status IS NULL OR s.overall_rag = @status)
           AND (@date_from IS NULL OR s.as_of_date >= @date_from)
           AND (@date_to IS NULL OR s.as_of_date <= @date_to)
         ORDER BY s.as_of_date DESC, s.version_no DESC
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'GOV_COMPONENTS'
    BEGIN
        SELECT s.as_of_date AS AsOfDate, s.version_no AS SnapshotVersion, d.kpi_name AS Kpi,
               CASE WHEN k.is_enabled = 1 THEN N'Yes' ELSE N'No' END AS Enabled, k.numerator AS Numerator, k.denominator AS Denominator,
               k.excluded_count AS Excluded, k.failing_count AS Failing, k.score AS Score, k.rag AS Rating,
               k.target_value AS Target, k.warning_value AS Warning, k.weight AS Weight, k.direction AS Direction,
               k.period_days AS PeriodDays,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.asset_governance_snapshot_kpi k
          JOIN grac_practice.asset_governance_snapshot s ON s.snapshot_id = k.snapshot_id
          JOIN grac_practice.asset_governance_kpi d ON d.kpi_code = k.kpi_code
         WHERE k.snapshot_id = @snap
           AND (@status IS NULL OR k.rag = @status)
         ORDER BY d.display_order
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @kpi IS NOT NULL
    BEGIN
        SELECT s.as_of_date AS AsOfDate, s.version_no AS SnapshotVersion, i.record_kind AS RecordKind, i.record_id AS RecordId,
               i.record_name AS RecordName, i.outcome AS Outcome, i.numerator AS Numerator, i.denominator AS Denominator,
               i.reason AS Reason,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.asset_governance_snapshot_item i
          JOIN grac_practice.asset_governance_snapshot s ON s.snapshot_id = i.snapshot_id
         WHERE i.snapshot_id = @snap AND i.kpi_code = @kpi
           AND (@status IS NULL OR i.outcome = @status)
           AND (@search IS NULL OR i.record_name LIKE N'%' + @search + N'%')
         ORDER BY CASE i.outcome WHEN N'FAIL' THEN 1 WHEN N'PASS' THEN 2 ELSE 3 END, i.record_name, i.record_id
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE
        THROW 53101, 'Unknown report for the Governance family.', 1;
END
GO

CREATE OR ALTER PROCEDURE grac_practice.sp_asset_report_privacy
    @report_code     NVARCHAR(40),
    @organization_id BIGINT,
    @search          NVARCHAR(200) = NULL,
    @status          NVARCHAR(60)  = NULL,
    @asset_type_id   INT           = NULL,
    @date_from       DATE          = NULL,
    @date_to         DATE          = NULL,
    @days            INT           = NULL,
    @page_number     INT           = 1,
    @page_size       INT           = 25
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @today DATE = CAST(SYSUTCDATETIME() AS DATE);

    IF @report_code = N'PRV_PERSONAL_DATA'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus,
               ps.PersonalDataProcessed, po.employee_name AS PrivacyOwner, ps.AssessmentStatus, ps.PrivacyReviewDate,
               ps.RetentionDueDate AS RetentionEnds, ps.LegalHold, ps.PrivacyStatus, ps.Failed, ps.Missing, ps.Partial,
               ps.Excepted, ps.Blocking,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_privacy_status(@organization_id, NULL) ps
          JOIN grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x ON x.AssetId = ps.AssetId
          LEFT JOIN grac_practice.organization_employee po ON po.employee_id = ps.PrivacyOwnerId
         WHERE ps.Applicability = N'APPLICABLE'
           AND (@status IS NULL OR ps.PrivacyStatus = @status)
         ORDER BY x.AssetName, x.AssetId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'PRV_DPIA'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus,
               v.hrp AS HighRiskProcessing, v.spc AS SpecialCategoryOrHealthData, v.chd AS ChildrenData,
               v.dreq AS DpiaRequired, v.dst AS DpiaStatus, v.pas AS PrivacyAssessment,
               dg.gap_count AS DpiaGaps, dg.messages AS DpiaGapDetail,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_privacy_values(@organization_id, NULL) v
          JOIN grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x ON x.AssetId = v.AssetId
         OUTER APPLY (SELECT COUNT(*) AS gap_count, STRING_AGG(CAST(g.Message AS NVARCHAR(MAX)), N' ') AS messages
                        FROM grac_practice.fn_asset_privacy_gaps(@organization_id, v.AssetId) g
                       WHERE g.RequirementCode = N'DPIA' AND g.IsExcepted = 0) dg
         WHERE v.pd IN (N'YES', N'UNKNOWN')
           AND (@status IS NULL OR (@status = N'GAP' AND dg.gap_count > 0) OR (@status = N'NO_GAP' AND dg.gap_count = 0))
         ORDER BY dg.gap_count DESC, x.AssetName, x.AssetId
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'PRV_MASK_ENC'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, g.RequirementName AS Requirement, g.GapKind AS Gap,
               g.Message, g.Enforcement, CASE WHEN g.IsExcepted = 1 THEN N'Yes' ELSE N'No' END AS Excepted, g.ExceptionExpiry,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_privacy_gaps(@organization_id, NULL) g
          JOIN grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x ON x.AssetId = g.AssetId
         WHERE g.RequirementCode IN (N'MASKING', N'ENCRYPTION')
           AND (@status IS NULL OR g.RequirementCode = @status)
         ORDER BY x.AssetName, x.AssetId, g.DisplayOrder
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'PRV_RETENTION'
    BEGIN
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.StatusName AS LifecycleStatus,
               v.rpol AS RetentionPolicy, v.rper AS RetentionPeriod, v.rtrg AS RetentionTrigger, v.lhold AS LegalHold,
               rt.RetentionDueDate AS RetentionEnds, DATEDIFF(DAY, @today, rt.RetentionDueDate) AS DaysLeft,
               orv.due_date AS OpenReviewDue, lrv.outcome AS LastDecision, lrv.completed_dt AS LastDecisionDt,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_privacy_values(@organization_id, NULL) v
          JOIN grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x ON x.AssetId = v.AssetId
         CROSS APPLY grac_practice.fn_asset_privacy_retention_calc(@organization_id, v.AssetId, v.rper, v.rtrg, v.RegisteredDate, v.psc) rt
         OUTER APPLY (SELECT TOP (1) r.due_date FROM grac_practice.asset_privacy_review r
                       WHERE r.asset_id = v.AssetId AND r.review_kind = N'RETENTION' AND r.status = N'OPEN'
                       ORDER BY r.due_date) orv
         OUTER APPLY (SELECT TOP (1) r.outcome, r.completed_dt FROM grac_practice.asset_privacy_review r
                       WHERE r.asset_id = v.AssetId AND r.review_kind = N'RETENTION' AND r.status = N'COMPLETED'
                       ORDER BY r.completed_dt DESC) lrv
         WHERE v.pd IN (N'YES', N'UNKNOWN') AND rt.RetentionDueDate IS NOT NULL
           AND rt.RetentionDueDate <= DATEADD(DAY, @days, @today)
           AND (@status IS NULL OR (@status = N'ENDED' AND rt.RetentionDueDate < @today)
                OR (@status = N'ENDING' AND rt.RetentionDueDate >= @today))
         ORDER BY rt.RetentionDueDate, x.AssetName
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE IF @report_code = N'PRV_EVIDENCE'
    BEGIN
        -- Evidence / certificate dates of assets in use (439, 9.1.7).
        SELECT x.AssetId, x.AssetName, x.AssetTypeName AS AssetType, x.OwnerName AS Owner, ef.evidence_name AS Evidence,
               v.value_date AS ExpiryDate, DATEDIFF(DAY, @today, v.value_date) AS DaysLeft,
               CASE WHEN v.value_date < @today THEN N'Expired' ELSE N'Expiring' END AS ExpiryState,
               CASE WHEN ef.restrict_on_expiry = 1 THEN N'Yes' ELSE N'No' END AS RestrictsUseOnExpiry,
               COUNT(*) OVER () AS TotalRows
          FROM grac_practice.fn_asset_report_assets(@organization_id, @search, @asset_type_id) x
          JOIN grac_practice.asset_field_value v ON v.asset_id = x.AssetId AND v.value_date IS NOT NULL
          JOIN grac_practice.asset_field_definition fd ON fd.field_definition_id = v.field_definition_id
          JOIN grac_practice.asset_evidence_field ef ON ef.field_key = fd.field_key AND ef.is_active = 1
         WHERE x.InUse = 1 AND v.value_date <= DATEADD(DAY, @days, @today)
           AND (@status IS NULL OR (@status = N'EXPIRED' AND v.value_date < @today)
                OR (@status = N'EXPIRING' AND v.value_date >= @today))
         ORDER BY v.value_date, x.AssetName
        OFFSET (@page_number - 1) * @page_size ROWS FETCH NEXT @page_size ROWS ONLY;
    END
    ELSE
        THROW 53101, 'Unknown report for the Privacy and Compliance family.', 1;
END
GO
PRINT '452: Contract, Technology, Risk, Governance and Privacy report procedures created.';
GO
